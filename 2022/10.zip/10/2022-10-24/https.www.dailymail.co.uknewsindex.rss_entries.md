# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## Top marks! Headmaster who runs his own chip shop is in line for prestigious award
 - [https://www.dailymail.co.uk/news/article-11350619/Top-marks-Headmaster-runs-chip-shop-line-prestigious-award.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350619/Top-marks-Headmaster-runs-chip-shop-line-prestigious-award.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 23:54:19+00:00

Lee Humphreys is the head-teacher of a comprehensive school. But by night, he works in his own fish and chip shop. The unconventional sideline has seen pupils dub him as Mr Chips.

## Lidia Thorpe vows: 'I'm not going anywhere' despite romance with ex-Rebels bikie boss Dean Martin
 - [https://www.dailymail.co.uk/news/article-11350329/Lidia-Thorpe-vows-Im-not-going-despite-romance-ex-Rebels-bikie-boss-Dean-Martin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350329/Lidia-Thorpe-vows-Im-not-going-despite-romance-ex-Rebels-bikie-boss-Dean-Martin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 23:51:41+00:00

Controversial Greens Senator Lidia Thorpe has vowed 'I'm not going anywhere' and will fight for the rights of First Nations people despite revelations of a secret romance with an ex-bikie gang leader.

## KFC workers are caught licking pieces of cooked chicken in Australia
 - [https://www.dailymail.co.uk/news/article-11350113/KFC-workers-caught-licking-pieces-cooked-chicken-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350113/KFC-workers-caught-licking-pieces-cooked-chicken-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 23:42:12+00:00

A group of young Australian KFC workers have been slammed for a viral video where they appear to lick pieces of cooked chicken, grab handfuls of lettuce and throw around food.

## Biden AND Obama will reunite to campaign in Pennsylvania as Fetterman takes lead
 - [https://www.dailymail.co.uk/news/article-11350073/Biden-Obama-reunite-campaign-Pennsylvania-Fetterman-takes-lead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350073/Biden-Obama-reunite-campaign-Pennsylvania-Fetterman-takes-lead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 23:41:36+00:00

President Joe Biden is expected to join forces with President Barack Obama in Pennsylvania the final weekend before the midterm elections, to lock down key races in the state.

## More worrying footage shows Biden looking confused after tree planting event at White House
 - [https://www.dailymail.co.uk/news/article-11350297/More-worrying-footage-shows-Biden-looking-confused-tree-planting-event-White-House.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350297/More-worrying-footage-shows-Biden-looking-confused-tree-planting-event-White-House.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 23:38:47+00:00

President Joe Biden, 70, appeared confused as he tried to make his way back to the White House following a tree planting event for the groundskeeper on the South Lawn on Monday.

## Boris Johnson will continue his backing for Ukraine in Russia war
 - [https://www.dailymail.co.uk/news/article-11350489/Boris-Johnson-continue-backing-Ukraine-Russia-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350489/Boris-Johnson-continue-backing-Ukraine-Russia-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 23:37:02+00:00

Boris Johnson is set to keep his promise to his friend Volodymyr Zelensky and keep flying the flag for Ukraine amid Putin's invasion, following his aborted Downing Street bid.

## Molly Russell's father hits out at Instagram for its 'slow' introduction of age verification softwar
 - [https://www.dailymail.co.uk/news/article-11350575/Molly-Russells-father-hits-Instagram-slow-introduction-age-verification-softwar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350575/Molly-Russells-father-hits-Instagram-slow-introduction-age-verification-softwar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 23:32:31+00:00

Molly Russell's (pictured) father has slammed Instagram for being 'so slow' in introducing age verification technology to protect children on the platform.

## Medibank private health insurance confirms customers data exposed in hack, adding to ahm breach
 - [https://www.dailymail.co.uk/news/article-11350501/Medibank-private-health-insurance-confirms-customers-data-exposed-hack-adding-ahm-breach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350501/Medibank-private-health-insurance-confirms-customers-data-exposed-hack-adding-ahm-breach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 23:29:00+00:00

Medibank revealed the recent hack is far worse than first thought, with millions of customers' data exposed,  including names, addresses, birthdates, Medicare numbers and claims data.

## From NHS to migration, what can we expect? We take a look at Rishi Sunak's vision for Britain
 - [https://www.dailymail.co.uk/news/article-11350571/From-NHS-migration-expect-look-Rishi-Sunaks-vision-Britain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350571/From-NHS-migration-expect-look-Rishi-Sunaks-vision-Britain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 23:24:57+00:00

He kept his cards close to his chest in the leadership race, but Rishi Sunak outlined his vision for Britain when he sparred with Liz Truss in hustings held over the summer.

## Biden likes to carry cash on so he can slip it to children for ice cream: report
 - [https://www.dailymail.co.uk/news/article-11350403/Biden-likes-carry-cash-slip-children-ice-cream-report.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350403/Biden-likes-carry-cash-slip-children-ice-cream-report.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 23:18:51+00:00

'I've seen him comfort people who were in tears talking about their ... hardships ... and give a young person money for ice cream just for sitting through the speech,' a former aide said.

## Charlise Mutten's mother seen for the FIRST time since her nine-year-old daughter's alleged murder
 - [https://www.dailymail.co.uk/news/article-11347383/Charlise-Muttens-mother-seen-time-nine-year-old-daughters-alleged-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347383/Charlise-Muttens-mother-seen-time-nine-year-old-daughters-alleged-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 23:16:10+00:00

Charlise Mutten's mother has been seen in public for the first time since the nine-year-old alleged murder in January, as Kallista Mutten, 39, was sentenced for stealing guns and ammunition.

## Murder investigation launched after woman dies in 'serious assault' inside home in Shoreham, Sussex
 - [https://www.dailymail.co.uk/news/article-11350485/Murder-investigation-launched-woman-dies-assault-inside-home-Shoreham-Sussex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350485/Murder-investigation-launched-woman-dies-assault-inside-home-Shoreham-Sussex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 23:15:13+00:00

Police have arrested a 64-year-old man after a woman, 59, was found dead in a home in Shoreham, Sussex on Monday afternoon.

## Meet the King of Countdown: The superfan who notched up the highest score in the show's history
 - [https://www.dailymail.co.uk/news/article-11350483/Meet-King-Countdown-superfan-notched-highest-score-shows-history.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350483/Meet-King-Countdown-superfan-notched-highest-score-shows-history.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 23:14:31+00:00

Tom Stevenson, 21, may live a quiet life but he has been feted on Twitter as 'an idol' and 'a hero' after he smashed two highly coveted records on popular Channel 4 show Countdown.

## Woman in critical condition after incident at Derbyshire retirement complex
 - [https://www.dailymail.co.uk/news/article-11350523/Woman-critical-condition-incident-Derbyshire-retirement-complex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350523/Woman-critical-condition-incident-Derbyshire-retirement-complex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 23:10:24+00:00

A woman is in a critical condition in hospital after an alleged assault in Shirland Court retirement complex in Shelton Lock, Derby. One man has been arrested in connection with the incident.

## Police review vetting system after rapist officer was hired despite 'liking' inappropriate posts
 - [https://www.dailymail.co.uk/news/article-11350513/Police-review-vetting-rapist-officer-hired-despite-liking-inappropriate-posts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350513/Police-review-vetting-rapist-officer-hired-despite-liking-inappropriate-posts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 23:08:01+00:00

Constable James Ford, 31, formerly of Bishop's Stortford, Hertfordshire, was jailed for 18 years last week as a judge described a 'horrific catalogue' of abuse against his victim that lasted over two years.

## Biden slips and calls Kamala Harris a 'great president' when wishing her happy birthday
 - [https://www.dailymail.co.uk/news/article-11350435/Biden-slips-calls-Kamala-Harris-great-president-wishing-happy-birthday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350435/Biden-slips-calls-Kamala-Harris-great-president-wishing-happy-birthday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 23:02:47+00:00

President Biden called Kamala Harris a 'great president' as he wished her a happy belated birthday on Monday.

## St Louis police name 19-year-old former student Orlando Harris as school gunman
 - [https://www.dailymail.co.uk/news/article-11350451/St-Louis-police-19-year-old-former-student-Orlando-Harris-school-gunman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350451/St-Louis-police-19-year-old-former-student-Orlando-Harris-school-gunman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 22:44:03+00:00

Orlando Harris, 19, was a former student at Central Visual and Performing Arts High School. He shot and killed a female teacher and a teenage girl before being shot dead by police on Monday morning.

## PICTURED: Maryland 'squatters' dump McDonald's in the trash and fill-up their neon Camaro with gas
 - [https://www.dailymail.co.uk/news/article-11349983/PICTURED-Maryland-squatters-dump-McDonalds-trash-neon-Camaro-gas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349983/PICTURED-Maryland-squatters-dump-McDonalds-trash-neon-Camaro-gas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 22:40:29+00:00

Photos snapped Monday show at least three of the unauthorized occupants who invaded the home in an upscale suburb of Maryland - unbeknownst to the couple who attempted to move in.

## NYPD's most-complained-about cop says his ways appear 'ugly' but are 'needed' to fight off crime
 - [https://www.dailymail.co.uk/news/article-11350223/NYPDs-complained-cop-says-ways-appear-ugly-needed-fight-crime.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350223/NYPDs-complained-cop-says-ways-appear-ugly-needed-fight-crime.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 22:39:04+00:00

Lieutenant Eric Dym, who retired from the force in October, insisted cops like him are 'the ones that you want to come to your door if, God forbid, you should ever need the police'.

## Anthony Albanese's government announces plan to build one million homes
 - [https://www.dailymail.co.uk/news/article-11350437/Anthony-Albaneses-government-announces-plan-build-one-million-homes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350437/Anthony-Albaneses-government-announces-plan-build-one-million-homes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 22:37:21+00:00

Building one million new homes will be the target of a Labor plan to bring together governments, the construction industry and super funds to boost investment in affordable housing.

## White House defends Biden border record after annual crossings top 2.76 million
 - [https://www.dailymail.co.uk/news/article-11350111/White-House-defends-Biden-border-record-annual-crossings-2-76-million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350111/White-House-defends-Biden-border-record-annual-crossings-2-76-million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 22:35:16+00:00

The White House defended its handling Monday of a record border crisis, saying the whole of the Western hemisphere was feeling the impact of people fleeing repressive regimes.

## EPHRAIM HARDCASTLE: Keir Starmer's schoolboy dust-up
 - [https://www.dailymail.co.uk/news/article-11350465/EPHRAIM-HARDCASTLE-Keir-Starmers-schoolboy-dust-up.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350465/EPHRAIM-HARDCASTLE-Keir-Starmers-schoolboy-dust-up.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 22:34:22+00:00

EPHRAIM HARDCASTLE: Sir Keir Starmer startles LBC interviewer Nick Ferrari by admitting that, as a schoolboy at Reigate Grammar, he indulged in fisticuffs.

## Emily Nicole Thompson seen smiling at a party weeks before alleged murder by ex in Strathpine
 - [https://www.dailymail.co.uk/news/article-11350185/Emily-Nicole-Thompson-seen-smiling-party-weeks-alleged-murder-ex-Strathpine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350185/Emily-Nicole-Thompson-seen-smiling-party-weeks-alleged-murder-ex-Strathpine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 22:05:50+00:00

Aaron Daniel Mitchelson Huckel, 19, has been charged over the alleged murder of Emily Nicole Thompson, 18, after police say the couple  met at a carpark in Strathpine in Brisbane 's north.

## GUY ADAMS: Rishi Sunak's grandparents came with next to nothing. But hard work changed everything
 - [https://www.dailymail.co.uk/news/article-11350251/GUY-ADAMS-Rishi-Sunaks-grandparents-came-hard-work-changed-everything.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350251/GUY-ADAMS-Rishi-Sunaks-grandparents-came-hard-work-changed-everything.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 21:57:29+00:00

During his teenage years, our future Prime Minister would spend weekends on his bicycle, delivering prescriptions to customers. Studying economics, he also began helping out by doing the books.

## Washington woman suffers 'significant' injuries after black bear attack
 - [https://www.dailymail.co.uk/news/article-11349477/Washington-woman-suffers-significant-injuries-black-bear-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349477/Washington-woman-suffers-significant-injuries-black-bear-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 21:41:49+00:00

A Washington state woman out walking her dog survived a bear attack after whacking the beast right in its nose, but not escaping without suffering significant injuries to her 'head and groin,' area.

## Will Joe Biden face an economy spiral like Liz Truss
 - [https://www.dailymail.co.uk/news/article-11341937/Will-Joe-Biden-face-economy-spiral-like-Liz-Truss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11341937/Will-Joe-Biden-face-economy-spiral-like-Liz-Truss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 21:38:53+00:00

President Joe Biden could find himself in  situation similar to that of British Prime Minister Liz Truss as the rising U.S. deficit and high inflation rate could make investors nervous, causing a drop in markets.

## Starmer vows to bring in tough sentences for protesters after activists vandalise the King's waxwork
 - [https://www.dailymail.co.uk/news/article-11350085/Starmer-vows-bring-tough-sentences-protesters-activists-vandalise-Kings-waxwork.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350085/Starmer-vows-bring-tough-sentences-protesters-activists-vandalise-Kings-waxwork.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 21:38:13+00:00

Eilidh McFadden, 20, was free to vault a security barrier and vandalise the statue of Charles - a noted environmentalist - despite arrests at two previous protests.

## Christian Porter engaged to criminal lawyer girlfriend Karen Espiner with huge diamond ring
 - [https://www.dailymail.co.uk/news/article-11350303/Christian-Porter-engaged-criminal-lawyer-girlfriend-Karen-Espiner-huge-diamond-ring.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350303/Christian-Porter-engaged-criminal-lawyer-girlfriend-Karen-Espiner-huge-diamond-ring.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 21:37:17+00:00

Former attorney-general Christian Porter and Karen Espiner were smiling from ear to ear at the Telethon Ball on Saturday night, where she wore a large diamond ring and showed a butterfly tattoo.

## New PM Rishi Sunak prepares for first day with a hellish in-tray and £40bn budget blackhole
 - [https://www.dailymail.co.uk/news/article-11350205/New-PM-Rishi-Sunak-prepares-day-hellish-tray-40bn-budget-blackhole.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350205/New-PM-Rishi-Sunak-prepares-day-hellish-tray-40bn-budget-blackhole.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 21:35:51+00:00

Rishi Sunak is preparing for his first day as Prime Minister with a hellish in-tray that includes soaring inflation, rising energy bills and a £49billion blackhole as he decides on a new cabinet

## Armed police and Met anti-terror units rush to incident in North London
 - [https://www.dailymail.co.uk/news/article-11350313/Armed-police-Met-anti-terror-units-rush-incident-North-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350313/Armed-police-Met-anti-terror-units-rush-incident-North-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 21:35:11+00:00

Emergency services are currently in attendance at an incident in Satter Mews, Stoke Newington, following reports of a person 'experiencing a mental health crisis'.

## Moment security guard drags climate activist from The View audience for shouting 'f*** you Ted Cruz'
 - [https://www.dailymail.co.uk/news/article-11350177/Moment-security-guard-drags-climate-activist-View-audience-shouting-f-Ted-Cruz.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350177/Moment-security-guard-drags-climate-activist-View-audience-shouting-f-Ted-Cruz.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 21:35:06+00:00

Video shared by Extinction Rebellion NYC shows the moment a climate protester was dragged out of The View's audience Monday for shouting down Republican Sen. Ted Cruz.

## Ukraine slams Emanuel Macron over move to broker peace talks with Vladimir Putin
 - [https://www.dailymail.co.uk/news/article-11350271/Ukraine-slams-Emanuel-Macron-broker-peace-talks-Vladimir-Putin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350271/Ukraine-slams-Emanuel-Macron-broker-peace-talks-Vladimir-Putin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 21:34:45+00:00

It comes as French President Emmanuel Macron urged Western leaders to negotiate 'around a table' with Russian despot Vladimir Putin.

## Harvey Weinstein is wheeled into courtroom for his LA rape trial where jury hears lurid accusations
 - [https://www.dailymail.co.uk/news/article-11349989/Harvey-Weinstein-wheeled-courtroom-LA-rape-trial-jury-hears-lurid-accusations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349989/Harvey-Weinstein-wheeled-courtroom-LA-rape-trial-jury-hears-lurid-accusations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 21:28:29+00:00

Disgraced Harvey Weinstein was wheeled into the courtroom for his LA rape trial with a jury set to hear details from eight women of how he sexually assaulted them.

## Fraudster Billy McFarland is hatching a comeback with mysterious new business venture
 - [https://www.dailymail.co.uk/news/article-11350071/Fraudster-Billy-McFarland-hatching-comeback-mysterious-new-business-venture.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350071/Fraudster-Billy-McFarland-hatching-comeback-mysterious-new-business-venture.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 21:25:46+00:00

Billy McFarland, 31, posted a cryptic video to his TikTok page in which he teased an event to which 'everybody's invited,' mere months after completing his sentence for fraud.

## James Tupper values Anne Heche's estate at $2M
 - [https://www.dailymail.co.uk/news/article-11349805/James-Tupper-values-Anne-Heches-estate-2M.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349805/James-Tupper-values-Anne-Heches-estate-2M.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 21:22:15+00:00

In a new petition for probate, James Tupper, 57 - who is currently locked in a legal battle with Anne Heche's son - challenging Homer Heche Laffoon's appraisal of his mother's estate of  $400,000.

## Mum of murdered nine-year-old girl Charlise Mutten to face court today
 - [https://www.dailymail.co.uk/news/article-11350253/Mum-murdered-nine-year-old-girl-Charlise-Mutten-face-court-today.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350253/Mum-murdered-nine-year-old-girl-Charlise-Mutten-face-court-today.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 21:12:41+00:00

A Sydney court is due to sentence the mother of murdered nine-year-old Charlise Mutten over a home invasion.

## Former Louisville Cardinals cheerleader Eric Ortiz died unexpectedly over the weekend
 - [https://www.dailymail.co.uk/news/article-11349763/Former-Louisville-Cardinals-cheerleader-Eric-Ortiz-died-unexpectedly-weekend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349763/Former-Louisville-Cardinals-cheerleader-Eric-Ortiz-died-unexpectedly-weekend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 21:04:21+00:00

Eric Ortiz, a 10-time national champion and former Louisville Cardinals cheerleader, was found dead over the weekend at just 30-years-old. His cause of death has not been revealed.

## Families fight back over cockerel ban on allotment after officials receive ONE noise complaint
 - [https://www.dailymail.co.uk/news/article-11350217/Families-fight-cockerel-ban-allotment-officials-receive-ONE-noise-complaint.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11350217/Families-fight-cockerel-ban-allotment-officials-receive-ONE-noise-complaint.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 21:01:18+00:00

A new management regime and a 72-year-old law banning cockerels from the nation's allotments mean they all face the chop. This comes after a Yorkshire allotment change in ownership.

## Potential juror excused from Trump Org trial says 'there's no way in hell' she could be impartial
 - [https://www.dailymail.co.uk/news/article-11349949/Potential-juror-excused-Trump-Org-trial-says-theres-no-way-hell-impartial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349949/Potential-juror-excused-Trump-Org-trial-says-theres-no-way-hell-impartial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 20:48:58+00:00

The former president himself has not been charged with any wrongdoing in the case, which has enveloped his family's real estate empire.

## US diplomat jailed in Russia for 'smuggling weed in contact lenses' is moved to secret penal colony
 - [https://www.dailymail.co.uk/news/article-11349689/US-diplomat-jailed-Russia-smuggling-weed-contact-lenses-moved-secret-penal-colony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349689/US-diplomat-jailed-Russia-smuggling-weed-contact-lenses-moved-secret-penal-colony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 20:42:13+00:00

Marc Fogel (pictured with his sisters) has been transferred to the camp without warning and his family have no contact.

## Rishi Sunak studied at Stanford but NONE of his professors remember him
 - [https://www.dailymail.co.uk/news/article-11349439/Rishi-Sunak-studied-Stanford-NONE-professors-remember-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349439/Rishi-Sunak-studied-Stanford-NONE-professors-remember-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 20:40:36+00:00

Rishi Sunak is also breaking boundaries as the first Stanford-educated UK leader, with the university arming him for the job with an MBA from its world-renown business school.

## Michigan Gov. Gretchen Whitmer seizes 6-point lead in new poll
 - [https://www.dailymail.co.uk/news/article-11349883/Michigan-Gov-Gretchen-Whitmer-seizes-6-point-lead-new-poll.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349883/Michigan-Gov-Gretchen-Whitmer-seizes-6-point-lead-new-poll.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 20:39:08+00:00

Wisconsin GOP Sen. Ron Johnson narrowly leads Mandela Barnes 50-49, while Tim Ryan and J.D. Vance are in a dead heat Ohio, in polls in two hard-fought seats that are key to control of the Senate.

## Shameless driver fined for high-risk sex act on busy Australian motorway
 - [https://www.dailymail.co.uk/news/article-11349921/Shameless-driver-fined-high-risk-sex-act-busy-Australian-motorway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349921/Shameless-driver-fined-high-risk-sex-act-busy-Australian-motorway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 20:29:18+00:00

The driver was hit with a $1,087 fine and four demerit points after his female passenger failed to wear her seatbelt correctly while engaging in a high-risk act on the Pacific Motorway at Coomera.

## India illuminates for Diwali: Hindus celebrate festival of light with record-breaking show of lamps
 - [https://www.dailymail.co.uk/news/article-11349607/India-illuminates-Diwali-Hindus-celebrate-festival-light-record-breaking-lamps.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349607/India-illuminates-Diwali-Hindus-celebrate-festival-light-record-breaking-lamps.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 19:43:37+00:00

Indians have celebrated Diwali as earthen oil lamps and dazzling lights lit up homes and streets across the country to mark the Hindu festival that symbolises the victory of light over darkness.

## Images show parts of the Mississippi River completely dried up by drought
 - [https://www.dailymail.co.uk/news/article-11349047/Images-shows-parts-Mississippi-River-completely-dried-drought.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349047/Images-shows-parts-Mississippi-River-completely-dried-drought.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 19:39:13+00:00

The rapid reduction is the worst seen since  1988, when a scorching drought overtook much of Middle America.

## Pensioners have been living on a building site for nearly 18 months
 - [https://www.dailymail.co.uk/news/article-11349821/Pensioners-living-building-site-nearly-18-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349821/Pensioners-living-building-site-nearly-18-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 19:36:51+00:00

Pensioners in Ebbw Vale, south Wales, have been living in the middle of an abandoned building site for over a year with their homes surrounded by mounds of rubble and half-finished buildings.

## Biden claims DEMS are 'fiscally responsible' in speech claiming he doesn't 'pay attention' to polls
 - [https://www.dailymail.co.uk/news/article-11349555/Biden-claims-DEMS-fiscally-responsible-speech-claiming-doesnt-pay-attention-polls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349555/Biden-claims-DEMS-fiscally-responsible-speech-claiming-doesnt-pay-attention-polls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 19:36:47+00:00

Biden insisted Democrats are 'fiscally responsible' when defending his  record to a room full of volunteers and organizers and said he isn't 'paying attention' to the polls two weeks ahead of midterms.

## Kanye West is DROPPED by Johnny Depp's lawyer Camille Vasquez and top talent agency CAA
 - [https://www.dailymail.co.uk/tvshowbiz/article-11349661/Kanye-West-DROPPED-Johnny-Depps-lawyer-Camille-Vasquez-talent-agency-CAA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11349661/Kanye-West-DROPPED-Johnny-Depps-lawyer-Camille-Vasquez-talent-agency-CAA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 19:33:05+00:00

Kanye West has been dropped by Camille Vasquez, the lawyer who defended Johnny Depp, as well as top talent agency CAA.

## U.S. accuses 13 Chinese spies of 'interfering with rights and freedoms' of American people
 - [https://www.dailymail.co.uk/news/article-11349701/U-S-accuses-13-Chinese-spies-interfering-rights-freedoms-American-people.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349701/U-S-accuses-13-Chinese-spies-interfering-rights-freedoms-American-people.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 19:28:57+00:00

'These cases lays bare the Chinese government's flagrant violation of international laws as they work to project their authoritarian view around the world,' said FBI Director Chris Wray

## Footballer who appeared on Wayne Rooney's TV show jailed again
 - [https://www.dailymail.co.uk/news/article-11349131/Footballer-appeared-Wayne-Rooneys-TV-jailed-again.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349131/Footballer-appeared-Wayne-Rooneys-TV-jailed-again.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 19:28:34+00:00

Ryan Wilson was serving four and a half years in Glenochil Prison, Clackmannanshire, when he was caught. He previously starred on Wayne Rooney's Sky show in 2010.

## 'He'll be better than Liz - but it won't be difficult!' Voters on the street back Rishi Sunak
 - [https://www.dailymail.co.uk/news/article-11349433/Hell-better-Liz-wont-difficult-Voters-street-Rishi-Sunak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349433/Hell-better-Liz-wont-difficult-Voters-street-Rishi-Sunak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 19:24:59+00:00

As the UK prepares to welcome Rishi Sunak as its third PM in under two months, voters across the country reacted with bemusement at the rip-roaring speed of events in Westminster.

## More than FIFTY people were shot in Chicago over the weekend
 - [https://www.dailymail.co.uk/news/article-11349277/More-FIFTY-people-shot-Chicago-weekend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349277/More-FIFTY-people-shot-Chicago-weekend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 19:06:35+00:00

Chicago police reported  51 shooting victims in the windy city over the weekend with 11 incidents being fatal. About nine of the victims were juveniles.

## Terrifying moment impatient Mercedes motorist RAMS learner driver off M1 near Nottingham
 - [https://www.dailymail.co.uk/news/article-11349537/Terrifying-moment-impatient-Mercedes-motorist-RAMS-learner-driver-M1-near-Nottingham.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349537/Terrifying-moment-impatient-Mercedes-motorist-RAMS-learner-driver-M1-near-Nottingham.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 18:56:23+00:00

This is the jaw-dropping moment when a learner driver's Peugeot was smashed off the road by an impatient Mercedes driver on the M1 between Sutton-in-Ashfield to Nottingham.

## Saudi Crown Prince MBS 'mocks Biden, 79, by making fun of gaffes and questioning his mental acuity'
 - [https://www.dailymail.co.uk/news/article-11349621/Saudi-Crown-Prince-MBS-mocks-Biden-79-making-fun-gaffes-questioning-mental-acuity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349621/Saudi-Crown-Prince-MBS-mocks-Biden-79-making-fun-gaffes-questioning-mental-acuity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 18:46:09+00:00

Saudi Crown Prince Mohammed bin Salman is no fan of President Biden, according to a new report.

## Criss Angels admits he panicked during botched stunt involving Ginuwine
 - [https://www.dailymail.co.uk/news/article-11348905/Criss-Angels-admits-panicked-botched-stunt-involving-Ginuwine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348905/Criss-Angels-admits-panicked-botched-stunt-involving-Ginuwine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 18:44:36+00:00

Criss Angel has admitted that his 'heart was in his mouth' as he watched R&amp;B singer Ginuwine pass out during a stunt gone wrong while filming the magician's new TV series on The CW.

## Missing Harmony Montgomery's father is charged with murder
 - [https://www.dailymail.co.uk/news/article-11349595/Missing-Harmony-Montgomerys-father-charged-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349595/Missing-Harmony-Montgomerys-father-charged-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 18:39:40+00:00

Harmony vanished sometime in late November or early December of 2019, but cops were only made aware of her disappearance last fall.

## Comedian Leslie Jordan dies at age 67
 - [https://www.dailymail.co.uk/news/article-11349725/Comedian-Leslie-Jordan-dies-age-67.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349725/Comedian-Leslie-Jordan-dies-age-67.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 18:39:31+00:00

Comedian Leslie Jordan has died after crashing his BMW into the side of a building in Hollywood on Monday.  The actor was 67. Police officials the actor 'suffered some sort of medical emergency'.

## Lucy Letby trial hears TV doctor and his colleagues 'raised concerns' about the neonatal nurse
 - [https://www.dailymail.co.uk/news/article-11349579/Lucy-Letby-trial-hears-TV-doctor-colleagues-raised-concerns-neonatal-nurse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349579/Lucy-Letby-trial-hears-TV-doctor-colleagues-raised-concerns-neonatal-nurse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 18:34:49+00:00

The neonatal nurse, 32, is standing trial charged with killing seven babies and the attempted murder of a further 10 at the Countess of Chester Hospital between between June 2015 and June 2016.

## Nearly all of America's schoolkids have studied or picked up critical race theory in class: survey
 - [https://www.dailymail.co.uk/news/article-11348759/Nearly-Americas-schoolkids-studied-picked-critical-race-theory-class-survey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348759/Nearly-Americas-schoolkids-studied-picked-critical-race-theory-class-survey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 18:34:48+00:00

While most Americans support teaching high schoolers about slavery and racism, many are opposed to CRT, which many see as a rewrite of history to indoctrinate kids with 'woke' ideology.

## TikTok star who pushed for 'gender-affirming care' started transitioning in March
 - [https://www.dailymail.co.uk/news/article-11349337/TikTok-star-pushed-gender-affirming-care-started-transitioning-March.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349337/TikTok-star-pushed-gender-affirming-care-started-transitioning-March.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 18:30:05+00:00

Dylan Mulvaney, 25, has gained a massive following on TikTok as she documents her transition to a transgender female, and was able to interview President Joe Biden on Friday.

## Nicola Sturgeon demands Rishi Sunak calls early general election
 - [https://www.dailymail.co.uk/news/article-11349575/Nicola-Sturgeon-demands-Rishi-Sunak-calls-early-general-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349575/Nicola-Sturgeon-demands-Rishi-Sunak-calls-early-general-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 18:28:22+00:00

The Scottish First Minister also warned against 'another round of Tory austerity' amid fears next week's Halloween budget will see severe spending cuts.

## Joe Biden was 'complicit in six alleged white collar crimes' 634-page watchdog report claims
 - [https://www.dailymail.co.uk/news/article-11336417/Joe-Biden-complicit-six-alleged-white-collar-crimes-634-page-watchdog-report-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11336417/Joe-Biden-complicit-six-alleged-white-collar-crimes-634-page-watchdog-report-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 18:25:35+00:00

Report by Marco Polo claims Joe is complicit in tax evasion, violations of the Presidential Records Act and using nonpublic information from a government job for financial gain.

## Rishi rises to the occasion! Moment new PM appears to levitate as he celebrates winning race to No10
 - [https://www.dailymail.co.uk/news/article-11349531/Rishi-rises-occasion-Moment-new-PM-appears-levitate-celebrates-winning-race-No10.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349531/Rishi-rises-occasion-Moment-new-PM-appears-levitate-celebrates-winning-race-No10.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 18:23:53+00:00

During his celebrations, the newly crowned PM was filmed suddenly appearing to gain an inch or two as he waved to his fellow Tory MPs at the Conservative Party HQ.

## Kensington killer who confessed to unsolved 1980 murder now faces life in jail
 - [https://www.dailymail.co.uk/news/article-11349331/Kensington-killer-confessed-unsolved-1980-murder-faces-life-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349331/Kensington-killer-confessed-unsolved-1980-murder-faces-life-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 18:17:10+00:00

John Paul, 61, who confessed to the murder of barman Anthony Bird, 42, found naked and tied up in his Kensington apartment in 1980, is facing a life sentence.

## Woman who claims she was raped by friend of Benjamin Mendy denies it was 'normal, forgettable sex'
 - [https://www.dailymail.co.uk/news/article-11349351/Woman-claims-raped-friend-Benjamin-Mendy-denies-normal-forgettable-sex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349351/Woman-claims-raped-friend-Benjamin-Mendy-denies-normal-forgettable-sex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 17:47:07+00:00

Louis Saha Matturie (pictured), 41, is alleged to have raped the girl, then 18, in his Manchester flat in 2012 after a date at Nando's, Chester Crown Court heard.

## Republicans demand fact-check after Biden says student loan plan 'got passed by a vote or two'
 - [https://www.dailymail.co.uk/news/article-11349369/Republicans-demand-fact-check-Biden-says-student-loan-plan-got-passed-vote-two.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349369/Republicans-demand-fact-check-Biden-says-student-loan-plan-got-passed-vote-two.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 17:43:05+00:00

President Biden described his new student loan debt forgiveness plan he created by executive order as a 'law' that narrowly cleared Congress. House Republicans are calling for a fact check.

## Ted Cruz reveals that he hid in a CLOSET on January 6 before voting to overturn 2020 results
 - [https://www.dailymail.co.uk/news/article-11349081/Ted-Cruz-reveals-hid-CLOSET-January-6-voting-overturn-2020-results.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349081/Ted-Cruz-reveals-hid-CLOSET-January-6-voting-overturn-2020-results.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 17:42:58+00:00

The excerpt shows the moment Cruz first found out that the ex-president's supporters breached the Capitol, as lawmakers in both chambers were certifying Biden's win.

## Jill Biden comforts Mary J. Blige after singer chokes up at cancer event
 - [https://www.dailymail.co.uk/news/article-11348979/Jill-Biden-comforts-Mary-J-Blige-singer-chokes-cancer-event.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348979/Jill-Biden-comforts-Mary-J-Blige-singer-chokes-cancer-event.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 17:42:10+00:00

Jill Biden comforted Mary J. Blige during an event at the White House on Monday after the singer choked up talking about her family's battles with cancer.

## James Stunt received hundreds of thousands of pounds in cash delivered in sacks, court hears
 - [https://www.dailymail.co.uk/news/article-11349295/James-Stunt-received-hundreds-thousands-pounds-cash-delivered-sacks-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349295/James-Stunt-received-hundreds-thousands-pounds-cash-delivered-sacks-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 17:38:42+00:00

James Stunt, 40, the ex-husband of F1 heiress Petra Ecclestone, is standing trial alongside seven other defendants accused of hiding funds at Bradford-based Fowler Oldfield.

## Quinton Simon's father reveals the toddler's mother tried to pin the disappearance on him
 - [https://www.dailymail.co.uk/news/article-11348685/Quinton-Simons-father-reveals-toddlers-mother-tried-pin-disappearance-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348685/Quinton-Simons-father-reveals-toddlers-mother-tried-pin-disappearance-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 17:33:32+00:00

DailyMail.com located Quinton Simon's biological father at his home 85 miles from Savannah, Georgia, where Quinton was last seen.

## Man who was dressed as a woman and tried to have sex with a dog is jailed for 12 weeks
 - [https://www.dailymail.co.uk/news/article-11349373/Man-dressed-woman-tried-sex-dog-jailed-12-weeks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349373/Man-dressed-woman-tried-sex-dog-jailed-12-weeks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 17:31:58+00:00

Peter Lerwill, 30, from Hurstpierpoint, West Sussex, admitted the vile act after he was initially arrested and kept in custody when a shocked member of the public alerted police.

## Body language expert Judi James said incoming PM Sunak appeared 'robotic' during his first address
 - [https://www.dailymail.co.uk/news/article-11349281/Body-language-expert-Judi-James-said-incoming-PM-Sunak-appeared-robotic-address.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349281/Body-language-expert-Judi-James-said-incoming-PM-Sunak-appeared-robotic-address.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 17:18:22+00:00

Body language expert Judi James said the incoming Prime Minister Rishi Sunak, 'out did his predecessor' Liz Truss 'in the worst way' following his speech at Conservative HQ.

## Lecturers threaten to bring 150 universities across the UK 'to a complete standstill' with strikes
 - [https://www.dailymail.co.uk/news/article-11349287/Lecturers-threaten-bring-150-universities-UK-complete-standstill-strikes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349287/Lecturers-threaten-bring-150-universities-UK-complete-standstill-strikes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 16:51:20+00:00

Lecturers threatened to bring every university in the UK 'to a complete standstill' with strikes in a dispute over pensions and pay after the University and College Union voted 'yes' in two ballots.

## 80% of Republicans AND Democrats believe opposing party is a threat to America, according to poll
 - [https://www.dailymail.co.uk/news/article-11348953/80-Republicans-Democrats-believe-opposing-party-threat-America-according-poll.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348953/80-Republicans-Democrats-believe-opposing-party-threat-America-according-poll.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 16:46:08+00:00

A new poll reveals the depths of the nation's political divide, with some 80% of Democrats and Republicans claiming the political opposition poses a threat to the very existence of the U.S.

## Putin's state TV mouthpieces say 'racist' Ukrainians won't love Sunak like they did Boris
 - [https://www.dailymail.co.uk/news/article-11349177/Putins-state-TV-mouthpieces-say-racist-Ukrainians-wont-love-Sunak-like-did-Boris.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349177/Putins-state-TV-mouthpieces-say-racist-Ukrainians-wont-love-Sunak-like-did-Boris.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 16:43:57+00:00

Olga Skabeyeva, known as Putin's Iron Doll, blasted the new Conservative leader, saying 'racist' Ukrainians won't show him the same love they showed Boris Johnson.

## 3 dead, including shooter, in St. Louis high school shooting
 - [https://www.dailymail.co.uk/news/article-11349235/2-hurt-St-Louis-high-school-shooting-gunman-custody.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349235/2-hurt-St-Louis-high-school-shooting-gunman-custody.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 16:40:49+00:00

At least three people are dead, including the gunman, after a shooting at a Missouri high school. The shooting happened at the Center Visual and Performing Arts High School in St. Louis.

## Marco Rubio says canvasser wearing his t-shirt and a DeSantis hat was ATTACKED
 - [https://www.dailymail.co.uk/news/article-11349203/Marco-Rubio-says-canvasser-wearing-t-shirt-DeSantis-hat-ATTACKED.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349203/Marco-Rubio-says-canvasser-wearing-t-shirt-DeSantis-hat-ATTACKED.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 16:36:22+00:00

'Last night one of our canvassers wearing my T-shirt and a Desantis hat was brutally attacked by 4 animals who told him Republicans weren't allowed in their neighborhood,' Rubio said.

## Experts warn parents against trick or treating after spike in drugs being hidden in wrappers
 - [https://www.dailymail.co.uk/news/article-11349057/Experts-warn-parents-against-trick-treating-spike-drugs-hidden-wrappers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349057/Experts-warn-parents-against-trick-treating-spike-drugs-hidden-wrappers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 16:35:52+00:00

Parents are being urged to keep vigilant about what candy their children are picking up for Halloween amid an influx of deadly fentanyl hidden in sweet wrappers in 26 states.

## Climate activists heckle Ted Cruz on The View
 - [https://www.dailymail.co.uk/news/article-11349255/Climate-activists-heckle-Ted-Cruz-View.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349255/Climate-activists-heckle-Ted-Cruz-View.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 16:29:59+00:00

Whoopi Goldberg told the protesters to leave as they condemned the panel for their lack of coverage on on climate.

## Kari Lake dares NFL to take Super Bowl away fron Arizona if she declares 'invasion' at border
 - [https://www.dailymail.co.uk/news/article-11348935/Kari-Lake-dares-NFL-Super-Bowl-away-fron-Arizona-declares-invasion-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348935/Kari-Lake-dares-NFL-Super-Bowl-away-fron-Arizona-declares-invasion-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 16:21:30+00:00

Arizona Republican gubernatorial hopeful Kari Lake dared the National Football League to take the 2023 Super Bowl away from Arizona should she declare an 'invasion' at the southern border.

## Mother guilty of child cruelty after failing to protect baby son beaten to death by her boyfriend
 - [https://www.dailymail.co.uk/news/article-11348963/Mother-guilty-child-cruelty-failing-protect-baby-son-beaten-death-boyfriend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348963/Mother-guilty-child-cruelty-failing-protect-baby-son-beaten-death-boyfriend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 16:15:20+00:00

Tamika Beaton, 25, from Peckham, south-east London, turned a blind eye to the abuse inflicted on her son Andrew Cawker by boyfriend Scott Coombe, 24, in the months leading up to her toddler's death.

## Gary Lineker sparks fresh BBC bias row after rebuking Keir Starmer for branding eco-zealots arrogant
 - [https://www.dailymail.co.uk/news/article-11349049/Gary-Lineker-sparks-fresh-BBC-bias-row-rebuking-Keir-Starmer-branding-eco-zealots-arrogant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349049/Gary-Lineker-sparks-fresh-BBC-bias-row-rebuking-Keir-Starmer-branding-eco-zealots-arrogant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 16:14:58+00:00

The Match of the Day host, 61, was speaking out after protesters from the eco mob launched an attack at Madame Tussauds, which saw them smear cake on a waxwork of King Charles.

## Former osteopath 'decapitated' pensioner 'who refused to give her money' for a home renovation
 - [https://www.dailymail.co.uk/news/article-11348863/Former-osteopath-decapitated-pensioner-refused-money-home-renovation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348863/Former-osteopath-decapitated-pensioner-refused-money-home-renovation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 16:13:53+00:00

Jemma Mitchell, 38, was accused of killing Mee Kuen Chong, 67, at her home in Wembley before dumping her body more than 250 miles away in Salcombe, Devon.

## Girl, 14, becomes the latest NYC subway crime victim as she's stabbed by a group of girls
 - [https://www.dailymail.co.uk/news/article-11348901/Girl-14-latest-NYC-subway-crime-victim-shes-stabbed-group-girls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348901/Girl-14-latest-NYC-subway-crime-victim-shes-stabbed-group-girls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 16:07:02+00:00

A 14-year-old girl was knifed on a New York subway located in Washington Heights on Sunday by two girls that she knew.

## DAN WOOTTON: BBC's Boris gaffe proves corporation wants Tories to lose under Sunak
 - [https://www.dailymail.co.uk/news/article-11349183/DAN-WOOTTON-BBCs-Boris-gaffe-proves-corporation-wants-Tories-lose-Sunak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349183/DAN-WOOTTON-BBCs-Boris-gaffe-proves-corporation-wants-Tories-lose-Sunak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 15:55:17+00:00

DAN WOOTTON: Following Boris Johnson's decision to pull out of the Conservative leadership contest last night, the BBC's  news channel launched an impromptu on air celebration.

## Ex-Minneapolis cop pleads guilty to aiding and abetting charge in George Floyd's death
 - [https://www.dailymail.co.uk/news/article-11349033/Ex-Minneapolis-cop-pleads-guilty-aiding-abetting-charge-George-Floyds-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349033/Ex-Minneapolis-cop-pleads-guilty-aiding-abetting-charge-George-Floyds-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 15:42:38+00:00

J Alexander Kueng pleaded guilty on Monday to aiding and abetting second-degree manslaughter in connection with George Floyd's death.

## An appointment with the King, PMQs and a budget: How Rishi Sunak will spend his first week as PM
 - [https://www.dailymail.co.uk/news/article-11349103/An-appointment-King-PMQs-budget-Rishi-Sunak-spend-week-PM.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349103/An-appointment-King-PMQs-budget-Rishi-Sunak-spend-week-PM.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 15:42:32+00:00

First of all, the 42-year-old will have to make a trip to see King Charles at Buckingham Palace in order to be formally appointed as PM.

## Residential street becomes 'ghost road' after landlords ramped up rents by more than a THIRD
 - [https://www.dailymail.co.uk/news/article-11348677/Residential-street-ghost-road-landlords-ramped-rents-THIRD.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348677/Residential-street-ghost-road-landlords-ramped-rents-THIRD.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 15:42:32+00:00

Tenants on Galingale Road in Norris Green are relocating after receiving notice of 'sudden' rent increases - some upwards of £235 per month - as the UK battles the cost-of-living crisis.

## Shock as radio station announces 55-year-old host 'passed away while presenting his program'
 - [https://www.dailymail.co.uk/news/article-11349085/Shock-radio-station-announces-55-year-old-host-passed-away-presenting-program.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349085/Shock-radio-station-announces-55-year-old-host-passed-away-presenting-program.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 15:41:17+00:00

Tim Gough, 55, was presenting his breakfast show for GenX Radio Suffolk when the music stopped playing half way through a song, an hour into his slot.

## At least 60 people are killed by military junta airstrikes on Myanmar music festival
 - [https://www.dailymail.co.uk/news/article-11348793/At-60-people-killed-military-junta-airstrikes-Myanmar-music-festival.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348793/At-60-people-killed-military-junta-airstrikes-Myanmar-music-festival.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 15:37:42+00:00

The number of casualties at Sunday night's celebration in the northern state of Kachin appeared to be the most in a single air attack since the military seized power in February last year.

## Pupil who fell to death from window on Spain school trip messaged friends wanting to go back to park
 - [https://www.dailymail.co.uk/news/article-11349067/Pupil-fell-death-window-Spain-school-trip-messaged-friends-wanting-park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349067/Pupil-fell-death-window-Spain-school-trip-messaged-friends-wanting-park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 15:35:15+00:00

A teenage rugby player fell to his death from a seventh floor window on a Spanish school trip after messaging friends he wanted to go back to a park where they had been drinking, inquest hears.

## Joanne Harris faces Society of Authors vote on whether she should quit
 - [https://www.dailymail.co.uk/news/article-11348569/Joanne-Harris-faces-Society-Authors-vote-quit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348569/Joanne-Harris-faces-Society-Authors-vote-quit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 15:23:51+00:00

Ms Harris posted the poll on Twitter in August after Harry Potter author Ms Rowling had expressed her support for her fellow writer Sir Sir Salmon Rushdie, who had just been stabbed in the US.

## Top doctor slams University of Minnesota medical school for 'abandoning the Hippocratic oath'
 - [https://www.dailymail.co.uk/news/article-11348775/Top-doctor-slams-University-Minnesota-medical-school-abandoning-Hippocratic-oath.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348775/Top-doctor-slams-University-Minnesota-medical-school-abandoning-Hippocratic-oath.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 15:16:00+00:00

University of Minnesota students recited an oath promising to 'uproot the legacy and perpetuation of structural violence deeply embedded within the healthcare system'.

## Man from Barrow-in-Furness tells court his life was 'ruined' when he was 'falsely accused of rape'
 - [https://www.dailymail.co.uk/news/article-11349037/Man-Barrow-Furness-tells-court-life-ruined-falsely-accused-rape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349037/Man-Barrow-Furness-tells-court-life-ruined-falsely-accused-rape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 15:11:44+00:00

Jordan Trengove, 22, was accused of raping Eleanor Williams on a night out in Barrow-in-Furness, Cumbria. She has been charged with perverting the course of justice.

## Tarek Zahed: Dramatic moment senior Comanchero shows off injuries in court
 - [https://www.dailymail.co.uk/news/article-11347541/Tarek-Zahed-Dramatic-moment-senior-Comanchero-shows-injuries-court.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347541/Tarek-Zahed-Dramatic-moment-senior-Comanchero-shows-injuries-court.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 15:02:13+00:00

Comanchero bikie Tarek Zahed - who survived an assassination attempt which killed his brother and saw him shot ten times - has appeared in court from prison missing an eye.

## Federal Budget 2022: Aussies detail what they want from Treasurer Jim Chalmers
 - [https://www.dailymail.co.uk/news/article-11339293/Federal-Budget-2022-Centrelink-uni-students-cost-living.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11339293/Federal-Budget-2022-Centrelink-uni-students-cost-living.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 15:00:32+00:00

Australians are begging for cost of living relief in Anthony Albanese's first budget as they complain about $16 beers, fuel prices ballooning out of control, and the 'ridiculous' price of childcare.

## Progressive oppo research is targeting huge field for 2024 including Trump, DeSantis, and Cheney
 - [https://www.dailymail.co.uk/news/article-11348797/Progressive-oppo-research-targeting-huge-field-2024-including-Trump-DeSantis-Cheney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348797/Progressive-oppo-research-targeting-huge-field-2024-including-Trump-DeSantis-Cheney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 14:51:37+00:00

A progressive opposition group isn't just focusing their efforts on Donald Trump for 2024 - but has broadened their research to nearly two dozen candidates who might make a bid.

## Worshippers take two SEX DOLLS to Myanmar's holiest site to perform 'ritual incantations'
 - [https://www.dailymail.co.uk/news/article-11348821/Worshippers-two-SEX-DOLLS-Myanmars-holiest-site-perform-ritual-incantations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348821/Worshippers-two-SEX-DOLLS-Myanmars-holiest-site-perform-ritual-incantations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 14:47:34+00:00

Eight people tried to bring the pair of 'lady dolls' into the towering, gold-plated Shwedagon pagoda in Yangon on Saturday.

## School test results took a HISTORIC hit during the pandemic
 - [https://www.dailymail.co.uk/news/article-11348761/School-test-results-took-HISTORIC-hit-pandemic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348761/School-test-results-took-HISTORIC-hit-pandemic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 14:45:28+00:00

Government data show nearly four in 10 eighth graders failed to grasp basic math concepts - a sign of the devastating effect of the Covid-19 pandemic on America's children.

## Greenpeace activists occupy parliament - after Just Stop Oil mob smeared cake on Charles waxwork
 - [https://www.dailymail.co.uk/news/article-11349029/Greenpeace-activists-occupy-parliament-Just-Stop-Oil-mob-smeared-cake-Charles-waxwork.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11349029/Greenpeace-activists-occupy-parliament-Just-Stop-Oil-mob-smeared-cake-Charles-waxwork.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 14:45:00+00:00

Campaigners entered the Palace of Westminster as tourists and visitors sitting down on the floor, before linking arms and reading testimonies from people struggling with bills.

## World's longest timber-towered suspension bridge opens to the public on Michigan mountain
 - [https://www.dailymail.co.uk/news/article-11348617/Worlds-longest-timber-towered-suspension-bridge-opens-public-Michigan-mountain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348617/Worlds-longest-timber-towered-suspension-bridge-opens-public-Michigan-mountain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 14:44:50+00:00

Nestled in a postcard-perfect Boyne Valley in the wooded splendor of Northern Michigan, Sky-Bridge Michigan was unveiled in all its 1,200-foot glory last week, after six months of construction.

## Putin's relatives 'are concerned about his coughing fits and constant nausea'
 - [https://www.dailymail.co.uk/news/article-11348803/Putins-relatives-concerned-coughing-fits-constant-nausea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348803/Putins-relatives-concerned-coughing-fits-constant-nausea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 14:41:27+00:00

Despite appearing considerably bloated and puffy in the face, the Russian president has lost 18lbs in recent months, said the channel which purports to have sources inside the Kremlin

## Top Democrat Sean Patrick Maloney in danger of LOSING his New York seat
 - [https://www.dailymail.co.uk/news/article-11348805/Top-Democrat-Sean-Patrick-Maloney-danger-LOSING-New-York-seat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348805/Top-Democrat-Sean-Patrick-Maloney-danger-LOSING-New-York-seat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 14:41:02+00:00

The Cook Political Report has moved the reelection of New York Rep. Sean Patrick Maloney into the 'tossup' category - a stunning move for the man who chairs the House Democratic campaign arm.

## The challenges waiting in Rishi Sunak's in-tray:
 - [https://www.dailymail.co.uk/news/article-11348997/The-challenges-waiting-Rishi-Sunaks-tray.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348997/The-challenges-waiting-Rishi-Sunaks-tray.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 14:35:26+00:00

Rishi Sunak faces a daunting task as Prime Minister and is expected to reign back Liz Truss's unfunded tax cuts and spending commitments.

## FTSE jumps by almost one per cent as Rishi Sunak is confirmed as the next Prime Minister
 - [https://www.dailymail.co.uk/news/article-11348813/FTSE-jumps-one-cent-Rishi-Sunak-confirmed-Prime-Minister.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348813/FTSE-jumps-one-cent-Rishi-Sunak-confirmed-Prime-Minister.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 14:35:07+00:00

The FTSE 100, which had down earlier today as a stronger pound weighed on multinationals, rose around one per cent in reaction to the news that Ms Mordaunt had failed in her bid to become PM.

## Rishi Sunak set to appoint Cabinet TOMORROW as new PM faces monstrous in-tray
 - [https://www.dailymail.co.uk/news/article-11348615/Rishi-Sunak-set-appoint-Cabinet-TOMORROW-new-PM-faces-monstrous-tray.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348615/Rishi-Sunak-set-appoint-Cabinet-TOMORROW-new-PM-faces-monstrous-tray.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 14:29:59+00:00

The state of the economy, the war in Ukraine, possible elections in Northern Ireland, the Channel migrants crisis and reuniting the Tory party are all tasks waiting in the new PM's in-tray.

## Three New Yorkers died from fentanyl overdoses after ordering cocaine from the same delivery service
 - [https://www.dailymail.co.uk/news/article-11348703/Three-New-Yorkers-died-fentanyl-overdoses-ordering-cocaine-delivery-service.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348703/Three-New-Yorkers-died-fentanyl-overdoses-ordering-cocaine-delivery-service.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 14:28:25+00:00

Julia Ghahramani, 26, a first-year lawyer; Ross Mtangi, 40, a trading executive at Credit Suisse Group AG; and Amanda Scher, 36, a social worker all died on March 18, 2021 after ordering cocaine.

## Missing Michigan family is found safe in Wisconsin but are still 'convinced people are after them'
 - [https://www.dailymail.co.uk/news/article-11348739/Missing-Michigan-family-safe-Wisconsin-convinced-people-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348739/Missing-Michigan-family-safe-Wisconsin-convinced-people-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 14:26:30+00:00

Anthony and Suzette Cirigliano, 51, fled their home in Fremont, Michigan, with sons Brandon, 19, and Noah, 15, last week.

## ISIS fanatic who planned to bomb Barcelona-Madrid match is jailed for three years
 - [https://www.dailymail.co.uk/news/article-11348743/ISIS-fanatic-planned-bomb-Barcelona-Madrid-match-jailed-three-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348743/ISIS-fanatic-planned-bomb-Barcelona-Madrid-match-jailed-three-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 14:24:44+00:00

Mohammed Amrani was instructed by ISIS to fly a drone packed with explosives over Barcelona's Camp Nou stadium during a Barcelona-Madrid match and blow it up (file image).

## Liz Truss dons her shades again and heads out of Downing Street before congratulating Rishi Sunak
 - [https://www.dailymail.co.uk/news/article-11348849/Liz-Truss-dons-shades-heads-Downing-Street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348849/Liz-Truss-dons-shades-heads-Downing-Street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 14:22:28+00:00

Liz Truss donned another pair of large sunglasses as she headed out of Downing Street this afternoon - minutes after it was confirmed Rishi Sunak will succeed her.

## Sex offender, 55, who posed as doctor to sexually assault patient, 81, is jailed for three years
 - [https://www.dailymail.co.uk/news/article-11348635/Sex-offender-55-posed-doctor-sexually-assault-patient-81-jailed-three-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348635/Sex-offender-55-posed-doctor-sexually-assault-patient-81-jailed-three-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 14:17:17+00:00

Carl Burger, 55, sneaked into the cubicle at the Royal Liverpool Hospital and told the woman he was a medical professional who was performing an examination.

## Brisbane teen Emily Nicole Thompson allegedly murdered by Aaron Daniel Mitchelson Huckel in Nambour
 - [https://www.dailymail.co.uk/news/article-11348695/Brisbane-teen-Emily-Nicole-Thompson-allegedly-murdered-Aaron-Daniel-Mitchelson-Huckel-Nambour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348695/Brisbane-teen-Emily-Nicole-Thompson-allegedly-murdered-Aaron-Daniel-Mitchelson-Huckel-Nambour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 14:13:57+00:00

The final photo posted by a teenager before she was allegedly murdered by her  ex-boyfriend has been revealed - as friends and family share their fond memories of her.

## 'A big mistake': Trump fires shot at Ron DeSantis for backing a Republican candidate he's opposing
 - [https://www.dailymail.co.uk/news/article-11348669/donald-trump-ron-desantis-joe-odea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348669/donald-trump-ron-desantis-joe-odea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 14:05:23+00:00

DeSantis appears to have angered the former president by endorsing Joe O'Dea, a moderate GOP candidate in Colorado who has not shied away from criticizing Trump.

## Russia faces 'inevitable defeat' in Kherson, former head of UK armed forces says
 - [https://www.dailymail.co.uk/news/article-11348419/Russia-faces-inevitable-defeat-Kherson-former-head-UK-armed-forces-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348419/Russia-faces-inevitable-defeat-Kherson-former-head-UK-armed-forces-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 13:52:33+00:00

General Lord Dannatt, former chief of the UK general staff, said Russia is already carrying out a 'managed withdrawal' from Kherson to avoid a 'chaotic' rout.

## Couple who got engaged in Mauritius have returned back home with a couple of stray dogs
 - [https://www.dailymail.co.uk/news/article-11348655/Couple-got-engaged-Mauritius-returned-home-couple-stray-dogs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348655/Couple-got-engaged-Mauritius-returned-home-couple-stray-dogs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 13:51:23+00:00

A kind-hearted couple who got engaged in Mauritius have returned back home with more than a just a wedding to plan after adopting a couple of stray dogs.

## Australia interest rates: Barefoot Investor says he 'LOVES' higher interest rates - here's why
 - [https://www.dailymail.co.uk/news/article-11348629/Australia-rates-Barefoot-Investor-says-LOVES-higher-rates-heres-why.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348629/Australia-rates-Barefoot-Investor-says-LOVES-higher-rates-heres-why.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 13:48:25+00:00

The Barefoot Investor revealed he loves high interest rates because they encourage responsible practices - but admitted not all Australians will be happy with his advice.

## Republicans tear into Kansas' Democratic Governor for taxpayer-funded 'all ages' drag show
 - [https://www.dailymail.co.uk/news/article-11348621/Republicans-tear-Kansas-Democratic-Governor-taxpayer-funded-ages-drag-show.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348621/Republicans-tear-Kansas-Democratic-Governor-taxpayer-funded-ages-drag-show.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 13:44:36+00:00

Among the sponsors is the Kansas Creative Arts & Industries Commission, which is a part of the state's Department of Commerce. It's  led by Kelly's lieutenant governor, David Toland.

## NSW politics: Health minister and face of Covid pandemic Brad Hazzard will retire at 2023 election
 - [https://www.dailymail.co.uk/news/article-11348481/NSW-politics-Health-minister-face-Covid-pandemic-Brad-Hazzard-retire-2023-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348481/NSW-politics-Health-minister-face-Covid-pandemic-Brad-Hazzard-retire-2023-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 13:38:25+00:00

The long-time member for Wakehurst on Sydney's northern beaches is the second NSW minister within 24 hours and fifth in recent months to announce he won't contest another four-year term.

## Biden spins deficit victory but is actually adding to debt
 - [https://www.dailymail.co.uk/news/article-11348619/Biden-spins-deficit-victory-actually-adding-debt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348619/Biden-spins-deficit-victory-actually-adding-debt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 13:25:41+00:00

Joe Biden is spinning economic victory out of the $1.4 trillion reduction of the national deficit but the drop came with the ending of covid relief fundings and he is actually increasing government spending.

## The surveillance footage that EXONERATES Uvalde teacher falsely accused of leaving door open
 - [https://www.dailymail.co.uk/news/article-11348641/The-surveillance-footage-EXONERATES-Uvalde-teacher-falsely-accused-leaving-door-open.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348641/The-surveillance-footage-EXONERATES-Uvalde-teacher-falsely-accused-leaving-door-open.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 13:22:40+00:00

Uvalde police initially accused Elementary School teacher Emilia 'Amy' Marin of propping open the door Uvalde gunman Salvador Ramos, 18, entered through.

## JPMorgan Chase's $28.5M-a-year president Daniel Pinto says a 'deeper recession' is compromise
 - [https://www.dailymail.co.uk/news/article-11348567/JPMorgan-Chases-28-5M-year-president-Daniel-Pinto-says-deeper-recession-compromise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348567/JPMorgan-Chases-28-5M-year-president-Daniel-Pinto-says-deeper-recession-compromise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 13:22:08+00:00

Daniel Pinto, 59, believes that 'putting inflation back in a box' is 'very important', even if it causes a 'slightly deeper recession.'

## Rishi Sunak WILL be the next PM: Penny Mordaunt drops out of Tory race
 - [https://www.dailymail.co.uk/news/article-11348701/Rishi-Sunak-PM-Penny-Mordaunt-drops-Tory-race.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348701/Rishi-Sunak-PM-Penny-Mordaunt-drops-Tory-race.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 13:20:11+00:00

Rishi Sunak is set to be named the new PM shortly, with his sole remaining rival Ms Mordaunt a long way off the threshold of 100 nominations needed to trigger a run-off.

## Linguists slam Cambridge University for teaching 'woke' version of 'gender-neutral' German
 - [https://www.dailymail.co.uk/news/article-11348533/Linguists-slam-Cambridge-University-teaching-woke-version-gender-neutral-German.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348533/Linguists-slam-Cambridge-University-teaching-woke-version-gender-neutral-German.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 13:08:44+00:00

Language experts have slammed Cambridge University (pictured) for teaching and encouraging students to speak a new 'woke version' of gender-neutral German.

## Cruise ship Coral Princess goes into Covid lockdown after outbreak on board off WA coast
 - [https://www.dailymail.co.uk/news/article-11348503/Cruise-ship-Coral-Princess-goes-Covid-lockdown-outbreak-board-WA-coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348503/Cruise-ship-Coral-Princess-goes-Covid-lockdown-outbreak-board-WA-coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 13:08:22+00:00

A cruise ship carrying 1900 passengers and crew has gone into partial lockdown off the West Australian due to a Covid outbreak on board.

## Fife home with dodgy wiring, collapsed ceiling and overgrown garden is up for £50,000 at auction
 - [https://www.dailymail.co.uk/news/article-11348581/Fife-home-dodgy-wiring-collapsed-ceiling-overgrown-garden-50-000-auction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348581/Fife-home-dodgy-wiring-collapsed-ceiling-overgrown-garden-50-000-auction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 13:07:51+00:00

The terraced property is on the High Street in Cupar, Fife, where the average property sells for over £330,000 - nearly seven times the amount the house is on auction for.

## Brutal type of Covid 'does not exist anymore', claims ex-Government adviser
 - [https://www.dailymail.co.uk/health/article-11348133/Brutal-type-Covid-does-not-exist-anymore-claims-ex-Government-adviser.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11348133/Brutal-type-Covid-does-not-exist-anymore-claims-ex-Government-adviser.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 12:44:33+00:00

The version of Covid that sent the UK into lockdown and scores of people onto mechanical ventilation is essentially gone thanks to community immunity, an ex-Government scientific advisor has claimed.

## House prices in UK cities are now rising faster than suburban and rural homes as the WFH trend wanes
 - [https://www.dailymail.co.uk/news/article-11348451/House-prices-UK-cities-rising-faster-suburban-rural-homes-WFH-trend-wanes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348451/House-prices-UK-cities-rising-faster-suburban-rural-homes-WFH-trend-wanes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 12:42:06+00:00

House prices in cities have been increasing at a greater rate than in rural areas as workers have been heading back into the office.

## Missing California boy, 15, spent two years living with a TEACHER, 61
 - [https://www.dailymail.co.uk/news/article-11348453/Missing-California-boy-15-spent-two-years-living-TEACHER-61.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348453/Missing-California-boy-15-spent-two-years-living-TEACHER-61.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 12:28:53+00:00

Michael Ramirez, 15, ran away from his family home in Sacramento in 2020 after an argument with his aunt and uncle about their strict rules.

## Ofcom clears BT Sport for airing Celtic fans waving 'F*** the Crown' banner days after Queen's death
 - [https://www.dailymail.co.uk/news/article-11348519/Ofcom-clears-BT-Sport-airing-Celtic-fans-waving-F-Crown-banner-days-Queens-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348519/Ofcom-clears-BT-Sport-airing-Celtic-fans-waving-F-Crown-banner-days-Queens-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 12:28:36+00:00

The incident happened at the start of the Parkhead club's Champions League tie against Shakhtar Donetsk in the Polish capital Warsaw last month, leaving TV viewers furious.

## Biden slams GOP for trying to ban sex changes for children in interview with trans TikTok activist
 - [https://www.dailymail.co.uk/news/article-11348505/Biden-slams-GOP-trying-ban-sex-changes-children-interview-trans-TikTok-activist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348505/Biden-slams-GOP-trying-ban-sex-changes-children-interview-trans-TikTok-activist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 12:28:04+00:00

Joe Biden said in a interview with a trans TikTok star that doesn't think states should have the power to regulate any health care related to a person transitioning from one sex to the other.

## Murder victim Zara Aleena, 35, was found 'bleeding, struggling to breathe' after stranger attacked
 - [https://www.dailymail.co.uk/news/article-11347941/Murder-victim-Zara-Aleena-35-bleeding-struggling-breathe-stranger-attacked.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347941/Murder-victim-Zara-Aleena-35-bleeding-struggling-breathe-stranger-attacked.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 12:23:32+00:00

An alleged killer accused of beating aspiring lawyer Zara Aleena to death as she walked home from a night out appeared at the Old Bailey today.

## Home where Logan Mwangi murdered by his mother, stepfather and stepbrother offered to new tenants
 - [https://www.dailymail.co.uk/news/article-11348413/Home-Logan-Mwangi-murdered-mother-stepfather-stepbrother-offered-new-tenants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348413/Home-Logan-Mwangi-murdered-mother-stepfather-stepbrother-offered-new-tenants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 12:18:53+00:00

The home where Logan Mwangi, five, was murdered has been advertised to new tenants. The Bridgend, Wales, flat recently appeared on a property portal.

## More than 500 migrants crossed the Channel in 10 dinghies yesterday despite thunderstorms
 - [https://www.dailymail.co.uk/news/article-11348571/More-500-migrants-crossed-Channel-10-dinghies-yesterday-despite-thunderstorms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348571/More-500-migrants-crossed-Channel-10-dinghies-yesterday-despite-thunderstorms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 12:17:27+00:00

While almost a month's worth of rain battered parts of southern England, 528 people people were detained after making the treacherous voyage to Dover.

## Lucy Letby trial: Nurse thought 'Oh no, not again' when premature baby girl collapsed, court hears
 - [https://www.dailymail.co.uk/news/article-11348521/Lucy-Letby-trial-Nurse-thought-Oh-no-not-premature-baby-girl-collapsed-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348521/Lucy-Letby-trial-Nurse-thought-Oh-no-not-premature-baby-girl-collapsed-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 12:10:24+00:00

A nurse caring for a baby girl at the Countess of Chester Hospital thought 'Oh no, not again' when the infant collapse 28 hours after her twin brother's death, Lucy Letby's murder trial heard today

## Russia claims Ukraine is in the 'final stage' of creating a 'dirty bomb'
 - [https://www.dailymail.co.uk/news/article-11348411/Russia-claims-Ukraine-final-stage-creating-dirty-bomb.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348411/Russia-claims-Ukraine-final-stage-creating-dirty-bomb.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 11:52:38+00:00

Concerns have been growing in recent weeks that Putin could resort to using an atomic bomb as Kyiv's counter-offensive continues to push Moscow's forces back.

## Melbourne TikTok: Eshay dine and dash gang run off after $500 meal at Old School Pizza in Coburg
 - [https://www.dailymail.co.uk/news/article-11348287/Melbourne-TikTok-Eshay-dine-dash-gang-run-500-meal-Old-School-Pizza-Coburg.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348287/Melbourne-TikTok-Eshay-dine-dash-gang-run-500-meal-Old-School-Pizza-Coburg.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 11:51:39+00:00

A group of Melbourne eshays were caught on CCTV cameras dining and dashing - with the restaurant posting the video to TikTok in an attempt to track them down.

## PICTURED: Couple, 39 and 38, who were tragically killed when their Porsche crashed into a tree
 - [https://www.dailymail.co.uk/news/article-11348417/PICTURED-Couple-39-38-tragically-killed-Porsche-crashed-tree.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348417/PICTURED-Couple-39-38-tragically-killed-Porsche-crashed-tree.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 11:50:48+00:00

A couple from Potton killed in a Porsche car crash have been named as the married parents of a three-year-old little boy.

## Winemaker loses unfair dismissal claim after he was fired for costing Sussex wine estate £500,000
 - [https://www.dailymail.co.uk/news/article-11348449/Winemaker-loses-unfair-dismissal-claim-fired-costing-Sussex-wine-estate-500-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348449/Winemaker-loses-unfair-dismissal-claim-fired-costing-Sussex-wine-estate-500-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 11:50:24+00:00

An employment tribunal heard Rathfinny Wine Estate based in Sussex concluded that senior winemaker Jonathan Medard was responsible for the problem and he was dismissed.

## Birmingham man who built two-storey house on driveway instead of a garage is told to tear it down
 - [https://www.dailymail.co.uk/news/article-11348219/Birmingham-man-built-two-storey-house-driveway-instead-garage-told-tear-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348219/Birmingham-man-built-two-storey-house-driveway-instead-garage-told-tear-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 11:44:02+00:00

The homeowner - a Mr M Singh - had originally been given approval to build a single-storey garage at their semi-detached property in Vaughton Street, Birmingham.

## Renters mock £1100-a-month London flat that 'looks like the film set of Saw'
 - [https://www.dailymail.co.uk/news/article-11348119/Renters-mock-1100-month-London-flat-looks-like-film-set-Saw.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348119/Renters-mock-1100-month-London-flat-looks-like-film-set-Saw.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 11:42:28+00:00

The 'prison-like' property is located in the Manor House Warehouse district of Haringey, north London and sparked dozens of mocking comments that compared it to a grisly horror film set.

## Metal detectorist who found wedding ring reveals owner didn't want it
 - [https://www.dailymail.co.uk/femail/article-11348335/Metal-detectorist-wedding-ring-reveals-owner-didnt-want-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11348335/Metal-detectorist-wedding-ring-reveals-owner-didnt-want-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 11:38:36+00:00

Steve Andrews, from Jersey, thought he was doing the right thing when he began looking for the owner of a wedding band he came across. But it turns out she wanted nothing to do with it.

## Port of Liverpool strikes: Dockworkers begin two-week walk-out in row over jobs and pay
 - [https://www.dailymail.co.uk/news/article-11348395/Port-Liverpool-strikes-Dockworkers-begin-two-week-walk-jobs-pay.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348395/Port-Liverpool-strikes-Dockworkers-begin-two-week-walk-jobs-pay.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 11:35:57+00:00

Nearly 600 Liverpool dockworkers have resumed a two-week strike today after talks with the dock operator, Peel Ports, collapsed in an ongoing dispute over jobs and pay

## Keir Starmer REFUSES to say whether comedian Eddie Izzard would qualify for an all-women shortlist
 - [https://www.dailymail.co.uk/news/article-11348315/Keir-Starmer-REFUSES-say-comedian-Eddie-Izzard-qualify-women-shortlist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348315/Keir-Starmer-REFUSES-say-comedian-Eddie-Izzard-qualify-women-shortlist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 11:35:06+00:00

A row is brewing within the Labour Party after Izzard this month launched a campaign to be chosen as the party's candidate for Sheffield Central ahead of the next general election.

## Su-34 bomber that smashed into Russian building killing 15 was caused by two SEAGULLS
 - [https://www.dailymail.co.uk/news/article-11348273/Su-34-bomber-smashed-Russian-building-killing-15-caused-two-SEAGULLS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348273/Su-34-bomber-smashed-Russian-building-killing-15-caused-two-SEAGULLS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 11:35:02+00:00

Investigators probing the crash say it was caused by two seagulls entering the engines during takeoff and their remains have been found in the wreckage.

## Sex attacker, 29, who tried to rape woman in her 60s at knifepoint is jailed for 15 years
 - [https://www.dailymail.co.uk/news/article-11348455/Sex-attacker-29-tried-rape-woman-60s-knifepoint-jailed-15-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348455/Sex-attacker-29-tried-rape-woman-60s-knifepoint-jailed-15-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 11:28:39+00:00

James Nicolaou, 29, lurked in the bushes before attacking the woman, who was in her late sixties, in Neasden Recreation Ground in north-west London.

## Woman praised after refusing to give her train seat to older passenger
 - [https://www.dailymail.co.uk/femail/article-11348137/Woman-praised-refusing-train-seat-older-passenger.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11348137/Woman-praised-refusing-train-seat-older-passenger.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 11:25:30+00:00

A UK-based woman, 32, has been praised after sharing her story on Reddit, revealing that she refused to move for an older passenger, because she'd specifically booked the seat to get work done.

## German doctor who killed his married lover is ordered to pay compensation to cover medical costs
 - [https://www.dailymail.co.uk/news/article-11348345/German-doctor-killed-married-lover-ordered-pay-compensation-cover-medical-costs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348345/German-doctor-killed-married-lover-ordered-pay-compensation-cover-medical-costs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 11:24:09+00:00

Surgeon Dr Andreas David Niederbichler, 45, was jailed for nine years for aggravated rape and bodily harm leading the death of his married lover, Yconne M., 38.

## Motorists told to get to Ampol Shell BP 
and Caltex to fill up with petrol NOW as fuel prices rise
 - [https://www.dailymail.co.uk/news/article-11348235/Motorists-told-Ampol-Shell-BP-Caltex-petrol-fuel-prices-rise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348235/Motorists-told-Ampol-Shell-BP-Caltex-petrol-fuel-prices-rise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 11:18:33+00:00

Motorists have a small window to fill up cheaply as many cities hit their first new petrol cycle after fuel excise was reinstated.

## Royal historian joins growing calls for producers to add disclaimer before each episode of The Crown
 - [https://www.dailymail.co.uk/news/article-11348251/Royal-historian-joins-growing-calls-producers-add-disclaimer-episode-Crown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348251/Royal-historian-joins-growing-calls-producers-add-disclaimer-episode-Crown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 11:14:35+00:00

Speaking to MailOnline, historian Andrew Lownie joined growing calls for a disclaimer to also be added at the start of each episode, after Netflix did add one to the trailer for the upcoming series.

## Cambridge University cancels Homerton College's annual Harry Potter-themed dinner in 'woke' protest
 - [https://www.dailymail.co.uk/news/article-11348357/Cambridge-University-cancels-Homerton-Colleges-annual-Harry-Potter-themed-dinner-woke-protest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348357/Cambridge-University-cancels-Homerton-Colleges-annual-Harry-Potter-themed-dinner-woke-protest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 11:05:06+00:00

EXCLUSIVE: Homerton College has long held the Hogwarts 'formal' dinners in its iconic wood-panelled Great Hall but this year the event has been replaced by a film night.

## Heir to the Lush cosmetics fortune applies to turn his 'secret' garden into eco-friendly plot
 - [https://www.dailymail.co.uk/news/article-11347979/Heir-Lush-cosmetics-fortune-applies-turn-secret-garden-eco-friendly-plot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347979/Heir-Lush-cosmetics-fortune-applies-turn-secret-garden-eco-friendly-plot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 11:02:45+00:00

Lush boss Simon Constantine wants to use Carey House to teach about biodiversity and sustainable horticulture. Plans lodged include a timber storage space and a compostable toilet.

## Vet reveals four cat breeds he would NEVER buy
 - [https://www.dailymail.co.uk/femail/article-11347959/Vet-reveals-four-cat-breeds-NEVER-buy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11347959/Vet-reveals-four-cat-breeds-NEVER-buy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 10:58:42+00:00

A UK vet has created a viral TikTok video revealing which four cat breeds he would never buy - and why, including Bengals, Sphinxes, Persians and Scottish Folds.

## Woman, 29, caught her obsessed stalker by taking photos of him as he followed her for four months
 - [https://www.dailymail.co.uk/news/article-11348181/Woman-29-caught-obsessed-stalker-taking-photos-followed-four-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348181/Woman-29-caught-obsessed-stalker-taking-photos-followed-four-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 10:52:40+00:00

Izabela Smialek, from Wigan, Greater Manchester, confronted Yousif Mohammed after he drove her to the brink of suicide with his four-month stalking campaign.

## Who is billionaire heiress and 'Mrs Sunak', Akshata Murthy?
 - [https://www.dailymail.co.uk/femail/article-11347709/Who-billionaire-heiress-Mrs-Sunak-Akshata-Murthy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11347709/Who-billionaire-heiress-Mrs-Sunak-Akshata-Murthy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 10:47:10+00:00

Akshata Murthy, 42, is set to become a new occupant of 10 Downing Street as her husband and former Chancellor, Rishi Sunak, is the favourite to win the Tory Party leadership election.

## Mother-of-two, 59, died from a blood clot days after undergoing a 'tummy-tuck', inquest hears
 - [https://www.dailymail.co.uk/news/article-11348161/Mother-two-59-died-blood-clot-days-undergoing-tummy-tuck-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348161/Mother-two-59-died-blood-clot-days-undergoing-tummy-tuck-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 10:40:00+00:00

Susan Kellock, 59, from Stonehouse, Gloucestershire, died from a blood clot five days after undergoing a 'tummy-tuck' at a private hospital, an inquest heard

## Eurozone economy plummets even further, dragged down by Germany as it heads into recession
 - [https://www.dailymail.co.uk/news/article-11348135/Eurozone-economy-plummets-dragged-Germany-heads-recession.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348135/Eurozone-economy-plummets-dragged-Germany-heads-recession.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 10:35:58+00:00

The S&amp;P Global Flash Eurozone composite Purchasing Managers' Index (PMI), seen as a good guide to overall economic health, fell to 47.1 this month, down from 48.1 in September.

## Just Stop Oil activists throw chocolate cake at King Charles' waxwork in Madame Tussauds
 - [https://www.dailymail.co.uk/news/article-11348187/Just-Stop-Oil-activists-throw-chocolate-cake-King-Charles-waxwork-Madame-Tussauds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348187/Just-Stop-Oil-activists-throw-chocolate-cake-King-Charles-waxwork-Madame-Tussauds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 10:27:37+00:00

Footage shows two of the eco loons pelting the waxwork at the famous London landmark as onlookers shout 'stop'.

## Just Stop Oil and XR leaders at war over extreme tactics of eco mobs
 - [https://www.dailymail.co.uk/news/article-11347877/Just-Stop-Oil-XR-leaders-war-extreme-tactics-eco-mobs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347877/Just-Stop-Oil-XR-leaders-war-extreme-tactics-eco-mobs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 10:23:30+00:00

Climate activists are at odds over what actions protesters should take to get the public's attention with some leaders urging members to 'upset people' and others calling for a 'moderate flank.'

## How will the new PM be chosen, and when do they take over from Liz Truss?
 - [https://www.dailymail.co.uk/news/article-11348115/How-new-PM-chosen-Liz-Truss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348115/How-new-PM-chosen-Liz-Truss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 10:23:19+00:00

Rishi Sunak and Penny Mordaunt are the last hopefuls standing in the Tory leadership contest after the dramatic withdrawal of Boris Johnson.

## Police launch desperate search for missing 14-year-old girl who was last seen in West Yorkshire
 - [https://www.dailymail.co.uk/news/article-11348249/Police-launch-desperate-search-missing-14-year-old-girl-seen-West-Yorkshire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348249/Police-launch-desperate-search-missing-14-year-old-girl-seen-West-Yorkshire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 10:23:14+00:00

Police say they are 'concerned' for the safety of 14-year-old Kiera Baker, who was last seen in Halifax, West Yorkshire. The teenager was reported missing yesterday.

## Keir Starmer poses with Sunday football team and insists he loves the 'banter' during games
 - [https://www.dailymail.co.uk/news/article-11347985/Keir-Starmer-poses-Sunday-football-team-insists-loves-banter-games.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347985/Keir-Starmer-poses-Sunday-football-team-insists-loves-banter-games.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 10:22:07+00:00

The Labour leader, 60, admitted he revels in the 'banter' during matches and how 'nobody gives a stuff' that he's a top politician.

## Search for missing teen Tea Wright-Finger and her Toyota Prado 4WD continues in Richmond, Qld
 - [https://www.dailymail.co.uk/news/article-11347947/Search-missing-teen-Tea-Wright-Finger-Toyota-Prado-4WD-continues-Richmond-Qld.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347947/Search-missing-teen-Tea-Wright-Finger-Toyota-Prado-4WD-continues-Richmond-Qld.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 10:16:32+00:00

Tea Wright-Finger was last seen by a friend who dropped her off near her blue Toyota Prado 4WD in Richmond in far-west Queensland on Sunday, October 16.

## Woman, 61, broke a proud Welshman's teeth after row about English buying second homes
 - [https://www.dailymail.co.uk/news/article-11347999/Woman-61-broke-proud-Welshmans-teeth-row-English-buying-second-homes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347999/Woman-61-broke-proud-Welshmans-teeth-row-English-buying-second-homes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 10:16:17+00:00

Julia Taylor, 61, left Alun Williams with two broken teeth after the glass accidentally connected with his mouth as she emptied the contents over his head at a pub.

## Could Boris Johnson now become Nato boss? Rishi Sunak hints at foreign role for ex-PM
 - [https://www.dailymail.co.uk/news/article-11348191/Could-Boris-Johnson-Nato-boss-Rishi-Sunak-hints-foreign-role-ex-PM.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348191/Could-Boris-Johnson-Nato-boss-Rishi-Sunak-hints-foreign-role-ex-PM.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 10:14:38+00:00

The former premier rejected attempting an unlikely No10 return last night that leaves his former chancellor Rishi Sunak in prime position to take power today.

## Virgin Australia gives passengers in middle seat on Melbourne-Adelaide flight Virgin Voyagers cruise
 - [https://www.dailymail.co.uk/news/article-11347831/Virgin-Australia-gives-passengers-middle-seat-Melbourne-Adelaide-flight-Virgin-Voyagers-cruise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347831/Virgin-Australia-gives-passengers-middle-seat-Melbourne-Adelaide-flight-Virgin-Voyagers-cruise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 10:14:03+00:00

Virgin Australia have  shocked passengers on a flight by giving free cruise tickets to flyers sitting in every middle seat after it was branded the worst seat on a plane.

## Students wear 'anti-cheating' during exams in Philippines
 - [https://www.dailymail.co.uk/news/article-11348037/Students-wear-anti-cheating-exams-Philippines.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348037/Students-wear-anti-cheating-exams-Philippines.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 10:11:57+00:00

Teachers at a school in Legazpi City told their students to wear the headgear to ensure 'integrity and honesty' in their exams, but gave them permission to 'go wild' with their designs.

## Moment new San Francisco DA is heckled out of debate by BLM protesters
 - [https://www.dailymail.co.uk/news/article-11348001/Moment-new-San-Francisco-DA-heckled-debate-BLM-protesters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348001/Moment-new-San-Francisco-DA-heckled-debate-BLM-protesters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 10:08:44+00:00

The students were demonstrating against Jenkins' postponement of a trial against Christopher Samayoa, a San Francisco police officer who shot and killed alleged carjacker Keita O'Neil in 2017.

## British mother and son homeless after officials sell £280,000 Spain home for £24,000 over ex's debt
 - [https://www.dailymail.co.uk/news/article-11348021/British-mother-son-homeless-officials-sell-280-000-Spain-home-24-000-exs-debt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11348021/British-mother-son-homeless-officials-sell-280-000-Spain-home-24-000-exs-debt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 10:06:23+00:00

Victoria Jenkins has lived in the same £280,000 home in the Costa del Sol for 22 years and her 13-year-old son Sam was born in the tourist hotspot.

## Shopper arrested for not scanning every item at Walmart self-checkout and stealing $1,000 of items
 - [https://www.dailymail.co.uk/news/article-11347945/Shopper-arrested-not-scanning-item-Walmart-self-checkout-stealing-1-000-items.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347945/Shopper-arrested-not-scanning-item-Walmart-self-checkout-stealing-1-000-items.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 10:04:08+00:00

A Michigan woman is being charged after allegedly stealing from Walmart by not scanning items at the self-checkout and swapping out barcodes for cheaper items.

## Adelaide: Murder riddle as decomposing body is found hidden in grass in Salisbury South city street
 - [https://www.dailymail.co.uk/news/article-11347827/Adelaide-Murder-riddle-decomposing-body-hidden-grass-Salisbury-South-city-street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347827/Adelaide-Murder-riddle-decomposing-body-hidden-grass-Salisbury-South-city-street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 10:01:24+00:00

Human remains have been found by a worker mowing the lawn at a property in Adelaide - with police suggesting the body may have been there for up to six months.

## Russians are blamed for spate of SPEED CAMERA thefts in Sweden, which can be stripped for drones
 - [https://www.dailymail.co.uk/news/article-11347965/Russians-blamed-spate-SPEED-CAMERA-thefts-Sweden-stripped-drones.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347965/Russians-blamed-spate-SPEED-CAMERA-thefts-Sweden-stripped-drones.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 09:44:37+00:00

One bizarre theory that has emerged is that Russia is behind the vanishing act and is using the Swedish speed cameras to build home-made drones that are being deployed to Ukraine.

## Ted Cruz is booed roundly by Yankees fans as he shows up in the Bronx to support the Astros
 - [https://www.dailymail.co.uk/news/article-11347721/Ted-Cruz-booed-roundly-Yankees-fans-shows-Bronx-support-Astros.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347721/Ted-Cruz-booed-roundly-Yankees-fans-shows-Bronx-support-Astros.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 09:40:53+00:00

Wearing a bright orange shirt to match the Astros' colors, Cruz watched on as Houston advanced to the World Series again. But he recieved a frosty reception from the fans inside Yankee Stadium.

## Killer, 68, will be quizzed over unsolved 1986 murder of Suzy Lamplugh as he seeks parole
 - [https://www.dailymail.co.uk/news/article-11347895/Killer-68-quizzed-unsolved-1986-murder-Suzy-Lamplugh-seeks-parole.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347895/Killer-68-quizzed-unsolved-1986-murder-Suzy-Lamplugh-seeks-parole.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 09:25:46+00:00

Suzy Lamplugh's suspected killer will be quizzed on new evidence allegedly linking him to her murder as part of his bid for parole.

## Drivers in London boroughs where cycle-friendly LTNs were introduced saw MORE traffic in 2021
 - [https://www.dailymail.co.uk/news/article-11347859/Drivers-London-boroughs-cycle-friendly-LTNs-introduced-saw-traffic-2021.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347859/Drivers-London-boroughs-cycle-friendly-LTNs-introduced-saw-traffic-2021.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 09:21:13+00:00

The 10 boroughs that adopted the controversial car-free zones saw total vehicle miles rise by an average of 41million in 2021 as road traffic in the capital rebounded to near-normal levels.

## BBC presenter sparks fury over her 'gleeful' reaction to Boris Johnson quitting Tory leadership race
 - [https://www.dailymail.co.uk/news/article-11347821/BBC-presenter-sparks-fury-gleeful-reaction-Boris-Johnson-quitting-Tory-leadership-race.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347821/BBC-presenter-sparks-fury-gleeful-reaction-Boris-Johnson-quitting-Tory-leadership-race.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 09:18:43+00:00

Outraged viewers are demanding action from regulator Ofcom over the comments by Martine Croxall on BBC's The Papers show last night.

## EasyJet plane flying from Gatwick to Greece came just 10 FEET from drone
 - [https://www.dailymail.co.uk/news/article-11347847/EasyJet-plane-flying-Gatwick-Greece-came-just-10-FEET-drone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347847/EasyJet-plane-flying-Gatwick-Greece-came-just-10-FEET-drone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 09:14:16+00:00

The Airbus A320's two pilots spotted the black flying object when they were reaching 16,000ft over the Kent coast, at which point the aircraft would have been travelling at more than 300mph.

## Britain's first non-white and Hindu prime minister set to take power on Diwali
 - [https://www.dailymail.co.uk/news/article-11347889/Britains-non-white-Hindu-prime-minister-set-power-Diwali.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347889/Britains-non-white-Hindu-prime-minister-set-power-Diwali.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 09:10:14+00:00

After Liz Truss's chaotic premiership ended in ignominy after just 44 days the Richmond MP is poised to be appointed as the UK's first non-white and Hindu leader on Diwali.

## Irish woman, 75, falls 60ft to her death from Majorca cliff path while hiking
 - [https://www.dailymail.co.uk/news/article-11347887/Irish-woman-75-falls-60ft-death-Majorca-cliff-path-hiking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347887/Irish-woman-75-falls-60ft-death-Majorca-cliff-path-hiking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 09:05:36+00:00

Officials said the Irish woman lost her balance and plunged 60ft from Pas d'en Segarra, a small overhang on a cliff that a path popular with Sunday walkers runs through.

## China's Xi Jinping surrounds himself with loyalists in 'show of force' as experts fear new Cold War
 - [https://www.dailymail.co.uk/news/article-11347719/Chinas-Xi-Jinping-surrounds-loyalists-force-experts-fear-new-Cold-War.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347719/Chinas-Xi-Jinping-surrounds-loyalists-force-experts-fear-new-Cold-War.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 09:01:46+00:00

The 69-year-old will lead the world's most populous nation for another five years after he was confirmed as General Secretary once more at yesterday's party congress.

## Dragon's Den star Drew Cockton wrote post about helping staff 'open up' hours before he died
 - [https://www.dailymail.co.uk/news/article-11347775/Dragons-Den-star-Drew-Cockton-wrote-post-helping-staff-open-hours-died.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347775/Dragons-Den-star-Drew-Cockton-wrote-post-helping-staff-open-hours-died.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 09:00:21+00:00

Drew Cockton, who died 'peacefully' at home aged 36, had shared an inspirational Instagram post before his death. He advised businesses to encourage staff to be their 'true and authentic selves'.

## Kew Gardens in Christmas lights row as it uses biofuel for annual display to slash emissions
 - [https://www.dailymail.co.uk/news/article-11347929/Kew-Gardens-Christmas-lights-row-uses-biofuel-annual-display-slash-emissions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347929/Kew-Gardens-Christmas-lights-row-uses-biofuel-annual-display-slash-emissions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 08:47:38+00:00

Kew Gardens has defended its sustainable credentials after eco-critics  slammed its annual Christmas lights display as a 'waste of money and energy'

## Royal Navy engineer, 31, who raped his sleeping male colleague is jailed for seven years
 - [https://www.dailymail.co.uk/news/article-11347881/Royal-Navy-engineer-31-raped-sleeping-male-colleague-jailed-seven-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347881/Royal-Navy-engineer-31-raped-sleeping-male-colleague-jailed-seven-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 08:37:26+00:00

Able Seaman Troy Glasgow, 31, has been jailed, dismissed from the Navy 'with disgrace' and placed on the sex offenders register after a trial at Bulford Military Court, Wiltshire.

## Captured female Ukrainian soldier reveals brutal torture inflicted on women by Russian forces
 - [https://www.dailymail.co.uk/news/article-11347857/Captured-female-Ukrainian-soldier-reveals-brutal-torture-inflicted-women-Russian-forces.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347857/Captured-female-Ukrainian-soldier-reveals-brutal-torture-inflicted-women-Russian-forces.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 08:37:04+00:00

Approximately 96 of the swapped prisoners are servicewomen, including 37 evacuees from Azovstal, whereas 12 are civilians.

## Gina Rinehart Netball Australia row sees South Australian radio host Andrew Costello slam athletes
 - [https://www.dailymail.co.uk/news/article-11347599/Gina-Rinehart-Netball-Australia-row-sees-South-Australian-radio-host-Andrew-Costello-slam-athletes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347599/Gina-Rinehart-Netball-Australia-row-sees-South-Australian-radio-host-Andrew-Costello-slam-athletes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 08:31:48+00:00

A radio host has slammed Netball Australia for 'spitting in the face' of mining magnate Gina Rinehart after she proposed a $15million sponsorship through her company

## Perth boy, 15, dies days after allegedly being bashed to death with a metal pipe by a group of men
 - [https://www.dailymail.co.uk/news/article-11347609/Perth-boy-15-dies-days-allegedly-bashed-death-metal-pipe-group-men.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347609/Perth-boy-15-dies-days-allegedly-bashed-death-metal-pipe-group-men.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 08:18:22+00:00

A teenager tragically died in hospital after being the alleged victim of a violent racial assault - with his alleged attackers, who used a machete and metal pipe, still on the run in Perth.

## DOMINIC LAWSON: Rishi Sunak is the real Right-winger
 - [https://www.dailymail.co.uk/debate/article-11347049/DOMINIC-LAWSON-Rishi-Sunak-real-Right-winger.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-11347049/DOMINIC-LAWSON-Rishi-Sunak-real-Right-winger.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 08:18:08+00:00

DOMINIC LAWSON: Rishi Sunak warned presciently that a policy of massive unfunded tax cuts would cause interest rates to spike upwards, to the great cost of mortgage holders.

## Man, 47, and woman, 30, are charged with murder of 63-year-old man who vanished a year ago
 - [https://www.dailymail.co.uk/news/article-11347801/Man-47-woman-30-charged-murder-63-year-old-man-vanished-year-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347801/Man-47-woman-30-charged-murder-63-year-old-man-vanished-year-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 08:09:44+00:00

A woman and a man have been charged with the murder of a 63-year-old who vanished from Islington without a trace.

## Sandy Hook: Alex Jones calls for a new trial following 'irrational' $1billion compensation award
 - [https://www.dailymail.co.uk/news/article-11347755/Sandy-Hook-Alex-Jones-calls-new-trial-following-irrational-1billion-compensation-award.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347755/Sandy-Hook-Alex-Jones-calls-new-trial-following-irrational-1billion-compensation-award.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 08:09:22+00:00

Infamous conspiracy theorist Alex Jones was ordered to pay at least $965 million to the families of the 20 students and six teachers killed in the 2012 Sandy Hook mass shooting.

## Children who think they're trans are probably just going through a 'phase', NHS says
 - [https://www.dailymail.co.uk/health/article-11347735/NHS-says-children-say-trans-just-going-phase.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11347735/NHS-says-children-say-trans-just-going-phase.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 08:04:17+00:00

NHS England issued draft guidance on treating children and young people with gender dysphoria - those who feel their gender is different from their sex.

## Russian pilot ejects from burning fighter jet as it crashes
 - [https://www.dailymail.co.uk/news/article-11347707/Russian-pilot-ejects-burning-fighter-jet-crashes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347707/Russian-pilot-ejects-burning-fighter-jet-crashes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 08:04:05+00:00

Helmet camera footage captures the moment a Russian Su-25 jet spun out of control mid-air and then fell to the ground in a flaming wreck as the pilot narrowly escaped with his life.

## The Rishi bounce? Pound soars to $1.14 after Boris Johnson drops out of Tory leadership race
 - [https://www.dailymail.co.uk/news/article-11347693/The-Rishi-bounce-Pound-soars-1-14-Boris-Johnson-drops-Tory-leadership-race.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347693/The-Rishi-bounce-Pound-soars-1-14-Boris-Johnson-drops-Tory-leadership-race.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 08:02:14+00:00

This morning, the value of Sterling climbed as high as $1.1401 against the dollar in early Asia trading, amid expectations could become Prime Minister today.

## Rishi Sunak on the verge of being named the next PM TODAY
 - [https://www.dailymail.co.uk/news/article-11347765/Rishi-Sunak-verge-named-PM-TODAY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347765/Rishi-Sunak-verge-named-PM-TODAY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 08:01:58+00:00

Rishi Sunak could be named as the new PM as early as 2.15pm, with his sole remaining rival Penny Mordaunt   struggling to reach the threshold of 100 nominations.

## Man arrested after alleged jewellery store armed robbery at Carnes Hills Marketplace, Sydney
 - [https://www.dailymail.co.uk/news/article-11347673/Man-arrested-alleged-jewellery-store-armed-robbery-Carnes-Hills-Marketplace-Sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347673/Man-arrested-alleged-jewellery-store-armed-robbery-Carnes-Hills-Marketplace-Sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 07:52:03+00:00

Police were called to a jewellery store at Carnes Hill Marketplace in Sydney's south-west after reports of an armed robbery.

## Kyle James Henk Daniels: Mosman swim coach may face third trial after jury discharged
 - [https://www.dailymail.co.uk/news/article-11347589/Kyle-James-Henk-Daniels-Mosman-swim-coach-face-trial-jury-discharged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347589/Kyle-James-Henk-Daniels-Mosman-swim-coach-face-trial-jury-discharged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 07:25:06+00:00

With his fate now in hands of the Department of Public Prosecutions, the former Mosman swim coach must still comply with strict bail conditions while he waits 
calls regarding a third trial.

## Horror on rollercoaster at theme park as man airlifted to hospital after ride 'slides from track'
 - [https://www.dailymail.co.uk/news/article-11347663/Horror-rollercoaster-theme-park-man-airlifted-hospital-ride-slides-track.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347663/Horror-rollercoaster-theme-park-man-airlifted-hospital-ride-slides-track.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 07:04:46+00:00

The man was rushed to hospital after a 'serious' medical emergency following the crash at the Oakwood Theme Park in Pembrokeshire, south Wales yesterday.

## Outrage as United Nations shows up at Australia's prisons for random inspections
 - [https://www.dailymail.co.uk/news/article-11347183/Outrage-United-Nations-shows-Australias-prisons-random-inspections.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347183/Outrage-United-Nations-shows-Australias-prisons-random-inspections.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 06:29:04+00:00

United Nation's inspectors have returned home to New York after unsuccessful attempts to inspect  NSW prisons. They say the states refusal to cooperate is a 'clear breach' of its obligations.

## San Francisco's $1.7m plan to make a single public toilet could be flushed down the drain
 - [https://www.dailymail.co.uk/news/article-11347495/San-Franciscos-1-7m-plan-make-single-public-toilet-flushed-drain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347495/San-Franciscos-1-7m-plan-make-single-public-toilet-flushed-drain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 06:25:42+00:00

The plan to build a single public toilet in the Noe Valley Town Square of San Francisco could be flushed down the drain as California Gov. Gavin Newsom threatens to block funding.

## Gov. Newsom calls for Los Angeles City Council members to resign
 - [https://www.dailymail.co.uk/news/article-11347559/Gov-Newsom-calls-Los-Angeles-City-Council-members-resign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347559/Gov-Newsom-calls-Los-Angeles-City-Council-members-resign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 06:21:46+00:00

California Governor Gavin Newsom has finally called for all of those involved in the Los Angeles City Council racism audio leak scandal to resign.

## How Gold's Gym became a global icon and celebrity hotspot
 - [https://www.dailymail.co.uk/news/article-11347343/How-Golds-Gym-global-icon-celebrity-hotspot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347343/How-Golds-Gym-global-icon-celebrity-hotspot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 06:11:15+00:00

What started out in 1965 as a small gym in Venice Beach, California, has since become the most iconic fitness company in the world - Gold's Gym.

## Man discovers used KFC glove in his large chips from Kwinina KFC in Western Australia
 - [https://www.dailymail.co.uk/news/article-11347407/Man-discovers-used-KFC-glove-large-chips-Kwinina-KFC-Western-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347407/Man-discovers-used-KFC-glove-large-chips-Kwinina-KFC-Western-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 06:05:10+00:00

A man has had a nasty surprise while grabbing a late-night bite to eat at his local KFC that has disgusted Australians.

## Fitbit sued by the ACCC for 'misleading customers' with refund policy
 - [https://www.dailymail.co.uk/news/article-11347535/Fitbit-sued-ACCC-misleading-customers-refund-policy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347535/Fitbit-sued-ACCC-misleading-customers-refund-policy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 06:04:51+00:00

Australia's competition watchdog is taking Google-owned fitness tracker giant Fitbit to court for allegedly refusing to provide refunds or replacing faulty devices.

## Woolworths, Qantas, Australia Post: Most trusted brands revealed despite some facing big scandals
 - [https://www.dailymail.co.uk/news/article-11347333/Woolworths-Qantas-Australia-Post-trusted-brands-revealed-despite-facing-big-scandals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347333/Woolworths-Qantas-Australia-Post-trusted-brands-revealed-despite-facing-big-scandals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 06:01:23+00:00

Woolworths was the overall winner of Australia's most trusted brand award, with the likes of Qantas, Toyota, Australia Post and ABC following close behind.

## Brain surgeon Charlie Teo charged jaw-dropping amounts to operate on children who died
 - [https://www.dailymail.co.uk/news/article-11346821/Brain-surgeon-Charlie-Teo-charged-jaw-dropping-amounts-operate-children-died.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346821/Brain-surgeon-Charlie-Teo-charged-jaw-dropping-amounts-operate-children-died.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 05:55:53+00:00

Controversial brain surgeon Charlie Teo charged large fees to the families of two children, who both died within a year - but he says tragedy among miracles are part of 'advancements'.

## Race for PM LIVE: Rishi Sunak set to become next Tory leader after Boris Johnson drops out
 - [https://www.dailymail.co.uk/news/live/article-11347561/Race-PM-LIVE-Rishi-Sunak-set-Tory-leader-Boris-Johnson-drops-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/live/article-11347561/Race-PM-LIVE-Rishi-Sunak-set-Tory-leader-Boris-Johnson-drops-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 05:55:45+00:00

LIVE: Follow MailOnline's coverage of the Conservative leadership contest with Rishi Sunak likely to be announced as Prime Minister as early as this afternoon.

## Qantas leave 12-year-old 'distraught' after kicking him off flight
 - [https://www.dailymail.co.uk/news/article-11346885/Qantas-leave-12-year-old-distraught-kicking-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346885/Qantas-leave-12-year-old-distraught-kicking-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 05:47:54+00:00

A young boy desperate to see his dad for the first time in nine months was left 'distraught' after Qantas refused to let him board a flight to see his father.

## Bandidos bikies pose for awkward Christmas card as weapons seized in sweeping NSW police raids
 - [https://www.dailymail.co.uk/news/article-11347117/Bandidos-bikies-pose-awkward-Christmas-card-weapons-seized-sweeping-NSW-police-raids.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347117/Bandidos-bikies-pose-awkward-Christmas-card-weapons-seized-sweeping-NSW-police-raids.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 05:22:22+00:00

Police have seized firearms, prohibited weapons, drugs and an awkward family-style Christmas card during raids on Bandidos and Finks alleged bikie gang members.

## Jury in trial of Brittany Higgins' accused rapist to enter their FIFTH day of deliberations
 - [https://www.dailymail.co.uk/news/article-11347481/Jury-trial-Brittany-Higgins-accused-rapist-enter-FIFTH-day-deliberations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347481/Jury-trial-Brittany-Higgins-accused-rapist-enter-FIFTH-day-deliberations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 05:13:47+00:00

Bruce Lehrmann is accused of raping the former Liberal staffer in Parliament House after a night out in March 2019. He has pleaded not guilty to sexual intercourse without consent.

## Telethon 2022 mankini man 'horrifies' Anthony Albanese
 - [https://www.dailymail.co.uk/news/article-11347265/Telethon-2022-mankini-man-horrifies-Anthony-Albanese.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347265/Telethon-2022-mankini-man-horrifies-Anthony-Albanese.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 05:00:55+00:00

Perth grandad John Bradley has provided an 'unforgettable' moment in Anthony Albanese's political career by wearing a very revealing mankini as he greeted the 'horrified' Prime Minister.

## Starward founder David Vitale's five tips for success as Melbourne whisky goes global
 - [https://www.dailymail.co.uk/news/article-11330289/Starward-founder-David-Vitales-five-tips-success-Melbourne-whiskey-goes-global.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11330289/Starward-founder-David-Vitales-five-tips-success-Melbourne-whiskey-goes-global.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 04:32:05+00:00

Melbourne's David Vitale has a unique way to make his Starward whisky, which is starting to fulfil his vision of changing the drink's image from what your dad drinks to an anytime social refreshment.

## Gina Rinehart netball row fuelled by Lang Hancock's racist remarks as Jacinta Price weighs in
 - [https://www.dailymail.co.uk/news/article-11346807/Gina-Rinehart-netball-row-fuelled-Lang-Hancocks-racist-remarks-Jacinta-Price-weighs-in.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346807/Gina-Rinehart-netball-row-fuelled-Lang-Hancocks-racist-remarks-Jacinta-Price-weighs-in.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 04:01:35+00:00

The infamous interview given by Gina Rinehart's dad, where he suggested sterilising Indigenous people who would not accept white 'civilisation, lies at the heart of netball's sponsorship saga.

## Luxury superyacht explodes in ball of flames on Hamilton Island, Queensland
 - [https://www.dailymail.co.uk/news/article-11347341/Luxury-superyacht-explodes-ball-flames-Hamilton-Island-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347341/Luxury-superyacht-explodes-ball-flames-Hamilton-Island-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 04:01:33+00:00

A superyacht has exploded in a giant ball of flames sending enormous plumes of black smoke spewing into the air off the coast of Queensland.

## Single-use plastic ban NSW: Everyday items that could lead to you copping an $11k fine
 - [https://www.dailymail.co.uk/news/article-11346989/Single-use-plastic-ban-NSW-Everyday-items-lead-copping-11k-fine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346989/Single-use-plastic-ban-NSW-Everyday-items-lead-copping-11k-fine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 03:58:30+00:00

From November 1, all single-use plastic will be banned in NSW, and individuals could be hit with an $11,000 fine for supplying items such as plastic straws, knives and forks with takeaway meals.

## Lidia Thorpe refers herself to Senate committee over her love affair with Rebels bikie Dean Martin
 - [https://www.dailymail.co.uk/news/article-11347355/Lidia-Thorpe-refers-Senate-committee-love-affair-Rebels-bikie-Dean-Martin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347355/Lidia-Thorpe-refers-Senate-committee-love-affair-Rebels-bikie-Dean-Martin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 03:49:20+00:00

Ms Thorpe is set to write to the Senate president requesting the Upper House's privileges committee look at her relationship with Dean Martin, the onetime Victorian Rebels president.

## Gina Rinehart Netball Australia fallout inspires companies to consider pulling out of other club
 - [https://www.dailymail.co.uk/news/article-11347345/Gina-Rinehart-Netball-Australia-fallout-inspires-companies-consider-pulling-club.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347345/Gina-Rinehart-Netball-Australia-fallout-inspires-companies-consider-pulling-club.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 03:45:28+00:00

Gina Rinehart has drawn a wave of support after her company Hancock Prospecting ripped up its $15million sponsorship deal with Netball Australia on Saturday.

## Cops and Amazon driver rescue three people from submerged car
 - [https://www.dailymail.co.uk/news/article-11347223/Cops-Amazon-driver-rescue-three-people-submerged-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347223/Cops-Amazon-driver-rescue-three-people-submerged-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 03:32:46+00:00

A sheriff's deputy was responding to a call when he came across an overturned car in a canal  and a delivery driver in the water rescuing people trapped inside.

## Netball Australia boss 'concerned' about finances after Gina Rinehart pulls sponsorship deal
 - [https://www.dailymail.co.uk/news/article-11345045/Netball-Australia-boss-concerned-finances-Gina-Rinehart-pulls-sponsorship-deal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11345045/Netball-Australia-boss-concerned-finances-Gina-Rinehart-pulls-sponsorship-deal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 03:19:19+00:00

Kelly Ryan said it was 'very disappointing' after Ms Rinehart's mining company Hancock Prospecting announced it would withdraw its support on Saturday.

## George MacKay 'could replace Ezra Miller as the sequel's superhero'
 - [https://www.dailymail.co.uk/news/article-11347143/George-MacKay-replace-Ezra-Miller-sequels-superhero.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347143/George-MacKay-replace-Ezra-Miller-sequels-superhero.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 02:42:36+00:00

Trouble actor Ezra Miller is set to star in upcoming superhero flick The Flash, but after being at the center of controversy the past six months, rumors are swirling of a possible replacement.

## How Australians are doing their tax returns WRONG - and a simple tip for making claims easy
 - [https://www.dailymail.co.uk/news/article-11347065/How-Australians-doing-tax-returns-WRONG-simple-tip-making-claims-easy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347065/How-Australians-doing-tax-returns-WRONG-simple-tip-making-claims-easy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 02:25:13+00:00

H&amp;R Block director of tax communications Mark Chapman said you didn't need to keep a copy of a receipt if the work-related expense was less than $300.

## ISIS bride Zehra Duman could return to Australia as government scrambles to close legal loophole
 - [https://www.dailymail.co.uk/news/article-11346715/ISIS-bride-Zehra-Duman-return-Australia-government-scrambles-close-legal-loophole.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346715/ISIS-bride-Zehra-Duman-return-Australia-government-scrambles-close-legal-loophole.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 02:06:13+00:00

The Albanese government is scrambling to block a major legislative loophole which could allow more than a dozen Islamic State 
terrorists back into Australia, including a notorious ISIS jihadi bride.

## New York City records its FIRST two monkeypox deaths
 - [https://www.dailymail.co.uk/news/article-11346849/New-York-City-records-two-monkeypox-deaths.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346849/New-York-City-records-two-monkeypox-deaths.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 02:02:49+00:00

The first two people in New York City have died from monkeypox-related illnesses, the New York City Department of Health have confirmed.

## 'It would simply not be the right thing to do': Boris Johnson QUITS Tory leadership contest
 - [https://www.dailymail.co.uk/news/article-11346057/Rishi-Sunak-crowned-Prime-Minister-tomorrow-Boris-Johnson-QUITS-leadership-race.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346057/Rishi-Sunak-crowned-Prime-Minister-tomorrow-Boris-Johnson-QUITS-leadership-race.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 01:53:07+00:00

The former Chancellor, who officially launched his campaign this morning, had more than double the number of publicly-declared supporters than Mr Johnson.

## Lisa Wilkinson slams Gina Rinehart over Netball Australia $15million sponsorship fallout
 - [https://www.dailymail.co.uk/news/article-11346903/Lisa-Wilkinson-slams-Gina-Rinehart-Netball-Australia-15million-sponsorship-fallout.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346903/Lisa-Wilkinson-slams-Gina-Rinehart-Netball-Australia-15million-sponsorship-fallout.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 01:48:47+00:00

Project co-host Lisa Wilkinson stepped in to defend the sports organisation as she unloaded on the mining magnate.

## Australia weather: Rain in Queensland, NSW, Victoria and WA as flood warnings continue
 - [https://www.dailymail.co.uk/news/article-11346535/Australia-weather-Rain-Queensland-NSW-Victoria-WA-flood-warnings-continue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346535/Australia-weather-Rain-Queensland-NSW-Victoria-WA-flood-warnings-continue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 01:44:33+00:00

Two rain cells battering New South Wales, Queensland and Victoria along with another system pouring over south Western Australia will continue to bring heavy rain to several regions.

## Kyle James Henk Daniels: Mosman swim coach found not guilty of tenth charge
 - [https://www.dailymail.co.uk/news/article-11347153/Kyle-James-Henk-Daniels-Mosman-swim-coach-not-guilty-tenth-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347153/Kyle-James-Henk-Daniels-Mosman-swim-coach-not-guilty-tenth-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 01:44:30+00:00

Kyle James Henk Daniels, 24, is facing a NSW District Court trial after being accused of touching nine female students during lessons at the Mosman Swim Centre in 2018 and 2019.

## President Biden discloses that he owns TWO shotguns - and adds that his late son Beau owned one
 - [https://www.dailymail.co.uk/news/article-11346963/President-Biden-discloses-owns-TWO-shotguns-adds-late-son-Beau-owned-one.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346963/President-Biden-discloses-owns-TWO-shotguns-adds-late-son-Beau-owned-one.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 01:40:12+00:00

President Joe Biden failed to acknowledge the allegations facing his son Hunter regarding his lying on a form about a firearm purchase when talking about responsible gun ownership.

## Portland mayor announces plan to BAN unsanctioned homeless encampments
 - [https://www.dailymail.co.uk/news/article-11346787/Portland-mayor-announces-plan-BAN-unsanctioned-homeless-encampments.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346787/Portland-mayor-announces-plan-BAN-unsanctioned-homeless-encampments.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 01:38:06+00:00

The mayor of Portland, Oregon, has announced plans to shut down any unsanctioned homeless camps in the city, calling the crisis a 'vortex of misery for all involved' during a press conference.

## Netflix in fresh The Crown row as close friend of Princess Diana hits out at series
 - [https://www.dailymail.co.uk/news/article-11347077/Netflix-fresh-Crown-row-close-friend-Princess-Diana-hits-series.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347077/Netflix-fresh-Crown-row-close-friend-Princess-Diana-hits-series.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 01:37:48+00:00

A close friend of Princess Diana has slammed Netflix as 'sadistic and wicked' over its depiction of her final hours in the latest series of The Crown.

## Ambulance workers vote on strike action over pay dispute as hundreds at UK's biggest port strike
 - [https://www.dailymail.co.uk/news/article-11347141/Ambulance-workers-vote-strike-action-pay-dispute-hundreds-UKs-biggest-port-strike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347141/Ambulance-workers-vote-strike-action-pay-dispute-hundreds-UKs-biggest-port-strike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 01:33:05+00:00

Today, 15,000 ambulance workers across 11 NHS trusts in England and Wales will vote on whether to strike over an ongoing pay dispute. GMB said the four per cent pay rise was a 'real terms pay cut'.

## Thomas Nicol: Today Show producer found not guilty of rape
 - [https://www.dailymail.co.uk/news/article-11347021/Thomas-Nicol-Today-producer-not-guilty-rape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347021/Thomas-Nicol-Today-producer-not-guilty-rape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 01:30:34+00:00

Thomas Joseph Nicol, 33, had pleaded not guilty to raping a woman he knew at his Bondi home, in Sydney's eastern suburbs, in January 2021.

## Jurors in the trial of Brittany Higgins' accused rapist Bruce Lehrmann share a note with judge
 - [https://www.dailymail.co.uk/news/article-11346785/Jurors-trial-Brittany-Higgins-accused-rapist-Bruce-Lehrmann-share-note-judge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346785/Jurors-trial-Brittany-Higgins-accused-rapist-Bruce-Lehrmann-share-note-judge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 01:29:01+00:00

Jurors arrived at the ACT Supreme Court on Monday morning to continue determining whether Bruce Lehrmann sexually assaulted the former Liberal staffer in Parliament House.

## Now 13 victims come forward after Texas hospital janitor is accused of peeing in water bottles
 - [https://www.dailymail.co.uk/news/article-11347001/13-victims-come-forward-Texas-hospital-janitor-accused-peeing-water-bottles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347001/13-victims-come-forward-Texas-hospital-janitor-accused-peeing-water-bottles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 01:27:41+00:00

Lucio Diaz, 50, is charged with indecent assault and aggravated assault with a deadly weapon and is being held on a $75,000 bond after being accused of peeing in employee water bottles in Texas.

## Rishi Sunak could be named UK's new PM TODAY after Boris Johnson pulled out of leadership contest
 - [https://www.dailymail.co.uk/news/article-11347121/Rishi-Sunak-named-UKs-new-PM-TODAY-Boris-Johnson-pulled-leadership-contest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347121/Rishi-Sunak-named-UKs-new-PM-TODAY-Boris-Johnson-pulled-leadership-contest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 01:26:51+00:00

Rishi Sunak has received the public backing of more than 150 Tory MPs - with more joining team Sunak following Mr Johnson's departure from the race.

## Fossil fuel tycoon's granddaughter is prominent backer of green zealots causing chaos on roads
 - [https://www.dailymail.co.uk/news/article-11346663/Fossil-fuel-tycoons-granddaughter-prominent-backer-green-zealots-causing-chaos-roads.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346663/Fossil-fuel-tycoons-granddaughter-prominent-backer-green-zealots-causing-chaos-roads.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 01:04:34+00:00

Aileen Getty, an heiress to the Getty family fortune, which, of course, grew from the very industry activists are keen to bring to its knees, is bankrolling Just Stop Oil.

## Urban house prices soar as buyers return to cities after fleeing for the countryside during pandemic
 - [https://www.dailymail.co.uk/news/article-11346805/Urban-house-prices-soar-buyers-return-cities-fleeing-countryside-pandemic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346805/Urban-house-prices-soar-buyers-return-cities-fleeing-countryside-pandemic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 01:00:30+00:00

Figures from mortgage lender Halifax show property prices in major cities have grown 9.2 per cent on average since the beginning of the year.

## SUE REID: The 72 hours that proved Britain CAN tackle illegal trafficking
 - [https://www.dailymail.co.uk/news/article-11346587/SUE-REID-72-hours-proved-Britain-tackle-illegal-trafficking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346587/SUE-REID-72-hours-proved-Britain-tackle-illegal-trafficking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:56:38+00:00

SUE REID: Elton, who speaks good English and says he studied it at university, first resolved to head for Britain after losing his job in Tirana.

## Texas man charged with killing two nurses opened fire while his girlfriend was giving birth
 - [https://www.dailymail.co.uk/news/article-11346769/Texas-man-charged-killing-two-nurses-opened-fire-girlfriend-giving-birth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346769/Texas-man-charged-killing-two-nurses-opened-fire-girlfriend-giving-birth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:55:23+00:00

Nestor Oswaldo Hernandez, 30, who opened fire at Methodist Dallas Medical Center in Texas on Saturday - killing two nurses - was on parole for aggravated at the time of the shooting.

## Sydney real estate: CoreLogic data shows NSW capital house prices drop by $100k
 - [https://www.dailymail.co.uk/news/article-11346803/CoreLogic-data-Sydneys-house-prices-drop-100k.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346803/CoreLogic-data-Sydneys-house-prices-drop-100k.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:51:47+00:00

House and unit prices together in Australia's most expensive city have fallen by $116,500 or 10.1 per cent since February, CoreLogic data showed.

## Liz Cheney says Trump will not be allowed to make January 6 deposition a 'circus'
 - [https://www.dailymail.co.uk/news/article-11346249/Cheney-rules-Trump-testifying-Jan-6-committee-live-TV-says-wont-make-circus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346249/Cheney-rules-Trump-testifying-Jan-6-committee-live-TV-says-wont-make-circus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:50:36+00:00

Speaking to NBC News' Meet The Press on Sunday, Cheney suggested it's possible that Trump committed 'multiple criminal offenses' which the panel is in the course of investigating.

## Rishi Sunak praises Boris Johnson after his decision not to run in the Tory leadership contest
 - [https://www.dailymail.co.uk/news/article-11346689/Rishi-Sunak-praises-Boris-Johnson-decision-not-run-Tory-leadership-contest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346689/Rishi-Sunak-praises-Boris-Johnson-decision-not-run-Tory-leadership-contest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:49:13+00:00

The former PM tonight said continuing his bid to return to No10 was 'simply not the right thing to do' after unsuccessfully reaching out to his two main rivals in an attempt to make a political pact.

## Murder suspect wanted for deaths of four across Arizona and Las Vegas is found dead in desert
 - [https://www.dailymail.co.uk/news/article-11346519/Murder-suspect-wanted-deaths-four-Arizona-Las-Vegas-dead-desert.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346519/Murder-suspect-wanted-deaths-four-Arizona-Las-Vegas-dead-desert.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:49:05+00:00

A man wanted in connection to four murders across Arizona and Nevada was found dead in the desert next to his girlfriend in an apparent murder-suicide.

## Penny Mordaunt resists calls to stand down to give Rishi Sunak a clean coronation
 - [https://www.dailymail.co.uk/news/article-11346907/Penny-Mordaunt-resists-calls-stand-Rishi-Sunak-clean-coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346907/Penny-Mordaunt-resists-calls-stand-Rishi-Sunak-clean-coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:46:53+00:00

With lagging support from MPs, there were serious questions about whether Penny Mordaunt would secure the 100 nominations needed by 2pm today to make it on to the ballot paper.

## California court rules in favor of Christian baker who refused to bake cake for lesbian wedding
 - [https://www.dailymail.co.uk/news/article-11346241/California-court-rules-favor-Christian-baker-refused-bake-cake-lesbian-wedding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346241/California-court-rules-favor-Christian-baker-refused-bake-cake-lesbian-wedding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:44:29+00:00

A California baker has won an anti-discrimination lawsuit over her refusal to make a wedding cake for a lesbian couple in October of 2017.

## GBBO winner Nadiya Hussain reveals make-up artists would lighten her skin for photoshoots
 - [https://www.dailymail.co.uk/tvshowbiz/article-11347005/GBBO-winner-Nadiya-Hussain-reveals-make-artists-lighten-skin-photoshoots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11347005/GBBO-winner-Nadiya-Hussain-reveals-make-artists-lighten-skin-photoshoots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:40:35+00:00

The television star, 37, who won the sixth series of The Great British Bake Off back in 2015, said that she was too scared to speak up for fear of 'rocking the boat'.

## Mom of Subway shove victim, who is now suicidal, BLASTS Mayor Eric Adams' response to NYC violence
 - [https://www.dailymail.co.uk/news/article-11345727/Maniac-shoves-stranger-NYC-subway-tracks-THIRTEENTH-person-pushed-platform-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11345727/Maniac-shoves-stranger-NYC-subway-tracks-THIRTEENTH-person-pushed-platform-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:40:31+00:00

A waiter and life-long New Yorker who was randomly tackled onto subway tracks in Brooklyn on Friday afternoon is traumatized to the point of being suicidal, his mother has said.

## JB Hi-Fi worker reveals secrets of working at retail chain - and hacks every Aussie needs to know
 - [https://www.dailymail.co.uk/news/article-10979377/JB-Hi-Fi-worker-reveals-secrets-working-retail-chain-hacks-Aussie-needs-know.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-10979377/JB-Hi-Fi-worker-reveals-secrets-working-retail-chain-hacks-Aussie-needs-know.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:32:30+00:00

Anyone who's worked in retail would have plenty of stories about strange customers  and co-workers and their bizarre experiences with them.
My time at JB Hi-Fi was certainly no different.

## Rishi Sunak could be dragged into Partygate probe if he wins Tory leadership race, colleagues warn
 - [https://www.dailymail.co.uk/news/article-11346789/Rishi-Sunak-dragged-Partygate-probe-wins-Tory-leadership-race-colleagues-warn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346789/Rishi-Sunak-dragged-Partygate-probe-wins-Tory-leadership-race-colleagues-warn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:30:18+00:00

Rishi Sunak was warned that he could be dragged into the Commons 'Partygate' probe as he seemed on course to become leader of the Conservatives last night.

## DAILY MAIL COMMENT:  Let magnanimity lead to Conservative unity
 - [https://www.dailymail.co.uk/news/article-11347069/DAILY-MAIL-COMMENT-Let-magnanimity-lead-Conservative-unity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11347069/DAILY-MAIL-COMMENT-Let-magnanimity-lead-Conservative-unity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:28:35+00:00

DAILY MAIL COMMENT: In the end, there was no turmoil, no back-stabbing, no psychodrama. In fact, it was the exact opposite of how the fractious Tory party has conducted itself for months.

## More than 900,000 drivers face £1,000 fine for failing to return expired licence, data shows
 - [https://www.dailymail.co.uk/news/article-11346973/More-900-000-drivers-face-1-000-fine-failing-renew-licence-data-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346973/More-900-000-drivers-face-1-000-fine-failing-renew-licence-data-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:21:18+00:00

DVLA figures show 926,000 people held cards on September 3 which had expired in the past year. They must be renewed every ten years and failure to return expired licence can incur a £1,000 fine.

## Burger King will ban plastic lids on drinks in bid to combat eco-damaging waste
 - [https://www.dailymail.co.uk/news/article-11346965/Burger-King-ban-plastic-lids-drinks-bid-combat-eco-damaging-waste.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346965/Burger-King-ban-plastic-lids-drinks-bid-combat-eco-damaging-waste.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:17:33+00:00

The move is intended for meals served inside outlets and is estimated to remove 17million lids from circulation, saving over 30,000kg of plastic each year.

## Oxford road chiefs could issue PERMITS for locals to drive through city to slash traffic congestion
 - [https://www.dailymail.co.uk/news/article-11346971/Oxford-road-chiefs-issue-PERMITS-locals-drive-city-slash-traffic-congestion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346971/Oxford-road-chiefs-issue-PERMITS-locals-drive-city-slash-traffic-congestion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:16:27+00:00

Under the proposal, which will be decided upon next month, households would be issued with permits allowing them to drive across the city on 100 days a year per vehicle.

## Organizers host rally in Los Angeles by hanging anti-Semitic banners over a freeway
 - [https://www.dailymail.co.uk/news/article-11346433/Organizers-host-rally-Los-Angeles-hanging-anti-Semitic-banners-freeway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346433/Organizers-host-rally-Los-Angeles-hanging-anti-Semitic-banners-freeway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:13:14+00:00

An anti-Semitic group was seen hovering over a series of banners on a Los Angeles freeway while praising Kanye West's recent war against Jews.

## Atlassian billionaire Mike Cannon-Brookes to save Netball Australia as Gina Rinehart withdraws offer
 - [https://www.dailymail.co.uk/news/article-11346735/Atlassian-billionaire-Mike-Cannon-Brookes-save-Netball-Australia-Gina-Rinehart-withdraws-offer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346735/Atlassian-billionaire-Mike-Cannon-Brookes-save-Netball-Australia-Gina-Rinehart-withdraws-offer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:05:35+00:00

Calls are mounting for Atlassian billionaire Mike Cannon-Brookes to save Netball Australia following Gina Rinehart withdrawing her $15 million sponsorship offer over team 'virtue signaling'.

## Iain Duncan Smith fears Tories will fail to fully get behind new leader
 - [https://www.dailymail.co.uk/news/article-11346897/Iain-Duncan-Smith-fears-Tories-fail-fully-new-leader.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346897/Iain-Duncan-Smith-fears-Tories-fail-fully-new-leader.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:03:13+00:00

Sir Iain Duncan Smith questioned yesterday whether anyone could lead the Conservative Party in its current 'split and divided' state.

## Ukraine's First Lady urges Germany to supply more weapons for war with Russia as she visits refugees
 - [https://www.dailymail.co.uk/news/article-11346911/Ukraines-Lady-urges-Germany-supply-weapons-war-Russia-visits-refugees.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11346911/Ukraines-Lady-urges-Germany-supply-weapons-war-Russia-visits-refugees.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-24 00:02:31+00:00

President Volodymyr Zelensky's wife, Olena Zelenska, issued a plea for more weapons as she met some of the million Ukrainian refugees who have fled to German cities including Frankfurt.


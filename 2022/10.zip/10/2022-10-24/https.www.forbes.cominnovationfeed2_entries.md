# Source:Forbs - innovation, URL:https://www.forbes.com/innovation/feed2, language:en-US

## When Is The Next Solar Eclipse In North America? After Europe’s ‘Smiley Face’ Sun Today Comes Six Eclipses For The U.S. And Canada
 - [https://www.forbes.com/sites/jamiecartereurope/2022/10/24/when-is-the-next-solar-eclipse-in-america-after-todays-smiley-face-sun-comes-five-unmissable-eclipses/](https://www.forbes.com/sites/jamiecartereurope/2022/10/24/when-is-the-next-solar-eclipse-in-america-after-todays-smiley-face-sun-comes-five-unmissable-eclipses/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-25 00:00:00+00:00

There’s a solar eclipse in Eurasia today—but when is it America’s turn?

## The Tragedy Of Wasted Deforested Land
 - [https://www.forbes.com/sites/christinero/2022/10/24/the-tragedy-of-wasted-deforested-land/](https://www.forbes.com/sites/christinero/2022/10/24/the-tragedy-of-wasted-deforested-land/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 23:47:39+00:00

between a third and a half of the land being deforested for the sake of agriculture doesn’t actually get used for that purpose

## NuraTrue Pro Wireless Lossless Audio – Can You Hear The Difference?
 - [https://www.forbes.com/sites/bennyhareven/2022/10/24/nuratrue-pro-wireless-lossless-audio--can-you-hear-the-difference/](https://www.forbes.com/sites/bennyhareven/2022/10/24/nuratrue-pro-wireless-lossless-audio--can-you-hear-the-difference/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 23:22:22+00:00

A few months ago I got a chance to test out the NuraTrue Pro headphones – wireless earbuds with a unique selling point: CD-quality lossless audio. The question is - can you hear the difference compared to a compressed source such as an iPhone.

## ‘The Walking Dead’ Season 11, Episode 20 Review: They Keep Killing The Wrong Characters Off
 - [https://www.forbes.com/sites/erikkain/2022/10/24/the-walking-dead-season-11-episode-20-review-they-keep-killing-the-wrong-characters-off/](https://www.forbes.com/sites/erikkain/2022/10/24/the-walking-dead-season-11-episode-20-review-they-keep-killing-the-wrong-characters-off/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 22:48:55+00:00

The Walking Dead continues to shuffle its way through its final season in one of the most uninspired stories since the Savior wars.

## See How Vocal Biomarkers Could Help Diagnose Cancer
 - [https://www.forbes.com/sites/jenniferhicks/2022/10/24/see-how-vocal-biomarkers-could-help-diagnose-cancer/](https://www.forbes.com/sites/jenniferhicks/2022/10/24/see-how-vocal-biomarkers-could-help-diagnose-cancer/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 22:40:19+00:00

This research project uses machine learning to create a database that could use vocal biomarkers to detect cancer.

## Cybersecurity Must Become A Top Priority In Healthcare
 - [https://www.forbes.com/sites/saibala/2022/10/24/cybersecurity-must-become-a-top-priority-in-healthcare/](https://www.forbes.com/sites/saibala/2022/10/24/cybersecurity-must-become-a-top-priority-in-healthcare/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 22:36:09+00:00

Cybersecurity breaches in healthcare can very tangibly affect patient lives.

## Lenovo's "New IT" To Empower Businesses And A Better World
 - [https://www.forbes.com/sites/carolinamilanesi/2022/10/24/lenovos-new-it-to-empower-businesses-and-a-better-world/](https://www.forbes.com/sites/carolinamilanesi/2022/10/24/lenovos-new-it-to-empower-businesses-and-a-better-world/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 22:24:56+00:00

In an exclusive interview for Forbes,  I spoke to Lenovo's Chairman and CEO, Yang Yuanqing about the company's internal transformation, its focus on innovation and its commitment to making a positive difference in the world, starting with safeguarding the planet.

## Can Twitter Survive Elon Musk?
 - [https://www.forbes.com/sites/lensherman/2022/10/24/can-twitter-survive-elon-musk/](https://www.forbes.com/sites/lensherman/2022/10/24/can-twitter-survive-elon-musk/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 22:04:50+00:00

Twitter needs to stop playing to its competitors’ strengths in chasing ads!  Twitter has the unique opportunity to capture the value of the space they currently occupy, by launching a serious subscription business — not unlike the successful transformation the NY made to a subscription-based model.

## Zen And The Art Of User Experience
 - [https://www.forbes.com/sites/servicenow/2022/10/24/zen-and-the-art-of-user-experience/](https://www.forbes.com/sites/servicenow/2022/10/24/zen-and-the-art-of-user-experience/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 21:52:56+00:00

How a frictionless UX can boost productivity and security by helping employees get in “the zone.”

## E.ON Powers To A Successful Digital Transformation
 - [https://www.forbes.com/sites/patrickmoorhead/2022/10/24/eon-powers-to-a-successful-digital-transformation/](https://www.forbes.com/sites/patrickmoorhead/2022/10/24/eon-powers-to-a-successful-digital-transformation/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 21:52:22+00:00

#1-Ranked Industry Analyst Patrick Moorhead provides a real-world case study that shows the successful impact of digital transformation on E.ON, a well-established energy supplier in the UK.

## NVIDIA GeForce RTX 4090 Sell-Through Indicators Highlight A Thriving PC Gaming Market
 - [https://www.forbes.com/sites/davealtavilla/2022/10/24/nvidia-geforce-rtx-4090-sell-through-indicators-highlight-a-thriving-pc-gaming-market/](https://www.forbes.com/sites/davealtavilla/2022/10/24/nvidia-geforce-rtx-4090-sell-through-indicators-highlight-a-thriving-pc-gaming-market/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 21:14:50+00:00

Not only are gaming PCs with powerful graphics cards still experiencing solid demand, but the entire desktop PC platform has experienced a transformation of sorts in recent years, and was driven even further into the mainstream during the pandemic.

## Wells Fargo Launches Virtual Assistant, Cleverly Named Fargo
 - [https://www.forbes.com/sites/tomgroenfeldt/2022/10/24/wells-fargo-launches-virtual-assistant-cleverly-named-fargo/](https://www.forbes.com/sites/tomgroenfeldt/2022/10/24/wells-fargo-launches-virtual-assistant-cleverly-named-fargo/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 20:58:55+00:00

Fargo will draw on insights gleaned from its conversations with a customer, in addition to a customer’s spending patterns and behaviors, she added.

## Understanding The Blockchain Layers To Solve The Scalability Challenges
 - [https://www.forbes.com/sites/sanjitsinghdang/2022/10/24/understanding-the-blockchain-layers-to-solve-the-scalability-challenges/](https://www.forbes.com/sites/sanjitsinghdang/2022/10/24/understanding-the-blockchain-layers-to-solve-the-scalability-challenges/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 20:57:09+00:00

Blockchain has tremendous advantages since it enables trust among its participants. This powerful mechanism is enabled by a layered architecture design of blockchain that empowers consensus and communication between the chain members. We lay out each layer of the blockchain and the role it plays.

## Fear Of Missing Out (FOMO) Associated With Maladaptive Behaviors Among College Students
 - [https://www.forbes.com/sites/anuradhavaranasi/2022/10/24/fear-of-missing-out-fomo-associated-with-maladaptive-behaviors-among-college-students/](https://www.forbes.com/sites/anuradhavaranasi/2022/10/24/fear-of-missing-out-fomo-associated-with-maladaptive-behaviors-among-college-students/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 20:33:59+00:00

A recent study that focuses on college students reveals that these behaviors include academic misconduct, drug and alcohol use, and breaking the law.

## Using Artificial Intelligence To Hunt For New Drugs: Daphne Koller’s Next Big Mission
 - [https://www.forbes.com/sites/stevevassallo/2022/10/24/using-artificial-intelligence-to-hunt-for-new-drugs-daphne-kollers-next-big-mission/](https://www.forbes.com/sites/stevevassallo/2022/10/24/using-artificial-intelligence-to-hunt-for-new-drugs-daphne-kollers-next-big-mission/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 20:01:40+00:00

The promise and perils of applying artificial intelligence to drug discovery. And advice on how to avoid inconsolable regret in life.

## DOJ Charges Alleged Chinese Intelligence Officers With Trying To Interfere With Huawei Prosecution
 - [https://www.forbes.com/sites/alisondurkee/2022/10/24/doj-charges-alleged-chinese-intelligence-officers-with-trying-to-interfere-with-huawei-prosecution/](https://www.forbes.com/sites/alisondurkee/2022/10/24/doj-charges-alleged-chinese-intelligence-officers-with-trying-to-interfere-with-huawei-prosecution/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 19:40:08+00:00

The DOJ previously indicted Chinese telecommunications giant Huawei on charges including fraud, racketeering and money laundering.

## Undisputed Day 1 Early Access Roster Update
 - [https://www.forbes.com/sites/brianmazique/2022/10/24/undisputed-day-1-early-access-roster-update/](https://www.forbes.com/sites/brianmazique/2022/10/24/undisputed-day-1-early-access-roster-update/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 19:17:07+00:00

The Day 1 early access roster for Undisputed grows each day with the release date potentially coming as early as December.

## Remote AV Testing Made Possible By $5.1 Million Investment In Univ. Of Michigan Site
 - [https://www.forbes.com/sites/edgarsten/2022/10/24/remote-av-testing-made-possible-by-51-million-investment-in-univ-of-michigan-site/](https://www.forbes.com/sites/edgarsten/2022/10/24/remote-av-testing-made-possible-by-51-million-investment-in-univ-of-michigan-site/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 18:40:38+00:00

Development of autonomous vehicles could be accelerated following a major investment in the University of Michigan's unique AV test facility giving researchers across the nation the ability to run remote tests.

## New Psychological Research Identifies 2 Ingredients Of A Great Dating Profile
 - [https://www.forbes.com/sites/traversmark/2022/10/24/new-psychological-research-identifies-2-ingredients-of-a-great-dating-profile/](https://www.forbes.com/sites/traversmark/2022/10/24/new-psychological-research-identifies-2-ingredients-of-a-great-dating-profile/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 18:38:59+00:00

Originality and self-disclosure are two elements of a captivating dating profile. Why do so many people miss it?

## Tesla Asks Drivers To Vote On New Supercharger Locations, But Will They Be Rural?
 - [https://www.forbes.com/sites/bradtempleton/2022/10/24/tesla-asks-drivers-to-vote-on-new-supercharger-locations-but-will-they-be-rural/](https://www.forbes.com/sites/bradtempleton/2022/10/24/tesla-asks-drivers-to-vote-on-new-supercharger-locations-but-will-they-be-rural/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 17:57:11+00:00

We need chargers not just on the popular routes but to make it possible to go anywhere in the backcountry without an EV being a compromise over gasoline.  It's not that hard to do.

## The Accidental Ecosystem By Peter S. Alagona — Review
 - [https://www.forbes.com/sites/grrlscientist/2022/10/24/the-accidental-ecosystem-by-peter-s-alagona---review/](https://www.forbes.com/sites/grrlscientist/2022/10/24/the-accidental-ecosystem-by-peter-s-alagona---review/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 17:28:55+00:00

This book tells the unlikely story of America’s cities — the ecosystem that was never supposed to exist — and how they went from being bereft of native wildlife to being populated by wild creatures

## TRICARE For All: Wrong For Iowa And America
 - [https://www.forbes.com/sites/gracemarieturner/2022/10/24/tricare-for-all-wrong-for-iowa-and-america/](https://www.forbes.com/sites/gracemarieturner/2022/10/24/tricare-for-all-wrong-for-iowa-and-america/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 17:24:55+00:00

Doctors can accept TRICARE’s lower rates because their practices also receive payments from private payers that fill the gap and keep their practices afloat.

## 15 Industry Leaders Share Their Votes For The Top Business Tech Story Of 2022
 - [https://www.forbes.com/sites/forbestechcouncil/2022/10/24/15-industry-leaders-share-their-votes-for-the-top-business-tech-story-of-2022/](https://www.forbes.com/sites/forbestechcouncil/2022/10/24/15-industry-leaders-share-their-votes-for-the-top-business-tech-story-of-2022/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 17:15:00+00:00

It's every leader’s job to be familiar with the tech tools leveraged in their organization and industry and to have an ear to the ground for what’s to come.

## Apple iOS 16.1: iPhone Users Urged To Update For Dazzling New Features
 - [https://www.forbes.com/sites/davidphelan/2022/10/24/apple-ios-161-iphone-users-urged-to-update-for-dazzling-new-features/](https://www.forbes.com/sites/davidphelan/2022/10/24/apple-ios-161-iphone-users-urged-to-update-for-dazzling-new-features/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 17:09:35+00:00

Apple’s latest iPhone software has been a long time coming and has lots of neat upgrades.

## Tesla Deserves An “A” For Its Financial Management
 - [https://www.forbes.com/sites/effibenmelech/2022/10/24/tesla-deserves-an-a-for-its-financial-management/](https://www.forbes.com/sites/effibenmelech/2022/10/24/tesla-deserves-an-a-for-its-financial-management/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 16:14:32+00:00

Tesla is facing growing competition in the EV space, which will likely erode its margins, and the risk of a recession is looming over all automakers. But Tesla is in a strong financial position, with a history of financial shrewdness and a proven record.

## 3 Tips To Master The Art Of The Long-Distance Relationship
 - [https://www.forbes.com/sites/traversmark/2022/10/24/3-tips-to-master-the-art-of-the-long-distance-relationship/](https://www.forbes.com/sites/traversmark/2022/10/24/3-tips-to-master-the-art-of-the-long-distance-relationship/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 15:51:02+00:00

Are we too quick to dismiss long-distance relationships?

## New MacBook Pro Leak Reveals Apple’s Powerful Surprise
 - [https://www.forbes.com/sites/ewanspence/2022/10/24/apple-macbook-pro-m2-pro-m2-ultra-leak-rumor/](https://www.forbes.com/sites/ewanspence/2022/10/24/apple-macbook-pro-m2-pro-m2-ultra-leak-rumor/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 15:48:31+00:00

Apple's MacBook Pro upgrade may not have made an appearance in October, but new details on the professional macOS laptops will keep interest high as people wait for their launch.

## Ventana Micro Brings RISC-V Into The Data Center
 - [https://www.forbes.com/sites/karlfreund/2022/10/24/ventana-micro-brings-risc-v-into-the-data-center/](https://www.forbes.com/sites/karlfreund/2022/10/24/ventana-micro-brings-risc-v-into-the-data-center/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 15:20:29+00:00

Ventana Micro Systems is out in front in enabling RISC-V to be Data-center grade.

## What Role Can Consumer Products Branding Play In The Kind Of World We Are Passing Along To Younger Generations?
 - [https://www.forbes.com/sites/stevensavage/2022/10/24/what-role-can-consumer-products-companies-play-in-the-kind-of-world-we-are-passing-along-to-younger-generations/](https://www.forbes.com/sites/stevensavage/2022/10/24/what-role-can-consumer-products-companies-play-in-the-kind-of-world-we-are-passing-along-to-younger-generations/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 15:00:00+00:00

Last week (October 17-20) a diverse community of businesses and organizations met for the Sustainable Brands 2022 conference

## Washington’s New $6 Billion Metro Line Needs Simpler Solutions
 - [https://www.forbes.com/sites/dianafurchtgott-roth/2022/10/24/washingtons-new-6-billion-metro-line-needs-simpler-solutions/](https://www.forbes.com/sites/dianafurchtgott-roth/2022/10/24/washingtons-new-6-billion-metro-line-needs-simpler-solutions/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 14:46:55+00:00

Trains aren’t available because most of Metro’s 7000-series rail cars, built by the Japanese firm Kawasaki, are sidelined due to safety concerns.

## Netflix-Ubisoft, Disney-Nintendo And The Nightmare Media Mergers We Don’t Need
 - [https://www.forbes.com/sites/paultassi/2022/10/24/netflix-ubisoft-disney-nintendo-and-the-nightmare-media-mergers-we-dont-need/](https://www.forbes.com/sites/paultassi/2022/10/24/netflix-ubisoft-disney-nintendo-and-the-nightmare-media-mergers-we-dont-need/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 14:45:32+00:00

Consolidation is happening all across the video game industry, with massive publishers devouring smaller ones on a nearly monthly basis, and it can often feel like we are heading toward a future where every video game is published by Microsoft, Sony, Nintendo or Embracer Group.

## American Semiconductor Innovation Coalition Readies Advanced Semiconductor Research Proposal For US CHIPS And Science Act
 - [https://www.forbes.com/sites/tiriasresearch/2022/10/24/american-semiconductor-innovation-coalition-readies-advanced-semiconductor-research-proposal-for-us-chips-and-science-act/](https://www.forbes.com/sites/tiriasresearch/2022/10/24/american-semiconductor-innovation-coalition-readies-advanced-semiconductor-research-proposal-for-us-chips-and-science-act/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 14:23:42+00:00

Using an established facility like the Albany NanoTech Complex as the seed crystal for NSTC and NAPMP makes quite a bit of economic sense and should be considered.

## What’s The Promise Of Healthcare Technology For Aging In Place?
 - [https://www.forbes.com/sites/forbestechcouncil/2022/10/24/whats-the-promise-of-healthcare-technology-for-aging-in-place/](https://www.forbes.com/sites/forbestechcouncil/2022/10/24/whats-the-promise-of-healthcare-technology-for-aging-in-place/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 14:15:00+00:00

The good news is that this glaring need to support both seniors and their caregivers has created an acute market opportunity. Are technology providers ready to deliver the tools necessary to strengthen the care relationships between seniors and caregivers?

## RPA Debunked: Why Rules-Based Automation Isn’t Built To Last
 - [https://www.forbes.com/sites/forbestechcouncil/2022/10/24/rpa-debunked-why-rules-based-automation-isnt-built-to-last/](https://www.forbes.com/sites/forbestechcouncil/2022/10/24/rpa-debunked-why-rules-based-automation-isnt-built-to-last/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 14:00:00+00:00

While we should not discount its achievements, RPA has natural limitations, from its high cost to how easily it breaks down when pushed beyond its rigid rule set.

## This Company Just Raised $71 Million To See The Forest For The Trees Within A Patient’s Cells
 - [https://www.forbes.com/sites/alexknapp/2022/10/24/this-company-just-raised-71-million-to-see-the-forest-for-the-trees-within-a-patients-cells/](https://www.forbes.com/sites/alexknapp/2022/10/24/this-company-just-raised-71-million-to-see-the-forest-for-the-trees-within-a-patients-cells/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 14:00:00+00:00

Spatial biology startup Resolve Biosciences is building up capital to accelerate its development of  'Genomics 3.0.'

## Science Sleuths Solve Century-Old Mystery Of Martian Meteorite's Discovery
 - [https://www.forbes.com/sites/davidbressan/2022/10/24/science-sleuths-solve-century-old-mystery-of-martian-meteorites-discovery/](https://www.forbes.com/sites/davidbressan/2022/10/24/science-sleuths-solve-century-old-mystery-of-martian-meteorites-discovery/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 13:53:15+00:00

A toxin that makes pigs vomit is the surprising key which has unlocked the century-old mystery of the origins of a Martian meteorite, and the possible identity of the Black student who discovered it.

## ‘Black Adam’ Bests ‘Shazam,’ Meaning ‘Black Adam 2’ Is Inevitable
 - [https://www.forbes.com/sites/paultassi/2022/10/24/black-adam-bests-shazam-meaning-black-adam-2-is-inevitable/](https://www.forbes.com/sites/paultassi/2022/10/24/black-adam-bests-shazam-meaning-black-adam-2-is-inevitable/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 13:47:57+00:00

The opening weekend numbers are in, and Black Adam has…performed quite well.

## How The Availability Of AI Is Changing The Security Landscape For Both Users And Developers
 - [https://www.forbes.com/sites/forbestechcouncil/2022/10/24/how-the-availability-of-ai-is-changing-the-security-landscape-for-both-users-and-developers/](https://www.forbes.com/sites/forbestechcouncil/2022/10/24/how-the-availability-of-ai-is-changing-the-security-landscape-for-both-users-and-developers/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 13:45:00+00:00

As the use of AI continues to expand, new applications will continue to arise—and today’s businesses should be prepared to take advantage.

## How (And Why) To Engage Employees Beyond Their Corner Of A Business
 - [https://www.forbes.com/sites/forbestechcouncil/2022/10/24/how-and-why-to-engage-employees-beyond-their-corner-of-a-business/](https://www.forbes.com/sites/forbestechcouncil/2022/10/24/how-and-why-to-engage-employees-beyond-their-corner-of-a-business/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 13:30:00+00:00

Expanding the definition of "need to know" for everyone can have strong benefits for individual employees and the business as a whole.

## In Tough Times, Risk Management Means Looking Beyond Current Problems
 - [https://www.forbes.com/sites/steveculp/2022/10/24/in-tough-times-risk-management-means-looking-beyond-current-problems/](https://www.forbes.com/sites/steveculp/2022/10/24/in-tough-times-risk-management-means-looking-beyond-current-problems/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 13:27:15+00:00

As volatility increases, risk management is being put on the spot. The temptation is for organizations to cut back and slow down, but standing still means losing ground competitively

## Take An All-Aboard Approach For New Tech Adoption
 - [https://www.forbes.com/sites/forbestechcouncil/2022/10/24/take-an-all-aboard-approach-for-new-tech-adoption/](https://www.forbes.com/sites/forbestechcouncil/2022/10/24/take-an-all-aboard-approach-for-new-tech-adoption/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 13:15:00+00:00

When it comes to new technology adoption, the technology is the easy part.

## How Procurement Leaders Drive Sustainability Into Midsize Companies
 - [https://www.forbes.com/sites/sap/2022/10/24/how-procurement-leaders-drive-sustainability-into-midsize-companies/](https://www.forbes.com/sites/sap/2022/10/24/how-procurement-leaders-drive-sustainability-into-midsize-companies/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 13:13:56+00:00

Learn how procurement leaders from midsize companies move beyond cost savings and toward operational resilience by prioritizing sustainability.

## Everything We Know About ‘House Of The Dragon’ Season 2
 - [https://www.forbes.com/sites/paultassi/2022/10/24/everything-we-know-about-house-of-the-dragon-season-2/](https://www.forbes.com/sites/paultassi/2022/10/24/everything-we-know-about-house-of-the-dragon-season-2/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 13:10:58+00:00

Here's what we know about House of the Dragon season 2 so far.

## Always-On Security In A Bot-Infested World
 - [https://www.forbes.com/sites/emilsayegh/2022/10/24/always-on-security-in-a-bot-infested-world/](https://www.forbes.com/sites/emilsayegh/2022/10/24/always-on-security-in-a-bot-infested-world/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 13:00:45+00:00

Not only do efforts equal expense, but bot attacks also have a direct impact on lost revenues and increased operational costs.

## AI Coming Of Age: Lessons For Startups
 - [https://www.forbes.com/sites/forbestechcouncil/2022/10/24/ai-coming-of-age-lessons-for-startups/](https://www.forbes.com/sites/forbestechcouncil/2022/10/24/ai-coming-of-age-lessons-for-startups/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 13:00:00+00:00

Startups might have an advantage over larger organizations in using AI: Building new business processes is a lot easier than changing existing processes that affect thousands of employees.

## Destiny 2’s Top 10 PvP Weapons List Is The Weirdest It Has Ever Looked
 - [https://www.forbes.com/sites/paultassi/2022/10/24/destiny-2s-top-10-pvp-weapons-list-is-the-weirdest-it-has-ever-looked/](https://www.forbes.com/sites/paultassi/2022/10/24/destiny-2s-top-10-pvp-weapons-list-is-the-weirdest-it-has-ever-looked/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 12:59:21+00:00

Destiny 2 has been attempting to hammer itself into new PvPs metas for a long while now, and we have reached a pretty bizarre point in the game’s history.

## New Apple Leak Reveals iPhone 15 Release Shock
 - [https://www.forbes.com/sites/gordonkelly/2022/10/24/apple-iphone-15-pro-max-ultra-titanium-chassis-new-iphone-design/](https://www.forbes.com/sites/gordonkelly/2022/10/24/apple-iphone-15-pro-max-ultra-titanium-chassis-new-iphone-design/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 12:55:39+00:00

Apple's flagship iPhone 15 will be unlike any previous iPhone...

## Five Key Practices For Becoming Authentic Female Leaders
 - [https://www.forbes.com/sites/forbestechcouncil/2022/10/24/five-key-practices-for-becoming-authentic-female-leaders/](https://www.forbes.com/sites/forbestechcouncil/2022/10/24/five-key-practices-for-becoming-authentic-female-leaders/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 12:45:00+00:00

Continually practicing and developing as authentic female leaders becomes the way forward to living a fulfilling life through contribution.

## ‘Bayonetta’ Voice Actress Admits She Was Not Offered Only $4,000 For The New Game
 - [https://www.forbes.com/sites/paultassi/2022/10/24/bayonetta-voice-actress-admits-she-was-not-offered-only-4000-for-the-new-game/](https://www.forbes.com/sites/paultassi/2022/10/24/bayonetta-voice-actress-admits-she-was-not-offered-only-4000-for-the-new-game/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 12:36:05+00:00

The dam has broken on the already messy Bayonetta 3 story, in which the game’s original voice actress, Hellena Taylor, claimed she was offered only $4,000 to reprise the role for the game.

## Why Logistics Might Be Ready For The Marketplace Model
 - [https://www.forbes.com/sites/forbestechcouncil/2022/10/24/why-logistics-might-be-ready-for-the-marketplace-model/](https://www.forbes.com/sites/forbestechcouncil/2022/10/24/why-logistics-might-be-ready-for-the-marketplace-model/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 12:30:00+00:00

Logistics typically involves three players, just like a marketplace.

## Israel Rolls Out Legion-X Drone Swarm For The Urban Battlefield
 - [https://www.forbes.com/sites/davidhambling/2022/10/24/israel-rolls-out-legion-x-drone-swarm-for-the-urban-battlefield/](https://www.forbes.com/sites/davidhambling/2022/10/24/israel-rolls-out-legion-x-drone-swarm-for-the-urban-battlefield/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 12:15:03+00:00

Israel is equipping infantry support companies with drone swarms for "seek-and-strike" missions, with a mix of aerial and ground robots able to navigate autonomously through urban terrain and find and attack targets.

## 14 Tasks Every IT Leader Should Delegate To Their Team
 - [https://www.forbes.com/sites/forbestechcouncil/2022/10/24/14-tasks-every-it-leader-should-delegate-to-their-team/](https://www.forbes.com/sites/forbestechcouncil/2022/10/24/14-tasks-every-it-leader-should-delegate-to-their-team/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 12:15:00+00:00

As tech leaders play increasingly large roles in companies, it’s essential for them to embrace the art of delegation.

## What’s Next For Telemedicine, And How Do We Get There?
 - [https://www.forbes.com/sites/forbestechcouncil/2022/10/24/whats-next-for-telemedicine-and-how-do-we-get-there/](https://www.forbes.com/sites/forbestechcouncil/2022/10/24/whats-next-for-telemedicine-and-how-do-we-get-there/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 12:15:00+00:00

Telehealth and RPM play an integral role in attaining unprecedented results, but achievement will come through a series of steps that build on previous successes while keeping an open mind to creativity and innovation.

## Apple TV Apps Just Got A Major New Feature
 - [https://www.forbes.com/sites/johnarcher/2022/10/24/apple-tv-apps-just-got-a-major-new-feature/](https://www.forbes.com/sites/johnarcher/2022/10/24/apple-tv-apps-just-got-a-major-new-feature/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 12:07:17+00:00

Samsung TV owners will be particularly happy

## Obamacare Open Enrollment Brings Election Day "Gift" To Voters
 - [https://www.forbes.com/sites/sallypipes/2022/10/24/obamacare-open-enrollment-brings-election-day-gift-to-voters/](https://www.forbes.com/sites/sallypipes/2022/10/24/obamacare-open-enrollment-brings-election-day-gift-to-voters/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 12:00:00+00:00

Last year, Obamacare sign-ups hit a record. The Biden administration is no doubt hoping for another one this year. And it doesn't care if it has to spend tens of billions of taxpayer dollars to get it.

## Why We Should All Appreciate Compliance Professionals More In 2022
 - [https://www.forbes.com/sites/forbestechcouncil/2022/10/24/why-we-should-all-appreciate-compliance-professionals-more-in-2022/](https://www.forbes.com/sites/forbestechcouncil/2022/10/24/why-we-should-all-appreciate-compliance-professionals-more-in-2022/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 12:00:00+00:00

You may not see any movies or comic books made about them, but when they do their duty with excellence and attention to detail, they can be the superheroes who save their institutions from cybercrime, millions of dollars in fines and reputational damage.

## Quantum Networking: A Market In Search Of A Leader
 - [https://www.forbes.com/sites/forbestechcouncil/2022/10/24/quantum-networking-a-market-in-search-of-a-leader/](https://www.forbes.com/sites/forbestechcouncil/2022/10/24/quantum-networking-a-market-in-search-of-a-leader/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 11:45:00+00:00

Quantum networking is one area within the quantum world that could represent a potential greenfield opportunity for the savvy entrepreneur or investor.

## Gain-Of-Function Experiments At Boston University Create A Deadly New Covid-19 Virus. Who Thought This Was A Good Idea?
 - [https://www.forbes.com/sites/stevensalzberg/2022/10/24/gain-of-function-experiments-at-boston-university-create-a-deadly-new-covid-19-virus-who-thought-this-was-a-good-idea/](https://www.forbes.com/sites/stevensalzberg/2022/10/24/gain-of-function-experiments-at-boston-university-create-a-deadly-new-covid-19-virus-who-thought-this-was-a-good-idea/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 11:30:00+00:00

After all the controversy over the past 2 years about gain-of-function research on viruses, it's shocking to learn that scientists at Boston University have just created a brand-new Covid-19 virus that causes 80% mortality in lab mice.

## The Importance Of Understanding Tech Debt—Even If It Doesn't Sound Cool
 - [https://www.forbes.com/sites/forbestechcouncil/2022/10/24/the-importance-of-understanding-tech-debt-even-if-it-doesnt-sound-cool/](https://www.forbes.com/sites/forbestechcouncil/2022/10/24/the-importance-of-understanding-tech-debt-even-if-it-doesnt-sound-cool/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 11:30:00+00:00

Tech debt is really more about prioritization than procrastination.

## Sound Is Becoming An Increasingly Important Component Of AR/VR
 - [https://www.forbes.com/sites/forbestechcouncil/2022/10/24/sound-is-becoming-an-increasingly-important-component-of-arvr/](https://www.forbes.com/sites/forbestechcouncil/2022/10/24/sound-is-becoming-an-increasingly-important-component-of-arvr/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 11:15:00+00:00

Realistic audio is expanding in VR and AR as businesses and creators learn how to implement it.

## A Background On Influencer Marketing And Four Strategies To Consider
 - [https://www.forbes.com/sites/forbestechcouncil/2022/10/24/a-background-on-influencer-marketing-and-four-strategies-to-consider/](https://www.forbes.com/sites/forbestechcouncil/2022/10/24/a-background-on-influencer-marketing-and-four-strategies-to-consider/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 11:00:00+00:00

Although "influencer marketing" might sound self-explanatory, there are many ways to go about it, some of which might pose significant risks or advantages to your company or brand.

## When A Celebrated Native Son Hires In Mexico And Cuts Staff At Home
 - [https://www.forbes.com/sites/amyfeldman/2022/10/24/when-a-celebrated-native-son-hires-in-mexico-and-cuts-staff-at-home/](https://www.forbes.com/sites/amyfeldman/2022/10/24/when-a-celebrated-native-son-hires-in-mexico-and-cuts-staff-at-home/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 11:00:00+00:00

Landing’s Bill Smith, one of Birmingham, Alabama’s biggest boosters, 
hired 100 workers in Mexico City, then laid off staff at home.

## Why Good Research Doesn’t Need To Take A Long Time
 - [https://www.forbes.com/sites/forbestechcouncil/2022/10/24/why-good-research-doesnt-need-to-take-a-long-time/](https://www.forbes.com/sites/forbestechcouncil/2022/10/24/why-good-research-doesnt-need-to-take-a-long-time/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 10:45:00+00:00

Here’s where we can learn from Covid-19 vaccine development. Speed should be a critical value, as not even the most resourced labs, businesses or even countries can expand time. Whatever we’re investigating, we need to find those answers faster.

## Why We Need APIs (And APIs Need Us Too)
 - [https://www.forbes.com/sites/adrianbridgwater/2022/10/24/why-we-need-apis-and-apis-need-us-too/](https://www.forbes.com/sites/adrianbridgwater/2022/10/24/why-we-need-apis-and-apis-need-us-too/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-10-24 10:31:09+00:00

This scenario actually already exists via projects like API gateway authentication, which is full of authoritative content.


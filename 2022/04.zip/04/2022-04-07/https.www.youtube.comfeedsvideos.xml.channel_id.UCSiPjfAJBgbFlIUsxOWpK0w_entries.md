# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Danny // Nataly Dawn of POMPLAMOOSE
 - [https://www.youtube.com/watch?v=eecBkwPHZ8g](https://www.youtube.com/watch?v=eecBkwPHZ8g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2022-04-07 00:00:00+00:00

This song is in honor of my great-grandmother, Danny. The name stood for “Dearest Granny,” but I only learned that a week ago :) Her actual name was Jane, but she took on the identity of Danny when her grandchildren came into the world. Some of my earliest memories are of her - sitting by her rocking chair, listening to songs and stories, going to her funeral. She was sharp as a tack, and especially loved poetry and riddles. So the chorus of the song is something of a riddle: “The window of opportunity is never as wide or so narrow as you expect it to be.” I don’t know that it’s very helpful advice, but at least it makes you scratch your head a little. What I love about the video is that it pays homage to her love of riddles too. The visual stunts are so smart and playful. A special thanks to Dom Fera for directing it, and Athena Wheaton for editing. It took a very focused crew to make this video happen and watching it come together was like magic. All that to say I’m very grateful to you all, and I think my great-grandma would love what we made together.

Spotify: https://open.spotify.com/artist/1vCgeJQjG0SFPCC9ixbCGz?si=Rhvgntj-RIWCp0kujm6_kQ
Apple Music: https://music.apple.com/us/artist/nataly-dawn/332859204

"Danny" is an original song by Nataly Dawn from her upcoming album "Gardenview"

VIDEO CREDITS
Director: Dom Fera
Director of Photography: Christian Colwell
Producer: Ryan Blewett
Editor: Athena Wheaton
Assistant Director: Michael Kiaunis
Hair and Makeup: Z'Dra Jaye
Production Designer: Bethany Struble
Wardrobe: Alexandria Allen
Unit Production Manager: Quinn Cavin
1st Assistant Camera: Austin Hughes
Gaffer: Alex Forcillo
Best Electric: Nolan Englund
Key Grip: Chris Li
Best Grip: Harrison Bliss

MUSICIAN CREDITS
Vocals: Nataly Dawn
Vibraphone, Harmonica, Wurlitzer: Ross Garren
Guitar: John Schroeder
Upright Bass: Eliana Athayde 
Drums: Kyle Crane

AUDIO CREDITS
Engineer/Mix: Caleb Parker
Assistant Engineer: Henri Cash
Mastering: Will Borza
Produced by: Ross Garren, John Schroeder & Nataly Dawn

LYRICS
Danny
I wish that I could see you there
Right beside your rocking chair
Recite your poetry

Oh Danny
Your stories in the Bible
Your mind was never idle
What are you telling me

Said you’d be surprised that the window
Of opportunity
Is never as wide or so narrow
As you expect it to be

Oh Danny
You always had such good advice
Except for when I wanted it
Like I want it now

And you’d be surprised that the window
Of opportunity
Is never as wide or so narrow
As you expect it to be
And I spent my life looking
For opportunity
When all of the while it was sitting
Right next to me
Yeah all of the while you were sitting
Right next to me


# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Wheel of Time Game Re-Release🎮Berserk 41👿Spirited Away Play💀-FANTASY NEWS
 - [https://www.youtube.com/watch?v=DfsZhNPOmPc](https://www.youtube.com/watch?v=DfsZhNPOmPc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-04-08 00:00:00+00:00

LET'S JUMP INTO THE FANTASY NEWS! 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.designbyhumans.com/shop/FantasyNews/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

NEWS:

00:00 intro

01:04 Wheel of Time Game Return: https://www.gog.com/en/game/the_wheel_of_time

02:46 Berserk Release: https://www.animenewsnetwork.com/news/2022-04-04/dark-horse-to-publish-1st-berserk-manga-volume-since-kentarou-miura-passing-in-november/.184361 

04:49 r/place

06:26 Gleanings: https://twitter.com/NealShusterman/status/1511029426099785731 

06:53 Witcher Cookbook: https://www.amazon.com/Witcher-Cookbook-Official-Guide-Continent/dp/1984860933 

07:36 Spirited Away Play: https://hypebeast.com/2022/4/live-action-spirited-away-play-to-stream-on-hulu 

09:11 Locke and Key: https://deadline.com/2022/04/locke-key-end-season-3-final-season-netflix-canceled-1234995301/ 

11:27 Ukraine Charity Fundraiser: https://youtu.be/Qve12mzK1iA 

11:41 Chris Pratt Garfield: https://twitter.com/discussingfilm/status/1511389844517400582?s=21&t=ZlktzK5xfhr0Ha2xIEZOag

13:34 Most Distant Star: https://www.sciencenews.org/article/star-most-distant-farthest-earendel-light-hubble

## Attack on Titan Final Season Review
 - [https://www.youtube.com/watch?v=-Kn5Ydu9NjM](https://www.youtube.com/watch?v=-Kn5Ydu9NjM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-04-07 00:00:00+00:00

My thoughts on the latest episode drops from #AttackOnTitan 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.designbyhumans.com/shop/FantasyNews/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231


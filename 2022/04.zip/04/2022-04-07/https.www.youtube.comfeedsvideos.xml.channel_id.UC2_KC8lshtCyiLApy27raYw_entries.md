# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## Early CGI Was Horrifying
 - [https://www.youtube.com/watch?v=XyGfxCxnZW0](https://www.youtube.com/watch?v=XyGfxCxnZW0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2022-04-07 20:01:38+00:00

CGI. Now with liminal spaces.

Unknown creations beyond human comprehension

Also sometimes lamps

Often a teapot


Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub

Be sure to check out my other channel ; https://www.youtube.com/c/Whimsu

Video Credits. Lots of good CGI stuff out there and I couldn't cover it all;

Ultimate History of CGI
Gabriel Mendes
Retro Space HD
Muzzy mawr
thelateraleye16
VintageCG
Rich S
Arbor Video
Sean Cunningham
saburwulf
Digital Guru
David Hoffman
crystalsculpture2
smeedysyd
Big 13


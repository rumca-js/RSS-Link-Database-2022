# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## ROCKSTAR REMAKING TWO OLDER GAMES, TOMB RAIDER RETURNS, & MORE
 - [https://www.youtube.com/watch?v=2c4CA7FoS9g](https://www.youtube.com/watch?v=2c4CA7FoS9g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-04-08 00:00:00+00:00

Thank you Raycon for sponsoring this video. Go to https://buyraycon.com/gameranx for 15% off your order! Brought to you by Raycon.

Max Payne, Monkey Island, and Tomb Raider make a return! Unreal Engine 5 graphics showcases bring the heat! All this and more in a week full of gaming news.

Jake on twitter: https://bit.ly/3gdkPqD​​​​

Instagram: https://bit.ly/3uUh9Ot


 ~~~~STORIES~~~~



Max Payne
https://investors.remedygames.com/announcements/remedy-entertainment-enters-agreement-with-rockstar-games-for-new-max-payne-12-project/

New Monkey Island
https://youtu.be/sahskKAxSCY

New Tomb Raider
https://www.theverge.com/2022/4/5/23011603/tomb-raider-new-crystal-dynamics-unreal-engine-5



Coalition cinematic UE5 tech demo
https://youtu.be/RTnYpt-QknA

Elden Ring no hit/damage run
https://youtu.be/mcd0Ne7ke4k


House of the Dead
https://youtu.be/dfN6YupQd7c

LEGO Star Wars 
https://youtu.be/3OXMDrrdogk

Rogue Legacy 2
https://youtu.be/uiV0oo7ZlH8


Half Life Alyx fan expansion
https://twitter.com/CoreyLaddo/status/1510663426086948870?s=20&t=4QxZax_ruEzE9WciXusIVA

Halo Infinite multiplayer stuff Lone Wolves season 2 May 3
https://youtu.be/o69uckS2jlU

The Quarry gameplay
https://www.youtube.com/watch?v=70crU8_6z0U

Ubisoft Breakpoint 
https://www.gamesindustry.biz/articles/2022-04-06-ubisoft-ends-ghost-recon-breakpoint-development-working-on-nfts-for-other-titles
https://www.theverge.com/2022/4/6/23013346/ubisoft-ghost-recon-breakpoint-content-nft-digits-quartz

## 10 Overlooked Mechanics In Spider-Man That'll Get You Playing Again
 - [https://www.youtube.com/watch?v=TR3JixGEB4k](https://www.youtube.com/watch?v=TR3JixGEB4k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-04-07 00:00:00+00:00

Insomniac's Spider-Man (PS4, PS5) is filled with cool reasons to jump back in. Here are some of our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Top 15 NEW Horror Games of 2022
 - [https://www.youtube.com/watch?v=VVaWMKX3kmU](https://www.youtube.com/watch?v=VVaWMKX3kmU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-04-07 00:00:00+00:00

2022 is bringing tons of horror game experiences for PC, PS5, PS4, Xbox Series X/S/One, and Nintendo Switch.. Here's every horror game worth keeping an eye on.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro 
00:11 MADiSON 
00:49 Stray Souls 
1:49 Choo-Choo Charles 
2:49 Evil Nun: The Broken Mask 
3:29 The Quarry 
4:48 Martha is Dead 
5:25 Fobia St. Dinfna Hotel 
6:09 Scorn 
6:54 Evil Dead: The Game 
7:29 Slitterhead 
8:29 Sons of the Forest 
9:25 Ghostwire Tokyo 
10:13 The Outlast Trials 
10:49 The Callisto Protocol 
11:19 Dead Space Remake 
12:02 BONUS

#15 MADiSON 

Platform : PC 

Release Date : June 24, 2022 



#14 Stray Souls 

Platform : PC 

Release Date : TBA 



#13 Choo-Choo Charles 

Platform : PC 

Release Date : TBA 2022 



#12 Evil Nun: The Broken Mask 

Platform : PC 

Release Date : TBA 2022 



#11 The Quarry 

Platform : PC PS4 PS5 XSX|S Xbox One 

Release Date : June 10, 2022 




#10 Martha is Dead 

Platform : PC PS4 PS5 XSX|S Xbox One 

Release Date : February 24, 2022 



#9 Fobia St. Dinfna Hotel 

Platform : PC 

Release Date : TBA 



#8 Scorn 

Platform : PC XSX|S 

Release Date : October 2022 



#7 Evil Dead: The Game 

Platform : PC PS4 PS5 XSX|S Xbox One Switch 

Release Date : May 13, 2022 



#6 Slitterhead 

Platform : TBA 

Release Date : TBA 



#5 Sons of the Forest 

Platform : PC 

Release Date : 20 May 2022 



#4 Ghostwire Tokyo 

Platform : PC PS5 

Release Date : March 25, 2022 



#3 The Outlast Trials 

Platform : PC 

Release Date : 2022 



#2 The Callisto Protocol 

Platform : PC PS5 XSX|S 

Release Date : 2022



#1 Dead Space Remake 

Platform : PC PS5 XSX|S

Release Date : Q4 2022 



BONUS

Dying Light 2: Stay Human 

Platform : PC PS4 PS5 XSX|S Xbox One February 4, 2022

Release Date : Switch  Q2 2022 



S.T.A.L.K.E.R. 2: Heart of Chernobyl 

Platform : PC XSX|S 

Release Date : Def delayed to 2023 



The Texas Chainsaw Massacre 

Platform : TBA 

Release Date : 2022 



The Dark Pictures Anthology: The Devil in Me 

Platform : PC PS4 PS5 XSX|S Xbox One 

Release Date : TBA 



Wronged Us 

Platform : PC 

Release Date : Probably 2023 



Ill 

Platform : TBA 

Release Date : Probably 2023


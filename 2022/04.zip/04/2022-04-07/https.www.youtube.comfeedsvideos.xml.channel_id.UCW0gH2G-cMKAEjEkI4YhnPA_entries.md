# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Mace of Sauron, Red Eye Edition United Cutlery UC3520 | Lord of the Rings Collectibles Review
 - [https://www.youtube.com/watch?v=GBNnauUw2Go](https://www.youtube.com/watch?v=GBNnauUw2Go)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-04-07 00:00:00+00:00

It's my first ever villain weapon- the Mace of Sauron!  This iconic weapon includes a couple bonus items - a War Banner featuring the Eye of Sauron and The One Ring itself!  Weighing in at nearly 15 pounds, this is hefty and brutal weapon, worthy of the Dark Lord!

Check out this and other Middle-earth United Cutlery products here!: https://bit.ly/3CPvvow

Official Description:
A replica of the massive mace wielded by the Dark Lord Sauron in the prologue of The Lord of the Rings: The Fellowship of the Ring. When Sauron's forces battled the Last Alliance of Elves and Men on the slopes of Mount Doom, Sauron emerged on the battlefield wearing blackened steel armor. In one iron gauntlet he held a massive six-bladed, black iron war mace. On one finger he wore the source of his power, The One Ring. With every swing of this terrible weapon Sauron crushed his foes, sending intimidation and fear throughout the ranks of all who would stand against him. This replica of the actor scale prop used in the movie is crafted of reinforced fiberglass-resin with an aged iron finish. Close attention to detail is a top priority in every piece, down to the intaglio-etched surface and corroded metal coloring. The oversized One Ring worn by Sauron is also included, crafted in gold plated solid metal. Displays on a polystone wall mount (mounting hardware and instructions included). Also included is a 53” in overall length, cloth war banner with the Red Eye of Sauron.

While this was sent to me by a vendor, I was under no obligation to give this item a positive review.  Any praise/criticism in my reviews is my genuine opinion/thoughts.  If you are surprised that I really enjoy a LOTR piece of memorabilia, you really shouldn't be. :)

#lordoftherings #unboxing #lotr


# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## Can Life Really Be Explained By Physics? (featuring Prof. Brian Cox)
 - [https://www.youtube.com/watch?v=k-vm3ZWnMWk](https://www.youtube.com/watch?v=k-vm3ZWnMWk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2022-04-08 00:00:00+00:00

Thank you to Policygenius for supporting PBS. To learn more go to https://Policygenius.com/BeSmart 
Go clubbing in virtual reality with Subcultured @pbsvoices: https://youtu.be/ZRPjgSrQ8gA 
↓↓↓ More info and sources below ↓↓↓

I recently got to sit down with physicist and science communicator extraordinaire Prof. Brian Cox. Did we talk about black holes, the Big Bang, or alien worlds? Nope! We talked about biology. Specifically, what is “life” and how did it begin? You might not expect it, but looking at life through the lens of physics can teach us a lot about why interesting groups of atoms like you and me exist.

Learn more about Professor Brian Cox here:
https://twitter.com/ProfBrianCox 
https://www.instagram.com/profbriancox/ 
https://www.facebook.com/ProfessorBrianCox 

ATP Synthase animations by Drew Berry (wehi.tv) courtesy of HHMI Biointeractive and WEHI

-----------

Special thanks to our Brain Trust Patrons:

Ali Freiburger
Amy Sowada
Attila Pix
Baerbel Winkler
Barbora Bei
Burt Humburg
Clinger-Hamilton Family
dani bowman
David Johnston
DeliciousKashmiri
Dustin
Eric Meer
Karen Haskell
Ken Board
Mehdi Damou
Robert Young
Roy Lasris
Salih Arslan

We’re on PATREON! Join the community https://www.patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/


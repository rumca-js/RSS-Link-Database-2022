# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## OnePlus becomes even weirder
 - [https://www.youtube.com/watch?v=Mkn-Onpqot8](https://www.youtube.com/watch?v=Mkn-Onpqot8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2022-04-08 00:00:00+00:00

This video was sponsorored by Curiositystream. Get the bundle with Nebula here: https://curiositystream.com/tfc

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► This video ◄◄◄  

This week we got more confusing OnePlus and OPPO phones, Microsoft announced a ton of new Windows 11 features like file explorer tabs, and Google had major security issues with the Play Store.

Episode 91

This video on Nebula: https://nebula.app/videos/the-friday-checkout-how-is-this-not-a-oneplus-phone
Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd 
Quiz: https://link.crrowd.com/quiz

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support my work directly:  https://flattr.com/@techaltar   

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:27 Release highlights
1:45 OnePlus - more confusion
3:31 Windows 11 - new features
4:50 Google Play - security issues


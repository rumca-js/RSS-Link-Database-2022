# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Ambulance - Movie Review
 - [https://www.youtube.com/watch?v=SwsQigvVR8o](https://www.youtube.com/watch?v=SwsQigvVR8o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-04-08 00:00:00+00:00

Michael Bay gives us a 2 hour chase sequence. Here's my review of AMBULANCE!

#Ambulance #AmbulanceMovie

## Moon Knight - Episodes 1 & 2 (My Thoughts)
 - [https://www.youtube.com/watch?v=GShELz_ZmEc](https://www.youtube.com/watch?v=GShELz_ZmEc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-04-07 00:00:00+00:00

Thank you Displate for sponsoring!
Click here for 26% off 1 or 2 prints, and 36% off 3 or more prints for a limited time! https://displate.com/jeremyjahns?art=624726cc42ac1

The first 2 episodes of MOON KNIGHT have aired, so here are my thoughts on this possibly refreshing spin on MCU material!

#MoonKnight


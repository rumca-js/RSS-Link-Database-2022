# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Mystery of alleged Chinese hack on eve of Ukraine invasion
 - [https://www.bbc.co.uk/news/technology-60983346?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-60983346?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-04-07 17:39:47+00:00

A western intelligence official believes the aim was espionage - but questions remain.

## Ronin Network bailed out by crypto giant Binance after hack
 - [https://www.bbc.co.uk/news/technology-61023381?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-61023381?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-04-07 15:24:20+00:00

Hacked cryptocurrency and games company says its customers will now be reimbursed.

## Nano ink solar cells allow tech to charge in any light
 - [https://www.bbc.co.uk/news/technology-61025430?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-61025430?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-04-07 13:53:59+00:00

Custom nano inks allow solar cells to be made to any shape and can use ambient light to power devices.

## Cuddly toy reviews used for headphones on Amazon
 - [https://www.bbc.co.uk/news/technology-61009406?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-61009406?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-04-07 01:59:27+00:00

Sellers are boosting ratings of electronics with reviews for completely different products, Which? finds.


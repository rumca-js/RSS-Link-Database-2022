# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Will Smith - This Goes Deeper Than You Thought
 - [https://www.youtube.com/watch?v=l8gauWZpIsQ](https://www.youtube.com/watch?v=l8gauWZpIsQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-04-08 00:00:00+00:00

Will Smith has resigned from the Academy after slapping Chris Rock at the Oscars – but why are people still talking about it and what is this latest culture war distracting us from? #WillSmith #Oscars #CultureWar

References
Rise and Fall of the Neoliberal Order By Gary Gerstle

https://unusualwhales.com/

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Elon Musk vs Twitter - What Does This Mean?
 - [https://www.youtube.com/watch?v=BIiEdCbz9gg](https://www.youtube.com/watch?v=BIiEdCbz9gg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-04-07 00:00:00+00:00

Elon Musk is now Twitter’s biggest shareholder – so will the platform become a vessel for free speech or continue to protect powerful interests? #ElonMusk #Twitter #Trump

References
https://www.theguardian.com/technology/2022/apr/05/elon-musk-join-twitter-board-stake-tesla-spacex
https://www.theguardian.com/technology/2022/apr/06/twitter-working-on-edit-button-but-says-idea-did-not-come-from-elon-musk
https://reclaimthenet.org/twitters-autoblock-blocking-pelosi-tweets/
https://mashable.com/article/twitter-autoblock-nancy-pelosi-healthcare-activist
https://www.foxbusiness.com/media/new-twitter-ceo-parag-agrawal-company-first-amendment

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


## Almost $8M of 'Freedom Convoy' donations still unaccounted for, documents show | CBC News
 - [https://www.cbc.ca/news/canada/ottawa/freedom-convoy-donations-1.6410105](https://www.cbc.ca/news/canada/ottawa/freedom-convoy-donations-1.6410105)
 - RSS feed: https://www.cbc.ca
 - date published: 2022-04-07 08:33:50+00:00

Almost $8M of 'Freedom Convoy' donations still unaccounted for, documents show | CBC News


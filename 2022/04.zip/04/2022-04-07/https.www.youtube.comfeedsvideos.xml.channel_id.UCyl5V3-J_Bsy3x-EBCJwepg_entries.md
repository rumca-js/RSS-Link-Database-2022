# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## The Bee Weekly: Twitter Changes and The New Bee Book on Democracy
 - [https://www.youtube.com/watch?v=Ni3h4SySoWk](https://www.youtube.com/watch?v=Ni3h4SySoWk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-04-08 00:00:00+00:00

It’s another week at the Bee and you can use our special link for 83% off Private Internet Access!:  https://privateinternetaccess.com/TheBabylonBee

Kyle and Adam are joined by Jarret to discuss the big new shareholder of Twitter. Didn’t you get the memo? The Bee is also releasing a brand new book! Enjoy a sneak peak of The Babylon Bee Guide To Democracy!

You can pre-order The Babylon Bee Guide To Democracy now!: https://www.amazon.com/Babylon-Bee-Guide-Democracy-Guides/dp/1684513723/ref=sr_1_7?keywords=the+babylon+bee+guide+to+wokeness&qid=1649198151&sprefix=the+babylon+bee+g%2Caps%2C117&sr=8-7

Stay a while and listen to new editions of Bee Radio w/ Austin “The Robinson” Robertson, Weakly News w/ Adam Yenser, and a brand new segment: Sizzler Facts. Listeners also get an exclusive leak of the audition tapes from some ambitious people who want Jen Psaki’s job.

In the subscriber’s lounge we hang out with world-famous Bee Subscriber JungleBiker. Will he answer the ten questions? Only you can find out!

This episode is brought to you by Strikeman Laser Dry Fire Training System. Ammo is expensive, but with a laser dry fire training system from Strikeman you can still train to become proficient in the safe and accurate use of your weapon. Use promo code AMMOFREEDOM to save 20% off at: http://TRAINWITHSTRIKEMAN.COM

This episode is also brought to you by MY PATRIOT SUPPLY. Don’t be unprepared when disaster strikes. Save $150 on a three month emergency food kit at: http://PrepareWithBee.com

## Cracker Jack Changes Name To Less Offensive Caucasian Jack
 - [https://www.youtube.com/watch?v=nCP2jVHB1Jw](https://www.youtube.com/watch?v=nCP2jVHB1Jw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-04-07 00:00:00+00:00

Cracker Jack has changed its name to Cracker Jill. No, wait -- it's Caucasian Jack. Wait. Caucasian Jill. No, it's White Jill! We talk to Frito-Lay to find out what name they finally decide on.

Follow Chandler's Youtube: https://www.YouTube.com/chandlerjuliet

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


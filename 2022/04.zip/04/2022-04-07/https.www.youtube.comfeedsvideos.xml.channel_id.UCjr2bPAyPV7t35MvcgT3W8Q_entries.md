# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## YouTube Has Blacklisted My Channel
 - [https://www.youtube.com/watch?v=IZZ59HOdAbI](https://www.youtube.com/watch?v=IZZ59HOdAbI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2022-04-07 17:06:33+00:00

YouTube is refusing to suggest my content to my subscribers and wider audiences. This can't go on. If you value my videos, please support my independent work on: https://www.patreon.com/thehatedone 

I have never trusted YouTube. I have always considered it a necessary evil for this channel. YouTube search function is used more often than any other search engine except for Google itself. 
YouTube is unavoidable. And this happened because YouTube used to be better than the alternative – the cable TV. 

Today, YouTube has been corrupted and commercialized to the point it’s becoming worse than TV. All videos are riddled with ads and half of those videos are ads themselves. Either sponsored, or affiliated, creators looking for ways to make easy money online. 

YouTube is a multi-tier system. 

You see, if you want to make it big on YouTube, you have to play by the rules written by the algorithm. Because MrBeast’s formula is so successful, every channel now has to emulate it. Whether it fits the content or not. 

The algorithm learned this is the only content that works right now. So every YouTuber under the sun is doing it. There is no integrity. Every YouTube video now has to be a shocking and outrageous clickbait. 
The dick-sucking facial expressions are totally ubiquitous now.  An anecdotal evidence: Here’s a personal finance channel that adopted the cock-throating technique and gets tons of views because of it.
Here’s another personal finance channel that didn’t adopt the technique and didn’t get the views because of it.
The line between entertainment and education is gone. It has been erased by the YouTube algorithm. Every video has to be a sensation. Anything short of that will fail.

On average, I dedicate anywhere between 5 – 10 hours of work for every minute of my videos. 5 – 10 hours of extensive research, scripting, recording and editing. Most of my videos barely earn $100 or $200. I let you do that math.

So small creators cannot rely on YouTube ads for their revenue. That’s nothing new. Just take sponsorship money and sign up for affiliate programs.  But that’s the problem with over-commercialization of Internet content. Just consider what my content is. 

A lot of my videos are recommending tools and services for people to use to protect their anonymity, privacy and security. In many cases, their safety and even lives may depend on the integrity of this information. Signing up for commercial services means now I’d have to craft my recommendations around the profit incentive of my sponsors. Which is exactly what’s happening to creators that fall down this route. 

Now they will tell you that corporate influence is not tainting their recommendations. But unless they are inhumanely immune to incentives, that’s just not the case. 
Would you trust a journalist that takes money from big oil to talk about a war in the Middle East? Or the energy industry? You wouldn’t. So why is it okay for YouTubers to take money from companies they are supposed to be the most critical of? 

If I want to criticize the big tech, government surveillance and failure of authority; if I want to make recommendations on what people should do to protect themselves from unjust overreach by corporations and states, then viewers should be the ones that hold me accountable. 
YouTube is killing my channel. So what are my choices? 

Right now I only have about a 170 patrons. That’s not enough to cover a professional editor for high quality video production. But with 500 patrons, I could hire a part-time editor to not only increase the quality of my videos but also make them more frequently. With 1,000 patrons, I could go out into the field  with a small crew and produce full-length documentary features. This is the ultimate goal of this channel. 

This is the only solution I can make peace with. It’s when you, my audience, step up to produce my content. You can sign up for my Patreon-only podcast with a private RSS feed to listen to up to two episodes a week. 

If you stick with me for three months or longer, you’ll be sent a piece of merch designed by me as form of gratitude for your loyalty. Currently I make stickers, mugs, hoodies and shirts. 
I am even considering experimenting with Briar and Cwtch for group chats and forums for my highest tier Patrons. 

So this is my special plea to all of you. If you want this content to exist, if you want me to keep making more videos, become a producer of The Hated One channel. Become my patron at patreon.com/thehatedone
The fate of this channel is in your hands. 

Credits
Music by: White Bat Audio: https://www.youtube.com/c/WhiteBatAudio

Follow me:
https://twitter.com/The_HatedOne_
https://www.reddit.com/r/thehatedone/

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.


# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Louis has meltdown
 - [https://www.youtube.com/watch?v=UUThdBfy_-U](https://www.youtube.com/watch?v=UUThdBfy_-U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-04-08 00:00:00+00:00

👉 https://tinyurl.com/rossmatrix
👉 https://youtu.be/FBR8IvXVwsE?t=1822
👉 https://www.cta.tech/Membership/Our-Members
👉 https://members.cta.tech/cta-member-directory?reload=timezone
👉 https://www.youtube.com/watch?v=xt3YSD36ZNc
👉 https://www.reddit.com/r/samsung/comments/tyepqa/samsung_now_installs_tiktok_as_an_essential_app/
👉 https://www.reddit.com/r/assholedesign/comments/tsiytu/i_cant_not_install_tiktok_on_a_new_samsung/
👉 https://www.youtube.com/watch?v=8GQms75Wl7U

🔵 Desk: https://amzn.to/3njMvN3
🔵 Chair: https://amzn.to/3zOuSdf
🔵 Microphone: https://amzn.to/3JZ2rOy
🔵 Camera: https://amzn.to/3CTk1Av

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## You will subscribe instead of own and you will like it!
 - [https://www.youtube.com/watch?v=zp19zbiuKTk](https://www.youtube.com/watch?v=zp19zbiuKTk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-04-08 00:00:00+00:00

👉 https://tinyurl.com/rossmatrix
👉 https://official-rossmann-merch.creator-spring.com/listing/you-ll-own-everything
👉 https://www.youtube.com/clip/UgkxvPw5y3IJsu7X3adIkHco62dHS4k1vmCt
🔵 Desk: https://amzn.to/3njMvN3
🔵 Chair: https://amzn.to/3zOuSdf
🔵 Microphone: https://amzn.to/3JZ2rOy
🔵 Camera: https://amzn.to/3CTk1Av

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## Zero motorcycle followup: a rot on the culture of ownership & repair
 - [https://www.youtube.com/watch?v=_NMx5NYOiyA](https://www.youtube.com/watch?v=_NMx5NYOiyA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-04-07 00:00:00+00:00

https://www.youtube.com/watch?v=FS5Df4UBMsM
https://youtu.be/oZtXKHo6vKs

👉 https://tinyurl.com/rossmatrix
👉 https://www.zeromotorcycles.com/cypherstore
👉 https://sur-ronusa.com/
👉 https://youtu.be/Z50cSlMdS2Y
👉 https://fighttorepair.org

🔵 Desk: https://amzn.to/3njMvN3
🔵 Chair: https://amzn.to/3zOuSdf
🔵 Microphone: https://amzn.to/3JZ2rOy
🔵 Camera: https://amzn.to/3CTk1Av

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ


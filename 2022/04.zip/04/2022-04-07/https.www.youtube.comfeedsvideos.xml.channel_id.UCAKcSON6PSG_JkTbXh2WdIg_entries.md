# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Wet Leg live concert at First Avenue - March 3, 2022 (full performance from The Current)
 - [https://www.youtube.com/watch?v=KhrJKasTbjw](https://www.youtube.com/watch?v=KhrJKasTbjw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-04-08 00:00:00+00:00

Isle of Wight duo Wet Leg hit the stage at First Avenue on March 3, 2022, ahead of their debut self-titled album due out April 8, 2022 on Domino Records.

Songs Played
00:00 Being in Love
02:20 Convincing
05:01 Wet Dream
07:18 Supermarket
11:02 Red Eggs
14:26 Too Late Now
19:19 Obvious
23:10 Oh No
25:51 Loving You
28:40 Ur Mum
33:25 It's a Shame
37:15 It's Not Fun
40:19 Angelica
45:00 Chaise Longue

Band members:
Rhian Teasdale – vocals/guitar
Hester Chambers – guitar/vocals
Ellis-James Durant – bass
Joshua Mobaraki – keys/guitar
Henry Holmes – drums

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits: 
Video Director, Color Grading - Eric Xu Romani
The Current Production Manager, Video Editor - Erik Stromstad
Show Lighting Designer - Paul Guthrie
Camera Operators - Erik Stromstad, Eric Xu Romani, Tom Campbell, Peter Ecklund
Audio Recording & Mixing - Evan Clark
Producers - Jesse Wiza, Derrick Stevens

Wet Leg
Rhian Teasdale – vocals/guitar
Hester Chambers – guitar/vocals
Ellis-James Durant – bass
Joshua Mobaraki – keys/guitar
Henry Holmes – drums

## Calexico's Joey Burns on losing yourself in art & writing 'El Mirador' (interview with The Current)
 - [https://www.youtube.com/watch?v=rKgolfTxDhM](https://www.youtube.com/watch?v=rKgolfTxDhM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-04-07 00:00:00+00:00

Calexico's Joey Burns joins Mary Lucia to discuss house shoes, losing yourself in writing lyrics, and the influences that shaped their upcoming record, 'El Mirador'.

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits: 
Guest - Joey Burns
Host - Mary Lucia
Producers - Jesse Wiza, Derrick Stevens
Technical Director - Erik Stromstad


## You can do a lot with an empty file
 - [https://rachelbythebay.com/w/2022/04/06/text/](https://rachelbythebay.com/w/2022/04/06/text/)
 - RSS feed: https://rachelbythebay.com
 - date published: 2022-04-07 09:40:07.434362+00:00




## Twitter Edits You
 - [http://www.kevinmarks.com/twittereditsyou.html](http://www.kevinmarks.com/twittereditsyou.html)
 - RSS feed: http://www.kevinmarks.com
 - date published: 2022-04-07 07:44:17.399090+00:00

With all the fuss about Twitter’s promised edit button, and how they might design it, we’re missing a disturbing development — Twitter is using its embedded javascript to edit other people’s sites.


# Source:Cercle, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ, language:en-US

## Bedouin live at Petra, Jordan for Cercle
 - [https://www.youtube.com/watch?v=xQCLf9T_M7Q](https://www.youtube.com/watch?v=xQCLf9T_M7Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ
 - date published: 2022-04-07 14:00:46+00:00

Bedouin playing an exclusive hybrid live set at Al-Khazneh (the Treasury) in Petra, Jordan, for Cercle.

☞ Support us and get access to exclusive videos & perks: https://Cercle.lnk.to/Patreon
☞ Listen to our playlists, tracks & sets: https://Cercle.lnk.to/Playlists
☞ Subscribe to our newsletter to know about our next shows: https://Cercle.lnk.to/Members
☞ Subscribe to our YouTube channel: https://Cercle.lnk.to/ytcercle

☞ Cercle Records 
Bedouin - Petra: https://Cercle.lnk.to/petrabedouin

☞  Bedouin
https://www.instagram.com/bedouin_official/
https://open.spotify.com/artist/5bKdC6382t97Qnpvs81Rqx
https://music.apple.com/fr/artist/bedouin/466912252

30°19'20.0"N 35°27'07.0"E

Video credits:

Artist: Bedouin
Venue: The Treasury, in Petra, Jordan 
Produced by Cercle
Executive producers: Derek Barbolla & Philippe Tuchmann
Film directed by: Pol Souchier & Derek Barbolla
Director of photography:  Mathieu Glissant
Cameramen: Mickaël Fidjili & Mathieu Glissant
Drone pilot: Alexis Olas & Jérémie Tridard
FPV drone: Filip Petronijević
Sound mastering: Laurent de Boisgisson
Production team: Anaïs De Framond, Dan Aufseesser, Armand Prouhèze
Communication: Pol Souchier, Lola Lebrati and Emie Monnier
Graphic Design: Anaëlle Rouquette
Label Assistant: Clémence Maillard
Technical Manager: Aurélien Moisan
Chief Financial Officer: Andy Cheremond
Post-production: Mathieu Glissant (Saison Unique Production)
Photographer: Marko Edge
______

Official partners: 
W Hotels
W Amman
Fuzz Events
Jordan Tourism Board
______

Special thanks to:
Husni Khuffash 
Alaa Al-Hindi
Carly Van Sickle
Joël Barbeau
Julia Fugazy
Amjad Audat
Christine Espinoza
Kathryn Flexner
Feras Oweis
Alexandra Marin
Fayez Burgan
Nader Alshakhatreh
Chik Mania Production
Mahmoud Zidan

______

This artistic performance has been recorded live.
Tracklist:

00:00:00 INTRO
00:02:00 DakhaBrakha - Svyryd (Bedouin rework)
00:08:20 Little Junior Parker - Tomorrow Never Knows (Bedouin Private Remix)
00:15:12 Bedouin - Tijuana
00:21:38 Bedouin - Shared Delusion
00:26:23 Bedouin - Petra (Original Mix)
00:32:37 Guy Laliberté, Soul Of Zoo – Into Your Tribe ft. The Frog Collective (Bedouin Remix) UNRELEASED
00:38:45 Bedouin - Aliens 
00:44:30 Bedouin - Khazna
00:51:08 DakhaBrakha - Doshchynk Nakrapai (Bedouin Rework)
00:58:39 Bedouin - Love and Hate
01:04:10 Bedouin - Indecision  
01:08:47 Bedouin - Firefly
01:14:44 Bobby McFerrin - Improvisacio 1 (Bedouin Private Remix) 
01:20:35 Bedouin - Set The Controls For The Heart Of The Sun (Original Mix)
01:35:19 Interview

______

Follow us on http://www.cercle.io


# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Wait, this is a Mandela Effect?!
 - [https://www.youtube.com/watch?v=BwzzOvPz7zQ](https://www.youtube.com/watch?v=BwzzOvPz7zQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2022-04-07 00:00:00+00:00

I was shocked when I found out... but also not because it's a sketch that I wrote... sign up for my Patreon so I can keep making videos and subscribe you weirdos: https://www.patreon.com/julienolke

Writer: Julie Nolke
Actors: Julie Nolke
Camera: Sam Larson
Editor: Alec McKay

FYI: The Mandela effect is when many people believe that something happened when, in reality, it never did. These groups are adamant that they can remember an incident or specific experience, even when it is demonstrably incorrect. 

In 2010, this phenomenon was dubbed the "Mandela Effect" by paranormal researcher Fiona Broome, who reported having vivid and detailed memories of news coverage of South African anti-Apartheid leader Nelson Mandela dying in prison in the 1980s. (Mandela actually died in 2013, after serving as President of South Africa from 1994 to 1999.) Broome reported that "perhaps thousands" of other people had the same memory of Mandela's death, and speculated that the phenomenon could be evidence of parallel realities.

Other examples include memories of the title of the Berenstain Bears children's books being spelled Berenstein or the logo of clothing brand Fruit of the Loom featuring a cornucopia. 

#sketch #comedy


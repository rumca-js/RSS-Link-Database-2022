# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Daria Zawiałow - koncert (MUZO.FM)
 - [https://www.youtube.com/watch?v=wca1j3ZAFjw](https://www.youtube.com/watch?v=wca1j3ZAFjw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2022-04-07 00:00:00+00:00

Daria Zawiałow na żywo w MUZO.FM. Artystka wykonała w naszym studiu wyjątkowe wersje kawałków: Za krótki sen, Żółta taksówka, Reflektory-Sny z płyty Wojny i noce oraz i Gdybym miała serce z albumu Helsinki. 

0:00 Za krótki sen
3:53 Żółta Taksówka
8:01 Reflektory - Sny
12:34 Gdybym Miała Serce

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Daria Zawiałow: http://www.facebook.com/dariazawialow
Instagram Daria Zawiałow: http://www.instagram.com/zavialovd
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


Skład:
Daria Zawiałow
Michał Kush
Piotr Rubik
Justyna Jarzębińska 
Marta Podobas

Mix i mastering: Marek Heimbürger w SL SOUND Studio

#popolsku


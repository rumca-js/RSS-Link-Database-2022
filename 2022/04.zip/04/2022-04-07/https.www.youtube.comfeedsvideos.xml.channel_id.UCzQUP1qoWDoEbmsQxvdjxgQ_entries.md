# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Did Nancy Pelosi's Husband Buy Tesla Stock Ahead of Electric Car Mandate?
 - [https://www.youtube.com/watch?v=zR38s5zKvEA](https://www.youtube.com/watch?v=zR38s5zKvEA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-04-08 00:00:00+00:00

Taken from JRE #1803 w/Greg Fitzsimmons:
https://open.spotify.com/episode/1pKkrYyWHsuI9y4ILwEu2y?si=60c6dad15cb64a58

## Joe on Elon Musk Being on the Board at Twitter
 - [https://www.youtube.com/watch?v=f0n7YI7jK1c](https://www.youtube.com/watch?v=f0n7YI7jK1c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-04-08 00:00:00+00:00

Taken from JRE #1803 w/Greg Fitzsimmons:
https://open.spotify.com/episode/1pKkrYyWHsuI9y4ILwEu2y?si=60c6dad15cb64a58

## Logan Paul at WrestleMania & Jake Paul's Tyron Woodley KO
 - [https://www.youtube.com/watch?v=XsFpPVWwbd0](https://www.youtube.com/watch?v=XsFpPVWwbd0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-04-08 00:00:00+00:00

Taken from JRE #1802 - Protect Our Parks 3:
https://open.spotify.com/episode/0HTyZfvJbXQbw5xRRTCDAJ?si=deea56345034497a

## R. Kelly is Singing for People in Jail
 - [https://www.youtube.com/watch?v=dihq18cp98s](https://www.youtube.com/watch?v=dihq18cp98s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-04-08 00:00:00+00:00

Taken from JRE #1802 - Protect Our Parks 3:
https://open.spotify.com/episode/0HTyZfvJbXQbw5xRRTCDAJ?si=deea56345034497a


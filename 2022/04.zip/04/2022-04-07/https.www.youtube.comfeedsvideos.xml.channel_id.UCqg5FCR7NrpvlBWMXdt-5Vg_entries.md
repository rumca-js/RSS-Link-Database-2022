# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Abermore | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=CzOf3dwnqy8](https://www.youtube.com/watch?v=CzOf3dwnqy8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-04-08 00:00:00+00:00

Elise Avery reviews Abermore, developed by Four Circle Interactive.

Abermore on Steam: https://store.steampowered.com/app/1569220/Abermore/

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Elden Ring's Stormveil Castle is the Game's True Tutorial
 - [https://www.youtube.com/watch?v=33B3yw2EHPs](https://www.youtube.com/watch?v=33B3yw2EHPs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-04-08 00:00:00+00:00

In today's episode of Anatomy, JM8 dissects the design ups and downs of Elden Rings first legacy dungeon Stormveil Castle.

If you want to see more game design content a new Anatomy episode will release every other week, or you can subscribe to JM8s personal channel for similar content: https://www.youtube.com/c/JM8GameDesign

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## LEGO Star Wars: The Skywalker Saga | Today We Play with Nick and Marty
 - [https://www.youtube.com/watch?v=c1CQW8Zoum4](https://www.youtube.com/watch?v=c1CQW8Zoum4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-04-07 00:00:00+00:00

This episode of Today We Play is brought to you by Ekster. Use our affiliate link to get 20% off your next smart wallet purchase. https://shop.ekster.com/theescapistmagazine

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Why Was Prey (2017) So Forgettable? | Extra Punctuation
 - [https://www.youtube.com/watch?v=UAYYN_tus10](https://www.youtube.com/watch?v=UAYYN_tus10)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-04-07 00:00:00+00:00

This episode of Extra Punctuation is brought to you by Ekster. Use our affiliate link to get 20% off your next smart wallet purchase. https://shop.ekster.com/theescapistmagazine

This week on Extra Punctuation, Yahtzee discusses why the 2017 Prey video game from Arkane Studios was so forgettable.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#ExtraPunctuation


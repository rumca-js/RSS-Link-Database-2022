# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Arlo Parks - Black Dog (Live on KEXP)
 - [https://www.youtube.com/watch?v=-HVWig1Dx4g](https://www.youtube.com/watch?v=-HVWig1Dx4g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-08 00:00:00+00:00

http://KEXP.ORG presents Arlo Parks performing “Black Dog” live in the KEXP studio. Recorded March 23, 2022.

Arlo Parks - Vocals
Madeleine Jones - Keyboards
Daniele Diodato - Guitar
Sam Harding - Bass
James Fernandez - Drums

Host: Larry Mizell, Jr.
Audio Engineers: Chris Miller, Chris Parker & Kevin Suggs
Audio Mixer: Mike Hill
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Ettie Wahl
Editor: Jim Beckmann

https://www.arloparksofficial.com
http://kexp.org

## Arlo Parks - Eugene (Live on KEXP)
 - [https://www.youtube.com/watch?v=60YhmU8oLz8](https://www.youtube.com/watch?v=60YhmU8oLz8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-08 00:00:00+00:00

http://KEXP.ORG presents Arlo Parks performing “Eugene” live in the KEXP studio. Recorded March 23, 2022.

Arlo Parks - Vocals
Madeleine Jones - Keyboards
Daniele Diodato - Guitar
Sam Harding - Bass
James Fernandez - Drums

Host: Larry Mizell, Jr.
Audio Engineers: Chris Miller, Chris Parker & Kevin Suggs
Audio Mixer: Mike Hill
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Ettie Wahl
Editor: Jim Beckmann

https://www.arloparksofficial.com
http://kexp.org

## Arlo Parks - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=WD5MFKh0vBM](https://www.youtube.com/watch?v=WD5MFKh0vBM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-08 00:00:00+00:00

http://KEXP.ORG presents Arlo Parks performing live in the KEXP studio. Recorded March 23, 2022.

Songs:
Eugene
Black Dog
Softly
Hope

Arlo Parks - Vocals
Madeleine Jones - Keyboards
Daniele Diodato - Guitar
Sam Harding - Bass
James Fernandez - Drums

Host: Larry Mizell, Jr.
Audio Engineers: Chris Miller, Chris Parker & Kevin Suggs
Audio Mixer: Mike Hill
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Ettie Wahl
Editor: Jim Beckmann

https://www.arloparksofficial.com
http://kexp.org

## Arlo Parks - Hope (Live on KEXP)
 - [https://www.youtube.com/watch?v=crLQg8K0jUw](https://www.youtube.com/watch?v=crLQg8K0jUw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-08 00:00:00+00:00

http://KEXP.ORG presents Arlo Parks performing “Hope” live in the KEXP studio. Recorded March 23, 2022.

Arlo Parks - Vocals
Madeleine Jones - Keyboards
Daniele Diodato - Guitar
Sam Harding - Bass
James Fernandez - Drums

Host: Larry Mizell, Jr.
Audio Engineers: Chris Miller, Chris Parker & Kevin Suggs
Audio Mixer: Mike Hill
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Ettie Wahl
Editor: Jim Beckmann

https://www.arloparksofficial.com
http://kexp.org

## Arlo Parks - Softly (Live on KEXP)
 - [https://www.youtube.com/watch?v=iXLeTuMk0j8](https://www.youtube.com/watch?v=iXLeTuMk0j8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-08 00:00:00+00:00

http://KEXP.ORG presents Arlo Parks performing “Softly” live in the KEXP studio. Recorded March 23, 2022.

Arlo Parks - Vocals
Madeleine Jones - Keyboards
Daniele Diodato - Guitar
Sam Harding - Bass
James Fernandez - Drums

Host: Larry Mizell, Jr.
Audio Engineers: Chris Miller, Chris Parker & Kevin Suggs
Audio Mixer: Mike Hill
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Ettie Wahl
Editor: Jim Beckmann

https://www.arloparksofficial.com
http://kexp.org


# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Superchunk - Endless Summer (Live on KEXP)
 - [https://www.youtube.com/watch?v=8HGfkhElxVM](https://www.youtube.com/watch?v=8HGfkhElxVM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-25 00:00:00+00:00

http://KEXP.ORG presents Superchunk performing “Endless Summer” live in the KEXP studio. Recorded April 4, 2022.

Mac McCaughan - Guitar / Vocals
Jason Narducy - Bass / Vocals
Jim Wilbur - Guitar
Jon Wurster - Drums

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro & Carlos Cruz
Editor: Carlos Cruz

http://superchunk.com
http://kexp.org/

## Superchunk - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=0qjx3JNvlMI](https://www.youtube.com/watch?v=0qjx3JNvlMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-25 00:00:00+00:00

http://KEXP.ORG presents Superchunk performing live in the KEXP studio. Recorded April 4, 2022.

Songs:
Wild Loneliness
Refracting
Endless Summer
Rainy Streets

Mac McCaughan - Guitar / Vocals
Jason Narducy - Bass / Vocals
Jim Wilbur - Guitar
Jon Wurster - Drums

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro & Carlos Cruz
Editor: Carlos Cruz

http://superchunk.com
http://kexp.org

## Superchunk - Rainy Streets (Live on KEXP)
 - [https://www.youtube.com/watch?v=mIfLJvdQRm0](https://www.youtube.com/watch?v=mIfLJvdQRm0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-25 00:00:00+00:00

http://KEXP.ORG presents Superchunk performing “Rainy Streets” live in the KEXP studio. Recorded April 4, 2022.

Mac McCaughan - Guitar / Vocals
Jason Narducy - Bass / Vocals
Jim Wilbur - Guitar
Jon Wurster - Drums

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro & Carlos Cruz
Editor: Carlos Cruz

http://superchunk.com
http://kexp.org

## Superchunk - Refracting (Live on KEXP)
 - [https://www.youtube.com/watch?v=mKsPHRPh3mA](https://www.youtube.com/watch?v=mKsPHRPh3mA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-25 00:00:00+00:00

http://KEXP.ORG presents Superchunk performing “Refracting" live in the KEXP studio. Recorded April 4, 2022.

Mac McCaughan - Guitar / Vocals
Jason Narducy - Bass / Vocals
Jim Wilbur - Guitar
Jon Wurster - Drums

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro & Carlos Cruz
Editor: Carlos Cruz

http://superchunk.com
http://kexp.org

## Superchunk - Wild Loneliness (Live on KEXP)
 - [https://www.youtube.com/watch?v=r0-rdrxQnKA](https://www.youtube.com/watch?v=r0-rdrxQnKA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-25 00:00:00+00:00

http://KEXP.ORG presents Superchunk performing “Wild Loneliness" live in the KEXP studio. Recorded April 4, 2022.

Mac McCaughan - Guitar / Vocals
Jason Narducy - Bass / Vocals
Jim Wilbur - Guitar
Jon Wurster - Drums

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro & Carlos Cruz
Editor: Carlos Cruz

http://superchunk.com
http://kexp.org


# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Autonomous Trucking - Where Exactly Are We? (And Other Questions) | Answers With Joe
 - [https://www.youtube.com/watch?v=B3hEP6igmOM](https://www.youtube.com/watch?v=B3hEP6igmOM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2022-04-25 00:00:00+00:00

Earn money for charity just by browsing the internet when you sign up for Tab For A Cause here: https://tab.gladly.io/joescott
With the current shortage of truckers, it makes you wonder what the state of autonomous trucking is right now. At least, it prompted one of my Patreon supporters to ask the question, and many others in today's lightning round video.


Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

You can listen to my podcast, Conversations With Joe on Spotify, Apple Podcasts, Google Podcasts, or wherever you get your podcasts.
Spotify 👉 https://spoti.fi/37iPGzF
Apple Podcasts 👉 https://apple.co/3j94kfq
Google Podcasts 👉 https://bit.ly/3qZCo1V

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

https://www.forbes.com/sites/alanohnsman/2016/10/25/this-buds-for-the-robot-otto-anheuser-busch-claim-first-automated-truck-shipment/?sh=12cecebc5615
https://www.wired.com/2016/10/ubers-self-driving-truck-makes-first-delivery-50000-beers/

https://ottomotors.com/

https://techcrunch.com/2021/12/29/tusimple-completes-its-first-driverless-autonomous-truck-run-on-public-roads/

https://www.forbes.com/sites/stevebanker/2021/05/11/the-autonomous-truck-revolution-is-right-around-the-corner/?sh=774b9f422c96

https://fortune.com/2022/04/07/autonomous-long-haul-trucking-to-transform-u-s-logistics/

https://phys.org/news/2022-03-bubble-through-nuclear-future-nasa-workhorse.html

Timestamps:
0:00 - Intro
1:59 - What type of microphone do I use?
2:23 - Did I take comedy classes?
4:18 - Autonomous trucks
8:15 - What TV show would I want to cameo on?
9:02 - What is one question I would ask my future self?
9:54 - Are Russians bad at poisoning people?
10:33 - Nuclear propulsion breakthrough
12:20 - Why do farts smell worse in water?


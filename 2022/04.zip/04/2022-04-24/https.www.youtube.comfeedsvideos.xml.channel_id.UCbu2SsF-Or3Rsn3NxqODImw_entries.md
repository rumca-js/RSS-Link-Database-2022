# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Apex Legends: Saviors - Official Cinematic Trailer
 - [https://www.youtube.com/watch?v=5ezttJANRCc](https://www.youtube.com/watch?v=5ezttJANRCc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-04-25 00:00:00+00:00

Check out what's coming next in Apex Legends with the reveal of Newcastle (Bangalore's brother Jackson), the next legend! Learn more in the coming days when the next Story from the Outlands drops as well on April 28th, 2022. 

#ApexLegends

## Dune Spice Wars Hands-on Preview
 - [https://www.youtube.com/watch?v=wBSdkSPDdWo](https://www.youtube.com/watch?v=wBSdkSPDdWo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-04-25 00:00:00+00:00

The 1965 sci-fi novel Dune is enduring for a lot reasons. It takes place in a world rife with political intrigue and fearsome spycraft, where trust is just as valuable as the spice found on the planet Arrakis. That makes Dune fertile ground for the 4X approach to strategy games--Shiro Games' Dune: Spice Wars tries to leverage these multitudes to give players a whole lot more to keep track of than just the enemy soldiers amassing on your borders.

## Elden Ring Demake For Game Boy Coming | GameSpot News
 - [https://www.youtube.com/watch?v=3iI_3rNyqV0](https://www.youtube.com/watch?v=3iI_3rNyqV0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-04-25 00:00:00+00:00

Elden Ring Is Being Demade For An Actual Game Boy, Infinity Ward Seemingly Teases Modern Warfare 2 and Diablo Immortal Release Date Confirmed. 

Reddit user Shintendo announced a demake of Elden Ring on the game’s subreddit and even posted a clip of the opening area and boss fight. Shintendo revealed they intend to show how they developed Elden Ring for actual Game Boy hardware on Twitch and archive it on their Youtube channel.

Infinity Ward's social media pages have gone dark in an apparent viral marketing campaign to promote this year's Call of Duty: Modern Warfare 2. Activision Blizzard management shared some additional morsels about both projects, confirming that Modern Warfare 2 is the "most advanced" entry in the series so far. Activision also boasted that Warzone 2, or whatever the new game is called, will feature "groundbreaking" innovations.

Diablo Immortal is set to launch on both iOS and Android on June 2. une 2 will also mark the beginning of an open beta test for the newly revealed PC version of the game, which will support full cross-progression with both iOS and Android.

STAMPS
00:00 - Intro
00:07 - Elden Ring
00:58 - Modern Warfare 2
02:05 - Diablo Immortal


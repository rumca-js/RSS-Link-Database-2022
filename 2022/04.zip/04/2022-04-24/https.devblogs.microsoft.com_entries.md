## Excuse me, has anybody seen the FOCAL interpreter? - The Old New Thing
 - [https://devblogs.microsoft.com/oldnewthing/20200616-00/?p=103869](https://devblogs.microsoft.com/oldnewthing/20200616-00/?p=103869)
 - RSS feed: https://devblogs.microsoft.com
 - date published: 2022-04-24 09:42:36.566282+00:00

I thought you had it.

## The Applesoft Compiler (TASC): We have the source code, in a sense - The Old New Thing
 - [https://devblogs.microsoft.com/oldnewthing/20220419-00/?p=106496](https://devblogs.microsoft.com/oldnewthing/20220419-00/?p=106496)
 - RSS feed: https://devblogs.microsoft.com
 - date published: 2022-04-24 09:41:49.892267+00:00

The desperation of programming under tight memory constraints.


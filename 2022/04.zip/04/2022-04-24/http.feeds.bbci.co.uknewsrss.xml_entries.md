# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Ethiopia's Lalibela struggles as war and Covid-19 keep tourists away
 - [https://www.bbc.co.uk/news/world-africa-61196572?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-61196572?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 23:03:27+00:00

In the historic Ethiopian town of Lalibela, civil war and Covid-19 have left many without livelihoods.

## MOTD2 analysis: Why Liverpool & Jurgen Klopp can rely on Divock Origi
 - [https://www.bbc.co.uk/sport/av/football/61211784?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/61211784?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 23:01:23+00:00

Match of the Day 2’s Mark Chapman, Micah Richards and Jermaine Jenas praise Liverpool's substitutes in their 2-0 Merseyside Derby win against Everton, particularly Divock Origi.

## The Olympic hopeful turned bike-riding bank robber
 - [https://www.bbc.co.uk/news/world-us-canada-61192215?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-61192215?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 23:01:23+00:00

When Tom Justice failed to make the Olympics he decided to use his cycling skills to rob banks instead.

## Ukraine roundup: No let up in fighting as Orthodox Easter marked
 - [https://www.bbc.co.uk/news/world-europe-61209764?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61209764?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 21:23:43+00:00

President Zelensky delivers a festive address and a blast survivor is targeted by false accusations.

## Julian Alaphilippe: World champion suffers multiple injuries in Liege-Bastogne-Liege crash
 - [https://www.bbc.co.uk/sport/cycling/61211810?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cycling/61211810?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 20:52:23+00:00

World champion Julian Alaphilippe suffers two broken ribs, a broken scapula and a collapsed lung after hitting a tree during Liege-Bastogne-Liege.

## Macron: I am president for everyone
 - [https://www.bbc.co.uk/news/world-europe-61211790?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61211790?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 20:24:35+00:00

After becoming the first French president re-elected in 20 years, Emmanuel Macron told supporters he was "the president of all."

## Odesa missile attack: 'My world was destroyed by a Russian missile'
 - [https://www.bbc.co.uk/news/world-europe-61210699?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61210699?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 20:16:58+00:00

Yuriy Glodan's wife, mother-in-law, and baby were killed in a strike on their apartment block in Odesa.

## Emma Raducanu wins Breakthrough of the Year at 2022 Laureus Sports Awards
 - [https://www.bbc.co.uk/sport/61211260?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/61211260?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 20:14:46+00:00

Tennis player Emma Raducanu wins the Breakthrough of the Year award at the 2022 Laureus World Sports Awards - one of three British winners.

## Historic win but president faces a divided country
 - [https://www.bbc.co.uk/news/world-europe-61209765?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61209765?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 19:24:45+00:00

The 44-year-old will now serve for another five years, but he is facing a polarised France.

## France election: Le Pen concedes defeat in presidential vote
 - [https://www.bbc.co.uk/news/world-europe-61211789?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61211789?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 18:59:08+00:00

Marine Le Pen addresses her supporters as she concedes in France's presidential vote.

## France election: Macron supporters cheer first projections
 - [https://www.bbc.co.uk/news/world-europe-61211425?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61211425?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 18:56:20+00:00

The incumbent, Emmanuel Macron, has secured the largest share of the vote in the presidential election.

## Tyson Fury v Dillian Whyte: 'I wouldn't be surprised if Fury does retire, but it's complicated'
 - [https://www.bbc.co.uk/sport/boxing/61209007?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/61209007?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 15:33:10+00:00

It is wholly possible Tyson Fury will retire after beating Dillian Whyte, but he could return for an undisputed clash next year, says BBC Radio 5 Live boxing analyst Steve Bunce.

## Prince Edward and Sophie welcomed on second leg of Caribbean tour
 - [https://www.bbc.co.uk/news/uk-61208485?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61208485?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 12:32:07+00:00

The Earl and Countess of Wessex continue their tour with a visit to St Vincent and the Grenadines.

## Partygate: Removing PM would lead to instability, says Oliver Dowden
 - [https://www.bbc.co.uk/news/uk-politics-61207801?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-61207801?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 12:30:08+00:00

As some Tories join calls for Boris Johnson to quit over partygate, his chairman says it would bring uncertainty.

## Labour calls for emergency budget over cost of living crisis
 - [https://www.bbc.co.uk/news/uk-politics-61207802?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-61207802?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 12:21:17+00:00

Sir Keir Starmer says the government's response to the crisis so far has been "utterly woeful".

## Nigeria oil blast: Police hunt illegal refinery owner after deadly explosion
 - [https://www.bbc.co.uk/news/world-africa-61207441?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-61207441?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 11:23:19+00:00

More than 100 were killed in an explosion at a hazardous site in Imo state, the authorities say.

## Tyson Fury v Dillian Whyte: Fury on retirement after impressive Wembley Stadium knockout
 - [https://www.bbc.co.uk/sport/av/boxing/61208756?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/boxing/61208756?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 11:15:58+00:00

WBC champion Tyson Fury says "there is nothing more I can do" as he discusses his potential retirement after a one-punch knockout of Dillian Whyte in the sixth round at Wembley.

## French vote as Macron aims to beat far-right Le Pen
 - [https://www.bbc.co.uk/news/world-europe-61204543?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61204543?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 11:15:24+00:00

After a divisive campaign, Marine Le Pen faces an uphill battle to defeat sitting President Macron.

## Hampshire family fall foul of post-Brexit passport rule
 - [https://www.bbc.co.uk/news/uk-england-hampshire-61202948?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-hampshire-61202948?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 09:41:54+00:00

Mum is told her passport is invalid for Portugal because it lasts longer than 10 years.

## Eric Chappell: Grantham-born Rising Damp writer dies aged 88
 - [https://www.bbc.co.uk/news/uk-england-lincolnshire-61207651?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lincolnshire-61207651?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 09:22:30+00:00

Chappell was the writer behind several hit TV sitcoms in the 1970s and 1980s.

## Jamie Wallis: First trans MP says part of him died after rape
 - [https://www.bbc.co.uk/news/uk-wales-politics-61207083?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-politics-61207083?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 09:13:40+00:00

Jamie Wallis said last month he has gender dysphoria and had been a victim of rape and blackmail.

## Japan: Ten confirmed dead from missing tourist boat
 - [https://www.bbc.co.uk/news/world-asia-61202599?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-61202599?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 09:09:43+00:00

The search continues in frigid waters off the Hokkaido island for 16 others who were on board.

## Tyson Fury v Dillian Whyte: Gypsy King retains WBC title at Wembley and vows to retire
 - [https://www.bbc.co.uk/sport/boxing/61188235?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/61188235?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 06:41:00+00:00

WBC champion Tyson Fury produces a stunning one-punch stoppage in the sixth round to beat fellow Briton Dillian Whyte and then insists he will retire.

## Harrogate calling: When Eurovision came to Yorkshire
 - [https://www.bbc.co.uk/news/uk-england-york-north-yorkshire-61150203?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-york-north-yorkshire-61150203?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 05:56:08+00:00

Forty years after Eurovision came to a Yorkshire spa town, BBC News speaks to those who were there.

## Newspaper headlines: PM defends premiership, and Ukraine's weapons pleas
 - [https://www.bbc.co.uk/news/blogs-the-papers-61205355?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-61205355?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 04:41:37+00:00

Boris Johnson insists he is delivering for Britain, as the Partygate scandal looms over Downing Street.

## Rio carnival: Brazil holds first Rio de Janeiro carnival since Covid
 - [https://www.bbc.co.uk/news/world-latin-america-61205687?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-61205687?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-24 01:49:24+00:00

Parades fill the streets of Brazil's Rio de Janeiro for the first carnival since the pandemic began.


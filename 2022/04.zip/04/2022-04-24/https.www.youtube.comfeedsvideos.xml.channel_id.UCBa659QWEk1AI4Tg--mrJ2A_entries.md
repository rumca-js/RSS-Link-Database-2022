# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## Downhill, on a couch, on public roads.
 - [https://www.youtube.com/watch?v=19o8yPaVp58](https://www.youtube.com/watch?v=19o8yPaVp58)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2022-04-25 00:00:00+00:00

The Monte Toboggans, in Funchal on the island of Madeira, are wicker sofas: a bit like the gondolas of Venice, only you're going downhill in regular traffic. More about them: https://www.carreirosdomonte.com/

Producer: Aitken Pearson https://firecrestindependent.com
Assistant Producer: Elsa Gouveia
Camera: Elton Cantoni
Editor: Dave Stevenson http://davestevenson.co.uk

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo


# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## David Blaine Teaches Me Magic!
 - [https://www.youtube.com/watch?v=7jaMJGtAV9M](https://www.youtube.com/watch?v=7jaMJGtAV9M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-04-25 00:00:00+00:00

Then I went and tried it on my friends.

Waveform Podcast: http://youtube.com/Waveform
Studio: http://youtube.com/TheStudio

MKBHD Merch: http://shop.MKBHD.com

0:00 FaceTime Magic with Austin Evans
3:03 Why David uses YouTube
7:24 Magic with MrWhoseTheBoss
11:55 Why TEACH Magic?
15:54 Magic with Dave2D
20:05 Why David does Magic!
23:06 The Reveal!

Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


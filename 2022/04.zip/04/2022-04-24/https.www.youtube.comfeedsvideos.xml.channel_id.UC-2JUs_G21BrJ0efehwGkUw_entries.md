# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Pretty Girl | David Ryan Harris (ft. Scary Pockets) - FUNK version
 - [https://www.youtube.com/watch?v=kjkToy25Bl4](https://www.youtube.com/watch?v=kjkToy25Bl4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2022-04-25 00:00:00+00:00

Come see David Ryan Harris LIVE with Scary Goldings on 6/3/22 at The Troubadour in Los Angeles! Tickets on sale NOW: https://wl.seetickets.us/event/David-RyanHarris/470179?afflky=TheTroubadour

Store: https://www.scarypocketsfunk.com
Patreon: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of David Ryan Harris' "Pretty Girl" by David Ryan Harris + Scary Pockets

MUSICIAN CREDITS
Vocals: David Ryan Harris
Bass: Sean Hurley
Organ: Larry Goldings
Keys: Charles Jones
Drums: Lemar Carter
Guitar: Ryan Lerman
Percussion, Guitar, Keys, Additional Production: Jesse Singer

AUDIO CREDITS
Recording Engineer: Caleb Parker
Assistant Engeineer: Peter Hanaman
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
DP: Nate Cuboi
Video Assistant: Po Han Su
Editor: Adam Kritzberg

Recorded Live at The Village in Los Angeles, CA.

#ScaryPockets #ScaryGoldings #Funk #DavidRyanHarris


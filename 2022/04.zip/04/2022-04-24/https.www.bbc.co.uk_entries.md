## Angela Rayner: MPs hit back over claims of 'Basic Instinct' tactics to distract PM - BBC News
 - [https://www.bbc.co.uk/news/uk-politics-61208037](https://www.bbc.co.uk/news/uk-politics-61208037)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2022-04-24 23:05:23.898393+00:00

An article suggesting Labour's deputy tries to distract the PM in the Commons is roundly condemned.

## Partygate: Removing PM would lead to instability, says Oliver Dowden - BBC News
 - [https://www.bbc.co.uk/news/uk-politics-61207801](https://www.bbc.co.uk/news/uk-politics-61207801)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2022-04-24 10:11:36.207270+00:00

As some Tories join calls for Boris Johnson to quit over partygate, his chairman says it would bring uncertainty.


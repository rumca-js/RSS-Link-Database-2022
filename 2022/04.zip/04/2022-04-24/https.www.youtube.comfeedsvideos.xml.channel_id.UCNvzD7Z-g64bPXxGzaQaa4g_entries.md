# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 8 New Games of May 2022
 - [https://www.youtube.com/watch?v=j2sW6z3Q4kQ](https://www.youtube.com/watch?v=j2sW6z3Q4kQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-04-25 00:00:00+00:00

May 2022 has a handful of solid games to check out on PC, PS5, PS4, Xbox Series X/S/One, and Switch.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Trek to Yomi 
Platform : PC PS5 XSX|S PS4 XBOX ONE
Release Date : May 5, 2022

My Time at Sandrock 
Platform : PC
Release Date : May 26, 2022

Warhammer 40,000: Chaos Gate - Daemonhunters 
Platform : PC
Release Date : May 5, 2022

Salt and Sacrifice 
Platform : PS4 PC PS5 
Release Date : May 10, 2022 

MX vs ATV Legends 
Platform : PC PS5 XSX|S PS4 XBOX ONE
Release Date : May 24, 2022

Vampire: The Masquerade - Swansong 
Platform : PC PS5 XSX|S PS4 XBOX ONE SWITCH
Release Date : May 19, 2022

Evil Dead: The Game 
PC PS5 XSX|S PS4 XBOX ONE SWITCH
Release Date : May 13, 2022

Sniper Elite 5
Platform : PC PS5 XSX|S PS4 XBOX ONE 
Release Date : May 26, 2022

BONUS
Deliver Us The Moon 
Platform : PS5 XSX|S
Release Date : May 19, 2022

Green Hell VR 
Platform : Steam VR
Release Date :  May 2022

## What Made Red Dead Redemption 2 A Big Deal?
 - [https://www.youtube.com/watch?v=3cbC4xLN03Q](https://www.youtube.com/watch?v=3cbC4xLN03Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-04-24 00:00:00+00:00

Red Dead Redemption 2 was a mainstream gaming success with incredibly unique storytelling. Let's take a look back at what made RDR2 such a big deal for us.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


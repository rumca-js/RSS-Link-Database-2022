# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## I WAS WRONG: Onewheel motor is NOT serialized - retraction & apology to my audience
 - [https://www.youtube.com/watch?v=8i2naNIBy1g](https://www.youtube.com/watch?v=8i2naNIBy1g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-04-24 00:00:00+00:00

https://www.youtube.com/watch?v=5J7JKgEJteI

https://www.youtube.com/watch?v=oNl2q6YZXlA
https://www.youtube.com/watch?v=xKEdi6vXMrU
https://www.youtube.com/watch?v=YzDE7ipLcW0
https://www.youtube.com/watch?v=04W_L1g6dec
https://www.youtube.com/watch?v=6G3ddOMvBws
https://www.youtube.com/watch?v=z4v8x5vs1Cs
https://www.androidauthority.com/self-repair-right-to-repair-3153191/


# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## We’re Not Allowed To Talk About This
 - [https://www.youtube.com/watch?v=rgQvEGn0zNc](https://www.youtube.com/watch?v=rgQvEGn0zNc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-04-25 00:00:00+00:00

From left to right, from Noam Chomsky to Tucker Carlson, war-skeptical voices are being denounced. Guess who benefits.
#Tucker #Chomsky #MainstreamMedia

References
https://taibbi.substack.com/p/americas-intellectual-no-fly-zone?s=r
https://abcnews.go.com/Business/wireStory/russias-invasion-ukraine-sends-news-network-ratings-83188734
https://www.jacobinmag.com/2022/04/defense-industry-ex-military-officials-pundits-corporate-news-ukraine
https://twitter.com/RBReich/status/1501354414224785414
https://truthout.org/articles/average-us-taxpayer-gave-900-to-military-contractors-last-year/

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## The Metaverse: This Changes Everything
 - [https://www.youtube.com/watch?v=FVo0RlUv29k](https://www.youtube.com/watch?v=FVo0RlUv29k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-04-24 00:00:00+00:00

A metaverse company is developing a way for people to talk to their loved ones even after they die …and all it requires is massive amounts of your personal data!
#Metaverse #Data #Privacy 

References
https://nypost.com/2022/04/15/you-could-become-immortal-in-the-metaverse-with-new-live-forever-mode/
https://www.vice.com/en/article/pkp47y/metaverse-company-to-offer-immortality-through-live-forever-mode

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


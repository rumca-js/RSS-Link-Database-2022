# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Jak weekend jest długi to się buty gubi
 - [https://www.youtube.com/watch?v=VWALxcgu3Pk](https://www.youtube.com/watch?v=VWALxcgu3Pk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-04-24 00:00:00+00:00

Dziś reklamy wyłączone, bo reklama jest w środku. Platforma Cambly - z kodem "dobry_wieczor" dostajesz 10 minut lekcji za darmo i 50% zniżki, gdy zdecydujesz się na subskrypcję roczną. Zniżki z kodem są aktywne do 15 maja 2022. Link do zapisów: https://cambly.biz/dobry_wieczor

Piosenka Fryderyka: https://youtu.be/-YCU7CkSbZA

Spis treści:
00:00 Wstęp
00:37 Dobry wieczór
00:41 Netflix ogłosił straty
03:06 Reklamy na Netflixie
05:12 Reklama Cambly
05:55 Obecna sytuacja w Szanghaju
06:21 Pracownicy zamieszkają w fabryce Tesli w Chinach
07:09 Apple płaci w Brazylii karę za brak ładowarki w pudełku
07:50 Film porównanie (Oneplus, Samsung, iPhone) na kanale Centrum Testów
08:02 Okulary Canona
09:00 Okulary z Kickstartera
09:53 Ceny kart graficznych spadły
10:05 Głosniki Bose w zagłówkach samochodu
11:00 Znośnego tygodnia!

Źródła:
Piosenka za, a nawet przeciw legalizacji: https://youtu.be/-wnvU4qAnM0
Netflix traci: https://bit.ly/3k3D4zv
Koniec dzielenia się hasłem do Netflixa: https://cnb.cx/3OJURd8
DJ Khaled na gitarze: https://bit.ly/3vFY30z
Reklamy na Netflixie: https://bit.ly/3KbZnxl
Lubimy płacić za oglądanie reklam: https://bit.ly/3vcHn1Q
Jak działa HBO Max z reklamami: https://cnet.co/3kpJ2eh
Oglądanie TV w autonomicznych samochodach: https://bit.ly/3rPvvR3
Pracownicy zamieszkają w fabryce Tesli w Chinach: https://bit.ly/3vIymwr
Chiński Elon Musk: https://bit.ly/37GOkPE
W Brazylii Apple płaci za brak ładowarki w pudełku: https://bit.ly/3v3Zffd
Mimo, że już raz zapłaciło: https://bit.ly/37u6u7f
Recenzja smartfonów na Centrum Testów: https://youtu.be/PzqAY-y7pq4
Okulary Canona do rozszerzonej rzeczywistości: https://bit.ly/3LsvPxb
Okulary z Kickstartera: https://bit.ly/3EPpCIX
Ceny kart graficznych spadły: https://bit.ly/3xPRQSr
Głośniki samochodowe w zagłówkach: https://bit.ly/3EWLgv7

Moje sociale:
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter


# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This video is pain - Intel $5,000 Extreme Tech Upgrade
 - [https://www.youtube.com/watch?v=lIxAPW0YAEU](https://www.youtube.com/watch?v=lIxAPW0YAEU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-04-25 00:00:00+00:00

Thanks to Intel for continuing to sponsor this awesome series! Buy an Intel Core i7-12700K: https://geni.us/2jgRNz

Buy an EVGA RTX 3070 XC3: https://geni.us/Y5GQw0

Buy an  ASUS TUF Z960 Plus: https://geni.us/raCM

Buy an EK-AIO 240 D-RGB: https://geni.us/Y7GgQ

Buy an AORUS FV43U QLED: https://geni.us/VhB0M

Buy some BeQuiet! Silent Wings 3 Fans: https://geni.us/uFB3a1R

Buy a Corsair RMx 850W: https://geni.us/Hr6V0xv

Buy a Corsair Vengeance LPX 64GB Ram Kit: https://geni.us/NfrT

Buy a Corsair 4000D AIRFLOW: https://geni.us/75g4aM

Buy an Elgato StreamDeck XL: https://geni.us/BeBvW

Buy some WD Red Plus 8TB Drives: https://geni.us/EzK14A

Buy an Audient EVO4 Interface: https://geni.us/YUe5XTr

Buy a Dan Clark Audio AEON RT: https://lmg.gg/dJ545

Buy an APC UPS 1500VA: https://geni.us/EfjwOOa

Buy an IKEA Bekant Tabletop: https://lmg.gg/J9Kbi

Buy a Secret Lab Titan 2022 Chair: https://lmg.gg/UmRLW

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1427205-this-video-is-pain-intel-5000-extreme-tech-upgrade/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

Special Intro by MBarek Abdelwassaa
https://www.instagram.com/mbarek_abdel/

CHAPTERS
---------------------------------------------------
0:00 Intro
1:11 PC Tour
3:30 The other PC
5:12 Current Setup
9:07 PC Build
19:17 New Desk
21:10 Monitors
24:13 NAS

## You Said I Was a Fool - Panasonic 4K Blu-ray Player
 - [https://www.youtube.com/watch?v=na1hqx4Yi68](https://www.youtube.com/watch?v=na1hqx4Yi68)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-04-24 00:00:00+00:00

Learn more about CORSAIR's new Xeneon Gaming Monitor: https://lmg.gg/XENEONLTT

SmartDeploy: Claim your FREE IT software (worth $580!) at https://lmg.gg/Sc3KR

Several years ago a lot of you weren't happy about us using an Xbox to compare Blu-ray and 4K Blu-ray so we ponied up for a $500 standalone player. It offers some advantages but is it worth spending that much more money on your setup if you already own a game console?

Discuss on the forum: https://linustechtips.com/topic/1426986-you-said-i-was-a-fool/

Buy an LG OLED EVO G1: https://geni.us/wyERmk

Buy a Panasonic DPUB820: https://geni.us/KV2X

Buy an Xbox Series X: https://geni.us/o4QI5R

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:15 You Were Right
2:35 YCbCr
6:55 Dolby Vision
9:37 Other Issues
10:20 Conclusion
12:06 Outro


# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Piękna Polska! Najlepsze miejsca w Polsce - kilkadziesiąt pomysłów na weekend [Poczuj Polskę]
 - [https://www.youtube.com/watch?v=Gf-wqJeA53E](https://www.youtube.com/watch?v=Gf-wqJeA53E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2022-04-24 07:33:13+00:00

Książka taniej i z podpisem? 📙👉 https://kolemsietoczy.pl/ksiazka/
Kurs filmowo-montażowy 👉 http://kursfilmowaniaimontazu.pl/

Cześć, jako że zbliża się sezon, to chciałem Wam podrzucić co nieco moim zdaniem, najładniejszych miejsc w Polsce. Mam dla Was kilkanaście regionów, które widokowo są absolutną topką w naszym kraju, i które chciałbym Wam pokazać w stylu serii "Poczuj" czyli w formie relaksującego połączenia spokojnych ujęć, odgłosów natury i muzyki. Bez gadania. 

Jeśli macie swoje, inne  typy miejsc wartych zobaczenia - to piszcie w komentarzach. A jeśli zaś jesteście ciekawi gdzie konkretnie pokazywane tutaj miejsca się znajdują, to na blogu kolemsietoczy.pl poszukać wpisów z danych regionów, albo poszukać filmów na tym kanale, bo o wielu z tych miejsc są osobne, pełne odcinki. Albo zainteresować się moją książkę Rower To jest świat, której znaczną część zajmują najlepsze trasy rowerowe w Polsce i blisko granicy, poprowadzone dokładnie przez wiele tutaj pokazywanych miejsc. 

►►Zachęcam do subskrypcji: http://bit.ly/2cmWbSO 

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

0:00 - Najlepsze miejsca w Polsce
1:05 - Beskid Sądecki i Pieniny
3:34 - Kaszuby
4:05 - Podlasie 
4:38 - Bug
5:03 - Pilica
5:55 - Brda
6:32 - Wybrzeże
6:50 - Kopań
7:22 - Hel i Mierzeja Wiślana
7:56 - Kotlina Sandomierska
9:19 - Dolny Śląsk
10:24 - Magiczne Bieszczady


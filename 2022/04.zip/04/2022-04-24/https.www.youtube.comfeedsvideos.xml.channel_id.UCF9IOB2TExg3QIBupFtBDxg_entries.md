# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## US, subvarient excellent news
 - [https://www.youtube.com/watch?v=ngUzts-krS4](https://www.youtube.com/watch?v=ngUzts-krS4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-04-24 00:00:00+00:00

Immunity generating omicron subvarients circulating widely in the United States

CDC data

https://covid.cdc.gov/covid-data-tracker/#trends_dailydeaths

Omicron BA.2 in US, April 16th 

https://www.medscape.com/viewarticle/972376?uac=127834AR&faf=1&sso=true&impID=4181385&src=wnl_edit_tpal

https://covid.cdc.gov/covid-data-tracker/#variant-proportions

93.4% of the coronavirus variants circulating in the United States

19% BA.2.12.1

Contains additional mutations, linked to immune evasion

New York State's health department

BA.2.12 and BA.2.12.1 most prevalent versions in central NY state

23%-27% growth advantage over the original BA.2


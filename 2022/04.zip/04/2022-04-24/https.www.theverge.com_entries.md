## Google, Meta, and others will have to explain their algorithms under new EU legislation - The Verge
 - [https://www.theverge.com/2022/4/23/23036976/eu-digital-services-act-finalized-algorithms-targeted-advertising](https://www.theverge.com/2022/4/23/23036976/eu-digital-services-act-finalized-algorithms-targeted-advertising)
 - RSS feed: https://www.theverge.com
 - date published: 2022-04-24 09:34:08.798001+00:00

The EU’s new legislation is designed to explain the web to users


# Source:Serpentza, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl7mAGnY4jh4Ps8rhhh8XZg, language:en-US

## How I Survived China for 14 Years
 - [https://www.youtube.com/watch?v=YZIokbbSlSI](https://www.youtube.com/watch?v=YZIokbbSlSI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl7mAGnY4jh4Ps8rhhh8XZg
 - date published: 2022-04-11 00:00:00+00:00

Being the first person to post YouTube videos out of Mainland China has led to all manner of adventures, ups and downs but how did I get to this point?...

Watch Stay Awesome, China! here:
https://youtu.be/mSie5A3LWgI

If you'd like to see the original stream with the full Q&A (over 2.5 hours long): https://youtu.be/mBhDtpkBCQ8

For a deeper dive into China's Propaganda influence and soft power, watch our liveshow ADVPodcasts: https://www.youtube.com/advpodcasts

Support Sasha and I on Patreon: http://www.patreon.com/serpentza
Bitcoin - bc1qxfjp2t6x5dpslv59u0jl89m6k643hcn8h2jsvp
Ethereum - 0x6Da150a2A8529110017Ed4db68B3dF0084900280
Paypal: https://paypal.me/winstonsterzel

DOCUMENTARY LINKS:
Conquering Southern China:
https://vimeo.com/ondemand/conqueringsouthernchina

Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina

Stay Awesome China (my new documentary): https://vimeo.com/ondemand/stayawesomechina

For Motorcycle adventures around the world, and a talk-show on two wheels go to ADVChina every Monday 1pm EST
https://www.youtube.com/advchina

For a realistic perspective on China and world travel from an American father and a Chinese mother with two half-Chinese daughters go to Laowhy86 every Wednesday 1pm EST
https://youtu.be/mErixa-YIJE

For a no-nonsense on the street look at Chinese culture and beyond from China's original YouTuber, join SerpentZA on Friday at 1pm EST
https://www.youtube.com/serpentza

Join me on Facebook: http://www.facebook.com/winstoninchina
Twitter: @serpentza
Instagram: serpent_za

Music used: (FREE) City Pop X Funk Type Beat -  Easy    Prod. BigBadBeats
https://www.youtube.com/watch?v=C3auI6e3CHU


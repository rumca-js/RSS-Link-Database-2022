# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I want to love Apple, but they’re making it hard - Mac Studio SSD Swapping
 - [https://www.youtube.com/watch?v=8IHqntr8FjY](https://www.youtube.com/watch?v=8IHqntr8FjY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-04-11 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

Is it possible to repair or upgrade the SSD in the Mac Studio?  We investigate.

Discuss on the forum: https://linustechtips.com/topic/1424143-i-want-to-love-apple-but-they%E2%80%99re-making-it-hard/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 - Hey Apple!
0:53 - GlassWire
1:07 - LTT Intro
1:15 - Unboxing the Mac Studio
2:43 - Teardown & PSU Suprise
5:05 - Not an SSD
6:54 - Flash module vs. SSD
9:17 - Putting the FU in DFU
11:00 - Can you Upgrade?
15:22 - Squarespace
15:57 - Outro

## Building the $1,000,000 Computer
 - [https://www.youtube.com/watch?v=5Hxr9k5Vdc4](https://www.youtube.com/watch?v=5Hxr9k5Vdc4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-04-10 00:00:00+00:00

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/linus

SmartDeploy: Claim your FREE IT software (worth $580!) at https://lmg.gg/SDQ2

We've unboxed it, we've built one of the servers, and now it's finally time! In this video, we're assembling the ENTIRE $1,000,000 petabyte of flash cluster, and powering it up for the FIRST TIME.

Discuss on the forum: https://linustechtips.com/topic/1423938-building-a-1000000-computer/

Check out the Kioxia CD6 Drives: https://lmg.gg/rkDFz
Check out AMD Epyc 32 Core Processors: https://geni.us/8KHx0
Check out AMD Epyc 64 Processors: https://lmg.gg/pN6lh
Check out the Supermicro Storage 1124US-TNRP: https://lmg.gg/6Qqcu
Check out the Supermicro GPU 4124GO-NART: https://lmg.gg/bgJiM
Check out Samsung DDR4 ECC Memory: https://lmg.gg/GAN0z
Check out the NVIDIA MSN3700-VS2F Switch: https://lmg.gg/0SKZE
Check out the NVIDIA ConnectX-6 200GbE Cards: https://lmg.gg/rfSEo
Buy Infinite Cables Fibre Cables: https://lmg.gg/HGrgD
Buy Infinite Cables Custom Cables: https://lmg.gg/K4JK8
Buy FS.com 100GbE Transceivers: https://bit.ly/3IX9qpr
Check out RackStuds! https://lmg.gg/ze86d

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro


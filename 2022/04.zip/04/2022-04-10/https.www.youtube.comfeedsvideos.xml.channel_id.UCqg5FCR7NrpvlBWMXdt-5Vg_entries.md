# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Moon Knight Offers a Novel Approach to Marvel's Villain Problem
 - [https://www.youtube.com/watch?v=FUOqHugfc-w](https://www.youtube.com/watch?v=FUOqHugfc-w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-04-11 00:00:00+00:00

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

One of the more frequent criticisms of Marvel Studios productions is that their villains are fairly bland, with exceptions like Kilmonger and Loki; this makes a certain amount of sense; after all, the hero is the big returning character and so it makes sense to invest energy in making them pop; Moon Knight essentially offers a twist on that by essentially literalizing the idea that Moon Knight is his own worst enemy, with so much of the show being about Marc and Steven fighting each other, and Arthur Harrow serving mostly as a foil or mirror.

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## The Escapist + - New Content, Merch and More Coming in 2022
 - [https://www.youtube.com/watch?v=GaBPLvzDLe4](https://www.youtube.com/watch?v=GaBPLvzDLe4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-04-11 00:00:00+00:00

We've been busy behind the scenes. Here's an update video detailing all the things we've been working, will be working on and some structure changes to channel. Thanks for all your support over the past three years! 

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag


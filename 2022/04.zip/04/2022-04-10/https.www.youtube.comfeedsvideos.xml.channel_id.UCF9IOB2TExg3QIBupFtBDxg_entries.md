# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## UK peaks, China locks down
 - [https://www.youtube.com/watch?v=Oji34lcJ1Yg](https://www.youtube.com/watch?v=Oji34lcJ1Yg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-04-11 00:00:00+00:00

UK, decline has just started

https://covid.joinzoe.com/data

Symptoms after two years

https://www.youtube.com/watch?v=PuRu4fuI_rU&t=9s

Tim Spector vindicated, 1st April

https://www.nhs.uk/conditions/coronavirus-covid-19/symptoms/main-symptoms/

Updated quietly, overnight, no announcement, no apology, no refencing

1st April

End of free testing in England

Tim Spector report

https://www.youtube.com/watch?v=PuRu4fuI_rU&t=9s

Symptoms

Runny nose, 82%

Fatigue, 70%

Headache, 69%

Sore throat, 69%

Sneezing, 68%

Persistent cough, 54%

Hoarse, 47%

Chills or shivers, 36%

Joint pains, 33%

Fever, 32%

Dizzy, 30%

Brain fog, 28%

Sore eyes, 25%

Altered smell, 24%

Muscle pains, 23%

Lower back pain, 23%

Swollen glands, 21%

Skipped meals, 18%

Ear ringing, 17%

Diarrhoea

Lateral flow tests, 20% false negatives 
(confirmed by same day PCR positive tests)

2.6 % of LTS tests give a false positive

Best to swab nose AND throat

R = 1

Prevalence, One in 14

Rates will remain high for a long time

75 +, plateau

Other age groups downward trend

China, Shanghai

https://www.nytimes.com/live/2022/04/10/world/covid-19-mandates-cases-vaccine?type=styln-live-updates&label=coronavirus%20updates&index=0

Two years of zero-Covid policies

Shanghai, 25 million people, citywide lockdown since early April,

because of a surge in Omicron

Saturday, cases + 25,000

## US, Best guess
 - [https://www.youtube.com/watch?v=ifvlkY47KtY](https://www.youtube.com/watch?v=ifvlkY47KtY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-04-11 00:00:00+00:00

US cases still low, but I expect them to rise

https://www.nytimes.com/2022/04/06/briefing/covid-cases-us-omicron-subvariant.html?action=click&pgtype=LegacyCollection&state=default&module=styln-coronavirus&variant=show&region=BELOW_MAIN_CONTENT&block=storyline_flex_guide_recirc

Down about 1% as BA.2 has become the dominant

Original Omicron, so contagious, predictable global spread

More immunity

In liberal parts of the U.S., vaccination rates high

Conservative communities, normal life for some time

(death rates have been higher)

BA.2 has recently become dominant variant in India, South Africa, Africa

Andy Slavitt, former Biden Covid adviser

BA.1 has infected 45% of Americans

Fewer tests

Uninsured people now must pay foe tests

Many testing clinics have closed

Jessica Malaty Rivera, Boston Children’s Hospital

Quality of current Covid data “abysmal.”

Dr. Scott Gottlieb, former F.D.A. commissioner

Some parts of the country “dramatically” underreporting cases

Trends in Covid hospitalizations lag case trends by about a week

(hospitalizations have continued to fall in the U.S.)



Best guess

U.S. infections will rise soon


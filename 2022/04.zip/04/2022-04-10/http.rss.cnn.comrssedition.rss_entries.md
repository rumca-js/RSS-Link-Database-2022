# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Jimmy Kimmel called out Republican lawmaker, then she called the cops on him
 - [https://www.cnn.com/videos/politics/2022/04/10/jimmy-kimmel-marjorie-taylor-greene-acostanr-vpx.cnn](https://www.cnn.com/videos/politics/2022/04/10/jimmy-kimmel-marjorie-taylor-greene-acostanr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 22:34:08+00:00

CNN's Jim Acosta and political commentators Margaret Hoover and John Avlon discuss a feud between Republican lawmaker Rep. Marjorie Taylor Greene (R-GA) and late-night TV host Jimmy Kimmel.

## Texas district attorney says he will drop murder charge against woman in connection with 'self-induced abortion'
 - [https://www.cnn.com/2022/04/10/us/texas-district-attorney-drops-murder-charge/index.html](https://www.cnn.com/2022/04/10/us/texas-district-attorney-drops-murder-charge/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 21:28:16+00:00

A Texas district attorney is filing a motion to dismiss a murder charge against a woman arrested last week in connection with what law enforcement called "the death of an individual by self-induced abortion."

## Tiger Woods' comeback at Masters comes to an end
 - [https://www.cnn.com/2022/04/10/golf/tiger-woods-2022-masters-final-round-spt-intl/index.html](https://www.cnn.com/2022/04/10/golf/tiger-woods-2022-masters-final-round-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 20:33:36+00:00

Tiger Woods finished his latest appearance at the Masters with a six-over 78 as he capped off his remarkable comeback at Augusta National after nearly 16 months away from golf.

## What does former CIA director see coming in the weeks ahead in Ukraine?
 - [https://www.cnn.com/videos/world/2022/04/10/petraeus-ukraine-russia-war-movements-sotu-vpx.cnn](https://www.cnn.com/videos/world/2022/04/10/petraeus-ukraine-russia-war-movements-sotu-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 19:45:55+00:00

Former CIA Director Gen. David Petraeus (ret.) breaks down Russian tactics in Ukraine up to this point, and where he sees them going next.

## 'Birtherism' to the 'Big Lie': Inside Obama's fight to counter disinformation
 - [https://www.cnn.com/2022/04/10/politics/obama-birtherism-big-lie-disinformation/index.html](https://www.cnn.com/2022/04/10/politics/obama-birtherism-big-lie-disinformation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 17:50:21+00:00

Former President Barack Obama is urgently throwing himself into the fight against disinformation, taking a yearslong private fascination into the open as he makes addressing the issue a key pillar of his post-presidency.

## Manchester City and Liverpool play out pulsating draw to keep Premier League title race in the balance
 - [https://www.cnn.com/2022/04/10/football/manchester-city-liverpool-premier-league-spt-intl/index.html](https://www.cnn.com/2022/04/10/football/manchester-city-liverpool-premier-league-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 17:44:18+00:00

The Premier League title race remains nip and tuck after Manchester City and Liverpool played out a pulsating 2-2 draw on Sunday in Manchester.

## NFL QB hit and killed by dump truck on Florida highway
 - [https://www.cnn.com/2022/04/09/sport/dwayne-haskins-steelers-death-spt-intl/index.html](https://www.cnn.com/2022/04/09/sport/dwayne-haskins-steelers-death-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 17:36:10+00:00

Pittsburgh Steelers quarterback Dwayne Haskins, the former Ohio State star who was poised to enter his fourth year in the NFL, has died, his head coach said in a statement released by the team Saturday.

## US police agencies are sending protective gear to Ukrainian civilians in what experts call an unprecedented move
 - [https://www.cnn.com/2022/04/10/world/police-departments-send-equipment-to-ukraine/index.html](https://www.cnn.com/2022/04/10/world/police-departments-send-equipment-to-ukraine/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 17:13:31+00:00

The governors of Iowa and Nebraska announced last week interagency initiatives to donate police protective gear, including military-grade equipment such as helmets and vests, to Ukraine to help civilians defend themselves against Russia's invasion.

## One of the most powerful tools against Covid-19 is finally gaining traction
 - [https://www.cnn.com/2022/04/10/health/covid-19-ventilation-matters-wellness/index.html](https://www.cnn.com/2022/04/10/health/covid-19-ventilation-matters-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 16:50:41+00:00

• Lockdowns in Shanghai and other Chinese cities pose a growing threat to the economy

## Former UK prime minister has a plan to prosecute Putin
 - [https://www.cnn.com/videos/world/2022/04/10/putin-possible-prosecution-gps-vpx.cnn](https://www.cnn.com/videos/world/2022/04/10/putin-possible-prosecution-gps-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 15:10:52+00:00

Former British Prime Minister Gordon Brown lays out his plan to prosecute Russian President Vladimir Putin for war crimes in Ukraine.

## 'How is this not genocide?': Tapper asks Biden's national security adviser
 - [https://www.cnn.com/videos/world/2022/04/10/jake-sullivan-genocide-russia-ukraine-sotu-vpx.cnn](https://www.cnn.com/videos/world/2022/04/10/jake-sullivan-genocide-russia-ukraine-sotu-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 14:16:46+00:00

President Biden's National Security Adviser Jake Sullivan speaks to Jake Tapper about the Russian invasion of Ukraine and what the United States is doing to support Ukraine.

## $3.2 million in alleged cocaine seized at Texas border
 - [https://www.cnn.com/2022/04/10/us/texas-cocaine-seized-laredo-truck/index.html](https://www.cnn.com/2022/04/10/us/texas-cocaine-seized-laredo-truck/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 14:10:38+00:00

A tractor trailer coming into the US from Mexico was caught Friday carrying 427 pounds of alleged cocaine, the US Customs and Border Protection (CBP) said Sunday.

## Banks are making big money off of Russian debt
 - [https://www.cnn.com/2022/04/09/investing/russia-debt-wall-street-billions/index.html](https://www.cnn.com/2022/04/09/investing/russia-debt-wall-street-billions/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 13:09:35+00:00

US banks have left Russia, but that doesn't mean they're done making money off the Kremlin's horrific invasion of Ukraine.

## Jennifer Lopez shares video of her engagement ring from Ben Affleck
 - [https://www.cnn.com/videos/entertainment/2022/04/09/ben-affleck-jennifer-lopez-engaged-kj-orig.cnn](https://www.cnn.com/videos/entertainment/2022/04/09/ben-affleck-jennifer-lopez-engaged-kj-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 12:23:29+00:00

Nearly twenty years after their first engagement, Jennifer Lopez and Ben Affleck are engaged again. Lopez announced the engagement in a short video on her newsletter, "On the JLO."

## Military analyst explains what Putin's new commander tells us about his strategy
 - [https://www.cnn.com/videos/world/2022/04/10/aleksandr-dvornikov-russia-commander-putin-nr-vpx.cnn](https://www.cnn.com/videos/world/2022/04/10/aleksandr-dvornikov-russia-commander-putin-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 12:11:53+00:00

Ret. Lt. Gen. Mark Hertling discusses Putin's appointment of Aleksandr Dvornikov to be the new commander for his war in Ukraine and what it means for the conflict.

## 'SNL' hosts a quiz show mocking Instagram
 - [https://www.cnn.com/videos/media/2022/04/10/snl-instagram-quiz-show-orig.cnn](https://www.cnn.com/videos/media/2022/04/10/snl-instagram-quiz-show-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 10:03:48+00:00

'SNL' cast members portray contestants on a quiz show mocking users of Instagram

## Ukrainian refugees in Poland get help for trauma you can't see -- mental health
 - [https://www.cnn.com/2022/04/10/politics/ukrainian-refugees-poland-mental-health/index.html](https://www.cnn.com/2022/04/10/politics/ukrainian-refugees-poland-mental-health/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 10:03:04+00:00

Eight-year-old Yana was going to gymnastics class six days a week at home near Odessa, Ukraine.

## This man won the lottery using his little brother's license plate numbers
 - [https://www.cnn.com/2022/04/10/us/maryland-lottery-brother-license-plate-trnd/index.html](https://www.cnn.com/2022/04/10/us/maryland-lottery-brother-license-plate-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 10:01:32+00:00

A lucky Maryland man snagged a $25,000 lottery prize after playing the numbers on his younger brother's license plate.

## Here's why the Parkland shooter is facing a jury even though he has already pleaded guilty
 - [https://www.cnn.com/2022/04/10/us/nikolas-cruz-penalty-phase-explainer/index.html](https://www.cnn.com/2022/04/10/us/nikolas-cruz-penalty-phase-explainer/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 07:01:46+00:00

Jury selection began this past week in the penalty phase of Nikolas Cruz's trial, the part of his court case that will determine whether he is sentenced to death or life in prison for the 2018 shooting at a high school in Parkland, Florida.

## How often you wash your dog's bowl can affect your health, too, study says
 - [https://www.cnn.com/2022/04/10/health/pet-food-bacterial-contamination-study-wellness/index.html](https://www.cnn.com/2022/04/10/health/pet-food-bacterial-contamination-study-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 06:01:28+00:00

How we feed our pets, store their food and wash their dishes can have negative health consequences if not done properly -- for both humans and animals.

## French voters head to the polls in presidential race
 - [https://www.cnn.com/2022/04/10/europe/french-election-first-round-intl/index.html](https://www.cnn.com/2022/04/10/europe/french-election-first-round-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 05:24:07+00:00

French voters head to the polls Sunday for one of the most consequential presidential elections the country has seen in decades.

## Australian leader sets general election for May 21
 - [https://www.cnn.com/2022/04/10/australia/australia-elections-may-morrison-intl-hnk/index.html](https://www.cnn.com/2022/04/10/australia/australia-elections-may-morrison-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 04:53:22+00:00

Australia will hold its general election on May 21, Prime Minister Scott Morrison announced on Sunday, launching a six-week campaign period, where voter concern over issues like the cost of living and climate change are expected to take center stage.

## Analysis: 1st US ambassador to Ukraine: 'I think we handled it wrong from the get-go'
 - [https://www.cnn.com/2022/04/10/politics/ukraine-first-us-ambassador/index.html](https://www.cnn.com/2022/04/10/politics/ukraine-first-us-ambassador/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 04:01:12+00:00

Ukraine's first President, waiting to see America's 41st, chatted with a White House press aide -- in Ukrainian. George H.W. Bush's deputy secretary of state didn't need to hear more.

## UK pledges new military assistance for Ukraine after PM's surprise visit to Kyiv
 - [https://www.cnn.com/2022/04/09/europe/ukraine-uk-boris-johnson-intl-gbr/index.html](https://www.cnn.com/2022/04/09/europe/ukraine-uk-boris-johnson-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 00:29:01+00:00

The UK is to send 120 armored vehicles and new anti-ship missile systems to Ukraine, Downing Street announced Saturday, after Prime Minister Boris Johnson paid an in-person visit to Ukrainian President Volodymyr Zelensky.

## Convicted hit man's escape evokes mob's 'ruthless' heyday in one American city
 - [https://www.cnn.com/2022/04/09/us/dominic-taddeo-escape-rochester-mob/index.html](https://www.cnn.com/2022/04/09/us/dominic-taddeo-escape-rochester-mob/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-10 00:13:14+00:00

Dominic Taddeo was in his early 20s when a US Justice Department lawyer appeared before a Senate subcommittee with a dire warning about the future mafia hit man's hometown.


# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## My robot double sells out (so I don't have to)
 - [https://www.youtube.com/watch?v=uXlQuTRSmzc](https://www.youtube.com/watch?v=uXlQuTRSmzc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2022-04-11 00:00:00+00:00

Thanks to Engineered Arts! https://www.engineeredarts.co.uk/ | AD: 👨‍💻 NordVPN's best deal is here: https://nordvpn.com/tomscott - with a 30-day money-back guarantee!

Edited by Dave Stevenson http://www.davestevenson.co.uk/

I haven't been able to do VPN advertising for a long time. Well, this one time, I don't have to: because the robot double's going to do it for me.

With many thanks to all the team at Engineered Arts who worked on this. To be clear, this is not sponsored by them, I paid money (technically, NordVPN's money) for the Mesmer robot -- or at least, for the silicone mask and 3D printed skull that were put together for just one day!

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo


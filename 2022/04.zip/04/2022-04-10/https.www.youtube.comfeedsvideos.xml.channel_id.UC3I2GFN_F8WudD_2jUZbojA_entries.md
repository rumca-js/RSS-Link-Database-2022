# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Ducks Ltd. - 18 Cigarettes (Live on KEXP)
 - [https://www.youtube.com/watch?v=Hu8kKaIe3gE](https://www.youtube.com/watch?v=Hu8kKaIe3gE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-11 00:00:00+00:00

http://KEXP.ORG presents Ducks Ltd. performing “18 Cigarettes” live in the KEXP studio. Recorded March 24, 2022.

Tom McGreevey - Guitar / Vocals
Katie Ryan - Bass
Jonathan Pappo - Drums
Alex Nelson - Guitar

Host: John Richards
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Carlos Cruz

https://www.ducksltd.co
http://kexp.org

## Ducks Ltd. - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=ekABKwhovmI](https://www.youtube.com/watch?v=ekABKwhovmI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-11 00:00:00+00:00

http://KEXP.ORG presents Ducks Ltd. performing live in the KEXP studio. Recorded March 24, 2022.

Songs:
How Lonely Are You?
Old Times
Under The Rolling Moon
18 Cigarettes

Tom McGreevey - Guitar / Vocals
Katie Ryan - Bass
Jonathan Pappo - Drums
Alex Nelson - Guitar

Host: John Richards
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Carlos Cruz

https://www.ducksltd.co
http://kexp.org

## Ducks Ltd. - How Lonely Are You? (Live on KEXP)
 - [https://www.youtube.com/watch?v=oVIQ9idcOBQ](https://www.youtube.com/watch?v=oVIQ9idcOBQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-11 00:00:00+00:00

http://KEXP.ORG presents Ducks Ltd. performing “How Lonely Are You?” live in the KEXP studio. Recorded March 24, 2022.

Tom McGreevey - Guitar / Vocals
Katie Ryan - Bass
Jonathan Pappo - Drums
Alex Nelson - Guitar

Host: John Richards
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Carlos Cruz

https://www.ducksltd.co
http://kexp.org

## Ducks Ltd. - Old Times (Live on KEXP)
 - [https://www.youtube.com/watch?v=XaW_Z-ehYAc](https://www.youtube.com/watch?v=XaW_Z-ehYAc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-11 00:00:00+00:00

http://KEXP.ORG presents Ducks Ltd. performing “Old Times” live in the KEXP studio. Recorded March 24, 2022.

Tom McGreevey - Guitar / Vocals
Katie Ryan - Bass
Jonathan Pappo - Drums
Alex Nelson - Guitar

Host: John Richards
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Carlos Cruz

https://www.ducksltd.co
http://kexp.org

## Ducks Ltd. - Under The Rolling Moon (Live on KEXP)
 - [https://www.youtube.com/watch?v=mRj3_KYvDXw](https://www.youtube.com/watch?v=mRj3_KYvDXw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-11 00:00:00+00:00

http://KEXP.ORG presents Ducks Ltd. performing “Under The Rolling Moon” live in the KEXP studio. Recorded March 24, 2022.

Tom McGreevey - Guitar / Vocals
Katie Ryan - Bass
Jonathan Pappo - Drums
Alex Nelson - Guitar

Host: John Richards
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Carlos Cruz

https://www.ducksltd.co
http://kexp.org


# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Lab Leak: BOMBSHELL Leaked Documents
 - [https://www.youtube.com/watch?v=yXcNACtRs-s](https://www.youtube.com/watch?v=yXcNACtRs-s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-04-11 00:00:00+00:00

What’s the truth of the covid origins? A bombshell article by Vanity Fair based on more than 100,000 leaked documents uncovers some damning revelations. 
#Wuhan #LabLeak #Fauci #Pandemic 

References
https://www.vanityfair.com/news/2022/03/the-virus-hunting-nonprofit-at-the-center-of-the-lab-leak-controversy

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Thomas Frank: How Populism Was Politically Recontextualised
 - [https://www.youtube.com/watch?v=WxX-Cyb0RPg](https://www.youtube.com/watch?v=WxX-Cyb0RPg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-04-11 00:00:00+00:00

Author Thomas Frank explains on my podcast Under The Skin how the term populism was politically recontextualised. 
#RightWing #Populism #Politics
 
Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## The Truth About Pfizer's Vaccines
 - [https://www.youtube.com/watch?v=uEoNZSLabLc](https://www.youtube.com/watch?v=uEoNZSLabLc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-04-10 00:00:00+00:00

Does critiquing the pharmaceutical industry and the medicines we all take make you a conspiracy theorist? In this video we look at a recent peer-reviewed article taken from British Medical Journal to look more closely at the industry of “evidence based medicine”. 
#BigPharma #BMJ #pfizer

References
https://www.statista.com/statistics/953104/pharma-industry-tv-ad-spend-us/
https://www.bmj.com/content/376/bmj.o702?sort_by=field_highwire_a_epubdate_value&sort_order=DESC&items_per_page=10&panels_ajax_tab_tab=bmj_related_rapid_responses&panels_ajax_tab_trigger=rapid-responses

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


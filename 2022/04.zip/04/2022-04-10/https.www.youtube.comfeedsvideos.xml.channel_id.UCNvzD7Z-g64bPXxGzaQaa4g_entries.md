# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Elden Ring: 10 Things You Can Only Do At MAX LEVEL
 - [https://www.youtube.com/watch?v=x7-aUE2kB-g](https://www.youtube.com/watch?v=x7-aUE2kB-g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-04-11 00:00:00+00:00

Elden Ring (PC, PS5, PS4, Xbox Series X/S/One) still has plenty to do if you're crazy enough to reach max level.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Kingdom Hearts 4: NEW Things You NEED TO KNOW
 - [https://www.youtube.com/watch?v=pRtxX2Algtg](https://www.youtube.com/watch?v=pRtxX2Algtg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-04-11 00:00:00+00:00

Kingdom Hearts 4 (PC, PS5, Xbox Series X/S/One?) is officially a thing. Here's everything to know about the announcement, from gameplay, release date expectations, new characters, and more.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#KingdomHearts

## Top 15 NEW Exploration Games of 2022
 - [https://www.youtube.com/watch?v=MvtE29ln4qk](https://www.youtube.com/watch?v=MvtE29ln4qk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-04-10 00:00:00+00:00

Looking to explore in video game worlds? We've got you covered with these upcoming games for PC, PS5, PS4, Xbox Series X/S/One/Switch.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:14 Sengoku Dynasty
1:20 Stray 
2:10 Avatar: Frontiers of Pandora
2:53 Pokémon Legends: Arceus 
3:50 Hogwarts Legacy 
4:21 Lego Star Wars skywalker saga 
5:31 Hollow Knight: Silksong 
6:30 The Day Before 
7:17 A Plague Tale: Requiem 
7:54 Sonic Frontiers 
8:43 Forspoken 
9:16 God of War Ragnarok 
9:52 Horizon Forbidden West 
10:32 Elden Ring 
11:10 Starfield 

#15 Sengoku Dynasty

Platform : PC 

Release Date : 2022 



#14 Stray 

Platform : PC PS4 PS5 

Release Date : 2022 



#13 Avatar: Frontiers of Pandora

Platform : PC PS5 XSX|S STADIA LUNA 

Release Date : 2022 



#12 Pokémon Legends: Arceus 

Platform : SWITCH 

Release Date : January 28, 2022



#11 Hogwarts Legacy 

Platform : PC PS4 PS5 XSX|S XBOX ONE SWITCH 

Release Date : Q4 2022 



#10 Lego Star Wars skywalker saga 

Platform : PC PS4 PS5 XSX|S Switch XBOX ONE 

Release Date : April 5, 2022 



#9 Hollow Knight: Silksong 

Platform : PC SWITCH LINUX 

Release Date : TBA 



#8 The Day Before 

Platform : PC PS5 XSX|S 

Release Date : June 21, 2022



#7 A Plague Tale: Requiem 

Platform : PC PS4 XBOX ONE May 14, 2019

Release Date : SWITCH PS5 XSX|S July 6, 2022 



#6 Sonic Frontiers 

Platform : PC PS4 PS5 XSX|S XBOX ONE SWITCH 

Release Date : Late 2022 



#5 Forspoken 

Platform : PC PS5 

Release Date : October 11, 2022 



#4 God of War Ragnarok 

Platform : PS4 PS5 

Release Date : 2022 



#3 Horizon Forbidden West 

Platform : PS4 PS5 

Release Date : February 18, 2022



#2 Elden Ring 

Platform : PC PS4 PS5 XSX|S XBOX ONE 

Release Date : February 25, 2022 



#1 Starfield 

Platform : PC XSX|S 

Release Date : November 11, 2022


# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Powstaje megabaza informacji o obywatelach! Ile prywatności zostanie nam w Polskim Ładzie?
 - [https://www.youtube.com/watch?v=Jd64Lu3qjwk](https://www.youtube.com/watch?v=Jd64Lu3qjwk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2022-04-11 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/38JL5aj
2. https://mc.bip.gov.pl/projekty-aktow-prawnych-mc/projekt-rozporzadzenia-rady-ministrow-w-sprawie-wykazu-rejestrow-publicznych-i-systemow-teleinformatycznych-z-ktorych-udostepniane-sa-dane-na-potrzeby-prowadzenia-analiz-w-ramach-zintegrowanej-platformy-analitycznej.html
3. https://bit.ly/3KCKN31
---------------------------------------------------------------
🎴 Do kolażu wykorzystano grafikę autorstwa: 
youtube.com / Kancelaria Premiera
https://bit.ly/3xfkatA
---------------------------------------------------------------
💡 Tagi: #PiS #polityka
--------------------------------------------------------------

## Co Wołodymyr Zełenski robił krótko po pomarańczowej rewolucji? Przemilczane fakty z życia prezydenta
 - [https://www.youtube.com/watch?v=Oijz-9wc0Wo](https://www.youtube.com/watch?v=Oijz-9wc0Wo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2022-04-10 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/377xglp
2. https://bit.ly/3JrGs1o
3. https://bit.ly/3jvgwXP
4. https://bit.ly/3O4Djbo
5. https://bit.ly/3uscTIM
6. https://bit.ly/3vb20dc
7. https://bit.ly/3O38HHa
8. https://bit.ly/3upMnQc
9. https://bit.ly/3E0pvdl
10. https://bit.ly/3JtyiFq
---------------------------------------------------------------
🎴 Do kolażu wykorzystano grafikę autorstwa: 
gov.ua - https://bit.ly/3Kyloat
---
Klim Novgorodtsev / Associated Press
https://bit.ly/3M1EZkC 
---------------------------------------------------------------
💡 Tagi: #Ukraina #Zełenski 
--------------------------------------------------------------


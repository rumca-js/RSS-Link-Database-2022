# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## Czy warto się dzielić? Kontakty w chmurze.
 - [https://www.youtube.com/watch?v=ifEqZlru2FE](https://www.youtube.com/watch?v=ifEqZlru2FE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2022-04-10 00:00:00+00:00

Dawno, dawno temu lista kontaktów przechowywana była na karcie SIM lub w pamięci telefonu z klawiaturą numeryczną. Wraz z postępem technologii dostaliśmy do dyspozycji możliwość synchronizowania kontaktów do chmury, z czego pewnie dzisiaj prawie każdy z nas korzysta. Kto ma dostęp do Twojej książki telefonicznej? Czy bezpieczeństwo naszej tożsamości zależy tylko od nas samych?

Zapraszam!

Źródła:
⛔ Dlaczego warto rozważyć odinstalowanie Truecallera?
https://bit.ly/3r8dWey

❌ Clubhouse i prywatność nie idą w parze
https://bit.ly/3jexFVH

📰 Washington Post o problemie prywatności kontaktów
https://wapo.st/3jeiTys

🔍 W jaki sposób Signal zapewnia prywatność w wyszukiwaniu kontaktów?
https://bit.ly/3xce54Q

💰 MyFamilyTree na portalu crunchbase
https://bit.ly/3NSrkgS

👨‍🔬 Badanie Christopha Hagena z University of Wurzburg
https://bit.ly/3NUnT9f

Jeżeli nie ufasz skracanym linkom (bardzo dobrze!) to dodaj na ich końcu plusik ‘+’.
W ten sposób podejrzysz na stronie bit.ly dokąd prowadzą.

Relevant xkcd: https://xkcd.com/1810/

© Wszystkie znaki handlowe należą do ich prawowitych właścicieli.

Dziękuję za Waszą uwagę. ❤️

Znajdziecie mnie również na;
Instagramie @mateuszemsi https://www.instagram.com/mateuszemsi/
Twitterze @MateuszChrobok https://twitter.com/MateuszChrobok
LinkedInie @mateuszchrobok https://www.linkedin.com/in/mateuszchrobok/
Podcasty na Anchor https://anchor.fm/mateusz-chrobok
Podcasty na Spotify https://open.spotify.com/show/6y6oWs20HwRejktOWHTteR
Podcast na Apple Podcasts https://podcasts.apple.com/us/podcast/mateusz-chrobok-bezpiecze%C5%84stwo-startupy-i-sztuczna-inteligencja/id1617335932 
Patronite @MateuszChrobok https://patronite.pl/MateuszChrobok

Rozdziały:
00:00 Intro
00:54 Smartfony
02:07 Aplikacje
04:46 Prywatność
08:31 Zagrożenia
12:07 Genealogia
13:30 Rozwiązania
16:51 Co Robić i Jak Żyć?


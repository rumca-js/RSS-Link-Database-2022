# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## I found the girl in the photo - now our abuser is in jail
 - [https://www.bbc.co.uk/news/uk-scotland-61039063?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-61039063?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 23:53:19+00:00

Emma tracked down the girl whose picture was in the home of a music teacher who abused her as a teenager.

## Putin's mysterious Facebook 'superfans' on a mission
 - [https://www.bbc.co.uk/news/blogs-trending-61012398?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-trending-61012398?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 23:09:24+00:00

Posts praising the Russian leader are being viewed by millions on the social network.

## 'I'm under no illusions,' says British soldier in Ukraine, after comrades killed
 - [https://www.bbc.co.uk/news/world-europe-61058139?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61058139?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 23:06:53+00:00

Ajay Spence quit his life in Belfast to help defend Kyiv - now he is being redeployed to east Ukraine.

## Cost of living crisis: Nurse skips meals to feed her children
 - [https://www.bbc.co.uk/news/uk-61062263?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61062263?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 23:01:39+00:00

A single mother working for the NHS says rising prices mean she is struggling to pay for food.

## The microchip implants that let you pay with your hand
 - [https://www.bbc.co.uk/news/business-61008730?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61008730?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 23:01:34+00:00

You can now get a payment chip injected beneath your skin, turning you into a human bank card.

## Cost of living: 'My money-saving life hacks'
 - [https://www.bbc.co.uk/news/uk-england-london-61037560?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-61037560?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 23:01:07+00:00

With a squeeze on household budgets, how are Londoners saving money?

## Somalia drought: 'Act now or 350,000 children will die'
 - [https://www.bbc.co.uk/news/world-africa-61036465?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-61036465?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 23:00:45+00:00

In what experts call Somalia's worst drought in a decade, children are facing severe malnutrition.

## Falklands War: 'The UK is still usurping our land'
 - [https://www.bbc.co.uk/news/world-latin-america-61028653?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-61028653?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 23:00:13+00:00

Argentina's president has said he will keep fighting for control of the islands, also known as the Malvinas.

## Manchester City 2-2 Liverpool: 'A joy to watch' - action and reaction from Alan Shearer
 - [https://www.bbc.co.uk/sport/av/football/61062554?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/61062554?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 22:59:45+00:00

Match of the Day 2's Alan Shearer analyses the key incidents from Manchester City v Liverpool, a game he describes as "a joy to watch".

## Ukraine village scarred by aftermath of occupation
 - [https://www.bbc.co.uk/news/world-europe-61062213?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61062213?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 20:54:08+00:00

As Russian forces retreat to eastern Ukraine, Andriivka and other abandoned villages are left devastated.

## France election: This time it won’t be a walkover for Macron
 - [https://www.bbc.co.uk/news/world-europe-61061359?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61061359?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 20:24:56+00:00

Emmanuel Macron will face a run-off against Marine Le Pen, in what is far from a done deal.

## Akshata Murty: Inquiry into leak of Rishi Sunak's wife's taxes begins
 - [https://www.bbc.co.uk/news/uk-politics-61055789?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-61055789?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 11:22:04+00:00

Labour says a row over Akshata Murty's tax affairs raises questions over the chancellor's judgement.

## Ronaldo: Police investigating after Manchester United forward appears to break fan's phone
 - [https://www.bbc.co.uk/sport/football/61053927?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/61053927?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 10:55:45+00:00

Merseyside Police are investigating an alleged assault after Manchester United forward Cristiano Ronaldo appeared to break a fan's phone.

## Imran Khan ousted as Pakistan's PM after vote
 - [https://www.bbc.co.uk/news/world-asia-61055210?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-61055210?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 10:39:57+00:00

The former cricket star loses a no-confidence vote 13 hours after his party tried to delay it.

## French election: Macron faces far-right challenge as France votes
 - [https://www.bbc.co.uk/news/world-europe-61049717?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61049717?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 10:18:26+00:00

The opening round of the French presidential race could become a cliffhanger for Emmanuel Macron.

## ‘A fantasy’ - amateur jockey’s Grand National fairytale
 - [https://www.bbc.co.uk/sport/horse-racing/61050673?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/horse-racing/61050673?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 09:16:10+00:00

Grand National-winning jockey Sam Waley-Cohen pays tribute to his brother after 'fantasy' triumph in his last-ever ride.

## Why is steroid use rising among male bodybuilders?
 - [https://www.bbc.co.uk/news/uk-england-gloucestershire-60765050?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-gloucestershire-60765050?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 08:16:58+00:00

More bodybuilders are taking drugs knowing the damage they can do to their bodies, an academic says.

## Hauliers want priority for perishable goods at Dover
 - [https://www.bbc.co.uk/news/business-61053402?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61053402?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 07:47:03+00:00

Drivers say deliveries of produce like meat are losing quality and value in long waits at the port.

## Ukraine war: Johnson and Zelensky tour near-empty streets in Kyiv
 - [https://www.bbc.co.uk/news/world-europe-61057005?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61057005?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 06:47:51+00:00

Boris Johnson makes a surprise visit to Ukraine's capital, and meets President Volodymyr Zelensky.

## Australian Grand Prix: Charles Leclerc wins in Melbourne as title rival Max Verstappen retires
 - [https://www.bbc.co.uk/sport/formula1/61056578?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/61056578?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 06:34:24+00:00

Charles Leclerc takes a dominant victory in the Australian Grand Prix to move into a commanding position in the World Championship.

## Dwarfism: Woman's battle against ignorance starts in schools
 - [https://www.bbc.co.uk/news/uk-wales-61037196?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-61037196?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 06:08:15+00:00

Danielle endures frequent name-calling, stares and people trying to take photos of her.

## Full embargo on oil could stop war - ex-Putin aide
 - [https://www.bbc.co.uk/news/business-61040424?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61040424?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 04:37:15+00:00

President Putin's former chief economic advisor tells the BBC Western countries could stop the war.

## Henry Patterson: The Eagle has Landed author dies aged 92
 - [https://www.bbc.co.uk/news/entertainment-arts-61054455?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-61054455?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 02:16:41+00:00

Henry Patterson wrote 85 novels, including the WW2 thriller penned under the pseudonym Jack Higgins.

## Masters: Scottie Scheffler leads at Augusta, Cameron Smith & Shane Lowry chasing
 - [https://www.bbc.co.uk/sport/golf/61055709?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/golf/61055709?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 01:20:13+00:00

American Scottie Scheffler remains in a good position to win his first major at the Masters, but sees his lead reduced late in Saturday's third round.

## Masters: Tee-times for Scottie Scheffler, Tiger Woods & Rory McIlroy at Augusta National
 - [https://www.bbc.co.uk/sport/golf/61003499?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/golf/61003499?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 00:57:06+00:00

Tee-times for round four of the Masters at Augusta National with Scottie Scheffler leading from Cameron Smith.

## Masters: Scottie Scheffler and Cameron Smith shine in Masters day three best shots
 - [https://www.bbc.co.uk/sport/av/golf/61054433?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/golf/61054433?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-10 00:09:19+00:00

Leaderboard heavyweights Scottie Scheffler, Cameron Smith and Charl Schwartzel all feature in the best shots of day three at the 2022 Masters at Augusta.


# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## BOKKA - How... It All Ends - MUZO.FM live
 - [https://www.youtube.com/watch?v=JdWhaYYYO_E](https://www.youtube.com/watch?v=JdWhaYYYO_E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2022-04-10 00:00:00+00:00

BOKKA na żywo w MUZO.FM. Utwór How... It All Ends pochodzi z płyty Blood Moon. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook BOKKA: http://www.facebook.com/bokkamusic
Instagram BOKKA: http://www.instagram.com/bokkamusic
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm

Rejestracja audio: Sebastian Zalewski
Mix: BOKKA
Światła: Artur „Żarów” Solmiński


BOKKA - How... It All Ends tekst

try to understand 
that love that i’m feeling
yearning for more 
i’m overwhelmed


it feels like a dream
and i’m under water
searching for something 
to chase


it feels like a dream, 
i’m under water
i breathe for you 
and so many more


don’t make me choose
between life and death
look at the moon
are we there yet?


don’t make me chose
between you and them
look at the moon
it’s how it all ends


# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## The SteamDeck is Incomplete But Fun!
 - [https://www.youtube.com/watch?v=dQrBgda0sEY](https://www.youtube.com/watch?v=dQrBgda0sEY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-04-11 00:00:00+00:00

SteamDeck is so fun, I'm hoping it doesn't get killed off like the rest of Valve's... attempts
The water bottles! http://MKBHD.com
dbrand Killswitch: https://dbrand.com/steam-deck

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Steamdeck provided by Valve for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


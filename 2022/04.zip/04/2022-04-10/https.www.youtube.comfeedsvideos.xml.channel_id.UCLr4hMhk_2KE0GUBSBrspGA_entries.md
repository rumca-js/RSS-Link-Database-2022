# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Niezręczność prowadzi do sukcesu!
 - [https://www.youtube.com/watch?v=nzmgzFslLhA](https://www.youtube.com/watch?v=nzmgzFslLhA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-04-10 00:00:00+00:00

Są na to badania: https://bit.ly/38uC70o
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

Poza tym dziś w odcinku:
00:00 Poważna sztuka samoobrony
00:27 Dobry wieczór
00:55 Uczucie dyskomfortu rozwija
01:27 Elon Musk kupuje 9% Twittera
02:02 Twitter robi Muska dyrektorem 
02:34 Mikroplastik w płucach
03:12 Nowy OnePlus 10 Pro z Hasselbladem
03:37 Oppo Reno 8 marki OnePlus
03:53 Podróż na stację kosmiczną
05:05 Twarz Zuckerberga na banknotach w metaversie
05:38 Drukarka 3D od Ankera
05:53 Pracownicy Google w Stanach wracają do biur
06:06 ...takich na przykład
07:01 i dostają hulajnogę na pocieszenie
08:02 Hulajnoga Unagi
08:48 Znośnego tygodnia!

Źródła:
Elon Musk kupuje 9% Twittera: https://bit.ly/3uqrwMs
Twitter robi Muska dyrektorem: https://bit.ly/3xi0Src
Mamy w płucach mikroplastik: https://bit.ly/3rey0we
Oppo Reno 8 to będzie OnePlus 10 bez pro: https://bit.ly/3DY8al2
Pierwsza prywatna podróż na stację kosmiczną: https://bit.ly/3rfU35A
Zuck Buck: https://cnet.co/3jqq86u
Drukarka 3D od Ankera: https://bit.ly/3DW8Mrz
Google zapłaci pracownikom za hulajnogi: https://bit.ly/3LXgNzh

Moje sociale:
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter


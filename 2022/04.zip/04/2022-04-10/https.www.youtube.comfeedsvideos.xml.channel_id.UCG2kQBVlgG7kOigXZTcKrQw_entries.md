# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Wszystkie odpały MAJÓW. Formowanie czaszek, alkoholowe lewatywy i gra w piłkę na śmierć i życie
 - [https://www.youtube.com/watch?v=kgk7vMrdjpo](https://www.youtube.com/watch?v=kgk7vMrdjpo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2022-04-10 07:15:00+00:00

🎬 http://kursfilmowaniaimontazu.pl/ 🎬

Zapraszam na film o Cywilizacji Majów. Starałem się podejść do tego nieco bardziej na luzie niż wiele tego typu publikacji, skupiając się nieco mniej na nudnych faktach, a bardziej na dziwactwach majów. Aczkolwiek, żeby nie było monotematycznie, to odkryciom Majów i osiągnięciom ich cywilizacji też się przyjrzymy. Podobnie jak przyczynom upadku cywilizacji Majów.

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

spis treści
0:00 - kurs filmowo-montażowy
0:18 - wszystkie odpały Majów
3:09 - jak Majowie unikali apokalipsy
4:36 - jak Majowie upiększali swoje ciała
7:14 - jaki sport wynaleźli Majowie?
8:41 - budownictwo Majów
9:51 - pismo Majańskie
10:51 - Majańskie świątynie
11:41 - w czym Majowie wyprzedzali zachodni świat?
12:12 - Majańskie wojny
13:35 - o upadku cywilizacji Majów
16:15 - ludy Majańskie dziś


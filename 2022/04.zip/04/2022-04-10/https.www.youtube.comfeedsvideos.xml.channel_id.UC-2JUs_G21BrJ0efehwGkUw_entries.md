# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Levitating | @dualipa | FUNK cover ft. @jaaaaaaa
 - [https://www.youtube.com/watch?v=-tEzMiM2HRg](https://www.youtube.com/watch?v=-tEzMiM2HRg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2022-04-11 00:00:00+00:00

Store: https://www.scarypocketsfunk.com
Patreon: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Dua Lipa's "Levitating" by Scary Pockets & Julia Nunes.

MUSICIAN CREDITS
Lead vocal: Julia Nunes
Drums: Abe Laboriel Jr.
Bass: Nick Campbell
Guitar: Ariel Posen
Guitar: Ryan Lerman
Keys: Carey Frank

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
DP: Kenzo Le
Editor: Adam Kritzberg

Recorded Live at East West in Los Angeles, CA.

#ScaryPockets #Funk #DuaLipa #JuliaNunes #Levitating


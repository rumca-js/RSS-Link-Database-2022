# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Games With Insane Graphics That FLOPPED
 - [https://www.youtube.com/watch?v=6AmncotR2Wg](https://www.youtube.com/watch?v=6AmncotR2Wg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-04-23 00:00:00+00:00

Some video games look absolutely gorgeous but never quite live up to their gameplay potential.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## SONY BUYING ANOTHER STUDIO? NEW STAR WARS GAME & MORE
 - [https://www.youtube.com/watch?v=RvxodskAm-4](https://www.youtube.com/watch?v=RvxodskAm-4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-04-22 00:00:00+00:00

Thank you Vapor95 for sponsoring this video. Use the discount code Gameranx at Vapor95.com for 15% off your order!  https://vapor95.com/discount/gameranx

Lots of PlayStation and Sony news, more game delays and release date shifts from Nintendo, and more in a week full of gaming news.

Jake on Instagram: https://bit.ly/3uUh9Ot


 ~~~~STORIES~~~~

SONY BUYING ANOTHER STUDIO?
https://www.reddit.com/r/PS5/comments/u4nw4b/jeff_grubb_says_the_rumored_big_sony_playstation/
https://www.thesixthaxis.com/2022/04/19/from-software-sony-buy-rumour/

God of War update
https://www.reddit.com/r/PS5/comments/u82c5d/bruno_velazquez_god_of_war_ragnarok_animation/

NEW STAR WARS GAME
https://www.thewrap.com/new-star-wars-video-game-skydance-new-media-lucasfilm/

New Insomniac game?
https://www.playstationlifestyle.net/2022/04/21/insomniac-multiplayer-game-world-class/



Ads in games
https://www.theverge.com/2022/4/21/23035875/sony-playstation-microsoft-games-in-game-ads

Syphon Filter
https://www.videogameschronicle.com/news/four-classic-syphon-filter-games-have-been-rated-for-ps4-and-ps5/


Xenoblade Chronicles 3 now July 29
Splatoon 3 now September 9th

VR showcase 
https://youtu.be/0qPfI_azgDY

Skate 4 

Godzilla and King Kong in Warzone
https://youtu.be/V_vNYs_Be0k

Saints Row customization
https://youtu.be/jaavEloyAxM

New Halo modes
https://www.ign.com/articles/halo-infinite-dev-reveals-3-new-modes-coming-in-season-2?utm_source=twitter


It Takes Two movie
https://variety.com/2022/film/news/it-takes-two-movie-amazon-dwayne-johnson-1235236319/

Sonic Origins
https://www.theverge.com/2022/4/20/23033583/sonic-origins-sega-hedgehog-ps5-xbox


New Tales from the Borderlands 
https://www.comingsoon.net/games/news/1219005-new-tales-from-the-borderlands-release-window-announced?fbclid=IwAR07Ey91QW3jIwgAa0kQh6_dkxOpd6lYikm5ed9z-QR3-zvlIY4NKGpNu-o


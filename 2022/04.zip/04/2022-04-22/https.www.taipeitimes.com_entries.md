## US’ chip bid ‘futile,’ Morris Chang says - Taipei Times
 - [https://www.taipeitimes.com/News/biz/archives/2022/04/22/2003776996](https://www.taipeitimes.com/News/biz/archives/2022/04/22/2003776996)
 - RSS feed: https://www.taipeitimes.com
 - date published: 2022-04-22 07:54:28+00:00

US’ chip bid ‘futile,’ Morris Chang says - Taipei Times


## Rapidly building interactive CLIs in Go with Bubbletea → Inngest Blog
 - [https://www.inngest.com/blog/interactive-clis-with-bubbletea](https://www.inngest.com/blog/interactive-clis-with-bubbletea)
 - RSS feed: https://www.inngest.com
 - date published: 2022-04-22 18:32:30+00:00




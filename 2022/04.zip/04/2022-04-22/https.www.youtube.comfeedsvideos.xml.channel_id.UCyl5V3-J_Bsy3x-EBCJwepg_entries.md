# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Babylon Bee Weak-ly News Update 4/23/2022: Goodbye Mask Mandates and The Easter Bunny Is President
 - [https://www.youtube.com/watch?v=fZvHBbW4tZI](https://www.youtube.com/watch?v=fZvHBbW4tZI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-04-23 00:00:00+00:00

Host Adam Yenser gives us the news of the week, including a Trump-appointed judge striking down the federal mask mandates, an Easter bunny is now telling the President what to do and where to go, and streaming services like Netflix and CNN+ are getting crushed.

Watch the full podcast here: https://youtu.be/nurAH7Y2eRE

Follow Adam on Youtube: https://www.youtube.com/user/adamyenser

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## The Babylon Bee Tours The Creation Museum
 - [https://www.youtube.com/watch?v=Ad_foP5csB0](https://www.youtube.com/watch?v=Ad_foP5csB0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-04-23 00:00:00+00:00

The world has been waiting thousands—not billions—of years for this amazing walkthrough of the Creation Museum. Join The Babylon Bee's Editor-in-Chief Kyle Mann and Answers in Genesis founder Ken Ham as they tour the museum and talk about God's creation.

Be sure to not miss when Kyle and Ken walked through the Ark Encounter: https://www.youtube.com/watch?v=N-Cz3SmAO_M

Check out Answers in Genesis: https://answersingenesis.org/

Learn more about the Creation Museum: https://creationmuseum.org/

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## The Bee Weekly: Doxxing Libs of TikTok and Rational Dating With Dennis Prager
 - [https://www.youtube.com/watch?v=nurAH7Y2eRE](https://www.youtube.com/watch?v=nurAH7Y2eRE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-04-22 00:00:00+00:00

It’s another week at the Bee and you can use our special link for 83% off Private Internet Access: https://www.privateinternetaccess.com/offer/recommended?channel=The%20Babylon%20Bee&source=podcastgeneral&coupon=3Y4M&aff_sub4=3Y4M&aff_id=12775

Kyle, Adam, and Emma Spies discuss the doxxing of Libs of TikTok, the demise of mask mandates on airlines, Disney losing their little autonomous zone, and much more! Adam Yenser brings Weakly News, Austin Robertson presents another edition of Bee Radio, and Dennis Prager sits down for a talk about dating—what else?—from a large desk in a dramatic power move.

This episode is brought to you by My Patriot Supply. Go to https://PrepareWithBee.com to get special pricing on your emergency food supply!

This episode is brought to you by Strikeman Laser Dry Fire Training System. Ammo is expensive, but with a laser dry fire training system from Strikeman you can still train to become proficient in the safe and accurate use of your weapon. Use promo code AMMOFREEDOM to save 20% off: https://www.strikeman.io/


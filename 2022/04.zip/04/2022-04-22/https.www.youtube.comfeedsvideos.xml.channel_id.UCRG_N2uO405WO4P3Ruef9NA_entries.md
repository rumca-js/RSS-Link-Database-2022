# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Huawei is turning things around
 - [https://www.youtube.com/watch?v=pbZTdf5fcXk](https://www.youtube.com/watch?v=pbZTdf5fcXk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2022-04-22 00:00:00+00:00

Get access to Nebula & Curiositystream: https://curiositystream.com/tfc
Watch Technorama: https://nebula.app/technorama

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  
 
►►► This video ◄◄◄  

This week Huawei teamed up with BMW, bringing the App Gallery to the new BMW i7, Netflix had a rough quarter and their stock stumbled, and the EU's USB C mandate got closer to becoming a reality.

Episode 93

This video on Nebula: 
https://nebula.app/videos/the-friday-checkout-huawei-is-turning-things-around
 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support my work directly:  https://flattr.com/@techaltar   

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:30 Release highlights
1:23 Huawei x BMW
3:06 Netflix tumbles
5:22 EU USB C mandate update


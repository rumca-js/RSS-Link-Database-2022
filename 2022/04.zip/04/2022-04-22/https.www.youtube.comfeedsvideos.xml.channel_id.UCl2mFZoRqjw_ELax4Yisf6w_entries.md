# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## An honest response to Kyle about onewheels, featuring Josh Haley
 - [https://www.youtube.com/watch?v=04W_L1g6dec](https://www.youtube.com/watch?v=04W_L1g6dec)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-04-23 00:00:00+00:00

🔵 QUESTIONS FOR KYLE DOERKSEN OF FUTURE MOTION: https://docs.google.com/document/d/1trWYQHo4D3RxrB_uaG7uniI3K7QGdIRz3H7il99r0QU/edit

Two weeks ago, Kyle posted a video called "A conversation with Kyle" https://www.youtube.com/watch?v=PnUD58kaNPc Conversations have two sides. Today, I'd like to share the opposing side of that conversation.

🔵 JW Batteries GoFundMe: https://www.gofundme.com/f/jw-batteries-being-sued-by-future-motion-makers-of

https://www.stokelifeservice.com/
https://facebook.com/permawheelie
https://instagram.com/permawheelie

🔵 https://tinyurl.com/rossmatrix
Post a message on screen http://bit.ly/postamessage Or else I will read it in the normal chat if it is not swamped. I am sorry if I miss your message, I do my best to read as much stuff as I can that is somewhat interesting even if it is a normal unpaid messagA talk with Josh Haley about Future Motion & the Onewheele, but the chat sometimes moves way too fast for me to get things.

## Drunk AMA livestream
 - [https://www.youtube.com/watch?v=wUGPUJy9A8Q](https://www.youtube.com/watch?v=wUGPUJy9A8Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-04-22 00:00:00+00:00

Support the stream: https://streamlabs.com/louisrossmann Post a message on screen http://bit.ly/postamessage Or else I will read it in the normal chat if it is not swamped. I am sorry if I miss your message, I do my best to read as much stuff as I can that is somewhat interesting even if it is a normal unpaid message, but the chat sometimes moves way too fast for me to get things. https://tinyurl.com/rossmatrix

## They still haven't rented this three years later....
 - [https://www.youtube.com/watch?v=VNJEAv-KWis](https://www.youtube.com/watch?v=VNJEAv-KWis)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-04-22 00:00:00+00:00




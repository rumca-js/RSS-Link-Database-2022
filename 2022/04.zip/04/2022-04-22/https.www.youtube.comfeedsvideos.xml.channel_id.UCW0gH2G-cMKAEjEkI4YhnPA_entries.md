# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Life of Elrond Half-elven | Tolkien Explained
 - [https://www.youtube.com/watch?v=623izLLd3eI](https://www.youtube.com/watch?v=623izLLd3eI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-04-23 00:00:00+00:00

Elrond is one of the most important characters throughout The Lord of the Rings, The Hobbit, and the Silmarillion. His life would be one full of significance, but also separation from those he loved. Through hardship and war, he would rise to become one of the wisest and most powerful rulers in Middle-earth.

Today's video is brought to you by SlideBelts!
Save 20% at Slidebelts.com with the code: NERDOFTHERINGS

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

To purchase artist work, check out these amazing artists!

Anna Podedworna - https://www.artstation.com/akreon
Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html
Donato Giancola - https://www.donatoarts.com/online-store/secure-store/Middle-earth-c34110463
Aronja Art - https://www.instagram.com/aronjaart/
Ivan Cavini - https://www.instagram.com/ivan_cavini/
Sara Morello - https://www.artstation.com/saramorello
Matěj Čadil - https://www.etsy.com/people/matejcadil
Tulikoura - https://www.deviantart.com/tulikoura
Aegeri - https://www.deviantart.com/aegeri

Elrond - WETA
Elrond and Celebrian - Kuliszu
Elrond and Elros - Kinko White
Elrond, Elros, and Maglor - Jenny Dolfen
Last Alliance - Skullb*st*rd
Elrond in the Second Age - Soni Alcorn-Hender
Downfall of Numenor - Donato Giancola
Isildur and the ring - Andrea Piparo
Elrond and Estel - Kuliszu
Elrond - Alystraea
Beleriand Map - Lamaarcana
Luthien in the court of Morgoth - Pete Amachree
Camping - Tolman Cotton
Elrond, Elros, Earendil, and Elwing - Jenny Dolfen
The Oath Has Been Awakened - Jenny Dolfen
Earendil and Elwing - Steamey
Maglor took pity upon them - Catherine Karina Chmiel
Maglor's Fostering - Turner Mohan
War of Wrath - Dracarysdrekkar7
Earendil and the Battle of Eagles and Dragons - Ted Nasmith
Maglor and Elrond - Jenny Dolfen
Manwe Sulimo - Christina Kraus
Beren and Luthien - Janka Lateckova
Tuor and Idril - Jenny Dolfen
Andunie - Ralph Damiani
Elros looking west from Numenor - Anke Eissmann
Andunie - David Greset
Elrond - Jenny Dolfen
Until the world is broken and remade - Jenny Dolfen
Armenelos - Ralph Damiani
Elrond - WETA
The Forging - Ralph Damiani
Sauron, the War of the Last Alliance - Matt DeMino
Sauron - WETA
Rivendell - Ted Nasmith
Journeying up the Gwathlo - Anke Eissmann
Drakar - David Greset
Rivendell at Sunset - Kuliszu
Celebrian - Jenny Dolfen
The Destroying Wave over Numenor - Kip Rasmussen
Minas Tirith - Ralph Damiani
Sauron - Jerry Vanderstelt
Noldor Armor - David Greset
The Last Alliance - Jenny Dolfen
Sauron vs Elendil and Gil-galad on Orodruin - Kip Rasmussen
Breaking of Narsil - John Howe
Isildur - Soni Alcorn-Hender
Isildur's Last Counselor - Anke Eissmann
Ohtar Takes Leave of Isildur - Anke Eissmann
The Death of Isildur - Anke Eismann
Elrond and Narsil - Donato Giancola
Isildur - Sara M Morello
Elrond - Steve Airola
Rivendell - Alan Lee
Arwen - Jenny Dolfen
Rivendell - Alan Lee
Rivendell - Ivan Cavini
Carn Dum, Angmar - Matthew Stewart
Witch King - LOTRO
Gondorian Shield - Fantasy Flight
Glorfindel returns to Rivendell - Jenny Dolfen
Rivendell - Ralph Damiani
Arthedain Rangers - Fantasy Flight
Elrond - Magali Villeneuve
Aragorn at Helm's Deep - Donato Giancola
Ringbearers - Jenny Dolfen
Elrond - Sarka Skorpikova
Orcs Debate - Turner Mohan
Lord of Rivendell - Kinko White
Celebrian - Jenny Dolfen
Grey Havens - Ralph Damiani
Rivendell - Jerry Vanderstelt
Elrond - Anke Eissmann
Orcrist - Ted Nasmith
Tuor Reaches Gondolin - Ted Nasmith
The Map of Thorin - Donato Giancola
Gandalf, Doors of Moria - Donato Giancola
Thorin Oakenshield - Anke Eissmann
Attack on Dol Guldur - Angus McBride
Strider - Matthew Stewart
Strider - CK Goksoy
Aragorn - Adam Middleton (WETA)
Tinuviel Reborn - Ted Nasmith
Arwen - Jerry Vanderstelt
Aragorn and Arwen - Sara M Morello
Arwen and Aragorn - Matthew Stewart
Elrond Half-elven - Donato Giancola
Arwen's Gift - Anke Eissmann
Imladris - Sara M Morello
Arwen and Elessar - Brothers Hildebrandt
Saruman - Donato Giancola
Saruman the White - Matt DeMino
Gandalf and Frodo examine the ring - Donato Giancola
Amon Sul - Tolman Cotton
Frodo's Recovery - Donato Giancola
Gandalf and Frodo in Rivendell - Anke Eissmann
Council of Elrond - Alan Lee
Gandalf and Frodo - Andrea Piparo
Sauron's Army at Barad-dur - Shadow of War
The Reforging of the Sword - Darrell Sweet
Fellowship in Hollin - Donato Giancola
What Say You - Bembiann
Thus Came Aragorn - Ted Nasmith
The Last Debate - Alan Lee
Elrohir - Magali Villeneuve
Rangers Scout the Ruins of Barad-dur - Ted Nasmith
Coronation - Anke Eissmann
The Steward and the King - Anke Eissmann
Luthien - Jenny Dolfen
Departure at the Grey Havens - Ted Nasmith
Grey Havens - Tolman Cotton
A Summer Ride - Kuliszu

#elrond #lordoftherings #tolkien


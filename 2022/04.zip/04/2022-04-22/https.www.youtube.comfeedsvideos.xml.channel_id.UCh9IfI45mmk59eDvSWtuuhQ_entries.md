# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## When Your Plastic Bottle Finally Degrades
 - [https://www.youtube.com/watch?v=TENglVcYKdw](https://www.youtube.com/watch?v=TENglVcYKdw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2022-04-22 00:00:00+00:00

Offset your carbon footprint with me on Wren! We'll plant 10 extra trees for the first 100 people who sign up! http://wren.co/start/ryangeorge

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats.
Twitter/Instagram: @TheRyanGeorge

#EarthDay


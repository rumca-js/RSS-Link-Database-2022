# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## 1 Księga Kronik || Rozdział 23
 - [https://www.youtube.com/watch?v=2rlDyhIE-pw](https://www.youtube.com/watch?v=2rlDyhIE-pw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-04-23 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#285] Nie wsadzaj palca w ranę
 - [https://www.youtube.com/watch?v=zbLkeP3IF4o](https://www.youtube.com/watch?v=zbLkeP3IF4o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-04-23 00:00:00+00:00

#cnn #dobrewiadomości    @Langustanapalmie 

Kazanko do okienka, czyli komentarz do niedzielnych czytań.

Niedziela, II Tydzień Wielkanocny, Rok C, II
Druga Niedziela Wielkanocna, czyli Miłosierdzia Bożego

1. czytanie (Dz 5, 12-16)

Wiele znaków i cudów działo się wśród ludu przez ręce apostołów. Trzymali się wszyscy razem w krużganku Salomona. A z obcych nikt nie miał odwagi dołączyć się do nich, lud zaś ich wychwalał.
Coraz bardziej też rosła liczba mężczyzn i kobiet przyjmujących wiarę w Pana. Wynoszono też chorych na ulice i kładziono na łożach i noszach, aby choć cień przechodzącego Piotra padł na któregoś z nich. Także z miast sąsiednich zbiegały się wielkie rzesze do Jeruzalem, znosząc chorych i dręczonych przez duchy nieczyste, a wszyscy doznawali uzdrowienia.

2. czytanie (Ap 1, 9-11a. 12-13. 17-19)

Ja, Jan, wasz brat i współuczestnik w ucisku i królestwie, i wytrwaniu w Jezusie, byłem na wyspie, zwanej Patmos, z powodu słowa Bożego i świadectwa Jezusa. Doznałem zachwycenia w dzień Pański i posłyszałem za sobą potężny głos, jak gdyby trąby mówiącej: «Co widzisz, napisz w księdze i poślij siedmiu Kościołom: do Efezu, Smyrny, Pergamonu, Tiatyry, Sardes, Filadelfii i Laodycei».
I obróciłem się, by patrzeć, co to za głos do mnie mówił; a obróciwszy się, ujrzałem siedem złotych świeczników i pośród świeczników kogoś podobnego do Syna Człowieczego, przyobleczonego w szatę do stóp i przepasanego na piersiach złotym pasem.
Kiedy Go ujrzałem, do stóp Jego padłem jak martwy, a On położył na mnie prawą rękę, mówiąc: «Przestań się lękać! Ja jestem Pierwszy i Ostatni, i Żyjący. Byłem umarły, a oto jestem żyjący na wieki wieków i mam klucze śmierci i Otchłani. Napisz więc to, co widziałeś i co jest, i co potem musi się stać».

Ewangelia (J 20, 19-31)

Wieczorem w dniu zmartwychwstania, tam gdzie przebywali uczniowie, choć drzwi były zamknięte z obawy przed Żydami, przyszedł Jezus, stanął pośrodku i rzekł do nich: «Pokój wam!» A to powiedziawszy, pokazał im ręce i bok. Uradowali się zatem uczniowie, ujrzawszy Pana.
A Jezus znowu rzekł do nich: «Pokój wam! Jak Ojciec Mnie posłał, tak i Ja was posyłam». Po tych słowach tchnął na nich i powiedział im: «Weźmijcie Ducha Świętego! Którym odpuścicie grzechy, są im odpuszczone, a którym zatrzymacie, są im zatrzymane».
Ale Tomasz, jeden z Dwunastu, zwany Didymos, nie był razem z nimi, kiedy przyszedł Jezus. Inni więc uczniowie mówili do niego: «Widzieliśmy Pana!»
Ale on rzekł do nich: «Jeżeli na rękach Jego nie zobaczę śladu gwoździ i nie włożę palca mego w miejsce gwoździ, i ręki mojej nie włożę w bok Jego, nie uwierzę».
A po ośmiu dniach, kiedy uczniowie Jego byli znowu wewnątrz domu i Tomasz z nimi, Jezus przyszedł, choć drzwi były zamknięte, stanął pośrodku i rzekł: «Pokój wam!» Następnie rzekł do Tomasza: «Podnieś tutaj swój palec i zobacz moje ręce. Podnieś rękę i włóż w mój bok, i nie bądź niedowiarkiem, lecz wierzącym».
Tomasz w odpowiedzi rzekł do Niego: «Pan mój i Bóg mój!»
Powiedział mu Jezus: «Uwierzyłeś dlatego, że Mnie ujrzałeś? Błogosławieni, którzy nie widzieli, a uwierzyli».
I wiele innych znaków, których nie zapisano w tej księdze, uczynił Jezus wobec uczniów. Te zaś zapisano, abyście wierzyli, że Jezus jest Mesjaszem, Synem Bożym, i abyście wierząc, mieli życie w imię Jego.

________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

Niedzielnik na ROK C
→ https://wdrodze.pl/produkt/niedzielnik-c-komentarze-do-czytan-adam-szustak/

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#1074] Otwiera
 - [https://www.youtube.com/watch?v=t0YdUp1WCjg](https://www.youtube.com/watch?v=t0YdUp1WCjg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-04-23 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
Strona zbiórki → https://charytatywnie.fundacjamalak.pl/

Tradycyjne przelewy:
Nr konta do wpłat w PLN: 42 2490 0005 0000 4600 1184 3564 
IBAN: PL 42 2490 0005 0000 4600 1184 3564
Tytułem: UKRAINA

Fundacja MALAK
ul. Śliwkowa 4
31-982 Kraków
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## 1 Księga Kronik || Rozdział 22
 - [https://www.youtube.com/watch?v=oIY5PAxr6UI](https://www.youtube.com/watch?v=oIY5PAxr6UI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-04-22 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#1073] Wino
 - [https://www.youtube.com/watch?v=9nwrBqIamHE](https://www.youtube.com/watch?v=9nwrBqIamHE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-04-22 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
Strona zbiórki → https://charytatywnie.fundacjamalak.pl/

Tradycyjne przelewy:
Nr konta do wpłat w PLN: 42 2490 0005 0000 4600 1184 3564 
IBAN: PL 42 2490 0005 0000 4600 1184 3564
Tytułem: UKRAINA

Fundacja MALAK
ul. Śliwkowa 4
31-982 Kraków
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.


# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## Razer makes a Linux laptop, Duck Duck Go Browser, and Ubuntu 22.04 - Linux and Open Source News
 - [https://www.youtube.com/watch?v=uLSSrJNIb3k](https://www.youtube.com/watch?v=uLSSrJNIb3k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2022-04-22 00:00:00+00:00

Install the Startpage Privacy protection extension for free: https://add.startpage.com/en/protection/?campaign=4&source=aff 

Get your Linux desktop or laptop here: https://slimbook.es/en/


👏 SUPPORT THE CHANNEL:
Get access to an exclusive weekly podcast, vote on the next topics I cover, and get your name in the credits:

YOUTUBE: https://www.youtube.com/channel/UC5UAwBUum7CPN5buc-_N1Fw/join

Patreon: https://www.patreon.com/thelinuxexperiment

Or, you can donate whatever you want: https://paypal.me/thelinuxexp?locale.x=fr_FR

You can also protect your privacy by using this extension from Startpage, each install helps the channel with a small commission: https://add.startpage.com/en/protection/?campaign=4&source=aff 

🏆 FOLLOW ME ELSEWHERE:
Linux news in Youtube Shorts format: https://www.youtube.com/channel/UCtZp0mK9IBrpS2-jNzMZmoA

Join us on our Discord server: https://discord.gg/xK7ukavWmQ

Twitter : http://twitter.com/thelinuxEXP

My Gaming on Linux Channel: https://www.youtube.com/channel/UCaw_Lz7oifDb-PZCAcZ07kw

📷 GEAR I USE:
Sony Alpha A6600 Mirrorless Camera: https://amzn.to/30zKyn7
Sigma 56mm Fixed Prime Lens: https://amzn.to/3aRvK5l
Logitech MX Master 3 Mouse: https://amzn.to/3BVI0Od
Bluetooth Space Grey Mac Keyboard: https://amzn.to/3jcJETZ
Logitech Brio 4K Webcam: https://amzn.to/3jgeTh9
LG Curved Ultrawide Monitor: https://amzn.to/3pcTVDH
Logitech White Speakers: https://amzn.to/3n6wSb0
Xbox Controller: https://amzn.to/3BWmIA3
*Amazon Links are affiliate codes and generate small commissions to support the channel*


00:00 Intro
00:41 Sponsor: Stay private online with this extensions
01:48 KDE Gear updates
02:55 This week on KDE Plasma
03:51 GNOME app updates
04:52 SUSE is working on something intriguing
05:50 Solaris is now more open
06:37 Razer made a laptop running Linux
07:46 Starlabs now has a desktop PC with Linux
08:48 The Starbook now has Ryzen CPUs
09:55 More details about the Duck Duck Go Browser
10:55 Ubuntu 22.04 was released
11:52 Borked games on Proton DB going down fast
12:59 2200 Games on Deck
13:46 Gaming Flatpak helps you game on Linux
14:49 Proton 7.0-2 is out
15:56 Sponsor: Get your laptop or Desktop with Linux from Slimbook
16:37 Support the channel


KDE Gear 22.04 was released.
https://kde.org/announcements/gear/22.04.0/

There's another one of these nice weekly KDE blog posts.
https://pointieststick.com/2022/04/14/this-week-in-kde-stable-desktop-icons-and-even-better-gestures/

Not to be outdone, GNOME application developers are also hard at work!
https://thisweek.gnome.org/posts/2022/04/twig-39/

SUSE Linux is developing what they call an adaptable Linux platform, or ALP for short.
https://linuxiac.com/suse-linux-enterprise-alp/

There's a new version of Solaris 11.4 which is freely available
https://www.phoronix.com/scan.php?page=news_item&px=Oracle-Solaris-11.4-CBE

In an amazing development, Razer teamed up with Lambda labs to make the Tensorbook
https://linuxiac.com/razer-lambda-tensorbook-linux-laptop/

Starlabs, a manufacturer of devices shipping with Linux out of the box, has a new small form factor desktop to complement their laptop lineup.
https://9to5linux.com/star-labs-unveil-their-first-amd-powered-mini-linux-pc-with-coreboot-support

Still on Starlabs, the Starbook now has the option to use Ryzen CPUs
https://9to5linux.com/you-can-now-pre-order-the-starbook-mk-v-linux-laptop-with-an-amd-ryzen-7-cpu

Duck Duck Go gave more details about their incoming web browser designed for privacy.
https://www.toolinux.com/?duckduckgo-navigateur-web

Ubuntu 22.04 was released
https://www.youtube.com/watch?v=oUkl1NrsBI8

The number of games marked as Borked on ProtonDB has been decreasing rapidly. 
https://boilingsteam.com/protons-recent-push-to-reduce-the-number-of-borked-games/
https://boilingsteam.com/ubuntu-continues-falling-like-a-rock-as-a-gaming-distro/

Another week, another milestone for the Steam Deck, which now reaches 2200 games marked as verified, or playable.
https://boilingsteam.com/2200-games-on-the-steam-deck/

Gaming Flatpak is a script that will let you install tons of gaming related software
https://github.com/Chevek/Gaming-Flatpak

Proton also got a new update, version 7.0-2
https://github.com/ValveSoftware/Proton/wiki/Changelog#70-2


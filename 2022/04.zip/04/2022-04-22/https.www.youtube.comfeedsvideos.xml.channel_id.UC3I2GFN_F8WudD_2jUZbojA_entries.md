# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Hurray For The Riff Raff - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=Bqgsikd6fcA](https://www.youtube.com/watch?v=Bqgsikd6fcA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-22 00:00:00+00:00

http://KEXP.ORG presents Hurray For The Riff Raff performing live in the KEXP studio. Recorded April 1, 2022.

Songs:
Pierced Arrows
Pointed At The Sun
Saga
Rhododendron

Alynda Segarra - Guitar / Vocals
Howe Pearson - Keys / Bass
Matt Peterson - Keys / Guitar
Yan Westerlund - Drums

Host: Cheryl Waters
Audio Engineers: Mike Sapienza & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Ettie Wahl
Editor: Jim Beckmann

http://www.hurrayfortheriffraff.com
http://kexp.org

## Hurray For The Riff Raff - Pierced Arrows (Live on KEXP)
 - [https://www.youtube.com/watch?v=Xpd90I-Tzhk](https://www.youtube.com/watch?v=Xpd90I-Tzhk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-22 00:00:00+00:00

http://KEXP.ORG presents Hurray For The Riff Raff performing “Pierced Arrows” live in the KEXP studio. Recorded April 1, 2022.

Alynda Segarra - Guitar / Vocals
Howe Pearson - Keys / Bass
Matt Peterson - Keys / Guitar
Yan Westerlund - Drums

Host: Cheryl Waters
Audio Engineers: Mike Sapienza & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Ettie Wahl
Editor: Jim Beckmann

http://www.hurrayfortheriffraff.com
http://kexp.org

## Hurray For The Riff Raff - Pointed At The Sun (Live on KEXP)
 - [https://www.youtube.com/watch?v=v8Wa76uJFSU](https://www.youtube.com/watch?v=v8Wa76uJFSU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-22 00:00:00+00:00

http://KEXP.ORG presents Hurray For The Riff Raff performing “Pointed At The Sun” live in the KEXP studio. Recorded April 1, 2022.

Alynda Segarra - Guitar / Vocals
Howe Pearson - Keys / Bass
Matt Peterson - Keys / Guitar
Yan Westerlund - Drums

Host: Cheryl Waters
Audio Engineers: Mike Sapienza & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Ettie Wahl
Editor: Jim Beckmann

http://www.hurrayfortheriffraff.com
http://kexp.org

## Hurray For The Riff Raff - Rhododendron (Live on KEXP)
 - [https://www.youtube.com/watch?v=WjgHj4_zB8Y](https://www.youtube.com/watch?v=WjgHj4_zB8Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-22 00:00:00+00:00

http://KEXP.ORG presents Hurray For The Riff Raff performing “Rhododendron” live in the KEXP studio. Recorded April 1, 2022.

Alynda Segarra - Guitar / Vocals
Howe Pearson - Keys / Bass
Matt Peterson - Keys / Guitar
Yan Westerlund - Drums

Host: Cheryl Waters
Audio Engineers: Mike Sapienza & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Ettie Wahl
Editor: Jim Beckmann

http://www.hurrayfortheriffraff.com
http://kexp.org

## Hurray For The Riff Raff - Saga (Live on KEXP)
 - [https://www.youtube.com/watch?v=TMg1Uh9jFaU](https://www.youtube.com/watch?v=TMg1Uh9jFaU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-22 00:00:00+00:00

http://KEXP.ORG presents Hurray For The Riff Raff performing “Saga” live in the KEXP studio. Recorded April 1, 2022.

Alynda Segarra - Guitar / Vocals
Howe Pearson - Keys / Bass
Matt Peterson - Keys / Guitar
Yan Westerlund - Drums

Host: Cheryl Waters
Audio Engineers: Mike Sapienza & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Ettie Wahl
Editor: Jim Beckmann

http://www.hurrayfortheriffraff.com
http://kexp.org


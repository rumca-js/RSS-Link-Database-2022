# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## Why Hollywood Now REFUSES to Bow Down to China
 - [https://www.youtube.com/watch?v=9aLzzg3xwps](https://www.youtube.com/watch?v=9aLzzg3xwps)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2022-04-22 00:00:00+00:00

Chris Fenton, a Hollywood executive responsible for successfully pairing up the USA and China's movie industries tells all about how it happened with films like Iron Man 3, and Looper, and how it all went too far, and a necessary rebalance is needed. 

Chris Fenton's Book - Feeding the Dragon 
https://www.amazon.com/Feeding-Dragon-Trillion-Hollywood-American/dp/1642935867
https://feedingthedragonbook.com/
Chris Fenton Twitter - https://twitter.com/TheDragonFeeder

◘ Support me on Patreon to talk to me directly and support my work - http://www.patreon.com/laowhy86
◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

Crypto support 
◘ Bitcoin - bc1qrvvga0c4kn69rlte47q0tzrhugn9pf426tqhvm
◘ ETH -  0x456E5A9B875d4eF8DCb70eB1F7Fa376C520b206C

My documentaries - 
◘ Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina
◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

ADVChina - https://www.youtube.com/advchina
SerpentZA - https://www.youtube.com/serpentza
ADVPodcasts - https://www.youtube.com/advpodcasts
China Fact Chasers - https://www.youtube.com/c/ChinaFactChasers

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

Music -
Big Bad Beats
https://www.youtube.com/c/bigbadbeats

Thumbnail elements - Hollywood Reporter 
The Yale Politic


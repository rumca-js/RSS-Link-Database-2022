## Stop Validating Email Addresses With Regex
 - [https://davidcel.is/posts/stop-validating-email-addresses-with-regex/](https://davidcel.is/posts/stop-validating-email-addresses-with-regex/)
 - RSS feed: https://davidcel.is
 - date published: 2022-04-22 20:44:45.932735+00:00

Just stop, y’all. It’s a waste of your time and your effort. Put down your Google search for an email regular expression, take a step back, and breathe. Ther...


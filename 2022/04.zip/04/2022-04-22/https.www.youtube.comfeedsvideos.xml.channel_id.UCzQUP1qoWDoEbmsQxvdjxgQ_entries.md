# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe on the Video of Mike Tyson Being Harassed on a Plane
 - [https://www.youtube.com/watch?v=Wjx7LaqEHJo](https://www.youtube.com/watch?v=Wjx7LaqEHJo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-04-23 00:00:00+00:00

Taken from JRE #1808 w/Dan Soder:
https://open.spotify.com/episode/1LpqRZgJzula5p71rIhRyo?si=48969dd62f554e27

## Why Are Airlines Restraining People with Duct Tape?
 - [https://www.youtube.com/watch?v=pLoiUm8JTkI](https://www.youtube.com/watch?v=pLoiUm8JTkI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-04-23 00:00:00+00:00

Taken from JRE #1808 w/Dan Soder:
https://open.spotify.com/episode/1LpqRZgJzula5p71rIhRyo?si=f766943a0e6e48ae

## Douglas Murray Clarifies the Idea of Being "Lucky"
 - [https://www.youtube.com/watch?v=kmS8oJ6aHjE](https://www.youtube.com/watch?v=kmS8oJ6aHjE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-04-22 00:00:00+00:00

Taken from JRE #1807 w/Douglas Murray:
https://open.spotify.com/episode/38irHbd6pdQkZWazZ029hq?si=516c83dbbadf4292

## Douglas Murray on People's Need for Religion
 - [https://www.youtube.com/watch?v=QCJUEqppqNk](https://www.youtube.com/watch?v=QCJUEqppqNk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-04-22 00:00:00+00:00

Taken from JRE #1807 w/Douglas Murray:
https://open.spotify.com/episode/38irHbd6pdQkZWazZ029hq?si=516c83dbbadf4292


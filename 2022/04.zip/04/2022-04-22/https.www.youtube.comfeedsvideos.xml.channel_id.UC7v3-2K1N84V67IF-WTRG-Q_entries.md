# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Northman - Movie Review
 - [https://www.youtube.com/watch?v=ADU_3yp_KDs](https://www.youtube.com/watch?v=ADU_3yp_KDs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-04-23 00:00:00+00:00

Director Robert Eggers brings a Norse epic of revenge to life. Here's my review for THE NORTHMAN

#TheNorthman

## The Unbearable Weight of Massive Talent - Movie Review
 - [https://www.youtube.com/watch?v=HRkxXBuwHrU](https://www.youtube.com/watch?v=HRkxXBuwHrU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-04-22 00:00:00+00:00

Get the exclusive NordVPN deal here: https://nordvpn.com/jahns. It’s risk free with Nord’s 30 day money-back guarantee!
Thanks to NordVPN for sponsoring this video.

Nicholas Cage plays Nick Cage in a buddy spy comedy that celebrates the work of the man himself. Here's my review for THE UNBEARABLE WEIGHT OF MASSIVE TALENT!

#MassiveTalent #NickCage


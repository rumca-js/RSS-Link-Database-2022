# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## Synthwave Hardware Jam // Novation Circuit Tracks // I'm Something of a Scientist Myself
 - [https://www.youtube.com/watch?v=dQe91ecllp0](https://www.youtube.com/watch?v=dQe91ecllp0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2022-04-23 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong Watch the original remix: https://youtu.be/McQ7ops4zk0
Turn on captions for equipment & workflow explanation

Music-nerd stuff:
This jam is DAWless. The @NovationTV Circuit Tracks is the brain and sequencer. The opening synth and chords are the Circuit's internal Synth 2, with macro controls (e.g. Filter and Glide) controlled by the Korg Nanokey Studio. The bass is using internal Synth 1. The drums use Drum Tracks 1-3 (kick, snare, hats) and Drum Track 4 is used for the vocal sample. Only 1 MIDI track is being used to control the @ArturiaOfficial Microfreak for the 7 note arp. I use Scenes on the Circuit to go from one section to another, or to 'mute' tracks (it's a workaround - to mute, I use a blank pattern)
For guitars I use a Joyo American Sound for amp and @tcelectronic Echobrain for delay, going into a @SingularSoundOfficial Aeros Loop Studio, with a @DisasterAreaDesigns Midi Baby on the floor to trigger a loop record and to trigger playbank when the loop recording is done.
Recorded as stereo (Circuit) and multitracks (guitar loop and solo) into a Zoom H5 and mastered in Logic Pro X (some eq and reverb and compression).


# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## $138 Motorola Edge 5G - Repair Taken To The Edge
 - [https://www.youtube.com/watch?v=QaIpZuy-s-E](https://www.youtube.com/watch?v=QaIpZuy-s-E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2022-04-23 00:00:00+00:00

The problems at the edge.
Get parts, tools and repair guides at iFixit:
Shop US: https://iFixit.com/hughjeffreys
Shop AU: https://ifix.gd/hughjeffreysau
30% OFF using code "SPICYPILLOW" (AU Only)

Tools I Use: https://www.hughjeffreys.com/tools
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com
Store: https://www.hughjeffreys.com/store
Instagram: http://instagram.com/hughjeffreys
---------------------------------------------------------------------------------------


(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)


# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Dlaczego dzieci zadają tyle pytań... a potem przestają?
 - [https://www.youtube.com/watch?v=xhD2ojikohU](https://www.youtube.com/watch?v=xhD2ojikohU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2022-04-23 00:00:00+00:00

Nasza edukacyjna książka dla dzieci
► https://naukowybelkot.pl/product/lelony-odkrywaja-dlaczego-niebo-jest-niebieskie

👉 Patronite ► https://patronite.pl/NaukowyBelkot 

📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

No więc - mam pewne ogłoszenie w sprawie dziecięcych pytań

===
Wyznaczanie liczby pi z dzieckiem
👉 https://www.youtube.com/watch?v=Ip8GDvQY3Hw

Neotenia
👉 https://youtu.be/yTaWIAtIXVY

===
Rozkład jazdy:

0:00 Encyklopedia na główce szpilki
3:01 Definicje, 302 neurony, definicje
4:40 Gry i zabawy
5:58 Przyjrzyjmy się mózgowi
7:05 Nauczmy się czegoś
9:05 Ewolucyjny sens
11:30 Dlaczego przestajemy pytać
13:18 Rola rodzica
14:30 Co można zrobić z tym wszystkim

===
Źródła (wybrane):

M. Jempa i in. - Neural mechanisms underlying the induction and relief of perceptual curiosity
C. Kidd i in. - The psychology and neuroscience of curiosity
B. Sadowski - Biologiczne mechanizmy zachowania się ludzi i zwierząt
G. Ofer i in. - Curiosity: Reflections on Its Nature and Functions
G. Loewenstein - The psychology of curiosity: a review and reinterpretation
https://www.opencolleges.edu.au/informed/features/importance-kids-asking-questions/
https://www.curiousworld.com/blog/why-do-kids-ask-so-many-questions
https://theswaddle.com/how-to-stimulate-curiosity-questions/
https://www.livescience.com/5892-kids.html


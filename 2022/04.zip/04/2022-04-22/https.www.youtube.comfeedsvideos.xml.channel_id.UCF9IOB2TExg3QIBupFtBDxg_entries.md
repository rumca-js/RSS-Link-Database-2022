# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## UK, Groundhog day
 - [https://www.youtube.com/watch?v=6m20pwFyz0s](https://www.youtube.com/watch?v=6m20pwFyz0s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-04-22 00:00:00+00:00

Covid symptom study

https://covid.joinzoe.com

Cases, + 217,150 = 3,763,847

https://www.youtube.com/watch?v=x-AIM_yHCs4

UK R = 0.9

Cases, down 19% on the week

One in 17 symptomatic

Cases down in all age groups, over 75 coming down faster

Cases down in all regions

UK hospitalisations remain relatively high

Symptoms

Runny nose, 84%

Fatigue, 72%

Headache, 69%

Sore throat, 69%

Sneezing, 69%

Persistent cough, 56%

Hoarse, 49%

Chills or shivers, 37%

Joint pains, 34%

Fever, 32%

Dizzy, 32%

Brain fog, 29%

Sore eyes, 26%

Altered smell sensation, 25%

Muscle pains, 23%

Lower back pain, 23%

Swollen glands, 21%

Skipped meals, 10%

Ear ringing, 19%

Diarrhoea

ONS

https://www.ons.gov.uk/peoplepopulationandcommunity/healthandsocialcare/conditionsanddiseases/articles/coronaviruscovid19/latestinsights

W/E 9th April

6.92% in England (1 in 14 people) 

7.63% in Wales (1 in 13 people) 

5.23% in Northern Ireland 
(1 in 19 people) 

5.98% in Scotland (1 in 17 people)

Self-reported long COVID as of 5 March 2022

1.7 million people

2.7% of the population

69% long COVID symptoms at least 12 weeks

45% at least one year

Fatigue, 51%

Shortness of breath, 34%

Loss of smell, 28%

Muscle ache, 24%

Symptoms adversely affected the day-to-day activities, 67%
 
Antibodies

Infected with COVID-19 or vaccinated

Week beginning 28 March 2022

Percentage of adults, antibodies above a 179 nanograms per millilitre (ng/ml) 

98.9% in England 

98.8% in Wales 

99.2% in Northern Ireland 

99.0% in Scotland


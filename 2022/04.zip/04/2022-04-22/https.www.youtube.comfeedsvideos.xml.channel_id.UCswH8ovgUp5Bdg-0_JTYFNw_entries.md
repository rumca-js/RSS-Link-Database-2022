# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Here We Go Again
 - [https://www.youtube.com/watch?v=cBH005RSqh4](https://www.youtube.com/watch?v=cBH005RSqh4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-04-23 00:00:00+00:00

A new California bill threatens to strip doctors of their medical licenses for spreading “misinformation” – where else are we seeing this level of state control… hmmm?
#Covid #Pandemic #Misinformation 

References
https://reclaimthenet.org/california-assembly-bill-2098-censorship/
https://bariweiss.substack.com/p/a-warning-from-shanghai?s=r

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## This Is What Julian Assange Warned Us About
 - [https://www.youtube.com/watch?v=JqjRXiprVh8](https://www.youtube.com/watch?v=JqjRXiprVh8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-04-22 00:00:00+00:00

Julian Assange is one step closer to a US trial under the Espionage Act, meaning that while the US denounces Russian war crimes it’s simultaneously imprisoning a journalist for exposing its own war crimes. #JulianAssange #WikiLeaks #Criminal 

References
https://scheerpost.com/2021/12/13/hedges-the-execution-of-julian-assange/
https://caitlinjohnstone.substack.com/p/the-us-cries-about-war-crimes-while?s=r

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


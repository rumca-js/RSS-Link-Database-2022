# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## $1,500 LotR Edition💰 New Dresden Novella📘 Minecraft Movie⛏️-FANTASY NEWS
 - [https://www.youtube.com/watch?v=miYDH_erMIE](https://www.youtube.com/watch?v=miYDH_erMIE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-04-22 00:00:00+00:00

Let's talk about the flood of Lord of the Rings News! 
Checkout Campfire Today:  https://www.campfirewriting.com/write/for-novelists?utm_source=youtube&utm_medium=video&utm_campaign=DG_Q1_22 

New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.designbyhumans.com/shop/FantasyNews/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

News:

00:00 Intro 

00:26 Most Expensive LotR Edition: https://www.foliosociety.com/usa/rings 

01:20 Lotr Images: https://twitter.com/lotronprime/status/1516457357466775557?s=21&t=VvPZJpZQ977L1gKjH3zJkw 

01:57 New LotR Covers: https://www.reddit.com/r/lotr/comments/u76msm/new_lotr_covers_to_be_released_this_year/?utm_medium=android_app&utm_source=share 

03:07 LotR Playing Cards: https://www.kickstarter.com/projects/kingswildproject/the-lord-of-the-rings-playing-cards-vol-1 

04:45 Martin’s Troll: https://georgerrmartin.com/notablog/2022/04/20/the-winds-of-june/ 

06:00 New Dresden Novella: https://www.audible.com/pd/The-Law-Audiobook/B09Y286JK6 

06:31 Netflix falling down: https://www.hollywoodreporter.com/business/digital/netflix-q1-2022-earnings-1235132028/ 

09:30 Love Death Season 3: https://www.polygon.com/23031898/love-death-robots-trailer-release-date-season-3-netflix 

10:01 Andy Serkis Directing Animal Farm: https://deadline.com/2022/04/andy-serkis-to-direct-animated-adaptation-of-george-orwells-animal-farm-1235005933/ 

10:25 Spiderverse release dates: https://tinyurl.com/mrx9fuuv 
https://twitter.com/DiscussingFilm/status/1516949854148255744?t=gqmRkhEtkqZr1csAPrXFMg&s=09

10:49 Water Dancer Adaptation: https://mobile.twitter.com/DiscussingFilm/status/1516127828366049286?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Etweet 

11:51 Minecraft Movie: https://twitter.com/DiscussingFilm/status/1516120055251148802


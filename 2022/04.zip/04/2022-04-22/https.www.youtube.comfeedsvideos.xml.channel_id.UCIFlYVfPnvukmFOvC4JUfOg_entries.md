## #6 Przeprowadzka do Teksasu part(1/2)
 - [https://www.youtube.com/watch?v=elAZdJIsi4E](https://www.youtube.com/watch?v=elAZdJIsi4E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIFlYVfPnvukmFOvC4JUfOg
 - date published: 2022-04-22 00:00:00+00:00

Baklava, pęknięta rura i pierwszy hike w tym roku.
🧗🏻Wesprzyj moje przygody na patronite: https://patronite.pl/Nejtan
📷 Instagram: https://www.instagram.com/nejthan
📜 Napisz do mnie: swiatwedlugnejtana@gmail.com
🎵 Muzyka: https://share.epidemicsound.com/m7uq26

2022 Trip z  @Vlog Casha   po Florydzie https://bit.ly/3uueZGV
2021 Trip z  @Vlog Casha   po zachodzie Usa i Alaska
https://bit.ly/3D6ClpI
#swiatwedlugnejtana #nejtan


## Shitposting as a Learning Style - Last Week in AWS Blog
 - [https://www.lastweekinaws.com/blog/shitposting-as-a-learning-style/](https://www.lastweekinaws.com/blog/shitposting-as-a-learning-style/)
 - RSS feed: https://www.lastweekinaws.com
 - date published: 2022-04-22 18:14:18.946372+00:00

Everyone learns in different ways. Some methods work super well for one person, while someone else just doesn't "get it." While most of us know this intellectually, it's easy to forget that other people aren't all like we are. I'm speaking in this case, of course, about myself.


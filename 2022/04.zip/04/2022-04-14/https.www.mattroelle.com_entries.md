## Matt Roelle | Fennel: The Practical Lisp
 - [https://www.mattroelle.com/fennel-the-practical-lisp](https://www.mattroelle.com/fennel-the-practical-lisp)
 - RSS feed: https://www.mattroelle.com
 - date published: 2022-04-14 20:24:30.683833+00:00




# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Fighting Fake News with Alex Marlow | A Bee Interview
 - [https://www.youtube.com/watch?v=CqHkmfM6ZcU](https://www.youtube.com/watch?v=CqHkmfM6ZcU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-04-15 00:00:00+00:00

Check out Private Internet Access here using our exclusive link to get the deal: http://privateinternetaccess.com/TheBabylonBee

Alex Marlow is the Editor-in-Chief of Breitbart News and hosts the Breitbart News Daily Podcast. Marlow faces Adam Yenser’s Real or Fake Headlines challenge and reminisces about Joe Biden’s most memorable speeches. Marlow recently published a book called Breaking the News: Exposing the Establishment Media’s Hidden Deals and Secret Corruption, which is available now: https://www.amazon.com/Breaking-News-Exposing-Establishment-Corruption/dp/B08PVZXZDX/ref=sr_1_1?crid=35CZXRY4M8D5D&keywords=breaking+the+news+alex+marlow&qid=1649958208&sprefix=breaking+the+news+alex+marlo%2Caps%2C176&sr=8-1

This episode is also brought to you by Faithful Counseling. Get help today from people who share you faith and values: https://faithfulcounseling.com/babylonbee

## Twitter Employee Undergoes Therapy Over Elon Musk Takeover
 - [https://www.youtube.com/watch?v=rFNCsSBnYVg](https://www.youtube.com/watch?v=rFNCsSBnYVg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-04-15 00:00:00+00:00

Mandy is absolutely triggered by Twitter's possible takeover by Elon Musk. She attends a Twitter-sponsored therapy session to help her cope.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## The Babylon Bee Tours The Ark Encounter
 - [https://www.youtube.com/watch?v=N-Cz3SmAO_M](https://www.youtube.com/watch?v=N-Cz3SmAO_M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-04-14 00:00:00+00:00

You might think the perfect crossover doesn't exist, but it does. It's The Babylon Bee doing the Ark Encounter! Join Editor-in-Chief Kyle Mann and Answers in Genesis founder Ken Ham as they tour the giant replica of Noah's Ark in Kentucky. It's real, and it's spectacular.

Check out Answers in Genesis: https://answersingenesis.org/

Learn more about the Ark Encounter: https://arkencounter.com/

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


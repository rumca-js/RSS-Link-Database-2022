# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Indigo De Souza - Bad Dream (Live on KEXP)
 - [https://www.youtube.com/watch?v=gxMFSgSCaOo](https://www.youtube.com/watch?v=gxMFSgSCaOo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-15 00:00:00+00:00

http://KEXP.ORG presents Indigo De Souza performing “Bad Dream” live in the KEXP studio. Recorded March 28, 2022.

Indigo De Souza - Vocals / Guitar
Dexter Webb - Guitar
Zack Kardon - Bass
Avery Sullivan - Drums

Host: Larry Mizell, Jr.
Audio Engineer: Kevin Suggs
Audio Mixer: Alex Farrar
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.indigodesouza.com
http://kexp.org

## Indigo De Souza - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=8XTRX2DCUDU](https://www.youtube.com/watch?v=8XTRX2DCUDU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-15 00:00:00+00:00

http://KEXP.ORG presents Indigo De Souza performing live in the KEXP studio. Recorded March 28, 2022.

Songs:
Kill Me
Late Night Crawler
Bad Dream
Real Pain

Indigo De Souza - Vocals / Guitar
Dexter Webb - Guitar
Zack Kardon - Bass
Avery Sullivan - Drums

Host: Larry Mizell, Jr.
Audio Engineer: Kevin Suggs
Audio Mixer: Alex Farrar
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.indigodesouza.com
http://kexp.org

## Indigo De Souza - Kill Me (Live on KEXP)
 - [https://www.youtube.com/watch?v=kIJrU7ezlX0](https://www.youtube.com/watch?v=kIJrU7ezlX0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-15 00:00:00+00:00

http://KEXP.ORG presents Indigo De Souza performing “Kill Me” live in the KEXP studio. Recorded March 28, 2022.

Indigo De Souza - Vocals / Guitar
Dexter Webb - Guitar
Zack Kardon - Bass
Avery Sullivan - Drums

Host: Larry Mizell, Jr.
Audio Engineer: Kevin Suggs
Audio Mixer: Alex Farrar
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.indigodesouza.com
http://kexp.org

## Indigo De Souza - Late Night Crawler (Live on KEXP)
 - [https://www.youtube.com/watch?v=Sveasp-hChA](https://www.youtube.com/watch?v=Sveasp-hChA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-15 00:00:00+00:00

http://KEXP.ORG presents Indigo De Souza performing “Late Night Crawler” live in the KEXP studio. Recorded March 28, 2022.

Indigo De Souza - Vocals / Guitar
Dexter Webb - Guitar
Zack Kardon - Bass
Avery Sullivan - Drums

Host: Larry Mizell, Jr.
Audio Engineer: Kevin Suggs
Audio Mixer: Alex Farrar
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.indigodesouza.com
http://kexp.org

## Indigo De Souza - Real Pain (Live on KEXP)
 - [https://www.youtube.com/watch?v=ayVrXGfJBOs](https://www.youtube.com/watch?v=ayVrXGfJBOs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-15 00:00:00+00:00

http://KEXP.ORG presents Indigo De Souza performing “Real Pain” live in the KEXP studio. Recorded March 28, 2022.

Indigo De Souza - Vocals / Guitar
Dexter Webb - Guitar
Zack Kardon - Bass
Avery Sullivan - Drums

Host: Larry Mizell, Jr.
Audio Engineer: Kevin Suggs
Audio Mixer: Alex Farrar
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.indigodesouza.com
http://kexp.org


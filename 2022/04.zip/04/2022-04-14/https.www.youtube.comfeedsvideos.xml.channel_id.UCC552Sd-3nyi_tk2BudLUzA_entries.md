# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## This Is The First LIQUID Robot, And It’s Unbelievable
 - [https://www.youtube.com/watch?v=VmV3m0QqNOY](https://www.youtube.com/watch?v=VmV3m0QqNOY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2022-04-14 00:00:00+00:00

These robots are truly mind-blowing and fascinating.
Use our link or code 'asapscience30' to get 30% off a year long Skillshare membership: ​https://skl.sh/asapscience04222

Join our science mailing list: https://bit.ly/34fWU27

Special thanks to Professor Li Zhang for chatting to me about their creation.

FOLLOW US!
Instagram: https://instagram.com/asapscience​​
Facebook: https://facebook.com/asapscience​​
Twitter: https://twitter.com/asapscience​​
TikTok: @AsapSCIENCE 

Written by: Mitchell Moffit 
Edited by: Luka Šarlija

The study/source:

https://onlinelibrary.wiley.com/doi/abs/10.1002/adfm.202112508


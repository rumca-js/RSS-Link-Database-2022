# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## She leads teams of mobile medics who respond to global disasters
 - [https://www.cnn.com/2022/04/14/world/ukraine-refugee-emergency-medicine-responders-cnnheroes/index.html](https://www.cnn.com/2022/04/14/world/ukraine-refugee-emergency-medicine-responders-cnnheroes/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-04-14 23:46:17+00:00

People around the globe have been moved by the horrible images of Ukrainians in distress, fleeing their homes after the Russian invasion began in late February. But the scope of the situation can be difficult to comprehend.


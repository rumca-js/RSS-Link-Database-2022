# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## The Rise of A.I. Companions [Documentary]
 - [https://www.youtube.com/watch?v=QGLGq8WIMzM](https://www.youtube.com/watch?v=QGLGq8WIMzM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2022-04-15 00:00:00+00:00

Become smarter in 5 minutes by signing up for free today: https://cen.yt/mbcoldfusion14  - Thanks to Morning Brew for sponsoring today’s video.

What if AI companion systems become so believable, humans begin to treat them as a shoulder to lean on? This has already began to happen and in this episode, we take a deep dive to investigate.

A small correction, I just realised I kept calling "Euginia" "Eugina" sorry about that.

New Spotify Album https://open.spotify.com/album/2mQkQEgmLxCJC8JpcsiF2T?si=1IR2hx7SQWyqbehiv69IkQ

GPT-3 Talking (second half of video): https://www.youtube.com/watch?v=BpnnD_0IlbE
GPT-3 Deep Dive: https://www.youtube.com/watch?v=Te5rOTcE4J4

» ColdFusion Discord:  https://discord.gg/coldfusion
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusioncollective
» Podcast I Co-host: https://www.youtube.com/channel/UC6jKUaNXSnuW52CxexLcOJg
» Podcast Version of Videos: https://open.spotify.com/show/3dj6YGjgK3eA4Ti6G2Il8H
https://podcasts.apple.com/us/podcast/coldfusion/id1467404358

ColdFusion Music Channel: https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

ColdFusion Merch:
INTERNATIONAL: https://store.coldfusioncollective.com/
AUSTRALIA: https://shop.coldfusioncollective.com/

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- "New Thinking" written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

Sources:

https://futurism.com/ai-girlfriend-wife

https://www.analyticsinsight.net/the-difference-between-artificial-intelligence-and-machine-learning/#:~:text=Artificial%20intelligence%20is%20a%20technology,humans%20to%20solve%20complex%20problems.

https://blogs.scientificamerican.com/observations/ai-doesnt-actually-exist-yet/#:~:text=In%20fact%2C%20artificial%20intelligence%20for,birth%20have%20been%20greatly%20exaggerated.

https://thenextweb.com/news/confused-replika-ai-users-are-standing-up-for-bots-trying-bang-the-algorithm

https://futurism.com/chatbot-abuse

https://thebollywoodticket.com/uncategorized/83394/growth-drivers-of-ai-companion-market-with-relevancy-mapping-by-key-player-like-replika-tyche-luvozo-ubtech-hanson-robitics-no-isolation-and-more-forecast-2022-2028/

https://ubtrobot.com/collections/innovation-at-ubtech?ls=en

https://miko.ai/au

https://twitter.com/natonlinesafety/status/1481231950069346305/photo/1

https://www.indiewire.com/2021/01/microsoft-black-mirror-deceased-people-chatbots-1234610894/

https://www.washingtonpost.com/technology/2021/02/04/chat-bots-reincarnation-dead/

My Music Channel:  https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

//Soundtrack//

Sublab - So in love

Tom Hartney - Moonlight

We are all astronauts - Doves

Sean Williams  - Fray

Brutalist - South Street

Lemongrass - Heartbreaker

Deccies - Subtle

Blink House Hum

Burn Water- Ikigai

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide


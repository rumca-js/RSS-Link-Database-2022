# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Serious Sam: Tormental | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=ZNk5eDpAJ4Y](https://www.youtube.com/watch?v=ZNk5eDpAJ4Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-04-15 00:00:00+00:00

KC Nwosu reviews Serious Sam: Tormental, developed by Gungrounds and Croteam.

Serious Sam: Tormental on Steam: https://store.steampowered.com/app/640340/Serious_Sam_Tormental/

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Ghostwire: Tokyo is the Next Best Thing to Actually Visiting Japan
 - [https://www.youtube.com/watch?v=4rIOZyOer8E](https://www.youtube.com/watch?v=4rIOZyOer8E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-04-14 00:00:00+00:00

Welcome to Quest Log, our every other week video game diary series where we share our favorite moments from the games we're currently playing. This week Marty takes a look at Ghostwire Tokyo and why it's rendition of Japan is the next best thing to actually being there... minus, you know, ghosts and stuff.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag


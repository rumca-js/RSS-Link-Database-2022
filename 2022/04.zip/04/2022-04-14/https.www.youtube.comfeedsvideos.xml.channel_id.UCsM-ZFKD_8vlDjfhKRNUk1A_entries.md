# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## BOKKA - Walk On A Wire - live MUZO.FM
 - [https://www.youtube.com/watch?v=_VIx86Qm8jY](https://www.youtube.com/watch?v=_VIx86Qm8jY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2022-04-14 00:00:00+00:00

BOKKA na żywo w MUZO.FM. Utwór Walk On A Wire pochodzi z płyty Blood Moon. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook BOKKA: http://www.facebook.com/bokkamusic
Instagram BOKKA: http://www.instagram.com/bokkamusic
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


Rejestracja audio: Sebastian Zalewski
Mix: BOKKA
Światła: Artur „Żarów” Solmiński


BOKKA Walk On A Wire tekst

Swimming in the sea
Swimming out of trouble
Hoping it will do
What it does for others
 
Hanging by a thread
I fail to see
I walk on a wire
Like a needle in hay
Invisibly 
I walk on a wire 
 
Living after dark
Sleeping through the daytime 
Waiting for the end
Hoping for a fade out
 
Hanging by a thread
I fail to see
I walk on a wire
Like a needle in hay
Invisibly 
I walk on a wire


# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## CYBERPUNK 2077 DLC RELEASE UPDATE, NEXT NAUGHTY DOG GAME LEAKED? & MORE
 - [https://www.youtube.com/watch?v=xdxOkTjfuzU](https://www.youtube.com/watch?v=xdxOkTjfuzU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-04-15 00:00:00+00:00

Thank you Dr. Squatch for sponsoring this video. New customers can get 20% off on orders of $20 or more. Use my code DSQGAMERANX and click https://bit.ly/32gaV2J

Jake on twitter: https://bit.ly/3gdkPqD​​​​

Instagram: https://bit.ly/3uUh9Ot


 ~~~~STORIES~~~~



CD Projekt Red and Cyberpunk DLC expansion release window timing
https://twitter.com/CyberpunkGame/status/1514646107434987532
+ https://finance.yahoo.com/news/cdpr-says-vast-part-fixing-194000986.html
+ https://gameranx.com/updates/id/298421/article/cd-projekt-red-busy-with-multiple-projects-in-addition-to-witcher-4/


Naughty Dog’s next game?
https://comicbook.com/gaming/news/playstation-ps4-ps5-naughty-dog-the-last-of-us-uncharted-new-game/

Sony Epic investment 
https://www.videogameschronicle.com/news/sony-makes-1bn-investment-in-epic-games-to-deepen-relationship-in-the-metaverse-field/


KH4
https://youtu.be/RvxuSoJIEvs

No Man’s Sky Outlaws
https://youtu.be/NHLQBc9u5RE

Steelrising gameplay
https://youtu.be/bl7vozWD94M

Did you know gaming’s Metal Gear Solid
https://youtu.be/olBnzkWWumE

BF 2042 uh oh
https://www.videogameschronicle.com/news/battlefield-2042s-steam-player-count-falls-below-1000-for-the-first-time/

https://www.techradar.com/news/square-enixs-latest-rpg-falls-below-10-players-on-steam

Need for Speed returns?
https://gameranx.com/updates/id/298382/article/need-for-speed-2022-will-combine-realistic-graphics-with-anime/

## Most Ambitious Over The Top Action RPG?
 - [https://www.youtube.com/watch?v=Wp1iQsnIyqE](https://www.youtube.com/watch?v=Wp1iQsnIyqE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-04-14 00:00:00+00:00

Black Myth Wukong is an upcoming next gen RPG with sunning graphics and much more underneath the surface. Here's what we know.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


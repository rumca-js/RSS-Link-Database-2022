# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Korg Volca FM2: 10 Minutes of Downtempo
 - [https://www.youtube.com/watch?v=0Br-dU34T48](https://www.youtube.com/watch?v=0Br-dU34T48)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2022-04-14 00:00:00+00:00

10 minutes of retro boom-bap downtempo made with the Korg Volca FM2. All sounds (but drums) from the Volca FM2. Some additional reverb and processing have been applied.
Watch my Volca FM2 review here: https://youtu.be/AOhC9vh1fw4
Get one today: https://bit.ly/3602cDS
Get Dexed: https://asb2m10.github.io/dexed/
Use the editor from Oscillator Sync: https://synthmata.com/volca-fm/
------------------------------------
Patreon:  http://bit.ly/rmrpatreon

My Music: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

## Korg Volca FM2: A Tiny, Powerful Existential Crisis
 - [https://www.youtube.com/watch?v=AOhC9vh1fw4](https://www.youtube.com/watch?v=AOhC9vh1fw4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2022-04-14 00:00:00+00:00

Korg has released an update to the Volca FM, this time with more polyphony, a reverb, and other quality of life enhancements. It still made me feel weird. This video explains why. To be fair: I think this is a really cool synth. FM is a great and expressive synthesis method, and 6-OP FM is really capable. I just wish some things had been done differently.
Listen to what I made with the Volca FM 2 here: https://www.youtube.com/watch?v=0Br-dU34T48
Get one today: https://bit.ly/3602cDS
Get Dexed: https://asb2m10.github.io/dexed/
Use the editor from Oscillator Sync: https://synthmata.com/volca-fm/
------------------------------------
Patreon:  http://bit.ly/rmrpatreon

My Music: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia


## The Scoop: Inside the Longest Atlassian Outage of All Time
 - [https://newsletter.pragmaticengineer.com/p/scoop-atlassian?s=w](https://newsletter.pragmaticengineer.com/p/scoop-atlassian?s=w)
 - RSS feed: https://newsletter.pragmaticengineer.com
 - date published: 2022-04-14 19:28:28.458556+00:00

Hundreds of companies have no access to JIRA, Confluence and Atlassian Cloud. What can engineering teams learn from the poor handling of this outage?


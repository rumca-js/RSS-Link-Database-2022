# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## Live DAWLess Jam // Novation Circuit Tracks //Jacked To The T*ts
 - [https://www.youtube.com/watch?v=kGKLZ1B_ytc](https://www.youtube.com/watch?v=kGKLZ1B_ytc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2022-04-15 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong Watch the original remix: https://youtu.be/uPCLmgsY5Sc
Turn on captions for equipment & workflow explanation

Music-nerd stuff:
This jam is DAWless. The @NovationTV Circuit Tracks is the brain and sequencer. I used the 2 internal synths, for the opening chords and the arp bass. The drums use Drum Tracks 1-3 (kick, snare, hats) and Drum Track 4 is used for the vocal sample. The 2 MIDI Tracks control the @rolandglobal JU06 and @ArturiaOfficial Microfreak for extra chord pads and plinky arps. I use Scenes on the Circuit to go from one section to another, or to 'mute' tracks (it's a workaround - to mute, I use a blank pattern)
Foe the guitars I use a Zoom G1Xon for effects, going into a @SingularSoundOfficial Aeros Loop Studio, with a @DisasterAreaDesigns Midi Baby on the floor to trigger a loop record and to trigger playbank when the loop recording is done.
Recorded into a Zoom H5.


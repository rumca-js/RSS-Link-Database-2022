# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Star Trek Picard - No More Reviews, I'm Out
 - [https://www.youtube.com/watch?v=WaK7jGyY4Wo](https://www.youtube.com/watch?v=WaK7jGyY4Wo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-04-15 00:00:00+00:00

So I had an interesting revelation when it came to deciding on my next review, and the prospect of watching Picard Season 2 came up - I just don't care about this show anymore. I don't want to watch it, and I don't want to review it. And here's why.


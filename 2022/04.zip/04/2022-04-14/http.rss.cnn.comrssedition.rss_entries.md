# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Harry and Meghan visit Queen Elizabeth II on way to Invictus Games
 - [https://www.cnn.com/2022/04/14/uk/harry-megan-visit-queen-gbr-uk-intl/index.html](https://www.cnn.com/2022/04/14/uk/harry-megan-visit-queen-gbr-uk-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 23:21:20+00:00

A spokesperson for the Duke and Duchess of Sussex has confirmed to CNN that the couple visited Queen Elizabeth II on their way to The Hague to attend The Invictus Games, which begin on Saturday.

## Unable to evacuate, these Ukrainians face the horrors of war every day
 - [https://www.cnn.com/videos/world/2022/04/14/ukraine-donbas-avdiivka-front-lines-living-war-shelling-tsr-ward-pkg-vpx.cnn](https://www.cnn.com/videos/world/2022/04/14/ukraine-donbas-avdiivka-front-lines-living-war-shelling-tsr-ward-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 22:51:48+00:00

Unable to evacuate, hundreds of Ukrainians near the war front lines are living without water, electricity and in constant fear. CNN's Clarissa Ward reports.

## Top international prosecutor speaks to CNN after visiting Bucha
 - [https://www.cnn.com/videos/world/2022/04/14/karim-khan-international-war-crimes-prosecutor-ukraine-sot-lead-vpx.cnn](https://www.cnn.com/videos/world/2022/04/14/karim-khan-international-war-crimes-prosecutor-ukraine-sot-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 22:23:23+00:00

CNN's Jake Tapper speaks with International Criminal Court Prosecutor Karim Khan, who is leading the war crimes investigation in Ukraine, about what he saw while touring Bucha and Borodianka.

## Elon Musk says his offer to buy Twitter is about 'the future of civilization,' not making money
 - [https://www.cnn.com/2022/04/14/tech/musk-twitter-offer-explanation/index.html](https://www.cnn.com/2022/04/14/tech/musk-twitter-offer-explanation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 22:04:17+00:00

Elon Musk defended his offer to purchase Twitter on Thursday, saying during an on-stage interview at the TED conference that he sees the acquisition as nothing less than a turning point for civilization.

## Bollywood mega-stars Alia Bhatt and Ranbir Kapoor wed in intimate Mumbai ceremony
 - [https://www.cnn.com/style/article/alia-bhatt-ranbir-kapoor-wedding-intl-scli/index.html](https://www.cnn.com/style/article/alia-bhatt-ranbir-kapoor-wedding-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 19:26:48+00:00

Two of Bollywood's biggest stars, Alia Bhatt and Ranbir Kapoor, tied the knot in Mumbai on Thursday in an intimate ceremony attended by some of the greats of Indian cinema.

## Analyst: This underscores Putin's terrible miscalculation
 - [https://www.cnn.com/videos/world/2022/04/14/putin-miscalculation-nato-susan-glasser-sot-vpx-ip.cnn](https://www.cnn.com/videos/world/2022/04/14/putin-miscalculation-nato-susan-glasser-sot-vpx-ip.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 19:14:05+00:00

CNN global affairs analyst Susan Glasser says that Russian President Vladimir Putin's threat to deploy nuclear weapons if Sweden and Finland join NATO underscores the terrible miscalculation made when he decided to invade Ukraine.

## Some Belarusians want to fight Russians in Ukraine. They also hope to free their country from Putin's grip
 - [https://www.cnn.com/2022/04/14/europe/belarus-ukraine-volunteers-intl/index.html](https://www.cnn.com/2022/04/14/europe/belarus-ukraine-volunteers-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 18:45:05+00:00

In a wooded area on the Polish side of the Poland-Ukraine border, men dressed in crisp, clean, camouflage are given tourniquets. They kneel on the muddy ground and start to learn basic survival training.

## Atrocities are piling up across Ukraine. CNN witnessed some of the horrors
 - [https://www.cnn.com/2022/04/14/europe/ukraine-russia-atrocities-eyewitness-intl-cmd/index.html](https://www.cnn.com/2022/04/14/europe/ukraine-russia-atrocities-eyewitness-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 18:25:57+00:00

Indiscriminate killings of civilians attempting to flee the violence. Victims found with their hands tied behind their backs. An attack on a maternity hospital, a theater turned shelter bombed. The list of atrocities and apparent war crimes allegedly committed by Russian troops in Ukraine gets longer by the day.

## ISIS 'Beatle' convicted in relation to kidnapping and deaths of four Americans
 - [https://www.cnn.com/2022/04/14/politics/isis-beatle-convicted-on-all-counts/index.html](https://www.cnn.com/2022/04/14/politics/isis-beatle-convicted-on-all-counts/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 17:50:58+00:00

The last member of the ISIS cell known as the "Beatles," a British group of fighters, was convicted by a jury Thursday of assisting in the kidnapping and deaths of four Americans between 2012 and 2015.

## Team GB ordered to return Olympic medal from Tokyo 2020 Games
 - [https://www.cnn.com/2022/04/14/sport/team-gb-return-2020-olympics-medal-spt-intl/index.html](https://www.cnn.com/2022/04/14/sport/team-gb-return-2020-olympics-medal-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 17:28:34+00:00

The British Olympic Association (BOA) announced on Thursday the team was informed by the Court of Arbitration for Sport (CAS) that it must return the silver medals from the 4x100m relay event won during the Tokyo 2020 Olympic Games.

## Video of mom at Elton John concert goes viral on TikTok
 - [https://www.cnn.com/videos/media/2022/04/14/elton-john-mom-tiktok-concert-tour-mxp-hln-vpx.hln](https://www.cnn.com/videos/media/2022/04/14/elton-john-mom-tiktok-concert-tour-mxp-hln-vpx.hln)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 17:08:11+00:00

See the viral TikTok video of a mom's emotional reaction to Elton John in concert during his final tour.

## Even small amounts of exercise fight depression, study says
 - [https://www.cnn.com/2022/04/14/health/exercise-depression-study-wellness/index.html](https://www.cnn.com/2022/04/14/health/exercise-depression-study-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 16:45:20+00:00

Get up and move -- even small doses of physical activity, such as brisk walking, may substantially lower the risk of depression, according to a new data analysis.

## See the impact of Russia's war on countries around the world
 - [https://www.cnn.com/videos/world/2022/04/14/russia-ukraine-global-food-security-mckenzie-pkg-ctw-vpx.cnn](https://www.cnn.com/videos/world/2022/04/14/russia-ukraine-global-food-security-mckenzie-pkg-ctw-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 16:32:13+00:00

Russia's war in Ukraine has caused a shortage of wheat and grain that many countries depend on. CNN's David McKenzie walks through the far-reaching impact of the conflict.

## 'It's insane': Johnny Depp's friend breaks down during testimony
 - [https://www.cnn.com/videos/media/2022/04/14/johnny-depp-friend-emotional-testimony-amber-heard-defamation-trial-mpx-vpx.hln](https://www.cnn.com/videos/media/2022/04/14/johnny-depp-friend-emotional-testimony-amber-heard-defamation-trial-mpx-vpx.hln)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 16:24:56+00:00

Johnny Depp's longtime friend, Isaac Baruch, took the witness stand in the actor's defamation trial against his ex-wife Amber Heard.

## Man convicted in Colombia of murdering his wife arrested after 27 years on the run, FBI says
 - [https://www.cnn.com/2022/04/14/us/william-hernando-usma-acosta-arrested/index.html](https://www.cnn.com/2022/04/14/us/william-hernando-usma-acosta-arrested/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 16:20:30+00:00

A man who fled to the US from Colombia after the murder his wife in 1994 was arrested Wednesday in Massachusetts, the FBI said in a news release.

## Mitch McConnell reveals a fundamental truth about Donald Trump
 - [https://www.cnn.com/2022/04/14/politics/mitch-mcconnell-donald-trump-scapegoat/index.html](https://www.cnn.com/2022/04/14/politics/mitch-mcconnell-donald-trump-scapegoat/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 15:25:15+00:00

Donald Trump l-o-v-e-s a good scapegoat.

## 'They're coming and coming and coming': Hear from Ukrainian soldiers on front line
 - [https://www.cnn.com/videos/tv/2022/04/13/eastern-ukraine-on-defense-ben-wedeman-the-lead.cnn](https://www.cnn.com/videos/tv/2022/04/13/eastern-ukraine-on-defense-ben-wedeman-the-lead.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 15:11:26+00:00

CNN's Ben Wedeman speaks to civilians and troops in Ukraine's eastern front as a Russian offensive begins in the region.

## Joe Biden's poll numbers just aren't getting any better
 - [https://www.cnn.com/2022/04/14/politics/biden-approval-rating-polls/index.html](https://www.cnn.com/2022/04/14/politics/biden-approval-rating-polls/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 15:00:41+00:00

With just more than 200 days left until the 2022 election, there's little evidence that President Joe Biden's poll numbers are improving -- and there's some data to suggest things are getting worse.

## Powerful 'rivers in the sky' could cause Antarctic Peninsula's biggest ice shelf to collapse
 - [https://www.cnn.com/2022/04/14/world/antarctica-larsen-c-ice-shelf-atmospheric-rivers-climate-intl/index.html](https://www.cnn.com/2022/04/14/world/antarctica-larsen-c-ice-shelf-atmospheric-rivers-climate-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 14:59:43+00:00

When temperatures in Antarctica soared to 38 degrees Celsius above normal -- around 70 Fahrenheit -- in March, a teetering ice shelf the size of Los Angeles collapsed. Scientists don't know what role the extreme temperatures may have played in the event, but the heat rushed in through what's known as an atmospheric river, a long plume of moisture that transports warm air and water vapor from the tropics to other parts of the Earth.

## Hong Kong TV series sparks 'brownface' controversy after actor darkens skin
 - [https://www.cnn.com/style/article/hong-kong-tv-series-brownface/index.html](https://www.cnn.com/style/article/hong-kong-tv-series-brownface/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 12:09:25+00:00

A Hong Kong TV series has sparked controversy over the use of "brownface" after one of its actors darkened her skin with makeup to play a Filipina domestic worker.

## Russian Navy's warship is either floating abandoned or at the bottom of the Black Sea
 - [https://www.cnn.com/2022/04/14/europe/russia-navy-cruiser-moskva-fire-abandoned-intl-hnk-ml/index.html](https://www.cnn.com/2022/04/14/europe/russia-navy-cruiser-moskva-fire-abandoned-intl-hnk-ml/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 11:46:17+00:00

One of the Russian Navy's most important warships is either floating abandoned or at the bottom of the Black Sea, a massive blow to a military struggling against Ukrainian resistance 50 days into Vladimir Putin's invasion of his neighbor.

## Elon Musk offers to buy Twitter
 - [https://www.cnn.com/2022/04/14/tech/elon-musk-twitter-offer/index.html](https://www.cnn.com/2022/04/14/tech/elon-musk-twitter-offer/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 11:43:44+00:00

Elon Musk has made an offer to buy Twitter.

## Colombia soccer great dies after car crash
 - [https://www.cnn.com/2022/04/14/football/freddy-rincon-dies-intl-spt/index.html](https://www.cnn.com/2022/04/14/football/freddy-rincon-dies-intl-spt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 11:20:00+00:00

Former Colombia soccer captain Freddy Rincón has died after being involved in a car crash in Cali, the hospital treating him said in a statement.

## Curiosity rover comes up against dangerous 'scaly' terrain on Mars
 - [https://www.cnn.com/2022/04/14/world/mars-curiosity-rover-sharp-rocks-scn/index.html](https://www.cnn.com/2022/04/14/world/mars-curiosity-rover-sharp-rocks-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 11:14:26+00:00

The Curiosity rover just avoided a near run-in with some razor-sharp rocks on Mars.

## Opinion: The gender binary was always a story. Now we can tell ourselves a new one
 - [https://www.cnn.com/2022/04/14/world/gender-x-non-binary-language-as-equals-intl-cmd/index.html](https://www.cnn.com/2022/04/14/world/gender-x-non-binary-language-as-equals-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 10:46:24+00:00

As of Monday it is possible for US citizens to select "X" instead of "F" and "M" when applying for a passport. The US has now joined countries such as Germany, Canada, Nepal and Pakistan in offering a third gender category.

## Covid-19 booster raises antibody levels against Omicron for children ages 5 through 11, Pfizer and BioNTech say
 - [https://www.cnn.com/2022/04/14/health/pfizer-booster-5-to-11-results/index.html](https://www.cnn.com/2022/04/14/health/pfizer-booster-5-to-11-results/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 10:45:17+00:00

A third shot of the children's dose of Pfizer/BioNTech's Covid-19 vaccine raised Omicron-fighting antibodies by 36 times in kids 5 through 11 years of age, the companies said in a news release Thursday. The companies plan to request emergency use authorization from the US Food and Drug Administration for a booster dose for this age group.

## Seven-time Olympic champion Allyson Felix announces plans to retire after 2022 season
 - [https://www.cnn.com/2022/04/14/sport/allyson-felix-announces-retirement-spt-intl/index.html](https://www.cnn.com/2022/04/14/sport/allyson-felix-announces-retirement-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 09:44:57+00:00

Allyson Felix -- the most decorated US track and field athlete in Olympics history -- announced that she plans to retire following the conclusion of the 2022 season.

## Death on a river shows the brutality of Russian occupation
 - [https://www.cnn.com/2022/04/13/europe/ukraine-kherson-russia-boat-family-intl-cmd/index.html](https://www.cnn.com/2022/04/13/europe/ukraine-kherson-russia-boat-family-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 09:44:43+00:00

Lviv, Ukraine (CNN) — All Vladimir Nesterenko wanted to do when he grew up was to play basketball. The brown haired 12-year-old dribbled and shot hoops with his dad Oleh in the village where they lived in Ukraine's southern Kherson region. He idolized NBA legend Michael Jordan.

## Ugly scenes in Madrid as Manchester City edges past Atlético Madrid
 - [https://www.cnn.com/2022/04/14/football/manchester-city-atletico-madrid-quarterfinal-champions-league-spt-intl/index.html](https://www.cnn.com/2022/04/14/football/manchester-city-atletico-madrid-quarterfinal-champions-league-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 09:26:31+00:00

Tensions boiled over as Manchester City reached the semifinals of the UEFA Champions League after surviving an intense battle in the second-leg against Atlético Madrid on Wednesday.

## CNN reporter explains significance of potential missile strike on Russian ship
 - [https://www.cnn.com/videos/world/2022/04/14/russia-warship-damage-potential-missile-strike-intl-vpx.cnn](https://www.cnn.com/videos/world/2022/04/14/russia-warship-damage-potential-missile-strike-intl-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 09:22:48+00:00

There are conflicting reports about why one of the Russian Navy's most important warships is either floating abandoned or at the bottom of the Black Sea.  CNN's Clare Sebastian reports.

## Death toll jumps to 259 after flooding washed away roads, destroyed homes in South Africa
 - [https://www.cnn.com/2022/04/13/africa/south-africa-rain-floods-climate-intl/index.html](https://www.cnn.com/2022/04/13/africa/south-africa-rain-floods-climate-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 08:49:50+00:00

Heavy rains and flooding battered the eastern coast of South Africa on Wednesday, killing at least 259 people, damaging roads and destroying homes.

## Suspected Brooklyn shooter called in a tip on himself and was arrested about an hour later
 - [https://www.cnn.com/collections/subway-shooting-intl-041322/](https://www.cnn.com/collections/subway-shooting-intl-041322/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 07:58:48+00:00



## Putin shrugs off heavy military losses
 - [https://www.cnn.com/collections/intl-ukraine-0413/](https://www.cnn.com/collections/intl-ukraine-0413/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 07:49:07+00:00



## Opinion: Putin is shifting the goal posts. The West must too
 - [https://www.cnn.com/2022/04/13/opinions/kyiv-ukraine-russia-brutality-west-bociurkiw/index.html](https://www.cnn.com/2022/04/13/opinions/kyiv-ukraine-russia-brutality-west-bociurkiw/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 07:46:58+00:00

What was once one of the most beautiful and thriving capitals in Europe has been transformed over weeks of Russian aggression into an eerie ghost town. Monuments to Kyiv's founders and notable Ukrainian cultural leaders have been boarded up to protect them from destruction.

## 'God's going to help us get through all of this.' A 165 mph tornado causes widespread devastation in Texas community
 - [https://www.cnn.com/2022/04/14/weather/severe-weather-tornadoes-texas-thursday/index.html](https://www.cnn.com/2022/04/14/weather/severe-weather-tornadoes-texas-thursday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 07:41:22+00:00

After a tornado packing 165 mph winds rolled through Bell County, Texas, Tuesday, JudyLynn Hughes began sifting through what was left of her belongings.

## Meet the people who want to spend the rest of their lives on cruise ships
 - [https://www.cnn.com/travel/article/living-on-a-cruise-ship-cost-benefits/index.html](https://www.cnn.com/travel/article/living-on-a-cruise-ship-cost-benefits/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 06:56:08+00:00

Angelyn Burk has been in love with cruising since she boarded a megaship for the first time back in 1992 to sail in the Caribbean.

## Analysis: US faces race against time with fresh assault looming
 - [https://www.cnn.com/2022/04/14/politics/us-aid-ukraine-race-for-time/index.html](https://www.cnn.com/2022/04/14/politics/us-aid-ukraine-race-for-time/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 06:28:29+00:00

US officials are confronting fresh questions about whether a massive aid package for Ukraine will arrive soon enough and whether it will be enough to sustain Ukrainian forces in what is turning into a protracted war with Russia.

## New Zealand court grants China's extradition request for murder suspect in landmark case
 - [https://www.cnn.com/2022/04/14/asia/new-zealand-china-extradite-kyung-yup-kim-intl-hnk/index.html](https://www.cnn.com/2022/04/14/asia/new-zealand-china-extradite-kyung-yup-kim-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 06:17:00+00:00

New Zealand's top court ruled Wednesday that a murder suspect can be extradited to China to face trial in a landmark decision following a more than decade-long legal battle.

## What images of Russian trucks say about its military's struggles
 - [https://www.cnn.com/2022/04/14/europe/ukraine-war-russia-trucks-logistics-intl-hnk-ml/index.html](https://www.cnn.com/2022/04/14/europe/ukraine-war-russia-trucks-logistics-intl-hnk-ml/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 04:06:05+00:00

• Video: He was once Putin's Prime Minister. Now he supports Ukraine

## Cuba Gooding Jr. pleads guilty to forcible touch
 - [https://www.cnn.com/2022/04/13/entertainment/cuba-gooding-jr/index.html](https://www.cnn.com/2022/04/13/entertainment/cuba-gooding-jr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 03:46:40+00:00

Actor Cuba Gooding Jr. entered a plea of guilty on Wednesday to a misdemeanor charge of forcibly touching a woman at a New York City nightclub in 2018.

## Frantic moment caught on camera as Iowa news crew escapes tornado
 - [https://www.cnn.com/videos/us/2022/04/14/iowa-tornado-meteorologist-news-crew-storms-escape-live-tv-aw-orig.cnn](https://www.cnn.com/videos/us/2022/04/14/iowa-tornado-meteorologist-news-crew-storms-escape-live-tv-aw-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 03:03:56+00:00

An Iowa meteorologist chasing a storm cuts his live shot short as a tornado touches down nearby.

## Why the US is giving new, heavier weapons to Ukraine
 - [https://www.cnn.com/2022/04/13/politics/us-weapons-ukraine-war/index.html](https://www.cnn.com/2022/04/13/politics/us-weapons-ukraine-war/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 02:39:53+00:00

For the first time since Russia's invasion of Ukraine, the US is providing Kyiv with the types of high-power capabilities some Biden administration officials viewed as too much of an escalation risk a few short weeks ago.

## Two US cities host Russia-backed radio station that spreads war propaganda
 - [https://www.cnn.com/videos/media/2022/04/14/russia-backed-radio-sputnik-war-propaganda-us-ac360-marquardt-dnt-vpx.cnn](https://www.cnn.com/videos/media/2022/04/14/russia-backed-radio-sputnik-war-propaganda-us-ac360-marquardt-dnt-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 02:24:56+00:00

A radio station sponsored by Russian state media and hosted by Americans is spreading war propaganda in two US cities. CNN's Alex Marquardt reports.

## 'I had to do something to gain his respect': January 6 defendant testifies he believed Trump sent him to attack on US Capitol
 - [https://www.cnn.com/2022/04/13/politics/january-6-rioter-trump-defense-dustin-thompson/index.html](https://www.cnn.com/2022/04/13/politics/january-6-rioter-trump-defense-dustin-thompson/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 01:08:07+00:00

Alleged rioter Dustin Thompson took the stand in his trial on Wednesday and told a Washington, DC, jury that he believed he had received "presidential orders" to go to the US Capitol on January 6, 2021.

## 'Kind of a misogynistic thing': Joan Collins pushes back on 'b*tch' characterization
 - [https://www.cnn.com/videos/us/2022/04/13/joan-collins-strong-assertive-roles-cwallace-cnnplus-vpx.cnn](https://www.cnn.com/videos/us/2022/04/13/joan-collins-strong-assertive-roles-cwallace-cnnplus-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 00:54:33+00:00

Golden Globe-winning actress Joan Collins talks with CNN's Chris Wallace about the roles she's played and the label many applied to those characters. "Who's Talking to Chris Wallace" is available on CNN+ -- CNN's new subscription streaming service.

## Putin critic says he begged friend and fellow Kremlin critic not to go to Moscow
 - [https://www.cnn.com/videos/world/2022/04/13/bill-browder-putin-critic-ebof-vpx.cnn](https://www.cnn.com/videos/world/2022/04/13/bill-browder-putin-critic-ebof-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-04-14 00:53:26+00:00

CNN's Erin Burnett talks to longtime Putin critic Bill Browder about his friend and fellow Putin critic, Vladimir Kara-Murza, being detained in Moscow as fears mount for his safety.


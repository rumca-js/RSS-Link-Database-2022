# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Red Rising NFT Resolution🎭 Cyberpunk 2077 Done?🦾 D&D Direct🎲 -FANTASY NEWS
 - [https://www.youtube.com/watch?v=3hSmlsArx6s](https://www.youtube.com/watch?v=3hSmlsArx6s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-04-15 00:00:00+00:00

Let's jump into the FANTASY NEWS! 
Check out Babbel and pick up a new language: https://go.babbel.com/12m65-youtube-danielgreene-apr-2022/default 

New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.designbyhumans.com/shop/FantasyNews/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

00:00 intro

00:20 Red Rising Controversy: https://twitter.com/Pierce_Brown/status/1513934960855379968 

03:44 The World We Make: https://twitter.com/orbitbooks/status/1513530380027977732 

04:13 Folio Society Lord Of The Rings: https://twitter.com/foliosociety/status/1514559604746764291 

04:58 DnD Beyond Purchase: https://tinyurl.com/ufrshd4b 

05:40 Hell Is Us: https://www.youtube.com/watch?v=lzmcwj8UnJg&ab_channel=IGN 

06:06 Stranger Things 4: https://www.youtube.com/watch?v=yQEondeGvKo&ab_channel=StrangerThings 

06:38 Crimes of the Future: https://www.youtube.com/watch?v=QVX7df79BNo&ab_channel=NEON 

06:54 D&D Direct: https://www.youtube.com/watch?v=5A9KrjfUqT8&ab_channel=Dungeons%26Dragons 

07:17 Cyberpunk “Done”: https://kotaku.com/cyberpunk-2077-cdpr-expansion-multiplayer-fix-patch-wit-1848795532 

09:28 Scrat got his Nut: https://twitter.com/discussingfilm/status/1514358487198928899?s=21&t=p17hQ_UejGwyT2dUV75R9w

## Elden Ring (Casual Thoughts)
 - [https://www.youtube.com/watch?v=kGqnGR5jQjE](https://www.youtube.com/watch?v=kGqnGR5jQjE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-04-14 00:00:00+00:00

My thoughts so far playing Elden Ring! #EldenRing 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.designbyhumans.com/shop/FantasyNews/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231


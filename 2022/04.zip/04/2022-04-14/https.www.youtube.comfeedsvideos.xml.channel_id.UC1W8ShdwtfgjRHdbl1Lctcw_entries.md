# Source:NASS, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw, language:en-US

## San Francisco 1920s in Color [60fps, Remastered] w/sound design added
 - [https://www.youtube.com/watch?v=PShpDHmrXh8](https://www.youtube.com/watch?v=PShpDHmrXh8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw
 - date published: 2022-04-15 00:00:00+00:00

I colorized, restored and created a sound design for this video of San Francisco 1920s, California Street cable car, Chinatown , Harbor from an elevated view , Golden Gate Park , Steinhart Aquarium , Ferry Building , Ferryboats on Bay, U.S.S. Pennsylvania, long shot, crossing the Bay , Coming into ferry slip at Oakland , Lake Merritt, Oakland, we can clearly see what is happening in broad daylight,

Video Restoration Process:
✔ FPS boosted to 60 frames per second 
✔ Image resolution boosted up to HD 
✔ Improved video sharpness and brightness 
✔ Colorized only for the ambiance (not historically accurate)
✔added sound design only for the ambiance
✔restoration:(stabilisation,denoise,cleand,deblur) 

Please, be aware that colorization colors are not real and fake, colorization was made only for the ambiance and do not represent real historical data.

Thanks to Prelinger Archives share the amazing B&W Video Source

B&W Video Source from: Prelinger Archives on archive.org
B&W Video Source: https://archive.org/details/0773_Gould_can_5570-1_13_07_42_00

sound design resource: freesound.org, other

- - - - - - - - - - - - - - - - - - - -
📨 Contact me at :nassthegoodman@gmail.com
- - - - - - - - - - - - - - - - - - - -
For any Copyright issues, please reach out to us first before filing a claim with YouTube. Send us a message or email detailing your concerns and we'll make sure the matter is resolved immediately. All contact details in our channel's "About" page! Please consider "fair use" before filing a claim. Thank You!


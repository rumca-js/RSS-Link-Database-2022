## Elon Musk Wants to Buy Out Twitter (TWTR) in Final $43 Billion Unsolicited Bid - Bloomberg
 - [https://www.bloomberg.com/news/articles/2022-04-14/elon-musk-launches-43-billion-hostile-takeover-of-twitter](https://www.bloomberg.com/news/articles/2022-04-14/elon-musk-launches-43-billion-hostile-takeover-of-twitter)
 - RSS feed: https://www.bloomberg.com
 - date published: 2022-04-14 14:00:26.841282+00:00

Elon Musk has made a controversial offer to buy Twitter Inc., saying the company has extraordinary potential and he is the person to unlock it.


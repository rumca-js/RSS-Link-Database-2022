# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Why you SHOULD double text
 - [https://www.youtube.com/watch?v=qd56eM4j2pw](https://www.youtube.com/watch?v=qd56eM4j2pw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2022-04-14 00:00:00+00:00

Another Mirror sketch, have your wine at the ready. Thank you to BetterHelp for sponsoring today's video. Get 10% off your first month here: https://BetterHelp.com/nolke 

Sign up for my Patreon so I can keep making videos and subscribe you weirdos: https://www.patreon.com/julienolke

Writer: Julie Nolke
Actors: Julie Nolke
Camera: Sam Larson
Editor: Alec McKay


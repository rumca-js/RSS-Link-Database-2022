# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Maniac // Michael Sembello // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=5mfwbkWJP8o](https://www.youtube.com/watch?v=5mfwbkWJP8o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2022-04-14 00:00:00+00:00

Been on a Michael Sembello trip ever since covering Maniac. What a weird, ingenious composition!

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of Michael Sembello's "Maniac" by Pomplamoose.

MUSICIAN CREDITS
Lead Vocals: Nataly Dawn
Synth: Jack Conte, Swatkins & Karina DePiano
Drums: Ben Rose
Background Vocals: Sarah Dugas

AUDIO CREDITS
Engineer: Bill Mims
Assistant Engineer: Jack Corbett
Mixing/Mastering: Yianni AP
Producer: Ben Rose

VIDEO CREDITS
Director: Dom Fera
DP: Ryan Blewett
Camera Operators: Austin Hughes, Riley Donavan
Gaffer: Nash White
Video Editor/Colorist: Athena Wheaton
PA/Wardrobe: Alex Allen
Operations Manager: Chris Modl

LYRICS
Just a steel town girl on a Saturday night
Lookin' for the fight of her life
In the real-time world, no one sees her at all
They all say she's crazy
Locking rhythms to the beat of her heart
Changing movement into light
She has danced into the danger zone
Where the dancer becomes the dance

It can cut you like a knife
If the gift becomes the fire
On a wire between will and what will be

She's a maniac, maniac on the floor
And she's dancing like she's never danced before
She's a maniac, maniac on the floor
And she's dancing like she's never danced before

On the ice-blue line of insanity
Is a place most never see
It's a hard-won place of mystery
Touch it, but can't hold it
You work all your life for this moment in time
It could come or pass you by
It's a push-shove world, but there's always a chance
If the hunger stays the night

There's a cold kinetic heat
Struggling, pressing for the beat
Never stopping with her head against the wind

She's a maniac, maniac on the floor
And she's dancing like she's never danced before
She's a maniac, maniac, I should know
And she's dancing like she's never danced before

Ooh, oh
Oh

There's a cold kinetic heat
Struggling, stretching for the beat
On a wire between will and what will be

She's a maniac, maniac on the floor
And she's dancing like she's never danced before
She's a maniac, maniac, I should know
And she's dancing, yeah she’s dancing, oh she’s dancing

She's a maniac, maniac on the floor
And she's dancing like she's never danced before
She's a maniac, maniac, I should know
And she's dancing like she's never danced before


# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## It's getting ugly for Twitter
 - [https://www.youtube.com/watch?v=gvTynAXTSeA](https://www.youtube.com/watch?v=gvTynAXTSeA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2022-04-15 00:00:00+00:00

Visit https://brilliant.org/TFC/ to get started learning STEM for free, and the first 200 people will get 20% off their annual premium subscription - Sponsored by Brilliant.

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► This video ◄◄◄  

This is a short Easter-edition Friday checkout where I discuss Elon Musk wanting to buy Twitter and some surprising data from TSMC's earnings.

Episode 92

This video on Nebula: 
Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd 
Quiz: https://link.crrowd.com/quiz

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support my work directly:  https://flattr.com/@techaltar   

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:30 Release highlights
2:00 Elon vs Twitter
5:38 TSMC figures


# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Mike Tyson Talks About Tigers
 - [https://www.youtube.com/watch?v=Ac2xYmkLmpU](https://www.youtube.com/watch?v=Ac2xYmkLmpU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-04-15 00:00:00+00:00

Taken from JRE #1805 w/Mike Tyson:
https://open.spotify.com/episode/2jAYGAbZHxReyhtK6kI5xG?si=a07a8aa478dc4dc3

## Mike Tyson on His Comeback Fight and Being Challenged by Jake Paul
 - [https://www.youtube.com/watch?v=6OwLmg9rGAQ](https://www.youtube.com/watch?v=6OwLmg9rGAQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-04-15 00:00:00+00:00

Taken from JRE #1805 w/Mike Tyson:
https://open.spotify.com/episode/2jAYGAbZHxReyhtK6kI5xG?si=a07a8aa478dc4dc3

## A DoggFather Moment - JRE Toons
 - [https://www.youtube.com/watch?v=vEOCYddL9PY](https://www.youtube.com/watch?v=vEOCYddL9PY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-04-14 00:00:00+00:00

Another hilarious moment animated by PaulyToon from the Joe Rogan Experience #1733 with Snoop Dogg - https://open.spotify.com/episode/2g8rE0wmd4WnObewi3DzwU?si=vlkXaSEtRcWUpjVJ1IvHzQ


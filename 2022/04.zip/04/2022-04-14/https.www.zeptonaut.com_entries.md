## Why is selling software so weird?
 - [https://www.zeptonaut.com/posts/selling-software-is-weird/](https://www.zeptonaut.com/posts/selling-software-is-weird/)
 - RSS feed: https://www.zeptonaut.com
 - date published: 2022-04-14 11:17:59.289138+00:00

Building software looks a lot like building a house. Selling the two is nothing alike.


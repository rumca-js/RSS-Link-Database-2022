# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Durry - Trauma Queen (live at Flowers Studio for The Current)
 - [https://www.youtube.com/watch?v=JFVUOkcAj1w](https://www.youtube.com/watch?v=JFVUOkcAj1w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-04-15 00:00:00+00:00

From their parent's basement in Burnsville, MN to Flowers Studio in Minneapolis--the nostalgic indie rock act Durry join The Current for the latest in the Minnesota Sessions series to perform "Trauma Queen" from their breakout debut EP, Suburban legends.

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits
Director, Camera Op, Editor, Colorist - Evan Clark
Camera Op, Mix Engineer - Eric Romani
Camera Op - Tom Campbell
Audio Recording, Flowers Studio - Kris Johnson
Producer - Jesse Wiza
Durry - Austin Durry, Tarryn Durry, Ashley Durry, Dane Hoppe

## Durry - Who's Laughing Now (live for The Current at Flowers Studio)
 - [https://www.youtube.com/watch?v=JvX1uSeH9o0](https://www.youtube.com/watch?v=JvX1uSeH9o0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-04-15 00:00:00+00:00

From their parent's basement in Burnsville, MN to Flowers Studio in Minneapolis--the nostalgic indie rock act Durry join The Current for the latest in the Minnesota Sessions series to perform "Who's Laughing Now" from their breakout debut EP, Suburban legends.

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits
Director, Camera Op, Editor, Colorist - Evan Clark
Camera Op, Mix Engineer - Eric Romani
Camera Op - Tom Campbell
Audio Recording, Flowers Studio - Kris Johnson
Producer - Jesse Wiza
Durry - Austin Durry, Tarryn Durry, Ashley Durry, Dane Hoppe

## Minnesota Sessions: Durry at Flowers Studio (live for The Current)
 - [https://www.youtube.com/watch?v=LBG2IQjGBbY](https://www.youtube.com/watch?v=LBG2IQjGBbY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-04-15 00:00:00+00:00

From their parent's basement in Burnsville, MN to Flowers Studio in Minneapolis--the nostalgic indie rock act Durry join The Current for the latest in the Minnesota Sessions series to perform tracks from their breakout debut EP, Suburban legends.

Songs Played:
00:00 Losers Club
03:45 Trauma Queen
07:15 Who's Laughing Now

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits
Director, Camera Op, Editor, Colorist - Evan Clark
Camera Op, Mix Engineer - Eric Romani
Camera Op - Tom Campbell
Audio Recording, Flowers Studio - Kris Johnson
Producer - Jesse Wiza
Durry - Austin Durry, Tarryn Durry, Ashley Durry, Dane Hoppe

## The Head and the Heart's Jonathan Russell talks 'Every Shade of Blue' (interview with The Current)
 - [https://www.youtube.com/watch?v=A_x9Vu9JOWk](https://www.youtube.com/watch?v=A_x9Vu9JOWk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-04-14 00:00:00+00:00

@theheadandtheheart's Jonathan Russell joins Mary Lucia of The Current to discuss the band's 2022 record 'Every Shade of Blue'. Plus, the two talk about overcoming writer's block, navigating touring with children, and the importance of trust in songwriting. 

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits: 
Guest - Jonathan Russell
Host - Mary Lucia
Producers - Jesse Wiza, Derrick Stevens
Technical Director - Peter Ecklund


# Source:FRONTLINE PBS | Official, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ, language:en-US

## War Crimes Watch: She’s Working to Make Putin Pay | FRONTLINE + AP
 - [https://www.youtube.com/watch?v=t3OL0dsrmSw](https://www.youtube.com/watch?v=t3OL0dsrmSw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2022-04-15 00:00:00+00:00

The Associated Press and FRONTLINE gained special access to Ukraine’s Prosecutor General Iryna Venediktova who is heading the legal battle to make Vladimir Putin and his forces pay for the atrocities committed in her country.

This journalism is made possible by viewers like you. Support your local PBS station here: http://www.pbs.org/donate​.

Love FRONTLINE? Find us on the PBS Video App, where there are more than 300 FRONTLINE documentaries available to watch any time: https://to.pbs.org/FLVideoApp​ 

Subscribe on YouTube: http://bit.ly/1BycsJW​
Instagram: https://www.instagram.com/frontlinepbs​
Twitter: https://twitter.com/frontlinepbs​
Facebook: https://www.facebook.com/frontline

Funding for FRONTLINE is provided through the support of PBS viewers and by the Corporation for Public Broadcasting. Additional funding is provided by the Abrams Foundation; the John D. and Catherine T. MacArthur Foundation; Park Foundation; the Heising-Simons Foundation; and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation, and additional support from Koo and Patricia Yuen.


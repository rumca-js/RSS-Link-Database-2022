# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Wait… Did They Just Admit That?
 - [https://www.youtube.com/watch?v=E_Nf0Q5XLjw](https://www.youtube.com/watch?v=E_Nf0Q5XLjw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-04-15 00:00:00+00:00

As a viral video last week showed college students in Chicago challenging journalists over the Hunter Biden business dealings, and more revelations around Russiagate come to light, why are the mainstream media not responding to the growing lack of trust in their narratives?
#HillaryClinton #HunterBiden #JoeBiden #DonaldTrump #RussiaGate 

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Fauci & Facebook's "False Information" Crackdown
 - [https://www.youtube.com/watch?v=SXgf7xwu8ws](https://www.youtube.com/watch?v=SXgf7xwu8ws)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-04-14 00:00:00+00:00

As Anthony Fauci is now branded as “false information” by Facebook, in relation to clip that has resurfaced from the past in which he discusses the flu vaccine, we ask, is this really about protecting the world from disinformation?
#Fauci #facebook #disinformation #vaccine

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


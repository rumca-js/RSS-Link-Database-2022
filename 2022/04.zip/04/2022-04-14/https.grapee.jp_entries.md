## Tokyo’s Manuscript Writing Cafe only allows writers on a deadline, and won’t let them leave until finished – grape Japan
 - [https://grapee.jp/en/199026](https://grapee.jp/en/199026)
 - RSS feed: https://grapee.jp
 - date published: 2022-04-14 20:16:19+00:00

Japanese manuscript writing cafe for writers in Tokyo only allows customers who are writers on a deadline, and doesn't let them leave until they've finished writing


# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Yes. I am a "Tech" YouTube unable to manage a Livestream. How could you tell?
 - [https://www.youtube.com/watch?v=HCLEb2I-VdM](https://www.youtube.com/watch?v=HCLEb2I-VdM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2022-04-15 00:00:00+00:00

Reading donations: https://donate.lukesmith.xyz
Or superchat with Monero: https://xmr.lukesmith.xyz


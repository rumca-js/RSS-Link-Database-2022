# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## An Update On My Fraud - WAN Show April 15, 2022
 - [https://www.youtube.com/watch?v=TEygSwHWhfA](https://www.youtube.com/watch?v=TEygSwHWhfA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-04-15 00:00:00+00:00

Sign up for OVHcloud and get a free consultation & save 40% on Veeam Backup & Replication at https://bit.ly/3jCuQ0U

Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off

Try Vultr today with an exclusive 30-day $100 code for signing up at https://getvultr.com/LTT

Floatplane Developer Application Forms:
Front end: https://forms.gle/Tr3kvqYAuDTFaFiA8
Back end: https://forms.gle/PBBKya1zcD27iPew8

Check out the WAN Show & Podcast Gear: https://lmg.gg/podcastgear
Check out the They're Just Movies Podcast: https://lmg.gg/tjmpodcast

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/An-Update-On-My-Fraud---WAN-Show-April-15--2022-e1hag7l

Timestamps: (Courtesy of NoKi1119)
0:00 Chapters
1:04 Intro ft. Stream Deck issues
1:50 Topic #1 - Yvonne & Linus's wire fraud update
3:56 Explaining the fraud
6:08 Fraud update, incompetent authorities
12:16 Linus's take on financial crimes
15:16 Linus voicing his frustration, discussing wages
17:21 Money returned, Linus states his opinion on the system
19:41 Topic #2 - JC's first tweet NFT to lose almost $29m
23:22 NFTs in gaming & assets
25:40 LTTStore eggshell t-shirt, waffle long-sleeve
31:36 Topic #3 - Linus's re-take on Elon Musk
32:35 Clarifying last WAN's & current points
38:03 Elon purchasing Twitter, thoughts on Elon & stocks
46:18 Final thoughts on the stocks purchase & pricing manipulation
49:36 Merch Messages #1, issues with many messages
50:45 Luke's flamethrower "idea"
51:08 Home painting & color suggestions
54:16 LTTStore gift cards, $1000 gift cards
56:48 Hardest choice made on LTT, Luke investment & Linus's LinkedIn
1:05:24 Sponsor - OVHcloud
1:07:52 Sponsor - Squarespace
1:08:40 Sponsor - Vultr
1:09:36 Topic #4 - Honda takes down 3D printable of their models
1:15:50 Topic #5 - Tim Cook hates side-loading
1:18:45 LTTStore "bed ripper" duvets idea, strawpoll
1:20:58 Merch Messages #3
1:21:16 Chinese smartphones & personal user data
1:23:26 More streams with other LMG users idea
1:24:44 Best remote networking, Starlink
1:25:34 Touring ASML factories
1:26:54 Ubiquiti security system & lawsuit discussion idea
1:27:44 Running LMG & the warehouse
1:30:16 Competition & innovation in cheap tech
1:31:32 "Legal" emulation video update
1:32:16 Nick calls, strawpoll update
1:34:15 Outro

## "The Fastest Gaming CPU in the World" - Ryzen 7 5800X3D
 - [https://www.youtube.com/watch?v=O0gbfvJDsv4](https://www.youtube.com/watch?v=O0gbfvJDsv4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-04-14 00:00:00+00:00

Get 50% off your Zoho CRM annual subscription at: https://lmg.gg/ZohoCRM

Check out the Lambda Tensorbook at https://lambdalabs.com/linus

Intel got out ahead of AMD’s newest Ryzen CPU launch with the Core i9-12900KS – Was it enough to take the fight out of AMD’s 3D V-Cache Ryzen 7 5800X3D, or is it still the world’s fastest gaming CPU?

Discuss on the forum: https://linustechtips.com/topic/1424735-the-fastest-gaming-cpu-in-the-world/


Buy an AMD Ryzen 7 5800X3D: https://lmg.gg/Rl2OD

Buy an AMD Ryzen 7 5800X: https://geni.us/UNCh

Buy an AMD Ryzen 9 5950X: https://geni.us/11DYJ

Buy an Intel Core i7-12700K: https://geni.us/fnNXqZ

Buy an Intel Core i9-12900K: https://geni.us/WfcPFYi

Buy an Intel Core i9-12900KS: https://geni.us/mEYYHt5

Buy an ASUS Maximus Z690 Hero: https://geni.us/BW2w0

Buy an ASUS Crosshair VIII Hero Wi-Fi: https://geni.us/munZ

Buy a Nvidia GeForce RTX 3090 Ti: https://geni.us/spQ428B

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:01 What's so "3D" about it and why is it for cache?
2:44 Gaming benchmarks
4:29 Productivity benchmarks
5:44 Thermals & power consumption
6:25 Overclocking...
7:11 Conclusion: Is it the fastest...?


## #4 To już jest koniec, ostatki w Miami z @vlogcasha
 - [https://www.youtube.com/watch?v=O-VIbL2XH3Q](https://www.youtube.com/watch?v=O-VIbL2XH3Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIFlYVfPnvukmFOvC4JUfOg
 - date published: 2022-04-05 00:00:00+00:00

Wszystko co dobre szybko się kończy, skondensowany zapis ostatnich kilku dni z @vlogcasha  w Miami przed rozstaniem się na dobre.

A Simple Eggstaurant
1516 Washington Ave, Miami Beach, FL 33139 
Adres: https://g.page/eggstaurant?share
📷 Instagram https://www.instagram.com/eggstaurant 
🧗🏻Wesprzyj moje przygody na patronite: https://patronite.pl/Nejtan
📷 Instagram: https://www.instagram.com/nejthan
📜 Napisz do mnie: swiatwedlugnejtana@gmail.com
🎵 Muzyka: https://share.epidemicsound.com/m7uq26

2022 Trip z  @vlogcasha    po Florydzie https://bit.ly/3uueZGV
2021 Trip z  @vlogcasha    po zachodzie Usa i Alaska
https://bit.ly/3D6ClpI
#swiatwedlugnejtana #nejtan


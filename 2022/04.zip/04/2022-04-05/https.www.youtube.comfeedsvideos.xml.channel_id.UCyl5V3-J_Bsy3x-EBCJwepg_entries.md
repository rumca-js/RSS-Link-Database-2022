# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Tuttle Twins Episode 8 Premiere with The Babylon Bee
 - [https://www.youtube.com/watch?v=wZ-I57PF0oo](https://www.youtube.com/watch?v=wZ-I57PF0oo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-04-06 00:00:00+00:00

Editor-in-chief Kyle Mann of The Babylon Bee joined The Tuttle Twins for the premiere of Episode 8. JOIN THE DROP AT https://www.angel.com/NFT!

Why doesn't everyone get equal pay? Join Ethan and Emily as they travel back in time to visit people like Babe Ruth and learn about the economic value that people provide.

Join the Tuttle Twins and Babylon Bee for the release of Episode 8!

## Auditions For New White House Press Secretary
 - [https://www.youtube.com/watch?v=5xtYJnK4aIs](https://www.youtube.com/watch?v=5xtYJnK4aIs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-04-05 00:00:00+00:00

Jen Psaki has announced her plan to resign as press secretary. We've obtained the exclusive tape from those auditioning to be her replacement. Pull up a chair, settle in, and circle back.

Subscribe to Chandler's Youtube: https://www.YouTube.com/chandlerjuliet

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


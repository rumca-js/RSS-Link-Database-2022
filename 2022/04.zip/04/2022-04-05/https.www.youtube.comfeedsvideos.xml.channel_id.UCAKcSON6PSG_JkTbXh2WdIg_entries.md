# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Superchunk - Endless Summer (live for The Current)
 - [https://www.youtube.com/watch?v=9svSBOTkx60](https://www.youtube.com/watch?v=9svSBOTkx60)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-04-06 00:00:00+00:00

Following the release of their 2022 album 'Wild Loneliness,' North Carolina's Superchunk join The Current to play "Endless Summer" from their new record. 

Plus, check out the bands full virtual session, including an interview with Superchunk's Mac McCaughan: https://youtu.be/jQOG6dhv8qs

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits: 
Superchunk - Jon Wurster, Jim Wilbur, Jason Narducy, Mac McCaughan
Producers - Jesse Wiza, Derrick Stevens
Technical Director - Eric Romani

## Superchunk - Wild Loneliness (live for The Current)
 - [https://www.youtube.com/watch?v=W5udbm2FR_Y](https://www.youtube.com/watch?v=W5udbm2FR_Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-04-06 00:00:00+00:00

Following the release of their 2022 album 'Wild Loneliness,' North Carolina's Superchunk join The Current to play the title track from the new record. 

Plus, check out the bands full virtual session, including an interview with Superchunk's Mac McCaughan: https://youtu.be/jQOG6dhv8qs

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits: 
Superchunk - Jon Wurster, Jim Wilbur, Jason Narducy, Mac McCaughan
Digital Producer - Jesse Wiza
Technical Director - Eric Romani


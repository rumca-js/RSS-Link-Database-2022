# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## YouTube SCAMS To Watch Out For
 - [https://www.youtube.com/watch?v=wfrhlG_Xns8](https://www.youtube.com/watch?v=wfrhlG_Xns8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2022-04-06 00:00:00+00:00

• Get up to 83% off Private Internet Access VPN!  ⇨ https://privateinternetaccess.com/TJ (Sponsored)

▼ Time Stamps: ▼
0:00 - Intro
0:27 - Very Good Message Indeed
1:42 - Scam Type #1
4:11 - Scam Type #2
5:57 - Scam Type #3
8:21 - Scam Type #4

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬


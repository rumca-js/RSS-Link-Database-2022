# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Dune: The Indian behind VFX Oscar for sci-fi epic
 - [https://www.bbc.co.uk/news/world-asia-india-60983131?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-60983131?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 23:56:04+00:00

Namit Malhotra started his company from a garage in Mumbai. Now it's winning Academy Awards.

## Brazil at work: Black and held back
 - [https://www.bbc.co.uk/news/world-latin-america-60980009?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-60980009?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 23:52:18+00:00

Brazil has one of the largest black and mixed race populations but black people only hold 6% of managerial posts.

## South Korea: Why so many struggle to sleep
 - [https://www.bbc.co.uk/news/world-asia-60703300?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-60703300?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 23:45:49+00:00

Growing numbers of South Koreans suffer from sleep deprivation, with many turning to sleeping pills.

## Hydra: How German police dismantled Russian darknet site
 - [https://www.bbc.co.uk/news/technology-61002904?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-61002904?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 23:31:42+00:00

German police say illegal sales on the site amounted to at least £1bn a year

## The guitarist who saved hundreds of people on a sinking cruise liner
 - [https://www.bbc.co.uk/news/world-africa-60841291?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-60841291?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 23:29:40+00:00

Guitarist Moss Hills helped evacuate a sinking cruise liner after some of the crew jumped ship

## Bucha killings: 'I wish they had killed me too'
 - [https://www.bbc.co.uk/news/world-europe-61003878?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61003878?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 23:18:35+00:00

A family tells the BBC how Oleg Abramov, a welder in Bucha, was shot dead outside his home.

## Obama jokes with 'Vice-President Biden' at White House
 - [https://www.bbc.co.uk/news/world-us-canada-61005429?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-61005429?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 23:18:13+00:00

The former president can't help ribbing his old deputy on a "good old days" jaunt to the White House.

## Who is this future pop megastar on archive TV reel?
 - [https://www.bbc.co.uk/news/world-us-canada-61005427?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-61005427?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 23:11:31+00:00

A local TV producer was stunned to recognise this boy in footage from outside a school 50 years ago.

## Will France's 'forgotten' workers get what they want?
 - [https://www.bbc.co.uk/news/business-60958295?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60958295?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 23:07:10+00:00

Post-election the country's next leader must decide whether to re-invest in heavy industry, or not.

## The siege of Sarajevo 30 years on: ‘We felt forgotten'
 - [https://www.bbc.co.uk/news/world-europe-60983643?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60983643?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 23:01:19+00:00

Zlata Filipovic was amongst the Bosnian children who witnessed the atrocities in Sarajevo 30 years ago.

## Brain injury: ‘They leave their walking frames and they’re free’
 - [https://www.bbc.co.uk/news/uk-northern-ireland-60989252?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-60989252?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 23:01:18+00:00

People with brain injuries in Belfast are rediscovering their love of cycling.

## A Ukrainian man has to choose between his family and his country
 - [https://www.bbc.co.uk/news/world-europe-60996098?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60996098?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 23:01:16+00:00

A Ukrainian man has to choose between his family and his country.

## Ukraine round-up: The evidence vs Russian denials
 - [https://www.bbc.co.uk/news/world-europe-60997639?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60997639?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 20:00:07+00:00

The UN hears of alleged Russian atrocities as Moscow accuses Ukraine of staging the killings.

## War in Ukraine: 'I saw a Russian soldier shoot my father dead in Bucha'
 - [https://www.bbc.co.uk/news/world-europe-60989121?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60989121?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 19:04:24+00:00

Teenager's account adds to growing evidence of atrocities allegedly committed by Russian soldiers in Bucha.

## 100-year-old takes computer classes at local library
 - [https://www.bbc.co.uk/news/uk-wales-61002602?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-61002602?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 17:16:32+00:00

Margaret Griffiths, a retired headteacher, keeps her mind sharp by learning something new every day

## Bucha killings: Satellite image of bodies site contradicts Russian claims
 - [https://www.bbc.co.uk/news/60981238?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/60981238?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 17:13:56+00:00

Russia called footage of bodies in Bucha 'staged' but its evidence for this does not stack up.

## EU targets Russian coal and ships in new sanctions
 - [https://www.bbc.co.uk/news/world-europe-60993645?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60993645?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 14:19:07+00:00

Revelations of atrocities have added impetus to calls for further measures against Russia's economy.

## Bobbi-Anne McLeod: Man admits teenager's murder
 - [https://www.bbc.co.uk/news/uk-england-devon-60987941?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-devon-60987941?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 13:29:10+00:00

Cody Ackland admits murdering the 18-year-old, who was last seen at a bus stop in Plymouth.

## Manchester Airport: Police could help tackle 'chaos', mayor says
 - [https://www.bbc.co.uk/news/uk-england-manchester-60994073?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-60994073?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 13:20:20+00:00

Mayor Andy Burnham is meeting Manchester Airport bosses to discuss the "concerning" situation.

## British charity hunts for team to run Antarctica post office
 - [https://www.bbc.co.uk/news/uk-60994404?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60994404?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 12:46:13+00:00

Tasks also include counting penguins and general maintenance, though they will not have running water.

## British father and son, 9, killed in Australian mountain landslide
 - [https://www.bbc.co.uk/news/world-australia-60991775?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-60991775?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 12:42:36+00:00

Two other family members, a woman, 50, and her 14-year-old son, are in hospital with critical injuries.

## 'Hero' Richard Woodcock sacrificed life to save boy in Milton Keynes
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-60996074?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-60996074?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 12:38:59+00:00

Richard Woodcock had gone to help a two-year-old neighbour who was in trouble, an inquest hears.

## Energy: What do we know about the UK's new strategy?
 - [https://www.bbc.co.uk/news/uk-politics-60982346?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60982346?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 12:22:54+00:00

A government strategy is expected to contain plans to expand nuclear and offshore wind power.

## Liverpool: Mohamed Salah wants to sign new deal - Egypt sports minister
 - [https://www.bbc.co.uk/sport/football/60997940?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60997940?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 12:04:58+00:00

Forward Mohamed Salah intends to sign a new deal at Liverpool, says Egypt sports minister Ashraf Sobhi.

## Ukraine war: Zelensky fears worst atrocities still to be found
 - [https://www.bbc.co.uk/news/world-europe-60994848?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60994848?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 11:58:56+00:00

Ukraine's president says Borodyanka may have suffered more than other towns abandoned by Russian troops.

## Channel 4 stars speak out on privatisation plan
 - [https://www.bbc.co.uk/news/entertainment-arts-60993888?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60993888?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 10:52:15+00:00

Kirstie Allsopp and Matt Lucas voice concerns about a government plan to privatise the broadcaster.

## New rules on gambling adverts ban celebrities and sports stars
 - [https://www.bbc.co.uk/news/business-60994728?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60994728?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 10:47:25+00:00

Firms will not be able to use stars like footballer Cristiano Ronaldo and Love Island's Chris Hughes.

## England: Niamh Charles & Beth England out of World Cup qualifier
 - [https://www.bbc.co.uk/sport/football/60993379?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60993379?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 10:34:16+00:00

Forwards Niamh Charles and Beth England will miss England's World Cup qualifier in North Macedonia on Friday after testing positive for Covid.

## Shanghai Covid lockdown extended to entire city
 - [https://www.bbc.co.uk/news/world-asia-china-60994022?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-60994022?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 10:07:30+00:00

China's financial hub is now subject to indefinite restrictions after Covid cases hit a new high.

## Rare Sumatran rhino gives birth after eight miscarriages
 - [https://www.bbc.co.uk/news/world-60993659?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-60993659?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 10:04:42+00:00

The critically endangered Sumatran rhino gave birth to a female calf in an Indonesian sanctuary.

## Ukrainian boy building Lego again thanks to 'non-stop' donations
 - [https://www.bbc.co.uk/news/world-europe-60994304?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60994304?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 09:53:43+00:00

Lego enthusiast Andrey Sigorov, 11, was forced to leave his collection behind when he came to Ireland.

## Cardi B wins order forcing YouTuber to remove defamatory videos
 - [https://www.bbc.co.uk/news/newsbeat-60995424?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-60995424?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 09:48:50+00:00

A judge has ordered Latasha Kebe, known as Tasha K, to to delete and never repost defamatory videos.

## Masters: Tiger Woods backed to play at Augusta National
 - [https://www.bbc.co.uk/sport/golf/60994628?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/golf/60994628?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 09:48:28+00:00

There was an "atmosphere like you've never seen before" at Augusta National on Monday as thousands of fans swarmed after Tiger Woods who is trying to prove he is fit to play this week's major.

## What is Russia's Wagner Group of mercenaries in Ukraine?
 - [https://www.bbc.co.uk/news/world-60947877?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-60947877?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 09:34:35+00:00

The Wagner Group is a shadowy Russian mercenary organisation which has been active across the world.

## MOTD Top 10: Trent Alexander-Arnold - assist king
 - [https://www.bbc.co.uk/sport/av/football/60994514?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/60994514?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 08:12:09+00:00

On this week's MOTD Top 10 podcast, Gary Lineker, Alan Shearer and Micah Richards discuss the best set-piece takers in Premier League history - but who is number one?

## Benfica v Liverpool: How Portuguese club overcame internal unrest to reach Champions League quarter-finals
 - [https://www.bbc.co.uk/sport/football/60980975?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60980975?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 05:59:38+00:00

Benfica have endured a miserable season in many ways, yet have impressed in Europe and on Tuesday face Liverpool in the Champions League quarter-finals.

## The Papers: Zelensky 'haunted' by Bucha visit, and tribute to soap icon
 - [https://www.bbc.co.uk/news/blogs-the-papers-60991441?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-60991441?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 05:04:28+00:00

Papers picture President Volodymyr Zelensky as he visited the site of an alleged atrocity in Ukraine.

## 'Stolen' Charles Darwin notebooks left on library floor in pink gift bag
 - [https://www.bbc.co.uk/news/entertainment-arts-60980288?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60980288?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 04:32:52+00:00

Two books owned by Charles Darwin are left outside Cambridge University library in a pink gift bag.

## NHS not making progress on early cancer diagnosis
 - [https://www.bbc.co.uk/news/health-60988390?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-60988390?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-05 02:18:48+00:00

Progress in England has been static for six years - and pandemic may make outlook worse, MPs say.


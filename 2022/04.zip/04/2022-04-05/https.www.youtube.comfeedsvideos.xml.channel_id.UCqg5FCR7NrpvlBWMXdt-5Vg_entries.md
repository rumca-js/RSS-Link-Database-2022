# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Is Cyberpunk 2077 Finally Worth Playing in 2022? | Breakout
 - [https://www.youtube.com/watch?v=0ak9omR6YpQ](https://www.youtube.com/watch?v=0ak9omR6YpQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-04-06 00:00:00+00:00

Support the stream: https://streamlabs.com/theescapist1 With the big gaming lull finally here, Nick has been checking out Cyberpunk 2077 again after waiting patiently for the next-gen updates. Marty's still finding weird things in Kirby and KC has been enjoying LEGO Star Wars.

Featuring Nick Calandra, Marty Sliva and KC Nwosu, the freeform podcast dives into a bit of our daily lives, the latest games, movies, tv shows and books, the occasional craft beer review and random topics we find interesting.

New episodes every Wednesday morning from 9 AM to 10:00 AM CT. 

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Tiny Tina's Wonderlands (Zero Punctuation)
 - [https://www.youtube.com/watch?v=x-66lspUT0I](https://www.youtube.com/watch?v=x-66lspUT0I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-04-06 00:00:00+00:00

This week on Zero Punctuation, Yahtzee reviews Tiny Tina's Wonderlands. 

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#ZeroPunctuation

## Chrono Cross: The Radical Dreamers Edition | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=hzhzt-uUBHI](https://www.youtube.com/watch?v=hzhzt-uUBHI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-04-05 00:00:00+00:00

Marty Sliva reviews Chrono Cross: The Radical Dreamers Edition, developed by Square Enix.

Chrono Cross: The Radical Dreamers Edition on Steam: https://store.steampowered.com/app/1133760/CHRONO_CROSS_THE_RADICAL_DREAMERS_EDITION/

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Fantastic Beasts: The Secrets of Dumbledore Can't Recapture the Potter Magic | Review
 - [https://www.youtube.com/watch?v=n-9nqjqpv-A](https://www.youtube.com/watch?v=n-9nqjqpv-A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-04-05 00:00:00+00:00

Matthew Razak reviews Fantastic Beasts: The Secrets of Dumbledore for The Escapist.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## The Best (and Worst) Star Wars Video Games | Slightly Something Else
 - [https://www.youtube.com/watch?v=3MJhjb3TrZo](https://www.youtube.com/watch?v=3MJhjb3TrZo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-04-05 00:00:00+00:00

Support the stream: https://streamlabs.com/theescapist1 This episode of Slightly Something Else is brought to you by Ekster. Use our affiliate link to get 20% off your next smart wallet purchase. https://shop.ekster.com/theescapistmagazine

This week on Slightly Something Else, with the big new Star Wars game out, Yahtzee and Marty discuss the best and worst Star Wars video games.

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag


# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## 90s Time Traveler Discovers NFTs
 - [https://www.youtube.com/watch?v=TcmpqeIcbAw](https://www.youtube.com/watch?v=TcmpqeIcbAw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2022-04-06 00:00:00+00:00

Go to https://buyraycon.com/ryangeorge for 15% off your order! Brought to you by Raycon.

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats.
Twitter/Instagram: @TheRyanGeorge


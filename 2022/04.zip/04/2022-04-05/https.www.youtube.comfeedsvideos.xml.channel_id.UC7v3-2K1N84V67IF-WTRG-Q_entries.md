# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Fantastic Beasts: The Secrets of Dumbledore - Movie Review
 - [https://www.youtube.com/watch?v=keHhQmttBik](https://www.youtube.com/watch?v=keHhQmttBik)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-04-05 00:00:00+00:00

The saga of the milking of the Wizarding World continues with the 3rd Fantastic Beasts movie. Here's my review for FANTASTIC BEASTS: THE SECRETS OF DUMBLEDORE!

#FantasticBeasts #WizardingWorld


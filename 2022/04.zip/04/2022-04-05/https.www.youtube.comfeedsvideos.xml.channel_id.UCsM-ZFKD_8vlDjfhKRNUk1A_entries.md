# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## BOKKA - 900 - live MUZO.FM
 - [https://www.youtube.com/watch?v=paQpWyXtJoM](https://www.youtube.com/watch?v=paQpWyXtJoM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2022-04-05 00:00:00+00:00

BOKKA na żywo w MUZO.FM. Utwór 900 pochodzi z płyty Blood Moon. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV

Facebook BOKKA: http://www.facebook.com/bokkamusic
Instagram BOKKA: http://www.instagram.com/bokkamusic

Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


Rejestracja audio: Sebastian Zalewski
Mix: BOKKA
Światła: Artur „Żarów” Solmiński


BOKKA 900 tekst

I won’t fall
I won’t follow
I won’t follow you inside this horror
I won’t go
I won’t go on
I won’t let you take me down this road


I am so tired
You’ll never see it on my face
But I am so tired
all alone with the mess


Never again, never again, never again I’ll fall 
for this wicked road, this wicked road
Never again, never again, never again I’ll fall 
for this wicked road, this wicked road


I won’t be
I won’t become
Someone else, it doesn’t work like that
I won’t stand
I won’t stand by
You are on your own and I’m on mine


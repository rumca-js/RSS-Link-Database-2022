# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Disney is Grooming Your Children?!
 - [https://www.youtube.com/watch?v=7nkRutlagOM](https://www.youtube.com/watch?v=7nkRutlagOM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-04-06 00:00:00+00:00

Grab your Cacao Bliss at https://earthechofoods.com/jpsears
Use Code "JP" for 15% Off!

Check Out My Merch Here - https://awakenwithjp.com

See my LIVE Comedy Shows - https://awakenwithjp.com/pages/events

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Is Disney grooming your children? In this special report we look into the "Secret Gay Agenda" of Disney employees to indoctrinate your children. Also Governor Ron DeSantis is fighting back! 

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

## The Best Female Swimmer in the World!
 - [https://www.youtube.com/watch?v=_sgjc29QCGo](https://www.youtube.com/watch?v=_sgjc29QCGo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-04-05 00:00:00+00:00

Grab your Real White Sonic Toothbrush at https://naturaltoothbrush.com/jpsears

Check Out My Merch Here - https://awakenwithjp.com

See my LIVE Comedy Shows - https://awakenwithjp.com/pages/events

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Being the top female swimmer in the world isn't easy. Especially when your teammates are scared to be around you. Here's what it's like being the top female swimmer!

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com


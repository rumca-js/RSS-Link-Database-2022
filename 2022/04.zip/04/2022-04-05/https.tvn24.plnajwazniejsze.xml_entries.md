# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Małgorzata zmarła od razu, Laura cztery dni później, w szpitalu. Krzysztof S. nie pamięta, jak je zabił
 - [https://tvn24.pl/premium/gilowice-sprawa-wypadku-w-ktorym-zginely-malgorzata-rodak-i-jej-corka-laura-5661429?source=rss](https://tvn24.pl/premium/gilowice-sprawa-wypadku-w-ktorym-zginely-malgorzata-rodak-i-jej-corka-laura-5661429?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-04-05 11:07:28+00:00

<img alt="Małgorzata zmarła od razu, Laura cztery dni później, w szpitalu. Krzysztof S. nie pamięta, jak je zabił" src="https://tvn24.pl/najnowsze/cdn-zdjecie-y37yxx-pwa-1-5663414/alternates/LANDSCAPE_1280" />
    Wbiegł mu pod koła czarny pies. Odbił w prawo, by go nie potrącić i wjechał do rowu. Próbował skręcić w lewo, hamować, wrócić na drogę - tak mówił w śledztwie. W sądzie tego nie pamiętał. Było jakieś zwierzę, ale w rowie doznał chwilowej utraty przytomności. Uderzył w mostek i wtedy dopiero się ocknął. Lecąc w powietrzu, porwał z mostku żonę i córkę Andrzeja, który stał obok nich i przeżył.


# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## The Prettiest Gaming Setup - Intel $5,000 Extreme Tech Upgrade
 - [https://www.youtube.com/watch?v=gCnJjWRf5dk](https://www.youtube.com/watch?v=gCnJjWRf5dk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-04-06 00:00:00+00:00

Thanks to Intel for continuing to sponsor this series! Buy an Intel CORE 12700K: https://geni.us/BoeG

Discuss on the forum: https://linustechtips.com/topic/1423097-the-prettiest-gaming-setup-intel-5000-extreme-tech-upgrade/

GroveMade: https://bit.ly/LINUSGM

Buy a Zotac RTX 3060 AMP: https://geni.us/G3zfVDR

Buy an ASUS Z690-A Strix: https://geni.us/SpRnZ

Buy a Corsair 4000X RGB: https://geni.us/QrSYGN

Buy an Gigabyte G27Q 27" Monitor: https://geni.us/3Mdzsg

Buy a Logitech C920S: https://geni.us/caAjFv

Buy an LG G Pro X Superlight: https://geni.us/U3bA

Buy a Rode PSA1 Mic Arm: https://geni.us/XYc7aE

Buy an AT2020 USB Mic: https://geni.us/AtsD5Wx

Buy a AT8458a Mic Shock Mount: https://geni.us/rHjDhqx

Buy the Kanto YU2 Speakers: https://geni.us/o03c4

Buy the Kanto S2 Stands: https://geni.us/sHcN

Buy a SecretLab TITAN EVO 2022: https://lmg.gg/SecretlabSC

Buy a Wacom Intuos Tablet: https://geni.us/EvxnJT

Buy the Posca Pens set: https://geni.us/PzerlMM

Buy an Anker PowerExpand 9-in-2 Media Hub: https://geni.us/omxgZw

Buy a Vitruvi Diffuser: https://geni.us/kvyRDTR

Buy an IKEA Lack Shelf: https://geni.us/IPKfx

Buy an Nanoleaf Light Panels Smarter Kit: https://geni.us/puS6

Buy a Universal Audio Volt 1 USB-C Audio Interface: https://geni.us/FHCQr6

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 – Intro 
1:38 – Sarah’s Parts
4:46 – Building the PC
14:14 – Setting up her Streaming and Design Space
20:53 – Unboxing the rest
23:12 - Conclusion

## I Tried to Break a Million Dollar Computer - IBM Z16 Facility Tour!
 - [https://www.youtube.com/watch?v=ZDtaanCENbc](https://www.youtube.com/watch?v=ZDtaanCENbc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-04-05 00:00:00+00:00

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/linus

Save 10% and Free Worldwide Shipping at Ridge Wallet by using offer code LINUS at https://www.ridge.com/LINUS

IBM invited us to do a facility tour showing off the mainframes they sell to high frequency trading customers and the like. You want to see wacky, custom hardware? This is it!

Discuss on the forum: https://linustechtips.com/topic/1422880-i-tried-to-break-a-million-dollar-computer-ibm-tour/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:16 What's a Z16?
1:55 Cooling
3:00 Power
3:40 Compute
6:00 Nutty Socket
9:18 Crazy VRMs
11:24 RAM like you've never seen it before
12:50 Cache work weird
15:00 now THIS is networking!
19:30 Welcome to the Patch Room
21:15 "my wife unit"
21:42 What's this for?
22:15 Price $$
23:45 Outro


## A Tale of Yak Shaving: Accidentally Making a Language, for an Engine, for a Game
 - [https://verdagon.dev/blog/yak-shave-language-engine-game](https://verdagon.dev/blog/yak-shave-language-engine-game)
 - RSS feed: https://verdagon.dev
 - date published: 2022-04-05 11:38:52+00:00




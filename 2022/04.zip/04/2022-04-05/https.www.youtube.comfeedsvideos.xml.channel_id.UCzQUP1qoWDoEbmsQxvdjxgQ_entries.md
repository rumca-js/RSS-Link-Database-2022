# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## The UFC's Jim Miller on His Battle with Lyme Disease
 - [https://www.youtube.com/watch?v=Rj9-4hMgvPg](https://www.youtube.com/watch?v=Rj9-4hMgvPg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-04-06 00:00:00+00:00

Taken from JRE MMA Show #120 w/Jim Miller:
https://open.spotify.com/episode/78iIqoRx7hDgMoloX2qfVE?si=07a65b112692493f

## David Mamet on Current State of Hollywood
 - [https://www.youtube.com/watch?v=MwuUrpzYTRs](https://www.youtube.com/watch?v=MwuUrpzYTRs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-04-05 00:00:00+00:00

Taken from JRE #1801 w/David Mamet:
https://open.spotify.com/episode/0EGUBSTWebFwgzfr96q2Ci?si=b72fc3fecd4846b9

## David Mamet on the Important Mythology of the Bible
 - [https://www.youtube.com/watch?v=fds6Nm1QQNk](https://www.youtube.com/watch?v=fds6Nm1QQNk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-04-05 00:00:00+00:00

Taken from JRE #1801 w/David Mamet:
https://open.spotify.com/episode/0EGUBSTWebFwgzfr96q2Ci?si=b72fc3fecd4846b9


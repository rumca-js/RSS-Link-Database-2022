# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Blackrock Want To BAN Crypto Because Of THIS
 - [https://www.youtube.com/watch?v=pvb1mXjrCPI](https://www.youtube.com/watch?v=pvb1mXjrCPI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-04-06 00:00:00+00:00

The CEO of BlackRock has said that the Ukraine invasion could be used to accelerate use of central bank digital currencies. Luckily, Blackrock aren’t a very big company with connections to government with authority that rivals the World Bank, so nothing to worry about. #Bitcoin #DigitalCurrencies #Ukraine #War

References
https://reclaimthenet.org/blackrock-russia-cbdc-push/
https://www.jacobinmag.com/2022/03/index-funds-blackrock-vanguard-stocks-ownership-democracy-concentration

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Big Tech & Big Media Are Teaming Up Against You
 - [https://www.youtube.com/watch?v=0iKcd-ItB90](https://www.youtube.com/watch?v=0iKcd-ItB90)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-04-05 00:00:00+00:00

A proposed bi-partisan bill would push Big Tech and Big Media to make content distribution deals, further cementing their alliance and pushing out independent creators. 
#BigTech #MainstreamMedia #CNN #FoxNews

References
https://reclaimthenet.org/bi-partisan-bill-would-push-big-tech-and-big-media-to-make-content-distribution-deals/
https://www.freepress.net/news/press-releases/journalism-competition-and-preservation-act-bad-news-local-journalism-and

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


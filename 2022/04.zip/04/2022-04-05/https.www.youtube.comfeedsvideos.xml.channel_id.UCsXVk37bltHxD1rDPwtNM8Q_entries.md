# Source:Kurzgesagt – In a Nutshell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q, language:en-US

## We WILL Fix Climate Change!
 - [https://www.youtube.com/watch?v=LxgMdjyw8uw](https://www.youtube.com/watch?v=LxgMdjyw8uw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q
 - date published: 2022-04-05 00:00:00+00:00

Getting something from the kurzgesagt shop is the best way to support us and to keep our videos free for everyone. ►► https://kgs.link/shop-159     
(Worldwide Shipping Available)

Sources & further reading:
https://sites.google.com/view/sources-can-we-fix-climate/

Visit https://brilliant.org/nutshell/ to get started learning STEM for free, and the first 200 people will get 20% off their annual premium subscription.

Our home is burning. Rapid climate change is destabilizing our world. It seems our emissions will not fall quickly enough to avoid runaway warming and we may soon hit tipping points that will lead to the collapse of ecosystems and our civilization.

While scientists, activists and much of the younger generation urge action, it appears most politicians are not committed to do anything meaningful while the fossil fuel industry still works actively against change. It seems humanity can’t overcome its greed and obsession with short term profit and personal gain to save itself. 

And so for many the future looks grim and hopeless. Young people feel particularly anxious and depressed. Instead of looking ahead to a lifetime of opportunity they wonder if they will even have a future or if they should bring kids into this world. It’s an age of doom and hopelessness and giving up seems the only sensible thing to do. 

But that’s not true. You are not doomed. Humanity is not doomed.


OUR CHANNELS
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
German Channel: https://kgs.link/youtubeDE 
Spanish Channel: https://kgs.link/youtubeES 


HOW CAN YOU SUPPORT US?
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
This is how we make our living and it would be a pleasure if you support us!

Get Merch designed with ❤ https://kgs.link/shop  
Join the Patreon Bird Army 🐧  https://kgs.link/patreon  


DISCUSSIONS & SOCIAL MEDIA
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Reddit:            https://kgs.link/reddit
Instagram:     https://kgs.link/instagram
Twitter:           https://kgs.link/twitter
Facebook:      https://kgs.link/facebook
Discord:          https://kgs.link/discord
Newsletter:    https://kgs.link/newsletter


OUR VOICE
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
The Kurzgesagt voice is from 
Steve Taylor:  https://kgs.link/youtube-voice


OUR MUSIC ♬♪
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
700+ minutes of Kurzgesagt Soundtracks by Epic Mountain:

Spotify:            https://kgs.link/music-spotify
Soundcloud:   https://kgs.link/music-soundcloud
Bandcamp:     https://kgs.link/music-bandcamp
Youtube:          https://kgs.link/music-youtube
Facebook:       https://kgs.link/music-facebook

The Soundtrack of this video:
Soundcloud: https://bit.ly/3v0ZGWu
Bandcamp: https://bit.ly/3r4qF29

If you want to help us caption this video, please send subtitles to subtitle@kurzgesagt.org
You can find info on what subtitle files work on YouTube here:
https://support.google.com/youtube/answer/2734698?hl=en-GB&ref_topic=7296214
Thank you!

🐦🐧🐤 PATREON BIRD ARMY 🐤🐧🐦
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Many Thanks to our wonderful Patreons (from http://kgs.link/patreon) who support us every month and made this video possible:
Markus Schaidinger, nanowashere x, Nicholas Bales, Alexis St-Laurent, Roberto, Patrick Rathke, ThatTubaGuy, Michael Henry, Colin Stephens, Cy 'kkm' K'Nelson, Renen Adar, Kurt Steinkraus, erikfahr, Neo Architects, Sanne van Herwijnen, Alex Schumacher, Matt Gutberlet, Jose Barrera, Glenn Hall, Steven Dawson, Vengarth, Michael Patton, ggroggs, Gabriele Vissio, Wilee, Bernt Sietsma, Teddy Toussaint, Kisay, Jayce Collins, leandro, Cassandra Riling, Spencer Czapiewski, su4ns3t, Nicha Traipipattanapong, Eigenverse, Mikakohanpepperoni, Bonku BRB, Swagner, David Wagner, Random Dev, Litten, Luke Felix-Rose, Gabriel Steel, Chlorissa Pecha, Anatidae, freakazoid, Ayrton Aquiles Mera Concha, Christoph Stock, Bruce Kneale, ShakyHades ., Alexandre Paques, Sieghard Hillbrecht, Matthieu Heras, Victoria Morgan, Aubrey T, Wyvern, NDRS, Y.Tamino, Dan Walker, Bruce A Johnson, Luke Elasky, VictorHuerta, KeyarK, Patron12, Nail Saberov, Devon Charlton, Sara & Son, Porus, Julija Besciokova, Cathy Wu, Nikita Kozlov, Kira Kuhne, David Noack, Alex Suarez Mendez, DerRobot, Rimuru Tempest, Terell Seitz, Benjamin Duggan, Martyn Warry, John Doe, William Sallembien, Gabriele Quida, Skyler Foster, Ant Corke, Nicolas, Nuttakan Chuntra, Brin, Tactical Bagels, Nathan Zubrzycki, hollowjackals, Joshua Stringham, Anveio, Carla, Ethan Ogiba, Alin Nica, David Richard Bakken, DrummerGeek


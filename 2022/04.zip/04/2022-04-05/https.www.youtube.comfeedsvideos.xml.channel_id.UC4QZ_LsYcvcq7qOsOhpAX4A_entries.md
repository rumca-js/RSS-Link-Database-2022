# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## Why Elon Musk Became Twitter's Largest Shareholder
 - [https://www.youtube.com/watch?v=aWuc1RGNLe8](https://www.youtube.com/watch?v=aWuc1RGNLe8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2022-04-05 00:00:00+00:00

Update: He's now on the board. 
Elon Musk becoming the largest shareholder in Twitter certainly raises some eyebrows, but what caused him to make the move? And what could it all mean for Twitter's future?

» Podcast Discussing this in more depth: https://www.youtube.com/channel/UC6jKUaNXSnuW52CxexLcOJg

» ColdFusion Discord:  https://discord.gg/coldfusion

» ColdFusion Documentary on How Twitter Started | https://www.youtube.com/watch?v=p8N0xN0ihMA

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusioncollective
» Podcast Version of Videos: https://open.spotify.com/show/3dj6YGjgK3eA4Ti6G2Il8H
https://podcasts.apple.com/us/podcast/coldfusion/id1467404358

ColdFusion Music Channel: https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

ColdFusion Merch:
INTERNATIONAL: https://store.coldfusioncollective.com/
AUSTRALIA: https://shop.coldfusioncollective.com/

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- "New Thinking" written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

Sources:

https://money.cnn.com/quote/shareholders/shareholders.html?symb=TWTR&subView=institutional

https://www.abc.net.au/news/2022-04-04/elon-musk-buys-9-per-cent-stake-in-twitter/100965686

https://www.smh.com.au/business/companies/elon-musk-buys-stake-in-twitter-to-become-top-shareholder-20220405-p5aatd.html

https://www.pbs.org/newshour/economy/sec-claims-authority-to-subpoena-elon-musk-over-tweets

https://www.barrons.com/articles/tesla-ceo-elon-musk-sec-twitter-51648193760

https://www.bloomberg.com/news/articles/2022-03-29/musk-claims-sec-misconduct-as-he-seeks-end-to-limits-on-tweets

https://www.theverge.com/2022/3/8/22967122/elon-musk-tesla-sec-tweet-court-subpoena-investigation

https://tass.com/world/1427585?utm_source=google.com&utm_medium=organic&utm_campaign=google.com&utm_referrer=google.com

https://interestingengineering.com/11-of-elon-musks-most-controversial-and-surprising-tweets

https://www.engadget.com/the-morning-after-jack-dorsey-misses-the-old-internet-111305456.html

My Music Channel:  https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

//Soundtrack//

Sleepy Fish - Forgot It Was Monday 

Delectatio - It-s Ok

G Mills & Molly McPhaul - Waterfalls

Gem Club - First Weeks

A Zed And Two L's - Fila Brazillia

Burn Water - A Promise

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide


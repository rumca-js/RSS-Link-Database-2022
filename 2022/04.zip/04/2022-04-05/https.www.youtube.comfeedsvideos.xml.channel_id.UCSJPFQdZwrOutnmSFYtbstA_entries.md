# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Peacemaker - Better Than I Expected
 - [https://www.youtube.com/watch?v=tLM_G29WEDs](https://www.youtube.com/watch?v=tLM_G29WEDs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-04-06 00:00:00+00:00

I have to admit, I was skeptical about a TV spinoff from The Suicide Squad, but Peacemaker turned out to be a surprisingly good show.


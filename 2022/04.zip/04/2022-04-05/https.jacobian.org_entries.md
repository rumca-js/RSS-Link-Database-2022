## Exit Interviews Are a Trap - Jacob Kaplan-Moss
 - [https://jacobian.org/2022/apr/4/exit-interviews-are-a-trap/](https://jacobian.org/2022/apr/4/exit-interviews-are-a-trap/)
 - RSS feed: https://jacobian.org
 - date published: 2022-04-05 06:51:36+00:00

It’s tempting to air your grievances at your exit interview. Don’t. There’s almost no upside to speaking up, and tremendous potential downside. Avoid exit interviews if you can. If you must go, be totally bland; say nothing negative.


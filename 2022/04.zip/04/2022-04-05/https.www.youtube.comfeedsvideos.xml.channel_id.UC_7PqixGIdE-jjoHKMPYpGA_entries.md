# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Dlatego nie reklamuję CBD...
 - [https://www.youtube.com/watch?v=zv_CoSRC710](https://www.youtube.com/watch?v=zv_CoSRC710)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2022-04-06 00:00:00+00:00

📚 Kup moją najnowszą książkę ► https://siedem.alt.pl
Do 9 listopada darmowa wysyłka na terenie Polski

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
👉 Nasz naukowy portal► https://naukowybelkot.pl

📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

Tak... Będzie o olejkach CBD...

===
Czy można wierzyć publikacjom
👉 https://www.youtube.com/watch?v=Avq9X0SSiLU

Placebo
👉 https://www.youtube.com/watch?v=rgtPI8urtkE

===
Rozkład jazdy:

0:00 Twój ulubiony celebryta vs CBD
2:10 Źródła #disclaimer
3:52 Braki dowodów #disclaimer
5:00 Placebo #disclaimer
6:30 Czy działa na ludzi?
8:20 Czy uzależnia?
8:52 Bezpieczeństwo
11:50 Epilepsja
12:58 Ból
14:50 Nowotwory
15:17 Lęki
16:35 Choroby psychiczne
17:55 Przypadłości neurologiczne
18:40 Sen
19:01 Uzależnienia
19:40 Wiarygodność

===
Źródła (wybrane):

N. Black i in. - Cannabinoids for the treatment of mental disorders and symptoms of mental disorders: A systematic review and metaanalysis
D. Larsen i in. - Dosage, Efficacy and Safety of Cannabidiol Administration in Adults: A Systematic Review of Human Trials
J. Moltke i in. - Reasons for cannabidiol use: a crosssectional study of CBD users, focusing on self-perceived stress, anxiety, and sleep problems
M. Eisenstein - From menace to medicine
F. Pampolina i in. - Potential Clinical Benefits of CBD-Rich Cannabis Extracts Over Purified CBD in Treatment-Resistant Epilepsy: Observational Data Meta-analysis
C. White - Potential Clinical Benefits of CBD-Rich Cannabis Extracts Over Purified CBD in Treatment-Resistant Epilepsy: Observational Data Meta-analysis
D. Sholler i in. - Potential Clinical Benefits of CBD-Rich Cannabis Extracts Over Purified CBD in Treatment-Resistant Epilepsy: Observational Data Meta-analysis
E. Chesney i in. - Adverse effects of cannabidiol: a systematic review and meta-analysis of randomized clinical trials
K. Iffland i in. - An Update on Safety and Side Effects of Cannabidiol: A Review of Clinical Data and Relevant Animal Studies
N. Vozoris i in. - Morbidity and mortality associated with prescription cannabinoid drug use in COPD
E. Seltzer i in. - Cannabidiol (CBD) as a Promising Anti-Cancer Drug
E. Boland i in. - Cannabinoids for adult cancer-related pain: systematic review and meta-analysis
M. Mucke i in. - Systematic review and meta‐analysis of cannabinoids in palliative medicine
A. Hazekamp i in. - Grote variatie in samenstelling cannabisolie noopt tot rege
https://sciencebasedmedicine.org/where-are-we-with-cbd/


# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Broadband firms 'must do more to promote social tariffs'
 - [https://www.bbc.co.uk/news/technology-60983343?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-60983343?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-04-05 22:09:14+00:00

The culture secretary says suppliers must do more to promote discounted rates to low-income homes.

## Twitter moves to limit Russian government accounts
 - [https://www.bbc.co.uk/news/technology-60992373?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-60992373?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-04-05 16:10:59+00:00

The platform has taken action to limit more than 300 Kremlin accounts, including President Putin's.

## What are Elon Musk's plans for Twitter?
 - [https://www.bbc.co.uk/news/technology-60995694?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-60995694?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-04-05 13:19:05+00:00

The Tesla founder has become the social network's biggest single shareholder, and a board member.

## The Works forced to shut some shops after cyber-attack
 - [https://www.bbc.co.uk/news/business-60993635?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60993635?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-04-05 11:06:24+00:00

The retailer said that five of its 526 shops have temporarily been shut since the attack last week.

## Zomato and Swiggy: Indian food delivery unicorns face antitrust probe
 - [https://www.bbc.co.uk/news/world-asia-india-60992263?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-60992263?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-04-05 05:15:29+00:00

The country's competition watchdog is probing allegations that the firms charge exorbitant commissions.


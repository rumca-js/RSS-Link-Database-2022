# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Elden Ring: 10 Things To Do After You FINISH THE GAME
 - [https://www.youtube.com/watch?v=IeaUet3sDW0](https://www.youtube.com/watch?v=IeaUet3sDW0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-04-06 00:00:00+00:00

Elden Ring (PC, PS5, PS4, Xbox Series X/S/One) is a massive game, and it's not over at the "end" screen. Here's what you should do after the end.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#EldenRing

## Lego Star Wars: The Skywalker Saga - 10 Things The Game Doesn't Tell You
 - [https://www.youtube.com/watch?v=VbU2W3JzXeI](https://www.youtube.com/watch?v=VbU2W3JzXeI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-04-05 00:00:00+00:00

LEGO Star Wars: The Skwalker Saga (PC, PS5, PS4, Xbox Series X/S/One, Nintendo Switch) is filled with cool things to discover and a few tricks along the way.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#LEGOstarwars


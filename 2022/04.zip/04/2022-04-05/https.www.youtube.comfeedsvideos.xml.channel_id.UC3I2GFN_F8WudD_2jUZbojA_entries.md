# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Bonobo - Counterpart (Live on KEXP)
 - [https://www.youtube.com/watch?v=3qIxtrhRwVA](https://www.youtube.com/watch?v=3qIxtrhRwVA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-06 00:00:00+00:00

http://KEXP.ORG presents Bonobo performing “Counterpart” live in the KEXP studio. Recorded March 22, 2022.

Simon Green - Bass / Synthesizer
Nicole Miglis - Vocals (“From You” & “Surface”)
Jordan Rakei - Vocals (“Shadows”)
Jack Baker - Drums
Mike Lesirge - Horns / Keys
Johnny Tomlinson - Keys
Ewan Wallace - Guitar

Host: Cheryl Waters
Audio Engineers: Tommy Williams & Kevin Suggs
Audio Mixer: Tommy Williams
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Ettie Wahl
Editor: Jim Beckmann

https://bonobomusic.com
http://kexp.org

## Bonobo - From You (Live on KEXP)
 - [https://www.youtube.com/watch?v=MphCW13UYGM](https://www.youtube.com/watch?v=MphCW13UYGM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-06 00:00:00+00:00

http://KEXP.ORG presents Bonobo performing “From You” (feat. Nicole Miglis) live in the KEXP studio. Recorded March 22, 2022.

Simon Green - Bass / Synthesizer
Nicole Miglis - Vocals
Jack Baker - Drums
Mike Lesirge - Horns / Keys
Johnny Tomlinson - Keys
Ewan Wallace - Guitar

Host: Cheryl Waters
Audio Engineers: Tommy Williams & Kevin Suggs
Audio Mixer: Tommy Williams
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Ettie Wahl
Editor: Jim Beckmann

https://bonobomusic.com
http://kexp.org

## Bonobo - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=dRrlo5Retng](https://www.youtube.com/watch?v=dRrlo5Retng)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-06 00:00:00+00:00

http://KEXP.ORG presents Bonobo performing live in the KEXP studio. Recorded March 22, 2022.

Songs:
Counterpart
Shadows
From You
Surface

Simon Green - Bass / Synthesizer
Nicole Miglis - Vocals (“From You” & “Surface”)
Jordan Rakei - Vocals (“Shadows”)
Jack Baker - Drums
Mike Lesirge - Horns / Keys
Johnny Tomlinson - Keys
Ewan Wallace - Guitar

Host: Cheryl Waters
Audio Engineers: Tommy Williams & Kevin Suggs
Audio Mixer: Tommy Williams
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Ettie Wahl
Editor: Jim Beckmann

https://bonobomusic.com
http://kexp.org

## Bonobo - Shadows (Live on KEXP)
 - [https://www.youtube.com/watch?v=qPn1FBvQh-k](https://www.youtube.com/watch?v=qPn1FBvQh-k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-06 00:00:00+00:00

http://KEXP.ORG presents Bonobo performing “Shadows” (feat. Jordan Rakei) live in the KEXP studio. Recorded March 22, 2022.

Simon Green - Bass / Synthesizer
Jordan Rakei - Vocals
Jack Baker - Drums
Mike Lesirge - Horns / Keys
Johnny Tomlinson - Keys
Ewan Wallace - Guitar

Host: Cheryl Waters
Audio Engineers: Tommy Williams & Kevin Suggs
Audio Mixer: Tommy Williams
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Ettie Wahl
Editor: Jim Beckmann

https://bonobomusic.com
http://kexp.org

## Bonobo - Surface (Live on KEXP)
 - [https://www.youtube.com/watch?v=-9-mHESbjqY](https://www.youtube.com/watch?v=-9-mHESbjqY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-06 00:00:00+00:00

http://KEXP.ORG presents Bonobo performing “Surface” (feat. Nicole Miglis) live in the KEXP studio. Recorded March 22, 2022.

Simon Green - Bass / Synthesizer
Nicole Miglis - Vocals
Jack Baker - Drums
Mike Lesirge - Horns / Keys
Johnny Tomlinson - Keys
Ewan Wallace - Guitar

Host: Cheryl Waters
Audio Engineers: Tommy Williams & Kevin Suggs
Audio Mixer: Tommy Williams
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Ettie Wahl
Editor: Jim Beckmann

https://bonobomusic.com
http://kexp.org


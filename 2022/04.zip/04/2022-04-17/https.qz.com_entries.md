## Quartz is taking down the paywall on QZ.com — Quartz
 - [https://qz.com/2154695/quartz-is-taking-down-the-paywall-on-qz-com/](https://qz.com/2154695/quartz-is-taking-down-the-paywall-on-qz-com/)
 - RSS feed: https://qz.com
 - date published: 2022-04-17 17:18:17.699849+00:00

We are excited to announce that we have lifted the paywall on QZ.com, and are making the vast majority of our journalism free for everyone to read.


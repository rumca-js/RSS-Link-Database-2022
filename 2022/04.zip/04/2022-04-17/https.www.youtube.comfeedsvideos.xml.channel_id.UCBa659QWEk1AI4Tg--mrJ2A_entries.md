# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## The bridge that must legally wobble
 - [https://www.youtube.com/watch?v=swLyst02ZK4](https://www.youtube.com/watch?v=swLyst02ZK4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2022-04-18 00:00:00+00:00

"Daly's Bridge", in Cork, Ireland, is better known as the Shakey Bridge. Because it shakes. But what happens when a bridge like that has to be repaired and refurbished? • Thanks to Cllr McCarthy: his site is http://corkheritage.ie/ !

Edited by Dave Stevenson http://davestevenson.co.uk

A thorough study of how the Bridge shakes: http://publish.ucc.ie/boolean/pdf/2015/00/32-ODonnell-2015-00-en.pdf [PDF]

I did try (a lot!) to get an interview with someone from RPS Group, who were in charge of the refurbishment, but I just wasn't able to make contact. However, I'm indebted to Michael Minehane, principal engineer, whose talk to Engineers Ireland gives a lot of in-depth information about the bridge was refurbished! You can watch it here, along with Cllr McCarthy's history of the bridge: https://www.youtube.com/watch?v=j52poh2ZfSA

Thanks to Youssuf Radwan for the suggestion!

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo


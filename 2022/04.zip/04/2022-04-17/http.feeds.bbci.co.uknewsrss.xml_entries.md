# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Ukraine war: Germany's conundrum over its ties with Russia
 - [https://www.bbc.co.uk/news/world-europe-61118706?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61118706?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 23:30:49+00:00

Berlin now has some hard decisions to make following years of dialogue and co-operation with Moscow.

## 'I felt more joy than I thought possible'
 - [https://www.bbc.co.uk/news/science-environment-61106081?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-61106081?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 23:29:48+00:00

How it feels to treat your depression with a hallucinogenic drug.

## Captagon: Jordan's undeclared war against Syria drug traffickers
 - [https://www.bbc.co.uk/news/world-middle-east-61040359?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-61040359?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 23:29:32+00:00

Soldiers have a shoot-to-kill policy to stop millions of Captagon pills being smuggled from Syria.

## Nigeria's Spider-Man fighting for a cleaner society
 - [https://www.bbc.co.uk/news/world-africa-61111613?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-61111613?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 23:14:50+00:00

Jonathan Olakunle is fighting for a cleaner society in Osogbo, Nigeria.

## 'I am only the UK's sixth black female QC'
 - [https://www.bbc.co.uk/news/uk-england-london-61101239?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-61101239?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 23:02:10+00:00

Nneka Akudolu was told she had little chance of becoming a barrister, now she's a Queen's Counsel.

## Why I didn't use my real name at work
 - [https://www.bbc.co.uk/news/business-61106074?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61106074?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 23:01:14+00:00

Should you change your name to fit in at work? We look at why some people have anglicised their names.

## Match of the Day 2 analysis: How Bruno Guimaraes won the game for Newcastle
 - [https://www.bbc.co.uk/sport/av/football/61136987?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/61136987?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 23:00:11+00:00

Match of the Day 2 pundits Stephen Warnock and Leon Osman praise Newcastle's matchwinner Bruno Guimaraes after their 2-1 win over Leicester.

## Sri Lanka healthcare on verge of collapse in economic crisis
 - [https://www.bbc.co.uk/news/world-asia-61111405?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-61111405?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 22:58:37+00:00

Doctors warn of catastrophe in Sri Lanka where medical supplies are running out in the financial crisis.

## World Snooker Championship 2022: Ronnie O'Sullivan beats David Gilbert
 - [https://www.bbc.co.uk/sport/snooker/61134890?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/snooker/61134890?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 22:38:40+00:00

World number one Ronnie O'Sullivan showcases his mettle by coming from behind to beat David Gilbert 10-5 at the World Championship in Sheffield.

## How well have Scotland and the UK coped with Covid?
 - [https://www.bbc.co.uk/news/uk-scotland-61105949?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-61105949?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 22:32:29+00:00

As Scotland takes off the face masks, James Cook asks how the country has done tackling Covid.

## Garth Crooks' Team of the Week: Mane, Ronaldo, Werner, Mount
 - [https://www.bbc.co.uk/sport/football/61135951?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/61135951?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 21:44:06+00:00

Who could threaten their club's goalscoring record? Which veteran should retire at the top this summer? Find out in Garth Crooks' latest Team of the Week.

## Ukraine round-up: Ukraine defies Mariupol deadline as Kharkiv shelled
 - [https://www.bbc.co.uk/news/world-europe-61135894?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61135894?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 20:15:28+00:00

Mariupol defenders ignore Russian calls to surrender, as Kharkiv and other cities face more shelling.

## Older residents of the east reluctant to hit the road
 - [https://www.bbc.co.uk/news/world-europe-61135091?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61135091?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 17:29:53+00:00

While young Ukrainians have moved to safety, many older residents say they have no choice but to stay.

## In pictures: Mountain bikers descend snowy peak
 - [https://www.bbc.co.uk/news/uk-scotland-highlands-islands-61134704?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-highlands-islands-61134704?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 12:38:50+00:00

About 300 daring riders made an Easter weekend descent of Aanoch Mor in the Highlands.

## Royal children join parents at Easter service
 - [https://www.bbc.co.uk/news/uk-61134007?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61134007?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 12:12:25+00:00

The Duke and Duchess of Cambridge brought their older children to St George's Chapel in Windsor.

## Next and finance firms buy JoJo Maman Bebe
 - [https://www.bbc.co.uk/news/business-61133553?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61133553?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 12:06:24+00:00

There will be no immediate job losses at the baby goods retailer, although its founder will step down.

## Rwanda plan not certain to deter migrants, says official
 - [https://www.bbc.co.uk/news/uk-politics-61133983?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-61133983?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 12:02:10+00:00

A top official said the policy would only be value for money if it stopped illegal entry to the UK.

## Extinction Rebellion: Seventy arrested at climate change protests
 - [https://www.bbc.co.uk/news/uk-england-london-61133235?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-61133235?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 11:44:31+00:00

Activists staged a spate of protests including scaling London's Marble Arch and an oil tanker.

## No 10 parties: PM's lockdown fine constitutional crisis, says historian
 - [https://www.bbc.co.uk/news/uk-politics-61134002?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-61134002?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 10:49:54+00:00

A leading expert says Boris Johnson "broke the law", "misled Parliament" and "shredded the ministerial code".

## Coventry fire: Two children among seven rescued from blaze
 - [https://www.bbc.co.uk/news/uk-england-coventry-warwickshire-61133586?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-coventry-warwickshire-61133586?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 10:27:03+00:00

Five adults and two children are rescued from the "severe" blaze in a 15th-floor flat.

## North Korea tests new weapon 'to improve tactical nukes'
 - [https://www.bbc.co.uk/news/world-asia-61133225?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-61133225?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 10:04:41+00:00

Kim Jong-un clapped as he watched the launch - a new indication of his intention to resume nuclear tests.

## Ukraine war: Trucks stuck at Poland-Belarus border as EU sanctions deadline passes
 - [https://www.bbc.co.uk/news/world-europe-61133439?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61133439?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 09:44:39+00:00

An 80km queue formed on the Polish border ahead of a deadline for Russian trucks to leave the EU.

## Easter: Snowdonia mountain path covered in human faeces - guide
 - [https://www.bbc.co.uk/news/uk-wales-61128854?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-61128854?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 09:17:54+00:00

Snowdon guide Gemma Davies says she even caught a man defecating on the mountain's railway line.

## Boris Johnson and Prince Charles remember war in Ukraine in Easter messages
 - [https://www.bbc.co.uk/news/uk-61129126?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61129126?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 09:10:51+00:00

Addressing Ukrainians in their language, Boris Johnson urged them to "be strong".

## I decided not to let cancer stop me dating
 - [https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-61011787?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-61011787?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 08:10:37+00:00

Katherine Crowson was 29 when she was diagnosed, and wanted to know when she would get her life back.

## Hull maritime pictures have decades of grime removed
 - [https://www.bbc.co.uk/news/uk-england-humber-61081173?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-humber-61081173?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 06:35:56+00:00

The paintings will go back to the Maritime Museum in Hull after its refurbishment.

## Ukraine: Online posts 'transform' war crimes documentation
 - [https://www.bbc.co.uk/news/uk-wales-61011855?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-61011855?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 06:18:49+00:00

Open-source evidence is increasingly used by the UN and war crimes investigators, says law professor.

## Penguin power and the 'dream job' in Antarctica
 - [https://www.bbc.co.uk/news/uk-northern-ireland-60996875?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-60996875?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 05:48:18+00:00

Kit Adams, from Newcastle, reflects on his time at the Penguin Post Office in the wilderness of Antarctica.

## Newspaper headlines: 'Ungodly' Rwanda plan and drug scandal claims
 - [https://www.bbc.co.uk/news/blogs-the-papers-61130828?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-61130828?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-17 04:39:38+00:00

The papers cover Justin Welby's criticism of refugee plans and fears over pills that harmed babies.


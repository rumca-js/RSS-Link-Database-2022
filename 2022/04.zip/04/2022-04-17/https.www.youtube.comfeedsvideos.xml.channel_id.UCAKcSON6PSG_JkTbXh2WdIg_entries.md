# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## COVID-19 is still threatening live music (Full LineCheck episode)
 - [https://www.youtube.com/watch?v=8f5BUmyoMNU](https://www.youtube.com/watch?v=8f5BUmyoMNU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-04-17 00:00:00+00:00

Live music is back, but despite vaccines and high hopes, COVID-19 is still infecting people and wreaking havoc on tour schedules and bottom lines. First Avenue General Manager Nate Kranz, Chair of Minnesota Independent Venue Alliance Shayna Milstein, and Gully Boys members Natalie Klemond and Mariah Mercedes tell Diane how they're navigating pandemic year three.

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCur...

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Dave Pirner clowns around with Jim McGuinn
 - [https://www.youtube.com/watch?v=5s-sB-Bi2sg](https://www.youtube.com/watch?v=5s-sB-Bi2sg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-04-17 00:00:00+00:00

On a visit to The Current, Soul Asylum's Dave Pirner gets a little silly in the music library while talking about Teenage Kicks with Jim McGuinn.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#davepirner #soulasylum

## Nat Harvie - No Ash (Live for LineCheck with The Current)
 - [https://www.youtube.com/watch?v=eGGsUDOoVos](https://www.youtube.com/watch?v=eGGsUDOoVos)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-04-17 00:00:00+00:00

Nat Harvie performs "No Ash" from their 2022 album 'Married in Song' for The Current's LineCheck, a series of conversations with the Minnesota music community. Find the full archive of LineCheck episodes here: https://www.youtube.com/playlist?list=PLYClJc3TpV5Lgb2cnQjjHfCfuzm9puhr7

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Nat Harvie - Waiting Song (Live for LineCheck with The Current)
 - [https://www.youtube.com/watch?v=DGANiUVCUvQ](https://www.youtube.com/watch?v=DGANiUVCUvQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-04-17 00:00:00+00:00

Nat Harvie performs "Waiting Song" from their 2022 album 'Married in Song' for The Current's LineCheck series. Find the full archive of LineCheck episodes here: https://www.youtube.com/playlist?list=PLYClJc3TpV5Lgb2cnQjjHfCfuzm9puhr7

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/


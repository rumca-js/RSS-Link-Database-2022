# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## 1 Księga Kronik || Rozdział 18
 - [https://www.youtube.com/watch?v=UbOLtjy_UdM](https://www.youtube.com/watch?v=UbOLtjy_UdM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-04-18 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#284] Nie karm trupa!
 - [https://www.youtube.com/watch?v=_d1ToQt5iTQ](https://www.youtube.com/watch?v=_d1ToQt5iTQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-04-18 00:00:00+00:00

@Langustanapalmie  #CNN #słowonaniedziele

Kazanko do okienka, czyli komentarz do niedzielnych czytań.

Poniedziałek, Oktawa Wielkanocna, Rok C, II
Poniedziałek w oktawie Wielkanocy

1. czytanie (Dz 2, 14. 22b-32)

W dniu Pięćdziesiątnicy stanął Piotr razem z Jedenastoma i przemówił donośnym głosem:
«Mężowie Judejczycy i wszyscy mieszkańcy Jeruzalem, przyjmijcie do wiadomości i posłuchajcie uważnie mych słów! Jezusa Nazarejczyka, Męża, którego posłannictwo Bóg potwierdził wam niezwykłymi czynami, cudami i znakami, jakich Bóg przez Niego dokonał wśród was, o czym sami wiecie, tego Męża, który z woli, postanowienia i przewidzenia Boga został wydany, przybiliście rękami bezbożnych do krzyża i zabiliście. Lecz Bóg wskrzesił Go, zerwawszy więzy śmierci, gdyż niemożliwe było, aby ona panowała nad Nim, bo Dawid mówi o Nim:
„Miałem Pana zawsze przed oczami, gdyż stoi po mojej prawicy, abym się nie zachwiał. Dlatego ucieszyło się moje serce i rozradował się mój język, także i moje ciało spoczywać będzie w nadziei, że nie zostawisz duszy mojej w Otchłani ani nie dasz Świętemu Twemu ulec rozkładowi. Dałeś mi poznać drogi życia i napełnisz mnie radością przed obliczem Twoim”.
Bracia, wolno powiedzieć do was otwarcie, że patriarcha Dawid umarł i został pochowany w grobie, który znajduje się u nas aż po dzień dzisiejszy. Więc jako prorok, który wiedział, że Bóg przysiągł mu uroczyście, iż jego Potomek zasiądzie na jego tronie, widział przyszłość i przepowiedział zmartwychwstanie Mesjasza, że ani nie pozostanie w Otchłani, ani ciało Jego nie ulegnie rozkładowi.
Tego właśnie Jezusa wskrzesił Bóg, a my wszyscy jesteśmy tego świadkami».

Ewangelia (Mt 28, 8-15)

Gdy anioł przemówił do niewiast, one pośpiesznie oddaliły się od grobu, z bojaźnią i wielką radością, i pobiegły oznajmić to Jego uczniom.
A oto Jezus stanął przed nimi, mówiąc: «Witajcie!» One podeszły do Niego, objęły Go za nogi i oddały Mu pokłon. A Jezus rzekł do nich: «Nie bójcie się! Idźcie i oznajmijcie moim braciom: niech udadzą się do Galilei, tam Mnie zobaczą».
Gdy one były w drodze, niektórzy ze straży przyszli do miasta i powiadomili arcykapłanów o wszystkim, co zaszło. Ci zebrali się ze starszymi, a po naradzie dali żołnierzom sporo pieniędzy i rzekli: «Rozpowiadajcie tak: Jego uczniowie przyszli w nocy i wykradli Go, gdy spaliśmy. A gdyby to doszło do uszu namiestnika, my z nim pomówimy i wybawimy was z kłopotu».
Ci więc wzięli pieniądze i uczynili, jak ich pouczono. I tak rozniosła się ta pogłoska między Żydami, i trwa aż do dnia dzisiejszego.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## 1 Księga Kronik || Rozdział 17
 - [https://www.youtube.com/watch?v=FLwIiqjdNFI](https://www.youtube.com/watch?v=FLwIiqjdNFI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-04-17 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.


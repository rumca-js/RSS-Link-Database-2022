# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## Console Wars - NINTENDO vs SEGA
 - [https://www.youtube.com/watch?v=tBdeKWl0E5g](https://www.youtube.com/watch?v=tBdeKWl0E5g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2022-04-17 00:00:00+00:00

Get your exclusive deal here! https://NordVPN.com/gitz - it's risk free with Nord's 30 day money-back guarantee!

Special thanks to our Patron Producers!

Albert Hutchins
Andrew Palmer
Adam Knopow

Created by ► 
Tom Hinchliffe & Don Greger

VO ► 
SNES, PS1 - Suzune Okabe https://twitter.com/ALExSTAR33
GENESIS, N64 - AJ Sparkx https://twitter.com/AJsparkx

Animatic  ►
BoyPorcelain

Animation ►
Holly Gee
CalebJordann
Arzonaut

3D ►
TatermanNG

Custom Sprites ►
Neweegee 

Backgrounds ►
Soured Apple https://www.twitter.com/SouredApple
Naav Draws https://www.instagram.com/naav_draws/
Adila Noor @taksesal
Chompolon @chompolino
 
Music ►
Zach Heyde https://youtube.com/playlist?list=PLXtP4ANq7nIUYo6VZEEHtd8H3HP_MthUC
Tom Ryan (intro theme)

Sound ► 
Justin Greger

Ad Compositing ► 
Oddest of the Odd

Translation Assistance ►
Mike Mararudo

Merch ►
https://crowdmade.com/flashgitz

Instagram ►
https://www.instagram.com/flashgitz/

Twitter ►
https://www.twitter.com/flashgitzanims
https://www.twitter.com/flashgitztom
https://www.twitter.com/flashgitzdon

Discord ►
https://discord.gg/nJCcJj6


# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Samochodem z Filipin do Polski? Q&A
 - [https://www.youtube.com/watch?v=gR_dh9t2EYY](https://www.youtube.com/watch?v=gR_dh9t2EYY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2022-04-17 08:05:28+00:00

Odpowiadam na pytania widzów. Lista pytań w przypiętym komentarzu

Wszystkie odcinki BezPlanu chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry)

BezPlanu Daily: https://www.youtube.com/channel/UCHXOfJP9fwMNXWGFKstju_w

Sklep: https://bezplanu.com
Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv
Wsparcie na Patronite: http://bit.ly/2KsFTZk

Czas akcji: kwiecień 2022r.


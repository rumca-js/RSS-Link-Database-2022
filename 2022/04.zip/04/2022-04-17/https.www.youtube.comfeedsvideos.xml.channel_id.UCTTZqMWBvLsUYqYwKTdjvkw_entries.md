# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## Jak sprzedaje się VPNy w Internecie?
 - [https://www.youtube.com/watch?v=Ijdkl9GVh3c](https://www.youtube.com/watch?v=Ijdkl9GVh3c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2022-04-17 00:00:00+00:00

To będzie odcinek trochę inny niż zwykle. Natknąłem się ostatnio na pracę naukową, gdzie postanowiono przyjrzeć się reklamom VPNów. Myślę, że to dobra okazja, aby opowiedzieć w jaki sposób sprzedaje się produkty poprzez reklamy. Jakiego języka się używa? Czy stwierdzenia, które tam się znajdują są zgodne z prawdą? A może dużo się obiecuje, a tak naprawdę niewiele za tym idzie?
Inspirowałem się formatem Czytamy naturę kanału @CopernicusCenter który bardzo lubię i serdecznie polecam.
Zapraszam!

Źródła:
📝 Praca badawcza o reklamowaniu VPNów przez influencerów na Youtube
https://bit.ly/3NXGT6P

▶️ Materiał o zdecentralizowanym VPNie Deeper dla @centrumtestow6722 
https://www.youtube.com/watch?v=8keaPBSlYhw

📺 Kanał @CopernicusCenter  którego seria Czytamy naturę Łukasza Lamży była dla mnie inspiracją przy tworzeniu tego odcinka
https://www.youtube.com/c/CopernicuscenterEduPl

▶️ Mój materiał o tym, jak wybrać VPNa
https://www.youtube.com/watch?v=87u0matbDPU

Jeżeli nie ufasz skracanym linkom (bardzo dobrze!) to dodaj na ich końcu plusik ‘+’.
W ten sposób podejrzysz na stronie bit.ly dokąd prowadzą.

Relevant xkcd: https://xkcd.com/341/

© Wszystkie znaki handlowe należą do ich prawowitych właścicieli.

Dziękuję za Waszą uwagę. ❤️

Znajdziecie mnie również na;
Instagramie @mateuszemsi https://www.instagram.com/mateuszemsi/
Twitterze @MateuszChrobok https://twitter.com/MateuszChrobok
LinkedInie @mateuszchrobok https://www.linkedin.com/in/mateuszchrobok/
Podcasty na Anchor https://anchor.fm/mateusz-chrobok
Podcasty na Spotify https://open.spotify.com/show/6y6oWs20HwRejktOWHTteR
Podcast na Apple Podcasts https://podcasts.apple.com/us/podcast/mateusz-chrobok-bezpiecze%C5%84stwo-startupy-i-sztuczna-inteligencja/id1617335932 
Patronite @MateuszChrobok https://patronite.pl/MateuszChrobok

#nordvpn #współpraca #surfshark #cyberbezpieczeństwo

Rozdziały:
00:00 Intro
00:47 Naśladownictwo
02:37 Metodologia
05:55 Wnioski
11:55 Problemy
15:03 Case Study
16:37 Podsumowanie
19:03 Co Robić i Jak Żyć?


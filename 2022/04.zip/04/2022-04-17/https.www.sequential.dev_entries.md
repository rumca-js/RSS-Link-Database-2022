## Be less technical
 - [https://www.sequential.dev/posts/be-less-technical/](https://www.sequential.dev/posts/be-less-technical/)
 - RSS feed: https://www.sequential.dev
 - date published: 2022-04-17 17:23:04.796246+00:00

Improving communication by being less technical whenever you can be


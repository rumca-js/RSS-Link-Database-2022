# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Why Genetic Engineering Can’t Do Everything (Yet)
 - [https://www.youtube.com/watch?v=CNnlXCVn2m0](https://www.youtube.com/watch?v=CNnlXCVn2m0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-04-18 00:00:00+00:00

Get 30% off your first purchase (plus free shipping) when you use my code SCISHOW30 at https://cometeer.com/scishow5

We've made some great strides in understanding the human genome, but before we can tackle genetic engineering, we have some "chicken and egg" problems to figure out.


Hosted by: Hank Green

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Mastanos​, ​Sam Lutfi​, ​Bryan Cloer​, ​Kevin Bealer​, ​Christoph Schwanke​, ​Tomás Lagos González​, ​Jason A Saslow​, ​Tom Mosner​, ​Jacob​, ​Ash​, ​Eric Jensen​, ​Jeffrey Mckishen​, ​Alex Hackman​, ​Matt Curls​, ​Christopher R Boucher​, ​Piya Shedden​, ​Jeremy Mysliwiec​, ​Chris Peters​, ​Dr. Melvin Sanicas​, ​charles george​, ​Adam Brainard​, ​Harrison Mills​, ​Silas Emrys​, ​Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow
----------
Sources:

Sources:
https://www.nature.com/articles/nature03154
https://bmcecolevol.biomedcentral.com/articles/10.1186/s12862-021-01905-7 
https://academic.oup.com/g3journal/article/7/1/109/6031559 
https://www.nature.com/articles/srep09143
https://genomebiology.biomedcentral.com/articles/10.1186/gb-2011-12-2-r18#Sec10
https://academic.oup.com/nar/article/40/10/e72/2411059

https://www.mpg.de/18386613/potato-genome 
https://www.nature.com/articles/s41588-022-01015-0
 https://www.nature.com/articles/s41438-019-0181-z
https://www.britannica.com/science/polyploidy 
https://www.nature.com/articles/nature10158 
https://www.nature.com/articles/s41588-020-0699-x

https://www.eurekalert.org/news-releases/943064 
https://www.sciencedirect.com/science/article/pii/S2589004222000517 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6707551/
https://www.cdc.gov/lyme/index.html
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3826218/

IMAGES

https://commons.wikimedia.org/wiki/File:Adult_deer_tick.jpg#/media/File:Adult_deer_tick.jpg
https://commons.wikimedia.org/wiki/File:Borrelia_burgdorferi-cropped.jpg
https://www.gettyimages.com/detail/photo/super-macro-close-up-of-female-tick-carrying-royalty-free-image/1222973019?adppopup=true
https://commons.wikimedia.org/wiki/File:Ixodes_scapularis.png#/media/File:Ixodes_scapularis.png



https://www.gettyimages.com/detail/photo/potato-on-field-royalty-free-image/936859246?adppopup=true
https://en.wikipedia.org/wiki/File:Misc_pollen_colorized.jpg
https://www.gettyimages.com/detail/photo/potatoes-royalty-free-image/471199439?adppopup=true
https://www.gettyimages.com/detail/photo/organic-potatoes-or-spud-harvest-in-farmer-hands-in-royalty-free-image/546463986?adppopup=true
https://www.storyblocks.com/video/stock/wheat-at-sunset-cornfileld-in-the-beautiful-late-evening-sunshine-crop-of-cereals-wheat-harvest-ears-of-wheat-sp71krbrhjzsygm9l
https://www.gettyimages.com/detail/photo/chromosome-dna-royalty-free-image/165816264?adppopup=true
https://www.gettyimages.com/detail/photo/free-range-chicken-close-up-royalty-free-image/157562881
https://www.gettyimages.com/detail/photo/hummingbird-in-golden-gate-park-san-francisco-royalty-free-image/521608256?adppopup=true
https://bmcecolevol.biomedcentral.com/articles/10.1186/s12862-021-01905-7/figures/3
https://www.gettyimages.com/detail/photo/them-stare-royalty-free-image/1293605723?adppopup=true
https://www.gettyimages.com/detail/photo/funny-burrowing-owl-athene-cunicularia-royalty-free-image/964611070?adppopup=true
https://www.storyblocks.com/video/stock/spiral-strands-of-dna-on-the-dark-background-ru-9ipg2sk34suh45
https://www.storyblocks.com/video/stock/dna-sequencing-the-bases-of-a-fragment-of-dna-abstract-background-skx-uxydpkgvmnshp
https://www.gettyimages.com/detail/photo/ostrich-with-mouth-wide-open-royalty-free-image/1323901769?adppopup=true

## Unexpected Dangers of Sports
 - [https://www.youtube.com/watch?v=DnFnIExNWb8](https://www.youtube.com/watch?v=DnFnIExNWb8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-04-17 00:00:00+00:00

From turf toe to toxic Zamboni's, sports injuries aren't just for pro athletes.

Hosted by: Stefan Chin

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Mastanos​, ​Sam Lutfi​, ​Bryan Cloer​, ​Kevin Bealer​, ​Christoph Schwanke​, ​Tomás Lagos González​, ​Jason A Saslow​, ​Tom Mosner​, ​Jacob​, ​Ash​, ​Eric Jensen​, ​Jeffrey Mckishen​, ​Alex Hackman​, ​Matt Curls​, ​Christopher R Boucher​, ​Piya Shedden​, ​Jeremy Mysliwiec​, ​Chris Peters​, ​Dr. Melvin Sanicas​, ​charles george​, ​Adam Brainard​, ​Harrison Mills​, ​Silas Emrys​, ​Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow #sports #science
----------
Sources:
https://my.clevelandclinic.org/health/diseases/17590-turf-toe 
https://www.frontiersin.org/articles/10.3389/fneur.2018.00772/full 
https://www.epa.gov/indoor-air-quality-iaq/indoor-air-quality-and-ice-arenas 
https://oem.bmj.com/content/59/4/224 
https://www.cdc.gov/mmwr/preview/mmwrhtml/mm6445a3.htm 
https://journals.sagepub.com/doi/full/10.1177/2325967121999646 
https://pubmed.ncbi.nlm.nih.gov/34886503/ 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7233258/
https://www.mayoclinic.org/diseases-conditions/achilles-tendon-rupture/symptoms-causes/syc-20353234
https://www.mayoclinic.org/diseases-conditions/concussion/symptoms-causes/syc-20355594 
https://www.mayoclinic.org/diseases-conditions/acl-injury/symptoms-causes/syc-20350738 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3782736/ 
https://eor.bioscientifica.com/view/journals/eor/3/9/2058-5241.3.180012.xml 
https://scholar.google.com/scholar_lookup?title=Turf-toe%3A+a+shoe-surface+related+football+injury&author=KD+RB+Bowers+Martin&publication_year=1976&journal=Med+Sci+Sports&volume=8&pages=81-83 
And now for celebratory injuries:
https://www.espn.com/nfl/story/_/id/12016745/detroit-lions-linebacker-stephen-tulloch-discusses-bizarre-celebration-injury
https://profootballtalk.nbcsports.com/2010/03/25/bill-gramatica-still-laughs-at-his-own-torn-acl/ 
https://bleacherreport.com/articles/1700649-soccer-player-injures-himself-celebrating-scoring-first-pro-goal
https://www.cbssports.com/mlb/news/aubrey-huff-hits-dl-with-celebration-knee-injury/
https://www.espn.com/blog/chicago/cubs/post/_/id/170/chicago-cubs-pitcher-ryan-dempster-out-with-broken-toe 
https://bleacherreport.com/articles/2207976-sandro-and-the-most-embarrassing-footballer-injuries 
https://www.espn.com/blog/sportscenter/post/_/id/69508/chris-coghlan-pies-himself-into-the-celebration-hall-of-shame 
https://www.nfl.com/news/bears-lamarr-houston-tears-acl-while-celebrating-0ap3000000418019 
https://www.foxsports.com/mlb/gallery/kendry-morales-injury-gallery-052910 
https://www.espn.in/mlb/news/story?id=4490022 
https://www.espn.com/olympics/skiing/news/story?id=3898788 
https://www.pga.com/archive/news/european-tour/thomas-levet-recovering-freak-injury-promises-never-jump-in-lake-again 

IMAGES


https://en.wikipedia.org/wiki/File:Gray444.png
https://www.storyblocks.com/video/stock/two-men-without-t-shirts-in-the-ring-hold-a-duel-dynamic-camera-movement-r3cvwmfmmjbq7ofuo
https://www.istockphoto.com/photo/young-woman-runner-warm-up-outdoor-gm477628210-66816939
https://commons.wikimedia.org/wiki/File:ACL_Tear.png
https://commons.wikimedia.org/wiki/File:Achilles_Tendon_Tear.png
https://commons.wikimedia.org/wiki/File:1123_Muscles_of_the_Leg_that_Move_the_Foot_and_Toes_b.png
https://www.storyblocks.com/video/stock/footage-of-an-ice-resurfacing-machine-polishing-the-rink-rjhlzkzuejtj587t9
https://www.storyblocks.com/video/stock/footage-of-an-ice-resurfacing-machine-polishing-the-rink-skygsfbonjtj6r065
https://www.istockphoto.com/photo/seamless-repetitive-lungs-pattern-on-blue-background-gm1266416810-371240952
https://www.storyblocks.com/video/stock/big-crowd-of-young-people-skating-on-the-indoor-ice-rink-with-manufactured-ice-on-it-and-colored-light-bolfn2viqwj7nzfief
https://commons.wikimedia.org/wiki/File:USA_I_in_heat_1_of_2_man_bobsleigh_at_2010_Winter_Olympics_2010-02-20.jpg
https://commons.wikimedia.org/wiki/File:USA-1_in_heat_3_of_4_man_bobsleigh_at_2010_Winter_Olympics_2010-02-27.jpg
https://commons.wikimedia.org/wiki/File:BobsldRun.jpg
https://www.storyblocks.com/video/stock/young-ballerina-dancing-beautifully-bjfufyqainjsy6jqug
https://www.storyblocks.com/video/stock/players-of-american-football-team-moscow-bruins-try-scores-touchdown-during-training-hii70rd7eiwgv8e4u


https://www.gettimages.com
www.storyblocks.com


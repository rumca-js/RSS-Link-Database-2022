# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Wymyśliła sobie orgazm i ma na to badania.
 - [https://www.youtube.com/watch?v=2q4NecBaQX4](https://www.youtube.com/watch?v=2q4NecBaQX4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-04-18 00:00:00+00:00

Moje sociale:
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter
Dziś w odcinku:
00:00 Wstęp
00:10 Dobry Wieczór
00:18 Elon Musk chce jednak kupić Twittera w całości
01:04 Czas na konsumpcję marihuanen
01:36 Musk jest w stanie zapłacić za Twittera więcej niż TT jest wart obecnie
03:36 Kanye West na prezydenta
04:11 Drukarka 3D od Ankera
04:42 Można doprowadzić się do orgazmu myślami
06:03 Policja zatrzymuje samochód autonomiczny
08:35 Naukowcowm udało się cofnąć wiek ludzkiej skóry o 30 lat
09:25 GoPro Hero 10 Black Bones
09:52 DJI Mini 3 Pro
10:00 Zapowiedź filmu o OnePlus 10 Pro
11:02 USC typu C w iPhone 14
11:37 Znośnego tygodnia!

Źródła:
Elon chce kupić Twittera w całości: https://bit.ly/3M98a4A
Kobieta, która doprowadza się do orgazmu myślami: https://bit.ly/3Mahcyj
Policja zatrzymuje samochód autonomiczny: https://bit.ly/3M9Wsqv
Cofnęli wiek komórek ludzkiej skóry o 30 lat: https://bit.ly/3xB1WGw
GoPro Hero 10 Black Bones: https://bit.ly/38SneVT
Przecieki DJI Mini 3 Pro: https://bit.ly/3Og8RuO
Porównanie foto video w OnePlus 10 Pro na kanale Centrum Testów: https://youtu.be/6_wCAhh59a8
Instagram Centrum Testów - https://www.instagram.com/centrumtestow/


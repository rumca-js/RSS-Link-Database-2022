# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## I UNCOVERED A BILLION DOLLAR FRAUD
 - [https://www.youtube.com/watch?v=CzbBi0agLNg](https://www.youtube.com/watch?v=CzbBi0agLNg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2022-04-18 00:00:00+00:00

I've been investigating Safemoon for almost a year now, and finally we're ready to reveal our findings. 
Safemoon is, in my belief, a massive fraud created by promises of a "locked LP", and the idea of going "safely to the moon." In actuality this was all a lie. 

Billion dollar market cap, FBI Investigations, Gambian Windfarms, this story truly has it all. 

Big thanks to BOOTSY (Twitter:@BlameBootsy) and STRIDER (Twitter:@StriderCynic) for helping make this video possible
Also thanks to 𝒇𝒐𝒏𝒛𝒊𝒆 (@realFUD), Mutahar (SomeOrdinaryGamers) and Barely Sociable as well for their assistance. 

Follow Coffeezilla: 
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
Credits: 
3D Artist: Ed Leszczynski https://www.instagram.com/ed_leszczynski/
Video Editor: Harry Bagg  https://twitter.com/HarryRBagg
MAXWELL THE ROBOT: Technicals on YouTube
Virtual Production Software: Aximmetry https://aximmetry.com/


This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.E


# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Ford's Coolest Electric Truck is from 1978!
 - [https://www.youtube.com/watch?v=q72dA533sCg](https://www.youtube.com/watch?v=q72dA533sCg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-04-18 00:00:00+00:00

Here's a concept: Old classic truck... Electrified!

MKBHD Merch: http://shop.MKBHD.com

Ford's official page: https://media.ford.com/content/fordmedia/fna/us/en/news/2021/11/02/all-electric-f-100-eluminator-concept.html

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


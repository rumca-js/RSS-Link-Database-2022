# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Easy on Me | @adele | funk cover ft. @MarioJoseMusic
 - [https://www.youtube.com/watch?v=jJinC2JNNe8](https://www.youtube.com/watch?v=jJinC2JNNe8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2022-04-18 00:00:00+00:00

Store: https://www.scarypocketsfunk.com
Patreon: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Adele's "Easy on Me" by Scary Pockets & Mario Jose.

MUSICIAN CREDITS
Lead vocal/Trombone: Mario Jose
Drums: Kyle Crane
Bass: Nick Campbell
Keys: Swatkins
Organ: Jason Goldstein
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Chris Sorem
Mixing/Mastering: Craig Polasko
Brian Green: Percussion, guitar, keyboards, & additional production

VIDEO CREDITS
DP: Nate Cuboi
Lighting: Michael Thomas
Editor: Adam Kritzberg

Recorded Live at The Nest Recorders in Los Angeles, CA.

#ScaryPockets #Funk #Adele #EasyOnMe #MarioJose


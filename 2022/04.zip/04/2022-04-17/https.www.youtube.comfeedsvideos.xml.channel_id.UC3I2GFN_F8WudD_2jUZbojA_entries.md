# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## alt-J - Chicago (Live on KEXP)
 - [https://www.youtube.com/watch?v=GdPWe-40OXU](https://www.youtube.com/watch?v=GdPWe-40OXU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-18 00:00:00+00:00

http://KEXP.ORG presents alt-J performing “Chicago” live in the KEXP studio. Recorded March 29, 2022.

Joe Newman - Guitar / Vocals
Gus Unger-Hamilton - Keyboard / Glockenspiel / Bass Guitar / Vocals

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Jim Beckmann

https://www.altjband.com/
http://kexp.org

## alt-J - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=XANPObswCsE](https://www.youtube.com/watch?v=XANPObswCsE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-18 00:00:00+00:00

http://KEXP.ORG presents alt-J performing live in the KEXP studio. Recorded March 29, 2022.

Songs:
U&Me
Hard Drive Gold
Chicago
Tessellate

Joe Newman - Guitar / Vocals
Gus Unger-Hamilton - Keyboard / Glockenspiel / Bass Guitar / Vocals

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Jim Beckmann

https://www.altjband.com/
http://kexp.org

## alt-J - Hard Drive Gold (Live on KEXP)
 - [https://www.youtube.com/watch?v=2iXWqXcO8aM](https://www.youtube.com/watch?v=2iXWqXcO8aM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-18 00:00:00+00:00

http://KEXP.ORG presents alt-J performing “Hard Drive Gold” live in the KEXP studio. Recorded March 29, 2022.

Joe Newman - Guitar / Vocals
Gus Unger-Hamilton - Keyboard / Glockenspiel / Bass Guitar / Vocals

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Jim Beckmann

https://www.altjband.com/
http://kexp.org

## alt-J - Tessellate (Live on KEXP)
 - [https://www.youtube.com/watch?v=6bJNZNj7nJs](https://www.youtube.com/watch?v=6bJNZNj7nJs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-18 00:00:00+00:00

http://KEXP.ORG presents alt-J performing “Tessellate” live in the KEXP studio. Recorded March 29, 2022.

Joe Newman - Guitar / Vocals
Gus Unger-Hamilton - Keyboard / Glockenspiel / Bass Guitar / Vocals

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Jim Beckmann

https://www.altjband.com/
http://kexp.org

## alt-J - U&Me (Live on KEXP)
 - [https://www.youtube.com/watch?v=axEXkqcxX3s](https://www.youtube.com/watch?v=axEXkqcxX3s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-04-18 00:00:00+00:00

http://KEXP.ORG presents alt-J performing “U&Me” live in the KEXP studio. Recorded March 29, 2022.

Joe Newman - Guitar / Vocals
Gus Unger-Hamilton - Keyboard / Glockenspiel / Bass Guitar / Vocals

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Jim Beckmann

https://www.altjband.com/
http://kexp.org


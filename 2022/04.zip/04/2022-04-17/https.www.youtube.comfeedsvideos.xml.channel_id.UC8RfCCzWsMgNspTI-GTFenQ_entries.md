# Source:Luetin09, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ, language:en-US

## 40K - THE SQUATS RETURN? THEY NEVER WENT AWAY - Warhammer 40,000 Lore/History
 - [https://www.youtube.com/watch?v=BsWr37Wt2F8](https://www.youtube.com/watch?v=BsWr37Wt2F8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ
 - date published: 2022-04-18 00:00:00+00:00

Go to http://www.audible.com/luetin or text luetin to 500 500 to get your free trial. 
► Subscribe: http://goo.gl/oeZMBS 
► Siege Studios: https://siegestudios.co.uk/
► Crystal Fortress Premium Storage: http://bit.ly/3oFuDf7
► Goblin Gaming: (Get - 20% off 40K Products) https://tinyurl.com/6vwcayvj
► Patreon: https://www.patreon.com/Luetin 
► Twitch: http://www.twitch.tv/Luetin
► Twitter: http://twitter.com/luetin09

Timestamps:
0:00 Intro
1:31 Squats & The Truth
11:44 Squat History
19:41 Squat Ages
27:15 Trade & Imperium
32:39 Technology
36:55 Lost Fragments
46:52 Indomitus Era
54:07 Outro

► BGM Credits:
► Kevin MacLeod (Royalty Free Music): http://incompetech.com/music/
► https://epidemicsound.com

This video is an opinion editorial commentary.
Copyright Disclaimer Under Section 107 of the Copyright Act 1976, allowance is made for fair use purposes such as criticism, commentary, parody, news reporting, teaching, scholarship, and research.

All works used in this video (Images, audio etc) belong to their respective authors
(This does not include the audio commentary or licensed BGM).

This is an entirely Unofficial discussion/production.
Games workshop, Warhammer 40,000, Warhammer, 40k, Space Marine etc are all Trademarks of Games Workshop Ltd. Games Workshop does not endorse or support the 'Lore' videos. All views and opinions expressed in this video belong to Luetin09 and in absolutely no way reflect the views or opinions of Games Workshop Ltd.


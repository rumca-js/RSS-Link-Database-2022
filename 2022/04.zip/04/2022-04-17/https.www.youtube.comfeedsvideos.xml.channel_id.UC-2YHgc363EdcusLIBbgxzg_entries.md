# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## What Was The Worst Year In Human History? | Answers With Joe
 - [https://www.youtube.com/watch?v=ynTUjFCfGVA](https://www.youtube.com/watch?v=ynTUjFCfGVA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2022-04-18 00:00:00+00:00

Go to https://hensonshaving.com and enter "JOESCOTT" at checkout to get 100 free blades with your purchase. (Note: you must add both the 100 blade pack and the razor for the discount to apply.)
We're living in trying times, maybe you heard that somewhere? But there have definitely been worse times to be alive. In today's video, we look back at some of the worst years in human history, including one year that historians seem to agree was the worst of them all.

Watch this video ad-free on Nebula: https://nebula.tv/videos/joescott-what-was-the-worst-year-in-human-history


Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

You can listen to my podcast, Conversations With Joe on Spotify, Apple Podcasts, Google Podcasts, or wherever you get your podcasts.
Spotify 👉 https://spoti.fi/37iPGzF
Apple Podcasts 👉 https://apple.co/3j94kfq
Google Podcasts 👉 https://bit.ly/3qZCo1V

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe


LINKS LINKS LINKS:

https://www.history.com/topics/middle-ages/black-death

https://historydaily.org/death-ships-everything-about-ships-that-brought-plague-europe

https://www.haaretz.com/archaeology/.premium-1177-bce-the-year-civilization-was-destroyed-1.5350507

https://www.almanac.com/year-without-summer-mount-tambora-volcanic-eruption

https://dustyoldthing.com/1816-year-without-summer/

https://www.facinghistory.org/weimar-republic-fragility-democracy/politics/casualties-world-war-i-country-politics-world-war-i

https://www.theatlantic.com/ideas/archive/2020/04/disease-has-never-been-just-disease-native-americans/610852/

https://www.worldhistory.org/Moche_Civilization/

https://theconversation.com/volcanoes-plague-famine-and-endless-winter-welcome-to-536-what-historians-and-scientists-believe-was-the-worst-year-to-be-alive-175654

https://www.science.org/content/article/why-536-was-worst-year-be-alive



Timestamps:
0:00 - Intro
1:38 - We didn't start the fire
2:33 - 1347
4:35 - 1177 BC
6:09 - 1816
7:34 - 1914
9:25 - 1492
11:20 - 536, The Worst Year Ever
13:31 - Conclusion


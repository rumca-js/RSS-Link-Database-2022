# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Morbius - Yup, It's Terrible
 - [https://www.youtube.com/watch?v=j4ru5MD2ViI](https://www.youtube.com/watch?v=j4ru5MD2ViI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-04-18 00:00:00+00:00

So... Morbius was awful. But hey, at least you get to watch me tear it a new one. 

Want to help support this channel? 
Check out my books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8/ref=dp_byline_cont_pop_ebooks_1
Subscribe on Patreon: https://www.patreon.com/TheCriticalDrinker
Subscribe on Subscribestar: https://www.subscribestar.com/the-critical-drinker


# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Why women vote for India PM Narendra Modi's BJP
 - [https://www.bbc.co.uk/news/world-asia-india-61077736?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-61077736?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 23:23:33+00:00

India's PM is an alpha male who leads a patriarchal party - so what's the appeal?

## Are there affordable ways to cut your heating bill?
 - [https://www.bbc.co.uk/news/business-61068688?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61068688?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 23:17:43+00:00

Alternatives to gas and oil heating are becoming more popular but are still expensive.

## The 24-year-old helping people talk about their mental health
 - [https://www.bbc.co.uk/news/uk-england-york-north-yorkshire-61108854?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-york-north-yorkshire-61108854?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 23:14:14+00:00

Ben Ogden has spent months standing with a sign telling people it's ok to talk.

## Forced adoptions: Nurse speak out over pressure on unmarried mothers
 - [https://www.bbc.co.uk/news/uk-61121738?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61121738?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 23:01:19+00:00

A former nurse says she witnessed "callous behaviour" towards unmarried mothers forced to give up their babies.

## No 10 network targeted with spyware, says group
 - [https://www.bbc.co.uk/news/uk-61142687?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61142687?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 21:59:14+00:00

Researchers say they warned UK officials about being targeted, but the software's makers deny the claims.

## Falklands War: Injured veteran and nurse reunited after 40 years
 - [https://www.bbc.co.uk/news/uk-wales-61109453?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-61109453?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 20:50:42+00:00

Denzil Connick, from south Wales, was treated by Nicci Pugh in 1982 - now, 40 years on, they meet again.

## Ukraine round-up: Lviv counts civilian dead and credible sinking warship video
 - [https://www.bbc.co.uk/news/world-europe-61144220?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61144220?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 20:19:33+00:00

Credible footage of sinking Russian warship surfaces as Ukraine says Russia has started its assault to seize Donbas in the east.

## Wales' hospitality businesses struggle to recruit staff
 - [https://www.bbc.co.uk/news/uk-wales-61094777?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-61094777?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 17:44:26+00:00

One holiday park owner hires five chefs from India after being unable to fill the jobs locally.

## Ukraine war: Donbas tourist town braces for Russian assault
 - [https://www.bbc.co.uk/news/world-europe-61139415?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61139415?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 17:15:26+00:00

Sviatohirsk was a tourist trail staple but is now just another place in the Donbas where people flee war.

## Ukraine war: Dramatic images appear to show sinking Russian warship Moskva
 - [https://www.bbc.co.uk/news/world-europe-61141118?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61141118?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 16:40:25+00:00

Russia says the Moskva sank after an explosion of ammunition, but Ukrainians say they hit it with missiles.

## Wayne Quilliam: Photographing the diversity of Aboriginal Australia
 - [https://www.bbc.co.uk/news/world-australia-61033360?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-61033360?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 16:18:26+00:00

Australia has hundreds of Indigenous groups - and Wayne Quilliam is hoping to photograph them all.

## Ukraine war: First civilian deaths in Lviv shatter sense of safety
 - [https://www.bbc.co.uk/news/world-europe-61141817?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61141817?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 16:10:13+00:00

The western city's mayor says the strikes show there are "no safe and unsafe locations" in Ukraine.

## Man arrested after incident at Horse Guards in London
 - [https://www.bbc.co.uk/news/uk-england-london-61140393?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-61140393?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 12:31:12+00:00

There are no reports of any injuries and there is no known risk to the public, police say.

## Rwanda asylum critics have no solutions, says Patel
 - [https://www.bbc.co.uk/news/uk-61137081?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61137081?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 12:17:07+00:00

The home secretary responds after criticism of her refugee plan from the Archbishop of Canterbury.

## Partygate: No easy return for Boris Johnson after Easter break
 - [https://www.bbc.co.uk/news/uk-politics-61140292?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-61140292?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 12:17:06+00:00

Boris Johnson is expected to face questions from MPs on Tuesday after being fined for breaching Covid rules.

## Ukraine war: Captured Briton Shaun Pinner's family hope for quick resolution
 - [https://www.bbc.co.uk/news/uk-61139735?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61139735?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 11:36:57+00:00

Shaun Pinner, who is being held by Russian forces, is described as a well-respected soldier by his family.

## Covid: Law on wearing face masks in Scotland is lifted
 - [https://www.bbc.co.uk/news/uk-scotland-61139581?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-61139581?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 11:19:51+00:00

Face-covering rules have changed but people are still being strongly advised to wear them voluntarily.

## Ukraine war: Prince Harry hails 'extraordinary' Ukraine Invictus team
 - [https://www.bbc.co.uk/news/world-europe-61139107?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61139107?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 11:00:36+00:00

Prince Harry voices his support for Ukraine and applauded their attendance at the Invictus Games.

## Volunteers with cars to transport patients instead of ambulances
 - [https://www.bbc.co.uk/news/uk-england-london-61140384?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-61140384?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 10:57:12+00:00

Volunteers will be sent to those who need assistance to ease pressure on ambulance services.

## Dozens arrested at Sweden riots sparked by planned Quran burnings
 - [https://www.bbc.co.uk/news/world-europe-61134734?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61134734?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 10:42:52+00:00

There have been clashes between police and people angry at a far-right group's plan to burn Qurans.

## Sewage: Ban water firm bonuses until discharges end, Lib Dems say
 - [https://www.bbc.co.uk/news/uk-politics-61065588?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-61065588?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 10:16:42+00:00

Bosses paid £27m extra since 2020 despite 1,000 sewage spills a day, according to the party's research.

## Police disperse illegal rave in Dorset village of East Lulworth
 - [https://www.bbc.co.uk/news/uk-england-dorset-61139702?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-dorset-61139702?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 09:43:54+00:00

Police thank East Lulworth residents for their patience while they moved on the last partygoers.

## Households cancel streaming services to cut costs, report says
 - [https://www.bbc.co.uk/news/business-61139483?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61139483?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 09:13:53+00:00

The rise in the cost of living has led to more households cutting their subscription services.

## Snowdonia authority tells hikers to visit toilet before climbing
 - [https://www.bbc.co.uk/news/uk-wales-61138653?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-61138653?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 08:48:26+00:00

Some walkers 'caught short' are pooing on Wales' highest mountain.

## Ukraine war: Mariupol defenders will fight to the end says PM
 - [https://www.bbc.co.uk/news/world-europe-61135901?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61135901?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 08:16:37+00:00

Capturing the city is a major strategic goal for Russia, leaving it in control of vast swathes of the country.

## Ukraine war: How a BBC journalist's family escaped the country
 - [https://www.bbc.co.uk/news/world-europe-61139105?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61139105?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 08:00:32+00:00

Vitaly Shevchenko's family fled Ukraine with the help of two BBC audience members.

## Falklands veteran recalls HMS Coventry bombing and rescue
 - [https://www.bbc.co.uk/news/uk-england-bristol-61095749?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-bristol-61095749?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 06:14:03+00:00

Former warrant officer John Sheldon from Yeovilton helped bring burned and injured crew to safety.

## The elderly who can't flee their Ukrainian homes
 - [https://www.bbc.co.uk/news/world-europe-61132626?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61132626?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 04:58:12+00:00

Intense shelling in Mykolaiv has forced many people to flee, leaving some elderly residents behind.

## Newspaper headlines: MPs attack Welby 'rant' and PM 'led boozy party'
 - [https://www.bbc.co.uk/news/blogs-the-papers-61136840?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-61136840?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-04-18 04:49:00+00:00

The papers cover the backlash to the archbishop's criticism of the UK's asylum plan and more No 10 party claims.


# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Ministerstwo Zdrowia zerwało kontrakt z Pfizerem! Nie chce zapłacić za szczepionki, które zamówił!
 - [https://www.youtube.com/watch?v=ND_TI85E-os](https://www.youtube.com/watch?v=ND_TI85E-os)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2022-04-19 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3jRzJ6e
2. https://bit.ly/3MhLmQd
3. https://bit.ly/3Etr8QM
4. https://bit.ly/3B6HGLE
5. https://bit.ly/3a1F99F
6. https://bit.ly/2W1gw9J
7. https://bit.ly/3i5ofMD
8. https://bit.ly/3L0yXQi
9. https://bit.ly/3OyVypA
10. https://bit.ly/3paYNsN
11. https://bit.ly/3vv9p7t
---------------------------------------------------------------
💡 Tagi: #Pfizer #Niedzielski
--------------------------------------------------------------

## Juwal Noach Harari o kontroli społeczeństwa poprzez używki i gry komputerowe. Analiza
 - [https://www.youtube.com/watch?v=n8Yr1NIcU-U](https://www.youtube.com/watch?v=n8Yr1NIcU-U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2022-04-18 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3OoK0VB
2. https://bit.ly/2Y3P100
---------------------------------------------------------------
💡 Tagi: #internet #polityka #media
--------------------------------------------------------------

## Robert Bąkiewicz o strategicznej współpracy polsko - ukraińskiej i odbudowie Ukrainy
 - [https://www.youtube.com/watch?v=IkMgsinwSsA](https://www.youtube.com/watch?v=IkMgsinwSsA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2022-04-18 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3vtFRaa
2. https://bit.ly/3uQHLCJ
3. https://bit.ly/3jQYBv7
4. https://bit.ly/3jOReEs
5. https://bit.ly/3tJ8TSq
6. https://bit.ly/3HVLlyX 
7. https://bit.ly/3jNJkeE
8. https://bit.ly/3OiWCO7
9. https://bit.ly/3JPqm1t
10. https://bit.ly/3rusENi
11. https://bit.ly/3JQWjqg
12. https://bit.ly/3JSqbCT
13. https://bit.ly/3MdvsGq
14. https://bit.ly/3KXR4qb
15. https://bit.ly/3xBSYco
16. https://bit.ly/3OnpZPw
---------------------------------------------------------------
🎴 Do kolażu wykorzystano grafikę autorstwa: 
wikipedia.org / Nicole Wójcik
https://bit.ly/3MdW4HC
---------------------------------------------------------------
💡 Tagi: #Polska #Ukraina
--------------------------------------------------------------


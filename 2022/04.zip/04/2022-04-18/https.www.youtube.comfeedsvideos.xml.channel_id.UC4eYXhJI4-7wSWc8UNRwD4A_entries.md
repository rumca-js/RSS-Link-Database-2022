# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Meet The 2022 Tiny Desk Contest Community
 - [https://www.youtube.com/watch?v=PMLRBZravU8](https://www.youtube.com/watch?v=PMLRBZravU8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2022-04-19 00:00:00+00:00

This year, we received Tiny Desk Contest entries from Puerto Rico and the U.S. Virgin Islands, from Maine to California and every state in between. Meet some of the artists who sent in videos from their desks with big dreams to play behind ours.

Watch the full versions of all the entries featured in the video and learn more about the Tiny Desk Contest: https://npr.org/tinydeskcontest 

Songs: 
- SNACKTIME PHILLY, "Gotta Get Funky"
- AYVIO, "Grow Up"
- Lalah, "Caramelo"


# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The Quest 2 has Competition!
 - [https://www.youtube.com/watch?v=r35xUf3Gch4](https://www.youtube.com/watch?v=r35xUf3Gch4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-04-19 00:00:00+00:00

The first 1,000 people to use the link or my code thrillseeker will get a 1 month free trial of Skillshare: https://skl.sh/thrillseeker04221

Thank you to Skillshare for supporting my channel and TMG!
BUT! HELLO and WELCOME TO, Tuesday Newsday! Your number one resource for the entire week's worth of VR news! This week we have some massive news from Pico regarding the Pico Neo 3 Link and Neo 4, two headsets set to compete globally (soon) with the Meta Quest 2. Also some great new VR games are on their way soon! That and so much more! Hope you enjoy!

Outro song:
https://soundcloud.com/etherealdelta/something-good-look-at-the-sky-drum-and-bass-remix?utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing
https://www.youtube.com/watch?v=zSUbAKFFMTo&list=LL&index=1

My links: 
Discord:
https://discord.gg/2hCGM9BYez
Twitch:
https://www.twitch.tv/thrilluwu
Twitter:
https://twitter.com/Thrilluwu
Patreon:
https://www.patreon.com/Thrillseeker

Invest in Thrillseeker Media Group Inc. 
https://www.startengine.com/thrillseekermediagroup

TIMESTAMPS:
00:00 Intro
00:39 Ad
01:28 VR booming
02:08 Meta gaming showcase
02:28 Bonelab?
02:56 Pico Neo 3 Link
05:27 Pico 4
08:05 Meme break
08:26 Apple burns Meta
09:45 PSVR 2 Apple AR/VR delayed
10:30 Weird HTC Vive product?
11:22 QOTW
12:21 OUTRO! :D


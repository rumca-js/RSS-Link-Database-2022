# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## The REAL Reason They Hate Musk
 - [https://www.youtube.com/watch?v=2Qui-0bVzrc](https://www.youtube.com/watch?v=2Qui-0bVzrc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-04-19 00:00:00+00:00

As Elon Musk continues to offer clues as to a potential purchase of Twitter, what are the many protestations from the media REALLY about? 
#ElonMusk #Twitter #Musk #FreeSpeech #Censorship

References
https://www.theguardian.com/technology/2022/apr/15/twitter-poison-pill-elon-musk-takeover
https://vancouversun.com/news/local-news/elon-musk-offers-to-buy-twitter-talks-about-it-at-ted-in-vancouver
https://taibbi.substack.com/p/twitters-chickens-come-home-to-roost?s=r

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## The Great Reset: It Begins
 - [https://www.youtube.com/watch?v=fjGYsner6oI](https://www.youtube.com/watch?v=fjGYsner6oI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-04-18 00:00:00+00:00

Klaus Schwab and the WEF tout their work in saving the world using environmental metrics called ESGs. But if companies that have good scores are actually the worst environmental violators, could it be that what the WEF are really working towards is a social credit scoring system?
#KlausSchwab #WEF #BillGates #TheGreatReset  

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


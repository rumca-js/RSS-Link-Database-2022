## Wartime Is a Bad Time To Mess With the Internet | Electronic Frontier Foundation
 - [https://www.eff.org/deeplinks/2022/03/wartime-bad-time-mess-internet](https://www.eff.org/deeplinks/2022/03/wartime-bad-time-mess-internet)
 - RSS feed: https://www.eff.org
 - date published: 2022-03-04 16:21:54.087975+00:00

Like most people, we at EFF are horrified by Russia’s invasion of Ukraine. Also like most people, we are not experts on military strategy or international diplomacy. But we do have some expertise with the internet and civil liberties, which is why we are deeply concerned that governments around the...


# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## "Super Hidden" Files in Windows (Even Experts Don't Know About)
 - [https://www.youtube.com/watch?v=3BWTo87oCwc](https://www.youtube.com/watch?v=3BWTo87oCwc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2022-03-05 00:00:00+00:00

I bet almost none of you know about this 🤔

⇒ Become a channel member for special emojis, early videos, and more! Check it out here: https://www.youtube.com/ThioJoe/join

▼ Time Stamps: ▼
0:00 - Intro
1:13 - Hiding Text
2:58 - Hiding An Entire File
5:01 - Some Additional Points
5:23 - Deleting Alternate Data Streams
6:21 - How to Find Alternate Data Streams
7:59 - AlternateStreamView Tool
9:20 - Real Usage Examples
11:40 - What's the Point?

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬


# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## VR is missing something BIG
 - [https://www.youtube.com/watch?v=s4nStJm5TYM](https://www.youtube.com/watch?v=s4nStJm5TYM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-03-05 00:00:00+00:00

Legs. We walk with em. We kick things with em. They ground us in reality. 

Literally. 

We need them in Virtual Reality even if they're "hard to do" 

Outro Music: https://soundcloud.com/etherealdelta/magic

My links: 
https://discord.gg/sZyzWXVXMz
https://www.twitch.tv/thrilluwu
https://www.patreon.com/Thrillseeker
https://twitter.com/Thrilluwu
https://www.startengine.com/thrillseekermediagroup


# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## This new chip tech could change everything!
 - [https://www.youtube.com/watch?v=0N2IVSOdMYE](https://www.youtube.com/watch?v=0N2IVSOdMYE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2022-03-04 00:00:00+00:00

Sponsored by Curiositystream. Visit https://curiositystream.com/tfc to sign up and get access to Nebula for free with your subscription.

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► This video ◄◄◄  

This week a new chip alliance called UCIe was formed, Apple announced its March 8th event and Samsung got caught throttling 10000 apps.

Episode 86

List of throttled apps: https://docs.google.com/spreadsheets/d/1rihB84MYpPylmsPpQHThr3lIegYGozE5/edit#gid=1024731923

This video on Nebula: https://nebula.app/videos/the-friday-checkout-new-combined-chips-are-coming
Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd 
Quiz: https://link.crrowd.com/quiz

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support my work directly:  https://flattr.com/@techaltar   

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:31 Release highlights
2:02 Samsung, the throttler
4:08 Chips like legos
6:52 Apple event


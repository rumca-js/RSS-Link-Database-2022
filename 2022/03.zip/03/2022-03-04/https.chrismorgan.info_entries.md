## Don’t use the Unlicense, an inferior license with an atrocious name - an article by Chris Morgan
 - [https://chrismorgan.info/blog/unlicense/](https://chrismorgan.info/blog/unlicense/)
 - RSS feed: https://chrismorgan.info
 - date published: 2022-03-04 16:12:39+00:00

Not only is it poorly drafted with better alternatives available, but “Unlicensed” means the precise opposite of “unlicensed”.


# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## What if Sauron got The One Ring? | Tolkien Theory
 - [https://www.youtube.com/watch?v=IMtK_ntVorQ](https://www.youtube.com/watch?v=IMtK_ntVorQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-03-05 00:00:00+00:00

We look at sections of The Lord of the Rings and Tolkien's letters to answer the question - what would happen if Sauron reclaimed The One Ring?  We'll pick up from Frodo's failure at Mount Doom to determine Sauron's strategy, how the elves would seek to combat him, and who would be left standing!

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

To purchase artist work, check out these amazing artists!

Anna Podedworna - https://www.artstation.com/akreon
Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html
Donato Giancola - https://www.donatoarts.com/online-store/secure-store/Middle-earth-c34110463
Aronja Art - https://www.instagram.com/aronjaart/
Ivan Cavini - https://www.instagram.com/ivan_cavini/
Sara Morello - https://www.artstation.com/saramorello
Tulikoura - https://www.deviantart.com/tulikoura

Sauron - Jerry Vanderstelt
Sauron at Barad-dur - Shadow of War
Sauron - Anna Podedworna (thumbnail)
Sauron - WETA
Sauron - Shadow of War
At the Cracks of Doom - Ted Nasmith
Frodo and Sam in Mordor - Andrea Piparo
Sauron - WETA
Sauron - Guardians of Middle-earth
Battle of the Black Gate - Ted Nasmith
The Eagle's Song - Anke Eissmann
Nazgul Charge - Felix Englund
Battle of Dale - WETA
Eye of Sauron - John Howe
Battle of Dale - WETA
Dol Guldur - WETA
Sauron - Guardians of Middle-earth
Angband - Skullb*st*rd
Battle of Pelennor Fields - Aegeri
Sauron - Shadow of War
Sauron - WETA
Galadriel - Catherine Karina Chmiel
Elrond Halfelven - Donato Giancola
Morgoth - CK Goksoy
Minas Tirith - Ralph Damiani
Lothlorien - Ralph Damiani
Rivendell - Ralph Damiani
Grey Havens - Ralph Damiani
Sauron - Alan Lee
Carn Dum - Skullb*st*rd
Orthanc - Ralph Damiani
Fortress - Felix Englund
The Mouth of Sauron - John Howe
The Mouth of Sauron - John Howe
Mouth of Sauron - Guardians of Middle-earth
Nazgul Bowing Before Sauron - Kip Rasmussen
Sauron - Janka Lateckova
Barad-dur - Shadow of War
Saruman - John Howe
The Voice of Isengard - Matthew Stewart
Sauron - Tom Romain (for Lore of the Rings YouTube channel)
Luthien in the Court of Morgoth - Pete Amachree
Sauron the Deceiver - Skullb*st*rd
Spirit of Sauron - Skullb*st*rd
The Shadow of Sauron - Ted Nasmith
Morgoth - CK Goksoy
Morgoth the Vala - Skullb*st*rd
The Shores of Valinor - Ted Nasmith
Eru Iluvatar - Janka Lateckova
Music of the Gods - Kip Rasmussen
Wanderer - CK Goksoy
Radagast the Brown - Ralph Damiani
Alatar and Pallando - Ralph Damiani
Alatar and Pallando 2 - Ralph Damiani
Sam and Frodo in Emyn Muil - Ted Nasmith
Mount Doom - Alan Lee
Samwise Gamgee - Matthew Stewart

#sauron #lordoftherings #tolkien

## Sean Astin hosts Tolkien Trivia, Q&A, & Wrapping Up Fellowship with his Book Club!
 - [https://www.youtube.com/watch?v=GQQF9xmqsWg](https://www.youtube.com/watch?v=GQQF9xmqsWg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-03-04 00:00:00+00:00

I was honored to be a guest on Sean Astin's Zoom Event to celebrate his book club wrapping up The Fellowship of the Ring - and Fable was kind enough to let me share the video here on the channel.  Also featuring Don Marshall and SH from Fable, we talk about our appreciation for JRR Tolkien, finding comfort in Middle-earth, Q&A with Sean.  PLUS Sean and Sarah host a Tolkien Trivia Showdown between me and Don! 

Join me, Sean, Sarah, and Don in the Sean Astin Book Club!  Visit: https://fable.co/seanastin

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

#tolkien #lordoftherings #seanastin


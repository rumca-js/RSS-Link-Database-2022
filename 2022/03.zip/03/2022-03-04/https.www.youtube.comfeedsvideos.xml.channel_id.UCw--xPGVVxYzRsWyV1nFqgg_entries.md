# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Sanderson Shatters Records🥇 New Tolkien Art🎨 More Pokémon🐲 -Fantasy News
 - [https://www.youtube.com/watch?v=hAaqIMaF8hM](https://www.youtube.com/watch?v=hAaqIMaF8hM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-03-04 00:00:00+00:00

let's Jump into the FANTASY NEWS! 
Check out campfire today: https://www.campfirewriting.com/write/for-novelists?utm_source=youtube&utm_medium=video&utm_campaign=DG_Q1_22 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

00:00 intro

01:08 Kickstarter Progress: https://www.kickstarter.com/projects/dragonsteel/surprise-four-secret-novels-by-brandon-sanderson?ref=bva2b9 

02:53 Secret Story One: https://www.brandonsanderson.com/first-look-at-secret-project-1/ 

Graph by Marc Bitterli: https://www.reddit.com/r/brandonsanderson/comments/t4zfpx/updated_brando_sando_publishing_stats_details/

Chapters Read By Sanderson: https://www.youtube.com/watch?v=bBUVXcIE0E0&ab_channel=BrandonSanderson 

04:48 Bendergate is over: https://twitter.com/variety/status/1498780118923157505?s=21 

05:45 Pokemon Scarlette and Violet: https://www.youtube.com/watch?v=xXVG5kG6U5k&ab_channel=Pok%C3%A9monAsiaENG 

06:40 New Tolkien art: https://news.artnet.com/art-world/j-r-r-tolkein-art-2079698 

08:49 Priscilla Tolkien Passes: https://www.theonering.net/torwp/2022/03/01/112398-priscilla-tolkien-dies-aged-92/


# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## 140 million infections in US
 - [https://www.youtube.com/watch?v=BaUK31EjRRo](https://www.youtube.com/watch?v=BaUK31EjRRo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-03-04 00:00:00+00:00

Or is it many more that that? If you would like John’s text books, (it is free to download the PDFs)

Link to free download of my 2 textbooks

http://159.69.48.3/

Physiology book in hard copy
https://www.ebay.co.uk/itm/154770452796?mkevt=1&mkcid=16&mkrid=710-127635-2958-0



140 million Americans have had coronavirus

Nationwide COVID-19 Infection-Induced Antibody Seroprevalence (Commercial laboratories)

https://covid.cdc.gov/covid-data-tracker/#national-lab

https://www.cdc.gov/coronavirus/2019-ncov/cases-updates/commercial-lab-surveys.html

58 % up to 17 years, have antibodies infection

Last data, 72,000 blood samples taken in January

Percentage, United States, resolving or past infection with SARS-CoV-2,

but not how much antibody is present,

do not necessarily indicate the percentage of people with sufficient antibody to protect against reinfection

These percentages do not include people who have been vaccinated against SARS-CoV-2 and have no history of infection. 

Results directly from paper

https://pubmed.ncbi.nlm.nih.gov/33231628/

Estimated SARS-CoV-2 Seroprevalence in the US as of September 2020



 


 



 




Nationwide COVID-19 Infection- and Vaccination-Induced Antibody Seroprevalence (Blood donations)

https://covid.cdc.gov/covid-data-tracker/#nationwide-blood-donor-seroprevalence

Percentage, 16 years and older, developed antibodies against SARS-CoV-2 from vaccination or infection.

December 2021


 


Australia

https://www.health.gov.au/health-alerts/covid-19/case-numbers-and-statistics

 





UK, ONS

https://www.ons.gov.uk/peoplepopulationandcommunity/healthandsocialcare/conditionsanddiseases/articles/coronaviruscovid19/latestinsights

Week ending 19 February

3.84% in England (1 in 25 people) 

3.23% in Wales (1 in 30 people)

7.23% in Northern Ireland (1 in 14 people)

4.57% in Scotland (1 in 20 people)

## Brief global pandemic update
 - [https://www.youtube.com/watch?v=TbOoGgtnXUg](https://www.youtube.com/watch?v=TbOoGgtnXUg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-03-04 00:00:00+00:00

Most areas getting over omicron pandemic wave, a few still in the early stages
https://ourworldindata.org/coronavirus


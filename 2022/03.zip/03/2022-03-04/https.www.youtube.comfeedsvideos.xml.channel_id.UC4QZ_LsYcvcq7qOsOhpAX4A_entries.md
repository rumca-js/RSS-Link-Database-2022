# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## Russian Sanctions and Global Economic Risk
 - [https://www.youtube.com/watch?v=D2vLH0tJVHo](https://www.youtube.com/watch?v=D2vLH0tJVHo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2022-03-04 00:00:00+00:00

The sanctions on Russia’s financial system were used to deter Putin from further escalation in the war, but what are the risks?

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

» ColdFusion Discord:  https://discord.gg/coldfusion
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusioncollective
» Podcast I Co-host: https://www.youtube.com/channel/UC6jKUaNXSnuW52CxexLcOJg
» Podcast Version of Videos: https://open.spotify.com/show/3dj6YGjgK3eA4Ti6G2Il8H
https://podcasts.apple.com/us/podcast/coldfusion/id1467404358

ColdFusion Music Channel: https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

ColdFusion Merch:
INTERNATIONAL: https://store.coldfusioncollective.com/
AUSTRALIA: https://shop.coldfusioncollective.com/

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- "New Thinking" written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

Sources:

https://theconversation.com/just-short-of-nuclear-the-latest-financial-sanctions-will-cripple-russias-economy-178000 
 
https://edition.cnn.com/2022/03/02/investing/default-sanctions-russia/index.html

https://files.stlouisfed.org/files/htdocs/publications/review/02/11/ChiodoOwyang.pdf

https://finance.yahoo.com/news/central-bank-russia-launches-swift-154004953.html

https://www.investopedia.com/articles/personal-finance/050515/how-swift-system-works.asp


My Music Channel:  https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

//Soundtrack//

Tom Day - Future Holds
Kazukii - Milo
Valotihkuu - Sleeping In Wildflower Meadow
Aphex Twin - Stone In Focus 
Nova Nova – See
Burn Water – Nostalgia Dreams


» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide


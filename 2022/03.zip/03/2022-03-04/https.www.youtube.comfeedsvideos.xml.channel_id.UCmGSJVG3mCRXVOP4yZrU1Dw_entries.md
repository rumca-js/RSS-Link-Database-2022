# Source:John Harris, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmGSJVG3mCRXVOP4yZrU1Dw, language:en-US

## Putin Will Lose, Here's Why
 - [https://www.youtube.com/watch?v=FQ4hvLqNfqo](https://www.youtube.com/watch?v=FQ4hvLqNfqo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmGSJVG3mCRXVOP4yZrU1Dw
 - date published: 2022-03-05 00:00:00+00:00

Putin is taking over land, but losing the war. 
Get an exclusive NordVPN deal here: https://nordvpn.com/johnnyharris
Donate to Save The Children here or on their website: https://www.savethechildren.org/help-ukraine

We’re matching donations to Save The Children | Ukraine up to $10,000.
The recent escalation in hostilities in Ukraine has put at least 7.5 million children in grave danger of physical harm, severe emotional distress, and displacement. Save the Children have been in Ukraine since 2014, and are on the ground near the Ukrainian border providing people with life-saving assistance as they flee the conflict. Please donate, every little bit counts.

This is Putin’s war and to understand it you have to look at the story Putin tells himself and the Russian people that helped justify this invasion. In this video I explore Putin’s motive and make the case that Russia has already lost this war.

Thank you to the excellent reporting by: The New York Times, The BBC, Reuters, The Economist. Thank you to all those on the ground who sent me videos and perspectives about the situation. 

Here are some related videos I’ve made:
The REAL Reason Putin is Invading Ukraine - https://youtu.be/LJNtfyq3TDE
Here’s What Happens if China Invades Taiwan - https://youtu.be/VNZ0so0LCoM
Why is Russia so DAMN BIG? - https://youtu.be/HBlZlmXyR5M
The Man Putin Fears The Most - https://youtu.be/hrORwk_RZLM

- ways to support - 
My Patreon: https://www.patreon.com/johnnyharris
Our custom Presets & LUTs: https://store.dftba.com/products/johnny-iz-luts-and-presets

- where to find me -
Instagram: https://www.instagram.com/johnny.harris/
Tiktok: https://www.tiktok.com/@johnny.harris
Facebook: https://www.facebook.com/JohnnyHarrisVox
Iz's (my wife’s) channel: https://www.youtube.com/iz-harris

- how i make my videos -
Tom Fox makes my music, work with him here: https://tfbeats.com/
I make maps using this AE Plugin: https://aescripts.com/geolayers/?aff=77
All the gear I use: https://www.izharris.com/gear-guide
 
- my courses - 
Learn a language: https://brighttrip.com/course/language/
Visual storytelling: https://www.brighttrip.com/courses/visual-storytelling

- about -
Johnny Harris is a filmmaker and journalist. He currently is based in Washington, DC, reporting on interesting trends and stories domestically and around the globe. Johnny's visual style blends motion graphics with cinematic videography to create content that explains complex issues in relatable ways. He holds a BA in international relations from Brigham Young University and an MA in international peace and conflict resolution from American University.

- press - 
NYTimes: https://www.nytimes.com/2021/11/09/opinion/democrats-blue-states-legislation.html
NYTimes: https://www.nytimes.com/video/opinion/100000007358968/covid-pandemic-us-response.html
Vox Borders: https://www.youtube.com/watch?v=hLrFyjGZ9NU
Finding Founders: https://findingfounders.co/episodes/johnny-harris-2esj3-c3pet-2pg4c-xbtwa-5gaaa
NPR Planet Money: https://www.npr.org/transcripts/1072164745


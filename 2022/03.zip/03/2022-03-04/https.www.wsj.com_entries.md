## Texas Parents of Transgender Teen Win Legal Victory - WSJ
 - [https://www.wsj.com/articles/texas-parents-of-transgender-teen-win-legal-victory-11646270616](https://www.wsj.com/articles/texas-parents-of-transgender-teen-win-legal-victory-11646270616)
 - RSS feed: https://www.wsj.com
 - date published: 2022-03-04 21:02:29.658400+00:00

Court forbids the state from investigating family for child abuse under new Texas directive. 


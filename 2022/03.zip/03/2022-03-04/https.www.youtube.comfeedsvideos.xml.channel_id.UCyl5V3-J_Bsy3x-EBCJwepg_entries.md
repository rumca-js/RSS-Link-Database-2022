# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## The Bee Weekly: Russia Invades, Moral Fossil Fuels, and The Bee Turns 6
 - [https://www.youtube.com/watch?v=Iuq87jtEPkU](https://www.youtube.com/watch?v=Iuq87jtEPkU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-03-04 00:00:00+00:00

On The Bee Weekly, Kyle and Adam are joined by Mike Luso to talk about this week at the Babylon Bee as The Bee turns 6 years old, Russia invades Ukraine, and Biden gives an interesting State of the Union. Then Alex Epstein—no relation—brings his moral case for fossil fuels.

You can find out more about Alex Epstein at the Center for Industrial Progress: https://industrialprogress.com/

Get his book The Moral Case For Fossil Fuels: https://www.amazon.com/Moral-Case-Fossil-Fuels/dp/1591847443

Or pre-order his upcoming book Fossil Future: https://www.amazon.com/Fossil-Future-Flourishing-Requires-Gas-Not-ebook/dp/B098M3Y7VC/ref=sr_1_1?crid=3DPAUCIGNV6CX&keywords=fossil+future&qid=1646353107&s=books&sprefix=fossil+futur%2Cstripbooks%2C113&sr=1-1

This episode is brought to you by My Patriot Supply: preparewithbee.com

This episode is also brought to you by Daily Nouri: https://dailynouri.com/

In need of Christian counseling? Check out our friends and Faithful Counseling: faithfulcounseling.com/babylonbee


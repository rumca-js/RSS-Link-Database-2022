# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## The Economy Is Fake, the Jobs Are Fake, the Money Is Fake
 - [https://www.youtube.com/watch?v=9lDTdLQnSQo](https://www.youtube.com/watch?v=9lDTdLQnSQo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2022-03-04 00:00:00+00:00

You can't roast people too badly for being "antiwork" when most jobs are simply useless nowadays. Polls have shown that around half of people report either their job is totally useless, or that it's unclear to them if there is any social benefit to their work whatsoever. How has this happened? Why do people put so much effort into what is, in effect, play work.

 We talk about David Graeber's article, book and concept of Bullshit Jobs, jobs so inane that even the people working them can't justify their existence. This brings up economic questions of hyper-production, the Consoomerist economy, post-scarcity and of course the alleged panacea of Universal Basic Income (UBI).

 At the root of all of it is a public-private plastic economy based on easy and highly inflationary money, which strips people of savings and keeps people working like good wagies from cradle to the grade on jobs that exist just to keep the fake economy going. Comments on the psychological effects of Bitcoin and hard money included.

 Antiwork R*dditor appears on Fox News: https://odysee.com/Antiwork_mod_lol:f The original Bullshit jobs article: https://www.strike.coop/bullshit-jobs/ "Why It's Bad to Have High GDP": https://lukesmith.xyz/articles/why-its-bad-to-have-high-gdp

00:00:00 The Fake Economy
00:01:09 Virgin antiwork Redditor vs. Chad Fox News
00:03:01 David Graeber's BS Jobs 00:06:08 An example of a BS job in the German military
00:08:09 How many people have fake jobs?
00:09:22 Is it just a government problem?
00:16:12 The Coofvid Lockdown and "Non-essential workers"
00:18:31 Defining Modern Wageslavery and on "Employees" and Time
00:22:52 The types of BS jobs
00:25:30 Goons and Cigarette Ads
00:27:09 Fake non-software jobs
00:30:25 This is NotRelated.xyz
00:31:38 LONG Donation reading
00:46:12 The culture of Wagecuckery and Hyperproduction
00:49:50 Graeber and the Wagie mindset
00:50:17 Universal Basic Income (UBI) and Post-Scarcity
00:53:18 UBI and the Wagie Uprising
00:56:28 The Inflation Run
00:59:09 Should I care about inflation?
01:00:06 Life in a deflationary economy
01:02:19 What are BS jobs in the inflationary economy?
01:04:38 Would Graeber agree?
01:06:01 Inflation as theft.
01:07:07 Why high GDP is bad
01:09:36 The example of the Bitcoiner mindset
01:10:54 Will gold and Bitcoin destroy the economy? Yes.
01:13:38 Hard Money and Bullsh*t Jobs: The Endgame
01:15:09 Fake Anarchism and UBI
01:16:20 Comments on Left and Right Anarchism
01:18:18 Closing Notes, including *important* RSS updates!


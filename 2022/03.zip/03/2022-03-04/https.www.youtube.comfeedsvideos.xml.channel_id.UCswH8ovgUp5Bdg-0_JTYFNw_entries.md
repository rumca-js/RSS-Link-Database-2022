# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Lab Leak: They Are Trying To Hide This
 - [https://www.youtube.com/watch?v=R1TisjALpow](https://www.youtube.com/watch?v=R1TisjALpow)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-03-05 00:00:00+00:00

A study featured in the New York Times once again reprises the assertion that the COVID-19 pandemic began in a Wuhan market, not a lab. Case closed then, right?  
#Wuhan #LabLeak #Covid #Pandemic 

References
https://www.outkick.com/why-we-should-question-latest-report-that-pandemic-originated-in-wuhan-market/

https://www.nytimes.com/interactive/2022/02/26/science/covid-virus-wuhan-origins.html

https://mobile.twitter.com/Ayjchan/status/1497937447577133066

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Russian Anti-War Protests - This Is How We Come Together
 - [https://www.youtube.com/watch?v=kRQ9WtP-97w](https://www.youtube.com/watch?v=kRQ9WtP-97w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-03-04 00:00:00+00:00

Politicians across the world have been busy expressing their admiration for Russians risking arrest to take part in anti-war marches – but that didn’t stop them voting to restrict the right to protest in their own countries 
#Protest #Putin #Russia #Ukraine 

References
https://nationalpost.com/news/canada/did-chrystia-freeland-pose-with-extremist-symbols-or-is-it-russian-disinformation

https://www.wsj.com/articles/canadian-democracy-survive-justin-trudeau-freedom-convoy-peaceful-protest-ottawa-unacceptable-views-emergency-act-civil-liberties-11645472383

https://www.bigissue.com/news/activism/these-mps-praised-brave-russian-protesters-then-voted-to-restrict-protest-in-the-uk/

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


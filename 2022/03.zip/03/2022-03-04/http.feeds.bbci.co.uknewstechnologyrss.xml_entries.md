# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Facebook hits out at Russia blocking its platforms
 - [https://www.bbc.co.uk/news/technology-60626777?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-60626777?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-03-04 21:50:43+00:00

The Russian communications regulator said on Friday that Facebook has been blocked in the country.

## Microsoft stops selling products in Russia
 - [https://www.bbc.co.uk/news/technology-60621205?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-60621205?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-03-04 16:41:01+00:00

The tech giant will no longer sell products and services there following the invasion of Ukraine.

## Ukraine says it is fighting first 'hybrid war'
 - [https://www.bbc.co.uk/news/technology-60622977?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-60622977?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-03-04 16:14:18+00:00

Alongside the conventional war in Ukraine, a cyber-conflict is also being fought, says the government.

## Fitbit recalls Ionic watch following skin burns
 - [https://www.bbc.co.uk/news/technology-60621202?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-60621202?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-03-04 13:49:04+00:00

The US regulator received more than 70 reports of burn injuries from the Fitbit Ionic's battery.

## Ukraine conflict: Government to sell NFTs to fund war against Russia
 - [https://www.bbc.co.uk/news/business-60613613?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60613613?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-03-04 05:50:50+00:00

The announcement comes just days after Ukraine raised more than £200m in a sale of war bonds.


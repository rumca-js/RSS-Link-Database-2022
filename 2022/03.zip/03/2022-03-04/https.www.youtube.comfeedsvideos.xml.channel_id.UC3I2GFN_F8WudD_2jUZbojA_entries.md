# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Hand Habits - 4th of july (Live on KEXP)
 - [https://www.youtube.com/watch?v=PDoIfSHHXJQ](https://www.youtube.com/watch?v=PDoIfSHHXJQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-03-04 00:00:00+00:00

http://KEXP.ORG presents Hand Habits performing “4th of july” live in the KEXP studio. Recorded February 19, 2022.

Meg Duffy - Guitar & Lead Vocals
Gregory Uhlmann - Guitar & Backing Vocals
Alan Wyffels - Keyboard & Backing Vocals
Patrick Kelly - Bass
Tim Carr - Drums

Host: DJ Morgan
Audio Engineer & Mastering: Julian Martlew
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Kendall Rock
Editor: Carlos Cruz

https://www.handhabits.band
http://kexp.org

## Hand Habits - Aquamarine (Live on KEXP)
 - [https://www.youtube.com/watch?v=l4HkM0-qJcQ](https://www.youtube.com/watch?v=l4HkM0-qJcQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-03-04 00:00:00+00:00

http://KEXP.ORG presents Hand Habits performing “Aquamarine” live in the KEXP studio. Recorded February 19, 2022.

Meg Duffy - Guitar & Lead Vocals
Gregory Uhlmann - Guitar & Backing Vocals
Alan Wyffels - Keyboard & Backing Vocals
Patrick Kelly - Bass
Tim Carr - Drums

Host: DJ Morgan
Audio Engineer & Mastering: Julian Martlew
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Kendall Rock
Editor: Carlos Cruz

https://www.handhabits.band
http://kexp.org

## Hand Habits - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=EPUv1P8b2yE](https://www.youtube.com/watch?v=EPUv1P8b2yE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-03-04 00:00:00+00:00

http://KEXP.ORG presents Hand Habits performing live in the KEXP studio. Recorded February 19, 2022.

Songs:
No Difference
More Than Love
Aquamarine
4th of july

Meg Duffy - Guitar & Lead Vocals
Gregory Uhlmann - Guitar & Backing Vocals
Alan Wyffels - Keyboard & Backing Vocals
Patrick Kelly - Bass
Tim Carr - Drums

Host: DJ Morgan
Audio Engineer & Mastering: Julian Martlew
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Kendall Rock
Editor: Carlos Cruz

https://www.handhabits.band
http://kexp.org

## Hand Habits - More Than Love (Live on KEXP)
 - [https://www.youtube.com/watch?v=x6uEDblNoX4](https://www.youtube.com/watch?v=x6uEDblNoX4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-03-04 00:00:00+00:00

http://KEXP.ORG presents Hand Habits performing “More Than Love” live in the KEXP studio. Recorded February 19, 2022.

Meg Duffy - Guitar & Lead Vocals
Gregory Uhlmann - Guitar & Backing Vocals
Alan Wyffels - Keyboard & Backing Vocals
Patrick Kelly - Bass
Tim Carr - Drums

Host: DJ Morgan
Audio Engineer & Mastering: Julian Martlew
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Kendall Rock
Editor: Carlos Cruz

https://www.handhabits.band
http://kexp.org

## Hand Habits - No Difference (Live on KEXP)
 - [https://www.youtube.com/watch?v=YxUkEgx6WOo](https://www.youtube.com/watch?v=YxUkEgx6WOo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-03-04 00:00:00+00:00

http://KEXP.ORG presents Hand Habits performing “No Difference” live in the KEXP studio. Recorded February 19, 2022.

Meg Duffy - Guitar & Lead Vocals
Gregory Uhlmann - Guitar & Backing Vocals
Alan Wyffels - Keyboard & Backing Vocals
Patrick Kelly - Bass
Tim Carr - Drums

Host: DJ Morgan
Audio Engineer & Mastering: Julian Martlew
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Kendall Rock
Editor: Carlos Cruz

https://www.handhabits.band
http://kexp.org


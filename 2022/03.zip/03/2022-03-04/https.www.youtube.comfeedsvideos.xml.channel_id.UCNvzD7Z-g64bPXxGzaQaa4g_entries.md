# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## TWO NEW PLAYSTATION EXCLUSIVES LEAKED, NEXT GEN GTA5 REVEALED, & MORE
 - [https://www.youtube.com/watch?v=Ky-LYN7EGBA](https://www.youtube.com/watch?v=Ky-LYN7EGBA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-03-04 00:00:00+00:00

Thank you HelloFresh for sponsoring this video. Use code POGGAMERANX16 for up to 16 FREE MEALS + 3 surprise gifts across 6 HelloFresh boxes, plus free shipping at https://strms.net/gameranxHelloFreshYT

A rumor on new PS5 games, more Pokemon games around the corner, Star Wars Eclipse updates, and more in a week full of gaming news.

Jake on twitter: https://bit.ly/3gdkPqD​​​​

Instagram: https://bit.ly/3uUh9Ot


 ~~~~STORIES~~~~


Rockstar details next gen GTA5
https://www.gamespot.com/articles/new-gta-5-and-gta-online-for-ps5-and-xbox-series-x-s-details-screenshots-revealed/1100-6501259/?ftag=CAD-01-10abi2f

https://www.rockstargames.com/newswire/article/172872k8a375k8/gtav-and-gta-online-coming-march-15-for-playstation-5-and-xbox-series?utm_source=twitter&utm_medium=o_social&utm_campaign=gtav_announcement_transfer-details-20220304

Two NEW PS5 exclusives leaked?
https://www.dualshockers.com/new-infamous-and-sly-cooper-reportedly-in-development-for-ps5/


New Pokemon
https://scarletviolet.pokemon.com/en-us/


Gabe https://youtu.be/9Dy-KWjp-m0
New Valve game: https://youtu.be/py65lULJ8w0

Good read on Miyazakihttps://www.newyorker.com/culture/persons-of-interest/hidetaka-miyazaki-sees-death-as-a-feature-not-a-bug


Gran Turismo 7 trailer:
https://youtu.be/ULfjoCqEo6I

Kirby demo
https://youtu.be/2O2HOgq_H_s



RE next gen
https://twitter.com/RE_Games/status/1499036815000543234

Star Wars Eclipse 
https://www.xfire.com/exclusive-quantic-dream-struggles-to-hire-for-star-wars-eclipse-release-aimed-for-2027/

Stalker 2
https://www.pcgamer.com/stalker-2-development-paused-we-are-striving-to-help-our-employees-and-their-families-to-survive/
https://www.nme.com/news/gaming-news/game-developers-are-creating-a-charity-bundle-to-support-ukraine-3172062

***How to help***
https://www.reddit.com/r/ukraine/comments/s6g5un/want_to_support_ukraine_heres_a_list_of_charities/


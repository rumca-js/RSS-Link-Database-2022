# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This blows away the competition - JONSBO N1 NAS Build
 - [https://www.youtube.com/watch?v=boKmZKTKXHc](https://www.youtube.com/watch?v=boKmZKTKXHc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-03-05 00:00:00+00:00

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/linus

Get 50% off on your annual Zoho CRM subscription at: https://lmg.gg/ZohoCRM

We’ve built some crazy servers in the range of petabytes of storage, but we haven’t talked much about smaller, more practical home NAS units… or how you can build one yourself – like we’re doing today with the JONSBO N1 NAS case and Seagate storage.

Discuss on the forum!: https://linustechtips.com/topic/1416118-100tb-in-this-tiny-case/

Buy the Jonsbo N1 Mini Case: https://lmg.gg/1Drij

Buy an AMD Ryzen 3 3100 on Amazon: https://geni.us/DXWFvnc

Buy an Asus ROG STRIX B550-I: https://geni.us/Z83J0o

Buy a G.Skill Ripjaws V 16 GB Kit on Amazon: https://geni.us/b4Apku

Buy a Kingston A400 120 GB on Amazon: https://geni.us/wyePZbl

Buy an EVGA SuperNOVA GM 550W: https://geni.us/ax4A

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro

## Never Hate On Your Community - WAN Show March 4, 2022
 - [https://www.youtube.com/watch?v=im9nFi79n8c](https://www.youtube.com/watch?v=im9nFi79n8c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-03-04 00:00:00+00:00

Get 50% off your Zoho CRM annual subscription with code ZCRM50 at: https://lmg.gg/ZohoCRMWAN

Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off

Purchase a Seasonic FOCUS Power Supply at https://geni.us/F7w6w4g


Check out the WAN Show & Podcast Gear: https://lmg.gg/podcastgear

Check out the They're Just Movies Podcast: https://lmg.gg/tjmpodcast


Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Never-Hate-On-Your-Community---WAN-Show-March-4--2022-e1fc8gc

Timestamps: (Courtesy of NoKi1119)
0:00 Chapters
0:55 Intro
1:22 Linus does not count Twitch as a community
1:53 Topic #1 - Artesian Builds & Kiapia drama
3:21 Explaining giveaway program
7:13 Linus's story on Christmas giveaway
10:44 Community backlash
13:40 Linus lasts a week without controversy
15:19 JayzTwoCents built Kiapia a PC
15:58 PC tech communities stick together
16:58 Topic #2 - Nintendo removes videos of Yuzu run on Steam Deck
18:53 Modded Switch ROM dumping & legal piracy
21:10 Nintendo & yuzu emulator videos take-down discussion
24:44 Fair use, dumping ROMs on Steam Deck, discussing emulators
29:27 Roblox Corp is worth more than Nintendo
31:45 Linus explains Nintendo's reasoning
33:07 Gabe delivering Decks, Linus's experience with Deck
35:02 Talking games: Horizon ZD, Zelda BotD, Horizon FW
48:36 Sponsor - Squarespace 
49:30 Sponsor - Seasonic
50:06 Sponsor - Zoho CRM
50:56 LTTStore new colored cable ties
51:58 Linus was late due to Sarah's new streaming setup
54:09 Topic #3 - Tech industry actions against Russia
55:22 LMG is no longer working with Russia or Belarus
56:48 Russian Rubel falling, Russian stock market closed
57:18 Russia blocking websites, Starlink in Ukraine
58:03 Roscosmos threatening SpaceX to shut down ISS
59:22 Russians, the people, are NOT "Russia"
1:00:37 Topic #4 - Nvidia hacked, 1 TB data leak
1:02:02 References to code chips & credentials in leak
1:04:03 DLSS source code leak
1:05:47 Topic #5 - Epic games buys Bandcamp, BC Fridays
1:09:23 Topic #6 - Rivian backlash for pre-order price
1:13:48 Merch Messages
1:14:00 SAM effect on AMD RX GPUs
1:15:01 Steam Deck with external hubs, M2 holder
1:15:45 Linus recommends waiting on buying GPUs
1:16:30 Thoughts on Pokemon
1:19:08 Destiny 2 banning Deck players, Deck & Windows
1:23:20 Pokemon idea
1:25:35 Color calibration drift for cameras
1:26:35 LTTStore backpack plans & most exciting feature
1:28:04 Vault restoration, SteamOS on AYA & ONEX
1:31:02 Floatplane as ticket-based music streaming
1:31:46 Devices being "fast enough" for consumers
1:33:28 Thunderbolt dock worth
1:34:38 Windows requirement to log-in bypassed
1:35:32 Sea of Stars, Steam Deck game experience
1:39:36 Why LTTStore woman merch lacks logos
1:47:20 Outro


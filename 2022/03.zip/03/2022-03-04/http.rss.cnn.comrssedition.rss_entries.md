# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Serena Williams: 'I should have been at like 30 or 32' grand slam singles titles
 - [https://www.cnn.com/2022/03/04/tennis/serena-williams-grand-slam-amanpour-spt-intl/index.html](https://www.cnn.com/2022/03/04/tennis/serena-williams-grand-slam-amanpour-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 22:52:05+00:00

Widely considered to be the GOAT of women's tennis, 23-time grand slam champion Serena Williams says she's still aiming to beat Margaret Court's record of 24.

## Pence to condemn Republican Putin 'apologists' in speech to RNC donors
 - [https://www.cnn.com/2022/03/04/politics/mike-pence-republican-putin-rnc/index.html](https://www.cnn.com/2022/03/04/politics/mike-pence-republican-putin-rnc/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 22:23:19+00:00

Former Vice President Mike Pence is expected to condemn Republican "apologists" who have complimented Russian President Vladimir Putin amid his invasion of Ukraine, according to excerpts of a Friday speech to top GOP donors, obtained by CNN.

## Missing ship found in Lake Superior after 130 years
 - [https://www.cnn.com/travel/article/shipwreck-atlanta-found-lake-superior/index.html](https://www.cnn.com/travel/article/shipwreck-atlanta-found-lake-superior/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 22:15:20+00:00

Once thought to be lost forever, the 130-year-old wreckage of the ship Atlanta has finally been discovered at the bottom of Lake Superior.

## Watch Amanpour's full interview with Serena Williams
 - [https://www.cnn.com/videos/sports/2022/03/04/amanpour-serena-williams-tennis-venture-king-richard.cnn](https://www.cnn.com/videos/sports/2022/03/04/amanpour-serena-williams-tennis-venture-king-richard.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 22:12:25+00:00

The woman who changed the face of tennis sits down with Christiane Amanpour to talk chasing the record, changing the narrative around her father and navigating racism and sexism

## Ship 'still beautiful' after 130 years at the bottom of Lake Superior
 - [https://www.cnn.com/videos/travel/2022/03/04/shipwreck-atlanta-found-lake-superior-orig-llr.cnn](https://www.cnn.com/videos/travel/2022/03/04/shipwreck-atlanta-found-lake-superior-orig-llr.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 21:33:04+00:00

A 130-year-old shipwreck has been discovered 650-feet below the surface of Lake Superior.

## These Covid-19 symptoms raise new questions
 - [https://www.cnn.com/2022/03/04/opinions/covid-19-cardiovascular-symptoms-sepkowitz/index.html](https://www.cnn.com/2022/03/04/opinions/covid-19-cardiovascular-symptoms-sepkowitz/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 20:47:40+00:00

Two years ago, the calamitous first wave of the Covid-19 pandemic hit the US with unprecedented intensity. The depth of the terror can be difficult to recall and, thanks to advances in diagnosis, treatment and vaccination, is unlikely to recur.  For scientists, however, it is crucial to revisit the dark time and rethink what happened by examining the almost endless data that was collected to try to better understand both the immediate and the long-term effects this disease has on the body.

## This Toyota just sold for $2.5 million
 - [https://www.cnn.com/2022/03/04/business/toyota-shelby-2000gt/index.html](https://www.cnn.com/2022/03/04/business/toyota-shelby-2000gt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 20:39:26+00:00

A Toyota sold at a Florida collector car auction Friday for $2.5 million. As you might guess, this was not your standard Rav4 Hybrid. (Yes, car prices have gone up a lot, but not that much.)

## An invasive species named an ethnic slur finally has a new name
 - [https://www.cnn.com/2022/03/04/world/gypsy-moth-spongy-moth-name-change-scn/index.html](https://www.cnn.com/2022/03/04/world/gypsy-moth-spongy-moth-name-change-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 20:19:48+00:00

After months of a renaming process for an invasive moth species, the Entomological Society of America has decided -- "spongy moth" is the new common name replacing the offensive "gypsy moth."

## Supreme Court upholds death sentence of Boston Marathon bomber Dzhokhar Tsarnaev
 - [https://www.cnn.com/2022/03/04/politics/tsarnaev-supreme-court/index.html](https://www.cnn.com/2022/03/04/politics/tsarnaev-supreme-court/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 19:54:42+00:00

The Supreme Court on Friday upheld the death sentence of Dzhokhar Tsarnaev, one of the two brothers responsible for the 2013 Boston Marathon bombing which led to the deaths of three spectators and a police officer, reversing a lower court decision.

## Russia says it's blocking access to Facebook
 - [https://www.cnn.com/2022/03/04/tech/russia-blocks-facebook/index.html](https://www.cnn.com/2022/03/04/tech/russia-blocks-facebook/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 19:30:45+00:00

Russia is blocking Facebook in the country, according to its communications regulator.

## How dangerous was Russia's attack at the Zaporizhzhia nuclear power plant?
 - [https://www.cnn.com/2022/03/04/europe/ukraine-zaporizhzhia-nuclear-plant-attack-explainer-intl/index.html](https://www.cnn.com/2022/03/04/europe/ukraine-zaporizhzhia-nuclear-plant-attack-explainer-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 18:33:36+00:00

Russian troops have occupied Europe's largest nuclear power plant, after fierce fighting near the Ukrainian facility that drew international condemnation and sparked fears of a potential nuclear incident.

## Russia condemned for 'reckless' attack on Ukraine's largest nuclear power plant
 - [https://www.cnn.com/2022/03/03/europe/zaporizhzhia-nuclear-power-plant-fire-ukraine-intl-hnk/index.html](https://www.cnn.com/2022/03/03/europe/zaporizhzhia-nuclear-power-plant-fire-ukraine-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 18:22:36+00:00

A fire that threatened potential disaster at Ukraine's largest nuclear power plant following an attack by Russian troops has been extinguished, authorities said early Friday morning.

## Zelensky's acting career prepared him for the world stage
 - [https://www.cnn.com/2022/03/04/entertainment/volodymyr-zelensky-acting-career/index.html](https://www.cnn.com/2022/03/04/entertainment/volodymyr-zelensky-acting-career/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 17:44:28+00:00

It makes sense that Hollywood has rallied around Ukrainian President Volodymyr Zelensky.

## Fantasy author's surprise new book series sets Kickstarter record
 - [https://www.cnn.com/2022/03/04/media/kickstarter-brandon-sanderson-books/index.html](https://www.cnn.com/2022/03/04/media/kickstarter-brandon-sanderson-books/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 17:10:03+00:00

Brandon Sanderson, the prolific fantasy author, broke the record for the most-funded Kickstarter recipient by bringing in more than $20.3 million on the platform since March 1.

## 'It is not just Ukraine we are protecting.' The foreigners and expats taking up arms to fight Russia
 - [https://www.cnn.com/2022/03/04/europe/ukraine-foreign-fighters-russia-intl-cmd/index.html](https://www.cnn.com/2022/03/04/europe/ukraine-foreign-fighters-russia-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 16:49:44+00:00

The gray asphalt road that leads to Ukraine's Shehyni border crossing with Poland has for the past week seen 30-mile tailbacks as people try to flee the country, often saying tearful goodbyes to the family members and friends staying behind to fight the Russian invasion.

## Just one drink per day can shrink your brain, study says
 - [https://www.cnn.com/2022/03/04/health/alcohol-brain-shrinkage-wellness/index.html](https://www.cnn.com/2022/03/04/health/alcohol-brain-shrinkage-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 16:45:59+00:00

Just one pint of beer or average glass of wine a day may begin to shrink the overall volume of the brain, a new study has found, and the damage worsens as the number of daily drinks rises.

## CNN's Berman asks NATO chief: How can you be sure Putin won't attack a NATO nation?
 - [https://www.cnn.com/videos/world/2022/03/04/nato-secretary-general-jens-stoltenberg-interview-newday-berman-vpx.cnn](https://www.cnn.com/videos/world/2022/03/04/nato-secretary-general-jens-stoltenberg-interview-newday-berman-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 16:30:42+00:00

NATO Secretary General Jens Stoltenberg discusses the alliance's current position in the Ukraine crisis following the latest round of Russian attacks targeting civilians and a nuclear power plant.

## 'I know the truth': CNN asks Russians what they think about Putin's war
 - [https://www.cnn.com/videos/media/2022/03/04/russia-media-ukraine-war-troops-humanitarian-aid-robertson-dnt-vpx.cnn](https://www.cnn.com/videos/media/2022/03/04/russia-media-ukraine-war-troops-humanitarian-aid-robertson-dnt-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 16:14:44+00:00

CNN's Nic Robertson reports that Russian state media is not showing the death and destruction from the war with Ukraine and is instead showing Russian soldiers handing out humanitarian aid to Ukranians.

## Disney+ is adding a cheaper subscription tier
 - [https://www.cnn.com/2022/03/04/media/disney-ads-service/index.html](https://www.cnn.com/2022/03/04/media/disney-ads-service/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 16:02:00+00:00

Disney+ is creating an ad-supported tier for its streaming service to ramp up its growing subscriber base.

## Cricket icon Shane Warne dies aged 52
 - [https://www.cnn.com/2022/03/04/sport/shane-warne-death-spt-intl/index.html](https://www.cnn.com/2022/03/04/sport/shane-warne-death-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 15:56:24+00:00

Australian cricketer Shane Warne, considered one of the greatest players in history of the sport, has died at the age of 52, his management company confirmed to CNN on Friday.

## Russia's second biggest oil company calls for an end to Putin's war
 - [https://www.cnn.com/collections/intl-biz-ukraine-040322/](https://www.cnn.com/collections/intl-biz-ukraine-040322/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 15:44:26+00:00



## Mila Kunis and Ashton Kutcher vow to match $3 million in donations for Ukrainian refugees
 - [https://www.cnn.com/2022/03/04/entertainment/mila-kunis-ashton-kutcher-ukraine-intl-scli/index.html](https://www.cnn.com/2022/03/04/entertainment/mila-kunis-ashton-kutcher-ukraine-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 15:08:30+00:00

"Proud Ukrainian" Mila Kunis and her husband, Ashton Kutcher, have pledged to match up to $3 million in donations to help refugees fleeing her native country amid the conflict with Russia.

## Colin Farrell has a big weekend
 - [https://www.cnn.com/2022/03/04/entertainment/colin-farrell-movies-comeback/index.html](https://www.cnn.com/2022/03/04/entertainment/colin-farrell-movies-comeback/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 14:56:31+00:00

Colin Farrell is back in a big way. He appears in two movies released on Friday, "The Batman" and "After Yang."

## Years ago, she told police she had been abducted, beaten and branded. Now she's charged with making it all up
 - [https://www.cnn.com/2022/03/04/us/california-woman-charged-false-report-missing/index.html](https://www.cnn.com/2022/03/04/us/california-woman-charged-false-report-missing/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 14:43:07+00:00

When she was found after a three-week search in 2016, a Northern California woman told police she had been abducted and branded by two women who kept her chained in a closet.

## Stonehenge was an ancient time-keeping system, archaeologist says
 - [https://www.cnn.com/style/article/stonehenge-calendar-study-scn/index.html](https://www.cnn.com/style/article/stonehenge-calendar-study-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 14:35:37+00:00

Astronomical alignments were built into the design and orientation of Stonehenge -- the imposing monument that dominates a flat plain in southwest England.

## How Mark Zuckerberg is trying to reduce his exposure to public scrutiny
 - [https://www.cnn.com/2022/03/04/tech/meta-facebook-mark-zuckerberg-nick-clegg/index.html](https://www.cnn.com/2022/03/04/tech/meta-facebook-mark-zuckerberg-nick-clegg/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 14:16:58+00:00

When Russia moved to "partially restrict" Facebook access in the country last week, drawing the social network deeper into an international conflict, it prompted a defiant response from the company's most visible representative on the world stage.

## What's next for the batsuit?
 - [https://www.cnn.com/style/article/the-batman-batsuit-design/index.html](https://www.cnn.com/style/article/the-batman-batsuit-design/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 13:48:36+00:00

When costume designer Glyn Dillon got a call asking if he'd be interested in working on Matt Reeves' newly-released movie "The Batman," the first thing he sketched was a pair of ears. "How big are the ears?" he remembered worrying about. "For some reason, it's a big deal with all the fans," he said over Zoom.

## Bar owners are swapping out Moscow Mules for Kyiv Mules
 - [https://www.cnn.com/2022/03/04/business/moscow-mule-kyiv-mule/index.html](https://www.cnn.com/2022/03/04/business/moscow-mule-kyiv-mule/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 13:41:36+00:00

As Russia's assault on Ukraine continues, American bar and restaurant owners are hoping a small word change will help show their solidarity with the Ukrainian people. In a move reminiscent of the "freedom fries" fad of the early aughts, they're taking Moscow Mules off the menu and replacing them with Kyiv Mules.

## Dozens killed in blast at Shia mosque in Pakistan's Peshawar
 - [https://www.cnn.com/2022/03/04/asia/pakistan-peshawar-blast-intl/index.html](https://www.cnn.com/2022/03/04/asia/pakistan-peshawar-blast-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 13:01:21+00:00

A blast struck a Shia mosque during Friday prayers in Pakistan's northwestern city of Peshawar, killing at least 30 people, police and hospital officials said.

## Long, stressful and exhausting: One family's escape from Kyiv
 - [https://www.cnn.com/2022/03/04/europe/kyiv-ukraine-family-flight-intl-cmd/index.html](https://www.cnn.com/2022/03/04/europe/kyiv-ukraine-family-flight-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 12:21:58+00:00

When the explosions rocked Kyiv's city center, Yana and Sergii Lysenko were stunned.

## I see my own struggles on screen in "Euphoria"
 - [https://www.cnn.com/2022/03/04/opinions/euphoria-addiction-grief-zendaya-depression-reese/index.html](https://www.cnn.com/2022/03/04/opinions/euphoria-addiction-grief-zendaya-depression-reese/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 12:08:55+00:00

Note: This op-ed contains mild spoilers for HBO's "Euphoria." HBO and CNN share a parent company.

## Man was filming video when military strike rained down
 - [https://www.cnn.com/videos/world/2022/03/04/blast-kharkiv-man-interrupted-sot-newday-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2022/03/04/blast-kharkiv-man-interrupted-sot-newday-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 12:05:01+00:00

A man's video was interrupted by an explosion when the area of the city council was hit by a military strike in Kharkiv, Ukraine, amid Russian bombardment of the city. The incident occurred on Wednesday, March 2nd.

## Ukraine request postponement of 2022 World Cup qualifier against Scotland
 - [https://www.cnn.com/2022/03/04/football/scotland-ukraine-world-cup-qualifier-spt-intl/index.html](https://www.cnn.com/2022/03/04/football/scotland-ukraine-world-cup-qualifier-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 11:44:54+00:00

Football's world governing body has confirmed it received a request from the Ukrainian FA to postpone its 2022 World Cup qualifier against Scotland.

## He was Russia's richest man. Hear what he has to say about Putin
 - [https://www.cnn.com/videos/business/2022/03/04/mikhail-khodorkovsky-putin-intv-dos-santos-ovn-intl-ldn-vpx.cnn](https://www.cnn.com/videos/business/2022/03/04/mikhail-khodorkovsky-putin-intv-dos-santos-ovn-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 10:26:36+00:00

CNN's Nina dos Santos speaks with Mikhail Khodorkovsky, a former Russian oil tycoon and Kremlin critic who says Russian President Vladimir Putin is "the enemy of humankind."

## Carli Lloyd says she 'hated' the culture of USWNT before retiring
 - [https://www.cnn.com/2022/03/04/football/carli-lloyd-uswnt-culture-spt-intl/index.html](https://www.cnn.com/2022/03/04/football/carli-lloyd-uswnt-culture-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 10:07:40+00:00

Carli Lloyd, one of the most successful players in the history of the United States Women's National Team (USWNT), says she "hated" playing for the team in the final years before she retired last year.

## Sony and Honda are starting a new company to make electric vehicles
 - [https://www.cnn.com/2022/03/04/business/sony-honda-new-ev-company-intl-hnk/index.html](https://www.cnn.com/2022/03/04/business/sony-honda-new-ev-company-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 09:46:19+00:00

Two of Japan's biggest names in business are teaming up.

## Space junk set to crash into the far side of the moon
 - [https://www.cnn.com/2022/03/04/world/rocket-crash-into-moon-scn/index.html](https://www.cnn.com/2022/03/04/world/rocket-crash-into-moon-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 08:02:21+00:00

A rocket part that's been careering around space for years is set to collide with the moon on Friday, and it will be the first time a chunk of space junk has unintentionally slammed into the lunar surface.

## 'Concerned' Ukrainian locals help protect Lviv's historic statues
 - [https://www.cnn.com/style/article/lviv-ukraine-statues-wrapped-heritage-protection/index.html](https://www.cnn.com/style/article/lviv-ukraine-statues-wrapped-heritage-protection/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 07:56:47+00:00

Residents of the Ukrainian cultural capital Lviv are assisting efforts to safeguard historic monuments, according to local heritage officials, with several stone statues seen being wrapped in protective sheets.

## Zelensky warns of 'nuclear terror' after nuclear plant attack
 - [https://www.cnn.com/videos/world/2022/03/04/ukraine-zelensky-nuclear-plant-zaporizhzhia-sot-ovn-hnk-intl-vpx.cnn](https://www.cnn.com/videos/world/2022/03/04/ukraine-zelensky-nuclear-plant-zaporizhzhia-sot-ovn-hnk-intl-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 07:16:12+00:00

Ukrainian president Volodymyr Zelensky condemned Russia's attack on the Zaporizhzhia nuclear power plant in a Facebook message and warned of the dangers associated with attacks on nuclear facilities.

## Graphic video shows horrific aftermath of Russian strike north of Kyiv
 - [https://www.cnn.com/videos/world/2022/03/04/chernihiv-russian-strike-aftermath-ukraine-sotvo-intl-ovn-vpx.cnn](https://www.cnn.com/videos/world/2022/03/04/chernihiv-russian-strike-aftermath-ukraine-sotvo-intl-ovn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 05:59:02+00:00

Graphic new footage shows the aftermath of a Russian strike north of Kyiv. Officials say an apartment building in the city of Chernihiv was hit on March 3, leaving at least 33 people dead and 18 wounded.

## Heartbreaking visit to Ukraine's largest children's hospital
 - [https://www.cnn.com/videos/world/2022/03/03/ukraine-children-hospital-shelling-underground-lead-ward-pkg-vpx.cnn](https://www.cnn.com/videos/world/2022/03/03/ukraine-children-hospital-shelling-underground-lead-ward-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-04 03:03:45+00:00

CNN correspondent Clarissa Ward visits the largest children's hospital in Ukraine as they try to protect their sickest patients from the war underground.


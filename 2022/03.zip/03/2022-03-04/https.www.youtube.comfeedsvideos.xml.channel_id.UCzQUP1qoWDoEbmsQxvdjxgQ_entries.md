# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## How Michael Bisping Fought With One Eye
 - [https://www.youtube.com/watch?v=OsPdhUQ0snE](https://www.youtube.com/watch?v=OsPdhUQ0snE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-03-04 00:00:00+00:00

Taken from JRE MMA Show #119 w/Michael Bisping:
https://open.spotify.com/episode/3jXCqVzvOmIGYTi3pXY4rc?si=7809ac2a35f04e6a

## Is Conor McGregor Planning to Comeback and Fight for a Belt?
 - [https://www.youtube.com/watch?v=JSSttci1Wzo](https://www.youtube.com/watch?v=JSSttci1Wzo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-03-04 00:00:00+00:00

Taken from JRE MMA Show #119 w/Michael Bisping:
https://open.spotify.com/episode/3jXCqVzvOmIGYTi3pXY4rc?si=7809ac2a35f04e6a


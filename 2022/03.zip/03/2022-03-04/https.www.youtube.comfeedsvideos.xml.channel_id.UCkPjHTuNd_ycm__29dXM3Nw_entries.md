# Source:G F Darwin, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCkPjHTuNd_ycm__29dXM3Nw, language:en-US

## T. Pudełko Masterclass #1 - Od czego jest aktor? #short
 - [https://www.youtube.com/watch?v=Fe9r4WQwZ5o](https://www.youtube.com/watch?v=Fe9r4WQwZ5o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCkPjHTuNd_ycm__29dXM3Nw
 - date published: 2022-03-04 15:53:33+00:00

Zastanawiacie się, co teraz robi Tadeusz Pudełko? Gra! Przecież jest aktorem! Ale oprócz grania, opowiada o tym, jak to jest być aktorem. Zobaczcież!

Patronite: https://patronite.pl/darwin​ 
Facebook: http://www.facebook.com/GrupaFilmowaDarwin
Instagram: https://instagram.com/g.f.darwin
Książka: http://darwin.altenberg.pl​
Gadżety Darwina: http://gfdarwin.teetres.com
Mail: kontakt@gfdarwin.pl

#GrupaFilmowaDarwin #GFDarwin


# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## All Of Us Are Dead - Zombie Survival At Its Best
 - [https://www.youtube.com/watch?v=i0uGOvIgcas](https://www.youtube.com/watch?v=i0uGOvIgcas)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-03-05 00:00:00+00:00

All Of Us Are Dead follows in the happy tradition of excellent South Korean shows that are miles ahead of anything Hollywood is producing right now. So strap in and join me as I review this excellent zombie horror show.


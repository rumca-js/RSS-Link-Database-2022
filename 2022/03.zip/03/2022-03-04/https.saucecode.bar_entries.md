## using www-authenticate for user authentication
 - [https://saucecode.bar/posts/06-using-www-authenticate.html](https://saucecode.bar/posts/06-using-www-authenticate.html)
 - RSS feed: https://saucecode.bar
 - date published: 2022-03-04 16:35:04.826216+00:00

This article explains how to use the www-authenticate header to handle user authentication without any client side code.


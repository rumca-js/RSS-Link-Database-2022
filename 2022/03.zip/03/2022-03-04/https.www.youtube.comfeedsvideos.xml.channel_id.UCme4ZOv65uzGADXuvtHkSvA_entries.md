# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## 1 Księga Królewska || Rozdział 21
 - [https://www.youtube.com/watch?v=-axsem9sKKI](https://www.youtube.com/watch?v=-axsem9sKKI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-03-05 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#277] Szatańska wersja zbawienia
 - [https://www.youtube.com/watch?v=xx9LEj5FnzM](https://www.youtube.com/watch?v=xx9LEj5FnzM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-03-05 00:00:00+00:00

#cnn #dobrewiadomości    @Langustanapalmie 

Kazanko do okienka, czyli komentarz do niedzielnych czytań.

Niedziela, I Tydzień Wielkiego Postu, Rok C, II
Pierwsza Niedziela Wielkiego Postu

1. czytanie (Pwt 26, 4-10)

Mojżesz powiedział do ludu:
«Kapłan weźmie koszyk z twoich rąk i położy go przed ołtarzem Pana, Boga twego. A ty wówczas wypowiesz te słowa wobec Pana, Boga swego:
„Ojciec mój, tułacz Aramejczyk, zstąpił do Egiptu, przybył tam w niewielkiej liczbie ludzi i tam się rozrósł w naród ogromny, silny i liczny. Egipcjanie źle się z nami obchodzili, gnębili nas i nałożyli na nas ciężkie roboty przymusowe. Wtedy wołaliśmy do Pana, Boga ojców naszych. Pan usłyszał nasze wołanie, wejrzał na naszą nędzę, nasz trud i nasze uciemiężenie. Wyprowadził nas Pan z Egiptu mocną ręką i wyciągniętym ramieniem wśród wielkiej grozy, znaków i cudów. Przyprowadził nas na to miejsce i dał nam ten kraj opływający w mleko i miód.
Teraz oto przyniosłem pierwociny płodów ziemi, którą dałeś mi, Panie”.
Rozłożysz je przed Panem, Bogiem swoim. Oddasz pokłon Panu, Bogu swemu».

2. czytanie (Rz 10, 8-13)

Bracia:
Cóż mówi Pismo? «Słowo to jest blisko ciebie, na twoich ustach i w sercu twoim». A jest to słowo wiary, którą głosimy. Jeżeli więc ustami swoimi wyznasz, że Jezus jest Panem, i w sercu swoim uwierzysz, że Bóg Go wskrzesił z martwych – osiągniesz zbawienie. Bo sercem przyjęta wiara prowadzi do sprawiedliwości, a wyznawanie jej ustami – do zbawienia. Wszak mówi Pismo: «Żaden, kto wierzy w Niego, nie będzie zawstydzony».
Nie ma już różnicy między Żydem a Grekiem. Jeden jest bowiem Pan wszystkich. On to rozdziela swe bogactwa wszystkim, którzy Go wzywają. Albowiem «każdy, kto wezwie imienia Pańskiego, będzie zbawiony».

Ewangelia (Łk 4, 1-13)

Pełen Ducha Świętego, powrócił Jezus znad Jordanu, a wiedziony był przez Ducha na pustyni czterdzieści dni, i był kuszony przez diabła. Nic przez owe dni nie jadł, a po ich upływie poczuł głód. Rzekł Mu wtedy diabeł: «Jeśli jesteś Synem Bożym, powiedz temu kamieniowi, żeby stał się chlebem».
Odpowiedział mu Jezus: «Napisane jest: „Nie samym chlebem żyje człowiek”».
Wówczas powiódł Go diabeł w górę, pokazał Mu w jednej chwili wszystkie królestwa świata i rzekł do Niego: «Tobie dam potęgę i wspaniałość tego wszystkiego, bo mnie są poddane i mogę je dać, komu zechcę. Jeśli więc upadniesz i oddasz mi pokłon, wszystko będzie Twoje».
Lecz Jezus mu odrzekł: «Napisane jest: „Panu, Bogu swemu, będziesz oddawał pokłon i Jemu samemu służyć będziesz”».
Zawiódł Go też do Jerozolimy, postawił na szczycie narożnika świątyni i rzekł do Niego: «Jeśli jesteś Synem Bożym, rzuć się stąd w dół. Jest bowiem napisane: „Aniołom swoim da rozkaz co do ciebie, żeby cię strzegli, i na rękach nosić cię będą, byś przypadkiem nie uraził swej nogi o kamień”».
Lecz Jezus mu odparł: «Powiedziano: „Nie będziesz wystawiał na próbę Pana, Boga swego”».
Gdy diabeł dopełnił całego kuszenia, odstąpił od Niego do czasu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

Niedzielnik na ROK C
→ https://wdrodze.pl/produkt/niedzielnik-c-komentarze-do-czytan-adam-szustak/

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#1035] Okruchy
 - [https://www.youtube.com/watch?v=8Xgna041X9E](https://www.youtube.com/watch?v=8Xgna041X9E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-03-05 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
Strona zbiórki → https://charytatywnie.fundacjamalak.pl/

Tradycyjne przelewy:
Nr konta do wpłat w PLN: 42 2490 0005 0000 4600 1184 3564 
IBAN: PL 42 2490 0005 0000 4600 1184 3564
Tytułem: UKRAINA

Fundacja MALAK
ul. Śliwkowa 4
31-982 Kraków
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## 1 Księga Królewska || Rozdział 20
 - [https://www.youtube.com/watch?v=uBUQSS1AAE0](https://www.youtube.com/watch?v=uBUQSS1AAE0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-03-04 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Listy z Ukrainy [#07] Bombowe urodziny
 - [https://www.youtube.com/watch?v=tf14FaYyuJQ](https://www.youtube.com/watch?v=tf14FaYyuJQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-03-04 00:00:00+00:00

#Ukraina @Langustanapalmie 

Strona zbiórki: https://charytatywnie.fundacjamalak.pl/
tradycyjne przelewy:
NR KONTA DO WPŁAT W 
PLN: 42 2490 0005 0000 4600 1184 3564 
IBAN: PL 42 2490 0005 0000 4600 1184 3564
TYTUŁEM: UKRAINA
Fundacja MALAK
ul. Śliwkowa 4
31-982 Kraków

------------------------------------------------------------
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#1034] Boleść
 - [https://www.youtube.com/watch?v=GfdAU3Fn1WE](https://www.youtube.com/watch?v=GfdAU3Fn1WE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-03-04 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
Strona zbiórki → https://charytatywnie.fundacjamalak.pl/

Tradycyjne przelewy:
Nr konta do wpłat w PLN: 42 2490 0005 0000 4600 1184 3564 
IBAN: PL 42 2490 0005 0000 4600 1184 3564
Tytułem: UKRAINA

Fundacja MALAK
ul. Śliwkowa 4
31-982 Kraków
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.


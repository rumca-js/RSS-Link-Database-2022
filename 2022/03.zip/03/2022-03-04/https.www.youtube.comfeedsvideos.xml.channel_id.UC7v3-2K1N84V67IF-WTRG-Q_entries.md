# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Batman - SPOILER Talk!
 - [https://www.youtube.com/watch?v=NwyeQSs9ss4](https://www.youtube.com/watch?v=NwyeQSs9ss4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-03-04 00:00:00+00:00

Get the exclusive NordVPN deal here: https://nordvpn.com/jahns. It’s risk free with Nord’s 30 day money-back guarantee!
Thanks to NordVPN for sponsoring this video.

Now that THE BATMAN is out, let's talk about the more spoiler-ish elements of this movie!

#TheBatman


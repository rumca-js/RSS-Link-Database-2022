# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Man City's Zinchenko on 'mission' to reveal truth
 - [https://www.bbc.co.uk/sport/football/60623061?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60623061?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 22:21:09+00:00

Oleksandr Zinchenko thanks the world for standing with Ukraine in an emotional interview with BBC Sport.

## Oleksandr Zinchenko: Ukraine & Man City defender talks about war in his homeland
 - [https://www.bbc.co.uk/sport/av/football/60627422?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/60627422?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 22:01:54+00:00

Manchester City defender Oleksandr Zinchenko tells Gary Lineker he cannot count the number of times he has cried in the past week after Russia invaded his homeland Ukraine.

## Cummins, Root & Strauss lead tributes to 'greatest showman' Warne
 - [https://www.bbc.co.uk/sport/cricket/60626656?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/60626656?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 20:52:16+00:00

Australia Test captain Pat Cummins calls Shane Warne a "once-in-a-century cricketer" as he leads tributes to the iconic leg-spinner who died on Friday aged 52.

## Ukraine war: UK's DEC charity appeal raises £55m in a day
 - [https://www.bbc.co.uk/news/uk-60623162?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60623162?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 20:40:45+00:00

The Queen and Prince of Wales are among those to donate to the appeal to help Ukrainian refugees.

## Ukraine conflict: Your guide to understanding day nine
 - [https://www.bbc.co.uk/news/world-europe-60622478?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60622478?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 20:28:53+00:00

Europe’s largest nuclear plant seized. Here's what you need to know after day nine of the war.

## 'Adulation and scandal' - Shane Warne obituary
 - [https://www.bbc.co.uk/sport/cricket/60624556?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/60624556?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 19:33:12+00:00

Why Shane Warne was one of cricket's greatest ever players, and also one of its most colourful characters.

## Nuclear plant: How close was nuclear plant attack to catastrophe?
 - [https://www.bbc.co.uk/news/world-60609633?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-60609633?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 19:32:49+00:00

After Russia seizes two nuclear plant sites, experts weigh the risk to Ukraine and the world at large.

## Shane Warne obituary: 'A man who made the cricket world spin'
 - [https://www.bbc.co.uk/sport/av/cricket/60626998?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/60626998?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 19:31:56+00:00

BBC Sport pays tribute to legendary Australia leg-spinner Shane Warne, one of the greatest cricketers of all time, who has died of a suspected heart attack aged 52.

## Ukraine war: 'My city's being shelled, but mum won’t believe me'
 - [https://www.bbc.co.uk/news/world-europe-60600487?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60600487?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 18:32:49+00:00

These Ukrainians say their Russian relatives only trust the narratives they see on TV at home.

## War in Ukraine: Russians on boycotts, sanctions and cancellations
 - [https://www.bbc.co.uk/news/world-europe-60585720?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60585720?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 18:17:55+00:00

Russia is being hit by a global backlash after it invaded Ukraine. How does it feel to be shunned?

## Why doesn't Ukraine attack the Russian convoy? And other questions
 - [https://www.bbc.co.uk/news/world-60617145?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-60617145?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 18:04:14+00:00

Correspondents and experts answer questions from readers on the BBC News website

## Why Tears For Fears' new album took seven years to make
 - [https://www.bbc.co.uk/news/entertainment-arts-60601910?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60601910?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 17:42:04+00:00

The band say there were several "false dawns" on the road to making The Tipping Point.

## Ukraine war: 'Russian soldiers killed my family while they fled'
 - [https://www.bbc.co.uk/news/world-europe-60578293?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60578293?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 17:30:07+00:00

The Fedko family was trying to flee fighting when Russian troops allegedly opened fire on their car.

## Ukraine crisis: Kharkiv residents still sheltering underground a week on
 - [https://www.bbc.co.uk/news/world-europe-60625400?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60625400?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 17:14:56+00:00

The BBC's Sarah Rainsford reports from a metro station where people have been sheltering from attacks.

## Roberto Carlos: Brazil World Cup legend makes losing appearance for Shropshire pub team
 - [https://www.bbc.co.uk/sport/football/60619414?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60619414?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 17:11:55+00:00

Brazil World Cup legend Roberto Carlos makes a guest appearance for a Shropshire pub team - and ends up on the losing side.

## War in Ukraine: Families run for cover as Russian air strikes hit Chernihiv
 - [https://www.bbc.co.uk/news/world-europe-60616946?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60616946?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 14:24:24+00:00

Residents of Chernihiv and other cities say apartments, hospitals and schools are being destroyed.

## Ukraine war: Why Kherson and Mariupol are key to Russian success
 - [https://www.bbc.co.uk/news/world-europe-60604876?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60604876?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 12:54:25+00:00

There are both strategic and historical reasons why the offensive in southern Ukraine is vital for Russia.

## Kyrell Matthews: The boy killed by his mum and her partner
 - [https://www.bbc.co.uk/news/uk-england-london-60584034?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-60584034?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 12:05:36+00:00

Harrowing secret recordings of Kyrell Matthews being hit and kicked were played to jurors.

## WATCH: 3D model shows extent of Russian military convoy
 - [https://www.bbc.co.uk/news/world-europe-60615754?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60615754?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 10:42:30+00:00

Sections of the 40-mile convoy are modelled in 3D using satellite imagery, showing its scale from above.

## Europe's largest nuclear plant shelled in Ukraine
 - [https://www.bbc.co.uk/news/world-60613863?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-60613863?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 05:01:24+00:00

Security camera footage from the Zaporizhzhia nuclear plant appears to show a fire at the facility.

## Birmingham: Labour holds seat in Erdington by-election
 - [https://www.bbc.co.uk/news/uk-england-birmingham-60613453?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-60613453?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 03:09:37+00:00

Paulette Hamilton is Birmingham's first black MP in an election held after the death of Jack Dromey.

## Ukraine: Liz Truss to call on international community to step up support
 - [https://www.bbc.co.uk/news/uk-60611616?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60611616?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 01:37:05+00:00

The foreign secretary says she will work with counterparts to "tighten the vice around Putin's war machine".

## Son of accused 6 January rioters testifies in court
 - [https://www.bbc.co.uk/news/world-us-canada-60608759?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60608759?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 01:30:11+00:00

“If you turn me in, you’re a traitor and traitors get shot,” Guy Reffitt is alleged to have told his son.

## Ukraine crisis: How much trade does Russia do with China?
 - [https://www.bbc.co.uk/news/60571253?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/60571253?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 01:27:47+00:00

The two countries have a growing economic partnership, but sanctions on Russia could complicate it.

## Mental health in Runcorn: 'We're just two lads who want to help'
 - [https://www.bbc.co.uk/news/newsbeat-60339952?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-60339952?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 00:39:17+00:00

Keelan and Paul set up a coffee club in memory of their friend Curt, who died after taking drugs.

## Winter Paralympics: The lowdown on being disabled in China
 - [https://www.bbc.co.uk/news/disability-60539739?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/disability-60539739?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 00:37:50+00:00

From an outrageous poet to an "atmosphere of fear", get the lowdown on disabled life in China.

## Moon crash: Discarded rocket part to hit Moon in hours, say scientists
 - [https://www.bbc.co.uk/news/science-environment-60596449?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-60596449?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 00:23:01+00:00

The space junk has confused experts but is soon to crash at high speed leaving a crater on the Moon.

## Ukraine: The race to save the country's artistic treasures
 - [https://www.bbc.co.uk/news/entertainment-arts-60603406?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60603406?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 00:20:11+00:00

As the Russian invasion continues, efforts to protect Ukraine's cultural heritage are stepped up.

## Rufford Lane ford: Millions watch cars get stuck in deep water
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-60575504?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-60575504?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 00:08:44+00:00

Videos of cars getting stuck in a Nottinghamshire ford are watched by millions around the world.

## Ukraine: On board a Nato spy plane monitoring Russian activity
 - [https://www.bbc.co.uk/news/world-europe-60612255?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60612255?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 00:08:33+00:00

The BBC has been given rare access to a surveillance flight on the Polish border with Ukraine and Belarus.

## The shipping giant banking on a greener fuel
 - [https://www.bbc.co.uk/news/business-60433204?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60433204?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 00:04:28+00:00

Maersk has ordered 12 huge ships that run on methanol rather than marine oil fuel.

## The manager who beat Real Madrid 'not afraid' as he leaves Europa League side to fight in Ukraine
 - [https://www.bbc.co.uk/sport/football/60601469?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60601469?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 00:03:31+00:00

Six months ago Yuriy Vernydub was winning at Real Madrid, one week ago he was managing in the Europa League. Now, he is in Ukraine and ready to fight.

## World Bank warns Ukraine war will cut global growth
 - [https://www.bbc.co.uk/news/business-60610537?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60610537?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 00:01:02+00:00

The president of the World Bank tells the BBC the war in Ukraine is a catastrophe

## FA Cup highlights: Boreham Wood's FA Cup adventure ended by Everton
 - [https://www.bbc.co.uk/sport/av/football/60613028?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/60613028?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-04 00:00:43+00:00

Watch match highlights as National League Boreham Wood's incredible FA Cup journey comes to an end but not without forcing Premier League Everton to dig deep for their narrow 2-0 fifth-round victory.


# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Obi-Wan Kenobi - Teaser Trailer (My Thoughts)
 - [https://www.youtube.com/watch?v=8zQwdIbzpvs](https://www.youtube.com/watch?v=8zQwdIbzpvs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-03-10 00:00:00+00:00

A 6 minute video of me talking about a minute and a half teaser trailer. But we have a teaser trailer for the upcoming OBI-WAN KENOBI trailer, so here are my thoughts on it!

#obiwankenobi #kenobi 

Watch the trailer here: https://www.youtube.com/watch?v=TWTfhyvzTx0&ab_channel=StarWars


# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Will Wight's Sanderson Parody📚 Forspoken Hits Different💞 Secret Project #2👀 -FANTASY NEWS
 - [https://www.youtube.com/watch?v=kKOQRZ84IiM](https://www.youtube.com/watch?v=kKOQRZ84IiM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-03-11 00:00:00+00:00

Let's jump into the fantasy news! 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

00:00 Intro 

00:31 Martin’s Update: https://georgerrmartin.com/notablog/2022/03/09/random-updates-and-bits-o-news/ 

01:16 Will Wight Kickstarter: https://www.kickstarter.com/projects/author-will-wight/fantasy-novels-cradle-1-3-by-will-wight/description 

01:42 khōréō: https://www.indiegogo.com/projects/khoreo-volume-2#/discussion 

02:09 Forspoken: https://www.youtube.com/watch?v=c7mxS5WEvzk&ab_channel=GameSpot 

03:41 One Piece Card Game: https://twitter.com/ONEPIECE_tcg_EN/status/1500652454630748163 

04:10 One Piece Casting Update: https://twitter.com/NetflixGeeked/status/1501321035299307522?t=4LS6ZDa95JNIsXgbar_rbA&s=19 

04:55 Star Trek Strange New worlds: https://www.youtube.com/watch?v=nxuyzk5DUFc&ab_channel=ParamountPlus 

05:24 Obi-Wan TV Show: https://www.youtube.com/watch?v=TWTfhyvzTx0&ab_channel=StarWars 

05:58 Stephen Spielberg involved in Halo?: https://www.indiewire.com/2022/03/halo-series-steven-spielberg-heavily-involved-1234705026/ 

07:06 Sanderson Secret Project 2 reveal: https://www.youtube.com/watch?v=9kLr1aNQTfQ&ab_channel=BrandonSanderson 

07:39 Mufasa Origin story: https://screenrant.com/lion-king-prequel-movie-mufasa-origin-story-details/

## Stormlight Special Edition Review (KRAKEN)
 - [https://www.youtube.com/watch?v=MWhD2yC79Kc](https://www.youtube.com/watch?v=MWhD2yC79Kc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-03-10 00:00:00+00:00

Check out the jackets here: https://krakenbook.com/
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231


# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## So This Is What They’ve Been Hiding
 - [https://www.youtube.com/watch?v=JCr7zkPAm1Y](https://www.youtube.com/watch?v=JCr7zkPAm1Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-03-11 00:00:00+00:00

Claims that Ukraine has biological weapons labs have been labelled as conspiracy theory. But with a high-ranking diplomat confirming this week that Ukraine has biological research facilities, does this further raise the need for transparency around this complex war? 
#Ukraine #Biolabs #Russia 

References
https://greenwald.substack.com/p/victoria-nuland-ukraine-has-biological?s=r

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## "They Planned It All Along"
 - [https://www.youtube.com/watch?v=leFyK7JDDjU](https://www.youtube.com/watch?v=leFyK7JDDjU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-03-10 00:00:00+00:00

Did you know that the WEF were talking about digital IDs back in 2016, 4 years before the pandemic?! Nick Corbishley, author of 'Scanned: Why Vaccine Passports and Digital IDs Will Mean The End of Privacy and Personal Freedom' tells us more...

Nick's New Book: Scanned - https://www.chelseagreen.com/product/scanned/
Article: https://medium.com/id2020/immunization-an-entry-point-for-digital-identity-ea37d9c3b77e

References 
https://medium.com/id2020/immunization-an-entry-point-for-digital-identity-ea37d9c3b77e

To listen to the full #UnderTheSkin episode, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

#VaccinePassports #Vaccine #DigitalIDs #Pandemic 

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Hunter Biden Paid By Ukrainian Energy Company?!
 - [https://www.youtube.com/watch?v=I0MvRbPc4e8](https://www.youtube.com/watch?v=I0MvRbPc4e8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-03-10 00:00:00+00:00

Events in Ukraine have seen interest resurface in the business dealings of the president’s son with Ukraine, Russia and China. Is this yet another past “conspiracy theory” that can no longer be dismissed? 
#Ukraine #HunterBiden #Russia 

References
https://www.theguardian.com/us-news/2022/feb/27/hunter-biden-joe-biden-president-business-dealings

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


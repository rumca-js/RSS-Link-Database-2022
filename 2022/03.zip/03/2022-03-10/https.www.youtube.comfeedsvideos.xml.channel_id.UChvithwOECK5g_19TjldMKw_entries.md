# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## China's Embarrassing Flip Flop on Russia
 - [https://www.youtube.com/watch?v=XZ8DfvbroeA](https://www.youtube.com/watch?v=XZ8DfvbroeA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2022-03-10 00:00:00+00:00

China has officially stated that it hasn't taken a side in the invasion of Ukraine by Russia. It started with full support of Russia, and then blamed it on the US/West, followed by now, a barrage of propaganda saying that China chooses peace, and will end up being the savior of the world by mediating between Russia and Ukraine. 

◘ Support me on Patreon to talk to me directly and support my work - http://www.patreon.com/laowhy86
◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

Crypto support 
◘ Bitcoin - bc1qrvvga0c4kn69rlte47q0tzrhugn9pf426tqhvm
◘ ETH -  0x456E5A9B875d4eF8DCb70eB1F7Fa376C520b206C

My documentaries - 
◘ Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina
◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

ADVChina - https://www.youtube.com/advchina
SerpentZA - https://www.youtube.com/serpentza
ADVPodcasts - https://www.youtube.com/advpodcasts

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

Music -
Big Bad Beats
https://www.youtube.com/c/bigbadbeats


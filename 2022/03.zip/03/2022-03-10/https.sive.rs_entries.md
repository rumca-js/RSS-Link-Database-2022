## The day Steve Jobs dissed me in a keynote | Derek Sivers
 - [https://sive.rs/itunes](https://sive.rs/itunes)
 - RSS feed: https://sive.rs
 - date published: 2022-03-10 06:54:22.261578+00:00

In May 2003, Apple invited me to their headquarters to discuss getting CD Baby’s catalog into the iTunes Music Store.


# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Breath of the Wild 2: release date, trailers and gameplay for Tears of the Kingdom
 - [https://www.techradar.com/news/breath-of-the-wild-2/](https://www.techradar.com/news/breath-of-the-wild-2/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-03-10 12:30:03+00:00

Breath of the Wild 2 now has an official title. It's called The Legend of Zelda Tears of the Kingdom. Here's what we know.

## Breath of the Wild 2: release date, trailers and gameplay for Tears of the Kingdom
 - [https://www.techradar.com/news/breath-of-the-wild-2](https://www.techradar.com/news/breath-of-the-wild-2)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-03-10 12:30:03+00:00

Breath of the Wild 2 is officially called The Legend of Zelda Tears of the Kingdom. Here's what we know about the game so far.


# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## MIYAZAKI ADVICE TO ELDEN RING NOOBS, CAPCOM'S NEW DINOSAUR GAME, & MORE
 - [https://www.youtube.com/watch?v=6S7AyHAAyQI](https://www.youtube.com/watch?v=6S7AyHAAyQI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-03-11 00:00:00+00:00

Sponsored by Vessi. Click https://vessi.com/gameranx and use our code GAMERANX for $25 off each pair of adult Vessi shoes! Free shipping to CA, US, AUS, NZ, JP, TW, KR, SGP


A State of Play brings new PlayStation games, Steam Deck is already getting upgraded, game delays and release dates, and more in a week full of gaming news.

Gamers supporting Ukraine: 
https://itch.io/b/1316/bundle-for-ukraine

Jake on twitter: https://bit.ly/3gdkPqD​​​​

Instagram: https://bit.ly/3uUh9Ot


 ~~~~STORIES~~~~




MIYAZAKI ADVICE TO ELDEN RING NOOBS
https://gameranx.com/updates/id/292464/article/miyazaki-wants-elden-ring-newbies-to-relax-about-difficulty/ + https://gameranx.com/updates/id/291994/article/elden-ring-players-not-beating-first-boss/
+
https://www.gamesradar.com/elden-ring-will-influence-future-fromsoftware-projects-says-miyazaki/


State of Play
https://youtu.be/IeKlckhHlrc
https://blog.playstation.com/2022/03/08/state-of-play-returns-this-wednesday/

https://www.polygon.com/22969786/valkyrie-elysium-announcement-trailer-square-enix-ps5-ps4-pc

OG dying light updated
https://twitter.com/DyingLightGame/status/1501211217091776518

WWE 2k22
https://youtu.be/4Q79LDfe5w4

Elite Dangerous on consoles
https://www.polygon.com/22971016/elite-dangerous-console-development-canceled-xbox-playstation-new-content-pc-only

Steam Deck windows
https://www.theverge.com/2022/3/10/22971108/valve-steam-deck-windows-runs-drivers-no-support


great Deus Ex video
https://youtu.be/bgJazjz9ZsA

Awesome Batman in Sifu
https://youtu.be/ybhFYJ0Wvrw

Release updates:
Dead Space remake to 2023
https://venturebeat.com/2022/03/10/dead-space-devs-push-remake-release-target-out-of-2022/

Forsaken: (October 11th)
https://twitter.com/Forspoken/status/1500863854359846913

Gotham Knights (10. 25)
https://twitter.com/GothamKnights/status/1501558438681317380

Ukraine
https://itch.io/b/1316/bundle-for-ukraine

## Elden Ring: Top 10 Armor Sets You CAN'T Afford to Miss
 - [https://www.youtube.com/watch?v=ZIw7NDnqR1o](https://www.youtube.com/watch?v=ZIw7NDnqR1o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-03-10 00:00:00+00:00

Elden Ring (PC, PS5, PS4, Xbox Series X/S/One) is filled with cool armor sets to earn. Here are some you that you shouldn't miss checking out.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#EldenRing


# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Dancing in the Dark // Bruce Springsteen // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=YluWV20TT5Y](https://www.youtube.com/watch?v=YluWV20TT5Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2022-03-10 00:00:00+00:00

Bruce has swagger. I didn’t grow up listening to him, so I just recently saw the video of “Dancing in the Dark” where he pulls Courteney Cox on stage. I’m only a little ashamed of it. But whenever you get to experience that video, whatever stage of life you’re in…it’s a gift.

Speaking of GIFTS - wow, what a seamless segue - it’s time for us to GIVE the “Best of 2021” record to you. Sign up to become a patron and you get to vote what songs go on the record (we made a lot…) Then we’ll mail you the CD! Or a signed postcard, if you have no use for CDs. http://www.patreon.com/pomplamoose to get your “Best of 2021” CD and vote what songs go on it!

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic

MUSICIAN CREDITS
Lead Vocals: Nataly Dawn
Keys: Jack Conte
More Keys: Rai Thistlethwayte
Bass: Nick Campbell
Drums: Ben Rose
Background Vocals: Sarah Dugas

AUDIO CREDITS
Audio Engineer: Bill Mims
Assistant Engineer: Jack Corbett
Mixing/Mastering: Caleb Parker
Producer: Ben Rose

VIDEO CREDITS
Director: Dom Fera
Director of Photography: Christian Colwell
Camera 2: Christopher Li
Camera 3: Austin Hughes
Gaffer: Nash White
Production Designer: Katie Theel
Wardrobe: Alex Allen
Video Editor/Colorist: Athena Wheaton


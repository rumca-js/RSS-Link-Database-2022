# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Targeting Iron to Fight Cancer | SciShow News
 - [https://www.youtube.com/watch?v=5AvHHN4WQio](https://www.youtube.com/watch?v=5AvHHN4WQio)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-03-11 00:00:00+00:00

Head to https://gift.climeworks.com/SciShow to start removing CO₂ from the air today. 

Cancer treatment is hard on the whole body, but a promising treatment is looking to target cancer's appetite and leave the rest of our cells alone.

Hosted by: Hank Green

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Tomás Lagos González, Sam Lutfi. Bryan Cloer, Christoph Schwanke, Kevin Bealer, Jacob, Jason A Saslow, Nazara, Tom Mosner, Ash, Eric Jensen, Jeffrey Mckishen, Matt Curls, Alex Hackman, Christopher R Boucher, Piya Shedden, Jeremy Mysliwiec, charles george, Chris Peters, Adam Brainard, Dr. Melvin Sanicas, Harrison Mills, Silas Emrys, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow
----------
Sources:

IMAGES

https://commons.wikimedia.org/wiki/File:A_lady_fainting_after_bloodletting._Oil_painting_after_Eglon_Wellcome_V0017315.jpg
https://www.istockphoto.com/photo/flying-pill-tablet-capsule-levitation-medicine-medical-treatment-for-disease-flu-gm1311641109-400686027

https://www.istockphoto.com/photo/xray-of-a-human-torax-gm488525897-39278408
https://commons.wikimedia.org/wiki/File:Breast_cancer_cell_(2).jpg
https://commons.wikimedia.org/wiki/File:Pancreas_adenocarcinoma_(4)_Case_01.jpg
https://commons.wikimedia.org/wiki/File:Cancer_cells_(1).jpg
https://commons.wikimedia.org/wiki/File:KRAS_protein_3GFT.png
https://www.ucsf.edu/news/2022/03/422401/treating-tough-tumors-exploiting-their-iron-addiction
https://www.istockphoto.com/photo/mouse-gm801197972-129920353
https://visualsonline.cancer.gov/details.cfm?imageid=10540

## The Secret Behind Elephant Seals Migration
 - [https://www.youtube.com/watch?v=VEoU6-1Rqwc](https://www.youtube.com/watch?v=VEoU6-1Rqwc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-03-10 00:00:00+00:00

Stefan Chen tells us about how Elephant Seals travel using their own, built-in GPS.
Head to https://linode.com/scishow to get a $100 60-day credit on a new Linode account. Linode offers simple, affordable, and accessible Linux cloud solutions and services.

Elephant seals are among the only known animals on earth to migrate twice a year, but how they do it makes the already incredible feat even more astounding.

Hosted by: Stefan Chen

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Tomás Lagos González, Sam Lutfi. Bryan Cloer, Christoph Schwanke, Kevin Bealer, Jacob, Jason A Saslow, Nazara, Tom Mosner, Ash, Eric Jensen, Jeffrey Mckishen, Matt Curls, Alex Hackman, Christopher R Boucher, Piya Shedden, Jeremy Mysliwiec, charles george, Chris Peters, Adam Brainard, Dr. Melvin Sanicas, Harrison Mills, Silas Emrys, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow
----------
Sources:
https://onlinelibrary.wiley.com/doi/epdf/10.1111/mms.12896
https://www.sciencedirect.com/science/article/pii/B9780123735539000882
https://www.eurekalert.org/news-releases/943804
https://www.cell.com/current-biology/fulltext/S0960-9822(22)00042-2

Image Sources
https://www.storyblocks.com/video/stock/aerial-view-ducks-takeoff-ducks-ashore-migration-of-ducks-hcdndh7tzj6yhw2js
https://commons.wikimedia.org/wiki/File:Monarch-butterflies-pacific-grove.jpg
https://commons.wikimedia.org/wiki/File:Arctic_tern_8624.jpg
https://www.storyblocks.com/video/stock/rough-ocean-sea-with-big-waves-swells-during-stormy-weather-rukblzreip6bc60s
https://commons.wikimedia.org/wiki/File:Elephant_seals_at_Ano_Nuevo_(91592).jpg
https://www.istockphoto.com/photo/close-up-of-a-northern-elephant-seal-seen-in-the-wild-in-north-california-gm1344523090-422848531
https://www.storyblocks.com/video/stock/elephant-seals-sleeping-on-the-sand-b7t0i2ddliyep4oyj
https://commons.wikimedia.org/wiki/File:Three_Mirounga_angustirostris_pups_nursing.jpg
https://www.storyblocks.com/video/stock/elephant-seals-sleeping-throwing-sand-to-keep-cool-s-iaahddliyepf9b7
https://www.storyblocks.com/video/stock/elephant-seals-fighting-battle-tight-shot-throwing-sand-byyt_hwpxiyeonvoa
https://www.istockphoto.com/photo/earth-magnetic-fields-elements-of-this-image-furnished-by-nasa-gm1283913863-381208521
https://www.storyblocks.com/video/stock/night-sky-time-lapse-go-the-stars-moving-across-the-sky-including-shooting-stars-bafvvz2sdkieyhqjw
https://www.storyblocks.com/video/stock/monarch-butterfly-on-a-pink-flower-martinique-zoo-danaus-plexippus-r1a23wyfpkh27xktg
https://www.storyblocks.com/video/stock/pan-down-of-large-colony-of-elephant-seals-near-san-simeon-california-bpp0xzamioyqap0q


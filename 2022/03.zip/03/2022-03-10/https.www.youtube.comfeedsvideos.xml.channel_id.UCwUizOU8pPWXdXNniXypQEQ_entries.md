# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## If Fiat Believers Acted Like Bitcoin Enthusiasts!
 - [https://www.youtube.com/watch?v=vFKMsWD1bHc](https://www.youtube.com/watch?v=vFKMsWD1bHc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-03-11 00:00:00+00:00

Join Zion at https://getzion.com/jp

Check Out My Merch Here - https://awakenwithjp.com

See my LIVE Comedy Shows - https://awakenwithjp.com/pages/events

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Here's what it would be like if traditional fiat currency believers were to act like Bitcoin enthusiasts!

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com


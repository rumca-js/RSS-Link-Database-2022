# Source:Techaltar, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA, language:en-US

## Why Russia Can't Survive Tech Sanctions
 - [https://www.youtube.com/watch?v=SV_4M9R8Ggs](https://www.youtube.com/watch?v=SV_4M9R8Ggs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA
 - date published: 2022-03-10 10:25:17+00:00

Sponsored by Curiosity Stream. Sign up at https://curiositystream.com/techaltar and get access to Nebula for free with your subscription!

Once you have an account, here is the Bonus video: https://nebula.app/videos/techaltar-putins-cyberattacks-are-weak-for-now

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► This video ◄◄◄  

After Putin's attacks on Ukraine, the US White House, the EU and much of the rest of the world hit Russia with strong sanctions targeting their access to key technologies and the global financial system. From chip imports to SWIFT, the sanctions are hard and many companies also decided to pull out. Will they work?

The Story Behind - ep. 84

Bonus video (Nebula Plus): https://nebula.app/videos/techaltar-putins-cyberattacks-are-weak-for-now
Asianometry's video about Russian chip manufacturing: https://www.youtube.com/watch?v=N_4R4X7AWtU
This video on Nebula: https://nebula.app/videos/techaltar-sanctions-will-they-defeat-putin

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support TechAltar directly:  https://flattr.com/@techaltar   

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► Attributions ◄◄◄  

Music by Edemski: https://soundcloud.com/edemski


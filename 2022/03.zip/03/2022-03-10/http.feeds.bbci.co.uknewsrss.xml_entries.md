# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Watch: Our correspondent goes into no-man's land with the Ukrainian army
 - [https://www.bbc.co.uk/news/world-europe-60699588?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60699588?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-10 22:47:46+00:00

The BBC spent a week with Ukrainian forces in Kharkiv as they fight to stop a further Russian advance.

## Quiz of the week: Who helped Dolly write a novel?
 - [https://www.bbc.co.uk/news/world-60685025?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-60685025?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-10 17:35:44+00:00

How closely have you been paying attention to what's been going on during the past seven days?

## Timbuktu manuscripts: Mali's ancient documents captured online
 - [https://www.bbc.co.uk/news/world-africa-60689699?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-60689699?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-10 17:10:58+00:00

The thousands of manuscripts contain centuries of African writing on maths, medicine and more.

## WATCH: Disposal experts defuse unexploded bomb in Ukraine
 - [https://www.bbc.co.uk/news/world-europe-60689562?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60689562?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-10 09:12:48+00:00

An unexploded 500kg (1102lb) bomb was discovered in Chernihiv in northern Ukraine.


# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Parcels - Famous (Live on KEXP)
 - [https://www.youtube.com/watch?v=d7vnUgoUttc](https://www.youtube.com/watch?v=d7vnUgoUttc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-03-11 00:00:00+00:00

http://KEXP.ORG presents Parcels performing “Famous” live in the KEXP studio. Recorded February 23, 2022.

Jules Crommelin - Guitar / Vocals
Noah Hill - Bass / Vocals
Patrick Hetherington - Guitar / Keys / Vocals
Louie Swain - Keys / Vocals
Anatole Serret - Drums / Vocals

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering: Julian Martlew
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editors: Alaia D’Alessandro & Jim Beckmann

https://www.parcelsmusic.com/
http://kexp.org

## Parcels - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=UcTj3JBoGkE](https://www.youtube.com/watch?v=UcTj3JBoGkE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-03-11 00:00:00+00:00

http://KEXP.ORG presents Parcels performing live in the KEXP studio. Recorded February 23, 2022.

Songs:
Famous
LIGHT
Somethinggreater
Once

Jules Crommelin - Guitar / Vocals
Noah Hill - Bass / Vocals
Patrick Hetherington - Guitar / Keys / Vocals
Louie Swain - Keys / Vocals
Anatole Serret - Drums / Vocals

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering: Julian Martlew
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editors: Alaia D’Alessandro & Jim Beckmann

https://www.parcelsmusic.com/
http://kexp.org

## Parcels - LIGHT (Live on KEXP)
 - [https://www.youtube.com/watch?v=wOgybGMTyCA](https://www.youtube.com/watch?v=wOgybGMTyCA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-03-11 00:00:00+00:00

http://KEXP.ORG presents Parcels performing “LIGHT” live in the KEXP studio. Recorded February 23, 2022.

Jules Crommelin - Guitar / Vocals
Noah Hill - Bass / Vocals
Patrick Hetherington - Guitar / Keys / Vocals
Louie Swain - Keys / Vocals
Anatole Serret - Drums / Vocals

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering: Julian Martlew
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editors: Alaia D’Alessandro & Jim Beckmann

https://www.parcelsmusic.com/
http://kexp.org

## Parcels - Once (Live on KEXP)
 - [https://www.youtube.com/watch?v=_AgWRZkPX_0](https://www.youtube.com/watch?v=_AgWRZkPX_0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-03-11 00:00:00+00:00

http://KEXP.ORG presents Parcels performing “Once” live in the KEXP studio. Recorded February 23, 2022.

Jules Crommelin - Guitar / Vocals
Noah Hill - Bass / Vocals
Patrick Hetherington - Guitar / Keys / Vocals
Louie Swain - Keys / Vocals
Anatole Serret - Drums / Vocals

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering: Julian Martlew
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editors: Alaia D’Alessandro & Jim Beckmann

https://www.parcelsmusic.com/
http://kexp.org

## Parcels - Somethinggreater (Live on KEXP)
 - [https://www.youtube.com/watch?v=tWlA-gsb_GE](https://www.youtube.com/watch?v=tWlA-gsb_GE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-03-11 00:00:00+00:00

http://KEXP.ORG presents Parcels performing “Somethinggreater” live in the KEXP studio. Recorded February 23, 2022.

Jules Crommelin - Guitar / Vocals
Noah Hill - Bass / Vocals
Patrick Hetherington - Guitar / Keys / Vocals
Louie Swain - Keys / Vocals
Anatole Serret - Drums / Vocals

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering: Julian Martlew
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editors: Alaia D’Alessandro & Jim Beckmann

https://www.parcelsmusic.com/
http://kexp.org


# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## The Bee Weekly: Our New World Of Soaring Gas Prices And Movies Not As Good As The Phantom Menace
 - [https://www.youtube.com/watch?v=eLWm9OXAiHU](https://www.youtube.com/watch?v=eLWm9OXAiHU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-03-11 00:00:00+00:00

This week The Babylon Bee discusses how insane gas prices are. Biden seems to think it’s entirely Russia’s fault but we know he’s just being modest. Kyle, Adam, and Jarret also discuss their personal top ten Sci-Fi films (but no one picks The Last Jedi? Weird.) We also sit down with Carl Trueman, the author of a very thick book called The Rise and Triumph of the Modern Self: Cultural Amnesia, Expressive Individualism, and the Road to Sexual Revolution. He now has a shorter, more approachable book covering the same ground called Strange New World.

You can pre-order Dr. Carl Trueman’s new book Strange New World now: https://www.amazon.com/Strange-New-World-Activists-Revolution-ebook/dp/B09J1L27BR

For the much larger book, check out The Rise and Triumph of the Modern Self: Cultural Amnesia, Expressive Individualism, and the Road to Sexual Revolution: https://www.amazon.com/Rise-Triumph-Modern-Self-Individualism/dp/1433556332

This episode is also brought to you by Daily Nouri: https://dailynouri.com/

This episode is brought to you by Private Internet Access: https://privateinternetaccess.com/TheBabylonBee

## Feminist Changes Mind As WW3 Kicks Off
 - [https://www.youtube.com/watch?v=4jSDXArDVBk](https://www.youtube.com/watch?v=4jSDXArDVBk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-03-10 00:00:00+00:00

This woman is an angry feminist -- but she's quickly changing her tune as World War 3 starts and she faces the possibility of getting drafted.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


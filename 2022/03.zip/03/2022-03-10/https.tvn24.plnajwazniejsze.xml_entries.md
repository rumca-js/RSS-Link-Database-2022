# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "Chwała Ukrainie!". Dramatyczny obraz wojny
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-1865,S00E1865,726751?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-1865,S00E1865,726751?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-03-10 20:15:35+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0qe42c-czarno-na-bialym-5631002/alternates/LANDSCAPE_1280" />
    Materiał Marcina Gutowskiego.


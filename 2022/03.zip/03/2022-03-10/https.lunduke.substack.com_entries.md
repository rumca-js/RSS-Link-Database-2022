## elementary OS is imploding - by Bryan Lunduke
 - [https://lunduke.substack.com/p/elementary-os-is-imploding?s=r](https://lunduke.substack.com/p/elementary-os-is-imploding?s=r)
 - RSS feed: https://lunduke.substack.com
 - date published: 2022-03-10 07:22:02.693680+00:00

elementary founder: "I might take some time off from Linux or join another community maybe"


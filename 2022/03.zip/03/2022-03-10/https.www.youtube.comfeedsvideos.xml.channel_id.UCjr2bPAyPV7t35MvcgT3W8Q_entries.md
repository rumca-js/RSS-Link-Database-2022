# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## Why Sanctions On Russia Will Not Work On Putin
 - [https://www.youtube.com/watch?v=eGrlrtfNhpc](https://www.youtube.com/watch?v=eGrlrtfNhpc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2022-03-10 00:00:00+00:00

Sanctions on Russia over Ukraine invasion will hurt Russian economy and its people. But they won't force Putin to change his mind. 
Support independent research and analysis by joining my Patreon page: https://www.patreon.com/thehatedone 

The sanctions on Russia imposed by the Western alliance is far beyond anything that could be considered reasonable. The sanctions didn’t stay confined to just the targets closest to Putin and individuals with actual power in the Russian government. They are hurting innocent Russian civilians who have no connection to Kremlin and no say in the matter of Putin’s foreign policy.

Sources
CIA profile on Russia: https://www.cia.gov/the-world-factbook/countries/russia/
Real GDP Purchasing Power Parity: https://www.cia.gov/the-world-factbook/field/real-gdp-purchasing-power-parity/country-comparison/
Russian economy profile: https://www.britannica.com/place/Russia/Economy
IMF economic data: https://www.imf.org/external/datamapper/NGDPD@WEO/OEMDC/ADVEC/WEOWORLD

The First Gulf War: https://www.britannica.com/event/Persian-Gulf-War
Iraq sanctions hurting people: https://www.nytimes.com/1995/12/01/world/iraq-sanctions-kill-children-un-reports.html
Counter-argument to the toll of sanctions on Iraq: https://www.washingtonpost.com/news/worldviews/wp/2017/08/04/saddam-hussein-said-sanctions-killed-500000-children-that-was-a-spectacular-lie/
Deterioration due to sanctions: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1120689/
Iraq's child mortality rate: https://www.jstor.org/stable/4417422
Excess mortality: https://www.pbs.org/frontlineworld/stories/iraq/sanctions.html

Study on the factors for sanctions to work: https://www.tandfonline.com/doi/abs/10.1080/13642989908406841?

Sanctions on Russia:
https://www.washingtonpost.com/politics/2022/02/24/russia-sanctions-ukraine-biden/?
https://home.treasury.gov/news/press-releases/jy0608
https://indianexpress.com/article/world/sanctions-imposed-on-russia-for-invading-ukraine-7797825/
Banning of news and social media:
https://www.cnet.com/news/russian-news-outlets-rt-and-sputnik-are-now-banned-in-europe/
https://www.cnet.com/news/facebook-youtube-to-restrict-some-russian-state-controlled-media-across-europe/

Putin's autocratic control over media and information
Google & Apple in Russia: https://www.washingtonpost.com/business/2021/09/17/navalny-google-apple-app-russia/
https://www.bloomberg.com/news/articles/2022-01-26/why-swift-s-global-payments-are-sanctions-pain-point-quicktake
https://www.theguardian.com/world/2022/mar/04/russia-completely-blocks-access-to-facebook-and-twitter
https://www.theguardian.com/media/2022/mar/04/bbc-temporarily-suspending-work-all-news-journalists-russia

Swift ban
https://www.theguardian.com/technology/2022/feb/24/what-is-swift-international-payments-network-russia-sanction

Switzerland's privacy haven: https://www.icij.org/investigations/pandora-papers/switzerland-fidinam-wealth-management-money-laundering/
https://www.theguardian.com/news/2022/feb/20/credit-suisse-secrets-leak-unmasks-criminals-fraudsters-corrupt-politicians

China's CIPS: https://www.bloomberg.com/news/articles/2021-09-22/china-s-fledgling-cross-border-payments-system-grows-its-reach

Zelenskiy's pleas to NATO: https://finance.yahoo.com/news/1-ukraines-zelenskiy-makes-desperate-165528610.html
No-fly zone: https://www.theguardian.com/world/2022/mar/05/zelenskiy-lashes-out-at-nato-over-no-fly-zone-as-russian-attacks-intensify?
https://www.theguardian.com/world/2022/mar/04/nato-chief-warns-of-worse-suffering-in-ukraine-and-russian-attacks-elsewhere

Ban on Russian gamers: https://www.cnet.com/tech/gaming/ukrainian-official-calls-on-xbox-and-playstation-to-ban-russian-gamers/

Poutine: https://www.msn.com/en-us/foodanddrink/foodnews/a-drummondville-restaurant-temporarily-revises-its-branding-because-putin-e2-80-99s-last-name-is-spelled-e2-80-9cpoutine-e2-80-9d-in-french/ar-AAUqh1Q

Banning Russian gymnastics team: https://www.msn.com/en-us/sports/other/russia-banned-from-international-gymnastics-curling-over-invasion-of-ukraine/ar-AAUDiks

Banning Russian Paralympic athletes: https://www.wsj.com/articles/russia-athletes-banned-from-paralympics-11646320434

Calls to ban Russian students: https://www.foxnews.com/media/eric-swalwell-russians-us-universities-retaliation

China's diplomacy towards Russia: https://thediplomat.com/2022/03/can-china-shield-russia-from-ukraine-linked-sanctions/
China's $117bn contract with Russia: https://www.express.co.uk/news/world/1571490/china-news-help-russia-ukraine-invasion-teaming-up-west-sanctions-spt

China helping Russia: https://www.msn.com/en-us/money/other/russia-owns-24140-billion-in-chinese-bonds-which-could-help-it-skirt-western-sanctions-analysts-say/ar-AAUvPNY
China not joining sanctions: https://www.cnbc.com/2022/03/02/china-will-not-join-sanctions-against-russia-banking-regulator-says.html

Follow me:
https://twitter.com/The_HatedOne_
https://www.reddit.com/r/thehatedone/


# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## How is this even possible? Arpara 5k Micro OLED Review
 - [https://www.youtube.com/watch?v=kadTbE1lIys](https://www.youtube.com/watch?v=kadTbE1lIys)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-03-10 00:00:00+00:00

Hello! Today we are taking a look at the Arpara 5k Micro Oled SteamVR tracked VR headset. This is the smallest production PCVR capable SteamVR tracked VR headset in the world currently. I actually really enjoyed my time with it, but it certainly has its flaws. It's hard to compare this to something like a Meta (Oculus) Quest 2, probably better to be compared to a Valve Index. In a lot of ways I could see something like this replacing my index if a lot of flaws were fixed. 

Arpara link: 
https://www.arparaland.com/

My links: 
https://discord.gg/sZyzWXVXMz
https://www.twitch.tv/thrilluwu
https://www.patreon.com/Thrillseeker
https://twitter.com/Thrilluwu
https://www.startengine.com/thrillsee...


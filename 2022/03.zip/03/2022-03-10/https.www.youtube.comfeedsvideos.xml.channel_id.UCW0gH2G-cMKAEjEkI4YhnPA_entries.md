# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Helm of Éomer by United Cutlery UNBOXING UC3460 | Lord of the Rings Collectibles Review
 - [https://www.youtube.com/watch?v=0hRTdK6DxS8](https://www.youtube.com/watch?v=0hRTdK6DxS8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-03-10 00:00:00+00:00

United Cutlery sent me one of the most unique helmets in all the Lord of the Rings trilogy - the helm of Éomer! I'll give an up-close look at this replica and its impressive base, while giving my initial reactions!

Check out this and Middle-earth United Cutlery products here!: https://bit.ly/3FRrn7f

Helm of Éomer: https://bit.ly/3FRrn7f
Sword of Éomer: https://bit.ly/3GXNB9f


Official Description:
Éomer was a captain of the king’s cavalry, Marshal of the Mark, and one of Rohan’s mightiest warriors. He bravely fought alongside King Theoden against the forces of Mordor at the battle of Helm’s Deep and on the Pelennor Fields, skillfully wielding his sword, Gúthwinë, and hurling his great spear. In the final stand against the dark lord Sauron, Éomer fought alongside Aragorn with the armies of Rohan and Gondor at the Gates of Mordor. His steel helm featured a brass horse head nose guard extending across the crest and engraved horse and sun motifs. He was recognized by his kinsmen on the battlefield by the long flowing horse tail that crested his great helm. This authentically detailed replica is a reproduction of the actual filming prop built by Weta Workshop and used in “The Lord Of The Rings” films presented by New Line Cinema. The helm is crafted of reinforced polyresin and genuine leather, with precisely-molded details and coloring.

While this was sent to me by a vendor, I was under no obligation to give this item a positive review.  Any praise/criticism in my reviews is my genuine opinion/thoughts.  If you are surprised that I really enjoy a LOTR piece of memorabilia, you really shouldn't be. :)

#lordoftherings #unboxing #collectibles


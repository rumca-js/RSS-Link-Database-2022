## Some tiny personal programs I've written
 - [https://jvns.ca/blog/2022/03/08/tiny-programs/](https://jvns.ca/blog/2022/03/08/tiny-programs/)
 - RSS feed: https://jvns.ca
 - date published: 2022-03-10 06:46:59.909924+00:00

Some tiny personal programs I've written


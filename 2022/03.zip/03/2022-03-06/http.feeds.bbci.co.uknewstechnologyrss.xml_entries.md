# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Ukraine war: President Zelensky invites Elon Musk to visit
 - [https://www.bbc.co.uk/news/world-europe-60637841?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60637841?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-03-06 09:47:17+00:00

Ukraine's president was thanking the tech entrepreneur for supplying Starlink equipment to the country.


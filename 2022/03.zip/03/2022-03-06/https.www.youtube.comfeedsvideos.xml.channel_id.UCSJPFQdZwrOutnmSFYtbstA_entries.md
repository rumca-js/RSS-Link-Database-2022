# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Batman - Spoiler Free Review
 - [https://www.youtube.com/watch?v=nCwfRWsxZfc](https://www.youtube.com/watch?v=nCwfRWsxZfc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-03-07 00:00:00+00:00

The Batman is one of the most anticipated movies of the year, but was it worth the wait? Find out in my spoiler-free review.


# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Feminist Changes Mind As WW3 Kicks Off
 - [https://www.youtube.com/watch?v=4jSDXArDVBk](https://www.youtube.com/watch?v=4jSDXArDVBk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-03-10 00:00:00+00:00

This woman is an angry feminist -- but she's quickly changing her tune as World War 3 starts and she faces the possibility of getting drafted.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


## The new silent majority: People who don't tweet
 - [https://www.axios.com/political-polarization-twitter-cable-news-ac9699c6-260d-4141-b511-5c7193566ea1.html](https://www.axios.com/political-polarization-twitter-cable-news-ac9699c6-260d-4141-b511-5c7193566ea1.html)
 - RSS feed: https://www.axios.com
 - date published: 2022-03-09 07:02:38.966803+00:00

The rising power and prominence of the nation's loudest, meanest voices distort our reality.


# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## How To Become a Woke Celebrity!
 - [https://www.youtube.com/watch?v=OvYmjoowSjE](https://www.youtube.com/watch?v=OvYmjoowSjE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-03-09 00:00:00+00:00

Grab your Magnesium Breakthrough at https://magnesiumbreakthrough.com/jp
Use Code "AWAKEN" For a Deal

Check Out My Merch Here - https://awakenwithjp.com

See my LIVE Comedy Shows - https://awakenwithjp.com/pages/events

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Ever wonder how to become a woke celebrity? Well becoming a mainstream celebrity has never been easier. With these easy to follow steps, you too can rise to the sewer system of being a woke mainstream celebrity!

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

## UPDATE: Russia and Ukraine Explained by Kamala Harris!
 - [https://www.youtube.com/watch?v=6Qxb2ihpxwQ](https://www.youtube.com/watch?v=6Qxb2ihpxwQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-03-09 00:00:00+00:00

Grab your Cacao Bliss at https://earthechofoods.com/jpsears
Use Code "JP" for 15% Off!

Check Out My Merch Here - https://awakenwithjp.com

See my LIVE Comedy Shows - https://awakenwithjp.com/pages/events

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Tune in for the latest update on everything that is going on with Ukraine and Russia. As explained by Kamala Harris! Plus Putin, Biden, and Elon Musk! The breaking news you can't miss. 

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com


# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Intel, you’re doing it wrong. - Intel NUC 12 Review
 - [https://www.youtube.com/watch?v=UGmGlaxf5tM](https://www.youtube.com/watch?v=UGmGlaxf5tM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-03-10 00:00:00+00:00

Receive a $25 credit for Ting Mobile today when you sign up at https://linus.ting.com/

Use code LINUS at https://pebblehost.com/dedicated for 30% off your first month, available for the first 100 people who sign up for dedicated server hosting.

Intel’s NUC’s are getting good – but at what cost? We’re taking a deep dive into the 12th Gen NUC Extreme to find out. 

Discuss on the forum: https://linustechtips.com/topic/1417201-the-smallest-no-compromises-gaming-pc-intel-dragon-canyon-nuc/

Buy an Intel Dragon Canyon NUC 12: https://geni.us/IOb8

Buy an RTX 3080 Ti: https://geni.us/h4RQnR

Buy a 2TB Crucial P5 Plus: https://geni.us/jrkn

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
0:52 Humble beginnings
1:43 EXTREME!
2:25 12th Gen 
3:33 Under the hood 
4:19 Stealth GPU
5:27 Inside the Compute Unit
7:00 Even deeper 
8:00 Paste Piracy 
8:40 12900K Tuning
11:05 Old vs New

## AMD just proved they're not your friend - Threadripper Pro 5000 Announcement
 - [https://www.youtube.com/watch?v=h74mZp0SvyE](https://www.youtube.com/watch?v=h74mZp0SvyE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-03-09 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Create your build at https://www.buildredux.com/linus

Threadripper upended the HEDT market when it released, but now it seems the more expensive Threadripper PRO is here to take over. Is AMD making a mistake, or is enthusiast HEDT simply obsolete?

Discuss on the forum: https://linustechtips.com/topic/1417015-amd-just-proved-theyre-not-your-friend/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:08 What AMD announced
1:45 What AMD didn't announce - And why
2:57 Why bother with Threadripper at all then?
3:24 What killed HEDT?
5:12 Why HEDT no longer makes sense
9:05 Conclusion - If you're "PRO", you can still buy it

## Apple makes my brain hurt… - Peek Performance Event
 - [https://www.youtube.com/watch?v=k8RkyaSHFLM](https://www.youtube.com/watch?v=k8RkyaSHFLM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-03-09 00:00:00+00:00

Receive a $25 credit for Ting Mobile today when you sign up at https://linus.ting.com/

Celebrate Ridge's 9th Anniversary and use offer code LINUS for 15% off sitewide until March 18th at https://www.ridge.com/LINUS

Apple’s Peek Performance event is over, and now that M1 Ultra is out of the bag, we now know that Macs are getting the chiplet treatment. What does it mean for PCs? And what about the Studio Display?

Discuss on the forum: https://linustechtips.com/topic/1416887-apple-makes-my-brain-hurt/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
0:57 Mac Studio - The Mini Pro
2:04 M1 ULTRA
3:09 Apple's up to their usual tricks...
4:00 M1 Ultra GPU and Media Engine
5:18 Storage is pricey and maybe buy a UPS
6:06 Studio Display
8:09 iPad Air - Now with M1 and 5G
8:48 iPhone SE - Missed opportunity
9:47 Curious wording and conclusion


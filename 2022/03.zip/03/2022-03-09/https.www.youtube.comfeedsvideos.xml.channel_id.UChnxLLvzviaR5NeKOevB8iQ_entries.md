# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Planning a Live Set With a Hybrid Eurorack System
 - [https://www.youtube.com/watch?v=uT-ls3zdv4g](https://www.youtube.com/watch?v=uT-ls3zdv4g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2022-03-09 00:00:00+00:00

Watch the performance here: https://youtu.be/6wdY5rQDH9M
Thank u to Patchwerks for sponsoring this video. Check out the gear mentioned here over on their website!

ALM Pamela's New Workout: https://shrsl.com/38qt7
Arturia Keystep 37: https://shrsl.com/38qt9
Elektron Octatrack: https://shrsl.com/38qtg
Make Noise Mimeophon: https://shrsl.com/38qun
Mutable Instrument Blades: https://shrsl.com/38qvj
Noise Engineering Manis Iteritas: https://shrsl.com/38qwa
Qu-Bit Data Bender: https://shrsl.com/38qwy
Qu-Bit Surface: https://shrsl.com/38qwr
Squarp Hermod: https://shrsl.com/38qxk
Tip-Top Z5000: https://shrsl.com/3c0xr
WMD Javelin: https://shrsl.com/3c0xn
After Later Audio Pique: https://shrsl.com/3c0xo
Arturia Rackbrute 6u:  https://shrsl.com/3c0xv

00:00 intro
00:54 synthstrom deluge
02:05 midi distribution
03:35 midi to cv
04:40 eurorack
13:44 ad break
14:47 samples and drums
23:31 playing a little
25:57 octatrack
27:49 outro
------------------------------------
Patreon:  http://bit.ly/rmrpatreon

My Music: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia


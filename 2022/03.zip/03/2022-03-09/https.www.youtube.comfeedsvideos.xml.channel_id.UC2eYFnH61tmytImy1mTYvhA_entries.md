# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Vim Alchemy with Macros
 - [https://www.youtube.com/watch?v=3eyzINMjlEk](https://www.youtube.com/watch?v=3eyzINMjlEk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2022-03-10 00:00:00+00:00

We unlock ancient, alchemical secrets with vim macros in a XeLaTeX document.

My website: https://lukesmith.xyz
Classical books reprinted by me: https://lindypress.net
Get all my videos off YouTube: https://videos.lukesmith.xyz
or Odysee: https://odysee.com/$/invite/@Luke:7

Please donate: https://donate.lukesmith.xyz
BTC: bc1qw5w6pxsk3aj324tmqrhhpmpfprxcfxe6qhetuv
XMR: 48jewbtxe4jU3MnzJFjTs3gVFWh2nRrAMWdUuUd7Ubo375LL4SjLTnMRKBrXburvEh38QSNLrJy3EateykVCypnm6gcT9bh

OR affiliate links to things l use:
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.

## The Future of Monero (Luke Smith and Kevin Wad)
 - [https://www.youtube.com/watch?v=31eI9UD83PY](https://www.youtube.com/watch?v=31eI9UD83PY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2022-03-09 00:00:00+00:00

We talk about basically everything about Monero, Bitcoin, their use in the future and more.

Kevin Wad's channel: https://www.youtube.com/channel/UCMg5jHjEp59TKy_0tdoeXnQ
Him on Monero Talk: https://www.youtube.com/watch?v=4lwRB7YxAsA

Timestamps:
00:00:00 Introduction
00:01:10 Monero maximalist definition
00:03:33 The fiat system is more private than Bitcoin.
00:15:20 Monero vs Bitcoin long term.
00:22:11 El Salvador
00:26:15 The 2020 Bitcoiner
00:29:00 BTC censorship and custodianship.
00:34:00 Taxes and Regulations
00:38:00 Bitcoiners don't use bitcoin.
00:40:00 BTC technically lack liquidity on layer 2
00:43:00 BTC maxis' argument against Monero.
00:49:00 What are chances BTC & XMR will fail?
00:57:00 Bitcoin reduced to an index fund.
00:58:30 Importance of Hard Money
01:00:06 Next Global Currency
01:18:00 The Necessity of the Non-digital Option
01:51:00 Etica Protocol

My website: https://lukesmith.xyz
Classical books reprinted by me: https://lindypress.net
Get all my videos off YouTube: https://videos.lukesmith.xyz
or Odysee: https://odysee.com/$/invite/@Luke:7

Please donate: https://donate.lukesmith.xyz
BTC: bc1qw5w6pxsk3aj324tmqrhhpmpfprxcfxe6qhetuv
XMR: 48jewbtxe4jU3MnzJFjTs3gVFWh2nRrAMWdUuUd7Ubo375LL4SjLTnMRKBrXburvEh38QSNLrJy3EateykVCypnm6gcT9bh

OR affiliate links to things l use:
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.


# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## The New Trash Can
 - [https://www.youtube.com/watch?v=IUB5dS7eeII](https://www.youtube.com/watch?v=IUB5dS7eeII)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2022-03-09 00:00:00+00:00

Apple announced the new Mac Studio and... it's not that different from a 2013 trash can Mac Pro—it was just in the right place, at the right time, with the right hardware. In this episode, we talk about Apple's "peek performance" keynote, Apple TV+, iPhone SE 3, the 2022 iPad Air, and of course, the Apple Studio Display and Mac Studio with M1 Ultra.

Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

0:00 Snoozefest
0:26 Apple TV: HBO, but Worse
1:56 Green iPhone Is Best iPhone
2:12 iPhone SE 3 Is Great—Back Off
3:23 iPad Air Regains Its Crown
4:15 M1 Ultra is Unsurprising
5:27 Where in the World Is Jade-4C?
5:50 Mac Studio Is Neat
8:43 Spicy Hot Take
9:05 Studio Display Is Not Neat
12:22 Hot Take Resumed


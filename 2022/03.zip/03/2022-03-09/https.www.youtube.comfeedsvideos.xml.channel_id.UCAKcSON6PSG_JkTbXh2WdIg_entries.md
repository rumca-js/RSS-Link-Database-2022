# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Gang of Youths' David Le'aupepe on family history, and going maximalist on 'Angel In Real Time'
 - [https://www.youtube.com/watch?v=-Nt-eE-RQ-A](https://www.youtube.com/watch?v=-Nt-eE-RQ-A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-03-10 00:00:00+00:00

Gang of Youths' frontman David Le'aupepe joins The Current to discuss the Australian alt-rock group's latest record, 'Angel In Real Time'. Reflecting on the loss of his father and exploration into his family history, Le'aupepe dove into a maximalist approach on the release, "... it needed to be offensive to taste making sensibilities. It needed to be a complete violation of all those things. It needed to not be a downtempo miserable, sad, sodden record that everyone expects. There's this weird idea that somehow you can only convey true emotion with sad quiet intimacies and I resent that. I think it's a very old fashioned way to look at music—to convey things with huge, enormous, sweeping, panoramic-style songs, I think is just as effective, and we wanted to combine the two sensibilities."

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits
Guest - David Le'aupepe
Host - Mary Lucia
Producer - Jesse Wiza, Derrick Stevens
Technical Director - Eric Romani


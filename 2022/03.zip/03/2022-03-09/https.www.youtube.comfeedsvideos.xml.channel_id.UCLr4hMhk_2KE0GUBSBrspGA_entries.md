# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Nowe Produkty Apple: iPhone SE, iPad Air, Mac Studio i Studio Display
 - [https://www.youtube.com/watch?v=ZftORFaHkKQ](https://www.youtube.com/watch?v=ZftORFaHkKQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-03-09 00:00:00+00:00

Czyli obejrzałem konferencję Apple, żebyście Wy nie musieli ;)
Spis treści:
00:00 Dobre rano
01:06 Apple TV+
03:26 iPhone 13 i nowe kolory
05:12 iPhone SE
08:45 iPad Air
10:53 Procesory M1
12:55 Mac Studio
16:26 Studio Display
20:43 Wnioski
22:36 Dobrego dnia!

Moje sociale:
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter


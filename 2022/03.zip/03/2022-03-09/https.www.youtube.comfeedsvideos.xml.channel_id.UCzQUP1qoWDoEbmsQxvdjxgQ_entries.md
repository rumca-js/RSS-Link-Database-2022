# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## What Motivated Nims Purja to Climb 14 of the World's Tallest Mountains
 - [https://www.youtube.com/watch?v=xqtRV7jWOzk](https://www.youtube.com/watch?v=xqtRV7jWOzk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-03-09 00:00:00+00:00

Taken from JRE #1790 w/Nims Purja:
https://open.spotify.com/episode/0JEBeXmsbltKWYuf4TqJ6k?si=c144ffbf6d4d47c3


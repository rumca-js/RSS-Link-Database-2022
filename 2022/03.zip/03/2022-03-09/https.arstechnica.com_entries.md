## Cloudflare refuses to pull out of Russia, says Putin would celebrate shutoff | Ars Technica
 - [https://arstechnica.com/tech-policy/2022/03/cloudflare-wont-cut-off-russia-says-it-needs-more-internet-access-not-less/](https://arstechnica.com/tech-policy/2022/03/cloudflare-wont-cut-off-russia-says-it-needs-more-internet-access-not-less/)
 - RSS feed: https://arstechnica.com
 - date published: 2022-03-09 23:18:34.363900+00:00

Cloudflare: "We believe the Russian government would celebrate us shutting down."

## At long last: Apple will sell a desktop monitor that doesn’t cost $5,000 | Ars Technica
 - [https://arstechnica.com/gadgets/2022/03/at-long-last-apple-will-sell-a-desktop-monitor-that-doesnt-cost-5000/](https://arstechnica.com/gadgets/2022/03/at-long-last-apple-will-sell-a-desktop-monitor-that-doesnt-cost-5000/)
 - RSS feed: https://arstechnica.com
 - date published: 2022-03-09 22:49:51.653246+00:00

The new monitor will support 5K and house an A13 Bionic chip.

## VW unveils adorable electric ID. Buzz, US sales begin in 2024 | Ars Technica
 - [https://arstechnica.com/cars/2022/03/vw-unveils-adorable-electric-id-buzz-us-sales-begin-2024/](https://arstechnica.com/cars/2022/03/vw-unveils-adorable-electric-id-buzz-us-sales-begin-2024/)
 - RSS feed: https://arstechnica.com
 - date published: 2022-03-09 22:47:36.684560+00:00

The three-row-long wheelbase version for North America is still two years away.


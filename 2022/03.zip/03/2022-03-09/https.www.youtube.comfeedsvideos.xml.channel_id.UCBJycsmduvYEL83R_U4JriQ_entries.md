# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## NEW Mac Studio & Apple Event Reactions!
 - [https://www.youtube.com/watch?v=CMm7UZKtGNk](https://www.youtube.com/watch?v=CMm7UZKtGNk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-03-09 00:00:00+00:00

The Mac Studio, The iPhone SE 2022, and the Studio Display have arrived. I have some thoughts.
Giveaway - You in yet? https://dbrand.com/winners
Studio Channel: https://www.youtube.com/c/TheStudio/
MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Return of the Mac
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


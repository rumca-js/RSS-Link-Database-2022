# Source:Climate Town, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCuVLG9pThvBABcYCm7pkNkA, language:en-US

## U.S. Oil & Gas Companies Trying To Profit From War In Ukraine | Climate Town
 - [https://www.youtube.com/watch?v=kJOuyckvDGY](https://www.youtube.com/watch?v=kJOuyckvDGY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCuVLG9pThvBABcYCm7pkNkA
 - date published: 2022-03-09 18:47:10+00:00

Thanks for watching. First things first - links to Ukrainian aid:
https://crisisrelief.un.org/t/ukraine
https://www.icrc.org/en/donate/ukraine
https://www.cbsnews.com/news/russia-ukraine-refugees-donations-charity/
https://www.rescue.org/article/ukraine-russia-crisis-what-happening
https://www.globalgiving.org/projects/ukraine-crisis-relief-fund/

sUbScRiBe FoR mOrE ViDeOs: https://www.youtube.com/c/climatetown?sub_confirmation=1

SOURCES SOURCES SOURCES:
FIRST GO AND FOLLOW THE INCREDIBLE AMY WESTERVELT:
https://www.hottakepod.com/war-who-is-it-good-for-the-fossil-fuel-industry/
And follow Popular Information
https://popular.info/p/fossil-fuel-companies-are-exploiting

Oil and Gas Leases:
https://www.forbes.com/sites/ianpalmer/2021/01/27/leasing-pause-for-oil-and-gas-companies-on-federal-lands--the-climate-future-is-here/
https://storymaps.arcgis.com/stories/63745d4475104a33968081ff008e36b9
https://www.blm.gov/programs/energy-and-minerals/oil-and-gas/about
https://www.npr.org/2021/11/26/1059398764/biden-calls-for-higher-fees-for-oil-gas-leasing-on-federal-land-stops-short-of-b

Keystone XL and Drilling: 
https://www.npr.org/2021/03/06/973649045/hold-that-drill-why-wall-street-wants-energy-companies-to-pump-less-oil-not-more
https://www.nytimes.com/2022/03/02/business/oil-prices-opec.html?referringSource=articleShare
https://www.cnn.com/2021/11/10/energy/oil-gas-prices-joe-biden/index.html
https://www.reuters.com/article/factcheck-keystonepipelinexl-builtandpai-idUSL1N2LA2SQ
https://www.mediamatters.org/fox-news/fox-news-mentioned-keystone-pipeline-141-times-one-week-during-networks-coverage-war
https://www.naturalgasintel.com/gop-doubles-down-on-deregulation-as-trump-claims-biden-to-lay-waste-to-u-s-oil-natural-gas/
VIDEO INTERVIEW ABOUT NOT WANTING TO INCREASE DRILLING: https://www.youtube.com/watch?v=FnnTMlNbfK4

https://www.nrdc.org/stories/what-keystone-pipeline
https://pboilandgasmagazine.com/report-independent-operators-lead-production-in-permian-basin/
https://www.mrt.com/business/oil/article/New-analysis-shows-supermajors-lag-independents-16649445.php


Oil Profits:
https://www.reuters.com/business/energy/chevron-posts-highest-profit-eight-years-surging-oil-gas-prices-2021-10-29/
https://www.theguardian.com/business/2021/dec/06/oil-companies-profits-exxon-chevron-shell-exclusive
https://www.cnbc.com/2022/02/10/totalenergies-earnings-q4-2021.html

Natural Gas:
https://www.eia.gov/dnav/ng/ng_move_expc_s1_m.htm
https://www.gti.energy/wp-content/uploads/2019/10/40-LNG19-04April2019-Zeal-Tom-paper.pdf 
https://www.energy.gov/sites/default/files/2022-02/LNG%20Monthly%20December%202021_0.pdf
https://www.eia.gov/dnav/ng/ng_move_expc_s1_m.htm

Russia, Germany, Europe:
https://www.reuters.com/business/sustainable-business/germany-aims-get-100-energy-renewable-sources-by-2035-2022-02-28/
https://www.reuters.com/business/sustainable-business/germany-aims-get-100-energy-renewable-sources-by-2035-2022-02-28/?utm_source=reddit.com
https://www.reuters.com/markets/europe/russias-oil-gas-revenue-windfall-2022-01-21/
https://www.investopedia.com/articles/investing/040414/how-russia-makes-its-money-and-why-it-doesnt-make-more.asp

Thanks to Ian MK Cessna for the intro animation
Written by Rollie Williams, Matt Nelsen, Ben Boult & Nicole Conlan

Renewable energy groups/advocacy:
American Council on Renewable Energy: https://acore.org/
Environmental and Energy Study Institute (EESI): https://www.eesi.org/
Rocky Mountain Institute (RMI): http://www.rmi.org/
Clean Energy States Alliance (CESA): https://www.cesa.org/

Books:
Electrify by Saul Griffiths
The New Map: Energy, Climate, and the Clash of Nations by Daniel Yergin
Short Circuiting Policy: Interest Groups and the Battle Over Clean Energy and Climate Policy in the American States Book by Leah Stokes
This Changes Everything: Capitalism vs. The Climate by Naomi Klein
The Shock Doctrine by Naomi Klein
On Fire: The Burning Case for a Green New Deal by Naomi Klein

LinkTree - https://linktr.ee/ClimateTown
Discord - https://discord.gg/A5Czqfgr4C
Instagram - https://www.instagram.com/climatetown/
Twitter - https://twitter.com/ClimateTown
TikTok - https://www.tiktok.com/@climatetown

STUFF YOU CAN DO

JOIN OUR DISCORD! We think it’d be pretty cool to harness our amazing community’s collective power and enthusiasm and make a gosh dang difference. We just created a channel called “#ukraine-war” (https://discord.gg/HCu7CRSn5t), where you can share info about how to help the citizens of Ukraine, or call out the organizations trying to profit from the tragedy, or even share a link that we missed to help other Climate Townies stay informed. (And in case you’re like me from a month ago and have no idea how to use Discord, here’s a helpful lil’ beginner’s guide - https://support.discord.com/hc/en-us/articles/360045138571-Beginner-s-Guide-to-Discord)


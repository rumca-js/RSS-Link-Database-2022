# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Elden Ring: Top 10 Armor Sets You CAN'T Afford to Miss
 - [https://www.youtube.com/watch?v=ZIw7NDnqR1o](https://www.youtube.com/watch?v=ZIw7NDnqR1o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-03-10 00:00:00+00:00

Elden Ring (PC, PS5, PS4, Xbox Series X/S/One) is filled with cool armor sets to earn. Here are some you that you shouldn't miss checking out.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#EldenRing

## 10 Misconceptions About Gamers From Non-Gamers [Pt 2]
 - [https://www.youtube.com/watch?v=PsdFS8keuW0](https://www.youtube.com/watch?v=PsdFS8keuW0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-03-09 00:00:00+00:00

Gamers often get a bad rap from the general public. Here are more misconceptions about video games. Let us know what you think!
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


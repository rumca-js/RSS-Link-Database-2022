# Source:Vlog Casha, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg, language:pl-PL

## WRÓCIŁEM DO USA! Na start, Floryda! - USA #01
 - [https://www.youtube.com/watch?v=sFxNXBTffbs](https://www.youtube.com/watch?v=sFxNXBTffbs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2022-03-19 00:00:00+00:00

🗺️ USA (2022) #01. Po kilku miesiącach pobytu w Polsce, postanowiłem, że czas ruszyć w kolejną podróż... wybór padł, ponownie, na USA :)

Kanał Nathana: @swiatwedlugnejtana

Wsparcie dla Ukrainy:
PCK https://pck.pl/na-pomoc-ukrainie/
Pomagam https://pomagam.pl/solidarnizukraina
Ukraiński Dom https://ukrainskidom.pl/pomoc-ukrainie/
UNICEF https://tinyurl.com/2p8nwv4s
Bank Ukraiński: https://bank.gov.ua/en/about/humanitarian-aid-to-ukraine
Bieg dla Ukrainy (26.03): https://biegdlaukrainy.pl/ 

Wolontariaty:
Wolontariaty są zarządzane na poziomie wojewódzkim/miejskim
Warszawa: https://wolontariat.waw.pl/
https://www.instagram.com/grupacentrum.waw/

❗ Zostań Patronem kanału!
https://patronite.pl/vlogcasha

5% zniżki na Kuga Campervan na hasło "VlogCasha" (wynajem na co najmniej 10 dni): https://www.travellers-autobarnrv.com/ 

Playlisty filmów z moich podróży:
USA (2022): https://bit.ly/3uGVdbd
Kuba (2021): https://bit.ly/3dhLIqK
USA (2021): https://bit.ly/35J0zKd
Meksyk (2021): http://bit.ly/3c7Jycf
Turcja (2019-2020): https://bit.ly/31VPCR3
Kolumbia (2020): https://bit.ly/36tqlhH
Tajlandia, Laos, Wietnam (2019): https://bit.ly/2wrM9t2
Australia (2018): https://bit.ly/2OJWYOy
USA (2017): https://bit.ly/2ya73NV
Autostop (2018): https://bit.ly/2NbHzos

Mój sprzęt:
Aparat/Obiektywy: Sony A7IV / FE 16-35mm F2.8 / FE 24-105mm F4
Plecak zielony: https://bit.ly/3y9cX1Y
Dron: https://bit.ly/3HCTZUv

(Linki afiliacyjne. Jeśli dokonacie zakupów po wejściu w mój link, otrzymam prowizję za polecenie.)

Muzyka z vloga pochodzi z serwisu Artlist. Skorzystaj z mojej promocji i odbierz 2 miesiące gratis!
Artlist: https://bit.ly/3mWjQwo

▸ Instagram: https://www.instagram.com/vlogcasha
▸ Facebook: https://www.facebook.com/vlogcasha/

#PodróżeCasha #USA


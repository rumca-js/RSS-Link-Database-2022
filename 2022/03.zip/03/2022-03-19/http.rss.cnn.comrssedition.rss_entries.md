# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Ex-CIA director on Russia's use of powerful weapon: 'Dangerous escalation'
 - [https://www.cnn.com/videos/world/2022/03/19/leon-panetta-vladimir-putin-russia-hypersonic-missiles-ukraine-war-tsr-vpx.cnn](https://www.cnn.com/videos/world/2022/03/19/leon-panetta-vladimir-putin-russia-hypersonic-missiles-ukraine-war-tsr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 23:27:59+00:00

Former CIA Director and Secretary of Defense Leon Panetta responds to confirmations by US officials that Russia launched powerful hypersonic missiles against Ukraine last week, the first known use of such missiles in combat. Russia claimed it deployed hypersonic missiles to destroy an ammunition warehouse in western Ukraine.

## Mariupol residents are being forced to go to Russia, city council says
 - [https://www.cnn.com/2022/03/19/europe/mariupol-shelter-commander-ukraine-intl/index.html](https://www.cnn.com/2022/03/19/europe/mariupol-shelter-commander-ukraine-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 22:13:42+00:00

People in the Ukrainian city of Mariupol risk their lives each time they emerge from underground bunkers, a local military official said, claiming the strategic port is facing the most intense fighting anywhere in the country.

## 'This will happen': Twice-poisoned Putin critic makes prediction about Russian government
 - [https://www.cnn.com/videos/world/2022/03/19/vladimir-kara-murza-putin-russian-government-war-in-ukraine-acostanr-vpx.cnn](https://www.cnn.com/videos/world/2022/03/19/vladimir-kara-murza-putin-russian-government-war-in-ukraine-acostanr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 21:04:58+00:00

Russian opposition politician Vladimir Kara-Murza speaks out about how Russia could possibly achieve regime change as the war in Ukraine continues.

## Russian cosmonauts spark speculation after arriving at International Space Station in Ukraine's colors
 - [https://www.cnn.com/2022/03/19/politics/russian-cosmonauts-ukraine-international-space-station/index.html](https://www.cnn.com/2022/03/19/politics/russian-cosmonauts-ukraine-international-space-station/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 19:21:30+00:00

A trio of Russian cosmonauts arrived Friday at the International Space Station wearing bright yellow flight suits trimmed with blue, raising questions about whether the three were showing solidarity with Ukraine by wearing its national colors and rebuking their own government's invasion.

## Worshipers at Canadian mosque subdue hatchet-wielding attacker, police say
 - [https://www.cnn.com/2022/03/19/americas/ontario-canada-mosque-possible-hate-crime/index.html](https://www.cnn.com/2022/03/19/americas/ontario-canada-mosque-possible-hate-crime/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 18:02:19+00:00

Worshipers at a mosque in the Canadian city of Mississauga on Saturday subdued a man who discharged bear spray while brandishing a hatchet in what police said was a possible hate crime.

## Detainee in Iran with triple nationality who was released as part of deal with UK is sent back to jail
 - [https://www.cnn.com/2022/03/19/middleeast/iran-uk-us-prisoner-tahbaz-zaghari-ratcliffe-intl/index.html](https://www.cnn.com/2022/03/19/middleeast/iran-uk-us-prisoner-tahbaz-zaghari-ratcliffe-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 17:21:47+00:00

One of the three detained British-Iranians who were released as part of a deal signed by the UK has been returned to jail in Tehran, his lawyer told CNN Friday.

## Prosecutors vowed 2 years ago to examine singer James Brown's death. Newly released documents show they did very little
 - [https://www.cnn.com/2022/03/19/us/james-brown-death-investigation/index.html](https://www.cnn.com/2022/03/19/us/james-brown-death-investigation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 12:40:59+00:00

On February 12, 2020, Jacque Hollander sat in a conference room on the third floor of an Atlanta courthouse and told prosecutors she thought James Brown had been murdered.

## Black therapists are struggling to be seen on TikTok. They're doing this instead.
 - [https://www.cnn.com/2022/03/19/health/black-therapists-tiktok-khn-partner-wellness/index.html](https://www.cnn.com/2022/03/19/health/black-therapists-tiktok-khn-partner-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 12:34:57+00:00

From a well-lighted room, the plants blurred in the background, their face framed by closed captioning, Shahem Mclaurin speaks directly into the camera. The lesson: "Ten ways to start healing."

## 4 US service members killed after aircraft crashes in Norway, PM says
 - [https://www.cnn.com/2022/03/19/europe/norway-us-military-osprey-nato-intl-hnk/index.html](https://www.cnn.com/2022/03/19/europe/norway-us-military-osprey-nato-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 12:25:04+00:00

A US military aircraft with four people aboard that appears to have crashed Friday during NATO training exercises in Norway has been spotted with "major damage," according to authorities.

## Man wins $8.9 million from forgotten lottery ticket bought at Christmas
 - [https://www.cnn.com/2022/03/19/us/oregon-lottery-forgotten-trnd/index.html](https://www.cnn.com/2022/03/19/us/oregon-lottery-forgotten-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 10:51:44+00:00

Nearly three months after buying a Megabucks lottery ticket and quickly forgetting about it, an Oregon man is a multimillionaire.

## 'Fashioning Masculinities:' Tracing the history of gender-fluid menswear
 - [https://www.cnn.com/style/article/fashioning-masculinities-va-harris-reed/index.html](https://www.cnn.com/style/article/fashioning-masculinities-va-harris-reed/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 10:44:04+00:00

A long cape in a light-catching dusty pink; a floral brocaded silk robe with a cinched waist; a military buff coat decorated with dainty ribbon fastenings -- these are some of the most subversive items featured in the new exhibition "Fashioning Masculinities: The Art of Menswear," at London's Victoria and Albert museum (the V&amp;A). But this distinctly feminine menswear isn't the work of today's new-gen fashion designers -- they are historical artifacts from the 17th, 18th and 19th centuries.

## Mike Tyson is selling ear-shaped cannabis-infused edibles called 'Mike Bites'
 - [https://www.cnn.com/2022/03/19/business/mike-tyson-ear-shaped-edibles-trnd/index.html](https://www.cnn.com/2022/03/19/business/mike-tyson-ear-shaped-edibles-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 10:28:55+00:00

More than two decades after Mike Tyson bit off a chunk of Evander Holyfield's ear at the 1997 WBA Heavyweight Championship fight, the legendary boxer has released a line of edibles -- in the shape of ears.

## Isolated tornadoes possible in US East Coast
 - [https://www.cnn.com/2022/03/19/weather/weekend-severe-storms-east-coast/index.html](https://www.cnn.com/2022/03/19/weather/weekend-severe-storms-east-coast/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 10:24:22+00:00

The same damaging storm system that rolled across the Southeast on Friday will continue this weekend, impacting over 50 million people along the East Coast.

## The destinations dropping all Covid rules for entry and more of the latest in travel
 - [https://www.cnn.com/travel/article/pandemic-travel-news-crystal-cabin-awards/index.html](https://www.cnn.com/travel/article/pandemic-travel-news-crystal-cabin-awards/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 10:20:50+00:00

This week at CNN Travel, we look at the countries dropping all their Covid-related rules for entry, innovative airplane cabin designs, new breathtaking bridges and why Finland is living its best life.

## How aid organizations are responding to the crisis in Ukraine
 - [https://www.cnn.com/2022/03/19/europe/ukraine-aid-organizations-response/index.html](https://www.cnn.com/2022/03/19/europe/ukraine-aid-organizations-response/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 10:00:19+00:00

In the parking lot of a refugee reception center just inside Poland, Ukrainian women spoke last week with a bus driver as aid worker Chris Skopec stood nearby.

## Lucrative Saudi-backed golf league is 'new opportunity' for players, says CEO
 - [https://www.cnn.com/2022/03/19/sport/saudi-golf-league-greg-norman-spt-intl/index.html](https://www.cnn.com/2022/03/19/sport/saudi-golf-league-greg-norman-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 09:39:49+00:00

The new lucrative Saudi Arabia-backed golf league is a "new opportunity" for players and the sport, according to its chairman Greg Norman.

## F1 2022 season preview: New designs, new drivers but one familiar rivalry
 - [https://www.cnn.com/2022/03/19/motorsport/f1-2022-season-preview-spt-intl/index.html](https://www.cnn.com/2022/03/19/motorsport/f1-2022-season-preview-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 09:25:08+00:00

For the first time since the dawn of the Mercedes era -- the team has now won eight consecutive constructors' championships -- there is genuine uncertainty about how the Formula One season will unfold, with the Bahrain Grand Prix on Sunday kicking off the new campaign.

## Paulo Fonseca: Former Roma manager shares family escape story from Ukraine
 - [https://www.cnn.com/2022/03/19/football/paulo-fonseca-roma-ukraine-spt-intl/index.html](https://www.cnn.com/2022/03/19/football/paulo-fonseca-roma-ukraine-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 09:08:13+00:00

They were woken in the early hours by the sound of bombs landing within earshot of their apartment in Kyiv. Like many others, they fled Ukraine, setting off on a perilous journey to safety.

## Ukraine refugees: Why the US has allowed so few
 - [https://www.cnn.com/2022/03/19/politics/ukraine-refugees-us-what-matters/index.html](https://www.cnn.com/2022/03/19/politics/ukraine-refugees-us-what-matters/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 06:30:09+00:00

Many Ukrainians -- more than 3 million and counting -- have fled their country since Russia's invasion, with nearly 2 million pouring into neighboring Poland and hundreds of thousands going to other nearby countries.

## Rep. Don Young, Alaska Republican and dean of the House, has died
 - [https://www.cnn.com/2022/03/18/politics/don-young-dies-republican-alaska-congressman/index.html](https://www.cnn.com/2022/03/18/politics/don-young-dies-republican-alaska-congressman/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 03:55:10+00:00

US Rep. Don Young, a Republican of Alaska and the dean of the House, has died, his office said in a statement Friday. He was 88.

## US defense secretary Lloyd Austin tells CNN Russia made 'missteps' in Ukraine invasion
 - [https://www.cnn.com/2022/03/18/politics/don-lemon-lloyd-austin-interview-cnntv/index.html](https://www.cnn.com/2022/03/18/politics/don-lemon-lloyd-austin-interview-cnntv/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 02:08:57+00:00

US Defense Secretary Lloyd Austin on Friday said that the US has "seen a number of missteps" by Russia in its invasion of Ukraine

## 'Madison is wrong': GOP backlash over Cawthorn grows after Zelensky insult
 - [https://www.cnn.com/2022/03/18/politics/madison-cawthorn-republican-reaction/index.html](https://www.cnn.com/2022/03/18/politics/madison-cawthorn-republican-reaction/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 01:47:38+00:00

When House Republicans gathered on the baseball field Friday morning for their weekly practice, members were abuzz about one topic: Rep. Madison Cawthorn.

## Cleveland Browns agree to trade for Texans' Deshaun Watson
 - [https://www.cnn.com/2022/03/18/sport/deshaun-watson-trade-browns-spt/index.html](https://www.cnn.com/2022/03/18/sport/deshaun-watson-trade-browns-spt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 01:20:13+00:00

The Houston Texans have agreed to trade embattled quarterback Deshaun Watson to the Cleveland Browns, according to Texans General Manager Nick Caserio.

## Ukrainian mayor describes abduction by Russian troops
 - [https://www.cnn.com/videos/world/2022/03/19/melitopol-ukraine-mayor-ivan-fedorov-russia-kidnapping-ac360-vpx.cnn](https://www.cnn.com/videos/world/2022/03/19/melitopol-ukraine-mayor-ivan-fedorov-russia-kidnapping-ac360-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 01:16:21+00:00

Melitopol, Ukraine, Mayor Ivan Fedorov tells CNN's Anderson Cooper about his kidnapping by Russian troops.

## Nicole Kidman reenacts classic 'I Love Lucy' scene
 - [https://www.cnn.com/videos/media/2022/03/18/nicole-kidman-reenacts-i-love-lucy-scene-orig-as.cnn](https://www.cnn.com/videos/media/2022/03/18/nicole-kidman-reenacts-i-love-lucy-scene-orig-as.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 00:44:58+00:00

Nicole Kidman posted a behind-the-scenes look at how she perfected her role as Lucille "Lucy" Ball in "Being The Ricardos" - a biographical film about the "I Love Lucy" star and her husband, Desi Arnaz.

## This is what parenting in a war zone looks like
 - [https://www.cnn.com/2022/03/18/europe/gallery/parents-ukraine-war-intl/index.html](https://www.cnn.com/2022/03/18/europe/gallery/parents-ukraine-war-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 00:44:53+00:00

Ukraine's families are in crisis as parents attempt to keep their children safe in a war zone.

## A Chinese vlogger shared videos of war-torn Ukraine. He's been labeled a national traitor
 - [https://www.cnn.com/2022/03/18/asia/wang-jixian-chinese-vlogger-ukraine-intl-hnk/index.html](https://www.cnn.com/2022/03/18/asia/wang-jixian-chinese-vlogger-ukraine-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 00:30:58+00:00

Wang Jixian didn't set out to become the Chinese voice of resistance in Ukraine. The 36-year-old resident of Odesa, a key target in Russia's invasion of the country, simply wanted to show his parents he was fine.

## Former professional tennis player takes up arms to defend Ukraine
 - [https://www.cnn.com/videos/world/2022/03/18/alexandr-dolgopolov-retired-ukrainian-tennis-ebof-intv-vpx.cnn](https://www.cnn.com/videos/world/2022/03/18/alexandr-dolgopolov-retired-ukrainian-tennis-ebof-intv-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-03-19 00:27:51+00:00

Retired Ukrainian professional tennis player Alexandr Dolgopolov talks with CNN's Erin Burnett on why he is fighting to defend Ukraine.


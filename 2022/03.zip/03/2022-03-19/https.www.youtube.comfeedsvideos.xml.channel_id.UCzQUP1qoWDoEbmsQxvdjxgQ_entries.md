# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Former CIA Officer Mike Baker on Ukraine and Putin
 - [https://www.youtube.com/watch?v=xQEmYYpWt2g](https://www.youtube.com/watch?v=xQEmYYpWt2g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-03-19 00:00:00+00:00

Taken from JRE #1793 w/Mike Baker:
https://open.spotify.com/episode/44i3nQNm6yXV9jS9FUZHI0?si=123427feecd948b4


# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Wracam na Kubę (niespodziewany gość odcinka)
 - [https://www.youtube.com/watch?v=xkKZFOhMwwI](https://www.youtube.com/watch?v=xkKZFOhMwwI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2022-03-19 09:00:18+00:00

Wszystkie odcinki BezPlanu chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry)

Ula: https://www.youtube.com/c/MyDreamland
Wspomniany vlog Casha: https://www.youtube.com/watch?v=IASMY7zTzAo

BezPlanu Daily: https://www.youtube.com/channel/UCHXOfJP9fwMNXWGFKstju_w

Sklep: https://bezplanu.com
Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv
Wsparcie na Patronite: http://bit.ly/2KsFTZk

Czas akcji: luty 2022r.


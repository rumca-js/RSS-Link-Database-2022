# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The History of the Arkenstone - Is it a Silmaril? | Tolkien Explained
 - [https://www.youtube.com/watch?v=nJmMDWsYarE](https://www.youtube.com/watch?v=nJmMDWsYarE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-03-19 00:00:00+00:00

The Arkenstone is the great "Heart of the Mountain", the gem passed down through generations of dwarven kings. It was discovered as the dwarves first settle in the Lonely Mountain, and followed their people to the Grey Mountains, and back to Erebor once more.  We will talk through both the history of the Arkenstone and whether a popular theory that it is a Silmaril has any merit!

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

To purchase artist work, check out these amazing artists!

Anna Podedworna - https://www.artstation.com/akreon
Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html
Donato Giancola - https://www.donatoarts.com/online-store/secure-store/Middle-earth-c34110463
Aronja Art - https://www.instagram.com/aronjaart/
Ivan Cavini - https://www.instagram.com/ivan_cavini/
Sara Morello - https://www.artstation.com/saramorello
Matěj Čadil - https://www.etsy.com/people/matejcadil
Tulikoura - https://www.deviantart.com/tulikoura
Aegeri - https://www.deviantart.com/aegeri

The Arkenstone - Ted Nasmith
Heart of the Mountain - Ted Nasmith
The Arkenstone - Donato Giancola
The Silmarils - Aegeri
Arkenstone - Andrea Piparo
Thrain Discovers the Lonely Mountain - Ted Nasmith
Dwarven Smith - Turner Mohan
The Arkensone - Fantasy Flight
Moria Dwarf - Turner Mohan
The Dragon is Coming - Tulikoura
Erebor - WETA
Conversation with Smaug - Ted Nasmith
Where are you, thief - Skullb*st*rd
Thorin bestows gifts upon Bilbo - John Howe
Thorin Oakenshield - John Howe
The Hobbit, Searching for the Arkenstone - Alan Lee
Erebor & Dale - WETA
The Death of Thorin - John Howe
The King of the Mountain - Alan Lee
It ends in Flame - Jenny Dolfen
Feanor and the SIlmarils - BellaBergolts
Elu Thingol and the Dwarves of Nargrod in Menegroth - Steamey
Maedhros - Lida Holubova
Tulkas Chaining Morgoth - Kip Rasmussen
Maedhros and Maglor prepared to defend themselves and die - Catherine Karina Chmiel
And Maglor took pity upon them - Catherine Karina Chmiel
Maedhros - YidanYuan
Maglor Casts a Silmaril into the Sea - Ted Nasmith
Feanor with Silmaril - Steamey
The Treasures of Erebor - Aegeri
Melkor and the Silmarils - Sara M Morello
Thror - WETA (Paul Tobin)
The Making of the SIlmarils - Kuliszu
Feanor Creates the SIlmarils - Ted Nasmith
Beren Recovers a Silmaril - Anke Eissmann
Carcharoth - Turner Mohan
Death of the Lord of Nogrod - Steamey
Death of Thingol - Steamey
Maedhros Casts Himself into a Chasm - Ted Nasmith
Dain - Turner Mohan
Smaug and Bilbo - Andrea Piparo
Smaug the Magnificent - Alan Lee
Surely that is a Silmaril - Alan Lee
Alatar and Pallando - Ralph Damiani
Minas Tirith - Aegeri
The Oath of Finrod and Barahir - Anke Eissmann
Radagast the Brown - Ralph Damiani
Gandalf in the Archives of Minas Tirith - Matthew Stewart
Alatar and Pallando - Ralph Damiani
Witch King - John Howe

#arkenstone #lordoftherings #tolkien


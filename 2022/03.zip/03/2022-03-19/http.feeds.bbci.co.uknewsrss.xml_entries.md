# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Street fighting in Mariupol and hypersonic missiles: Ukraine war daily round-up
 - [https://www.bbc.co.uk/news/world-europe-60807537?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60807537?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 20:20:33+00:00

Fierce fighting on Mariupol's streets, and Russia denies its cosmonauts wore Ukrainian colours in space.

## From waitress to cafe owner, all while still a teenager
 - [https://www.bbc.co.uk/news/uk-scotland-north-east-orkney-shetland-60754369?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-north-east-orkney-shetland-60754369?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 19:26:45+00:00

Chloe Campbell was 15 when she got a job in a Moray cafe - four years later she is the new boss.

## Ukraine: Brit finds refugee to host after Polish trip
 - [https://www.bbc.co.uk/news/uk-england-lancashire-60808449?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lancashire-60808449?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 17:46:17+00:00

A British man who flew to Poland to find a refugee to host says he is waiting to bring him to the UK.

## Ukraine conflict: Scores feared dead after Russia attack on Mykolaiv barracks
 - [https://www.bbc.co.uk/news/world-europe-60807636?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60807636?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 15:49:46+00:00

A source tells the BBC that up to 200 soldiers were at the Mykolaiv barracks when missiles hit.

## Hodgkinson pulls out of World Indoor Championships 800m because of injury
 - [https://www.bbc.co.uk/sport/athletics/60806121?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/athletics/60806121?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 13:22:22+00:00

Ukraine's Yaroslava Mahuchikh wins an emotional gold in the women's high jump at the World Athletics Indoor Championships in Belgrade.

## Clerkenwell murder probe after woman, 19, dies
 - [https://www.bbc.co.uk/news/uk-england-london-60805625?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-60805625?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 13:14:21+00:00

A woman has died after being found with serious injuries at a student halls in central London.

## Ukraine: Fire engine convoy leaves UK with vital supplies for firefighters
 - [https://www.bbc.co.uk/news/uk-england-kent-60806091?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-kent-60806091?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 12:04:35+00:00

The 22 vehicles containing equipment offered from across the UK will reach Poland in three days.

## Russians board International Space Station in Ukrainian colours
 - [https://www.bbc.co.uk/news/world-europe-60804949?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60804949?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 11:13:38+00:00

Three cosmonauts ditch the standard-issue Russian uniforms in an apparent show of solidarity.

## Women's World Cup: Australia batters achieve record run chase to beat India - highlights
 - [https://www.bbc.co.uk/sport/av/cricket/60806142?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/60806142?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 10:30:44+00:00

Watch Australia's best shots as they complete the highest chase in Women's World Cup history to beat India and reach the semi-finals.

## War in Ukraine: Gordon Brown backs Nuremberg-style trial for Putin
 - [https://www.bbc.co.uk/news/uk-60803155?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60803155?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 10:24:33+00:00

Gordon Brown and Sir John Major join calls for an international tribunal to investigate Russia.

## Australia book Women's World Cup semi spot
 - [https://www.bbc.co.uk/sport/cricket/60804190?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/60804190?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 09:07:38+00:00

Australia complete the highest chase in Women's World Cup history to beat India and reach the semi-finals.

## Biggar and Jones set for milestones as Wales host Italy
 - [https://www.bbc.co.uk/sport/rugby-union/60753312?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/60753312?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 07:15:51+00:00

Team news, match preview and statistics for Saturday's match between Wales and Italy at the Principality Stadium.

## Disability: Bedbound Gwynedd woman can only stare at ceiling
 - [https://www.bbc.co.uk/news/uk-wales-60768056?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-60768056?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 07:04:15+00:00

A rare genetic condition has left Jenny Rowbory bedbound for more than a decade.

## High-definition France bring England struggles into focus
 - [https://www.bbc.co.uk/sport/rugby-union/60802201?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/60802201?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 06:17:04+00:00

France are fully focused on their Grand Slam bid but England are searching for direction and shape as the pressure grows on head coach Eddie Jones.

## Lupin: Seven charged over armed heist on Paris filming set
 - [https://www.bbc.co.uk/news/world-europe-60804051?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60804051?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 05:17:36+00:00

Around 20 hooded attackers used fireworks to steal €300,000 worth of equipment from the crew.

## Comic Relief: Red Nose Day raises £42m in star-studded show
 - [https://www.bbc.co.uk/news/entertainment-arts-60792779?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60792779?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 04:29:43+00:00

Dawn French, Jennifer Saunders, Matt Lucas and David Walliams featured in the Red Nose Day broadcast.

## Assad: Syria's leader makes historic visit to UAE
 - [https://www.bbc.co.uk/news/world-middle-east-60804050?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-60804050?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 03:16:30+00:00

It marks Bashar al-Assad's first visit to an Arab country since the Syrian civil war began in 2011.

## UK's safe level for tap water too high - scientists
 - [https://www.bbc.co.uk/news/science-environment-60761972?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-60761972?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 01:00:38+00:00

Experts say the UK should reduce the amount of toxic "forever chemicals" allowed in drinking water.

## How Kremlin accounts manipulate Twitter
 - [https://www.bbc.co.uk/news/technology-60790821?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-60790821?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 00:34:41+00:00

One of the prime sources for fake news on Twitter comes straight from the Kremlin's network of Twitter accounts.

## Ukraine: How crowdsourcing is rescuing people from the war zone
 - [https://www.bbc.co.uk/news/technology-60785339?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-60785339?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 00:34:03+00:00

Volunteers inside and outside Ukraine are working together to help civilians escape the war safely.

## Ukraine war: Putin has redrawn the world - but not the way he wanted
 - [https://www.bbc.co.uk/news/world-europe-60767454?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60767454?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 00:33:33+00:00

Because of his miscalculations, there's a new iron curtain at the Russian leader’s door - writes Allan Little

## Ukraine: What have been Russia's military mistakes?
 - [https://www.bbc.co.uk/news/world-60798352?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-60798352?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 00:32:59+00:00

Senior Western defence and intelligence experts outline the battlefield errors made by Moscow.

## Sri Lanka tests UN's patience on human rights
 - [https://www.bbc.co.uk/news/world-asia-60739120?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-60739120?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 00:20:04+00:00

President Rajapaksa is resisting efforts to investigate alleged war crimes and improve a dismal rights record.

## Tanzania viewpoint: What President Samia has achieved in her first year
 - [https://www.bbc.co.uk/news/world-africa-60765848?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-60765848?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 00:15:33+00:00

After years of authoritarian rule, there are signs of change under the country's first female leader.

## Nazanin Zaghari-Ratcliffe's release: 'If any couple is going to survive this, it's them'
 - [https://www.bbc.co.uk/news/uk-60799708?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60799708?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 00:15:01+00:00

How the bond between Nazanin Zaghari-Ratcliffe and her family helped them endure the darkest of times.

## French elections: Putin's war gives Macron boost in presidential race
 - [https://www.bbc.co.uk/news/world-europe-60793320?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60793320?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 00:14:41+00:00

Russia's invasion of Ukraine has shaken up France's presidential elections, with only three weeks to go.

## Week in pictures: 12 - 18 March 2022
 - [https://www.bbc.co.uk/news/in-pictures-60793496?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-60793496?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 00:10:56+00:00

A selection of powerful images from all over the globe, taken in the past seven days.

## Ukraine war: From wedding dresses to camouflage capes
 - [https://www.bbc.co.uk/news/world-europe-60798650?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60798650?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 00:05:13+00:00

A group of Ukrainian seamstresses who fled the war are helping by making camouflage capes for soldiers.

## Hong Kong: 'My employer kicked me out because I caught Covid'
 - [https://www.bbc.co.uk/news/world-asia-china-60792822?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-60792822?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 00:04:05+00:00

'Lenlen' is one of several foreign domestic workers made homeless amid Hong Kong's Covid wave.

## Ukraine war: Jewish children airlifted to Israel
 - [https://www.bbc.co.uk/news/world-60785620?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-60785620?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-19 00:01:22+00:00

In Israel, some 90 Ukrainian children have been dressing up for the joyful Jewish holiday of Purim.


## The British government reportedly asked when Microsoft would 'get rid' of algorithms | Windows Central
 - [https://www.windowscentral.com/british-government-reported-asked-when-microsoft-would-get-rid-algorithms](https://www.windowscentral.com/british-government-reported-asked-when-microsoft-would-get-rid-algorithms)
 - RSS feed: https://www.windowscentral.com
 - date published: 2022-03-19 16:34:31.762842+00:00

Nadine Dorries, who is the UK's secretary for technology, asked Microsoft to "get rid" of algorithms, according to sources at Politico.


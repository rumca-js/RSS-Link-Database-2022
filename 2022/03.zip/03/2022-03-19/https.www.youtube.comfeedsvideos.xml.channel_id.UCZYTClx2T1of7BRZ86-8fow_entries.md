# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## 5 Mysteries Science Created... and Then Solved
 - [https://www.youtube.com/watch?v=403YL_uaY7I](https://www.youtube.com/watch?v=403YL_uaY7I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-03-20 00:00:00+00:00

Head to https://linode.com/scishow to get a $100 60-day credit on a new Linode account. Linode offers simple, affordable, and accessible Linux cloud solutions and services.

Asking questions almost always leads to finding answers, but those answers will often pose even more questions. Here are five mysteries started and later solved by science.

Hosted by: Hank Green

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Tomás Lagos González, Sam Lutfi. Bryan Cloer, Christoph Schwanke, Kevin Bealer, Jacob, Jason A Saslow, Nazara, Tom Mosner, Ash, Eric Jensen, Jeffrey Mckishen, Matt Curls, Alex Hackman, Christopher R Boucher, Piya Shedden, Jeremy Mysliwiec, charles george, Chris Peters, Adam Brainard, Dr. Melvin Sanicas, Harrison Mills, Silas Emrys, Alisa Sherbow

----------
#SciShow
----------
Sources:
https://www.nature.com/articles/ncomms13158.pdf 
https://www.science.org/content/article/early-cave-art-reveals-elusive-higgs-bison 
https://www.mdpi.com/1424-2818/10/3/65 
https://www.youtube.com/watch?v=2IYEDP3wO5k 
https://www.researchgate.net/publication/304743150_Cairncross_B_1998_Cosmic_cannonballs_a_rational_explanation_South_African_Lapidary_Magazine_vol_30_No_1_4-6 
https://www.researchgate.net/publication/325973139_The_Mysterious_Spheres_of_Ottosdal_South_Africa 
https://en.wikipedia.org/wiki/File:Ottosdal1.jpg 
https://www.atlasobscura.com/places/klerksdorp-spheres 
https://www.livescience.com/mars-blueberries-signs-of-water 
https://www.sciencedirect.com/science/article/abs/pii/S0037073810002939  
https://www.nature.com/articles/nature25014.pdf
https://phys.org/news/2017-12-thin-airmicrobe-mystery.html 
https://phys.org/news/2020-08-fossil-mystery-super-long-necked-reptiles-ocean.html 
https://www.cell.com/action/showPdf?pii=S0960-9822%2820%2931017-4 
https://www.nytimes.com/2015/07/07/science/hallucigenia-cambrian-explosions-strange-looking-poster-child.html 
https://www.sciencedaily.com/releases/2020/08/200806111849.htm 
https://palaeo-electronica.org/content/2019/2870-revision-of-tanystropheus 
https://journals.plos.org/plosone/article/file?id=10.1371/journal.pone.0146825&type=printable
https://www.sciencedaily.com/releases/2021/10/211020135914.htm 

Image Sources:
https://tinyurl.com/3rwxhdap
https://tinyurl.com/mw6tfvc6
https://www.storyblocks.com/video/stock/caveman-skull-australopithecus-and-evolution-4mw_nehogijqo2bto
https://www.istockphoto.com/photo/european-bison-gm1365435066-436301462
https://www.istockphoto.com/photo/european-wood-bison-gm941140448-257242486
https://www.istockphoto.com/photo/holstein-cows-in-the-pasture-gm1063058974-284208282
https://www.istockphoto.com/photo/cow-and-calf-bison-gm481257608-69262109
https://www.nature.com/articles/ncomms13158/figures/1
https://tinyurl.com/2p9neyux
https://tinyurl.com/6fu82dkv
https://www.flickr.com/photos/biodivlibrary/6358190883/
https://www.storyblocks.com/video/stock/flying-over-the-snow-coveredtundra-bdfxcf7zik5meyrlq
https://commons.wikimedia.org/wiki/File:Ottosdal1.jpg
https://ncse.ngo/mysterious-spheres-ottosdal-south-africa
https://commons.wikimedia.org/wiki/File:View_from_summit_of_Pikes_Peak_3.jpg
https://commons.wikimedia.org/wiki/File:Concretions_at_Glenafric.jpg
https://tinyurl.com/bdy2w7cu
https://www.storyblocks.com/video/stock/geology-sedimentary-rock-structures-jbesjtm
https://the-public-domain-review.imgix.net/collections/henrique-alvim-correa-war-of-the-worlds/laguerredesmonde00well_0123.jpg?w=600
https://mars.nasa.gov/resources/6944/martian-blueberries/
https://tinyurl.com/2p8zsa9a
https://commons.wikimedia.org/wiki/File:Eubacteria_(259_01)_Micrococcus_luteus_bacteria.jpg
https://www.storyblocks.com/video/stock/panning-of-a-massive-glacier-in-the-arctic-ranntqgjxiuef2zu7
https://www.storyblocks.com/video/stock/slow-motion-of-a-massive-glacier-in-the-cold-arctic-ha-k6pkxxiuspihdg
https://commons.wikimedia.org/wiki/File:Tanystropheus_longobardicus_4.JPG
https://commons.wikimedia.org/wiki/File:Tanystrophaeus_recon_6.jpg
https://commons.wikimedia.org/wiki/File:Tanystropheus_meridensis.JPG
https://en.wikipedia.org/wiki/Tanystropheus#/media/File:Tanystropheus.jpg
https://commons.wikimedia.org/wiki/File:Tanystropheus_longobardicus_1.JPG
https://en.wikipedia.org/wiki/The_Explorers_Club#/media/File:Explorers_Club_Headquarters.jpg
https://commons.wikimedia.org/wiki/File:Explorers_Club_sign_(82355).jpg
https://tinyurl.com/mrx5fdwu
https://commons.wikimedia.org/wiki/File:Megatherium_americanum_Marcus_Burkhardt.jpg
https://commons.wikimedia.org/wiki/File:Green_Sea_Turtle,_Cura%C3%A7ao.jpg
https://www.istockphoto.com/photo/woolly-mammoths-gm1133041268-300608511
https://www.istockphoto.com/photo/green-sea-turtle-gm1019266316-273933055

## Antimony: The Life-Saving Toxin
 - [https://www.youtube.com/watch?v=Tf0hPi3uj5c](https://www.youtube.com/watch?v=Tf0hPi3uj5c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-03-19 00:00:00+00:00

Start speaking a new language in 3 weeks with Babbel. Get up to 65% off in your subscription here: https://go.babbel.com/12m65-youtube-scishow-mar-2022/default

Antimony is toxic to inhale, swallow and touch, but it might also save your life.

Hosted by: Stefan Chin

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Tomás Lagos González, Sam Lutfi. Bryan Cloer, Christoph Schwanke, Kevin Bealer, Jacob, Jason A Saslow, Nazara, Tom Mosner, Ash, Eric Jensen, Jeffrey Mckishen, Matt Curls, Alex Hackman, Christopher R Boucher, Piya Shedden, Jeremy Mysliwiec, charles george, Chris Peters, Adam Brainard, Dr. Melvin Sanicas, Harrison Mills, Silas Emrys, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow
----------
Sources:
https://doi.org/10.1016/j.sjbs.2021.06.044 
https://pubs.rsc.org/en/content/articlehtml/2015/ra/c5ra02987b 
https://www.pmcplastics.com/materials/pvc-flexible/ 
https://doi.org/10.1039/C4RA14271C 
https://iopscience.iop.org/article/10.1149/1.2761829/meta 
https://www.versaperm.com/materials/PET%20Polyethylene%20terephthalate%20-%20vapour%20permeability.php 
https://www.mysciencework.com/patent/show/process-producing-polyethylene-terephthalate-using-specific-catalyst-stabilizer-system-EP0826713A1 
https://doi.org/10.1038/nchem.2134 
https://doi.org/10.1016/j.envpol.2014.05.012 
https://doi.org/10.1016/j.scitotenv.2016.04.184 
https://doi.org/10.1016/j.watres.2007.07.048 
http://dx.doi.org/10.4197/Met.28-1.10 
https://doi.org/10.1016/j.yrtph.2020.104824 
https://www.lenntech.com/periodic/elements/sb.htm 
https://www.nature.com/articles/aps2008107.pdf 
https://www.hindawi.com/journals/mbi/2011/571242/ 

https://commons.wikimedia.org/wiki/File:Nerium_oleander_flowers_leaves.jpg
https://commons.wikimedia.org/wiki/File:Antimony-4.jpg
https://commons.wikimedia.org/wiki/File:Periodic_Table-1.png
https://commons.wikimedia.org/wiki/File:Antimony_massive.jpg
https://www.istockphoto.com/photo/corrugated-pipe-gm1279922073-378376013
https://www.istockphoto.com/photo/polyester-fiber-synthetic-fabrics-eco-friendly-textile-recycled-recyclable-plastic-gm1335269806-417074692
https://commons.wikimedia.org/wiki/File:Taenia_saginata_adult_5260_lores.jpg

https://www.istockphoto.com/photo/the-study-parasite-or-worms-is-a-freshwater-fish-parasite-in-laboratory-gm1336129601-417499734
https://commons.wikimedia.org/wiki/File:Leishmania_donovani_01.png
https://www.istockphoto.com/photo/human-cancer-cell-gm1311222341-400382806
https://commons.wikimedia.org/wiki/File:Breast_cancer_cells.jpg
https://commons.wikimedia.org/wiki/File:Acute_leukemia-ALL.jpg

https://commons.wikimedia.org/wiki/File:Antimony_massive.jpg
https://commons.wikimedia.org/wiki/File:49-aspetti_di_vita_quotidiana,_vomito,Taccuino_Sanitatis,_Ca.jpg
https://commons.wikimedia.org/wiki/File:Antimony-119743.jpg


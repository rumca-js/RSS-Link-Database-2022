# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I Have the Power of the Sun - New House Solar Install
 - [https://www.youtube.com/watch?v=hBYbodmCBUQ](https://www.youtube.com/watch?v=hBYbodmCBUQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-03-20 00:00:00+00:00

Thanks to Epic Games for sponsoring - Add PC Building Simulator 2 to your wishlist here: https://www.epicgames.com/store/en-US/p/pc-building-simulator-2

A big part of the renovations at my new house have been focused on efficiency and environmental improvements, and today with the help of DualSun, we're installing new WATER COOLED solar panels.

Discuss on the forum: https://linustechtips.com/topic/1419368-i-have-the-power-of-the-sun/

Check out DualSun solar panels: https://dualsun.com/en/

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro

## I have SO many questions - Intel $5,000 Extreme Tech Upgrade
 - [https://www.youtube.com/watch?v=iuL1NTNGMA8](https://www.youtube.com/watch?v=iuL1NTNGMA8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-03-19 00:00:00+00:00

Thanks to Intel for continuing to sponsor this series! Buy an Intel Core i9-10850K: https://geni.us/0Ci11ic

Buy an EVGA RTX 3080 XC3: https://geni.us/QSo0

Buy an EK-AIO 360 D-RGB : https://lmg.gg/nE8ey

Buy a Noctua NH-D15: https://geni.us/AMfIf

Buy an MSI PRO Z490-A: https://geni.us/VJ3BAd

Buy a Ballistix 32GB 3600Mhz Kit: https://geni.us/1ewYm

Buy a Samsung 970 Evo 500GB NVME: https://geni.us/jaE39zm

Buy a 4000D Airflow White: https://geni.us/Ir8M

Buy a Corsair RMx 850W PSU: https://geni.us/pYNld

Buy an LG CX 55": https://geni.us/rlWv4

Buy an IronWolf NAS 8TB: https://geni.us/6HYhOpC

Buy a Yamaha HS8 Monitors: https://geni.us/slYGP

Check out Unraid: https://lmg.gg/fRPSd

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on our community forum: https://linustechtips.com/topic/1419161-i-have-so-many-questions-intel-5000-extreme-tech-upgrade/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

Special Intro by MBarek Abdelwassaa
https://www.instagram.com/mbarek_abdel/

CHAPTERS
---------------------------------------------------
0:00 Intro
1:56 Tour
7:00 PC Build
15:42 Room Setup
19:39 Audio
24:12 TV


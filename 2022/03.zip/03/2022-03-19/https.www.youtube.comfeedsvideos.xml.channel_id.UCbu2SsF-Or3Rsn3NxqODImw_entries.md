# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Fortnite Chapter 3 Season 2 Resistance Story Trailer
 - [https://www.youtube.com/watch?v=hVDQNxEuI88](https://www.youtube.com/watch?v=hVDQNxEuI88)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-03-20 00:00:00+00:00

Check out the Fortnite Chapter 3 Season 2 Story Trailer! 

Watch the latest trailer for the newest season coming to Fortnite. We get a look at Dr. Sloane with Prowler, as well as Agent Jones with Lara Croft. Additionally we see Dr. Strange, Iron Man, Black Widow, members of the seven and more.

Multiple vehicles were showcased including planes, tanks, battle buses, blimps, and more. Hard to say what will be available for players to drive but check it out.

#Fortnite #Resistance

## So You're Getting Back Into GTA Online…
 - [https://www.youtube.com/watch?v=3ddEF1i5GP0](https://www.youtube.com/watch?v=3ddEF1i5GP0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-03-20 00:00:00+00:00

If you’re curious about starting or jumping back into GTA Online now is the time. The streets of Los Santos have never looked better and Rockstar Games is ready to hold your hand through the process. Join Richie as he breaks down the process of returning to Grand Theft Auto Online for PS5 and Xbox Series X/S.

GTA Online has been around for nearly 10 years and with the launch of the next-gen version, there's no sign of slowing down. Since you may be asking yourself if it's worth diving back into the mean streets of Los Santos with a fresh start, we've made this video to show you exactly what that looks like.

A fresh start in GTA Online can be alluring. You're able to create an all-new custom character, and you're given loads of opportunities to rank up quickly. Not to mention you're given 4 million GTA bucks to get you going. The whole online system has also been streamlined to help new players start off on the right (or wrong) foot. You can now choose from four criminal careers- Executive, Gun Runner, Nightclub Owner, or Biker. From there, the real fun begins. Finding missions, joining crews and ranking up all await first time players. For classic players, the nostalgia will instantly kick in as you re-live early level missions dating back to 2013. Overall GTA Online is in a fun place, so if you're lucky enough to have a PS5 or Xbox Series X/S, it may just be worth it to start fresh.   

#GTAOnline

## Tiny Tina's Wonderlands - Everything To Know
 - [https://www.youtube.com/watch?v=_Avvs-hNH8M](https://www.youtube.com/watch?v=_Avvs-hNH8M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-03-20 00:00:00+00:00

Tiny Tina’s Wonderlands is a spin-off Borderlands game and takes place inside a Bunkers and Badasses roleplaying campaign. Here’s everything you need to know about loot, guns, magic spells, majestic unicorns, starting classes, the tabletop overworld, co-op, and more. 

Tiny Tina’s Wonderlands is Gearbox’s latest take on the Borderlands series and expands on tabletop roleplaying themes from Tiny Tina's Assault on Dragon Keep: A Wonderlands One-Shot Adventure. Dragon’s Keep was originally DLC for Borderlands 2. The game is set inside a Bunkers and Badasses tabletop campaign run by Tiny Tina as the Bunker Master. Wonderlands sports a cast of new characters, but features several returning faces as well, like Tina, Butt Stallion, and Mr. Torgue. Newer characters Valentine, Frette, and The Dragon Lord are played by notable voice actors Brooklyn Nine-Nine’s Andy Samberg, comedian, actor, writer Wanda Sykes, and Arrested Development’s, Will Arnett. Ashly Burch, fresh from her star turn as Aloy in Horizon Forbidden West returns as Tina.

The gameplay in Wonderlands departs from the Borderlands series with changes like a tabletop overworld, random encounters, a host of magic spells, wards, new classes based around the use of swords, hammers, and other fantasy weapons, as well as lots and lots of medieval-themed guns. Players are no longer locked to pre-made Vault Hunters and can fully customize their character, choose a backstory, voice, and pick one of six starting classes: the Brr-Zerker, Clawbringer Graveborn, Spellshot, Spore Warden, and Stabbomancer. Each class can be combined with any one of the other classes later in the game, which is called multiclassing. That allows for min/max builds or just bringing along multiple pets. 

Wonderlands releases on March 25th with the Season One pass starting April 21st. The game will launch for PC, PS4, PlayStation 5, Xbox One, and Xbox Series X|S, although you should be aware that only the two more expensive editions of the game have new-gen optimization

## Firearms Expert Reacts To PUBG: Battlegrounds’ Guns
 - [https://www.youtube.com/watch?v=q8knTq0lOZg](https://www.youtube.com/watch?v=q8knTq0lOZg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-03-19 00:00:00+00:00

Jonathan Ferguson, a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries, breaks down the weaponry of PUBG: Battlegrounds, including the Degtyaryov machine gun, a suppressed Thompson submachine gun, and the South Korean Daewoo K2 assault rifle.

00:00 - Opening
00:47 - SLR 
03:10 - Model 1928 Thompson Submachine gun
05:46 - Daewoo K2 Assault Rifle
07:10 - FB Beryl
08:51 - Winchester 1894
09:53 - Degtyaryov machine gun
11:25 - Winchester Model 1897
13:20 - MP5K
15:51 - M24 Sniper Weapon System
16:48 - M16A4 rifle
18:12 - FN P90
20:55 - Ending

In the latest video in the Firearm Expert Reacts series, Jonathan Ferguson--a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries--breaks down the guns of PUBG: Battlegrounds and compares them to their potential real-life counterparts.

Firearms Expert Reacts playlist - https://www.youtube.com/watch?v=y4T78VQoWUs&list=PLpg6WLs8kxGMgYb13XjPgOKbm5O-CDq7R

If you're interested in seeing more of Jonathan's work, you can check out more from the Royal Armouries right here. - https://www.youtube.com/user/RoyalArmouries

If you would like to support the Royal Armouries, you can make a charitable donation to the museum here. - https://royalarmouries.org/support-us/donations/

And if you would like to become a member of the Royal Armouries, you can get a membership here. - https://royalarmouries.org/support-us/membership/

You can either purchase Jonathan's book here. - https://www.headstamppublishing.com/bullpup-rifle-book

Or at the Royal Armouries shop here. - https://shop.royalarmouries.org/collections/thorneycroft-to-sa80-british-bullpup-firearms-1901-2020

You can subscribe to the Armax Journal that Jonathan Associate Edited here: https://www.armaxjournal.org/

## Guilty Gear -Strive- ARCREVO America Finals
 - [https://www.youtube.com/watch?v=-0TVMCke-e8](https://www.youtube.com/watch?v=-0TVMCke-e8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-03-19 00:00:00+00:00

The best Guilty Gear Strive players are colliding for one full day of tournament action that's not to be missed! All roads have led to the ARCREVO America 2021 Finals, where the best of the best will clash to crown the ARCREVO America champion. Presented by Guilty Gear Strive. 
#GuiltyGearStrive #ARCREVO2021

## Mario Kart 8 Deluxe - Booster Course Pass Graphics Comparison
 - [https://www.youtube.com/watch?v=ooQa3koR85Q](https://www.youtube.com/watch?v=ooQa3koR85Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-03-19 00:00:00+00:00

With Wave 1 of the new Booster Course Pass coming to Mario Kart 8 Deluxe and bringing back courses from previous Mario Kart games, we've put the old and new courses head-to-head to see the graphical differences.

It’s been 5 years since the release of Mario Kart 8 Deluxe, and 8 years since  Mario Kart 8 on Wii U, and while many had hoped for Mario Kart 9, Nintendo has decided to release DLC for 8 Deluxe instead. The Booster Course Pass will include stages from previous Mario Kart entries and will be released in waves until the end of 2023.

In this video we’ll be comparing Choco Mountain from Mario Kart 64 on Nintendo 64, Sky Garden from Mario Kart: Super Circuit on Game Boy Advance, and Shroom Ridge from Mario Kart DS on Nintendo DS. Mario Kart 64 was captured on Nintendo Switch through the Nintendo 64 - Nintendo Switch Online app, Mario Kart: Super Circuit was captured on the GBA Wii U Virtual Console, and Mario Kart DS was captured on the DS Wii U Virtual Console. Mario Kart 8 Deluxe was captured on the Nintendo Switch as well.

Mario Kart 8 Deluxe - Booster Course Pass is available now for $24.99, or free if you buy the Nintendo Switch Online + Expansion Pass subscription. Wave 1 includes Paris Promenade, Toad Circuit, Choco Mountain, Coconut Mall, Tokyo Blur, Shroom Ridge, Sky Garden, and Ninja Hideaway. Additional waves will be revealed in the future. For more on Mario Kart 8 Deluxe and all things Nintendo consider subscribing to GameSpot.

Timestamps:
00:00 - Choco Mountain
02:48 - Shroom Ridge
06:12 - Sky Garden

#MarioKartDeluxe


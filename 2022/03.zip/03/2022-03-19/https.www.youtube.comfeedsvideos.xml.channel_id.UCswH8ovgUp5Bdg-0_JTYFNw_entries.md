# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## The Great Reset: This Is How He Does It
 - [https://www.youtube.com/watch?v=1i5Jdk4Zh9E](https://www.youtube.com/watch?v=1i5Jdk4Zh9E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-03-20 00:00:00+00:00

WEF's Young Global Leaders program has the world’s most important leaders & tech CEOs  like Bill Gates, Mark Zuckerberg, Larry Page of Google & the founder of Wikipedia. This was explained by Nick Corbishley, who is the author of Scanned: Why Vaccine Passports and Digital IDs Will Mean the End of Privacy and Personal Freedom. #KlausSchwab #TheGreatReset #WEF 

Nick's New Book: Scanned - https://www.chelseagreen.com/product/scanned/
Article: https://medium.com/id2020/immunization-an-entry-point-for-digital-identity-ea37d9c3b77e

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Pfizer's 4th Vaccine Dose Is Scientific, Right?
 - [https://www.youtube.com/watch?v=XlDGJ0xoUuQ](https://www.youtube.com/watch?v=XlDGJ0xoUuQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-03-19 00:00:00+00:00

Pfizer’s CEO has said that a fourth booster shot 'is necessary'. But it’s definitely not about profit. The fact that it’s the most lucrative medicine in history has nothing to do with it. Don’t you even suggest it. #Pfizer #Pandemic #Covid

References
https://www.nytimes.com/2021/12/23/world/middleeast/israel-vaccine-4th-dose.html

https://www.theguardian.com/commentisfree/2022/feb/08/big-pharma-global-vaccine-rollout-covid-pfizer

https://thehill.com/policy/healthcare/598026-pfizer-ceo-says-a-fourth-booster-shot-is-necessary

https://www.businessinsider.com/lawmakers-bought-sold-covid-19-related-stocks-during-pandemic-2021-12?r=US&IR=T

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week - Pojedynek o Ukrainę
 - [https://www.youtube.com/watch?v=TmuHGb4ndfw](https://www.youtube.com/watch?v=TmuHGb4ndfw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-03-20 00:00:00+00:00

Poza tym dziś w odcinku:
00:00 Czy jesteśmy w stanie żyć bez Xiaomi
00:41 Będziemy kupować z lekkim obrzydzeniem
00:57 Dobry wieczór
01:05 Współpraca chińskich firm z Rosją
02:46 "Ochrona" planety przez Apple i cyber koza
03:37 Legalizacja krypto na Ukrainie
04:10 NFT na Instagramie
04:30 Upadek YouTube Vanced
06:33 Ban Kanyego na Twitterze
08:30 Nowe Samsungi i iPhone SE
09:34 Nowy smartphone od Nothing?
10:02 Nowe drony od DJI
10:40 Pożegnanko
10:47 Znośnego tygodnia i...
10:49 Klawiaturobranie

Źródła:
Klawiaturobranie tu: https://www.instagram.com/znosne_pl/
Xiaomi zapowiedziało nowe produkty: https://bit.ly/37Mq1iX
Czy DJI wspiera wojska rosyjskie: https://bit.ly/3N1p9Hv
Apple zarobiło miliardy pozbywając się ładowarek i słuchawek z pudełek: https://bit.ly/3qmhIAH
Elektryczna koza Kawasaki: https://bit.ly/37LfZyC
Ukraina legalizuje krypto: https://bit.ly/3N3jKQ1
Zuckerberg zapowiada NFT na instagramie: https://engt.co/36zRyDq
YT Vanced kończy działalność: https://bit.ly/3L0govu
YT Vanced a NFT: https://bit.ly/3tnPx6j
Kanye West zbanowany na Insta: https://bit.ly/3IkE4Zv
Pete Davidson nie poleci w kosmos: https://cnn.it/3qkjlPg
Premiera Samsungów A33 i A53: https://bit.ly/3wkaocP
DJI w poniedziałek wypuści drona dla rolników: https://bit.ly/3KXUkSa

https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter


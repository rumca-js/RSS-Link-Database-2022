# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## 2 Księga Królewska || Rozdział 14
 - [https://www.youtube.com/watch?v=XIIlr8BueOE](https://www.youtube.com/watch?v=XIIlr8BueOE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-03-20 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Medytacje wielkopostne [#07] Nie bój się
 - [https://www.youtube.com/watch?v=GD-yWl_P0Bw](https://www.youtube.com/watch?v=GD-yWl_P0Bw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-03-20 00:00:00+00:00

W Wielkim Poście, zapraszamy do wspólnych medytacji. W niedziele, wtorki i czwartki o godz. 17:00, spotkania z Bogiem w słowie i ciszy. W czasie zamętu, czas na zanurzenie się w obecności i pokoju Bożym! Chodźcie spotkać Pana.

@Langustanapalmie  #WielkiPost2022 #światłowciemności

improwizacja: Jan Smoczyński

________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## 2 Księga Królewska || Rozdział 13
 - [https://www.youtube.com/watch?v=fM6BlV3OgCU](https://www.youtube.com/watch?v=fM6BlV3OgCU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-03-19 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#279] Kiedy Bóg pozwala, żeby rozwaliło Ci się życie?
 - [https://www.youtube.com/watch?v=AVA3j1DnRkU](https://www.youtube.com/watch?v=AVA3j1DnRkU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-03-19 00:00:00+00:00

#cnn #dobrewiadomości    @Langustanapalmie 

Kazanko do okienka, czyli komentarz do niedzielnych czytań.

Niedziela, III Tydzień Wielkiego Postu, Rok C, II
Trzecia Niedziela Wielkiego Postu

1. czytanie (Wj 3, 1-8a. 13-15)

Gdy Mojżesz pasł owce swego teścia imieniem Jetro, kapłana Madianitów, zaprowadził owce w głąb pustyni i doszedł do Góry Bożej Horeb. Wtedy ukazał mu się Anioł Pański w płomieniu ognia, ze środka krzewu. Mojżesz widział, jak krzew płonął ogniem, a nie spłonął od niego.
Wtedy Mojżesz powiedział do siebie: «Podejdę, żeby się przyjrzeć temu niezwykłemu zjawisku. Dlaczego krzew się nie spala?» Gdy zaś Pan ujrzał, że podchodzi, by się przyjrzeć, zawołał Bóg do niego ze środka krzewu: «Mojżeszu, Mojżeszu!»
On zaś odpowiedział: «Oto jestem». Rzekł mu Bóg: «Nie zbliżaj się tu! Zdejmij sandały z nóg, gdyż miejsce, na którym stoisz, jest ziemią świętą». Powiedział jeszcze Pan: «Jestem Bogiem ojca twego, Bogiem Abrahama, Bogiem Izaaka i Bogiem Jakuba».
Mojżesz zasłonił twarz, bał się bowiem zwrócić oczy na Boga.
Pan mówił: «Dosyć napatrzyłem się na udrękę ludu mego w Egipcie i nasłuchałem się narzekań jego na ciemięzców, znam więc jego uciemiężenie. Zstąpiłem, aby go wyrwać z rąk Egiptu i wyprowadzić z tej ziemi do ziemi żyznej i przestronnej, do ziemi, która opływa w mleko i miód».
Mojżesz zaś rzekł Bogu: «Oto pójdę do Izraelitów i powiem im: Bóg ojców naszych posłał mnie do was. Lecz gdy oni mnie zapytają, jakie jest Jego imię, cóż im mam powiedzieć?» Odpowiedział Bóg Mojżeszowi: «Jestem, który jestem». I dodał: «Tak powiesz synom Izraela: Jestem posłał mnie do was».
Mówił dalej Bóg do Mojżesza: «Tak powiesz Izraelitom: Pan, Bóg ojców waszych, Bóg Abrahama, Bóg Izaaka i Bóg Jakuba posłał mnie do was. To jest imię moje na wieki i to jest moje zawołanie na najdalsze pokolenia».

2. czytanie (1 Kor 10, 1-6. 10-12)

Nie chciałbym, bracia, byście nie wiedzieli, że nasi ojcowie wszyscy co prawda zostawali pod obłokiem, wszyscy przeszli przez morze i wszyscy byli ochrzczeni w imię Mojżesza, w obłoku i w morzu; wszyscy też spożywali ten sam pokarm duchowy i pili ten sam duchowy napój. Pili zaś z towarzyszącej im duchowej skały, a skałą był Chrystus. Lecz w większości z nich nie upodobał sobie Bóg; polegli bowiem na pustyni.
Stało się zaś to wszystko, by mogło posłużyć za przykład dla nas, abyśmy nie byli skłonni do złego, tak jak oni zła pragnęli. Nie szemrajcie, jak niektórzy z nich szemrali – i zostali wytraceni przez dokonującego zagłady.
A wszystko to przydarzało się im jako zapowiedź rzeczy przyszłych, spisane zaś zostało ku pouczeniu nas, których dosięga kres czasów. Niech przeto ten, komu się zdaje, że stoi, baczy, aby nie upadł.

Ewangelia (Łk 13, 1-9)

W tym czasie przyszli jacyś ludzie i donieśli Jezusowi o Galilejczykach, których krew Piłat zmieszał z krwią ich ofiar.
Jezus im odpowiedział: «Czyż myślicie, że ci Galilejczycy byli większymi grzesznikami niż inni mieszkańcy Galilei, iż to ucierpieli? Bynajmniej, powiadam wam; lecz jeśli się nie nawrócicie, wszyscy podobnie zginiecie. Albo myślicie, że owych osiemnastu, na których zwaliła się wieża w Siloam i zabiła ich, było większymi winowajcami niż inni mieszkańcy Jeruzalem? Bynajmniej, powiadam wam; lecz jeśli się nie nawrócicie, wszyscy tak samo zginiecie».
I opowiedział im następującą przypowieść: «Pewien człowiek miał zasadzony w swojej winnicy figowiec; przyszedł i szukał na nim owoców, ale nie znalazł. Rzekł więc do ogrodnika: „Oto już trzy lata, odkąd przychodzę i szukam owocu na tym figowcu, a nie znajduję. Wytnij go, po co jeszcze ziemię wyjaławia?” Lecz on mu odpowiedział: „Panie, jeszcze na ten rok go pozostaw, aż okopię go i obłożę nawozem; i może wyda owoc. A jeśli nie, w przyszłości możesz go wyciąć”».

________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

Niedzielnik na ROK C
→ https://wdrodze.pl/produkt/niedzielnik-c-komentarze-do-czytan-adam-szustak/

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Listy z Ukrainy [#13] Hulajnogą po Kijowie
 - [https://www.youtube.com/watch?v=1NY7ojFceBM](https://www.youtube.com/watch?v=1NY7ojFceBM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-03-19 00:00:00+00:00

@langustanapalmie #ukraina #listyzukrainy
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#1047] Szarość
 - [https://www.youtube.com/watch?v=Uhyn5fGpDmY](https://www.youtube.com/watch?v=Uhyn5fGpDmY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-03-19 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
Strona zbiórki → https://charytatywnie.fundacjamalak.pl/

Tradycyjne przelewy:
Nr konta do wpłat w PLN: 42 2490 0005 0000 4600 1184 3564 
IBAN: PL 42 2490 0005 0000 4600 1184 3564
Tytułem: UKRAINA

Fundacja MALAK
ul. Śliwkowa 4
31-982 Kraków
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.


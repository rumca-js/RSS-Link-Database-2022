## The Coudenhove-Kalergi Plan – The Genocide of the Peoples of Europe
 - [https://expose-news.com/2022/03/19/the-genocide-of-the-peoples-of-europe/](https://expose-news.com/2022/03/19/the-genocide-of-the-peoples-of-europe/)
 - RSS feed: https://expose-news.com
 - date published: 2022-03-19 20:15:46+00:00

The Coudenhove-Kalergi Plan – The Genocide of the Peoples of Europe


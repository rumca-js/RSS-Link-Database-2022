# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Alt-J - U&Me (live performance for The Current)
 - [https://www.youtube.com/watch?v=vPRmu_NJ1KU](https://www.youtube.com/watch?v=vPRmu_NJ1KU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-03-19 00:00:00+00:00

Before the British indie-rock act @altj makes a stop in Minnesota on their 2022 tour, they shared a live performance of "U&Me" from their new record, 'The Dream'.

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## alt-J - Get Better (live performance for The Current)
 - [https://www.youtube.com/watch?v=KfnuPp73aHc](https://www.youtube.com/watch?v=KfnuPp73aHc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-03-19 00:00:00+00:00

Before the Grammy-winning British indie-rock act @altj makes a stop in Minnesota on their 2022 tour, they shared a live performance of "Get Better" from their 2022 record, 'The Dream'. Plus, check out 

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## alt-J - Hard Drive Gold (live performance for The Current)
 - [https://www.youtube.com/watch?v=fxMTTksSq2A](https://www.youtube.com/watch?v=fxMTTksSq2A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-03-19 00:00:00+00:00

Before the Grammy-winning British indie-rock act @altj makes a stop in Minnesota on their 2022 tour, they shared a live performance of "Hard Drive Gold" from their new record, 'The Dream'. Don't miss Gus Unger-Hamilton's conversation with The Current about the new record: https://www.youtube.com/watch?v=c76lnG2r8Ts

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## alt-J - Left Hand Free (live performance for The Current)
 - [https://www.youtube.com/watch?v=JSXdCVCb9u4](https://www.youtube.com/watch?v=JSXdCVCb9u4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-03-19 00:00:00+00:00

Before the Grammy-winning British indie-rock act @altj makes a stop in Minnesota on their 2022 tour, they shared a live performance of "Left Hand Free" from their 2014 record, 'This Is All Yours'. Plus, don't miss Gus Unger-Hamilton's conversation with The Current about the new record: https://www.youtube.com/watch?v=c76lnG2r8Ts

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## alt-J performing songs from 'The Dream,' and more (live for The Current)
 - [https://www.youtube.com/watch?v=0fQWfR9j2bE](https://www.youtube.com/watch?v=0fQWfR9j2bE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-03-19 00:00:00+00:00

Before the Grammy-winning British indie-rock act @altj makes a stop in Minnesota on their 2022 tour, they shared a four-song performance including tracks from their new record 'The Dream'. Plus, don't miss Gus Unger-Hamilton's conversation with The Current about the new record: https://www.youtube.com/watch?v=c76lnG2r8Ts

Songs Played:
00:00 Hard Drive Gold
02:37 Get Better
08:01 Left Hand Free
10:57 U&Me

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/


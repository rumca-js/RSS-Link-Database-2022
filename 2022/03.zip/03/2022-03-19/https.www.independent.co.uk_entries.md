## Amazon intentionally made it difficult to cancel Prime subscription in secret project | The Independent
 - [https://www.independent.co.uk/tech/amazon-prime-subscription-cancel-secret-project-b2038207.html](https://www.independent.co.uk/tech/amazon-prime-subscription-cancel-secret-project-b2038207.html)
 - RSS feed: https://www.independent.co.uk
 - date published: 2022-03-19 07:08:29.863295+00:00

Project ‘Iliad’ put multiple layers of questions and offers between the main Amazon page and the final cancellation


# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## International critique
 - [https://www.youtube.com/watch?v=JYig50EHX_E](https://www.youtube.com/watch?v=JYig50EHX_E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-03-20 00:00:00+00:00

Hong Kong, massive omicron wave, Africa update video

https://www.youtube.com/watch?v=b_iQGDxtsTA

Wefwafwa’s community health channel

https://www.youtube.com/channel/UCzsLklGgOttU3Se-WGLp7ow

https://www.theguardian.com/commentisfree/2022/mar/18/hong-kong-covid-surge-vaccination-rates

Beaches, theatres, museums, schools, gyms, libraries are shut.

Two people can meet in public

Strategy so far, keep the virus out

Trust issues, controls

Residential blocks suddenly cut off

Unvaccinated over 80

NZ, 2%

HK, 66%

Low levels of natural immunity

Out of coffins

Out of morgue space

Body bags on wards

China

https://www.aljazeera.com/news/2022/3/19/china-reports-first-covid-deaths-since-january-2021

Cases, + 4,365 + 4,051

Deaths, + 2 = 4,638

Fist since January 26th 2021

Zero-COVID strategy

Tens of millions, stay-home orders

Travel bans

Built 8 makeshift hospitals

Quarantine centres

Quarantined for days or weeks

President Xi

China to ‘stick with’ zero-COVID strategy

continue to put people and life at the forefront, stick with scientific accuracy and dynamic-zero, 

and curb the spread of the epidemic as soon as possible

King Canute and the tide (1028)

(Henry of Huntingdon)

https://upload.wikimedia.org/wikipedia/commons/b/b7/Canute_rebukes_his_courtiers.png

South Africa

https://www.nicd.ac.za/diseases-a-z-index/disease-index-covid-19/surveillance-reports/daily-hospital-surveillance-datcov-report/

Africa

https://www.theguardian.com/society/2022/mar/16/global-powers-inch-closer-to-agreement-to-waive-covid-vaccine-patents

Compromise, United States, European Union, India, South Africa, end a deadlock over an intellectual property waiver


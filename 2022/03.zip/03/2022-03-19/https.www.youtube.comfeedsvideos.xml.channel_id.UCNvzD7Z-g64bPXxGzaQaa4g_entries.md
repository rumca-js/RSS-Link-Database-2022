# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 HARDEST Platinum Trophies That Take Countless Hours
 - [https://www.youtube.com/watch?v=yzj_skj0sC4](https://www.youtube.com/watch?v=yzj_skj0sC4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-03-20 00:00:00+00:00

Everybody loves chasing trophies, but only a select few games have near unobtainable Platinums. Here are some of our favorite challenging examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 Elden Ring Locations FREAKIER Than You Thought
 - [https://www.youtube.com/watch?v=Eej4PEm8WNE](https://www.youtube.com/watch?v=Eej4PEm8WNE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-03-19 00:00:00+00:00

Elden Ring (PC, PS5, Xbox Series X/S/One) is filled with tons of creepy locations. Here are some of our favorites.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Samsung Galaxy S23: what we know so far
 - [https://www.techradar.com/news/samsung-galaxy-s23/](https://www.techradar.com/news/samsung-galaxy-s23/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-03-19 07:00:07+00:00

Samsung's next mainstream flagship is already getting leaked, and we also have a wish list for it.

## Samsung Galaxy S23: what we know so far
 - [https://www.techradar.com/news/samsung-galaxy-s23](https://www.techradar.com/news/samsung-galaxy-s23)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-03-19 07:00:07+00:00

Samsung's next mainstream flagship is already getting leaked, and we also have a wish list for it.


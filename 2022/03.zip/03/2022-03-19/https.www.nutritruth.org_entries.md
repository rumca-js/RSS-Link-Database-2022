## The Coudenhove-Kalergi Plan – The Genocide of the Peoples of Europe
 - [https://www.nutritruth.org/single-post/the-coudenhove-kalergi-plan-the-genocide-of-the-peoples-of-europe](https://www.nutritruth.org/single-post/the-coudenhove-kalergi-plan-the-genocide-of-the-peoples-of-europe)
 - RSS feed: https://www.nutritruth.org
 - date published: 2022-03-19 20:15:46+00:00

The Coudenhove-Kalergi Plan – The Genocide of the Peoples of Europe


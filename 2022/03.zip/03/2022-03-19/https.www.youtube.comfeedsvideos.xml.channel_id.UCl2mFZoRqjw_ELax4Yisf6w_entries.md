# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Smart devices get stupider and stupider...
 - [https://www.youtube.com/watch?v=YEZCySVQHEU](https://www.youtube.com/watch?v=YEZCySVQHEU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-03-20 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.tellerreport.com/tech/2022-03-18-aeg-combi-microwave-unusable-after-update--device-thinks-it-is-a-steam-oven.Bkxu7Aa-z9.html

## Unplugging the battery BRICKS this device; you MUST go back to the manufacturer
 - [https://www.youtube.com/watch?v=KGzDCnjgUbc](https://www.youtube.com/watch?v=KGzDCnjgUbc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-03-19 00:00:00+00:00

👉 https://tinyurl.com/rossmatrix
👉 https://www.reddit.com/r/onewheel/comments/pyxob7/a_word_from_our_friends_at_jw_batteries_in/
👉 https://www.youtube.com/watch?v=ZKALUEoRd7E
👉 https://www.ftc.gov/system/files/documents/reports/nixing-fix-ftc-report-congress-repair-restrictions/nixing_the_fix_report_final_5521_630pm-508_002.pdf
👉 https://www.youtube.com/watch?v=aaTFGrPyUoo
👉 https://www.youtube.com/watch?v=Dhuia0skrus

🔵 Desk: https://amzn.to/3njMvN3
🔵 Chair: https://amzn.to/3zOuSdf
🔵 Microphone: https://amzn.to/3JZ2rOy
🔵 Camera: https://amzn.to/3CTk1Av

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ


## Why youtubers are leaving YouTube
 - [https://www.youtube.com/watch?v=A4SxKYCQxo0](https://www.youtube.com/watch?v=A4SxKYCQxo0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3iNdSV_RQU7DHTGpqEW96w
 - date published: 2022-03-20 00:00:00+00:00

🌏 Get The Exclusive NordVPN deal here ➼ https://nordvpn.com/andrei. Use my link to get the 30-day money-back guarantee! ✌

While more and more kids aspire to become famous on the Internet, it's probably relevant to take a look at why more and more youtubers are choosing to leave their channels behind and quit YouTube. It's tempting to watch the big players and fantasize about how great it must be to be in their shoes, or to adopt the hustle mentality and quickly work your way into burnout, but sometimes it's good to listen to the stories of those who've been there and walked away, to understand that life is about a whole lot more than "the grind". 

------------------------------
CREDITS:

Andrei Terbea - Lead Animator

Stefan Popa - Assistant Animator
https://www.instagram.com/jtefe.ro/


The video I mentioned, from Emma Blackery:
https://youtu.be/0iueuDIF24E

------------------------------
MUSIC:

Background track:  "Delusional (Instrumental)" by Spring Gang
Outro song: Joakim Karud - "Loudness & Clarity"
http://youtube.com/joakimkarud

------------------------------
#YouTubers #Leaving #YouTube


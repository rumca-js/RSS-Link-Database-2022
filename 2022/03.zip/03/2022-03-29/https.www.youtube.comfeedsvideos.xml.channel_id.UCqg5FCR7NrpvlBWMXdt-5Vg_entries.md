# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Ghostwire: Tokyo (Zero Punctuation)
 - [https://www.youtube.com/watch?v=MHO1ehzxJ2w](https://www.youtube.com/watch?v=MHO1ehzxJ2w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-03-30 00:00:00+00:00

This week on Zero Punctuation, Yahtzee reviews Ghostwire: Tokyo. 

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#ZeroPunctuation

## Is PlayStation Plus Not Adding First-Party Exclusives at Launch a Mistake? | Breakout
 - [https://www.youtube.com/watch?v=tNkgazX7V1c](https://www.youtube.com/watch?v=tNkgazX7V1c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-03-30 00:00:00+00:00

Sony has revealed their the new PlayStation Plus model with updated tiers to compete with Microsoft's Game Pass, but we're wondering if they're making a mistake to not include their first party games at launch on the service through any tier. Oh, and the sequel to Breath of the Wild 2 got delayed again, so we'll talk about that.

Featuring Nick Calandra, Marty Sliva and KC Nwosu, the freeform podcast dives into a bit of our daily lives, the latest games, movies, tv shows and books, the occasional craft beer review and random topics we find interesting.

New episodes every Wednesday morning from 9 AM to 10:00 AM CT. 

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Yahtzee and KC Play Tiny Tina's Wonderlands | Post-ZP Stream
 - [https://www.youtube.com/watch?v=EEbURnwF5uA](https://www.youtube.com/watch?v=EEbURnwF5uA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-03-30 00:00:00+00:00

SPONSORED BY FANATICAL - Buy Tiny Tina's Wonderlands from the sponsor of today's video - Fanatical - an awesome site to buy officially licensed PC keys at great discounts. Tiny Tina's Wonderlands is currently available to buy at a 16% discount which comes in both standard and Chaotic Great editions.

Check our affiliate link below to get your copy of Tiny Tina's Wonderlands which also has a deluxe edition, and Fanatical will give you an extra 5% discount on your next purchase. https://www.fanatical.com/en/game/tiny-tina-s-wonderlands?ref=escapist

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Yahtzee plays two hours of Tiny Tina's Wonderlands for today's Post-ZP Stream.

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist​

Want to see the next episode a week early? Check out http://www.escapistmagazine.com​ for the latest episodes of your favorite shows.

---



---


The Escapist Merch Store ►►https://teespring.com/stores/the-esca...​
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag​
Follow us on Twitter ►► https://twitter.com/EscapistMag

#ZeroPunctuation

## Ikai | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=U2o5B4ZCLmo](https://www.youtube.com/watch?v=U2o5B4ZCLmo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-03-29 00:00:00+00:00

Will Cruz reviews Ikai, developed by PM Studios and Endflame.

Ikai on Steam: https://store.steampowered.com/app/1315210/Ikai/

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Yahtzee and Jack's Favorite Game Mods | Slightly Something Else
 - [https://www.youtube.com/watch?v=dTK77ZNF1wg](https://www.youtube.com/watch?v=dTK77ZNF1wg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-03-29 00:00:00+00:00

This episode of Slightly Something Else is brought to you by Manscaped. Get 20% OFF Manscaped + Free Shipping with promo code ESCAPIST at MANSCAPED.com! #ad #manscapedpod

This week on Slightly Something Else, Yahtzee and Jack discuss their favorite video game mods.

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag


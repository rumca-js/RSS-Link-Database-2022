# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Michael Shellenberger's Solution for the Homeless Problem in California
 - [https://www.youtube.com/watch?v=TsTDA2DT72k](https://www.youtube.com/watch?v=TsTDA2DT72k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-03-30 00:00:00+00:00

Taken from JRE #1798 w/Michael Shellenberger:
https://open.spotify.com/episode/6kc8Usp2Iv8gGrheicdpOM?si=e62207450ffe4927

## Joe on Will Smith Slapping Chris Rock at The Oscars
 - [https://www.youtube.com/watch?v=gN15j7RHPvE](https://www.youtube.com/watch?v=gN15j7RHPvE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-03-29 00:00:00+00:00

Taken from JRE #1797 w/Josh Barnett:
https://open.spotify.com/episode/5WqhbmwLU9v62ReXvk2Ob4?si=11412a1114dc41e6


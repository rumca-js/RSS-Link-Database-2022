# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Joe Biden's New World Order
 - [https://www.youtube.com/watch?v=iCfkKQiTI-M](https://www.youtube.com/watch?v=iCfkKQiTI-M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-03-30 00:00:00+00:00

Two recent comments from Joe Biden have been immediately dismissed by government officials and the MSM as not meaning what they appeared to mean. But was Biden just ad-libbing, or are these potential revelations backed-up by history? 
#NewWorldOrder #Biden #Russia 

References
https://www.nytimes.com/2022/03/27/world/europe/biden-putin-speech-reaction.html

https://www.commondreams.org/news/2022/03/26/suggesting-kremlin-regime-change-biden-says-putin-cannot-remain-power

https://www.washingtonpost.com/news/monkey-cage/wp/2016/12/23/the-cia-says-russia-hacked-the-u-s-election-here-are-6-things-to-learn-from-cold-war-attempts-to-change-regimes/

https://www.washingtonpost.com/news/monkey-cage/wp/2016/12/20/the-u-s-has-a-long-history-of-hacking-other-democracies/

https://www.channel4.com/news/factcheck/americas-long-history-of-meddling-in-other-countries-elections

https://caitlinjohnstone.com/2022/03/06/ukraine-is-a-sacrificial-pawn-on-the-imperial-chessboard/

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Russell Brand Reacts To Will Smith Slap
 - [https://www.youtube.com/watch?v=_13vkaaQMDM](https://www.youtube.com/watch?v=_13vkaaQMDM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-03-29 00:00:00+00:00

Everyone's talking about Will Smith hitting Chris Rock at the Oscars. Opinions vary, but
how has it made us feel, and was it part of a ceremony that just feels increasingly
meaningless? #WillSmith #Oscars #ChrisRock 

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


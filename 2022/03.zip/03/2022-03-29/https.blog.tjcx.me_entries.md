## I wasted $40k on a fantastic startup idea - by Tom - TJCX
 - [https://blog.tjcx.me/p/40k-fantastic-startup-idea?s=r](https://blog.tjcx.me/p/40k-fantastic-startup-idea?s=r)
 - RSS feed: https://blog.tjcx.me
 - date published: 2022-03-29 06:27:03.403375+00:00

When good ideas make bad business


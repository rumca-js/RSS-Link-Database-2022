# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Chris Pierson, Loremaster of Lord of the Rings Online (LOTRO)
 - [https://www.youtube.com/watch?v=tgsvMIGdnl8](https://www.youtube.com/watch?v=tgsvMIGdnl8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-03-29 00:00:00+00:00

We will be chatting LIVE with Chris Pierson of Standing Stone Games.  Chris is one of the incredible loremasters who work on The Lord of the Rings Online, which celebrates its 15th anniversary this year!  Join us for a fun chat as Chris answers your questions live!

Follow Nerd of the Rings on Twitch for regular LOTRO streams! twitch.tv/thenerdoftherings

#lordoftherings #lotro #tolkien


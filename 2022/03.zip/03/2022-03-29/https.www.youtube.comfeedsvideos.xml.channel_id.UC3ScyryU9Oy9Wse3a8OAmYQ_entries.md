# Source:FRONTLINE PBS | Official, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ, language:en-US

## Who Fueled Donald Trump’s Stolen Election Myth? | Plot to Overturn the Election | FRONTLINE
 - [https://www.youtube.com/watch?v=1aZU-aB3_oE](https://www.youtube.com/watch?v=1aZU-aB3_oE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2022-03-29 00:00:00+00:00

In the opening moments of a new documentary from FRONTLINE and ProPublica, correspondent A.C. Thompson begins a journey to find out who fueled the myth that the 2020 election was stolen from Donald Trump.

This journalism is made possible by viewers like you. Support your local PBS station here: http://www.pbs.org/donate. 

The full “Plot to Overturn the Election” documentary premieres Tuesday, March 29, at 10/9c on PBS & online. It traces hidden sources of misinformation about the 2020 election, demonstrating how a handful of people have had an outsized impact on the current U.S. crisis of democratic legitimacy. Learn more here: https://to.pbs.org/3iId0co

#2020Election #USPolitics #Documentary 

Love FRONTLINE? Find us on the PBS Video App, where there are more than 300 FRONTLINE documentaries available to watch any time: https://to.pbs.org/FLVideoApp 

Subscribe on YouTube: http://bit.ly/1BycsJW 
Instagram: https://www.instagram.com/frontlinepbs 
Twitter: https://twitter.com/frontlinepbs 
Facebook: https://www.facebook.com/frontline 

FRONTLINE is produced at GBH in Boston and is broadcast nationwide on PBS. Funding for FRONTLINE is provided through the support of PBS viewers and by the Corporation for Public Broadcasting. Additional support for FRONTLINE is provided by the Abrams Foundation, the John D. and Catherine T. MacArthur Foundation, the Park Foundation; and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation, and additional support from Koo and Patricia Yuen, and Joseph Azrack and Abigail Congdon.


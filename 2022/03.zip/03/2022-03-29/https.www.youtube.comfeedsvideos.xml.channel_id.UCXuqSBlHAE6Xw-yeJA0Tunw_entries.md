# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This Sleeper PC has a BIG Secret - Bunta the Sleeper PC
 - [https://www.youtube.com/watch?v=RmJryKpLKrM](https://www.youtube.com/watch?v=RmJryKpLKrM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-03-30 00:00:00+00:00

Thanks to Seasonic for sponsoring this build! Buy a Seasonic Prime Platinum PX-1300W: https://geni.us/R0aH6

How do you fit a Ryzen 9 5950X and an RTX 3090 into a tiny Sleeper PC?  Well let's just say Bunta has a lot going on down below ;)

Discuss on the forum: https://linustechtips.com/topic/1421558-this-small-pc-has-a-big-secret-sponsored/

Buy an AMD Ryzen 9 5950X: https://geni.us/nMA6el

Buy an Asus RTX 3090 Strix: https://geni.us/LhP1

Buy a kit of Crucial Ballistix Max 4000MHz RAM (2x16GB): https://geni.us/paTipn

Buy watercooling gear from Alphacool: https://lmg.gg/ohwN2

Buy the Connect D1 IO connector from Fractal Design: https://geni.us/B9rlcg

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Glamtage: Odyssey Eurobeat - Path of Desire
Video Link: https://youtu.be/1jIVZRTnt24
Listen on Spotify: https://open.spotify.com/track/2QgJa4B7Iz9Nx3NxSXK8qA?si=07c4a089ada64ea8

Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 - Say Hello to Bunta
0:33 - Linus spoils the surprise
1:18 - Alphacool sent us too much stuff
4:00 - Disassembling the old Vaio
4:55 - Test fitting
5:56 - GPU Block
7:06 - Loop planning
8:41 - Paint
9:50 - Drilling the Desk
10:55 - Alex got a fancy 3D Printer
11:33 - Attaching the Rad & more paint
13:00 - Final assembly begins
15:28 - Hi Seasonic!
16:20 - GPU Install
17:22 - Filling the loop
18:12 - The worst problems are the ones you see coming from a mile away but thought it would be fine
19:52 - He Works!
20:43 - EUROBEAT INTENSIFIES
21:08 - Bunta scares Linus with his monstrous drift
24:33 - Ty Seasonic
24:55 - Outro

## Nvidia missed the memo - GeForce RTX 3090 Ti
 - [https://www.youtube.com/watch?v=DDcA0c-Ahq0](https://www.youtube.com/watch?v=DDcA0c-Ahq0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-03-29 00:00:00+00:00

Get a 15-day free trial for unlimited backup at https://backblaze.com/LTT

SmartDeploy: Claim your FREE IT software (worth $580!) at https://lmg.gg/Jpt4k

Nvidia’s GeForce RTX 3090 was the most expensive consumer GPU ever made, but we thought it was a Titan. Now, the RTX 3090 Ti is here, with a price tag half again as big. Is Nvidia wrong, or were we?

Discuss on the forum: https://linustechtips.com/topic/1421286-nvidia-missed-the-memo/

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
0:58 3090... Ti? Specs please.
1:49 4K gaming benchmarks
2:31 Productivity benchmarks
3:01 Power consumption
3:48 But... Why?
5:01 Pricing and why this is a disappointment
7:17 Setting some bad precedents
8:19 Conclusion - People will buy it (but please don't)


# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## Google Chrome Major Update 100 - Biggest Features & Changes
 - [https://www.youtube.com/watch?v=XkfsW1zfPx0](https://www.youtube.com/watch?v=XkfsW1zfPx0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2022-03-30 00:00:00+00:00

Mostly minor changes, but find out more features you probably missed before!

⇒ Become a channel member for special emojis, early videos, and more! Check it out here: https://www.youtube.com/ThioJoe/join

▼ Time Stamps: ▼
0:00 - Intro
0:23 - Installing the Update
0:38 - New Chrome Logo / Icon
0:53 - Data Lite Mode Deprecated
1:11 - Tab Mute Button Returns!
2:00 - Multi-Screen API
2:23 - Introducing Next Segment
2:49 - Chrome 91: Recently Closed Tabs
3:15 - Chrome 92: Safety Check
4:02 - Chrome 93: SMS 2FA Sync
4:37 - Chrome 94: Sharing Hub
4:55 - Chrome 95: Save Tab Groups
5:14 - Chrome 96: Recent Pages Cache
5:33 - Chrome 97: Individual Site Storage Usage
6:12 - Chrome 98: Vector Emojis
6:24 - Chrome 99: Handwriting Recognition API

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬


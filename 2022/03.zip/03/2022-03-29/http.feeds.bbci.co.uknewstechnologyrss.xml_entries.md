# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## More must reconsider Russian anti-virus software use, UK warns
 - [https://www.bbc.co.uk/news/technology-60854882?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-60854882?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-03-29 15:49:25+00:00

But the National Cyber Security Centre says Kaspersky anti-virus is safe for individual users.


# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## 'We see the queue for food growing day by day'
 - [https://www.bbc.co.uk/news/business-60901422?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60901422?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 23:05:04+00:00

An anti-hunger charity sees unprecedented demand for surplus food during cost of living crisis.

## Concert For Ukraine: Refugees' stories centre stage at £12m charity show
 - [https://www.bbc.co.uk/news/entertainment-arts-60912544?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60912544?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 22:34:14+00:00

Ed Sheeran, Camila Cabello and Eurovision winner Jamala help raise funds at the Concert For Ukraine.

## Ukraine peace talks: The West calls for actions not words from Russia
 - [https://www.bbc.co.uk/news/world-europe-60920255?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60920255?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 21:55:00+00:00

The West calls for actions not words after the first sign of progress in peace talks.

## Rise of the five-year-old 'TikTots'
 - [https://www.bbc.co.uk/news/technology-60854885?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-60854885?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 21:39:56+00:00

Children as young as five are regularly using social media despite the rules, a survey finds.

## Kyrgios docked game for racquet smash in Miami
 - [https://www.bbc.co.uk/sport/tennis/60921399?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/60921399?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 20:33:29+00:00

Nick Kyrgios is docked a game in a tempestuous Miami Open last-16 defeat by Italy's Jannik Sinner.

## Why the Red Cross has to be neutral in the Ukraine conflict
 - [https://www.bbc.co.uk/news/world-europe-60921567?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60921567?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 19:42:52+00:00

The ICRC is worried that its operations might be undermined by misinformation about its work.

## Queen hears tributes to her 'beloved Philip'
 - [https://www.bbc.co.uk/news/uk-60918657?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60918657?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 17:53:40+00:00

The 95-year-old monarch overcomes her mobility problems to honour Prince Philip.

## Queen thanks DofE winner Doyin Sonibare after Prince Philip thanksgiving speech
 - [https://www.bbc.co.uk/news/uk-60918589?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60918589?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 17:42:08+00:00

Duke of Edinburgh Gold Award winner Doyin Sonibare delivers an address to senior royals at Westminster.

## China gains a foothold in Australia's backyard
 - [https://www.bbc.co.uk/news/world-asia-60896824?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-60896824?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 15:46:39+00:00

A Pacific island's invitation to China's military threatens to destabilise Oceania.

## Waitrose in row with Asda over 'Just Essentials' budget range
 - [https://www.bbc.co.uk/news/business-60862940?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60862940?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 12:25:48+00:00

Rival supermarket Waitrose says its own similarly-named discount brand "Essential" range is trademarked.

## UK seizes first superyacht in British waters
 - [https://www.bbc.co.uk/news/business-60912754?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60912754?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 12:16:55+00:00

The £38m yacht, named Phi, is owned by an unnamed Russian businessman, the government says.

## P&O Ferries says sacking U-turn would cause collapse
 - [https://www.bbc.co.uk/news/business-60913206?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60913206?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 12:09:10+00:00

P&amp;O's boss hits back at the transport secretary after he called on the company to reverse its decision.

## Queen attends Prince Philip memorial service at Westminster Abbey
 - [https://www.bbc.co.uk/news/uk-60902088?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60902088?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 12:04:25+00:00

The Duke of Edinburgh's dedication to duty was praised at a memorial service at Westminster Abbey.

## Russia-Ukraine war: Abramovich spotted in Istanbul peace talks
 - [https://www.bbc.co.uk/news/world-europe-60912474?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60912474?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 12:03:27+00:00

The Russian billionaire was seen as the talks began, following reports that he suffered poisoning symptoms.

## Twenty fines to be issued over No 10 lockdown parties
 - [https://www.bbc.co.uk/news/uk-politics-60911798?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60911798?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 11:51:24+00:00

Police say 20 fixed penalty notices will initially be issued over Downing Street parties that broke the law.

## Decathlon backtracks on Russia after boycott calls
 - [https://www.bbc.co.uk/news/business-60912746?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60912746?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 11:35:53+00:00

The sporting retailer has halted its business in Russia after criticism of its decision to stay.

## El Clasico: Match set to break women's crowd record - but is it a one off?
 - [https://www.bbc.co.uk/sport/football/60894257?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60894257?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 11:07:49+00:00

More than 90,000 tickets have been sold for Barcelona's Champions League quarter-final second leg with Real Madrid at the Nou Camp.

## University rugby player dies weeks after match injury
 - [https://www.bbc.co.uk/news/uk-england-somerset-60905063?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-somerset-60905063?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 10:59:45+00:00

Maddy Lawrence, 20, died from injuries she suffered in a tackle during a match on March 7.

## Saudi Arabia could host Usyk-Joshua in late June
 - [https://www.bbc.co.uk/sport/boxing/60890578?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/60890578?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 10:24:12+00:00

Saudi Arabia could host the Oleksandr Usyk-Anthony Joshua rematch in late June, according to the Ukrainian's promoter Alexander Krassyuk.

## Kev Crane: Singing plumber signs Hollywood film deal
 - [https://www.bbc.co.uk/news/uk-england-leicestershire-60912384?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leicestershire-60912384?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 10:19:26+00:00

Kev Crane secured a record contract after being overheard singing while fitting a bathroom.

## SEND review: Children to receive earlier support in new government plans
 - [https://www.bbc.co.uk/news/education-60875163?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-60875163?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 08:20:52+00:00

Critics say more urgency is needed to fix a "broken system", as a long-awaited review is published.

## MOTD Top 10: Should Harry Kane move in search of that elusive Premier League title?
 - [https://www.bbc.co.uk/sport/av/football/60870110?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/60870110?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 07:23:20+00:00

This week's MOTD Top 10 podcast is all about those stars who probably deserve a Premier League title win on their CV, but have never taken that final step to become champions.

## Ukraine: Sheltering with monks in a Romanian monastery
 - [https://www.bbc.co.uk/news/world-europe-60905198?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60905198?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 07:03:14+00:00

The Ukrainian family who found shelter in a an unlikely place after fleeing Kharkiv.

## Medvedev moves closer to top ranking with win over Martinez
 - [https://www.bbc.co.uk/sport/tennis/60906950?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/60906950?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 05:45:11+00:00

Russia's Daniil Medvedev is two wins away from regaining the men's world number one spot after reaching the Miami Open last 16.

## Knoydart community owns Britain's remotest mainland pub
 - [https://www.bbc.co.uk/news/uk-scotland-highlands-islands-60907329?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-highlands-islands-60907329?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 05:17:42+00:00

Locals succeed in their bid to buy The Old Forge on the Knoydart Peninsula in a landmark deal.

## The Papers: Abramovich poisoning and first Partygate fines
 - [https://www.bbc.co.uk/news/blogs-the-papers-60908585?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-60908585?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 04:57:00+00:00

The alleged chemical poisoning of the Russian tycoon and fines for Downing Street parties lead the papers.

## Shane Warne: Australians reflect on cricket legend and 'man of the people'
 - [https://www.bbc.co.uk/news/world-australia-60909634?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-60909634?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 04:08:31+00:00

Ahead of Warne's memorial service, ordinary Australians explain why his legacy transcends cricket.

## Anoosheh Ashoori tells of Iran jail 'hell'
 - [https://www.bbc.co.uk/news/world-middle-east-60909883?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-60909883?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 04:02:57+00:00

Anoosheh Ashoori, who arrived back in the UK this month, tells of his 'hell' in Tehran jail.

## Ukraine war: Odesa defies Russia and embraces signs of life
 - [https://www.bbc.co.uk/news/world-europe-60901032?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60901032?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 01:03:40+00:00

Residents of the historic city on Ukraine's coast are confident it will not fall to Russian forces.

## Will Smith apologises to Chris Rock after Oscars slap
 - [https://www.bbc.co.uk/news/entertainment-arts-60909487?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60909487?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 00:57:53+00:00

The actor says he was "out of line" after he slapped the comedian on stage at the Oscars.

## French election: Why the small town of Moissac is on edge
 - [https://www.bbc.co.uk/news/world-europe-60587079?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60587079?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 00:23:24+00:00

The relationship between a Bulgarian community and locals in Moissac sheds light on political issues.

## Biodiversity: What is it and how are we protecting it?
 - [https://www.bbc.co.uk/news/explainers-60823267?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/explainers-60823267?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 00:11:19+00:00

The planet is experiencing its sixth mass extinction event, but it is hoped action can be agreed.

## Climate change: Heatwave temperature threshold raised in England by Met Office
 - [https://www.bbc.co.uk/news/uk-60908169?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60908169?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-29 00:07:20+00:00

As the UK's climate warms, the temperature threshold in eight counties is raised by the Met Office.


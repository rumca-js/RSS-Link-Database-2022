# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Band of Horses' Ben Bridwell on 'Things Are Great' (interview with The Current)
 - [https://www.youtube.com/watch?v=g5UBADudhEo](https://www.youtube.com/watch?v=g5UBADudhEo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-03-30 00:00:00+00:00

Following the release of their 2022 record 'Things Are Great,' Band of Horses' Ben Bridwell joined The Current's Mary Lucia to talk about the ghosts of Ryman Auditorium, putting together the new record, and their upcoming North American tour with The Black Keys.

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits
Guest - Ben Bridwell
Host - Mary Lucia
Producer - Jesse Wiza
Technical Director - Peter Ecklund


# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## UK surge continues
 - [https://www.youtube.com/watch?v=UFWICK4ePg0](https://www.youtube.com/watch?v=UFWICK4ePg0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-03-29 00:00:00+00:00

Most common symptoms, Runny nose, 82% Fatigue, 70% Headache, 69%

Sore throat, 69%

Sneezing, 68%

Persistent cough, 53%

Hoarse, 46%

Chills or shivers, 36%

Joint pains, 33%

Fever, 32%

Dizzy, 30%

Brain fog, 27%

Sore eyes, 25%

Altered smell, 24%

Muscle pains, 23%

Lower back pain, 23%

Swollen glands, 21%

Skipped meals, 18%

Ear ringing, 17%

Covid more common than colds

Even if testing negative
UK

https://covid.joinzoe.com/data

ONS

https://www.ons.gov.uk/peoplepopulationandcommunity/healthandsocialcare/conditionsanddiseases/articles/coronaviruscovid19/latestinsights


Percentage of the community population that had COVID-19 up to 19 March 2022

6.39% in England (1 in 16 people)

6.35% in Wales (1 in 16 people) 

5.92% in Northern Ireland 
(1 in 17 people) 

9.00% in Scotland (1 in 11 people)

Antibodies

99.0% in England

98.9% in Wales 

98.8% in Northern Ireland 

99.0% in Scotland

Unvaccinated pupils were more likely to become infected with COVID-19 in the Autumn 2021 term

Compared with unvaccinated pupils

Those aged 12 to 15 years,
who had received one vaccine dose more than 14 days ago: 

were 23% less likely to report a positive test

(second half of the Autumn 2021 term 4th  November to 17th  December 2021)

UK official data

https://coronavirus.data.gov.uk/


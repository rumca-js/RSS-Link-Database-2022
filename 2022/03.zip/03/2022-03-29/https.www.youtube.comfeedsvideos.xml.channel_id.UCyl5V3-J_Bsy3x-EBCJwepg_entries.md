# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Twitter Suspends The Bee But Does Nothing About These Crazies
 - [https://www.youtube.com/watch?v=UBzV4UeL5Bo](https://www.youtube.com/watch?v=UBzV4UeL5Bo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-03-30 00:00:00+00:00

Twitter suspended The Babylon Bee until we delete our joke but seems to have no problem with these crazy people advocating violence and hate on its platform.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


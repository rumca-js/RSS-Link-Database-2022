# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Elden Ring: 10 Things You Didn't Know You Could Do
 - [https://www.youtube.com/watch?v=T7uUMh9m4QM](https://www.youtube.com/watch?v=T7uUMh9m4QM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-03-30 00:00:00+00:00

Elden Ring (PC, PS5, PS4, Xbox Series X/S/One) is filled with various small tricks and moments you possibly didn’t even notice. Here are some things you can do and see that you may not’ve realized.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 Gaming April Fools Jokes That Were RIDICULOUS [Part 2]
 - [https://www.youtube.com/watch?v=jFaRUA_oURs](https://www.youtube.com/watch?v=jFaRUA_oURs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-03-29 00:00:00+00:00

April Fools in the gaming world is always filled with tons of pranks, promotional spoofs, and other odd moments. Here are some of our favorite recent joke examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Sources:

https://www.siliconera.com/nier-replicant-april-fools-video-reimagines-game-as-a-slow-life-rpg/
--

https://www.youtube.com/watch?v=JnfP9qKAbk8&ab_channel=FINALFANTASYXIV
------
https://www.youtube.com/watch?v=9n4JAhskw0k&ab_channel=CORSAIR


https://www.youtube.com/watch?v=qA2bwf87jD8&t=46s&ab_channel=Landfall
---
https://www.thegamer.com/ducktales-quackshot-remake-not-happening/
------
https://www.youtube.com/watch?v=uaJ6I2d6SRo&ab_channel=RemedyEntertainment
------
https://twitter.com/Razer/status/1377355565265866752
---
https://www.facebook.com/watch/?v=965280863874310
+ https://www.ubisoft.com/en-us/game/for-honor/news-updates/2SGpRBJiYUmJ9UpEDJDAz5/a-small-april-fools-event-for-honor-mini-edition
https://wiki.warthunder.com/Space_Thunder
https://www.blog.google/products/maps/sssnakes-map/

BONUS
https://ehpodcasts.com/2019/04/01/resident-evil-2-april-fools-zombie-recruitment-prank-by-capcom-is-funny/

https://twitter.com/Bethesda_ANZ/status/1377396992918220800

## NEW PlayStation Plus Premium & Essential - 5 Things You Need to know
 - [https://www.youtube.com/watch?v=EFxrcJ3JIDs](https://www.youtube.com/watch?v=EFxrcJ3JIDs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-03-29 00:00:00+00:00

Sony announced a new version of PlayStation Plus for PS5 and PS4, with more tiers, downloadable games, and perks. Here's everything you need to know.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#PSplus


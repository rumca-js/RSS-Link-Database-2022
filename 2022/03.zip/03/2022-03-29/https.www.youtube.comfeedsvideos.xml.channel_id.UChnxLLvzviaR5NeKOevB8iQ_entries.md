# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## A Cat Learns Synthesis with Syntorial (Part 05)
 - [https://www.youtube.com/watch?v=1MKy9LC4JeI](https://www.youtube.com/watch?v=1MKy9LC4JeI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2022-03-29 00:00:00+00:00

Syntorial is a program designed to help you learn how music synthesizers work.
Cats are mammals.
Let's see what happens when we put them together.
https://www.syntorial.com/
------------------------------------
Patreon:  http://bit.ly/rmrpatreon

My Music: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia


# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Staged or Real? Will Smith Hits Chris Rock!
 - [https://www.youtube.com/watch?v=QgI2nnrnjz8](https://www.youtube.com/watch?v=QgI2nnrnjz8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-03-29 00:00:00+00:00

Grab your Magnesium Breakthrough at https://magnesiumbreakthrough.com/jp
Use Code "AWAKEN" For a Deal

Check Out My Merch Here - https://awakenwithjp.com

See my LIVE Comedy Shows - https://awakenwithjp.com/pages/events

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

At the Oscars this year, Will Smith slapped Chris Rock in the face after he made a bald joke about Will Smith's wife Jada. Was this real or staged?

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com


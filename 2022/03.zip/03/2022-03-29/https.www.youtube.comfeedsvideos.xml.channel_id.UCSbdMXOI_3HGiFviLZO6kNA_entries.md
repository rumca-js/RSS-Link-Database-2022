# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The Quest 2 Gets TWO Big Features I've Been Waiting For
 - [https://www.youtube.com/watch?v=JtDdllBYgaA](https://www.youtube.com/watch?v=JtDdllBYgaA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-03-29 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire week's worth of VR news. This week we have some fun news from the VR Taco open source omni-directional treadmill to the Meta Quest 2 getting a couple really awesome features that I've been waiting for: a better set of recording tools and new framedrop insurance on the Quest itself for airlink. Also a TON of new information on the Pimax 12k as well as more! Hope you enjoy this weeks news! 

My links: 
Discord:
https://discord.gg/2hCGM9BYez
Twitch:
https://www.twitch.tv/thrilluwu
Twitter:
https://twitter.com/Thrilluwu
Patreon:
https://www.patreon.com/Thrillseeker

INVEST IN THRILLSEEKER MEDIA GROUP:
https://www.startengine.com/thrillseekermediagroup

Timestamps:
00:00 INTRO
00:37 PSVR 2
02:02 MANUS QUANTUM METAGLOVE
02:54 QUEST UPDATES
06:24 MEME BREAK 
06:38 META CREATOR FUND
07:11 PIMAX
09:34 TACO VR
10:13 AR ACQUISITIONS
11:11 QOTW
11:48 OUTRO

Sources:
MRTV: https://www.youtube.com/watch?v=1TiCMTPTCzM
TacoVR: http://blogfarts.blogspot.com/2022/03/taco-vr-infento-based-omnidirectional.html


# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## How Telegram Became the Anti-Facebook
 - [https://www.youtube.com/watch?v=9Ym2GC3aX8Y](https://www.youtube.com/watch?v=9Ym2GC3aX8Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2022-03-30 00:00:00+00:00

Previous Episode: https://www.youtube.com/watch?v=W5P8ZBLC450
Podcast I Co-host: https://www.youtube.com/channel/UC6jKUaNXSnuW52CxexLcOJg

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

» ColdFusion Discord:  https://discord.gg/coldfusion
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusioncollective
» Podcast Version of Videos: https://open.spotify.com/show/3dj6YGjgK3eA4Ti6G2Il8H
https://podcasts.apple.com/us/podcast/coldfusion/id1467404358

ColdFusion Music Channel: https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

ColdFusion Merch:
INTERNATIONAL: https://store.coldfusioncollective.com/
AUSTRALIA: https://shop.coldfusioncollective.com/

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- "New Thinking" written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

Sources:

• https://www.nytimes.com/2021/01/26/world/europe/telegram-app-far-right.html 

• https://punchng.com/facebook-outage-how-telegram-became-fifth-most-downloaded-app-from-56th-report/ 

• https://www.businesstoday.in/technology/news/story/telegram-gained-70-mn-new-users-during-facebook-outage-308570-2021-10-06

• https://www.wired.com/story/how-telegram-became-anti-facebook/

• https://www.theguardian.com/technology/2021/oct/05/facebook-outage-what-went-wrong-and-why-did-it-take-so-long-to-fix

• https://www.fastcompany.com/90465378/telegram-facebook-and-the-furious-fight-over-the-future-of-cryptocurrency  


My Music Channel:  https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

//Soundtrack//

Sublab - So in Love

We Are All Astronaughts - Doves

Young American Primitive - Sunrise

Psalm Trees, Guillaume Muschalle - Forever Tired Ft. Thomas Renwick

Deccies - Subtle

Burn Water - A Promise

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide


# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## What Happens To Your Brain When You Mindlessly Scroll?
 - [https://www.youtube.com/watch?v=aNvvOQMx0jY](https://www.youtube.com/watch?v=aNvvOQMx0jY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2022-03-30 00:00:00+00:00

Start building your ideal daily routine. The first 500 people who click on the link will get 25% OFF Fabulous Premium: http://thefab.co/asapscience
Today we're talking about how your phone changes your brain AND body. 
Join our science mailing list: https://bit.ly/34fWU27

FOLLOW US!
TikTok: @AsapSCIENCE 
Instagram: https://instagram.com/asapscience​​
Twitter: https://twitter.com/asapscience​​

Written by: Gregory Brown & Tharsan Kana
Animations by: Max Simmons
Edited by: Luka Šarlija

Resources / Further reading:
https://onlinelibrary.wiley.com/doi/abs/10.1111/jasp.12506#:~:text=Results%20revealed%20that%20increased%20phubbing,both%20positive%20and%20negative%20affect.
https://www.nytimes.com/2019/02/23/business/cell-phone-addiction.html
https://pubmed.ncbi.nlm.nih.gov/23294345/
https://www.theguardian.com/lifeandstyle/2018/may/28/blue-light-led-screens-cancer-insomnia-health-issues#:~:text=In%20lab%20experiments%2C%20high%20exposure,%2C%E2%80%9D%20says%20O'Hagan.
https://www.bankmycell.com/blog/smartphone-addiction/
https://healthtalk.unchealthcare.org/the-effects-of-smartphone-usage-on-the-brain/
https://www.sciencedaily.com/releases/2017/11/171130090041.htm
https://bgr.com/business/smartphone-addiction-survey-data/
https://pubmed.ncbi.nlm.nih.gov/9054347/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6576600/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4826767/
https://sitn.hms.harvard.edu/flash/2018/dopamine-smartphones-battle-time/

Al-Hadidi, F., Bsisu, I., AlRyalat, S. A., Al-Zu’bi, B., Bsisu, R., Hamdan, M., Kanaan, T., Yasin, M., & Samarah, O. (2019). Association between mobile phone use and neck pain in university students: A cross-sectional study using numeric rating scale for evaluation of neck pain. PLOS ONE, 14(5), e0217231. https://doi.org/10.1371/JOURNAL.PONE.0217231

Allred, R. J., & Atkin, D. (2020). Cell Phone Addiction, Anxiety, and Willingness to Communicate in Face-to-Face Encounters. Https://Doi.Org/10.1080/08934215.2020.1780456, 33(3), 95–106. https://doi.org/10.1080/08934215.2020.1780456

Bartel, K., Scheeren, R., & Gradisar, M. (2018). Altering Adolescents’ Pre-Bedtime Phone Use to Achieve Better Sleep Health. Https://Doi.Org/10.1080/10410236.2017.1422099, 34(4), 456–462. https://doi.org/10.1080/10410236.2017.1422099

Brennan, R., Jan, J. E., & Lyons, C. J. (2006). Light, dark, and melatonin: emerging evidence for the importance of melatonin in ocular physiology. Eye 2007 21:7, 21(7), 901–908. https://doi.org/10.1038/sj.eye.6702597

Deloitte Insights. (2021). How the Pandemic has Stress-Tested the Crowded Digital Home. https://www2.deloitte.com/content/dam/insights/articles/6978_TMT-Connectivity-and-mobile-trends/DI_TMT-Connectivity-and-mobile-trends.pdf

Eide, T. A., Aarestad, S. H., Andreassen, C. S., Bilder, R. M., & Pallesen, S. (2018). Smartphone restriction and its effect on subjective withdrawal related scores. Frontiers in Psychology, 9(AUG). https://doi.org/10.3389/FPSYG.2018.01444/FULL

Griffiths, M. (2009). A ‘components’ model of addiction within a biopsychosocial framework. Http://Dx.Doi.Org/10.1080/14659890500114359, 10(4), 191–197. https://doi.org/10.1080/14659890500114359

Inal, E. E., Demirci, kadir, Çetintürk, A., Akgönül, M., & Savaş, S. (2015). Effects of smartphone overuse on hand function, pinch strength, and the median nerve. Muscle & Nerve, 52(2), 183–188. https://doi.org/10.1002/MUS.24695

Joshi, S. C., Woodward, J., & Woltering, S. (2022). Nighttime cell phone use and sleep quality in young adults. Sleep and Biological Rhythms, 20(1), 97–106. https://doi.org/10.1007/S41105-021-00345-6/TABLES/3

Schmuck, D. (2020). Does Digital Detox Work? Exploring the Role of Digital Detox Applications for Problematic Smartphone Use and Well-Being of Young Adults Using Multigroup Analysis. Cyberpsychology, Behavior and Social Networking, 23(8), 526–532. https://doi.org/10.1089/CYBER.2019.0578

Woo, E. H. C., White, P., & Lai, C. W. K. (2017). Effects of electronic device overuse by university students in relation to clinical status and anatomical variations of the median nerve and transverse carpal ligament. Muscle & Nerve, 56(5), 873–880. https://doi.org/10.1002/MUS.25697


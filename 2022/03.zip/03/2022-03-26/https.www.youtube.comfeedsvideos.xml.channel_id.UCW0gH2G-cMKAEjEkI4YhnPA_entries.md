# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Corsairs Of Umbar | Tolkien Explained
 - [https://www.youtube.com/watch?v=L2Ot7TDVf0g](https://www.youtube.com/watch?v=L2Ot7TDVf0g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-03-26 00:00:00+00:00

The Corsairs of Umbar were the fierce pirates of Middle-earth. In this video, we cover their origins as descendants of Númenor, their ongoing wars with Gondor, and their final battle against Aragorn and the Oathbreakers during the War of the Ring. The Corsairs are among the fiercest enemies of Gondor - raiding and attacking their lands, and killing their leaders over centuries of war.

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

To purchase artist work, check out these amazing artists!

Anna Podedworna - https://www.artstation.com/akreon
Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html
Donato Giancola - https://www.donatoarts.com/online-store/secure-store/Middle-earth-c34110463
Aronja Art - https://www.instagram.com/aronjaart/
Ivan Cavini - https://www.instagram.com/ivan_cavini/
Sara Morello - https://www.artstation.com/saramorello
Matěj Čadil - https://www.etsy.com/people/matejcadil
Tulikoura - https://www.deviantart.com/tulikoura
Aegeri - https://www.deviantart.com/aegeri

Dol Amroth - Angus McBride
Imperial Numenorean Armor - Turner Mohan
Umbar vs Minas Tirith - Angus McBride
Umbar Armada - Ralph Damiani
Eldalonde - David Greset
Umbar - Turner Mohan
Adunakhori - Tom Romain
Black Numenorean - War in the North
Isildur Cuts the Ring - Denis Gordeev
Umbar Slaver - Fantasy Flight
Corsairs of Umbar - Fantasy Flight
Minas Tirith - Aegeri
Minas Tirith - Aronja Art
Minas Tirith - Ralph Damiani
Eldacar of Gondor - Matej Cadil
Castamir the Usurper of Gondor - Matej Cadil
Hand of Castamir - Fantasy Flight
Osgiliath - Matej Cadil
Corsairs - Fantasy Flight
Corsairs - John Howe
Pelargir - Roger Garland
Throne of Gondor - Fantasy Flight
Gondorian Shield - Fantasy Flight
Corsairs of Umbar - John Howe
Dol Amroth - Ted Nasmith
Corsairs - Fantasy Flight
The Guarded City - Matej Cadil
Aragorn - Catherine Karina Chmiel
Corsair Leader - Fantasy Flight
Romenna - David Greset
Corsairs of Umbar - John Howe
The Fleet of Harad - Darrell Sweet
Corsairs - WETA
Oathbreakers - Lida Holubova
Andunie - David Greset

#lordoftherings #tolkien #tolkienreadingday


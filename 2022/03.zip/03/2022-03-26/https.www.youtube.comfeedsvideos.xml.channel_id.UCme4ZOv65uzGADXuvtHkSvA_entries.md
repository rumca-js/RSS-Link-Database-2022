# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## 2 Księga Królewska || Rozdział 21
 - [https://www.youtube.com/watch?v=2RbSS-rjuMk](https://www.youtube.com/watch?v=2RbSS-rjuMk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-03-27 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Medytacje wielkopostne [#10] Chłopiec
 - [https://www.youtube.com/watch?v=Z0VE3ZsXpx0](https://www.youtube.com/watch?v=Z0VE3ZsXpx0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-03-27 00:00:00+00:00

W Wielkim Poście, zapraszamy do wspólnych medytacji. W niedziele, wtorki i czwartki o godz. 17:00, spotkania z Bogiem w słowie i ciszy. W czasie zamętu, czas na zanurzenie się w obecności i pokoju Bożym! Chodźcie spotkać Pana.

@Langustanapalmie   #WielkiPost2022 #światłowciemności

improwizacja: Jan Smoczyński
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## 2 Księga Królewska || Rozdział 20
 - [https://www.youtube.com/watch?v=CXzwCpigv7c](https://www.youtube.com/watch?v=CXzwCpigv7c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-03-26 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#280] Dlaczego wracamy do starych grzechów?
 - [https://www.youtube.com/watch?v=kGzhrmS5Ot8](https://www.youtube.com/watch?v=kGzhrmS5Ot8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-03-26 00:00:00+00:00

#cnn #dobrewiadomości    @Langustanapalmie 

Kazanko do okienka, czyli komentarz do niedzielnych czytań.

Niedziela, IV Tydzień Wielkiego Postu, Rok C, II
Czwarta Niedziela Wielkiego Postu

1. czytanie (Joz 5, 9a. 10-12)

Pan rzekł do Jozuego: «Dziś zrzuciłem z was hańbę egipską».
Rozłożyli się obozem Izraelici w Gilgal i tam obchodzili Paschę czternastego dnia miesiąca wieczorem, na stepach Jerycha. Następnego dnia Paschy jedli z plonu tej krainy, chleby przaśne i ziarna prażone tego samego dnia.
Manna ustała następnego dnia, gdy zaczęli jeść plon tej ziemi. Nie mieli już więcej Izraelici manny, lecz żywili się tego roku plonami ziemi Kanaan.

2. czytanie (2 Kor 5, 17-21)

Bracia:
Jeżeli ktoś pozostaje w Chrystusie, jest nowym stworzeniem. To, co dawne, minęło, a oto wszystko stało się nowe. Wszystko zaś to pochodzi od Boga, który pojednał nas z sobą przez Chrystusa i zlecił nam posługę jednania. Albowiem w Chrystusie Bóg jednał z sobą świat, nie poczytując ludziom ich grzechów, nam zaś przekazując słowo jednania. Tak więc w imieniu Chrystusa spełniamy posłannictwo jakby Boga samego, który przez nas udziela napomnień.
W imię Chrystusa prosimy: pojednajcie się z Bogiem! On to dla nas grzechem uczynił Tego, który nie znał grzechu, abyśmy się stali w Nim sprawiedliwością Bożą.

Ewangelia (Łk 15, 1-3.11-32)

W owym czasie przybliżali się do Jezusa wszyscy celnicy i grzesznicy, aby Go słuchać. Na to szemrali faryzeusze i uczeni w Piśmie, mówiąc: «Ten przyjmuje grzeszników i jada z nimi».
Opowiedział im wtedy następującą przypowieść:
«Pewien człowiek miał dwóch synów. Młodszy z nich rzekł do ojca: „Ojcze, daj mi część własności, która na mnie przypada”. Podzielił więc majątek między nich. Niedługo potem młodszy syn, zabrawszy wszystko, odjechał w dalekie strony i tam roztrwonił swoją własność, żyjąc rozrzutnie.
A gdy wszystko wydał, nastał ciężki głód w owej krainie, i on sam zaczął cierpieć niedostatek. Poszedł i przystał na służbę do jednego z obywateli owej krainy, a ten posłał go na swoje pola, żeby pasł świnie. Pragnął on napełnić swój żołądek strąkami, którymi żywiły się świnie, lecz nikt mu ich nie dawał.
Wtedy zastanowił się i rzekł: „Iluż to najemników mojego ojca ma pod dostatkiem chleba, a ja tu przymieram głodem. Zabiorę się i pójdę do mego ojca, i powiem mu: Ojcze, zgrzeszyłem przeciw Niebu i względem ciebie; już nie jestem godzien nazywać się twoim synem: uczyń mnie choćby jednym z twoich najemników”. Zabrał się więc i poszedł do swojego ojca.
A gdy był jeszcze daleko, ujrzał go jego ojciec i wzruszył się głęboko; wybiegł naprzeciw niego, rzucił mu się na szyję i ucałował go. A syn rzekł do niego: „Ojcze, zgrzeszyłem przeciw Niebu i wobec ciebie, już nie jestem godzien nazywać się twoim synem”.
Lecz ojciec powiedział do swoich sług: „Przynieście szybko najlepszą szatę i ubierzcie go; dajcie mu też pierścień na rękę i sandały na nogi! Przyprowadźcie utuczone cielę i zabijcie: będziemy ucztować i weselić się, ponieważ ten syn mój był umarły, a znów ożył; zaginął, a odnalazł się”. I zaczęli się weselić.
Tymczasem starszy jego syn przebywał na polu. Gdy wracał i był blisko domu, usłyszał muzykę i tańce. Przywołał jednego ze sług i pytał go, co to ma znaczyć. Ten mu rzekł: „Twój brat powrócił, a ojciec twój kazał zabić utuczone cielę, ponieważ odzyskał go zdrowego”.
Rozgniewał się na to i nie chciał wejść; wtedy ojciec jego wyszedł i tłumaczył mu. Lecz on odpowiedział ojcu: „Oto tyle lat ci służę i nie przekroczyłem nigdy twojego nakazu; ale mnie nigdy nie dałeś koźlęcia, żebym się zabawił z przyjaciółmi. Skoro jednak wrócił ten syn twój, który roztrwonił twój majątek z nierządnicami, kazałeś zabić dla niego utuczone cielę”.
Lecz on mu odpowiedział: „Moje dziecko, ty zawsze jesteś ze mną i wszystko, co moje, do ciebie należy. A trzeba było weselić się i cieszyć z tego, że ten brat twój był umarły, a znów ożył; zaginął, a odnalazł się”».

________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

Niedzielnik na ROK C
→ https://wdrodze.pl/produkt/niedzielnik-c-komentarze-do-czytan-adam-szustak/

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Listy z Ukrainy [#15] Księża z brodą
 - [https://www.youtube.com/watch?v=KIu9MD4sIzE](https://www.youtube.com/watch?v=KIu9MD4sIzE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-03-26 00:00:00+00:00

@langustanapalmie #Ukraina #ListyZUkrainy
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

Utwór wspominany w liście: https://www.youtube.com/watch?v=9ICZ_LCkKDY

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#1053] Naprawdę
 - [https://www.youtube.com/watch?v=n9tLVhyWGB8](https://www.youtube.com/watch?v=n9tLVhyWGB8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-03-26 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
Strona zbiórki → https://charytatywnie.fundacjamalak.pl/

Tradycyjne przelewy:
Nr konta do wpłat w PLN: 42 2490 0005 0000 4600 1184 3564 
IBAN: PL 42 2490 0005 0000 4600 1184 3564
Tytułem: UKRAINA

Fundacja MALAK
ul. Śliwkowa 4
31-982 Kraków
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.


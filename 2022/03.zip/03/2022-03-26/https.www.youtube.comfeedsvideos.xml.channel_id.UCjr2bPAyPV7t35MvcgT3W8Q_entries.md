# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## How To be Anonymous In A Protest | Burner Phone Tutorial
 - [https://www.youtube.com/watch?v=vMJH-UJyENs](https://www.youtube.com/watch?v=vMJH-UJyENs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2022-03-27 00:00:00+00:00

If you want to attend a protest, you have to become unidentifiable. This is how you do it. 
Become a producer of independent research and analysis by joining my Patreon page: https://www.patreon.com/thehatedone 

Police now have the ability to harass protesters with arrests, threats and coercion all the way back to their homes and offices. Attending a protest with a phone will now tell the police exactly who are you, who you communicate with and where you live. 

Your phone has four main radio signals, all of which can compromise your security:
    • Cellular radio – is your phone’s most revealing data point. Your SIM card has a unique IMSI number that is broadcast indiscriminately into all directions. The police can capture this number with so called IMSI catchers, find your real phone number and even intercept your calls and SMS texts.
    • WiFi – is the second most common data point. Police can setup a rogue hotspot to trick your phone into connecting to it without you noticing and they can start monitoring your traffic in real time. 
    • Police can also use Bluetooth beacons to catch your phone’s unique identifier. They could also try to exploit known Bluetooth vulnerabilities to attack your device with malicious payload.
    • GPS is broadly used for precise locations services, but this one is the safest data point. Your phone is only a receiver of GPS signals and doesn’t transmit any information. Your phone may, however, store GPS coordinates, which may be revealed to the police if they capture and unlock your phone.

Surveillance is the best tool to silence dissent. This is why if you care about your cause, you are going to have to care about protecting the identity of you and your fellow protesters. Your goal must be to become unidentifiable. 

What follows is a comprehensive guide to become anonymous in the street.  The goal is extreme anonymity and no middle-ground compromises. This guide will be split into two parts – Digital security, and physical security. Make sure to follow and understand every step in both of these parts as they are both equally required to remain anonymous.

Sources
EFF's guide on attending a protest: https://ssd.eff.org/en/module/attending-protest
IMSI Catchers: https://www.eff.org/wp/gotta-catch-em-all-understanding-how-imsi-catchers-exploit-cell-networks
- Stingrays: https://www.wired.com/2015/10/stingray-government-spy-tools-can-record-calls-new-documents-confirm/
- https://www.wired.com/2014/06/feds-told-cops-to-deceive-courts-about-stingray/
How to prepare your phone for a protest: https://themarkup.org/ask-the-markup/2020/06/04/how-do-i-prepare-my-phone-for-a-protest
Protest privacy - photos: https://themarkup.org/ask-the-markup/2020/03/12/photos-privacy
Burner Phone tutorial by The Intercept: https://theintercept.com/2020/06/15/protest-tech-safety-burner-phone/
Rogue WIFI hotspots: https://www.forbes.com/sites/andygreenberg/2011/07/28/flying-drone-can-crack-wifi-networks-snoop-on-cell-phones/
Dataminers spy on social media: https://theintercept.com/2020/07/09/twitter-dataminr-police-spy-surveillance-black-lives-matter-protests/
Anonymous Twitter account: https://theintercept.com/2017/02/20/how-to-run-a-rogue-government-twitter-account-with-an-anonymous-email-address-and-a-burner-phone/
Facial recognition in Hong Kong protest: https://www.nytimes.com/2019/07/26/technology/hong-kong-protests-facial-recognition-surveillance.html

List of all apps and services mentioned (no affiliation)
GrapheneOS: https://grapheneos.org/
- Download: https://grapheneos.org/releases
- Install: https://grapheneos.org/install

F-Droid: https://f-droid.org/
Orbot: https://guardianproject.info/apps/org.torproject.android/
Tor Browser: https://www.torproject.org/
Aurora Store: https://f-droid.org/en/packages/com.aurora.store

KeepassDX: https://github.com/Kunzisoft/KeePassDX
Tutanota: https://tutanota.com/
Protonmail: https://protonmail.com/
SimpleLogin: https://simplelogin.io/
Aegis Authenticator: https://getaegis.app/
Signal: https://signal.org/
Briar: https://briarproject.org/
Wire: https://wire.com/en/
Anonymous Twitter: https://twitter3e4tixl4xyajtrzo62zg5vztmjuricljdp2c5kshju4avyoid.onion/
Scrambled Exif: https://f-droid.org/en/packages/com.jarsilio.android.scrambledeggsif/
ImagePipe: https://f-droid.org/en/packages/com.jarsilio.android.scrambledeggsif/
ObscuraCam: https://guardianproject.info/apps/obscuracam/
OsmAnd: https://osmand.net/

Credits
Music By: White Bat Audio https://www.youtube.com/c/WhiteBatAudio

Follow me:
https://twitter.com/The_HatedOne_
https://www.reddit.com/r/thehatedone/

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.


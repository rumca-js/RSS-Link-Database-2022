# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Jak poprawnie czytać GIF?
 - [https://www.youtube.com/watch?v=rC3yLKTLMxY](https://www.youtube.com/watch?v=rC3yLKTLMxY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-03-27 00:00:00+00:00

Dziś w odcinku:
00:00 Wstęp z pamiętnikiem Andy'ego Warhola
00:15 Twórca GIFa nie żyje
00:20 Dobry wieczór
01:33 Fabryka Tesli w Berlinie i tańczący Elon Musk
02:16 Nowa odsłona spotkań na Zoom
03:50 Ból i ciężar w Metaversie
04:30 Newsy smartfonowe - "a nie mówiłem"
04:58 Samsung A53
05:48 Subskrypcja na iPhone - iPhone w abonamencie
06:34 Rząd ukrainy ogląda TechWeek
09:18 Pożegnanko
09:38 Znośnego tygodnia!

Źródła:
Wynalazca gifów tworzy gify w lepszym świecie: https://cnn.it/36ysEV9
Elon Musk tańczy na otwarciu fabryki Tesli pod Berlinem: https://bit.ly/3qEi1XM
Dlaczego spotkania online męczą: https://bit.ly/3qEqRVz
Prawdziwy ból w nieprawdziwym świecie: https://bit.ly/3tF4LEi
NIC nie warty event firmy NIC: https://youtu.be/8Cq7dnESV7Y
Samsung wypuści nowe składaki w sierpniu: https://bit.ly/3LhyvwN
iPhone'y w abonamencie: https://bit.ly/3ICMJa0
Spadło zainteresowanie NFT i metaversem: https://bit.ly/36Mb0NA
Muzeum NFT w Ukrainie: https://bit.ly/36yfqIa

https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter


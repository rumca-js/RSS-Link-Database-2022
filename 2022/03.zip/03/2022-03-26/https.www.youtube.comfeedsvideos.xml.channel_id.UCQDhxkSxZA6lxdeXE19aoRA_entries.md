# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## Harder Than I Expected - E-waste iPhone X Transformed Into Something Spectacular
 - [https://www.youtube.com/watch?v=103lzg5qs6U](https://www.youtube.com/watch?v=103lzg5qs6U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2022-03-26 00:00:00+00:00

Phone broken beyond repair like this iPhone X? Turn it into a work of art!
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com
Store: https://www.hughjeffreys.com/store
Instagram: http://instagram.com/hughjeffreys
---------------------------------------Links---------------------------------------
Framed Phones: https://xreart.com/

Get parts, tools and repair guides at iFixit:
Shop US: https://iFixit.com/hughjeffreys
Shop AU: https://ifix.gd/hughjeffreysau

Tools I Use: https://www.hughjeffreys.com/tools
---------------------------------------------------------------------------------------


(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)


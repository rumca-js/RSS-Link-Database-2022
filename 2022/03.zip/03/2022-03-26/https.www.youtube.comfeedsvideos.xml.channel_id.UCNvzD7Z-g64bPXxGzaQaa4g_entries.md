# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 8 NEW Games of April 2022
 - [https://www.youtube.com/watch?v=mjbOS-oyq08](https://www.youtube.com/watch?v=mjbOS-oyq08)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-03-27 00:00:00+00:00

April 2022 might not be the greatest for game releases but there's still plenty for PC, PS5, PS4, Xbox Series X/S/One, and Nintendo Switch. Here's what you need to know.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


8 MLB The Show 22

Platform : Switch PS4 PS5 Xbox One XSX|S

Release Date : April 5, 2022 



7 The House of the Dead: Remake 

Platform : Switch 

Release Date : April 7, 2022 



6 Terrorbane 

Platform : PC Switch

Release Date : April 1, 2022 



5 Midnight Ghost Hunt

Platform : PC

Release Date : April 1, 2022 


4 Back 4 Blood: Tunnels of Terror DLC 

Platform : PC PS5 XSX|S PS4 XBOX ONE

Release Date : April 12, 2022



3 Chrono Cross: The Radical Dreamers Edition

Platform : Switch 

Release Date : April 7, 2022 



2 Nintendo Switch Sports 

Platform : Switch 

Release Date : April 29, 2022 



1 Lego Star Wars: The Skywalker Saga

Platform : Switch PS4 PS5 Xbox One XSX|S PC 

Release Date : April 5, 2022  



BONUS

Lumote: The Mastermote Chronicles 

Platform : PC PS4 XBOX ONE Switch

Release Date : April 21, 2022 



Kaiju Wars 

Platform : PC

Release Date : April 28, 2022 



13 Sentinels: Aegis Rim 

Platform : Switch 

Release Date : April 12, 2022

## Elden Ring: 20 WEIRDEST Weapons You NEED TO SEE
 - [https://www.youtube.com/watch?v=fQ0A1TVlloY](https://www.youtube.com/watch?v=fQ0A1TVlloY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-03-26 00:00:00+00:00

Elden Ring (PC, PS5, PS4, Xbox Series X/S/One) is filled with strange, weird weapons. Here are some of our favorites.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#eldenring


# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: SuperNao - Sound Traveller (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=9R01F8v2LGI](https://www.youtube.com/watch?v=9R01F8v2LGI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-03-26 00:00:00+00:00

"Sound Traveller" (1995?) by SuperNao/Virtual Dreams (Michiel Krop). Art "Seaview" (1994) by Peachy/TRSI^Haujobb^Masque.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Infinite oversampling with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Standard 4 channel Protracker module

Visit my channel for more Amiga music.


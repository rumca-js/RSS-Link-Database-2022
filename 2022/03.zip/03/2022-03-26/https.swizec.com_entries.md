## Saving time in UTC doesn't work and offsets aren't enough | Swizec Teller
 - [https://swizec.com/blog/saving-time-in-utc-doesnt-work-and-offsets-arent-enough/](https://swizec.com/blog/saving-time-in-utc-doesnt-work-and-offsets-arent-enough/)
 - RSS feed: https://swizec.com
 - date published: 2022-03-26 18:58:02.396994+00:00

Lessons from a painful outage with timezones, UTC offsets, and database clients that took a whole week to resolve.


# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## 5 Router Settings You Should Change Now!
 - [https://www.youtube.com/watch?v=mJnIgjyjEtc](https://www.youtube.com/watch?v=mJnIgjyjEtc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2022-03-26 00:00:00+00:00

Thanks to Mine for Sponsoring: Find out which companies have your data and reclaim it 😤 by visiting ⇨ https://bit.ly/ThioJoe-saymine 

▼ Time Stamps: ▼
0:00 - Intro
2:13 - Accessing the Config Menu
3:46 - Setting #1
4:35 - Setting #2
7:04 - Setting #3
9:02 - Setting #4
11:30 - Setting #5
12:51 - Bonus Setting

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬


# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## CHEAP Full Body Tracking for Quest 2 users! [ HaritoraX ]
 - [https://www.youtube.com/watch?v=aZ4EnAgDA9E](https://www.youtube.com/watch?v=aZ4EnAgDA9E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-03-26 00:00:00+00:00

Hello! I have been so excited to cover the HaritoraX, a full body tracking method that doesn't require any basestations or special external hardware- and IT'S ACTUALLY GOOD! I got to try the HaritoraX at CES but finally I got my hands on the full production unit- and I am impressed. Full body tracking for all users, Quest 2, Index, Reverb G2, doesn't matter. Plus, FBT on the go! 

INVEST IN THRILLSEEKER MEDIA GROUP:
https://www.startengine.com/thrillseekermediagroup

Outro music:
https://soundcloud.com/etherealdelta/magic

MY LINKS:
Twitch.tv/thrilluwu
Discord.gg/Thrill
Twitter.com/Thrilluwu

HaritoraX link: https://en.shiftall.net/products/haritorax

00:00 INTRO
00:55 FULL BODY TRACKING BACKGROUND
02:00 HARITORAX SETUP
04:14 TRACKING
07:32 SLIMEVR/ OPEN SOURCE FUL BODY TRACKING
10:01 HARITOTAX FUTURE
11:48 OUTRO


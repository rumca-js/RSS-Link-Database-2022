# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## How Minnesota musicians are thriving on TikTok (Full LineCheck episode)
 - [https://www.youtube.com/watch?v=JcQzkRqxNJo](https://www.youtube.com/watch?v=JcQzkRqxNJo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-03-27 00:00:00+00:00

"TikTok is nothing like any other platform," musician Xavier Goodman says. "You can post something, and an audience of over thousands of people can see it within a matter of 24 hours. And it’s more realistic. You really can just be yourself, be authentic, show the true version of you."

Goodman is a Minnesotan musician with more than 750,000 TikTok fans, and in this episode of LineCheck, he joined Austin and Taryn Durry, Mark Mallman, and The Current's Local Show host Diane to talk about the viral video platform TikTok. Authenticity is key, all four musicians agreed. Also important: practicing your craft, keeping an open mind, and making the most of your time on Earth.

## How to blow up on TikTok? Be yourself
 - [https://www.youtube.com/watch?v=5twO8b5M_3s](https://www.youtube.com/watch?v=5twO8b5M_3s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-03-27 00:00:00+00:00

Xavier Goodman (@xaviergoodman1) and Mark Mallman (@markmallman) spill their secret to gaining TikTok fans.

For more of these musicians' and Durry's conversations about TikTok, check out their full LineCheck conversation: https://youtu.be/JcQzkRqxNJo

## Mark Mallman - True Love (Live for LineCheck)
 - [https://www.youtube.com/watch?v=v86sfbPX5bE](https://www.youtube.com/watch?v=v86sfbPX5bE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-03-27 00:00:00+00:00

Mark Mallman performs "True Love" from his 2004 album "Mr. Serious" for The Current's virtual event series LineCheck.

## Mark Mallman - The End Is Not The End (Live for LineCheck)
 - [https://www.youtube.com/watch?v=TSa17Qh2QeY](https://www.youtube.com/watch?v=TSa17Qh2QeY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-03-26 00:00:00+00:00

Mark Mallman performs "The End Is Not The End," the title song off his 2016 album, for The Current's virtual event series LineCheck.


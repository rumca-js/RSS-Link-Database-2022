# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## The #1 Phone... In PRISON - Worlds Smallest Phone - Zanco tiny t1
 - [https://www.youtube.com/watch?v=7xouEd5cVE8](https://www.youtube.com/watch?v=7xouEd5cVE8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-03-27 00:00:00+00:00

Start your free trial to Devolutions at https://lmg.gg/DevolutionsLTT

Check out Hetzner Cloud and use code LTT22 for $20 off at https://lmg.gg/l1qdg

Have you ever needed to smuggle a phone somewhere? We hope not, but if you DO need to, we've got the goods that can help you beat the boss.

Discuss on the forum: https://linustechtips.com/topic/1420868-this-phone-fits-in-your-%E2%80%A6-but-why/

Buy the ZANCO Tiny t1: https://geni.us/YxhxqiJ

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:07 Equipment
3:04 What's Inside
4:45 Using It
7:15 Call Quality
9:55 Sneaking Contraband
13:20 The Real Test
14:14 Conclusion
15:40 Outro

## DirectStorage on Windows will make games so much better
 - [https://www.youtube.com/watch?v=Xlf2I1TYd8U](https://www.youtube.com/watch?v=Xlf2I1TYd8U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-03-26 00:00:00+00:00

Get your NZXT Function Keyboard today at: https://nzxt.co/FunctionLTT

Break the code and win awesome prizes, including a $12,000 Dream setup: https://go.tech/linus

DirectStorage, which lets your GPU access your SSD directly, has promised to make games better for years now. While it’s been on Xbox Series X since launch (and PS5 has its own version), now we’re finally getting it for PC. Why was it worth the wait?

Discuss on the forum: https://linustechtips.com/topic/1420663-today-pc-gaming-catches-up-to-consoles/

Buy an AMD Ryzen 9 5950X: https://geni.us/nMA6el

Buy an ASUS Crosshair VIII Hero Wi-Fi: https://geni.us/B13k

Buy a GeForce RTX 3060: https://geni.us/WQMAcA

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:00 DirectStorage is underrated
1:40 Playing with the demo
3:18 How game assets are usually loaded
4:26 Previous attempts to address the problem
5:52 Enter DirectStorage - Bigger than you think
6:38 Performance scaling and compression
7:46 Not ready... Yet.


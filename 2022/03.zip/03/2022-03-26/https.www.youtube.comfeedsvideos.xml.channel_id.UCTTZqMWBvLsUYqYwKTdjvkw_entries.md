# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## Iluzja Deep Fake, czyli dezinformacja pełną gębą
 - [https://www.youtube.com/watch?v=W9YKvYsEhEw](https://www.youtube.com/watch?v=W9YKvYsEhEw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2022-03-27 00:00:00+00:00

Wraz ze wzrostem mocy obliczeniowej metody generowania sztucznych obrazów stają się coraz lepsze i coraz szerzej dostępne. Opowiem Wam dzisiaj o deep fejkach. Czym są? Czy da się je odróżnić od prawdziwych filmów? I czy deepfake mógł potencjalnie zmienić losy wojny?

Zapraszam!

Źródła:
👨‍💻 Materiał @Computerphile o Deep Fake
https://bit.ly/3qwhk2R

📰 @VICEo deep fake z Tomem Cruisem
https://bit.ly/3wAdKbE

🕶 @DeepTomCruise na TikToku
https://bit.ly/3wxtKeI

🦸‍♂️ Deepfake z prezydentem Zeleńskim
https://bit.ly/3IwQD47

❗ Ukraińskie służby ostrzegają przed deepfake
https://bit.ly/36FAf42

⛔ Digital Deceit: Fake News, Artificial Intelligence, and Censorship in Educational Research
https://bit.ly/36nnw6b

👾 Artefakty w służbie odkrywania deep fejków
https://bit.ly/36Iwefm

🌈 Odkrywanie Deep Fake za pomocą kolorów
https://bit.ly/3L4vtMs

🤯 Nienaturalne pozycje głowy pozwalają na odkrycie podrabianych materiałów
https://bit.ly/3D3ddjQ

🐍 Metody generowania deep fake unikające detekcji
https://bit.ly/3IsTStm

🌡 DeepFake-o-meter
https://bit.ly/3isLyiT

🤬 Projekt faceswap na githubie
https://bit.ly/3itPr6X

🐦 Detekcja fejkowych tweetow
https://bit.ly/3ukZXDg

🏆 Konkurs wykrywania DeepFake na kaggle
https://bit.ly/3ivBPIp

🦾 Trening w rozpoznawaniu DeepFake, wraz z MIT
https://bit.ly/36fXCBz

🤖 Wykrywanie deep fake przez ludzi, maszyny, oraz ludzi wspartych maszynami
https://bit.ly/36ICLX6 

🔍 Otwartoźródłowe narzędzia do wykrywania DeepFake
https://bit.ly/3LpUx0L

📖 Lista projektów opensource na githubie, gdzie walczą z deepfake
https://bit.ly/3iBq2se

❓ Czy Putin na stadionie to fejk? Czy montaż?
https://bit.ly/3ulVujz

🇫🇷 France24 o fejku z prezydentem Zelenskym
https://bit.ly/3JCOo0r

🥔 Źródło deepfake z Jasiem Fasolą w Wiedźminie
https://bit.ly/3NrTMpu

Jeżeli nie ufasz skracanym linkom (bardzo dobrze!) to dodaj na ich końcu plusik ‘+’.
W ten sposób podejrzysz na stronie bit.ly dokąd prowadzą.

Relevant xkcd: https://xkcd.com/1838/

© Wszystkie znaki handlowe należą do ich prawowitych właścicieli.

Dziękuję za Waszą uwagę. ❤️

© Wszystkie znaki handlowe należą do ich prawowitych właścicieli.

Dziękuję za Waszą uwagę. ❤️

Znajdziecie mnie również na;
Instagramie @mateuszemsi https://www.instagram.com/mateuszemsi/
Twitterze @MateuszChrobok https://twitter.com/MateuszChrobok
LinkedInie @mateuszchrobok https://www.linkedin.com/in/mateuszchrobok/
Podcasty na Anchor https://anchor.fm/mateusz-chrobok
Podcasty na Spotify https://open.spotify.com/show/6y6oWs20HwRejktOWHTteR
Podcast na  Apple Podcasts https://podcasts.apple.com/us/podcast/mateusz-chrobok-bezpiecze%C5%84stwo-startupy-i-sztuczna-inteligencja/id1617335932 
Patronite @MateuszChrobok https://patronite.pl/MateuszChrobok

#cyberbezpieczeństwo

Rozdziały:
00:00 Intro
00:22 Czym jest Deep Fake?
06:12 Zastosowanie
08:46 Wykrywanie
14:55 Co Robić i Jak Żyć?


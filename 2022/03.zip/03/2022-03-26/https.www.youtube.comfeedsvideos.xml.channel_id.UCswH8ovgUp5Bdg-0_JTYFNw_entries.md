# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Meta Is Brainwashing Your Children At School
 - [https://www.youtube.com/watch?v=eWr6OZx_SRY](https://www.youtube.com/watch?v=eWr6OZx_SRY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-03-27 00:00:00+00:00

An increasing number of digital products that monitor students’ online behavior are being adopted by schools in association with Big tech – so what’s in it for them? 
#BigTech #Schools #Facebook #Meta 

References
https://www.nationofchange.org/2022/03/19/how-big-tech-sees-big-profits-in-social-emotional-learning-at-school/

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## This Is Why America Is F**ked.
 - [https://www.youtube.com/watch?v=XDcOim_WSOI](https://www.youtube.com/watch?v=XDcOim_WSOI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-03-26 00:00:00+00:00

I spoke with Matt Taibbi, who is a journalist and the author of Hate Inc: Why Today's Media Makes Us Despise One Another... He joined me on Under The Skin to discuss why both parties are exactly the same. #Corruption #Corporations #Politics 

Matt's Substack: https://taibbi.substack.com/

Matt's Book: https://www.amazon.co.uk/Hate-Inc-Todays-Despise-Another/dp/1682194078/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Ukraine War Is A Resource War
 - [https://www.youtube.com/watch?v=w5skiiRHnpo](https://www.youtube.com/watch?v=w5skiiRHnpo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-03-26 00:00:00+00:00

Is the situation in Ukraine really a resource war dominated by corporate power?
#Russia #Ukraine #Putin #Biden

References
https://www.commondreams.org/views/2022/03/09/war-still-racket-corporate-power-and-russian-invasion-ukraine

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Daria Zawiałow - Zółta taksówka - live MUZO.FM
 - [https://www.youtube.com/watch?v=XHPEf0aSpoU](https://www.youtube.com/watch?v=XHPEf0aSpoU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2022-03-26 00:00:00+00:00

Daria Zawiałow na żywo w MUZO.FM. Utwór Żółta taksówka pochodzi z płyty Darii Zawiałow - Wojny i noce. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Daria Zawiałow: http://www.facebook.com/dariazawialow
Instagram Daria Zawiałow: http://www.instagram.com/zavialovd
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


Skład:
Daria Zawiałow
Michał Kush
Piotr Rubik
Justyna Jarzębińska 
Marta Podobas

Mix i mastering: Marek Heimbürger w SL SOUND Studio

#popolsku


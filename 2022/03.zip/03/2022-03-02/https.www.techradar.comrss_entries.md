# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Apple HomePod 2: everything you need to know
 - [https://www.techradar.com/news/apple-homepod-2-what-we-want-to-see](https://www.techradar.com/news/apple-homepod-2-what-we-want-to-see)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-03-02 17:20:40+00:00

The long wait is over, and a new HomePod is here. Here's everything you need to know about Apple's new wireless AirPlay speaker.

## Upcoming games 2022: all the game releases for console and PC
 - [https://www.techradar.com/news/upcoming-games-2022-release-dates/](https://www.techradar.com/news/upcoming-games-2022-release-dates/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-03-02 16:55:35+00:00

2022 is now winding down, but there's still so many great games to look forward to. Here are the best upcoming games for the rest of the year and beyond!

## Upcoming games 2022: all the game releases for console and PC
 - [https://www.techradar.com/news/upcoming-games-2022-release-dates](https://www.techradar.com/news/upcoming-games-2022-release-dates)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-03-02 16:55:35+00:00

Even though there's only a few weeks left in 2022, there's still plenty to look forward to. Here are the upcoming games to keep an eye on.

## New Xbox Series X games: all the upcoming releases
 - [https://www.techradar.com/news/new-xbox-series-x-games/](https://www.techradar.com/news/new-xbox-series-x-games/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-03-02 16:10:08+00:00

If you're looking for what new Xbox Series X games are on their way before the end of the year, look no further! Here's what you'll be playing over the coming months, and beyond.

## New Xbox Series X games: all the upcoming releases
 - [https://www.techradar.com/news/new-xbox-series-x-games](https://www.techradar.com/news/new-xbox-series-x-games)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-03-02 16:10:08+00:00

If you're looking for what new Xbox Series X games are on their way before the end of the year, look no further!

## New PS5 games: all the upcoming PlayStation 5 game releases
 - [https://www.techradar.com/news/new-ps5-games/](https://www.techradar.com/news/new-ps5-games/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-03-02 16:01:11+00:00

Here are the new PS5 games to look forward to in the coming months.

## New PS5 games: all the upcoming PlayStation 5 game releases
 - [https://www.techradar.com/news/new-ps5-games](https://www.techradar.com/news/new-ps5-games)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-03-02 16:01:11+00:00

Here are the new PS5 games to look forward to in the coming months. From Spider-Man 2, to Final Fantasy 16.


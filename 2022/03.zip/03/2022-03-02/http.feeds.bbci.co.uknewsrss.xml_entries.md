# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## What sanctions could still be imposed on Russia?
 - [https://www.bbc.co.uk/news/business-60529926?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60529926?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 23:41:20+00:00

The measures are tougher than anything Vladimir Putin has faced. But more could be coming.

## Brandon Lee: The model school pupil who was a 30-year-old imposter
 - [https://www.bbc.co.uk/news/uk-scotland-60081503?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-60081503?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 22:55:22+00:00

A new film tells the tale of a man who posed as 17-year-old to return to his old high school.

## FA Cup Highlights Luton 2-3 Chelsea: Romelu Lukaku hits late winner as Chelsea survive Luton scare
 - [https://www.bbc.co.uk/sport/av/football/60548288?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/60548288?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 22:35:03+00:00

Chelsea survive a scare against Championship side Luton Town as they are forced to come from behind twice as they secure a 3-2 victory after Romelu Lukaku's late winner.

## FA Cup: Romain Perraud stunner gives Southampton lead against West Ham
 - [https://www.bbc.co.uk/sport/av/football/60594698?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/60594698?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 20:34:25+00:00

Romain Perraud scores his first goal in English football with a stunning long-range effort puts Southampton ahead in their FA Cup fifth-round tie against West Ham.

## Banksy works sell for millions at auction
 - [https://www.bbc.co.uk/news/uk-england-bristol-60593493?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-bristol-60593493?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 20:14:45+00:00

The two pieces, owned by Robbie Williams, went under the hammer in London on Wednesday.

## 'Putin has to be stopped' - the Britons preparing to fight in Ukraine
 - [https://www.bbc.co.uk/news/uk-60594223?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60594223?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 19:26:28+00:00

We talk to some of the people responding to President Zelensky's appeal for foreigners to join in the defence of his country

## Ukraine conflict: Donations pile high at London centre
 - [https://www.bbc.co.uk/news/uk-60594383?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60594383?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 18:13:02+00:00

A Polish social club in London launched an appeal for donations to send to Poland and Ukraine.

## Ukraine conflict: Mum in Poland takes in fleeing families
 - [https://www.bbc.co.uk/news/world-europe-60593201?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60593201?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 17:51:37+00:00

Joanna is opening her home in Poland to Ukraine refugees seeking shelter after reaching the border.

## Crab.e.cam: The underwater crab videos captivating Australia
 - [https://www.bbc.co.uk/news/world-australia-60567193?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-60567193?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 17:36:44+00:00

When an Australian fisherman tied a GoPro to his crab net, he never expected the footage to go viral.

## Ukraine conflict: We need support from our allies, say Klitschko brothers
 - [https://www.bbc.co.uk/news/world-60592931?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-60592931?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 15:56:24+00:00

The mayor of Kyiv and his brother, both renowned boxers, spoke to the BBC from Kyiv.

## Russia and Belarus athletes 'neutral' at Paralympics
 - [https://www.bbc.co.uk/sport/disability-sport/60586037?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/disability-sport/60586037?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 12:52:44+00:00

Athletes from Russia and Belarus will compete as neutrals at the 2022 Winter Paralympics in Beijing.

## Middlesbrough's Beating Heart art installation made permanent
 - [https://www.bbc.co.uk/news/uk-england-tees-60589431?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-tees-60589431?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 12:51:08+00:00

The installation has returned to Middlesbrough's skyline after touring the country.

## Oil and gas surge sparks fears over new bill rises
 - [https://www.bbc.co.uk/news/business-60584798?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60584798?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 12:50:05+00:00

Oil and gas prices continue to march upward as Western nations clamp down on major producer Russia.

## Ryanair boss: Air fares will be higher this summer
 - [https://www.bbc.co.uk/news/business-60584219?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60584219?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 12:45:46+00:00

Soaring oil prices and Covid effects will push up air fares this summer, says Michael O'Leary.

## Ukraine invasion: Are Russia's attacks war crimes?
 - [https://www.bbc.co.uk/news/world-europe-60583926?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60583926?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 12:29:14+00:00

As Russia's invasion of Ukraine continues, does what we’re witnessing amount to war crimes?

## Ukraine crisis: MPs applaud Ukrainian ambassador in UK Parliament
 - [https://www.bbc.co.uk/news/uk-politics-60586758?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60586758?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 12:21:22+00:00

Watch as politicians stand and clap for Vadym Prystaiko, who was attending Prime Minister's Questions.

## Ukraine: Calls for no-fly zone rejected by defence secretary
 - [https://www.bbc.co.uk/news/uk-60583670?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60583670?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 12:05:37+00:00

Efforts to keep Russian jets away from Ukraine could lead to a larger war in Europe, Ben Wallace warns.

## Russian Formula 1 drivers banned from competing in UK
 - [https://www.bbc.co.uk/sport/formula1/60586914?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/60586914?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 12:03:53+00:00

Russian drivers have been banned from competing in the UK by the national motorsport authority, Motorsport UK.

## OneWeb: Russian ultimatum over UK satellite launch
 - [https://www.bbc.co.uk/news/uk-politics-60587154?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60587154?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 11:48:45+00:00

Russia's space agency demands guarantees OneWeb satellites won't be used for military purposes.

## London Tube strike: Passengers face severe disruption after RMT action
 - [https://www.bbc.co.uk/news/uk-england-london-60583831?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-60583831?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 11:26:37+00:00

Eight out of 11 London Underground lines remain affected by the impact of a 24-hour walkout.

## Roman Abramovich's Chelsea future in doubt
 - [https://www.bbc.co.uk/sport/football/60585081?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60585081?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 10:56:01+00:00

Roman Abramovich's future as Chelsea owner is in doubt after a Swiss billionaire claims he has been offered the chance to buy the club.

## Atherstone ball game returns for 822nd year after pandemic break
 - [https://www.bbc.co.uk/news/uk-england-coventry-warwickshire-60570047?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-coventry-warwickshire-60570047?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 10:49:39+00:00

The traditional Shrove Tuesday game involves people competing on the streets for a leather ball.

## Verstappen to sign lucrative new Red Bull deal - report
 - [https://www.bbc.co.uk/sport/formula1/60586046?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/60586046?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 10:03:33+00:00

World champion Max Verstappen is reportedly poised to commit his future to Red Bull in one of Formula 1's most lucrative deals.

## Children's author Shirley Hughes dies aged 94
 - [https://www.bbc.co.uk/news/entertainment-arts-60584090?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60584090?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 09:33:14+00:00

The writer and illustrator was known for popular works including Alfie and Dogger.

## Svitolina on a 'mission' for Ukraine after beating Russia's Potapova
 - [https://www.bbc.co.uk/sport/tennis/60584240?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/60584240?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 08:22:49+00:00

Ukraine's Elina Svitolina says it is her mission "to unite the tennis community" behind her country after beating Russian Anastasia Potapova at the Monterrey Open.

## Tyson Fury says he will retire after Dillian Whyte fight in April
 - [https://www.bbc.co.uk/sport/boxing/60576934?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/60576934?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 07:27:07+00:00

Britain's heavyweight world champion Tyson Fury says he will retire after the defence of his WBC title against Dillian Whyte in April.

## Middlesbrough 'buzzing' with FA Cup upset of 'typical Tottenham'
 - [https://www.bbc.co.uk/sport/football/60582130?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60582130?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 07:09:20+00:00

Middlesbrough continue their stunning FA Cup run as "typical" Tottenham crash out of the FA Cup.

## Tiny chapel near Lockerbie offers Ukraine a helping hand
 - [https://www.bbc.co.uk/news/uk-scotland-south-scotland-60570427?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-south-scotland-60570427?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 06:10:50+00:00

A corrugated iron hut was transformed into a chapel by prisoners of war in the 1940s.

## Forced adoption: Daughter says her mum is owed apology
 - [https://www.bbc.co.uk/news/uk-wales-60571243?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-60571243?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 06:02:07+00:00

Anne Jones's mother was 36 when she gave birth in 1951, but had no means to keep her daughter.

## Ukraine conflict: Russia's Kharkiv attacks are war crimes, says Zelensky
 - [https://www.bbc.co.uk/news/world-europe-60579247?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60579247?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 04:56:27+00:00

The Ukrainian president asks the EU to prove it is with his country, while accusing Russia of terrorism.

## Ukraine: Indian students living in fear of shelling in Kharkiv
 - [https://www.bbc.co.uk/news/world-asia-india-60551905?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-60551905?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 04:52:58+00:00

A day after shelling killed an Indian student, his friends recount the horror of trying to escape Ukraine.

## Ukraine crisis: Biden threatens to punish Putin over invasion
 - [https://www.bbc.co.uk/news/world-us-canada-60582210?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60582210?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 04:17:12+00:00

The US president calls Russia's president a "dictator" and vows to punish him over the Ukraine invasion.

## The Papers: 'Defiant' Ukraine faces 'barbaric' attacks
 - [https://www.bbc.co.uk/news/blogs-the-papers-60581600?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-60581600?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 04:13:42+00:00

The papers highlight the bravery of Ukrainians in the face of intensifying Russian missile strikes.

## Ukraine: Watching the war on Russian TV - a whole different story
 - [https://www.bbc.co.uk/news/world-europe-60571737?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60571737?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 01:13:40+00:00

The war in Ukraine has led to outrage in the West, but in Russia TV viewers see a very different story.

## Ukraine's tech community rises to challenges of war
 - [https://www.bbc.co.uk/news/technology-60559014?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-60559014?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 01:12:58+00:00

From an app to alert people to sirens, to organising supplies, tech firms are helping the war effort.

## Vaccines could mean only one smear test a lifetime
 - [https://www.bbc.co.uk/news/health-60526714?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-60526714?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 00:49:23+00:00

HPV jab is so successful that women who have it will not need screening every few years, says cancer scientist.

## CEO Secrets: Mikaela Jade of Indigital shares her advice
 - [https://www.bbc.co.uk/news/business-60523038?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60523038?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-03-02 00:13:47+00:00

Mikaela Jade, founder and CEO of Indigital, Australian's first Indigenous Ed-tech company, shares her advice.


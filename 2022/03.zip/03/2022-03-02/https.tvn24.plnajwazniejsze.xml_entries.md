# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "Putin to socjopata. Nie żywi współczucia dla kogokolwiek, a tym bardziej dla narodów"
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-1852,S00E1852,718395?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-1852,S00E1852,718395?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-03-02 17:02:42+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3lkxcn-wladimir-putin-5620329/alternates/LANDSCAPE_1280" />
    Reportaż Magdaleny Raczkowskiej.


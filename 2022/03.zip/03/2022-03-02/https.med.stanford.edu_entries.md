## Better mental health found among transgender people who started hormones as teens | News Center | Stanford Medicine
 - [https://med.stanford.edu/news/all-news/2022/01/mental-health-hormone-treatment-transgender-people.html](https://med.stanford.edu/news/all-news/2022/01/mental-health-hormone-treatment-transgender-people.html)
 - RSS feed: https://med.stanford.edu
 - date published: 2022-03-02 21:35:04.955169+00:00

Transgender adults who started gender-affirming hormone therapy as teens had better mental health than those who waited until adulthood or wanted the treatment but never received it, a Stanford-led study found. 


# Source:Serpentza, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl7mAGnY4jh4Ps8rhhh8XZg, language:en-US

## China Wants this War More than Russia! Celebrates the Invasion Online!
 - [https://www.youtube.com/watch?v=kxprOQuVamE](https://www.youtube.com/watch?v=kxprOQuVamE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl7mAGnY4jh4Ps8rhhh8XZg
 - date published: 2022-03-02 00:00:00+00:00

Chinese people have been Cheering on this invasion online, mocking Ukraine and praising Russia, and the CCP wants this...

For a deeper dive into China's Propaganda influence and soft power, watch our liveshow ADVPodcasts: https://www.youtube.com/advpodcasts

Support Sasha and I on Patreon: http://www.patreon.com/serpentza
Bitcoin - bc1qxfjp2t6x5dpslv59u0jl89m6k643hcn8h2jsvp
Ethereum - 0x6Da150a2A8529110017Ed4db68B3dF0084900280
Paypal: https://paypal.me/serpentza

DOCUMENTARY LINKS:
Conquering Southern China:
https://vimeo.com/ondemand/conqueringsouthernchina

Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina

Stay Awesome China (my new documentary): https://vimeo.com/ondemand/stayawesomechina

For Motorcycle adventures around the world, and a talk-show on two wheels go to ADVChina every Monday 1pm EST
https://www.youtube.com/advchina

For a realistic perspective on China and world travel from an American father and a Chinese mother with two half-Chinese daughters go to Laowhy86 every Wednesday 1pm EST
https://youtu.be/mErixa-YIJE

For a no-nonsense on the street look at Chinese culture and beyond from China's original YouTuber, join SerpentZA on Friday at 1pm EST
https://www.youtube.com/serpentza

Join me on Facebook: http://www.facebook.com/winstoninchina
Twitter: @serpentza
Instagram: serpent_za


# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Netflix pauses future projects in Russia
 - [https://www.bbc.co.uk/news/technology-60596699?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-60596699?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-03-02 21:47:57+00:00

US technology giants Netflix and Oracle are the latest to move to distance themselves from Russia


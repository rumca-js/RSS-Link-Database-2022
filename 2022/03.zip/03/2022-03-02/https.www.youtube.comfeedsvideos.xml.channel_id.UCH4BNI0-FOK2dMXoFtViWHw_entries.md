# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## The Magic of Mirrors (Explained With Science)
 - [https://www.youtube.com/watch?v=ihQyEkLYtP8](https://www.youtube.com/watch?v=ihQyEkLYtP8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2022-03-03 00:00:00+00:00

Thank you to Brilliant for supporting PBS. To learn more, go to: https://brilliant.org/BeSmart/
We’re on PATREON! Join the community https://www.patreon.com/itsokaytobesmart
↓↓↓ More info and sources below ↓↓↓

How many times do you look in a mirror every day? Have you ever stopped to wonder how they actually work? Mirrors do strange things to our world, seemingly flipping everything so that what was right is left and what was left is right. But what if I told you that mirrors don’t actually flip the world left to right? The real magic of mirrors is far stranger and more interesting, as you’re about to learn.

Inspired by:
Gardner, Martin - The New Ambidextrous Universe: Symmetry and Asymmetry from Mirror Reflections to Superstrings

Check out It's Lit: Unabridged, a new podcast from PBS:
iTunes: https://podcasts.apple.com/us/podcast/its-lit-unabridged/id1603688708
Spotify: https://open.spotify.com/show/4XOCT3jhB12mYcbA15h7zx

-----------

Special thanks to our Brain Trust Patrons:

Mehdi Damou
Barbora Bei
Ken Board
The Clinger-Hamilton Family
Attila Pix
Burt Humburg
DeliciousKashmiri
Brian Chang
Roy Lasris
dani bowman
David Johnston
Salih Arslan
Baerbel Winkler
Robert Young
Amy Sowada
Eric Meer
Dustin
Karen Haskell
AlecZero

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/


## Tell HN: If You Are in Russia | Hacker News
 - [https://news.ycombinator.com/item?id=30508314](https://news.ycombinator.com/item?id=30508314)
 - RSS feed: https://news.ycombinator.com
 - date published: 2022-03-02 07:03:08.241393+00:00




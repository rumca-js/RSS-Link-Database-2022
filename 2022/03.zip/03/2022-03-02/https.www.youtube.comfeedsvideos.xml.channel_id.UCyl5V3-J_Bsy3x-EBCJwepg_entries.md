# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Brave New Army Commercial Promotes Inclusion And Diversity
 - [https://www.youtube.com/watch?v=nVUcevfmzEM](https://www.youtube.com/watch?v=nVUcevfmzEM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-03-03 00:00:00+00:00

In this new commercial from the U.S. Army, everyone's favorite branch of the military promotes their new, more diverse, more inclusive standards. From gender reveal grenades to more affirming drill sergeants, the Army is leading the way in inclusion!

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## LIVE: The State of the Union Address
 - [https://www.youtube.com/watch?v=5vAWl1yhWzQ](https://www.youtube.com/watch?v=5vAWl1yhWzQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-03-02 00:00:00+00:00

The Babylon Bee is here with the best camera angles and coverage of Biden's State of the Union address. Don't believe what you see on CNN or Fox News -- this is the real deal.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

#babylonbee #stateoftheunion #comedy #usa


# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Ukraine and Russia: What the Media Wants You To Think!
 - [https://www.youtube.com/watch?v=q1W5o3Xz5OI](https://www.youtube.com/watch?v=q1W5o3Xz5OI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-03-02 00:00:00+00:00

Grab your Blue Light Blocking Glasses at https://blublox.com/jp
Use Code "JP" for 15% Off!

Check Out My Merch Here - https://awakenwithjp.com

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Ukraine and Russia, here’s what the media wants you to think! As Putin and Russia unjustly invade Ukraine, why are they doing it? The brave Ukrainians are fighting Russian soldiers. Will they succeed? Should the US send military troops over to help protect Ukraine’s democracy?

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com


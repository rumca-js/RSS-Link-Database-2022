## Jobfished: the con that tricked dozens into working for a fake design agency - BBC News
 - [https://www.bbc.co.uk/news/uk-60387324](https://www.bbc.co.uk/news/uk-60387324)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2022-03-02 18:32:47.281569+00:00

Dozens of young people were tricked into thinking they were working for a glamorous UK design agency - which didn’t really exist.


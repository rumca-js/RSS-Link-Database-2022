# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## It's Official: They Lied
 - [https://www.youtube.com/watch?v=t0KB0Wl4TNs](https://www.youtube.com/watch?v=t0KB0Wl4TNs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-03-03 00:00:00+00:00

As Canada’s finance intelligence expert admits that Freedom Convoy donors posed no threat, we ask, what’s the real reason they were cut off from financial services?

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## War Is Profitable, This Is How
 - [https://www.youtube.com/watch?v=QnevpbkFrPE](https://www.youtube.com/watch?v=QnevpbkFrPE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-03-02 00:00:00+00:00

The Russian invasion of Ukraine continues. As do the pundits calling for military action.  
#Russia #Ukraine #War #Putin #Biden #WW3 

References
https://www.codepink.org/
https://www.commondreams.org/views/2022/02/24/putin-ukraine-bush-iraq-illegal-invasions-must-be-condemned
https://www.commondreams.org/views/2022/02/26/ukraine-and-myth-war

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


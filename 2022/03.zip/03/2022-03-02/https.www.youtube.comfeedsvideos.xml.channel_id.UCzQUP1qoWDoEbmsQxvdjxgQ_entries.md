# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Michael Jai White is a Legit Martial Artist
 - [https://www.youtube.com/watch?v=NgTOEC_-QMI](https://www.youtube.com/watch?v=NgTOEC_-QMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-03-02 00:00:00+00:00

Taken from JRE #1786 w/Freddie Gibbs and Brian Moses:
https://open.spotify.com/episode/20faSH30pfYG1bdwzzjpsr?si=815c966f2e234536

## Veteran Dakota Meyer on Receiving Ibogaine Therapy for PTSD
 - [https://www.youtube.com/watch?v=3eZnbWTb1YE](https://www.youtube.com/watch?v=3eZnbWTb1YE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-03-02 00:00:00+00:00

Taken from JRE #1787 w/Dakota Meyer:
https://open.spotify.com/episode/23UU1WhuEeHbXbTKIi7scJ?si=89eec74b97b64cb0

## What if Guys Could Make Millions Selling Sperm?
 - [https://www.youtube.com/watch?v=nHt_qPb7ULw](https://www.youtube.com/watch?v=nHt_qPb7ULw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-03-02 00:00:00+00:00

Taken from JRE #1786 w/Freddie Gibbs and Brian Moses:
https://open.spotify.com/episode/20faSH30pfYG1bdwzzjpsr?si=1a104630efcb4c03


# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Dope Tech: Weirdest Earbuds I've Ever Tried!
 - [https://www.youtube.com/watch?v=-EZ_3Tq9a8c](https://www.youtube.com/watch?v=-EZ_3Tq9a8c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-03-02 00:00:00+00:00

Enter the giveaway by following at the links below!

Twitter:
✅ https://twitter.com/Mrwhosetheboss
✅ https://twitter.com/dbrand
✅ https://twitter.com/MKBHD

Instagram:
✅ https://instagram.com/Mrwhosetheboss
✅ https://instagram.com/dbrand
✅ https://instagram.com/MKBHD

YouTube:
✅ https://youtube.com/Mrwhosetheboss
✅ https://youtube.com/MrwhosethebossShorts1
✅ https://youtube.com/dbrand
✅ https://youtube.com/MKBHD
✅ https://www.youtube.com/c/MKBHDShort

Facebook:
✅ https://facebook.com/Mrwhosetheboss
✅ https://facebook.com/dbrand
✅ https://facebook.com/MKBHD

Visit https://dbrand.com/winners for giveaway details. It's free and worldwide!

xScreen for XBox: https://upspecgaming.com
Sony Linkbuds: https://amzn.to/3ISRL3f
Asus ROG Flow Z13: https://rog.asus.com/laptops/rog-flow/rog-flow-z13-2022-series/
USB-C cable with screen: https://amzn.to/3HBUexo

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

xScreen provided by UPSpec Gaming. LinkBuds provided by Sony. Z13 Provided by Asus.


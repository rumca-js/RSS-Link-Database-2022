# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## LTT: The Video Game!
 - [https://www.youtube.com/watch?v=NIElzDm-Ki8](https://www.youtube.com/watch?v=NIElzDm-Ki8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-03-03 00:00:00+00:00

Thanks to Gigabyte for sponsoring the video! Learn more about the Gigabyte AERO 16 laptop here: https://lmg.gg/5j55o

Want to make a game? It's both easier AND harder than you might think, but with some patience and the ability to Google issues, anything is possible.

Thanks as well to Unity for providing their Pro license for this video. Check out Unity Pro at https://lmg.gg/UnityProLTT

Finally, thanks to Coding in Flow for his tutorial. If you want to do this yourself, check out the tutorial here: https://www.youtube.com/watch?v=Ii-scMenaOQ&list=PLrnPJCHvNZuCVTz6lvhR81nnaf1a-b67U

Link to game: https://lmg.gg/z5Dyl

Discuss on the forum: https://linustechtips.com/topic/1415733-we-made-a-video-game-in-12-hours/

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Game dev is hard
1:11 End result after 12 hours
2:25 Assets we used
4:02 What hardware can you use for game dev?
5:58 Playing Plouffe's old student project
8:38 Is game dev easy?

## I don’t get it Intel… - New Stock Cooler Review
 - [https://www.youtube.com/watch?v=2qrmqV5B6OQ](https://www.youtube.com/watch?v=2qrmqV5B6OQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-03-02 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Check out SignalRGB and sync all your RGB peripherals at https://bit.ly/SRGB-LMGF

Intel’s included CPU cooler’s have been function over form for YEARS – but their new line of in-the-box coolers are looking to change that, and they may even offer better performance too.

Discuss on the forum: https://linustechtips.com/topic/1415504-i-dont-get-it-intel-12th-gen-coolers/

Buy an MSI PRO Z690-A WiFi Motherboard: https://geni.us/AwXy8Y

Buy an Intel Core i7-12700K: https://geni.us/oTUR

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:10 The Old Guard 
1:45 Intel's new coolers 
3:07 Testing methodology 
4:39 The numbers
5:43 Fans
7:14 Beauty over brawn? 
7:52 Thoughts


# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Redban Tries Jujimufu's Smelling Salts
 - [https://www.youtube.com/watch?v=graEEzEkQtY](https://www.youtube.com/watch?v=graEEzEkQtY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-07-07 00:00:00+00:00

Taken from JRE #1841 w/Brian Redban:
https://open.spotify.com/episode/1KLPEuwJYASc9nRm3qitwL?si=a8d987d610ba4dcc

## The Amount of Round-Up & Plastic Contamination in Food
 - [https://www.youtube.com/watch?v=WEeJ9B1i8HI](https://www.youtube.com/watch?v=WEeJ9B1i8HI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-07-07 00:00:00+00:00

Taken from JRE #1841 w/Brian Redban:
https://open.spotify.com/episode/1KLPEuwJYASc9nRm3qitwL?si=a8d987d610ba4dcc

## Has Google Created Sentient AI?
 - [https://www.youtube.com/watch?v=RB-O0V9djEs](https://www.youtube.com/watch?v=RB-O0V9djEs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-07-06 00:00:00+00:00

Taken from JRE #1840 w/Marc Andreessen:
https://open.spotify.com/episode/2JDW5u8BlKHM5C5wInOT4u?si=141742e0e2b44a40


# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## A Comprehensive List Of All The Countries Where Communism Has Worked
 - [https://www.youtube.com/watch?v=i8Nz8ytJCy8](https://www.youtube.com/watch?v=i8Nz8ytJCy8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-07-07 00:00:00+00:00

In a collaboration with The Babylon Bee, Professor Gorb McStevens lists all the countries where communism hasn't turned into a totalitarian hellscape where you have to eat your dog.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Dismantling Islam With David Wood | A Bee Interview
 - [https://www.youtube.com/watch?v=HBpPxR-gO28](https://www.youtube.com/watch?v=HBpPxR-gO28)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-07-06 00:00:00+00:00

Head of Acts 17 Apologetics and sociopath David Wood discusses Islam, imprisonment, and personality disorders with The Babylon Bee. An important episode for anyone interested in talking to Muslims about the gospel message.

Check out Acts 17 Apologetics here: http://www.acts17.net/

And on YouTube: https://www.youtube.com/c/Acts17Apologetics

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


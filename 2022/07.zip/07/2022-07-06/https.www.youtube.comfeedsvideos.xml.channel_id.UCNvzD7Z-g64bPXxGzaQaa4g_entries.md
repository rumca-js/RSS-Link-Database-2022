# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## PS5 PRO: 8 Things We DON'T WANT
 - [https://www.youtube.com/watch?v=WjZ0VtLN4nA](https://www.youtube.com/watch?v=WjZ0VtLN4nA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-07-07 00:00:00+00:00

The PS5 Pro won't be a thing anytime soon, but however Sony decides to update the PS5, we've got a list of some things we don't want from it.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 Most DISAPPOINTING Games of 2022 [First Half]
 - [https://www.youtube.com/watch?v=msKOivZh8MU](https://www.youtube.com/watch?v=msKOivZh8MU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-07-06 00:00:00+00:00

2022 has already seen some great games, but we've also gotten plenty of misses. Here are the games that have disappointed us the most in this first half of the year.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro 
0:15 House of The Dead REMAKE
1:27 CHOCOBO GP
2:16 Vampire: The Masquerade - Swansong
3:34 Diablo Immortal
4:45 Dolmen
5:52 Dynasty Warriors 9 Empires
6:38 Babylon's Fall
7:57 CROSSFIRE X
9:47 Postal 4: No Regerts
11:05 Waifu Impact


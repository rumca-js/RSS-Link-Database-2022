# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Take down this video, Nintendo. I dare you. - Switch games on Steam Deck
 - [https://www.youtube.com/watch?v=oIYvPNtWZ34](https://www.youtube.com/watch?v=oIYvPNtWZ34)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-07-07 00:00:00+00:00

You can get 50% off your first month of KiwiCo at: http://kiwico.com/LTT

Nintendo made news for taking down YouTubers so much as showing emulation of Switch titles on Steam Deck. We’re taking it a step further and showing you how to do it. The right way.

Discuss on the forum: https://linustechtips.com/topic/1441761-hi-nintendo/
Watch on Floatplane.com to bypass the blurring! https://www.floatplane.com/

Check out the Valve Steam Deck: https://lmg.gg/VNaLA
Buy a Nintendo Switch: https://geni.us/ya62LVt
Buy a Nintendo Switch OLED: https://geni.us/zA3Bwt4

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro & Switch games on the Steam Deck!
3:33 Why we blurred the gameplay (floatplane.com)
4:00 Why should you do this?
4:40 How to jailbreak your switch & pull games off of it
8:41 How to setup the Steam Deck & emulator
11:13 Drawbacks & benefits
12:00 Disclaimer about legality & piracy

## I saved the best for last - Intel Design Center Development Motherboard
 - [https://www.youtube.com/watch?v=pyVZ05SO0Ic](https://www.youtube.com/watch?v=pyVZ05SO0Ic)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-07-06 00:00:00+00:00

Checkout iFixit's toolkits at: https://www.iFixit.com/LTT 

In the last part of my Intel Israel Design Center tour we got to go deeper into their validation lab and see up close and personal what a development motherboard and the tools around it look like.

Discuss on the forum: https://linustechtips.com/topic/1441525-this-secret-motherboard-is-priceless/

Learn more about Intel Transistors: https://youtu.be/Z7M8etXUEUU

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro & Motherboard
6:46 The TOP & Remote Validation
8:07 Cooling & The Thermal Head
9:28 Hot-Swap Chipset? Think Again
10:03 The Overclocking Lab
14:19 The Game Demo Room
16:47 Thank You


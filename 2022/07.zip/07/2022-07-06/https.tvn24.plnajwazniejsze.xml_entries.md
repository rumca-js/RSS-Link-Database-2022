# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Liczba narodzin spada, rośnie strach. Co robi rząd, by Polki (nie)chciały rodzić dzieci?
 - [https://tvn24.pl/premium/rejestr-ciaz-wchodzi-w-zycie-co-na-to-demografowie-liczba-narodzin-spada-rosnie-strach-5775277?source=rss](https://tvn24.pl/premium/rejestr-ciaz-wchodzi-w-zycie-co-na-to-demografowie-liczba-narodzin-spada-rosnie-strach-5775277?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-07-06 04:40:00+00:00

<img alt="Liczba narodzin spada, rośnie strach. Co robi rząd, by Polki (nie)chciały rodzić dzieci?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wqlruw-pluszak-lozko-dziecko-shutterstock1343955434-6209695/alternates/LANDSCAPE_1280" />
    Ministerstwo Zdrowia przekonuje, że to europejski standard. Wiele kobiet obawia się jednak, że to kolejne narzędzie kontroli, które może ułatwić poszukiwanie "zaginionych ciąż".


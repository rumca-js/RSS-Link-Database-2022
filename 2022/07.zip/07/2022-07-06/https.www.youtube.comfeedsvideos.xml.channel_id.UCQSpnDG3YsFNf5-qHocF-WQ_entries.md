# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## Are Computer Glasses a Scam? - Light Spectrum Analysis
 - [https://www.youtube.com/watch?v=3yrg2ZxrLdg](https://www.youtube.com/watch?v=3yrg2ZxrLdg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2022-07-07 00:00:00+00:00

It's more interesting than you might think 🤔

Amazon Links (Affiliate):
• Gunnar Amber Glasses: https://geni.us/GunnarAmber
• Spectra479 Glasses (Full Blue Blocking): https://geni.us/SpectraGlasses (Personally recommended, I use these myself)

Other Links:
• F.lux Software: https://justgetflux.com/
• Blackbody Spectrum Simulator: https://phet.colorado.edu/en/simulations/blackbody-spectrum

⇒ Become a channel member for special emojis, early videos, and more! Check it out here: https://www.youtube.com/ThioJoe/join

▼ Time Stamps: ▼
0:00 - Intro
0:35 - Use Case: Viewing Light Spectrums
3:10 - Various Measurements on Device
3:41 - Use Case: Videography
6:49 - Testing Blue-Blocker Glasses (Explanation)
8:46 - Test: "Clear" Lenses
11:29 - Test: "Amber" Lenses
12:35 - Test: True Blue Blockers
14:33 - Light Quality
16:32 - "Bad Light" Extreme Example
17:57 - How Light Quality is Rated
20:01 - The TM-30 Rating

Note: The links above are Amazon affiliate links, which means I'll probably get a small (usually ~1-2%) commission that helps support the channel if you decide to buy the item. The commission does not come out of your pocket, but rather from Amazon's.

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬


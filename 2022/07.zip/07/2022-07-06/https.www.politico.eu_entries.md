## Police fire on Dutch farmers protesting environmental rules – POLITICO
 - [https://www.politico.eu/article/police-fire-dutch-farmer-protest-nitrogen-emission-cut/](https://www.politico.eu/article/police-fire-dutch-farmer-protest-nitrogen-emission-cut/)
 - RSS feed: https://www.politico.eu
 - date published: 2022-07-06 08:54:54+00:00

Police fire on Dutch farmers protesting environmental rules – POLITICO


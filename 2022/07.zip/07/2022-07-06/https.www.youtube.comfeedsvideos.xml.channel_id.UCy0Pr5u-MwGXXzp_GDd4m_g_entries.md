# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Explaining the Pandemic to my Past Self Part 7
 - [https://www.youtube.com/watch?v=2UkeDPfKSgk](https://www.youtube.com/watch?v=2UkeDPfKSgk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2022-07-07 00:00:00+00:00

What would happen if I tried to explain what's happening now to the January 2022 version of myself?
Part 1 here: https://youtu.be/Ms7capx4Cb8
Part 2 here: https://youtu.be/xdyDpP2s-og
Part 3 here: https://youtu.be/Pbdk_lBCxJk
Part 4 here: https://youtu.be/VYdAQKoUm7o
1 Year Later here: https://youtu.be/fqlPsAAsZss
Part 5 here: https://youtu.be/fmADQYJe6ZY
Part 6 here: https://youtu.be/C_evvyk1_Vk

Written by: Julie Nolke
Shot by: Samuel Larson
Editor: Alec Mckay

Support the channel by liking and subscribing! 
Join my Patreon for behind the scenes videos and early access to videos here: https://www.patreon.com/julienolke


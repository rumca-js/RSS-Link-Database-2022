# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Subsonic Eye - Bug In Spring (Live on KEXP)
 - [https://www.youtube.com/watch?v=XeaNWY2hQ2I](https://www.youtube.com/watch?v=XeaNWY2hQ2I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-07 00:00:00+00:00

http://KEXP.ORG presents Subsonic Eye performing “Bug In Spring” live in the KEXP studio. Recorded June 15, 2022.

Nur Wahidah binte Abdul Halim - Vocals
Daniel Castro Borces - Guitarist
Jared Lim Junsheng - Guitarist
Spencer Tan Lizao - Bassist
Lucas Tee Ye Xuan - Drummer

Host: Evie
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://subsoniceye.bandcamp.com
http://kexp.org

## Subsonic Eye - Fruitcake (Live on KEXP)
 - [https://www.youtube.com/watch?v=sulVJ31GWVo](https://www.youtube.com/watch?v=sulVJ31GWVo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-07 00:00:00+00:00

http://KEXP.ORG presents Subsonic Eye performing “Fruitcake” live in the KEXP studio. Recorded June 15, 2022.

Nur Wahidah binte Abdul Halim - Vocals
Daniel Castro Borces - Guitarist
Jared Lim Junsheng - Guitarist
Spencer Tan Lizao - Bassist
Lucas Tee Ye Xuan - Drummer

Host: Evie
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://subsoniceye.bandcamp.com
http://kexp.org

## Subsonic Eye - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=LZDqLttdgmQ](https://www.youtube.com/watch?v=LZDqLttdgmQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-07 00:00:00+00:00

http://KEXP.ORG presents Subsonic Eye performing live in the KEXP studio. Recorded June 15, 2022.

Songs:
Bug In Spring
Fruitcake
Yearning
J-O-B

Nur Wahidah binte Abdul Halim - Vocals
Daniel Castro Borces - Guitarist
Jared Lim Junsheng - Guitarist
Spencer Tan Lizao - Bassist
Lucas Tee Ye Xuan - Drummer

Host: Evie
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://subsoniceye.bandcamp.com
http://kexp.org

## Subsonic Eye - J-O-B (Live on KEXP)
 - [https://www.youtube.com/watch?v=wdJ3QGOFfMQ](https://www.youtube.com/watch?v=wdJ3QGOFfMQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-07 00:00:00+00:00

http://KEXP.ORG presents Subsonic Eye performing “J-O-B” live in the KEXP studio. Recorded June 15, 2022.

Nur Wahidah binte Abdul Halim - Vocals
Daniel Castro Borces - Guitarist
Jared Lim Junsheng - Guitarist
Spencer Tan Lizao - Bassist
Lucas Tee Ye Xuan - Drummer

Host: Evie
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://subsoniceye.bandcamp.com
http://kexp.org

## Subsonic Eye - Yearning (Live on KEXP)
 - [https://www.youtube.com/watch?v=InPtad-cvnc](https://www.youtube.com/watch?v=InPtad-cvnc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-07 00:00:00+00:00

http://KEXP.ORG presents Subsonic Eye performing “Yearning” live in the KEXP studio. Recorded June 15, 2022.

Nur Wahidah binte Abdul Halim - Vocals
Daniel Castro Borces - Guitarist
Jared Lim Junsheng - Guitarist
Spencer Tan Lizao - Bassist
Lucas Tee Ye Xuan - Drummer

Host: Evie
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://subsoniceye.bandcamp.com
http://kexp.org

## Yann Tiersen - 11 5 18  1 12  12 15 3 8 (Live on KEXP)
 - [https://www.youtube.com/watch?v=N9dgKp94wT4](https://www.youtube.com/watch?v=N9dgKp94wT4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-06 00:00:00+00:00

http://KEXP.ORG presents Yann Tiersen performing “11 5 18  1 12  12 15 3 8” live in the KEXP studio. Recorded June 13, 2022.

Yann Tiersen - Modular Synth / Octatrack
Jens Thomsen - MPC / Effects
Emilie Tiersen - Vocals

Host: Evie
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.yanntiersen.com
http://kexp.org

## Yann Tiersen - 13 1 18 25 6 5 1 20  17 21 9 14 17 21 9 19 (Live on KEXP)
 - [https://www.youtube.com/watch?v=h7rAaAWoFmM](https://www.youtube.com/watch?v=h7rAaAWoFmM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-06 00:00:00+00:00

http://KEXP.ORG presents Yann Tiersen performing “13 1 18 25 6 5 1 20  17 21 9 14 17 21 9 19 (feat. QUINQUIS)” live in the KEXP studio. Recorded June 13, 2022.

Yann Tiersen - Modular Synth / Octatrack
Jens Thomsen - MPC / Effects
Emilie Tiersen - Vocals

Host: Evie
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.yanntiersen.com
http://kexp.org

## Yann Tiersen - 16 15 21 12 12  2 15 10 5 18 (Live on KEXP)
 - [https://www.youtube.com/watch?v=A9HtDaMF0O4](https://www.youtube.com/watch?v=A9HtDaMF0O4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-06 00:00:00+00:00

http://KEXP.ORG presents Yann Tiersen performing “16 15 21 12 12  2 15 10 5 18” live in the KEXP studio. Recorded June 13, 2022.

Yann Tiersen - Modular Synth / Octatrack
Jens Thomsen - MPC / Effects
Emilie Tiersen - Vocals

Host: Evie
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.yanntiersen.com
http://kexp.org

## Yann Tiersen - 3 8 1 16 20 5 18  14 9 14 5 20 5 5 14 (Live on KEXP)
 - [https://www.youtube.com/watch?v=h-smwbA1zig](https://www.youtube.com/watch?v=h-smwbA1zig)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-06 00:00:00+00:00

http://KEXP.ORG presents Yann Tiersen performing “3 8 1 16 20 5 18  14 9 14 5 20 5 5 14” live in the KEXP studio. Recorded June 13, 2022.

Yann Tiersen - Modular Synth / Octatrack
Jens Thomsen - MPC / Effects
Emilie Tiersen - Vocals

Host: Evie
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.yanntiersen.com
http://kexp.org

## Yann Tiersen - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=pxTm2csHjSk](https://www.youtube.com/watch?v=pxTm2csHjSk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-06 00:00:00+00:00

http://KEXP.ORG presents Yann Tiersen performing live in the KEXP studio. Recorded June 13, 2022.

Songs:
16 15 21 12 12. 2 15 10 5 18
13 1 18 25  (6 5 1 20. 17 21 9 14 17 21 9 19)
11 5 18. 1 12. 12 15 3 8
3 8 1 16 20 5 18. 14 9 14 5 20 5 5 14

Yann Tiersen - Modular Synth / Octatrack
Jens Thomsen - MPC / Effects
Emilie Tiersen - Vocals

Host: Evie
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.yanntiersen.com
http://kexp.org


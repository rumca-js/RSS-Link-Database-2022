## Auto manufacturer family tree: Who owns what?
 - [https://www.whichcar.com.au/car-advice/car-manufacturer-brands-family-tree](https://www.whichcar.com.au/car-advice/car-manufacturer-brands-family-tree)
 - RSS feed: https://www.whichcar.com.au
 - date published: 2022-07-06 19:25:40.824698+00:00

You might be surprised how the world's top car brands are shared around just a few parent companies


# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Expiration Date // POMPLAMOOSE ft. Nahneen Kula
 - [https://www.youtube.com/watch?v=7hwNCMX2vNg](https://www.youtube.com/watch?v=7hwNCMX2vNg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2022-07-07 00:00:00+00:00

It’s a cover of a Pomplamoose original, except with someone else singing lead vocals and playing bass, but also I’m on background vocals. It’s confusing. But it works. Because Nahneen Kula can do whatever she wants and make it great.

Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of Pomplamoose original "Expiration Date" by Pomplamoose & Nahneen Kula.

MUSICIAN CREDITS
Lead Vocals: Nahneen Kula
Background Vocals: Nataly Dawn, Loren Battley
Keys: Jack Conte
Guitar:  John Schroeder
Bass: Sammy Rothman
Drums: Ben Rose

AUDIO CREDITS
Engineer: Tim Sonnefeld
Assistant Engineer: Tyler Karmen
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
Director: Dom Fera
DP: Christian Colwell
Camera Operators: Harrison Bliss, Christopher Li
Gaffer: Arjay Ancheta
Lighting Tech: Brandon Garman
Production Designer: Shannon McDonough
Video Editor/Colorist: Athena Wheaton

Recorded at 64 Sound in Los Angeles.

LYRICS
Waiting for nothing to start
It's getting late
Why don't we call it a day
I could easily go for a drink
Watching you shrink
This isn't easy to say
But I'd like to get over
I'd like get over you

Never knew love was a fad
You fooled me bad
Wish you were easy to hate
But I'm stuck in the middle for now
Wondering how
I entertain this debate
And I'd like to get over
I'd like to get over you

Why did you stop
Doing the things you did
To make me fall
When did you start
Framing my dreams
To hang on your white walls

Dinner for two lost it's taste
When I embraced
All of your leftover bait
And I wish we had never gone stale
But who could tell
Your expiration date
Oh I'd like to get over
I'd like to get over you

Why did you stop
Building our little house
The picket fence
When did you start
Complimenting in past
And future tense

Stop
Wandering through my mind
As you once were
Start
Hoping that I'll come back
When you're the last man on earth

I guess that I should have known
Throw the first stone
If you feel perfect today
Oh I'd like to get over
I'd like to get over you


# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Rings of Power Teaser 2 BREAKDOWN | The Lord of the Rings on Prime
 - [https://www.youtube.com/watch?v=PMvUby_qI8Y](https://www.youtube.com/watch?v=PMvUby_qI8Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-07-06 00:00:00+00:00

Today, we got a new 1-minute teaser for The Lord of the Rings: The Rings of Power, with almost entirely new footage.  We got our first official looks at Tar-Miriel and ents, in addition to some intriguing shots of Galadriel, Elrond, and some Numenorean statues!

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

Art in the video:
Isildur with the Fruit of Nimloth - Sara Morello
Sara Morello - https://www.artstation.com/saramorello
Sauron - Jerry Vanderstelt
Jerry Vanderstelt - https://store.vandersteltstudio.com/main.sc

#lordoftherings #ringsofpower #lotronprime


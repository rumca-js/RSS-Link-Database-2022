# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Surely, This Didn't Just Happen...
 - [https://www.youtube.com/watch?v=w1_hYe3hhjE](https://www.youtube.com/watch?v=w1_hYe3hhjE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-07-07 00:00:00+00:00

The Democrat party. Nothing to see here, it’s all tickety-boo, plain sailing. Oh, other than the 1 million voters who’ve deserted them in favour of the Republicans. But that can’t have anything to do with Joe Biden and Kamala Harris, can it? #democrat #joebiden #kamalaharris 

References
https://www.pbs.org/newshour/politics/more-than-1-million-voters-switch-to-gop-raising-alarm-for-democrats
--------------------------------------------------------------------------------------------------------------------------
Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Don’t Be Fooled
 - [https://www.youtube.com/watch?v=eslgiZhs0js](https://www.youtube.com/watch?v=eslgiZhs0js)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-07-06 00:00:00+00:00

This week I spoke with David Sirota - award-winning journalist & writer and founder of Investigative News Site ‘The Lever’. We spoke about the weaponisation of identity against universalism in the economic sphere, such as why economic giants like JP Morgan, Goldman Sachs & Wall Street put up flags in support for identity issues. #corporation #pride #banks 

Visit The Lever: https://www.levernews.com/
--------------------------------------------------------------------------------------------------------------------------
Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Here's how Florida Trump voters are responding to the Jan. 6 hearings
 - [https://www.cnn.com/videos/politics/2022/07/06/florida-republicans-trump-voters-santiago-lead-vpx.cnn](https://www.cnn.com/videos/politics/2022/07/06/florida-republicans-trump-voters-santiago-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 23:12:38+00:00

More than 800 alleged rioters have been charged in connection with the January 6 attack on the Capitol. Of those, more people from Florida have been charged than from any other state. CNN's Leyla Santiago talks to Trump voters in Florida to see how they are responding to the House January 6 hearings.

## Ukrainian soldiers give CNN a close-up look at their 'most important weapon'
 - [https://www.cnn.com/videos/world/2022/07/06/ukraine-russia-weapon-rocket-launcher-phil-black-tsr-vpx.cnn](https://www.cnn.com/videos/world/2022/07/06/ukraine-russia-weapon-rocket-launcher-phil-black-tsr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 23:06:41+00:00

CNN's Phil Black visits the secret location of one of Ukraine's most powerful weapons in its fight against Russian forces.

## Biden will rescind Afghanistan's designation as a major non-NATO ally
 - [https://www.cnn.com/2022/07/06/politics/afghanistan-major-non-nato-ally-designation-biden-rescind/index.html](https://www.cnn.com/2022/07/06/politics/afghanistan-major-non-nato-ally-designation-biden-rescind/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 23:04:09+00:00

President Joe Biden in a letter to Congress on Wednesday said that he will officially rescind Afghanistan's designation as a major non‑NATO ally.

## 2-year-old orphaned in parade shooting survived because father shielded him with body
 - [https://www.cnn.com/2022/07/06/us/aiden-mccarthy-parents-highland-park-shooting/index.html](https://www.cnn.com/2022/07/06/us/aiden-mccarthy-parents-highland-park-shooting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 21:37:19+00:00

• Suspect admitted he carried out massacre, prosecution says

## Kim Kardashian walks Balenciaga show at Paris Couture Fashion Week
 - [https://www.cnn.com/style/article/kim-kardashian-balenciaga-model-runway-couture/index.html](https://www.cnn.com/style/article/kim-kardashian-balenciaga-model-runway-couture/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 21:15:09+00:00

While the world is seemingly one big runway for Kim Kardashian, today saw her stepping onto an actual catwalk at Balenciaga's latest show during Paris Haute Couture Week. While she has walked for LA  Fashion Week and  her sister's label Dash back in the late 2000s, this is Kardashian's most prestigious modeling accolade yet.

## Man guilty in hip-hop artist Nipsey Hustle's murder
 - [https://www.cnn.com/2022/07/06/entertainment/nipsey-hussle-verdict/index.html](https://www.cnn.com/2022/07/06/entertainment/nipsey-hussle-verdict/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 21:08:12+00:00

A Los Angeles jury has found Eric Ronald Holder, Jr. guilty of first-degree murder of the late rapper Nipsey Hussle.

## Numerous ministers and former allies have pulled their support for the beleaguered British Prime Minister and urged him to resign
 - [https://www.cnn.com/2022/07/06/uk/boris-johnson-uk-government-collapse-gbr-intl/index.html](https://www.cnn.com/2022/07/06/uk/boris-johnson-uk-government-collapse-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 21:06:00+00:00

Boris Johnson's scandal-ravaged premiership appeared on the brink of collapse Wednesday, after numerous ministers and former allies pulled their support for the beleaguered British Prime Minister and urged him to resign before he is forced from office.

## Sri Lanka is 'bankrupt,' Prime Minister says
 - [https://www.cnn.com/2022/07/05/asia/sri-lanka-bankrupt-fuel-crisis-intl-hnk/index.html](https://www.cnn.com/2022/07/05/asia/sri-lanka-bankrupt-fuel-crisis-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 20:23:34+00:00

Sri Lanka is "bankrupt," Prime Minister Ranil Wickremesinghe said Tuesday, as the country suffers its worst financial crisis in decades, leaving millions struggling to buy food, medicine and fuel.

## 'Like a reality show': Former UK MP outlines problems with Boris Johnson's leadership
 - [https://www.cnn.com/videos/world/2022/07/06/uk-prime-minister-boris-johnson-former-tory-mp-stewart-sot-amanpour-intl-ldn-vpx.cnni](https://www.cnn.com/videos/world/2022/07/06/uk-prime-minister-boris-johnson-former-tory-mp-stewart-sot-amanpour-intl-ldn-vpx.cnni)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 20:19:33+00:00

Former Conservative MP Rory Stewart discusses with CNN's Christiane Amanpour why British Prime Minister Boris Johnson must step down from his post.

## Things are going from bad to worse for Boris Johnson
 - [https://www.cnn.com/2022/07/06/uk/boris-johnson-crisis-explainer-intl-gbr/index.html](https://www.cnn.com/2022/07/06/uk/boris-johnson-crisis-explainer-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 19:43:05+00:00

UK Prime Minister Boris Johnson is facing his biggest crisis yet, after two senior Cabinet ministers resigned on Tuesday.

## 'Gentleminions': Why TikTok teens are wearing suits to 'Minions: The Rise of Gru'
 - [https://www.cnn.com/2022/07/06/entertainment/gentleminions-rise-of-gru-tiktok-cec/index.html](https://www.cnn.com/2022/07/06/entertainment/gentleminions-rise-of-gru-tiktok-cec/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 18:58:22+00:00

"Minions: The Rise of Gru" did gangbusters over the weekend. The latest film in the "Despicable Me" franchise of a would-be villain and his bizarre yellow henchmen had the biggest opening ever over the July 4th holiday.

## Johnson's tenure has been defined by scandal. Here are some of the biggest ones
 - [https://www.cnn.com/2022/07/06/uk/boris-johnson-scandals-intl/index.html](https://www.cnn.com/2022/07/06/uk/boris-johnson-scandals-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 18:52:23+00:00

The crisis that UK Prime Minister Boris Johnson is facing right now might be the gravest for his leadership so far -- but it's definitely not the first.

## EU says natural gas projects can be considered 'green' for investments
 - [https://www.cnn.com/2022/07/06/world/eu-votes-natural-gas-nuclear-green-sustainable-climate/index.html](https://www.cnn.com/2022/07/06/world/eu-votes-natural-gas-nuclear-green-sustainable-climate/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 17:37:40+00:00

European Union lawmakers voted Wednesday in favor of calling natural gas and nuclear power "green" or "sustainable" sources of energy, backing a proposal from European Commission, the EU's executive arm, that has spurred criticism from scientists and environmental advocates.

## Trump White House counsel to give transcribed interview to January 6 committee
 - [https://www.cnn.com/2022/07/06/politics/pat-cipollone-deposition-january-6-committee-this-week/index.html](https://www.cnn.com/2022/07/06/politics/pat-cipollone-deposition-january-6-committee-this-week/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 17:36:16+00:00

Trump White House Counsel Pat Cipollone has reached a deal with the January 6 committee to participate in a transcribed interview behind closed doors on Friday, multiple sources told CNN.

## Opinion: Who killed the republic? It's not Donald Trump
 - [https://www.cnn.com/2022/07/06/opinions/trump-liberals-primaries-2022-mcwhorter/index.html](https://www.cnn.com/2022/07/06/opinions/trump-liberals-primaries-2022-mcwhorter/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 16:52:22+00:00

The January 6 commission's emergency hearing last week cracked open an alternate reality in which maybe, perhaps, cross-your-heart-hope-to-die, former President Donald Trump won't get away with it this time -- and on top of that, election deniers finally got some comeuppance from GOP voters at the polls. But before exhaling all the way, let's check in on our country's favorite bellwether state, where Team Normal defeated Team Coup last month in the Republican runoff for the Alabama Senate seat being vacated by Sen. Richard Shelby.

## 2-year-old orphaned in parade shooting survived because father shielded him with body
 - [https://www.cnn.com/collections/intl-illinois-shooting/](https://www.cnn.com/collections/intl-illinois-shooting/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 16:48:52+00:00



## NY judge holds Trump appraiser in contempt, fines it $10,000 a day
 - [https://www.cnn.com/2022/07/06/politics/trump-appraiser-cushman-wakefield/index.html](https://www.cnn.com/2022/07/06/politics/trump-appraiser-cushman-wakefield/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 15:53:29+00:00

A New York judge fined the Trump Organization's former appraiser $10,000 a day after holding it in civil contempt of court for failing to comply with subpoenas from the New York attorney general's office.

## FBI Director Wray, MI5 chief raise alarm over China spying
 - [https://www.cnn.com/2022/07/06/politics/fbi-mi5-wray-china/index.html](https://www.cnn.com/2022/07/06/politics/fbi-mi5-wray-china/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 15:51:57+00:00

Top US and British law enforcement officials met with private business and academic leaders Wednesday to call attention to what they said is the serious security and economic threat posed by China, which is seeking to steal their intellectual property and influence politics in western countries.

## World-famous Pamplona bull-running festival returns after two-year Covid ban
 - [https://www.cnn.com/travel/article/spain-pamplona-bull-run-intl-scli/index.html](https://www.cnn.com/travel/article/spain-pamplona-bull-run-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 15:43:04+00:00

Thousands of revelers wearing white clothes and red scarves filled the streets of Spain's Pamplona on Wednesday as the bang of a firecracker kicked off the first San Fermin bull-running festival since the Covid-19 pandemic struck.

## Airbus A380 'flew 14 hours' with hole in side
 - [https://www.cnn.com/travel/article/airbus-a380-flew-14-hours-with-hole-in-side/index.html](https://www.cnn.com/travel/article/airbus-a380-flew-14-hours-with-hole-in-side/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 15:31:40+00:00

Passengers traveling on an Emirates flight to Brisbane, Australia were stunned when they noticed a huge hole in the side of the aircraft while they were disembarking.

## Dramatic video as rescuer uses rope to save a woman from submerged car
 - [https://www.cnn.com/videos/world/2022/07/06/car-rescue-typhoon-chaba-china-lon-orig.cnn](https://www.cnn.com/videos/world/2022/07/06/car-rescue-typhoon-chaba-china-lon-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 15:24:42+00:00

A woman was rescued from a car which had been flooded with river water after Typhoon Chaba reached northern China.

## Ons Jabeur makes grand slam history as she reaches Wimbledon semifinals
 - [https://www.cnn.com/collections/intl-wimbledon-0706/](https://www.cnn.com/collections/intl-wimbledon-0706/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 15:02:03+00:00



## Rivian's new SUV is great, but it'll face tough competition
 - [https://www.cnn.com/2022/07/06/business/rivian-r1s-review/index.html](https://www.cnn.com/2022/07/06/business/rivian-r1s-review/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 14:52:52+00:00

Rivian, the Amazon-backed electric truck and van maker, already has an award winning pickup in production, the R1T. Now it's coming out with an SUV, the Rivian R1S, that has all the good points of the Rivian pickup but with the added benefits of a fully enclosed body, including a generous cargo area in the back plus third row of seats to allow you take more friends camping.

## The SEC alone can't police billionaire CEOs like Elon Musk
 - [https://www.cnn.com/2022/07/06/perspectives/sec-billionaire-ceos-elon-musk/index.html](https://www.cnn.com/2022/07/06/perspectives/sec-billionaire-ceos-elon-musk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 14:28:13+00:00

In the startup world, pushing regulatory limits to promote a new business is often seen as "entrepreneurial" or "disruptive." But breaking securities laws, as Elon Musk has allegedly done, is something different.

## Some 300 inmates on run after suspected Boko Haram raid on Nigeria prison
 - [https://www.cnn.com/2022/07/06/africa/inmates-on-run-abuja-prison-break-intl/index.html](https://www.cnn.com/2022/07/06/africa/inmates-on-run-abuja-prison-break-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 14:26:40+00:00

Around 300 inmates are on the run after a suspected raid by Islamist Boko Haram militants on a prison in Nigeria's capital Abuja on Tuesday night, an interior ministry official said.

## Out-of-this world images revealed in Astronomy Photographer of the Year 2022 shortlist
 - [https://www.cnn.com/style/article/astronomy-photographer-of-the-year-scli-intl-scn/index.html](https://www.cnn.com/style/article/astronomy-photographer-of-the-year-scli-intl-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 13:54:24+00:00

The star-studded Milky Way above a US coastline, pink and purple clouds overlooking Argentina and a reflection of the Northern Lights in the still waters of a lake in Canada are some of the moments captured by shortlisted entrants to the 2022 Astronomy Photographer of the Year contest.

## Great Salt Lake is 'in trouble' as level falls to lowest on record for second year in a row
 - [https://www.cnn.com/2022/07/06/us/great-salt-lake-record-low-climate/index.html](https://www.cnn.com/2022/07/06/us/great-salt-lake-record-low-climate/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 13:45:48+00:00

The Great Salt Lake in Utah has dropped to its lowest level on record for the second time in less than a year as a climate change-fueled megadrought tightens its grip in the West.

## The vacation romance that's lasted 50 years
 - [https://www.cnn.com/travel/article/chance-encounters-vacation-romance-50-years/index.html](https://www.cnn.com/travel/article/chance-encounters-vacation-romance-50-years/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 13:30:22+00:00

In the sundrenched summer of 1971, Sura Crutch, a recent graduate of the Cleveland Institute of Art, headed to Europe for three months.

## Saudi Arabia's oil boom will fade. The Hajj could compensate
 - [https://www.cnn.com/2022/07/06/business/saudi-hajj-economy-mime-intl/index.html](https://www.cnn.com/2022/07/06/business/saudi-hajj-economy-mime-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 13:19:55+00:00

Oil has added trillions of dollars to Saudi Arabia's coffers over the decades, but it's a resource that will someday run out or lose value as the world turns to alternative energy.

## Why Republicans want to redefine one word in the Constitution
 - [https://www.cnn.com/2022/07/05/politics/independent-state-legislature-theory-what-matters/index.html](https://www.cnn.com/2022/07/05/politics/independent-state-legislature-theory-what-matters/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 12:59:08+00:00

The US Supreme Court is on a tear remaking the way Americans live.

## Why Joe Rogan won't have Trump on his podcast
 - [https://www.cnn.com/videos/media/2022/07/06/joe-rogan-podcast-donald-trump-2024-haberman-newday-vpx.cnn](https://www.cnn.com/videos/media/2022/07/06/joe-rogan-podcast-donald-trump-2024-haberman-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 12:55:00+00:00

CNN political analyst Maggie Haberman breaks down podcast host Joe Rogan's comments on former President Donald Trump. Rogan said he's not interested in helping Trump get reelected.

## Ben & Jerry's sues Unilever to block sale of Israeli business
 - [https://www.cnn.com/2022/07/06/business/ben--jerrys-unilever-israel-intl-hnk/index.html](https://www.cnn.com/2022/07/06/business/ben--jerrys-unilever-israel-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 12:35:03+00:00

Ben & Jerry's is suing its parent company in an attempt to cancel the sale of its business in Israel to a local partner that would continue to distribute its products in the West Bank.

## Patagonia's most elusive animals
 - [https://www.cnn.com/2022/07/06/world/gallery/patagonia-elusive-animals-scn/index.html](https://www.cnn.com/2022/07/06/world/gallery/patagonia-elusive-animals-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 12:15:24+00:00

Patagonia is a land of extremes, home to spectacular and reclusive wildlife that has what it takes to survive in one of the world's last great wildernesses.

## This is what the Highland Park suspect posted online before the shooting
 - [https://www.cnn.com/videos/us/2022/07/05/highland-park-shooter-social-media-2019-campbell-dnt-ebof-vpx.cnn](https://www.cnn.com/videos/us/2022/07/05/highland-park-shooter-social-media-2019-campbell-dnt-ebof-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 12:02:51+00:00

CNN's Josh Campbell reports on the history the Highland Park shooting suspect had with police and his troubling social media posts leading up to the July 4th attack.

## Japanese tea house lets visitors drink from $25,000 antique bowls
 - [https://www.cnn.com/travel/article/japan-expensive-tea-bowls-ceremony-intl-hnk/index.html](https://www.cnn.com/travel/article/japan-expensive-tea-bowls-ceremony-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 11:44:15+00:00

Participating in an ancient Japanese tradition, sipping from a $25,000 antique bowl and even finding a bit of a 1970s "Austin Powers" vibe.

## Ethiopian Prime Minister and rebel group blame each other for apparent civilian massacre
 - [https://www.cnn.com/2022/07/06/africa/civilians-reportedly-killed-ethiopia-oromia-intl/index.html](https://www.cnn.com/2022/07/06/africa/civilians-reportedly-killed-ethiopia-oromia-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 11:32:55+00:00

Ethiopian President Abiy Ahmed and rebel group Oromo Liberation Army (OLA) are blaming each other's military forces after an unconfirmed number of civilians were killed Monday in the country's Oromia region.

## Is North Korea hiding a bigger problem behind its Covid-19 outbreak?
 - [https://www.cnn.com/2022/07/05/asia/north-korea-bigger-health-problems-covid-intl-hnk/index.html](https://www.cnn.com/2022/07/05/asia/north-korea-bigger-health-problems-covid-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 10:52:38+00:00

Choi Jung-hun smiled as I read out the latest official Covid-19 figures from North Korean state media: fewer than 5 million cases of "fever" and just 73 fatalities -- a fraction of the death toll of every other country in the world.

## Growing a 150,000-hectare highway for the UK's insect 'commuters'
 - [https://www.cnn.com/2022/07/06/europe/buglife-b-lines-insect-wildflowers-scn-c2e-spc-intl/index.html](https://www.cnn.com/2022/07/06/europe/buglife-b-lines-insect-wildflowers-scn-c2e-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 09:02:15+00:00

Imagine traveling vast distances through a barren wilderness without access to food or water. That's the challenging reality facing many flying insects in the UK.

## Europe wants a high-speed rail network to replace airplanes
 - [https://www.cnn.com/travel/article/europe-high-speed-rail-network/index.html](https://www.cnn.com/travel/article/europe-high-speed-rail-network/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 08:39:35+00:00

Breakfast in Paris, lunch in Frankfurt and dinner in Vienna -- all without the hassle and frustration of flying.

## Xi'an shuts back down as China finds first cases of new Omicron subvariant
 - [https://www.cnn.com/2022/07/06/china/china-covid-xian-new-omicron-variant-intl-hnk/index.html](https://www.cnn.com/2022/07/06/china/china-covid-xian-new-omicron-variant-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 07:37:09+00:00

China's northwestern city of Xi'an, home to 13 million people, was partially shut down on Wednesday after it reported the country's first outbreak of a highly transmissible new Omicron subvariant that is fast dominating the United States and Europe.

## Suspected North Korean dam release forces South Koreans to evacuate holiday spot on river
 - [https://www.cnn.com/2022/07/05/asia/north-korea-dam-release-evacuate-river-intl-hnk/index.html](https://www.cnn.com/2022/07/05/asia/north-korea-dam-release-evacuate-river-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-06 03:31:27+00:00

North Korea appears to have released water from a dam near its border with South Korea, prompting vacationers in the neighbouring country to evacuate due to rising water levels on the Imjin River, officials said Tuesday.


# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Australia floods: Unfounded cloud seeding claims spread online
 - [https://www.bbc.co.uk/news/science-environment-62049654?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-62049654?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 23:23:32+00:00

False suggestions that Sydney floods were linked to weather manipulation reach thousands online.

## Covid: Norfolk man says he is 'fighting every day for life'
 - [https://www.bbc.co.uk/news/uk-england-norfolk-62071680?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-norfolk-62071680?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 23:09:30+00:00

A man who spent two months in a coma after having Covid says people should "never give up".

## Police officers 'photographed and manipulated body of suicide victim'
 - [https://www.bbc.co.uk/news/uk-northern-ireland-62012268?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-62012268?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 23:06:50+00:00

Allegations emerge that two police officers manipulated the body and shared photos and video online.

## Paradise reopened - Bali hopes for tourists to return
 - [https://www.bbc.co.uk/news/business-61992300?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61992300?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 23:01:44+00:00

The Indonesian island wants holidaymakers to come back as it reopens after two years.

## Chagos Islands FA: The team representing a lost homeland, 6,000 miles away
 - [https://www.bbc.co.uk/sport/football/61998551?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/61998551?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 23:01:16+00:00

The Chagos Islands football team are trying to keep the story of their ancestors alive, 6,000 miles from their disputed homeland.

## Boris Johnson: Welsh Secretary Simon Hart quits cabinet
 - [https://www.bbc.co.uk/news/uk-wales-politics-62058133?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-politics-62058133?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 23:00:41+00:00

Simon Hart was among the cabinet ministers who had earlier urged Boris Johnson to resign.

## Euro 2022: A night like no other for women's football in England
 - [https://www.bbc.co.uk/sport/football/62010421?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62010421?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 22:38:46+00:00

On a night that will be remembered for the occasion rather than England's performance, Euro 2022 gets off to a flying start in front of 68,871 at Old Trafford.

## England v Austria: How you rated the players from Euro 2022 opener at Old Trafford
 - [https://www.bbc.co.uk/sport/football/62071630?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62071630?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 22:18:37+00:00

How did you rate the players as England begin their Euro 2022 campaign with a win over Austria at Old Trafford?

## Gwynedd: Sheep rescued after 10 days stuck in mine shaft
 - [https://www.bbc.co.uk/news/uk-wales-62073174?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-62073174?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 22:12:58+00:00

Rescue team members descend on ropes into a mine to haul the trapped sheep back to safety

## Mary-Sophie Harvey says she was drugged at World Swimming Championships
 - [https://www.bbc.co.uk/sport/swimming/62072801?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/swimming/62072801?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 22:04:27+00:00

Canadian swimmer Mary-Sophie Harvey says she was drugged during the final night of the World Championships in Budapest last month.

## Euro 2022: Biggest women's sporting event in European history kicks off
 - [https://www.bbc.co.uk/sport/football/61717253?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/61717253?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 21:52:21+00:00

A record-breaking 500,000 tickets have been sold for Euro 2022, which kicks off with hosts England on Wednesday.

## How to watch every Women's Euro 2022 game on the BBC
 - [https://www.bbc.co.uk/sport/football/61736728?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/61736728?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 21:48:47+00:00

How to watch every Uefa Women's Euro 2022 game on the BBC this July.

## Euro 2022: Beth Mead's goal gives England winning start against Austria
 - [https://www.bbc.co.uk/sport/av/football/62071591?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/62071591?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 21:38:51+00:00

Watch highlights as England beat Austria in the opening match of the European Women's Championship.

## Ukraine round-up: Evacuation under fire and new oil tensions
 - [https://www.bbc.co.uk/news/world-europe-62068417?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62068417?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 20:57:07+00:00

Civilians flee Ukraine's eastern city of Slovyansk and Kazakh oil is hit by a Russian court ruling.

## Euro 2022: Beth Mead gives England lead against Austria at Old Trafford
 - [https://www.bbc.co.uk/sport/av/football/62071590?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/62071590?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 19:55:06+00:00

England's Beth Mead scores the opening goal against Austria at Old Trafford in the first match of the European Women's Championship.

## Rafael Nadal beats Taylor Fritz in Wimbledon quarter-finals
 - [https://www.bbc.co.uk/sport/tennis/62068283?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/62068283?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 19:23:21+00:00

Rafael Nadal fights through injury to come from behind to beat Taylor Fritz and reach the Wimbledon semi-finals.

## Circus acrobat injured in human cannonball stunt in Caerphilly
 - [https://www.bbc.co.uk/news/uk-wales-62054488?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-62054488?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 18:51:33+00:00

Phone footage shows the performer missing a safety net during a "human cannonball" stunt.

## Boris Johnson met Russian oligarch Lebedev without aides
 - [https://www.bbc.co.uk/news/uk-politics-62068421?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62068421?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 18:05:22+00:00

The prime minister admits he met Alexander Lebedev, an ex-KGB agent, without officials present.

## Alexia Putellas: Spain star on Euro 2022-ending injury - 'I have faith I can get back on track'
 - [https://www.bbc.co.uk/sport/football/62071072?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62071072?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 16:32:48+00:00

Spain's Alexia Putellas says "I have faith I can recover, get back on track and finished what I started" as an injury rules her out of Euro 2022.

## Former cameraman Peter Jouvenal speaks following release
 - [https://www.bbc.co.uk/news/technology-62068539?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62068539?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 16:05:43+00:00

Former cameraman Peter Jouvenal was held by the Taliban for six months.

## Three contested Michael Jackson songs removed from streaming services
 - [https://www.bbc.co.uk/news/entertainment-arts-62068017?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62068017?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 15:41:18+00:00

The songs, which fans have claimed contain 'fake' vocals, have been pulled from Spotify and YouTube.

## Fourth Thor film is 'funny but silly', critics say
 - [https://www.bbc.co.uk/news/entertainment-arts-62061742?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62061742?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 13:41:16+00:00

Taika Waititi's Thor: Love and Thunder receives broadly positive reviews, with some reservations.

## Boris Johnson: Embattled PM vows to keep going amid Tory revolt
 - [https://www.bbc.co.uk/news/uk-politics-62065534?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62065534?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 12:20:17+00:00

The PM says he has a "colossal" mandate from voters and will stay despite a growing revolt among Tory MPs.

## The problems start at the top, Javid tells PM
 - [https://www.bbc.co.uk/news/uk-politics-62061118?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62061118?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 12:13:46+00:00

Former health secretary Sajid Javid says the government's problems and scandals "start at the top".

## Whiskas pet food off Tesco shelves after price row
 - [https://www.bbc.co.uk/news/business-62056386?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62056386?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 12:13:26+00:00

Brand owner Mars pauses supply of pet foods to the UK's biggest supermarket chain in price row.

## Police probed Chris Pincher assault allegations
 - [https://www.bbc.co.uk/news/uk-england-stoke-staffordshire-62064605?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-stoke-staffordshire-62064605?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 11:59:50+00:00

No further action was taken by either the Metropolitan or Staffordshire Police forces.

## Trans tweets woman discriminated against, tribunal rules
 - [https://www.bbc.co.uk/news/uk-62061929?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62061929?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 11:57:17+00:00

Maya Forstater lost her job at a think tank over tweets saying people cannot change their biological sex.

## British Triathlon becomes first UK sport to create 'open' category for transgender athletes
 - [https://www.bbc.co.uk/sport/triathlon/62063359?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/triathlon/62063359?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 11:45:09+00:00

Transgender athletes will be barred from the female category at all events where there are prizes, times or rankings at stake, including at grassroots level.

## How might Boris Johnson be removed as PM?
 - [https://www.bbc.co.uk/news/uk-politics-62064784?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62064784?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 10:59:50+00:00

The PM is clinging on but if his premiership does come to an end, here is how it might happen.

## Who is Michelle Donelan and what is the new education secretary facing?
 - [https://www.bbc.co.uk/news/education-62061251?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-62061251?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 10:55:31+00:00

The new education secretary will have to take on rising costs for schools, and Covid catch-up pressures.

## Pound slides to two-year low against the dollar
 - [https://www.bbc.co.uk/news/business-62053700?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62053700?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 10:47:18+00:00

Investors flock to the safe haven dollar over concerns about the outlook for UK economic growth.

## Mason: Johnson facing day of judgement
 - [https://www.bbc.co.uk/news/uk-politics-62064714?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62064714?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 10:35:33+00:00

The prime minister is about to face MPs' questions as he sees ministers resign from his government.

## Zara Aleena died from head and neck injuries, coroner hears
 - [https://www.bbc.co.uk/news/uk-england-london-62063883?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-62063883?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 10:02:45+00:00

Jordan McSweeney, 29, is accused of her murder and remains in custody.

## Friends creator says show used wrong pronouns for Chandler's trans parent
 - [https://www.bbc.co.uk/news/entertainment-arts-62061739?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62061739?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 10:01:43+00:00

Marta Kauffman says it was a mistake not to use female pronouns for Chandler's transgender parent.

## Question of Sport: How will you get on in this week's Euros-themed quiz?
 - [https://www.bbc.co.uk/sport/football/62052310?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62052310?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 09:29:22+00:00

The Question of Sport team have put together a quiz to test your knowledge of the Women's European Championship.

## Chicago shooting: Parents of two-year-old boy among victims
 - [https://www.bbc.co.uk/news/world-us-canada-62047223?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62047223?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 08:53:06+00:00

Irina McCarthy and Kevin McCarthy were shot dead by a gunman, leaving their son Aiden an orphan.

## We're so short-staffed our hotel has to turn people away
 - [https://www.bbc.co.uk/news/uk-scotland-62049326?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-62049326?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 07:27:10+00:00

Business owners say they face increasing problems due to staffing shortages and soaring inflation.

## Meet the Lionesses: TikTok, turtlenecks and a world without bananas
 - [https://www.bbc.co.uk/sport/av/football/62058082?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/62058082?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 07:00:48+00:00

BBC Sport's Liam Loftus takes a tour of England's media day to ask the Lionesses some of the silliest questions they will face ahead of Euro 2022.

## Sarina Wiegman: The player, the manager, the leader, the person
 - [https://www.bbc.co.uk/sport/football/62016998?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62016998?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 06:01:45+00:00

As Sarina Wiegman prepares to lead England at the Euros, those who have worked with her reveal all to BBC Sport.

## The Papers: Johnson 'on brink' and 'battling for survival'
 - [https://www.bbc.co.uk/news/blogs-the-papers-62059064?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-62059064?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 05:15:37+00:00

The resignation of Rishi Sunak and Sajid Javid from Boris Johnson's government dominates headlines.

## England keeper ready for 'crazy' Euro 2022 opener
 - [https://www.bbc.co.uk/news/newsbeat-62038381?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-62038381?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 05:02:28+00:00

Ellie Roebuck says she is "chomping at the bit" to start England's bid for Euro 2022 glory.

## Mumbai: Heavy rains bring Indian city to a standstill
 - [https://www.bbc.co.uk/news/world-asia-india-62056709?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-62056709?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 04:44:53+00:00

Millions are battling flooding and overflowing sewers as monsoon rains lash India's financial capital.

## Ukraine war: Market hit as Russians shell frontline city Slovyansk
 - [https://www.bbc.co.uk/news/world-europe-62051585?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62051585?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 00:57:09+00:00

Two people died in Russian strikes on Ukraine's eastern city of Slovyansk, local officials say.

## Sidhu Moose Wala: The unsettling legacy of the rapper's protest music
 - [https://www.bbc.co.uk/news/world-asia-india-61973643?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-61973643?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 00:28:52+00:00

It has been more than a month since the rapper was shot dead. But he is still making headlines.

## Trans rescue: A future refuge for those fleeing violence
 - [https://www.bbc.co.uk/news/world-africa-61979384?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-61979384?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 00:23:53+00:00

Two trans women in Amsterdam are planning a refuge in Kenya for trans people at risk all over the world.

## Arabs believe economy is weak under democracy
 - [https://www.bbc.co.uk/news/world-middle-east-62001426?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-62001426?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 00:16:02+00:00

People are losing faith in democracy to deliver economic stability across Middle East and North Africa, according to a major new survey.

## Studio Electrophonique: The council house that launched top British bands
 - [https://www.bbc.co.uk/news/entertainment-arts-62001264?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62001264?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-06 00:13:40+00:00

A new film tells the story of how a Sheffield car mechanic's home doubled as Studio Electrophonique.


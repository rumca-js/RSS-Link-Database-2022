# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Alec Shaw - Fool's Gold (Live on KEXP)
 - [https://www.youtube.com/watch?v=QkNvym_3lc8](https://www.youtube.com/watch?v=QkNvym_3lc8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-29 00:00:00+00:00

http://KEXP.ORG presents Alec Shaw performing “Fool's Gold” live in the KEXP studio. Recorded July 5, 2022.

Alec Shaw - Guitar / Piano / Vocals
Nathan Stumpf - Guitar / Keys
Zan Fiskum - Piano / Keys / Vocals
Paul Hirschl - Drums
Nate Vigil - Bass
Choir: Tim Wilson, Tyler Markarian, Olivia Sherry, Betty Michaels, Danielle Nyoka, Sam Hiatt, Canaan Baka, Aaron Sternke, Payge Turner, Lauren Santi

Host: Eva Walker
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

http://www.alecshawmusic.com
http://kexp.org

## Alec Shaw - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=TDskBYe0R2M](https://www.youtube.com/watch?v=TDskBYe0R2M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-29 00:00:00+00:00

http://KEXP.ORG presents Alec Shaw performing live in the KEXP studio. Recorded July 5, 2022.

Songs:
Spinning
Here & There
Nobody But You
Fool’s Gold

Alec Shaw - Guitar / Piano / Vocals
Nathan Stumpf - Guitar / Keys
Zan Fiskum - Piano / Keys / Vocals
Paul Hirschl - Drums
Nate Vigil - Bass
Choir: Tim Wilson, Tyler Markarian, Olivia Sherry, Betty Michaels, Danielle Nyoka, Sam Hiatt, Canaan Baka, Aaron Sternke, Payge Turner, Lauren Santi

Host: Eva Walker
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

http://www.alecshawmusic.com
http://kexp.org

## Alec Shaw - Here & There (Live on KEXP)
 - [https://www.youtube.com/watch?v=8Ic6mOPhjXo](https://www.youtube.com/watch?v=8Ic6mOPhjXo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-29 00:00:00+00:00

http://KEXP.ORG presents Alec Shaw performing “Here & There” live in the KEXP studio. Recorded July 5, 2022.

Alec Shaw - Guitar / Piano / Vocals
Nathan Stumpf - Guitar / Keys
Zan Fiskum - Piano / Keys / Vocals
Paul Hirschl - Drums
Nate Vigil - Bass
Choir: Tim Wilson, Tyler Markarian, Olivia Sherry, Betty Michaels, Danielle Nyoka, Sam Hiatt, Canaan Baka, Aaron Sternke, Payge Turner, Lauren Santi

Host: Eva Walker
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

http://www.alecshawmusic.com
http://kexp.org

## Alec Shaw - Nobody But You (Live on KEXP)
 - [https://www.youtube.com/watch?v=s_8WOIuuZe8](https://www.youtube.com/watch?v=s_8WOIuuZe8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-29 00:00:00+00:00

http://KEXP.ORG presents Alec Shaw performing “Nobody But You” live in the KEXP studio. Recorded July 5, 2022.

Alec Shaw - Guitar / Piano / Vocals
Nathan Stumpf - Guitar / Keys
Zan Fiskum - Piano / Keys / Vocals
Paul Hirschl - Drums
Nate Vigil - Bass
Choir: Tim Wilson, Tyler Markarian, Olivia Sherry, Betty Michaels, Danielle Nyoka, Sam Hiatt, Canaan Baka, Aaron Sternke, Payge Turner, Lauren Santi

Host: Eva Walker
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

http://www.alecshawmusic.com
http://kexp.org

## Alec Shaw - Spinning (Live on KEXP)
 - [https://www.youtube.com/watch?v=SQcxneQiW1M](https://www.youtube.com/watch?v=SQcxneQiW1M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-29 00:00:00+00:00

http://KEXP.ORG presents Alec Shaw performing “Spinning” live in the KEXP studio. Recorded July 5, 2022.

Alec Shaw - Guitar / Piano / Vocals
Nathan Stumpf - Guitar / Keys
Zan Fiskum - Piano / Keys / Vocals
Paul Hirschl - Drums
Nate Vigil - Bass
Choir: Tim Wilson, Tyler Markarian, Olivia Sherry, Betty Michaels, Danielle Nyoka, Sam Hiatt, Canaan Baka, Aaron Sternke, Payge Turner, Lauren Santi

Host: Eva Walker
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

http://www.alecshawmusic.com
http://kexp.org


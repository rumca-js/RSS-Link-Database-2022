# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## NEW WHEEL OF TIME SHORTS!🎉 Martin Tests Positive🦠 Gollum Delay!⌛-FANTASY NEWS
 - [https://www.youtube.com/watch?v=UFbdUEXAAXU](https://www.youtube.com/watch?v=UFbdUEXAAXU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-07-29 00:00:00+00:00

LETS GET INTO THE FANTASY NEWS!!! 

New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.designbyhumans.com/shop/FantasyNews/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231


NEWS:

00:00 Intro

00:35 George R. R. Martin Covid: https://www.youtube.com/watch?v=qoqMl6XW-k4 

01:16 Malazan Update: https://m.facebook.com/story.php?story_fbid=pfbid0enweTrLCQUG1ZfBVbTBoRjt51mPQrtziJgXV9Av5X2tS7FW5U4maQy7oYdjr45LFl&id=100044126933474 

01:57 New Snow Crash: https://www.penguinrandomhouse.com/books/172832/snow-crash-by-neal-stephenson/hardcover 

02:23 Leather bounds coming back: https://twitter.com/DragonsteelBook/status/1552004603025264640?t=IUW_y1RKYeqekZALlU9M_g&s=19 

02:48 New Wheel of Time Audiobooks: https://dragonmount.com/news/book-news/rosamundtghtdr/ 

03:40 WoT Shorts: https://twitter.com/TheWheelOfTime/status/1550263651046567936 

04:17 Gollum Delay: https://twitter.com/gollumgame/status/1551598260732792832?s=21&t=WjvspGYNOJgLFPjOvawKcw 

06:06 Avatar Cabbage Actor: https://collider.com/avatar-the-last-airbender-live-action-series-cast-james-sie-netflix/ 

07:04 Pinocchio Trailer: https://www.youtube.com/watch?v=Tbl5Lbi4xEs&ab_channel=Netflix 

07:49 Sandman Trailer: https://www.youtube.com/watch?v=83ClbRPRDXU&ab_channel=Netflix 

08:44 EEAAO Box Office: https://mobile.twitter.com/FilmUpdates/status/1552048681888518144 

09:01 Knights Of The Old Republic Delay: https://www.bloomberg.com/news/articles/2022-07-26/star-wars-knights-of-the-old-republic-game-paused-amid-studio-shakeup


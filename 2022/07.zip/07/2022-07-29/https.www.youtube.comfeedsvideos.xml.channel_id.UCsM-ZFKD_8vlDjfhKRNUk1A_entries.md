# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Winona Oak - Koncert (MUZO.FM)
 - [https://www.youtube.com/watch?v=bUs_8W-2w7A](https://www.youtube.com/watch?v=bUs_8W-2w7A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2022-07-29 00:00:00+00:00

Winona Oak na żywo w MUZO.FM. Artystka wykonała w naszym studiu wyjątkowe wersje utworów Your Tomorrow i Piano In The Sky z debiutanckiej płyty Island Of The Sun. 

00:00 Your Tomorrow
02:28 Piano In The Sky

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Winona Oak: http://www.facebook.com/winonaoak
Instagram Winona Oak: http://www.instagram.com/winonaoak
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


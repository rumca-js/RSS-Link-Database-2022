# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## The CRT Hype Train Might Be Out of Control... - CRT vs OLED
 - [https://www.youtube.com/watch?v=C_-9Rw5CJNE](https://www.youtube.com/watch?v=C_-9Rw5CJNE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-07-30 00:00:00+00:00

Get up to 40% Off Pulseway's IT Management Software at https://lmg.gg/PulsewayLTT

Check out the Game On AMD Sales Event at https://amd.ryukyu/3PcncZn

Should you spend your hard-earned money on an HD display from 2003? CRT had some interesting final days that not a lot of people experienced or even remember and we're going to find out what your retro games look best on.

Discuss on the forum: https://linustechtips.com/topic/1446460-dont-buy-everything-i-recommend/

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:30 Why?
3:16 Infamous
6:21 Marvel vs Capcom 2
8:13 Power Stone 2
9:55 Sonic Adventure 2
12:00 FFX Remaster
13:28 Super Mario World
15:20 Ape Escape
17:05 Cross Code
18:36 Conclusion
20:11 Outro

## Is Intel ARC REALLY Cancelled?  - WAN Show July 29, 2022
 - [https://www.youtube.com/watch?v=4NnXdK-Kncc](https://www.youtube.com/watch?v=4NnXdK-Kncc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-07-29 00:00:00+00:00

Check out the Game On AMD sales event at https://amd.ryukyu/3RGrSIr
Check out Secret Lab at https://lmg.gg/SecretLabWAN

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Is-Intel-ARC-REALLY-Cancelled----WAN-Show-July-29--2022-e1lvgd1

Timestamps: (Courtesy of NoKi1119)
0:00 Chapters
2:13 Intro
2:42 Topic #1 - Intel's "allegedly cancelled" Arc
6:12 Moore's Law Is Dead's notes on the leak
8:42 Rumored leaks of internal Intel conversations
10:20 Discussing the road map, product releases
12:10 Linus on Intel's Larrabee, comparing to Arc
13:16 Optane removed, LMG & rumors, expenses of a project
17:42 Luke wanted a competitive GPU ft. Linus's theory
19:50 Linus on Alchemist, Tel Aviv tour & silicon costs
23:46 Intel's fab would take long, chipset funding
24:56 LTTStore's Stealth Hoodie Pro
27:13 Backpack to become purchasable by next mid-week
28:20 Deal of the Week - free LTTStore tote bag
29:01 Sponsor - AMD
30:11 Sponsor - SecretLab
31:22 Sponsor - Ubiquiti' ft. Dennis seeing naked Linus
33:22 Topic #2 - OverKill reaches out to LMG
33:48 Explaining the cease & desist
35:28 "I'm not threatening you" was due to harassed wife
36:08 COVID causing delays, website overhaul & orders
37:48 NDA, recording builds for content
38:29 Are Linus & Luke on OverKill's side now?
40:56 Merch Messages #1
41:08 Right-to-repair for LTTStore, screwdriver design, WAN LAN
49:01 Linus testing radio signals
50:54 Linus is planning to go to Backstreet Boys
52:03 Updates on the 64oz LTTStore bottles
52:39 Using the LTTStore desk pad as a bed rug & wall hangings
53:12 Formula E & racing technologies
54:09 LTTStore screwdriver holster
55:08 LTTStore shorts mesh lining, Linus shows prototype belt
56:54 Travel & packing tips
58:52 Monitor is fine, but the PC setup struggles
1:00:15 Preventing companies from killing & withdrawing products
1:02:05 Intel's Arc issues Are the executives misunderstanding?
1:03:48 Linus on having his children continuing his legacy
1:05:40 What LMG does to take care of employees
1:10:25 Silence-oriented internal GPU enclosure
1:12:23 Is Linus afraid of the recession affecting LMG's growth?
1:14:24 Linus Dbranding a house, which design to go for
1:14:54 Use cases of virtual machines for homes
1:17:07 Optical disk drive class-action lawsuit
1:17:50 Particular ChannelSuperFun activity that stood up
1:19:53 CallMeKris's 6-hour video collab
1:24:29 Are certificates like CompTIA A+ needed anymore?
1:25:55 Linus's home & pool progress update
1:27:08 Most risk in growing LMG
1:27:36 Wireless earpods, Apple's AirPods
1:28:48 Dream YouTube collabs that Linus would enjoy
1:29:44 Outro


# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## The global downfall of Chinese phone brands
 - [https://www.youtube.com/watch?v=5UxnqgzBjz0](https://www.youtube.com/watch?v=5UxnqgzBjz0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2022-07-29 00:00:00+00:00

Sponsored by Clickup. Sign up here: https://clickup.com/?%20utm_source=YouTube&utm_medium=Community&utm_content=video_whiteboards_FridayCheckout&utm_campaign=yt_whiteboards-22

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► This video ◄◄◄  

This week Chinese brands like OPPO, Vivo and Xiaomi got into trouble in India, China and Europe, OnePlus and Nokia dropped the things we loved about them and it was earnings week.

Episode 107

This video on Nebula: https://nebula.app/videos/the-friday-checkout-the-global-downfall-of-chinese-phone-brands

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support my work directly:  https://flattr.com/@techaltar   

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Writing & Research: Tristan Rayner
Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:25 Release highlights
2:47 Chinese brands in trouble
5:47 Nokia & OnePlus giving up
7:42 Earnings - Not stonks


# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Tolkien's Time Travel Story - Númenor & The Lost Road
 - [https://www.youtube.com/watch?v=w-AhkuodtMc](https://www.youtube.com/watch?v=w-AhkuodtMc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-07-30 00:00:00+00:00

In the 1930's, JRR Tolkien and CS Lewis made an agreement that they would embark on writing two distinct stories.  While Lewis would tell a story centering on space travel, Tolkien was tasked with writing a time travel tale.  While Lewis' work would result in his Space Trilogy, Tolkien's abandoned would help him further the story he truly wished to tell - that of Númenor and Middle-earth's Second Age.

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

For more on CS Lewis and his Space Trilogy (upcoming) check out Into the Wardrobe: https://www.youtube.com/c/IntotheWardrobe

To purchase artist work, check out these amazing artists!

Tulikoura - https://www.deviantart.com/tulikoura
Matthew Stewart - http://www.matthew-stewart.com/
BellaBergolts - https://www.deviantart.com/bellabergolts
Magdalena Katanska - https://www.artstation.com/magdalenakatanska/prints  https://www.instagram.com/qualiney
Jerry Vanderstelt - https://store.vandersteltstudio.com/main.sc
Anna Podedworna - https://www.artstation.com/akreon
Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html
Aronja Art - https://www.instagram.com/aronjaart/
Ivan Cavini - https://www.instagram.com/ivan_cavini/
Sara Morello - https://www.artstation.com/saramorello
Matěj Čadil - https://www.etsy.com/people/matejcadil
Tulikoura - https://www.deviantart.com/tulikoura
Aegeri - https://www.deviantart.com/aegeri
Noe Leyva - https://twitter.com/NoeLeyvArt

Andunie - David Greset
Professor JRR Tolkien - Skullb*st*rd
The Fall of Numenor - Darrell Sweet
Eldalonde - Ralph Damiani
Durin at the Mirrormere - Matej Cadil
The Last Hunt - Turner Mohan
Tuor's First View of the Sea - Anke Eissmann
Assassination of Alboin
The Mountains and the Sea - Alan Lee
The Eagles of Manwe - Ted Nasmith
Armenelos - Ralph Damiani
Beleriand Map - Lamaarcana
Library - Bryan Bitter
Gandalf with Book of Mazarbul - Matthew Stewart
Numenor - David Greset
Elendil the Tall - Tolman Cotton
Elendil - Kimberly
Tower in the bay - David Greset
White Ships - Ted Nasmith
Ar-Pharazon - Steamey
Earendil - Jenny Dolfen
Earendil Searches Tirion - Ted Nasmith
Ar-Pharazon - Dracarysdrekkar7
Imperial Numenorean Armour - Turner Mohan
The Pale King - Skullb*st*rd
Elendil - WETA
Eldalonde - Ralph Damiani
Morgoth and Sauron - Ralph Damiani
Smaug, Gandalf's Vision - WETA
Sauron before Ar-Pharazon - Anke Eissmann
Sinking of Numenor - John Howe
Sauron's Army - WETA
Sauron the Deceiver - Skullb*st*rd
Sauron, Commander of Angband - Toherrys
The King's Counselor - Turner Mohan
Numenorean - Matthew Stewart
Numenorean Armor - Turner Mohan
Numenor's Legion of Armenelos - Sam McKinnon
Earendil's Ship - John Howe
Out of the Sea I am Come - Turner Mohan
Ancalime in Numenor - Steamey



#tolkien #timetravel #numenor


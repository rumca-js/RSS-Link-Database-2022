## Bristol Drag queen children's story hour disrupted by protests - BBC News
 - [https://www.bbc.com/news/uk-england-bristol-62335147](https://www.bbc.com/news/uk-england-bristol-62335147)
 - RSS feed: https://www.bbc.com
 - date published: 2022-07-29 11:13:47.193167+00:00

A demonstration against a drag queen story reading for children causes the Bristol event to be postponed.


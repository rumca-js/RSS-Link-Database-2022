# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## The World's First True Computer Still Hasn't Been Built
 - [https://www.youtube.com/watch?v=rXdvKm6cri4](https://www.youtube.com/watch?v=rXdvKm6cri4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-07-29 00:00:00+00:00

Head to https://shopify.com/scishow for a 14-day free trial. Find out more about Shopify Balance: https://shopify.com/balance

The code cracking machines of the 1940’s are often referred to as the first computers, but they could not have been developed without the intricate machines that predated them by almost a hundred years, but were forgotten about for a century. 

Thumbnail Image modified from: Science Museum London / Science and Society Picture Library

Hosted By: Hank Green

Thumbnail credit: ArnoldReinhold
----------
Huge thanks go to the following Patreon supporter for helping us keep SciShow Space free for everyone forever: Jason A Saslow, David Brooks, and AndyGneiss!

Support SciShow Space by becoming a patron on Patreon: https://www.patreon.com/SciShowSpace

Or by checking out our awesome space pins and other products over at DFTBA Records: http://dftba.com/scishow
----------
Looking for SciShow elsewhere on the internet?
SciShow on TikTok: https://www.tiktok.com/@scishow
SciShow Tangents Podcast: http://www.scishowtangents.org
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow 
----------
Sources:
Computer: A History of the Information Machine (Martin Campbell-Kelly, William Aspray, Nathan Ensmenger, Jeffrey R.Yost, 3rd edition, 2013)https://www.britannica.com/technology/Colossus-computerhttps://www.britannica.com/technology/ENIAChttps://en.wikisource.org/wiki/Astronomische_Nachrichten/Volume_46/On_Mr._Babbage%27s_new_machine_for_calculating_and_printing_mathematical_and_astronomical_tableshttps://www.computerhistory.org/babbage/engines/https://www.britannica.com/technology/Difference-Enginehttps://www.smithsonianmag.com/history/what-a-difference-the-difference-engine-made-from-charles-babbages-calculator-emerged-todays-computer-109389254/https://www.whipplemuseum.cam.ac.uk/explore-whipple-collections/calculating-devices/charles-babbages-difference-enginehttps://www.britannica.com/technology/Analytical-Enginehttps://history-computer.com/charles-babbage-analytical-engine/https://www.computerhistory.org/babbage/adalovelace/https://www.britannica.com/biography/Charles-Babbagehttps://www.britannica.com/biography/Ada-Lovelacehttps://www.wired.com/2012/06/alan-turing-name-checks-his-predecessor-charles-babbage/https://collection.sciencemuseumgroup.org.uk/objects/co62243/difference-engine-no-1-difference-enginehttps://collection.sciencemuseumgroup.org.uk/objects/co62245/babbages-analytical-engine-1834-1871-trial-model-analytical-engine-millhttps://collection.sciencemuseumgroup.org.uk/objects/co526657/difference-engine-no-2-designed-by-charles-babbage-built-by-science-museum-difference-enginehttps://www.newscientist.com/article/mg20827915-500-lets-build-babbages-ultimate-mechanical-computer/?ignored=irrelevanthttps://www.cs.virginia.edu/~robins/Ada_and_the_First_Computer.pdfhttps://cse.umn.edu/cbi/who-was-charles-babbageImage Sources:https://commons.wikimedia.org/wiki/File:Demonstration_model_of_Babbage%E2%80%99s_Difference_Engine_No_1,_19th_century._(9660573663).jpghttps://commons.wikimedia.org/wiki/File:Wartime_picture_of_a_Bletchley_Park_Bombe.jpghttps://commons.wikimedia.org/wiki/File:%27bombe%27.jpghttps://commons.wikimedia.org/wiki/File:Table_of_Geography_and_Hydrography,_Cyclopaedia,_Volume_1.jpghttps://commons.wikimedia.org/wiki/File:Engaving_of_Charles_Babbage_from_Mechanics_Magazine.jpghttps://commons.wikimedia.org/wiki/File:Babbage_difference_engine_drawing.gifhttps://commons.wikimedia.org/wiki/File:Babbages_Difference_Engine_No_1,_1824-1832._%289660573845%29.jpghttps://collection.sciencemuseumgroup.org.uk/objects/co62245https://commons.wikimedia.org/wiki/File:Babbage_Analytical_Engine_Plan_1840_CHM.agr.jpghttps://commons.wikimedia.org/wiki/File:Ada_Lovelace.jpghttps://commons.wikimedia.org/wiki/File:Houghton_AC85.Su662.Zz843m.jpghttps://commons.wikimedia.org/wiki/File:Diagram_for_the_computation_of_Bernoulli_numbers.jpghttps://commons.wikimedia.org/wiki/File:AnalyticalMachine_Babbage_London.jpghttps://commons.wikimedia.org/wiki/File:PunchedCardsAnalyticalEngine.jpghttps://commons.wikimedia.org/wiki/File:Aiken.jpeghttps://commons.wikimedia.org/wiki/File:Harvard_Mark_I.jpghttps://commons.wikimedia.org/wiki/File:Difference_Engine_No._2_(2586076518).jpghttps://commons.wikimedia.org/wiki/File:Babbage_Difference_Engine_Detail_(6224956387).jpghttps://commons.wikimedia.org/wiki/File:Charles_Babbage_1860.jpghttps://commons.wikimedia.org/wiki/File:Ada_Byron_daguerreotype_by_Antoine_Claudet_1843_or_1850.jpg
https://en.wikipedia.org/wiki/File:Babbage_Analytical_Engine_Plan_1840_CHM.agr.jpg

The Steampunk Computers of the 1800s


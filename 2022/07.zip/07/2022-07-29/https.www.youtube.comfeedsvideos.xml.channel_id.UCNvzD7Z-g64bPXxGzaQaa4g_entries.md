# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Xenoblade Chronicles 3 - Before You Buy
 - [https://www.youtube.com/watch?v=MAPQnjAf6tw](https://www.youtube.com/watch?v=MAPQnjAf6tw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-07-30 00:00:00+00:00

Xenoblade Chronicles 3 (Nintendo Switch) is a MonolithSoft JRPG worth experiencing if you're a fan of the long-running series. Let's talk.
Subscribe for more: http://youtube.com/gameranxtv ▼▼



Watch more 'Before You Buy': https://bit.ly/2kfdxI6

#xenobladechronicles3

## FIRST GTA 6 DETAILS LEAK? NEW PS5 FEATURES & MORE
 - [https://www.youtube.com/watch?v=h77eSIlwhKY](https://www.youtube.com/watch?v=h77eSIlwhKY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-07-29 00:00:00+00:00

New GTA6 rumors and leaks, game releases, PSVR2 updates, and more in a week full of multiplatform gaming news.

Jake on Instagram: https://bit.ly/3uUh9Ot

Jake on twitter: https://bit.ly/3gdkPqD​​​​




 ~~~~STORIES~~~~



GTA6
https://www.bloomberg.com/news/articles/2022-07-27/gta-6-news-video-game-to-feature-playable-female-main-character

New PS5 features?
https://kotaku.com/playstation-5-sony-gamelists-1440p-beta-1849342708



Nier discovery
https://www.ign.com/articles/nier-automata-church-mystery-door-mods

KOTOR
https://www.bloomberg.com/news/articles/2022-07-26/star-wars-knights-of-the-old-republic-game-paused-amid-studio-shakeup


Multiversus
https://youtu.be/AVLeyKliDA4

Xenoblade Chronicles 3
https://youtu.be/k6GJlPOhPnE

Bully Unreal Engine 5 (via TeaserPlay)
https://youtu.be/mmfSikLHm7A



PSVR2 update
https://blog.playstation.com/2022/07/26/early-look-at-the-user-experience-for-playstation-vr2/

Meta Quest price hike
https://arstechnica.com/gaming/2022/07/meta-quest-2-vr-headset-price-jumps-100-to-399-gets-zero-new-features/


Black Panther game?
https://venturebeat.com/2022/07/25/report-ea-is-working-on-a-black-panther-game/


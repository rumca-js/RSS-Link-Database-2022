# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Język ukraiński urzędowym językiem w Polsce? Pojawiły się zapowiedzi!
 - [https://www.youtube.com/watch?v=OCA76xm_1Ck](https://www.youtube.com/watch?v=OCA76xm_1Ck)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2022-07-30 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3vPbNqT
2. https://bit.ly/3OMpsWj
3. https://bit.ly/3BykEAV
4. https://bit.ly/3OJWoPa
5. https://bit.ly/3OMpDAX
6. https://bit.ly/3Q7Qys0
7. https://bit.ly/3POhU6u
8. https://bit.ly/3Q9BzgT
9. https://bit.ly/3ap7lrg
10. https://bit.ly/3cOdEFA
11. https://bit.ly/3zJIzvF
12. https://bit.ly/3zgVx2M
13. https://bit.ly/3cSONk2
---------------------------------------------------------------
🎴 Do kolażu wykorzystano grafikę autorstwa: 
fandom.com / Kakarakak - https://bit.ly/3zg4qtn
---------------------------------------------------------------
💡 Tagi: #polityka #ukraina
--------------------------------------------------------------

## Rząd warszawski ratuje budowę zamku w Stobnicy! Powstało nowe prawo!
 - [https://www.youtube.com/watch?v=yhErJ435dUY](https://www.youtube.com/watch?v=yhErJ435dUY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2022-07-29 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3BrxKQm
2. https://bit.ly/3OIrBC8
3. https://bit.ly/3cPyx3k
4. https://bit.ly/3bhZJHp
5. https://bit.ly/3Jh1TU5
6. https://bit.ly/3oBQqoL
7. https://bit.ly/3bh4lxy
---------------------------------------------------------------
🎴 Do kolażu wykorzystano grafikę autorstwa: 
https://bit.ly/3JfLIGD
gov.pl - http://bit.ly/2lVWjQr
---------------------------------------------------------------
💡 Tagi: #polityka #stobnica
--------------------------------------------------------------


# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## The town destroyed to make way for a whites-only suburb
 - [https://www.bbc.co.uk/news/stories-62325802?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/stories-62325802?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 23:54:06+00:00

“We won’t move!” – The first ‘forced removals’ of apartheid-era South Africa

## Week in pictures: 23 - 29 July 2022
 - [https://www.bbc.co.uk/news/in-pictures-62336344?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-62336344?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 23:47:16+00:00

A selection of powerful images from all over the globe, taken in the past seven days.

## Nancy Pelosi's long history of opposing Beijing
 - [https://www.bbc.co.uk/news/world-asia-china-62343675?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-62343675?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 23:26:30+00:00

The US speaker is aggravating China over Taiwan - but has a long history of taking on Beijing.

## Bluey: How a cartoon dog became a role model for dads
 - [https://www.bbc.co.uk/news/entertainment-arts-62335678?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62335678?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 23:01:25+00:00

The hit Australian children's TV show Bluey has been streamed more than 100 million times in the UK.

## Commonwealth Games: Neil Fachie wins Scotland's first gold as England claim team pursuit bronze
 - [https://www.bbc.co.uk/sport/commonwealth-games/62352472?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/commonwealth-games/62352472?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 22:53:47+00:00

Para-cyclist Neil Fachie wins Scotland's first gold medal of the Commonwealth Games as Laura Kenny spearheads England to team pursuit bronze on the track where she made her name.

## Kentucky floods: 'More water than any of us have ever seen'
 - [https://www.bbc.co.uk/news/world-us-canada-62356410?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62356410?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 21:52:27+00:00

Children are among at least 16 people dead amid historic flooding in the US state of Kentucky.

## Commonwealth Games: England's 'incredible performance' wins team gymnastics gold
 - [https://www.bbc.co.uk/sport/av/commonwealth-games/62355843?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/commonwealth-games/62355843?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 21:04:46+00:00

Watch England cruise to a brilliant win in the men's team gymnastics final on day one of the 2022 Commonwealth Games in Birmingham.

## Ukraine round-up: Deadly attack on prisoners of war
 - [https://www.bbc.co.uk/news/world-europe-62353657?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62353657?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 19:50:37+00:00

Russia and Ukraine trade blame over a prison camp attack and a reprieve for a Russian teen.

## Wagatha Christie case: Judgement at a glance
 - [https://www.bbc.co.uk/news/uk-62345915?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62345915?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 16:30:21+00:00

Rebekah Vardy has lost her High Court libel case against fellow footballer's wife Coleen Rooney.

## Will Smith says he has 'reached out' to Chris Rock about Oscars slap
 - [https://www.bbc.co.uk/news/entertainment-arts-62348252?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62348252?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 15:46:33+00:00

The actor has posted a five-minute video online, answering questions from fans about the altercation.

## Commonwealth Games: Brinn Bevan aces parallel bars for Wales
 - [https://www.bbc.co.uk/sport/av/commonwealth-games/62351850?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/commonwealth-games/62351850?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 14:21:14+00:00

Watch Wales' Brinn Bevan score a huge 14.450 on the parallel bars during the artistic gymnastics men's team final & individual qualification on day one of the 2022 Commonwealth Games in Birmingham.

## Commonwealth Games: Scots creator reveals secrets of metal bull
 - [https://www.bbc.co.uk/news/uk-scotland-glasgow-west-62348411?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-glasgow-west-62348411?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 13:06:47+00:00

The 10m high sculpture was a highlight of the Commonwealth Games' opening ceremony.

## Commonwealth Games 2022: Reese Lynch on Josh Taylor, his family & medal ambitions
 - [https://www.bbc.co.uk/sport/commonwealth-games/61966505?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/commonwealth-games/61966505?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 12:06:37+00:00

Scottish light welterweight Reese Lynch says his family support can help him emulate world champion Josh Taylor.

## Euro 2022: Young players talk about diversity in England's squad
 - [https://www.bbc.co.uk/news/newsbeat-62346385?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-62346385?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 12:05:51+00:00

Euro 2022 has made the Lionesses household names - but some young want more diversity in the squad.

## Ukraine war: Russia says 40 Ukrainian prisoners killed in blast
 - [https://www.bbc.co.uk/news/world-europe-62344358?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62344358?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 11:59:21+00:00

The Ukrainian and Russian militaries accuse each other of shelling a prison camp in Donetsk.

## Boston: Two arrested after death of girl, 9, in suspected stabbing
 - [https://www.bbc.co.uk/news/uk-england-lincolnshire-62345092?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lincolnshire-62345092?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 11:57:04+00:00

Flowers are laid and candles lit as a murder investigation is under way in Boston, Lincolnshire.

## Commonwealth Games 2022: England's Alex Yee wins first gold
 - [https://www.bbc.co.uk/sport/av/commonwealth-games/62349499?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/commonwealth-games/62349499?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 11:37:30+00:00

Watch England's Alex Yee win the first gold medal of the 2022 Commonwealth Games in dramatic style as New Zealand's Hayden Wilde is given a 10-second penalty.

## Details of £400 energy payment to households revealed
 - [https://www.bbc.co.uk/news/business-62338543?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62338543?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 11:33:47+00:00

The money will be spread over six months but how it is received depends on how you pay your bills.

## Commonwealth Games 2022: Alex Yee wins triathlon gold in Birmingham's first medal event
 - [https://www.bbc.co.uk/sport/commonwealth-games/62346040?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/commonwealth-games/62346040?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 11:32:10+00:00

England's Alex Yee wins the first gold medal of the 2022 Commonwealth Games as world number one Hayden Wilde incurs a 10-second penalty late on in the race.

## Covid infections on the way down again across the UK
 - [https://www.bbc.co.uk/news/health-62344902?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-62344902?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 11:24:55+00:00

About 3.2 million are thought to have the virus - a drop of more than half a million on the previous week.

## Sarah Everard killer: Wayne Couzens loses bid to reduce whole-life term
 - [https://www.bbc.co.uk/news/uk-62345010?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62345010?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 11:07:45+00:00

The sentence of Sarah Everard’s murderer was one of five being reviewed at the Court of Appeal.

## UK heatwave: Weather forecasters report unprecedented trolling
 - [https://www.bbc.co.uk/news/uk-62323048?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62323048?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 10:57:48+00:00

Meteorologists from the BBC and elsewhere faced abuse as they reported on the UK's record heat.

## Hampshire and Isle of Wight hosepipe ban from 5 August
 - [https://www.bbc.co.uk/news/uk-england-hampshire-62345286?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-hampshire-62345286?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 10:53:02+00:00

The restriction aims to reduce the amount of water being extracted from two rivers.

## Fast fashion: How clothes are linked to climate change
 - [https://www.bbc.co.uk/news/science-environment-60382624?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-60382624?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 10:43:55+00:00

Fashion is responsible for 10% of global emissions - buying less and renting clothes could help.

## Euro 2022 final: How to watch and follow England v Germany on the BBC
 - [https://www.bbc.co.uk/sport/football/62346680?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62346680?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 10:38:49+00:00

England are one win away from a first major women's trophy - and you can watch and follow all the action from Sunday's Euro 2022 final on the BBC.

## Beyoncé album Renaissance a dance-floor hit with critics
 - [https://www.bbc.co.uk/news/entertainment-arts-62344821?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62344821?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 09:55:20+00:00

The star's seventh studio album is seen as having potential to "joyously redefine dance floors".

## Instagram U-turns on TikTok-style revamp
 - [https://www.bbc.co.uk/news/technology-62345306?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62345306?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 09:53:41+00:00

The social media platform pauses the rollout of new features after an online community backlash.

## Commonwealth Games 2022: Ellie Boatman scores four tries as England thrash Sri Lanka
 - [https://www.bbc.co.uk/sport/av/commonwealth-games/62347162?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/commonwealth-games/62347162?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 09:52:27+00:00

Watch Ellie Boatman score four tries in the first-half of England's 57-0 win against Sri Lanka in the women's rugby 7s at the Commonwealth Games.

## Commonwealth: Seven things you might not know
 - [https://www.bbc.co.uk/news/uk-43715079?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-43715079?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 09:08:38+00:00

With the 22nd Commonwealth Games underway in Birmingham, which countries make up the global club?

## Commonwealth Games: Leon Reid 'exploring all options' to overturn Games ban
 - [https://www.bbc.co.uk/sport/commonwealth-games/62332947?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/commonwealth-games/62332947?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 09:08:23+00:00

Northern Ireland sprinter Leon Reid says he is "exploring all options" to have his Commonwealth Games ban overturned.

## Spanish beach body campaign used my image without asking - model
 - [https://www.bbc.co.uk/news/newsbeat-62345734?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-62345734?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 09:05:22+00:00

British model Nyome says she had "no idea" a Spanish body positivity campaign had used her photo.

## Samuel Alito: Top US judge mocks world leaders over abortion ruling
 - [https://www.bbc.co.uk/news/world-us-canada-62344354?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62344354?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 08:03:51+00:00

Samuel Alito dismisses Boris Johnson and others who condemned the move to restrict abortion.

## Women's European Championship: Ten years, six landmark moments
 - [https://www.bbc.co.uk/sport/football/62280778?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62280778?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 05:45:02+00:00

BBC Sport identifies six key moments over the last decade that brought the English women's game to where it is today…

## Birmingham Commonwealth Games: How can I get to events?
 - [https://www.bbc.co.uk/news/uk-england-birmingham-62332208?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-62332208?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 05:33:58+00:00

Visitors to Birmingham are being encouraged to leave the car at home and use public transport.

## Harry Potter cafe left in limbo after fire damage
 - [https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-62297791?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-62297791?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 05:10:31+00:00

Almost a year on after a fire broke out on George IV Bridge in Edinburgh businesses remain shut.

## Chris Mason: Truss courts Johnson loyalists as Sunak faces jibes
 - [https://www.bbc.co.uk/news/uk-politics-62342965?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62342965?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 04:17:46+00:00

Liz Truss continues to emphasise her loyalty to the outgoing prime minister, while Rishi Sunak stands accused of stabbing him in the back

## Why Dutch farmers are protesting over emissions cuts
 - [https://www.bbc.co.uk/news/world-europe-62335287?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62335287?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 01:15:15+00:00

Farmers say proposals to cut livestock and reduce intensive farming unfairly target their industry.

## Climate change: Will naming heatwaves save lives?
 - [https://www.bbc.co.uk/news/world-us-canada-62297346?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62297346?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 00:18:42+00:00

Will naming heatwaves help stem rising heat-related deaths and hospitalisations across the US?

## Nepal: Return of the tigers brings both joy and fear
 - [https://www.bbc.co.uk/news/world-asia-62264158?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-62264158?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 00:14:22+00:00

The increase in tiger numbers in Nepal has brought challenges to the local community.

## Africa's week in pictures: 22-28 July 2022
 - [https://www.bbc.co.uk/news/world-africa-62332375?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-62332375?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-29 00:00:52+00:00

A selection of the best photos from across Africa and beyond this week.


# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## This Is Concerning
 - [https://www.youtube.com/watch?v=GL1krGIPdDQ](https://www.youtube.com/watch?v=GL1krGIPdDQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-07-30 00:00:00+00:00

I’ve been talking to Dr Bernardo Kastrup - author of ‘Why Materialism is Baloney’ about how the mainstream media and intellectual elites shape our reality in a materialistic world and how science underwrites our politics #mainstreamedia #CNN #materialism 
--------------------------------------------------------------------------------------------------------------------------
Tickets To My Live Show: https://www.russellbrand.com/live-dates/

Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## This Is F*cking Insane!
 - [https://www.youtube.com/watch?v=PrimInXVAn4](https://www.youtube.com/watch?v=PrimInXVAn4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-07-29 00:00:00+00:00

Veterans and active military families cannot afford to eat food in spite of Biden pledging $840 billion to the military. So why is this happening? 
#military #biden #pentagon #ukraine #russia  

References
https://responsiblestatecraft.org/2022/07/17/military-families-facing-housing-health-and-food-challenges-survey-finds/
https://policyadvice.net/insurance/insights/homeless-veterans-statistics/
https://responsiblestatecraft.org/2022/07/11/congress-showers-the-pentagon-with-cash-while-americans-pinch-pennies/
https://watson.brown.edu/costsofwar/files/cow/imce/papers/2021/Profits%20of%20War_Hartung_Costs%20of%20War_Sept%2013%2C%202021.pdf
https://www.nationalpriorities.org/pressroom/articles/2022/04/13/about-that-900-you-gave-pentagon-contractors/
https://truthout.org/articles/average-us-taxpayer-gave-900-to-military-contractors-last-year/
https://jacobin.com/2022/03/biden-budget-military-pentagon-social-spending-war
https://www.opensecrets.org/news/reports/capitalizing-on-conflict
--------------------------------------------------------------------------------------------------------------------------
Tickets To My Live Show: https://www.russellbrand.com/live-dates/

Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


# Source:SssethTzeentach, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg, language:en-US

## Space Warlord Organ Trading Simulator Review | Universal Donor Edition™
 - [https://www.youtube.com/watch?v=4Ppw5yTa3uk](https://www.youtube.com/watch?v=4Ppw5yTa3uk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg
 - date published: 2022-07-29 16:15:12+00:00

Universal donor edition.
30% off on Steam until August 1st:
https://store.steampowered.com/app/1507780/Space_Warlord_Organ_Trading_Simulator/

Companion OST:
https://spellmynamewithabang.bandcamp.com/album/the-space-warlord-organ-trading-simulator-official-companion-album

No merchants were charged in the making of this video.

-----------------------
Send Sseth Shekels: https://www.paypal.me/SsethTzeentachGB
Send Sseth Shekels per video:  https://www.patreon.com/Sseth
Send Sseth Shekels / crypto: https://www.subscribestar.com/ssethtzeentach

Website: https://www.ssethtzeentach.com/
Twitter: https://twitter.com/SsethTzeentach


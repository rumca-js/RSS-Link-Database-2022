## Sri Lanka Inflation Rises to 60.8% as Dollar Crunch Persists
 - [https://www.bloomberg.com/news/articles/2022-07-29/sri-lanka-inflation-climbs-to-60-8-as-dollar-crunch-persists](https://www.bloomberg.com/news/articles/2022-07-29/sri-lanka-inflation-climbs-to-60-8-as-dollar-crunch-persists)
 - RSS feed: https://www.bloomberg.com
 - date published: 2022-07-29 14:09:02+00:00

Sri Lanka Inflation Rises to 60.8% as Dollar Crunch Persists


# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Epstein's Harvard Connection & Ghislaine's List
 - [https://www.youtube.com/watch?v=A0jpYGmWpYI](https://www.youtube.com/watch?v=A0jpYGmWpYI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-07-29 00:00:00+00:00

Taken from JRE #1850 w/Whitney Cummings:
https://open.spotify.com/episode/5TD275rSLx8SmYrJvSoVRm?si=841a4f0f455247d4

## The Backlash Whitney Cummings Received Over Her Sitcom
 - [https://www.youtube.com/watch?v=TRzeL5FXd4Y](https://www.youtube.com/watch?v=TRzeL5FXd4Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-07-29 00:00:00+00:00

Taken from JRE #1850 w/Whitney Cummings:
https://open.spotify.com/episode/5TD275rSLx8SmYrJvSoVRm?si=841a4f0f455247d4


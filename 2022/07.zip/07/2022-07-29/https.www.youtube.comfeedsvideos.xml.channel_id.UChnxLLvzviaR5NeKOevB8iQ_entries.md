# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## An Elektron Syntakt Set (and Mini Review!)
 - [https://www.youtube.com/watch?v=HIe4FXmEajo](https://www.youtube.com/watch?v=HIe4FXmEajo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2022-07-29 00:00:00+00:00

Thanks for helping us raise over $2500 for abortion rights! The campaign is done!

The Syntakt is Elektron's most recent offering that features a bunch of analog and digital engines from other devices in a nice fun package. Here's a set I wrote on it after having it for a few days.

00:00 mini-review and track 1
02:22 track 2
05:14 track 3
08:06 track 4
10:41 track 5
13:35 track 6
15:38 track 7
17:59 track 8
20:03 track 9
21:36 track 10

Join Patreon and get access to music, presets, samples, and a great community.
Join Patreon:  http://bit.ly/rmrpatreon

Find my music here: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
YouTube Music: https://bit.ly/3PZQ4ol
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia


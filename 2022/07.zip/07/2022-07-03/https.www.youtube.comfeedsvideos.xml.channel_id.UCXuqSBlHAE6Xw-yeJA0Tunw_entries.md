# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I Await Sony’s Cease and Desist - PS3 Dev Kit
 - [https://www.youtube.com/watch?v=0Hr8aqGp5mk](https://www.youtube.com/watch?v=0Hr8aqGp5mk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-07-04 00:00:00+00:00

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/linus

Create your build at https://www.buildredux.com/linus

We got hands-on with a Playstation 3 development kit and an early prototype of the PS Vita. I promise this one will be interesting.

Discuss on the forum: https://linustechtips.com/topic/1441115-i-await-sony%E2%80%99s-cease-and-desist/

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro & History
2:53 The IO
3:57 The insides :o
9:07 Does it still work?
11:00 Life is Strange dev build
12:19 Little Big Planet dev build
13:09 Xbox games... on a PS3
14:22 The PS Vita prototype

## We’ve NEVER done this before… - Mother Vault Part 1 - JBOD
 - [https://www.youtube.com/watch?v=n_izpaZ0u5o](https://www.youtube.com/watch?v=n_izpaZ0u5o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-07-03 00:00:00+00:00

Get $25 off all pairs of Vessi Footwear with offer code LinusTechTips at https://www.Vessi.com/LinusTechTips

Get your Crucial DDR5 RAM today at: https://crucial.gg/LTT_DDR5

We've built some cool machines on the channel, but nothing is even close to the plan for our 3.6-petabyte archival storage array. 

Discuss on the forum: https://linustechtips.com/topic/1440919-the-craziest-server-weve-ever-built/

Check out the SuperMicro JBOD: https://lmg.gg/jbod
Check out InfiniteCable's MiniSAS HD external cables: https://lmg.gg/minisashdexternal

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro & History
4:19 The JBOD
9:15 The Computer
14:10 FILLED
15:26 Cabling & Zoning
16:23 It's... LOUD
18:19 IPMI
18:54 What about dual path & high availability?
19:58 It's aliveeee!
21:30 Performance testing & outro


# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Dumb Video Game Moves That Are TRULY INSANE
 - [https://www.youtube.com/watch?v=18QtVjjjYEQ](https://www.youtube.com/watch?v=18QtVjjjYEQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-07-04 00:00:00+00:00

Some gaming moves are super stupid but also extremely awesome. Yep, that's video games for you. Here are some of our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro 
0:20 Number 10 
1:43 Number 9 
3:30 Number 8
4:32 Number 7
5:42 Number 6
7:04 Number 5
8:01 Number 4 
9:15 Number 3 
10:16 Number 2
11:27 Number 1

## 10 WEIRD Gaming Stories of June 2022
 - [https://www.youtube.com/watch?v=MOSBsOOr5C0](https://www.youtube.com/watch?v=MOSBsOOr5C0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-07-03 00:00:00+00:00

Every month we put together the weirdest of the weird stories in the gaming world. Here's the weirdest gaming stories of June 2022.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


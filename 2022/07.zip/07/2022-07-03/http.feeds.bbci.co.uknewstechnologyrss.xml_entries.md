# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## MPs call for UK ban on two Chinese CCTV firms
 - [https://www.bbc.co.uk/news/technology-62003253?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62003253?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-07-03 23:19:25+00:00

Sixty-seven MPs and Lords have said Hikvision and Dahua surveillance equipment should be banned.


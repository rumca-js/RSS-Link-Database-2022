# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Ukrainian forces withdraw from Lysychansk, their last holdout in key region
 - [https://www.cnn.com/2022/07/03/europe/russia-ukraine-luhansk-lysychansk-intl/index.html](https://www.cnn.com/2022/07/03/europe/russia-ukraine-luhansk-lysychansk-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-03 21:28:31+00:00

Russia has taken control of Lysychansk, the last city in the Luhansk region in eastern Ukraine that was still under Ukrainian control.

## Several people killed in Copenhagen mall shooting, police say
 - [https://www.cnn.com/collections/intl-copenhagen/](https://www.cnn.com/collections/intl-copenhagen/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-03 20:45:19+00:00



## 6 dead and at least a dozen still missing after ice avalanche in Italian Alps
 - [https://www.cnn.com/2022/07/03/europe/italy-avalanche-rescue-intl/index.html](https://www.cnn.com/2022/07/03/europe/italy-avalanche-rescue-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-03 19:13:00+00:00

At least six people were killed and another eight injured following an avalanche of ice in the Italian Alps, CNN affiliate Skytg24 said Sunday, citing first responders.

## Carlos Sainz secures first F1 victory in British GP as Zhou Guanyu survives dramatic crash
 - [https://www.cnn.com/2022/07/03/motorsport/carlos-sainz-british-gp-zhou-guanyu-spt-intl/index.html](https://www.cnn.com/2022/07/03/motorsport/carlos-sainz-british-gp-zhou-guanyu-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-03 17:00:39+00:00

Carlos Sainz secured his first victory in F1 during a dramatic British Grand Prix on Sunday where Alfa Romeo's Zhou Guanyu survived a huge crash on the first lap.

## Mom agonizes about how to reach her son, a man with a Buddha tattoo who turned to hate
 - [https://www.cnn.com/2022/07/03/us/mom-tries-to-help-extremist-son-sidner/index.html](https://www.cnn.com/2022/07/03/us/mom-tries-to-help-extremist-son-sidner/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-03 16:59:46+00:00

The first sign of trouble was brief. Just a couple of comments during the hustle and bustle of regular life.

## The Mayflower 400 just crossed the Atlantic without any crew on board
 - [https://www.cnn.com/videos/business/2022/07/03/mayflower-autonomous-ship-ibm-promare-orig-jc.cnn](https://www.cnn.com/videos/business/2022/07/03/mayflower-autonomous-ship-ibm-promare-orig-jc.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-03 16:40:32+00:00

The Mayflower Autonomous Ship (MAS) is an innovative initiative led by marine non-profit ProMare. Its builders say the ship can help us deepen our understanding of critical issues such as climate change, ocean plastic pollution and marine mammal conservation.

## More Jan. 6 witnesses have come forward, Kinzinger says
 - [https://www.cnn.com/collections/jan-6-intl-070122/](https://www.cnn.com/collections/jan-6-intl-070122/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-03 15:34:37+00:00



## Kinzinger fires back after GOP governor attacks Cassidy Hutchinson's credibility
 - [https://www.cnn.com/videos/politics/2022/07/03/adam-kinzinger-kristi-noem-cassidy-hutchinson-donald-trump-bash-sotu-vpx.cnn](https://www.cnn.com/videos/politics/2022/07/03/adam-kinzinger-kristi-noem-cassidy-hutchinson-donald-trump-bash-sotu-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-03 14:39:09+00:00

Rep. Adam Kinzinger (R-IL) responds to South Dakota Gov. Kristi Noem's interview with CNN's Dana Bash, where she tried to discredit Cassidy Hutchinson's testimony to the January 6 select committee.

## CNN's Dana Bash asks GOP Gov. Kristi Noem if South Dakota would force a 10-year-old to have a baby
 - [https://www.cnn.com/videos/politics/2022/07/03/kristi-noem-south-dakota-governor-abortion-ban-bash-sotu-vpx.cnn](https://www.cnn.com/videos/politics/2022/07/03/kristi-noem-south-dakota-governor-abortion-ban-bash-sotu-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-03 14:00:41+00:00

Governor Kristi Noem (R-SD), discusses a report in the Indianapolis Star where an OBGYN said a 10-year-old girl was forced to leave Ohio to obtain an abortion. South Dakota has banned all abortions except when the mother's life is at risk.

## Hong Kong lawmaker photographed with Chinese President Xi tests positive for Covid-19
 - [https://www.cnn.com/2022/07/03/asia/china-xi-visit-hong-kong-covid-case-intl/index.html](https://www.cnn.com/2022/07/03/asia/china-xi-visit-hong-kong-covid-case-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-03 12:23:53+00:00

A Hong Kong lawmaker who was photographed standing close to Chinese President Xi Jinping earlier this week announced Sunday he had tested positive for Covid-19.

## Ukrainian forces withdraw from Lysychansk, their last holdout in key region
 - [https://www.cnn.com/collections/int-0702-ukraine/](https://www.cnn.com/collections/int-0702-ukraine/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-03 12:07:46+00:00



## Nick Kyrgios called 'evil' and a 'bully' by defeated Wimbledon opponent Stefanos Tsitsipas
 - [https://www.cnn.com/2022/07/03/tennis/nick-kyrgios-stefanos-tsitsipas-wimbledon-spt-intl/index.html](https://www.cnn.com/2022/07/03/tennis/nick-kyrgios-stefanos-tsitsipas-wimbledon-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-03 10:25:34+00:00

Stefanos Tsitsipas said Nick Kyrgios has an "evil side" to his character after losing to the Australian in a feisty match at Wimbledon on Saturday.

## Trump-backed Michigan secretary of state nominee said abortion is 'child sacrifice'
 - [https://www.cnn.com/2022/07/03/politics/kfile-kristina-karamo-abortion-child-sacrifice/index.html](https://www.cnn.com/2022/07/03/politics/kfile-kristina-karamo-abortion-child-sacrifice/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-03 10:03:54+00:00

Before becoming the Trump-backed Republican nominee for Michigan secretary of state, Kristina Karamo said that abortion is "child sacrifice" and a "satanic practice."

## Taliban: ISIS offshoot is a 'false sect'
 - [https://www.cnn.com/2022/07/03/middleeast/taliban-isis-k-seditious-sect-afghanistan-intl-hnk/index.html](https://www.cnn.com/2022/07/03/middleeast/taliban-isis-k-seditious-sect-afghanistan-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-03 08:24:51+00:00

The Taliban has declared the Islamic State affiliate ISIS-K a corrupt "sect" and forbidden Afghans from contact with it.

## Belarus claims to have shot down Ukrainian missiles
 - [https://www.cnn.com/2022/07/03/world/belarus-alexander-lukashenko-ukraine-missiles-russia-war-intl-hnk/index.html](https://www.cnn.com/2022/07/03/world/belarus-alexander-lukashenko-ukraine-missiles-russia-war-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-03 08:09:00+00:00

Belarusian President Alexander Lukashenko has accused Ukraine of firing missiles at military facilities on his country's territory.

## Some Americans are offering to help others travel out of state for an abortion. But experts urge caution
 - [https://www.cnn.com/2022/07/03/us/abortion-help-travel-out-of-state-online-offers/index.html](https://www.cnn.com/2022/07/03/us/abortion-help-travel-out-of-state-online-offers/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-03 08:02:16+00:00

The heartfelt messages spread across social media within hours of the seismic Supreme Court ruling overturning Roe v. Wade: If you need assistance getting an abortion in another state, I can help.

## Ukrainian footballer begged parents to flee. They said they'd be safe in leafy Bucha
 - [https://www.cnn.com/2022/07/02/football/ukraine-bucha-hong-kong-footballer-parents-intl-hnk/index.html](https://www.cnn.com/2022/07/02/football/ukraine-bucha-hong-kong-footballer-parents-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-03 04:35:19+00:00

Ukrainian professional footballer Aleks Shliakotin begged his parents to flee the country after Russian bombs went off a kilometer from their Kyiv home.

## Thousands told to evacuate Sydney, as heavy rains bring 'life threatening emergency'
 - [https://www.cnn.com/2022/07/02/weather/sydney-australia-flooding-intl-hnk/index.html](https://www.cnn.com/2022/07/02/weather/sydney-australia-flooding-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-03 03:22:50+00:00

Thousands of residents were ordered to evacuate southwest Sydney, Australia's biggest city, on Sunday with torrential rain and damaging winds pounding the east coast and threatening floods in areas that were hammered in March.

## Ex-Secret Service agent reacts to testimony: Did we expect anything less from Trump?
 - [https://www.cnn.com/videos/politics/2022/07/02/jonathan-wackrow-ex-secret-service-agent-trump-hutchinson-acostanr-vpx.cnn](https://www.cnn.com/videos/politics/2022/07/02/jonathan-wackrow-ex-secret-service-agent-trump-hutchinson-acostanr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-03 01:04:08+00:00

Former Secret Service agent Jonathan Wackrow commends the actions of his fellow agents on January 6, despite then-President Trump's alleged demands to be taken to the Capitol to join the insurrectionists.


# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Eating Your Immunizations
 - [https://www.youtube.com/watch?v=L1el6g4J6gw](https://www.youtube.com/watch?v=L1el6g4J6gw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-07-04 00:00:00+00:00

Visit http://brilliant.org/scishow/ to get started learning STEM for free, and the first 200 people will get 20% off their annual premium subscription.

For those with a fear of needles, edible vaccines seem like some distant utopian dream, but that dream may soon be a reality... for chickens.

Hosted by: Michael Aranda

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Matt Curls, Alisa Sherbow, Dr. Melvin Sanicas, Harrison Mills, Adam Brainard, Chris Peters, charles george, Piya Shedden, Alex Hackman, Christopher R Boucher, Jeffrey Mckishen, Ash, Silas Emrys, Eric Jensen, Kevin Bealer, Jason A Saslow, Tom Mosner, Tomás Lagos González, Jacob, Christoph Schwanke, Sam Lutfi, Bryan Cloer

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow
----------
Sources:
https://www.cdc.gov/flu/prevent/how-fluvaccine-made.htm 
https://www.mdpi.com/2076-393X/10/3/478/htm 
https://www.researchgate.net/profile/Phil-Wambura/publication/5352968_Oral_vaccination_of_chickens_against_Newcastle_disease_with_I-2_vaccine_coated_on_oiled_rice/links/02e7e51703e6749b0e000000/Oral-vaccination-of-chickens-against-Newcastle-disease-with-I-2-vaccine-coated-on-oiled-rice.pdf 
https://eorganic.org/node/7839 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7122597/ 
https://doi.org/10.1086/519692 
https://www.chop.edu/centers-programs/vaccine-education-center/vaccine-details/polio-vaccine 
https://www.sciencedirect.com/science/article/pii/S0168365915301796 
https://pubmed.ncbi.nlm.nih.gov/17627533/ 
https://www.sciencedirect.com/science/article/pii/S1056617119311055  
https://doi.org/10.1155/2016/4928637

Image Sources:
https://www.gettyimages.com/detail/video/plant-based-non-meat-vegan-burger-stock-footage/1204442474?adppopup=true
https://www.gettyimages.com/detail/video/syringe-ready-for-injection-stock-footage/1221621326?adppopup=true
https://www.gettyimages.com/detail/photo/chicken-or-hen-on-a-green-meadow-royalty-free-image/1217649450?adppopup=true
https://www.gettyimages.com/detail/video/antibodies-block-a-virus-from-entering-a-body-cell-stock-footage/1221226197?adppopup=true
https://www.gettyimages.com/detail/video/lemna-minor-or-common-duckweed-with-little-water-stock-footage/1355007113?adppopup=true
https://www.gettyimages.com/detail/video/free-range-rooster-and-chickens-grazing-in-the-garden-stock-footage/617619152?adppopup=true
https://www.gettyimages.com/detail/video/test-tubes-with-sample-samples-stored-in-the-stock-footage/1287233202?adppopup=true
https://www.gettyimages.com/detail/video/pharmaceutical-manufacturing-line-automatic-machine-at-stock-footage/1299623675?adppopup=true
https://www.gettyimages.com/detail/video/infected-human-body-red-and-white-blood-cells-and-stock-footage/1341698082?adppopup=true
https://www.gettyimages.com/detail/video/antibodies-attack-a-cancer-cell-or-virus-stock-footage/1167101317?adppopup=true
https://www.gettyimages.com/detail/video/young-white-chickens-and-roosters-walk-free-range-and-stock-footage/1332632465?adppopup=true
https://commons.wikimedia.org/wiki/File:A_(H5N1)_virion,_a_type_of_bird_flu_virus_which_is_a_subtype_of_avian_influenza_A.jpg
https://www.gettyimages.com/detail/illustration/seamless-texture-with-bacterias-and-germs-royalty-free-illustration/872316290?adppopup=true
https://www.gettyimages.com/detail/video/feeding-the-chicken-in-farm-stock-footage/1059095226?adppopup=true
https://www.gettyimages.com/detail/video/large-group-of-chickens-at-the-poultry-farm-stock-footage/685815410?adppopup=true
https://www.gettyimages.com/detail/video/free-range-chickens-peck-grass-while-roaming-around-stock-footage/1198491913?adppopup=true

How Plants Might Eliminate Shots… If You’re a Chicken


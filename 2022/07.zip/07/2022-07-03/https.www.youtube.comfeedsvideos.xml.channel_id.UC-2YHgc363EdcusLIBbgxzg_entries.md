# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Aim High: The Long, Strange History Of Drugs In The Military | Answers With Joe
 - [https://www.youtube.com/watch?v=RmKZk0y26Lg](https://www.youtube.com/watch?v=RmKZk0y26Lg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2022-07-04 00:00:00+00:00

Visit http://www.brilliant.org/answerswithjoe to start learning STEM for free, and the first 200 people will get 20% off their annual premium subscription.
In the 1960s, the US military tested a psychedelic called BZ on its own troops, to study how they could use it as a weapon. The results were shocking, but drugs have been used in the military for as long as humans have been fighting each other. Today we take a look at this taboo subject.

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

And my podcast channel, Conversations With Joe:
https://www.youtube.com/channel/UCJzc7TiJ2nnuyJkUpOZ8RKA

You can listen to my podcast, Conversations With Joe on Spotify, Apple Podcasts, Google Podcasts, or wherever you get your podcasts.
Spotify 👉 https://spoti.fi/37iPGzF
Apple Podcasts 👉 https://apple.co/3j94kfq
Google Podcasts 👉 https://bit.ly/3qZCo1V

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS -
https://militaryhistorynow.com/2018/05/08/combat-high-a-sobering-history-of-drug-use-in-wartime/
https://www.drugfreeworld.org/drugfacts/lsd/a-short-history.html
https://timeline.com/the-history-of-psychedelics-and-psychotherapy-fe70f72557aa
https://www.history.com/topics/crime/history-of-lsd
https://www.ncbi.nlm.nih.gov/books/NBK201480/
https://www.chemicalbook.com/ProductChemicalPropertiesCB1244838_EN.htm#:~:text=The%203%2Dquinuclidinyl%20benzilate%20(3,atropine%2C%20for%20treating%20gastrointestinal%20conditions
https://www.nbcnews.com/id/wbna3340693
https://www.wearethemighty.com/articles/army-chemical-weapons-bz/
https://www.newyorker.com/magazine/2012/12/17/operation-delirium
https://www.marijuanamoment.net/military-invests-27m-to-develop-new-class-of-psychedelics-inspired-drugs/
https://www.smithsonianmag.com/science-nature/why-psychedelic-drugs-may-become-a-key-treatment-for-ptsd-and-depression-180979983/
https://www.healthline.com/health-news/how-psychedelic-drugs-are-helping-veterans-and-others-with-ptsd-depression
https://www.newyorker.com/news/news-desk/high-anxiety-lsd-in-the-cold-war
https://pubmed.ncbi.nlm.nih.gov/28686061/
https://www.marijuanamoment.net/military-invests-27m-to-develop-new-class-of-psychedelics-inspired-drugs/

TIMESTAMPS -
0:00 - Intro
1:33 - Different Types of Stimulants
4:48 - Psychedelics
5:48 - Project MK-Ultra
6:41 - Agent BZ
7:35 - U.S. Army Experimenting With BZ
8:26 - Most Notable BZ Tests
11:04 - Project DORK
12:31 - Effects of Experiments
13:31 - Psychedelics to Treat 
14:55 - Sponsor - Brilliant


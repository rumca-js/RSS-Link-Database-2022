# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## A working flight simulator, no computers necessary
 - [https://www.youtube.com/watch?v=RJAYZgOZS08](https://www.youtube.com/watch?v=RJAYZgOZS08)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2022-07-04 00:00:00+00:00

There are only a few working Link Trainers left in the world: but before microprocessors, before display screnes, half a million pilots learned the basics of instrument flying inside one. More: https://www.most.org/explore/link-flight-trainer/

Edited by Michelle Martin, https://twitter.com/mrsmmartin

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo


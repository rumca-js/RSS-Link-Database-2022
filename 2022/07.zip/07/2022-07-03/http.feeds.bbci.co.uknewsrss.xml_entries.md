# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Kenya's cost-of-living crisis: 'I can't afford rice for my children'
 - [https://www.bbc.co.uk/news/world-africa-61881651?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-61881651?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 23:37:48+00:00

Florence Kambua has no choice but to salvage waste from a dump site in Kenya's capital to survive.

## Ben Raemers: The skateboarding hero who couldn't handle fame
 - [https://www.bbc.co.uk/news/uk-england-essex-61882028?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-61882028?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 23:36:08+00:00

When Ben Raemers killed himself at the top of his game, it left many skateboarders asking questions.

## Using human hair to fight oil spills
 - [https://www.bbc.co.uk/news/stories-62015006?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/stories-62015006?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 23:29:48+00:00

A hairdresser in Wales is collecting her customers' hair and turning it into something useful.

## Bihar: Their son vanished - then an imposter took over for 41 years
 - [https://www.bbc.co.uk/news/world-asia-india-61981241?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-61981241?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 23:17:22+00:00

An Indian man, pretending to be a missing son, deceived the boy's family for over four decades.

## The retailers setting up shop in the metaverse
 - [https://www.bbc.co.uk/news/business-61979150?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61979150?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 23:10:24+00:00

As brands join the new virtual universe they have to choose exactly where to locate themselves.

## Finding the Higgs: ‘Incredible’ moment in science
 - [https://www.bbc.co.uk/news/stories-61998895?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/stories-61998895?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 23:02:05+00:00

Cern physicist Dr Andre David describes the moment scientists found the ‘God particle’

## Ukraine round-up: Russia takes Lysychansk and border city hit
 - [https://www.bbc.co.uk/news/world-europe-62030058?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62030058?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 20:20:02+00:00

After weeks of heavy fighting Ukraine withdrew from Lysychansk - the latest eastern city to fall.

## The Railway Children sequel gets premiere at original Yorkshire station
 - [https://www.bbc.co.uk/news/entertainment-arts-62014506?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62014506?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 15:36:21+00:00

Jenny Agutter and her new co-stars travel to Oakworth, 52 years after the classic film's release.

## Emotional Sue Barker gets Centre Court ovation
 - [https://www.bbc.co.uk/sport/av/tennis/62029228?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/tennis/62029228?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 13:41:42+00:00

Watch Sue Barker receive a standing ovation from the Centre Court crowd after John McEnroe pays an emotional tribute to the BBC presenter.

## St Paul's Carnival: Scaled-down event honours elders
 - [https://www.bbc.co.uk/news/uk-england-bristol-62023355?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-bristol-62023355?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 12:18:17+00:00

Instead of the full event, community elders were honoured at St Paul's Carnival in Bristol.

## Chris Pincher: New claims emerge against former Tory MP
 - [https://www.bbc.co.uk/news/uk-politics-62025612?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62025612?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 11:54:58+00:00

Six new claims of inappropriate behaviour from over a decade come after the former Tory MP was suspended.

## Ukraine blamed by Russia for deadly blast in border city of Belgorod
 - [https://www.bbc.co.uk/news/world-europe-62025541?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62025541?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 11:54:06+00:00

Ukraine dismisses claims that its forces targeted homes in the Russian city of Belgorod, killing three.

## Peter Brook: British stage directing great dies aged 97
 - [https://www.bbc.co.uk/news/entertainment-arts-12553081?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-12553081?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 11:23:09+00:00

His works, featuring theatre's most distinguished names, both enthralled and shocked audiences.

## Wimbledon: Watch Nick Kyrgios hit back at Stefanos Tsitsipas for bullying claims
 - [https://www.bbc.co.uk/sport/av/tennis/62028352?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/tennis/62028352?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 11:07:32+00:00

Nick Kyrgios hits back at Stefanos Tsitsipas for accusing him of bullying and says the Greek player is "soft" following their controversial four-set thriller at Wimbledon.

## What happened when England last hosted the Women's European Championship?
 - [https://www.bbc.co.uk/sport/football/61810075?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/61810075?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 11:02:38+00:00

Seventeen years after England last hosted the Women's European Championship, the tournament is back in the country but what was it like in 2005 and was it a success?

## England v India: Redemption for Jasprit Bumrah as he catches Ben Stokes
 - [https://www.bbc.co.uk/sport/av/cricket/62028293?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/62028293?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 10:57:22+00:00

Watch as Ben Stokes loses his wicket as Jasprit Bumrah takes a sensational catch

## Sydney floods: Tens of thousands told to evacuate
 - [https://www.bbc.co.uk/news/world-australia-62027248?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-62027248?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 09:04:15+00:00

Roads have been cut off, with 18 evacuation orders in western Sydney alone and warnings of more to come.

## Taiwan: China attack not imminent, but US watching closely, says Gen Milley
 - [https://www.bbc.co.uk/news/world-asia-62022308?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-62022308?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 08:28:32+00:00

Top US general Mark Milley says China clearly is developing the capability to be able to attack Taiwan.

## LIV Golf: Paul Casey joins breakaway series as Branden Grace wins in Portland
 - [https://www.bbc.co.uk/sport/golf/62025387?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/golf/62025387?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 06:08:40+00:00

Paul Casey becomes the latest high-profile golfer to join the Saudi-backed LIV Golf Series.

## The Papers: PM 'turned blind eye' and Charles honours claim
 - [https://www.bbc.co.uk/news/blogs-the-papers-62025358?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-62025358?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 04:46:24+00:00

Boris Johnson has been accused of failing to act on Chris Pincher allegations sooner, papers report.

## Three police die in 'pure hell' Kentucky shooting
 - [https://www.bbc.co.uk/news/world-us-canada-62025539?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62025539?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 02:34:09+00:00

The officers are killed along with a police dog as they try to serve a warrant for domestic violence.

## Boris Johnson's 40 new hospitals pledge faces watchdog review
 - [https://www.bbc.co.uk/news/uk-politics-62025410?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62025410?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 00:36:13+00:00

The Conservatives said in their 2019 election manifesto the facilities would be built by 2030.

## US woman denied termination in Malta: 'I was terrified'
 - [https://www.bbc.co.uk/news/world-61959825?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-61959825?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-03 00:04:18+00:00

Andrea was medically evacuated to Spain as doctors in Malta could not terminate her pregnancy under the country's ban on abortion.


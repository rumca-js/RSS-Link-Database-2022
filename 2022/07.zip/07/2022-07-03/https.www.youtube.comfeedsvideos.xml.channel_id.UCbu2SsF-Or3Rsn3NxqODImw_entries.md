# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Best Games Of 2022 (So Far)
 - [https://www.youtube.com/watch?v=AvgTlF8kUPM](https://www.youtube.com/watch?v=AvgTlF8kUPM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-07-04 00:00:00+00:00

2022 has been packed full of great games, from huge blockbusters like Elden Ring to smaller titles that might have slipped under your radar.

00:00:00 - Intro
00:00:14 - Neon White
00:00:49 - The Quarry
00:01:20 - Kirby and the Forgotten Land
00:01:50 - Ghostwire: Tokyo
00:02:15 - Horizon: Forbidden West
00:02:45 - Tunic
00:03:21 - Elden Ring
00:03:54 - Stanley Parable: Ultra Deluxe
00:04:20 - Nintendo Switch Sports
00:04:43 - Destiny 2: The Witch Queen
00:05:06 - Nobody Saves The World
00:05:34 - Sniper Elite 5
00:05:54 - TMNT Shredder's Revenge
00:06:25 - Norco
00:06:57 - Monster Hunter Rise
00:07:52 - Outro

## 16 MORE Things You STILL Didn't Know In Zelda Breath Of The Wild
 - [https://www.youtube.com/watch?v=GdZI4JHLYqI](https://www.youtube.com/watch?v=GdZI4JHLYqI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-07-03 00:00:00+00:00

This time in Breath of the Wild, we show how Nintendo updates the map as you play the game, the newest broken glitch that duplicates anything, and the many places poison water is located in Breath of the Wild.

In the video above, we cover 16 facts, tips and tricks that aren’t quite as well known, ranging from secrets to glitches that are pretty simple and others that are fairly complex. The Legend of Zelda: Breath of the Wild has been out for five years at this point, and players have found some amazing things, intended or not, that keep the game and its sense of discovery feeling fresh.

0:00 Intro
0:12 Bow Sight Aiming
0:51 Inventory Slot Transfer
1:53 Blocking Your Cooking
2:24 Remembering NPC's Names
2:39 Map Is Sometimes Updated
3:02 Cheese Your Way Over Electrified Metal
3:15 Chuchu Categorization
3:54 Secret Ancient Weapon Boosting Gear
4:27 Secret Wolf Link Boosting Trick
5:09 Teba's Bow Holster
5:30 Bolson's Logo On Everything
5:46 Races Run At Different Speeds
6:06 Throwing Bug
6:24 How Puddles Work
6:43 The Forgotten Surf Up Modifier
7:05 The Poison Water Secret
8:09 Outro

#botw #gaming


# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Arcade (Loving You is a Losing Game) | @itsduncanlaurence | funk cover ft. Kenton Chen & Beck Pete
 - [https://www.youtube.com/watch?v=Zj0_aKbkWXM](https://www.youtube.com/watch?v=Zj0_aKbkWXM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2022-07-04 00:00:00+00:00

Come see us July 9th in Los Angeles! https://www.grandperformances.org/events/scary-pockets

Store: https://www.scarypocketsfunk.com
Patreon: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Duncan Laurence's "Arcade (Loving You is a Losing Game)" by Scary Pockets, Kenton Chen & Beck Pete.

MUSICIAN CREDITS
Lead vocal: Kenton Chen & Beck Pete
Drums: The Pocket Queen
Bass: Hagar Ben Ari
Keys: Charles Cornell
Organ: Charles Jones
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Craig Polasko

VIDEO CREDITS
DP: Alejandro Echevarria
Editor: Adam Kritzberg

Recorded Live at East West Studios in Los Angeles, CA.

#ScaryPockets #Funk #duncanlaurence #beckpete #kentonchen


# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## “Hang on, CIVIL WAR now?!” This is alarming.
 - [https://www.youtube.com/watch?v=QHF2srZrwoM](https://www.youtube.com/watch?v=QHF2srZrwoM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-07-04 00:00:00+00:00

Happy Independence Day! But as a new poll shows 44% of Americans believe the nation is headed toward another civil war, is the country more divided than ever? 
#independenceday #4thofjuly #civilwar #celebration 

References
https://danielpinchbeck.substack.com/p/is-civil-war-inevitable?utm_source=%2Fprofile%2F2728693-daniel-pinchbeck&utm_medium=reader2
--------------------------------------------------------------------------------------------------------------------------
Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## You KNEW Something Wasn't Right
 - [https://www.youtube.com/watch?v=F7BMO9YGzVI](https://www.youtube.com/watch?v=F7BMO9YGzVI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-07-03 00:00:00+00:00

Something is very wrong with corporate media. On my latest podcast I spoke with Batya Ungar-Sargon, author of “Bad News: How Woke Media Is Undermining Democracy” about the reasons corporate media doesn't represent ordinary people. 
#cnn #foxnews #msnbc 
--------------------------------------------------------------------------------------------------------------------------
Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Wow, Stranger Things Got Good
 - [https://www.youtube.com/watch?v=OLoToWBbbAU](https://www.youtube.com/watch?v=OLoToWBbbAU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-07-04 00:00:00+00:00

Somehow, Stranger Things managed to recover from the decline its been in for the past couple of seasons, and actually became really good again. Join me as I investigate why.

Want to help support this channel? 
Check out my books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8/ref=dp_byline_cont_pop_ebooks_1
Subscribe on Patreon: https://www.patreon.com/TheCriticalDrinker
Subscribe on Subscribestar: https://www.subscribestar.com/the-critical-drinker


# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Infections, transatlantic surge
 - [https://www.youtube.com/watch?v=tvzbdcTft7g](https://www.youtube.com/watch?v=tvzbdcTft7g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-07-12 00:00:00+00:00

US, Back to behavioural normal, No public health measures

South and West

Population level immunity is driving viral evolution, fast

BA.5

Antibodies from vaccination and infection offer little protection against infection

https://www.washingtonpost.com/health/2022/07/10/omicron-variant-ba5-covid-reinfection/?utm_campaign=wp_to_your_health&utm_medium=email&utm_source=newsletter&wpisrc=nl_tyh

BA.2.75, next after BA.5

Cases, flat, 100,000 per day

Infections, up, perhaps 1 million per day

Hospitalizations, up, 0.6% on the week

Deaths, flat

CDC, stay up to date on vaccines, 

and take appropriate precautions to protect themselves and others

UK covid infections

https://health-study.joinzoe.com/data

Cases, + 348,001

(Proportionate, 1 million new infections per day in the US)

Currently covid symptomatic, 4,296,603

UK data

https://coronavirus.data.gov.uk

Infections, up

Hospitalizations, up

Deaths, down

UKHSA

https://bidstats.uk/tenders/2022/W24/776667357

Requirement for the ongoing supply of additional Lateral Flow Testing and Polymerase Chain Reaction Kits

£ 2, 000, 000, 000 













Lord Kamall, health minister

https://www.telegraph.co.uk/news/2022/07/12/covid-measures-could-return-rising-cases-worsen-nhs-backlog/

If current increase in hospital admissions is affecting the backlog

clearly measures may well have to be introduced

Current data does not point to cases becoming more severe

but also what we have managed to do is break the link 

between infections and hospitalisations, 

and hospitalisations and death

If that gets out of control then of course we will stand up the measures that we have previously

Ziyad Al-Aly, epidemiologist, Washington University St. Louis

There are no public health measures at all 

We’re in a very peculiar spot, where the risk is vivid and it’s out there, 

but we’ve let our guard down and we’ve chosen, deliberately, to expose ourselves and make ourselves more vulnerable

https://www.researchsquare.com/article/rs-1749502/v1

Multiple infections have a higher cumulative risk of a severe illness or death

Reinfections may be mild

any coronavirus infection carries risk, and the risk of a really bad outcome — a heart attack, for example — builds cumulatively

I worry that by the time we have a vaccine for BA.5 we’ll have a BA.6 or a BA.7. 

This virus keeps outsmarting us

Mercedes Carnethon, epidemiologist, Northwestern University Feinberg School of Medicine

It feels as though everyone has given up

zero covid not plausible

Harlan Krumholz, Yale University professor of medicine

Percentage of people with severely debilitating symptoms is probably 1 to 5%

North Korea

North Korea suggests ‘alien things’ from the South brought Covid.

Coronavirus entered on foreign objects from South Korea

Started in villages near border, after touched “alien things.”

State Emergency Epidemic Prevention Headquarters

vigilantly deal with alien things

brought across the border by balloons, wind other climate phenomena

All objects to be reported

After two years of claiming to have no Covid cases, North Korea 

Declared a maximin emergency on May 12

Cases, 4.7 million (Covid-like symptoms)

Deaths, 73 (June 15)

New infections, 4,570 on Friday, (down from 390,000 mid-May)


# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Ólafur Arnalds - Full Performance
 - [https://www.youtube.com/watch?v=Wu5jrFhn0pU](https://www.youtube.com/watch?v=Wu5jrFhn0pU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-13 00:00:00+00:00

http://KEXP.ORG presents Ólafur Arnalds performing live in the KEXP studio. Recorded June 9, 2022.

Songs:
Happiness Does Not Wait
momentary
saman
We Contain Multitudes

Ólafur Arnalds - Piano
Pétur Björnsson - Violin
Sólveig Vaka Eyþórsdóttir - Violin
Karl Pestka - Viola
Unnur Jónsdóttir - Cello

Host: Cheryl Waters
Audio Engineers: Terence Goodchild & Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://olafurarnalds.com
http://kexp.org

## Ólafur Arnalds - Happiness Does Not Wait (Live on KEXP)
 - [https://www.youtube.com/watch?v=f5Ox2ACjAYw](https://www.youtube.com/watch?v=f5Ox2ACjAYw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-13 00:00:00+00:00

http://KEXP.ORG presents Ólafur Arnalds performing “Happiness Does Not Wait” live in the KEXP studio. Recorded June 9, 2022.

Ólafur Arnalds - Piano
Pétur Björnsson - Violin
Sólveig Vaka Eyþórsdóttir - Violin
Karl Pestka - Viola
Unnur Jónsdóttir - Cello

Host: Cheryl Waters
Audio Engineers: Terence Goodchild & Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://olafurarnalds.com
http://kexp.org

## Ólafur Arnalds - We Contain Multitudes (Live on KEXP)
 - [https://www.youtube.com/watch?v=DdPQtEGZUaE](https://www.youtube.com/watch?v=DdPQtEGZUaE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-13 00:00:00+00:00

http://KEXP.ORG presents Ólafur Arnalds performing “We Contain Multitudes” live in the KEXP studio. Recorded June 9, 2022.

Ólafur Arnalds - Piano
Pétur Björnsson - Violin
Sólveig Vaka Eyþórsdóttir - Violin
Karl Pestka - Viola
Unnur Jónsdóttir - Cello

Host: Cheryl Waters
Audio Engineers: Terence Goodchild & Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://olafurarnalds.com
http://kexp.org

## Ólafur Arnalds - momentary / saman (Live on KEXP)
 - [https://www.youtube.com/watch?v=c6JpIJgPjdA](https://www.youtube.com/watch?v=c6JpIJgPjdA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-13 00:00:00+00:00

http://KEXP.ORG presents Ólafur Arnalds performing “momentary" and "saman” live in the KEXP studio. Recorded June 9, 2022.

Ólafur Arnalds - Piano
Pétur Björnsson - Violin
Sólveig Vaka Eyþórsdóttir - Violin
Karl Pestka - Viola
Unnur Jónsdóttir - Cello

Host: Cheryl Waters
Audio Engineers: Terence Goodchild & Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://olafurarnalds.com
http://kexp.org

## Allison Russell - 4th Day Prayer (Live on KEXP)
 - [https://www.youtube.com/watch?v=MC5cyIMNjlw](https://www.youtube.com/watch?v=MC5cyIMNjlw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-12 00:00:00+00:00

http://KEXP.ORG presents Allison Russell performing “4th Day Prayer” live in the KEXP studio. Recorded June 19, 2022.

Allison Russell - Vocals / Banjo / Clarinet
Larissa Maestro - Cello / Vocals
Ganessa James - Bass / Vocals
Mandy Fer - Guitar / Vocals
Elizabeth Goodfellow - Drums / Vocals

Host: Gabriel Teodros
Audio Engineers: Ross Collier & Julian Martlew
Audio Mixer: Ross Collier
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Ettie Wahl
Editor: Jim Beckmann

https://allisonrussellmusic.com
http://kexp.org

## Allison Russell - All Of The Women (Live on KEXP)
 - [https://www.youtube.com/watch?v=pvxFekHwJXc](https://www.youtube.com/watch?v=pvxFekHwJXc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-12 00:00:00+00:00

http://KEXP.ORG presents Allison Russell performing “All Of The Women” live in the KEXP studio. Recorded June 19, 2022.

Allison Russell - Vocals / Banjo / Clarinet
Larissa Maestro - Cello / Vocals
Ganessa James - Bass / Vocals
Mandy Fer - Guitar / Vocals
Elizabeth Goodfellow - Drums / Vocals

Host: Gabriel Teodros
Audio Engineers: Ross Collier & Julian Martlew
Audio Mixer: Ross Collier
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Ettie Wahl
Editor: Jim Beckmann

https://allisonrussellmusic.com
http://kexp.org

## Allison Russell - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=HD2HOdwEY_w](https://www.youtube.com/watch?v=HD2HOdwEY_w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-12 00:00:00+00:00

http://KEXP.ORG presents Allison Russell performing live in the KEXP studio. Recorded June 19, 2022.

Songs:
Hy-Brasil / Quasheba, Quasheba
4th Day Prayer
All Of The Women
Nightflyer

Allison Russell - Vocals / Banjo / Clarinet
Larissa Maestro - Cello / Vocals
Ganessa James - Bass / Vocals
Mandy Fer - Guitar / Vocals
Elizabeth Goodfellow - Drums / Vocals

Host: Gabriel Teodros
Audio Engineers: Ross Collier & Julian Martlew
Audio Mixer: Ross Collier
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Ettie Wahl
Editor: Jim Beckmann

https://allisonrussellmusic.com
http://kexp.org

## Allison Russell - Hy-Brasil / Quasheba, Quasheba (Live on KEXP)
 - [https://www.youtube.com/watch?v=prNgzxIgx8s](https://www.youtube.com/watch?v=prNgzxIgx8s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-12 00:00:00+00:00

http://KEXP.ORG presents Allison Russell performing “Hy-Brasil" and "Quasheba, Quasheba” (originally recorded by Our Native Daughters) live in the KEXP studio. Recorded June 19, 2022.

Allison Russell - Vocals / Banjo / Clarinet
Larissa Maestro - Cello / Vocals
Ganessa James - Bass / Vocals
Mandy Fer - Guitar / Vocals
Elizabeth Goodfellow - Drums / Vocals

Host: Gabriel Teodros
Audio Engineers: Ross Collier & Julian Martlew
Audio Mixer: Ross Collier
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Ettie Wahl
Editor: Jim Beckmann

https://allisonrussellmusic.com
http://kexp.org

## Allison Russell - Nightflyer (Live on KEXP)
 - [https://www.youtube.com/watch?v=6RCDJsTRUhc](https://www.youtube.com/watch?v=6RCDJsTRUhc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-12 00:00:00+00:00

http://KEXP.ORG presents Allison Russell performing “Nightflyer” live in the KEXP studio. Recorded June 19, 2022.

Allison Russell - Vocals / Banjo / Clarinet
Larissa Maestro - Cello / Vocals
Ganessa James - Bass / Vocals
Mandy Fer - Guitar / Vocals
Elizabeth Goodfellow - Drums / Vocals

Host: Gabriel Teodros
Audio Engineers: Ross Collier & Julian Martlew
Audio Mixer: Ross Collier
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Ettie Wahl
Editor: Jim Beckmann

https://allisonrussellmusic.com
http://kexp.org


## How to do a Feeds Reboot to take back control of your algorithms - The Verge
 - [https://www.theverge.com/23191292/control-social-algorithms-feeds-reboot-how-to](https://www.theverge.com/23191292/control-social-algorithms-feeds-reboot-how-to)
 - RSS feed: https://www.theverge.com
 - date published: 2022-07-12 00:29:12.646017+00:00

Step one: make sure you still want to follow everything you follow.


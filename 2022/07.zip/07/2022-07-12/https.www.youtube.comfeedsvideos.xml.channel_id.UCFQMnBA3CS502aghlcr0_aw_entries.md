# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Billion Dollar Bankruptcy Gets WORSE
 - [https://www.youtube.com/watch?v=uZYMtVBXUrE](https://www.youtube.com/watch?v=uZYMtVBXUrE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2022-07-13 00:00:00+00:00

this is probably illegal and Mark Cuban is a terrible crypto investor. 
Voyager is a crypto broker that recently went bust, filed for chapter 11 bankruptcy and customers are worried about their money. I'm here to breakdown what Voyager did, why it matters and why what they're doing might not fly in court. 
Follow Coffeezilla: 
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
Credits: 
3D Artist: Ed Leszczynski https://twitter.com/LeszczynskiEd
Video Editor: Harry Bagg  https://twitter.com/HarryRBagg
Virtual Production Software: Aximmetry https://aximmetry.com/

This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.


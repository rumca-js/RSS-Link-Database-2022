# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## MASSIVE Changes coming to the Quest 2 and VR! GOODBYE FACEBOOK!
 - [https://www.youtube.com/watch?v=ySfgZOGr27s](https://www.youtube.com/watch?v=ySfgZOGr27s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-07-12 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news! Today we have some very good news regarding Oculus devices and software no longer requiring a linked Facebook account! but- that's not the whole story, Facebook accounts are replaced with Meta and Horizon accounts and you HAVE to do it before Jan 1 2023. Interesting. Also a cancelled Halo VR project from 343, Quest Pro news, and a new Quest 2 update (V42). All that and so much more! Hope you enjoy this week of VR news! 


MY OUTRO MUSIC:
https://youtu.be/u6JwgNQDVfI

MY LINKS:
Discord:
https://discord.gg/2hCGM9BYez
Twitch:
https://www.twitch.tv/thrilluwu
Twitter:
https://twitter.com/Thrilluwu
Patreon:
https://www.patreon.com/Thrillseeker


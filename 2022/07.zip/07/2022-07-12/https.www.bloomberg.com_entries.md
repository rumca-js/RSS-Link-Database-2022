## WeChat Is China’s Most Beloved (and Feared) Surveillance Tool
 - [https://www.bloomberg.com/news/features/2022-07-12/wechat-is-china-s-beloved-surveillance-tool?leadSource=uverify%20wall](https://www.bloomberg.com/news/features/2022-07-12/wechat-is-china-s-beloved-surveillance-tool?leadSource=uverify%20wall)
 - RSS feed: https://www.bloomberg.com
 - date published: 2022-07-12 15:58:01+00:00

WeChat Is China’s Most Beloved (and Feared) Surveillance Tool


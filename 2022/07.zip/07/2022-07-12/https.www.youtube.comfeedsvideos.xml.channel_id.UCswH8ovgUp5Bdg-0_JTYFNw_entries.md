# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## NEW TRUCKERS PROTEST?? This Is Impossible To Ignore
 - [https://www.youtube.com/watch?v=JMo6bdiv1Gg](https://www.youtube.com/watch?v=JMo6bdiv1Gg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-07-13 00:00:00+00:00

This week I spoke to activist Vandana Shiva about the Dutch farmers and how the mainstream media have framed their protests over new ecological regulations.
#vandanashiva #protest #farmersprotest #netherlands #srilanka 

Register for The Free Prescreening of ‘The Seeds Of Vandana Shiva’ here: https://core.live/movies/the-seeds-of-vandana-shiva

Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Psychedelics - Did You Know THIS?!
 - [https://www.youtube.com/watch?v=cNmusuWg9vA](https://www.youtube.com/watch?v=cNmusuWg9vA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-07-12 00:00:00+00:00

This week I spoke with Nicolas Glynos - Vice President of the Student Association for Psychedelic Studies / Co-founder of Psychedelic Neuroscience & Therapy for the University of Michigan & His work on DMT.
--------------------------------------------------------------------------------------------------------------------------
Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


# Source:The Guardian, URL:https://www.theguardian.com/rss, language:en-UK

## ‘Blows my mind’: first full-colour image of ancient galaxies – video
 - [https://www.theguardian.com/us-news/video/2022/jul/12/blows-my-mind-first-full-colour-image-of-ancient-galaxies-video](https://www.theguardian.com/us-news/video/2022/jul/12/blows-my-mind-first-full-colour-image-of-ancient-galaxies-video)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2022-07-12 04:18:54+00:00

<p>US president Joe Biden has revealed the first image from Nasa’s new space telescope, the deepest view of the cosmos ever captured. The first image from the $10bn James Webb space telescope shows the farthest humanity has ever seen in both time and distance, closer to the dawn of the universe, one million miles into the cosmos. 'First of all, that blows my mind,' Biden said. The world’s biggest and most powerful space telescope was launched into space last December from French Guiana in South America</p><ul><li><a href="https://www.theguardian.com/science/2022/jul/11/nasa-james-webb-telescope-ancient-galaxy-images">First images from Nasa’s James Webb space telescope reveal ancient galaxies</a></li></ul> <a href="https://www.theguardian.com/us-news/video/2022/jul/12/blows-my-mind-first-full-colour-image-of-ancient-galaxies-video">Continue reading...</a>


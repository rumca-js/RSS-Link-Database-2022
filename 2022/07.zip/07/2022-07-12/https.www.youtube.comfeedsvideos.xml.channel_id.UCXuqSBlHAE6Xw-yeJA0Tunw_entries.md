# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This Ugly PC will BLOW YOUR MIND - All Noctua Gaming PC
 - [https://www.youtube.com/watch?v=TFE9wfAfudE](https://www.youtube.com/watch?v=TFE9wfAfudE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-07-13 00:00:00+00:00

Thanks to Mine for sponsoring this video! Discover where your data is, and take it back at https://bit.ly/saymineLTT

PDQ.com: Start your FREE trial now! At https://lmg.gg/PDQJuly

Asus teamed up with Noctua to release the best and brownest 30 series cards – and to celebrate, we stuffed as many of their fans as possible in one PC build! 

Discuss on the forum: https://linustechtips.com/topic/1443009-this-ugly-pc-will-blow-your-mind/

Buy a Cooler Master H500 ARGB: https://geni.us/p2yEkS9
Buy a Noctua NF-A20 PWM: https://geni.us/e0lB
Buy a Noctua NH-D15 Chromax: https://geni.us/AlETc4
Buy a Noctua NF-A12x25 PWM:https://geni.us/YxMDv5S

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:34 Case and fan install
6:16 Motherboard and PSU 
9:20 CPU and RAM
10:34 Linus Paint Tips
11:02 Noctua story time
12:04 PC comes together
13:06 Big GPU!
15:13 1st boot and peripherals
16:34 Play some games
17:58 Outro

## You Can Build a PC Again!
 - [https://www.youtube.com/watch?v=Sb-rh8kj1CE](https://www.youtube.com/watch?v=Sb-rh8kj1CE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-07-12 00:00:00+00:00

It's been two years since you could reasonably build a gaming computer, but it's finally time! 
On this Prime Day, we build a computer!... we hope...

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/linus

Save 10% off your Ridge KeyCase and get Free Worldwide Shipping by using offer code LINUS at https://www.ridge.com/LINUS

Buy a CPU on Amazon: https://geni.us/sSSS
Buy a GPU on Amazon: https://geni.us/puu5j
Buy a Motherboard on Amazon: https://geni.us/HBUTU
Buy a PC Case on Amazon: https://geni.us/HzcJlQ
Buy RAM on Amazon: https://geni.us/9cxcf
Buy a PSU on Amazon: https://geni.us/HxpRHpD
Buy an SSD on Amazon: https://geni.us/5UL37

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech


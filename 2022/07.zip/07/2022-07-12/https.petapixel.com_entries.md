## Photographer Documents All 12,795 Items That She Owns | PetaPixel
 - [https://petapixel.com/2022/07/08/photographer-documents-all-12795-items-that-she-owns/](https://petapixel.com/2022/07/08/photographer-documents-all-12795-items-that-she-owns/)
 - RSS feed: https://petapixel.com
 - date published: 2022-07-12 12:58:04.693691+00:00

That's a lot of stuff.


# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Ksiądz gra w grę || A Plague Tale: Innocence [02] Wyśmiewana wiara
 - [https://www.youtube.com/watch?v=byX8Pkuhrfc](https://www.youtube.com/watch?v=byX8Pkuhrfc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-13 00:00:00+00:00

​@Langustanapalmie    #ksiadzgrawgre #ksiądzgrawgrę #aplaguetaleinnocence 

________________________________________
NIENASYCENI 
☞ Tauron Arena Kraków
☞ 6 października 2022 r. 

BILETY ☞ https://bit.ly/Nienasyceni_Tauron
WYDARZENIE ☞ https://fb.me/e/1WzTzhC1Q
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Judyty || Rozdział 02
 - [https://www.youtube.com/watch?v=6GAMUULFzAE](https://www.youtube.com/watch?v=6GAMUULFzAE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-13 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## NIESZCZĘŚNI [#03] Ściana
 - [https://www.youtube.com/watch?v=ey74ueB1qag](https://www.youtube.com/watch?v=ey74ueB1qag)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-13 00:00:00+00:00

PIĄTKOWA seria w środę, czyli przypomnienie i seria dla NIESZCZĘSNYCH.
[ Iz 38, 1-22 ] 
W owych dniach Ezechiasz zachorował śmiertelnie. Prorok Izajasz, syn Amosa, przyszedł do niego i rzekł mu: "Tak mówi Pan: Rozporządź domem twoim, bo umrzesz i nie będziesz żył". Wtedy Ezechiasz odwrócił się do ściany i modlił się do Pana. A mówił tak: "Ach, Panie, wspomnij na to, proszę, że postępowałem wobec Ciebie wiernie i z doskonałym sercem, że czyniłem to, co miłe oczom Twoim". I płakał Ezechiasz bardzo rzewnie. Wówczas Pan skierował do Izajasza słowo tej treści: «Idź, by oznajmić Ezechiaszowi: Tak mówi Pan, Bóg Dawida, twego praojca: Słyszałem twoją modlitwę, widziałem twoje łzy. Uzdrowię cię. Za trzy dni pójdziesz do świątyni Pańskiej. Oto dodam do twego życia piętnaście lat. Wybawię ciebie i to miasto z ręki króla asyryjskiego i roztoczę opiekę nad tym miastem». [Izajasz odrzekł:] "Niech ci będzie ten znak od Pana, że spełni On tę rzecz, którą przyrzekł: Oto ja cofnę cień [wskazówki zegarowej] o dziesięć stopni, po których słońce już zeszło na [słonecznym] zegarze Achaza". I cofnęło się słońce o dziesięć stopni, po których już zeszło.
Pieśń Ezechiasza, króla judzkiego, gdy popadł w chorobę, ale został z niej uzdrowiony: Mówiłem: W połowie moich dni muszę odejść; w bramach Szeolu odczuję brak reszty lat moich! Mówiłem: Nie ujrzę już Pana na ziemi żyjących, nie będę już patrzył na nikogo spośród mieszkańców tego świata. Mieszkanie me rozbiorą i przeniosą ode mnie jak namiot pasterzy. Zwijam jak tkacz moje życie. On mnie odcina od nici. Za dzień i jedną noc mnie zamęczysz. Krzyczę aż do rana. On kruszy jak lew wszystkie me kości: (w ciągu dnia i jednej nocy mnie zamęczysz). Jak pisklę jaskółcze, tak kwilę, wzdycham jak gołębica. Oczy me słabną patrząc ku górze. Panie, cierpię ucisk: Stań przy mnie! Cóż mam mówić? Wszak On mi powiedział i On to sprawił. Przeżyję spokojnie wszystkie moje lata po chwilach goryczy mej duszy. Nad którymi Pan czuwa, ci żyją, wśród nich dopełni się życie ducha mego. Uzdrowiłeś mnie i żyć dozwoliłeś! Oto na zdrowie zamienił mi gorycz. Ty zachowałeś mą duszę od dołu unicestwienia, gdyż poza siebie rzuciłeś wszystkie moje grzechy. Zaiste, nie Szeol Cię sławi ani Śmierć wychwala Ciebie; nie ci oglądają się na Twoją wierność, którzy w dół zstępują. Żywy, żywy Cię tylko wysławia, tak jak ja dzisiaj. Ojciec dzieciom rozgłasza Twoją wierność. Pan mnie zachowuje! Więc grać będziemy me pieśni na strunach przez wszystkie dni naszego życia w świątyni Pańskiej. Powiedział też Izajasz: "Weźcie placek figowy i przyłóżcie do wrzodu, a zdrów będzie!" Ezechiasz zaś rzekł: "Jaki znak upewni mię, że wejdę do świątyni Pańskiej?"

Zdjęcia i montaż: Marcin Jończyk.
Palec w kadrze: Palec Boży

________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#1143] Mdłości
 - [https://www.youtube.com/watch?v=XuBiPy9YRe4](https://www.youtube.com/watch?v=XuBiPy9YRe4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-13 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
NIENASYCENI 
☞ Tauron Arena Kraków
☞ 6 października 2022 r. 

BILETY ☞ https://bit.ly/Nienasyceni_Tauron
WYDARZENIE ☞ https://fb.me/e/1WzTzhC1Q
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Judyty || Rozdział 01
 - [https://www.youtube.com/watch?v=HQ_G_2B5Q0w](https://www.youtube.com/watch?v=HQ_G_2B5Q0w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-12 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## NIESZCZĘŚNI [#02] Pustka
 - [https://www.youtube.com/watch?v=xH_exTWK2a4](https://www.youtube.com/watch?v=xH_exTWK2a4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-12 00:00:00+00:00

Piątkowa seria we WTOREK na kanale @Langustanapalmie .

[ Łk 6, 20-26 ]
A On podniósł oczy na swoich uczniów i mówił: «Błogosławieni jesteście wy, ubodzy, albowiem do was należy królestwo Boże. Błogosławieni wy, którzy teraz głodujecie, albowiem będziecie nasyceni. Błogosławieni wy, którzy teraz płaczecie, albowiem śmiać się będziecie. Błogosławieni będziecie, gdy ludzie was znienawidzą, i gdy was wyłączą spośród siebie, gdy zelżą was i z powodu Syna Człowieczego podadzą w pogardę wasze imię jako niecne: cieszcie się i radujcie w owym dniu, bo wielka jest wasza nagroda w niebie. Tak samo bowiem przodkowie ich czynili prorokom. Natomiast biada wam, bogaczom, bo odebraliście już pociechę waszą. Biada wam, którzy teraz jesteście syci, albowiem głód cierpieć będziecie. Biada wam, którzy się teraz śmiejecie, albowiem smucić się i płakać będziecie. Biada wam, gdy wszyscy ludzie chwalić was będą. Tak samo bowiem przodkowie ich czynili fałszywym prorokom.

Zdjęcia i montaż: Marcin Jończyk.

________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#1142] W bagnie
 - [https://www.youtube.com/watch?v=NOsy3KlhSI4](https://www.youtube.com/watch?v=NOsy3KlhSI4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-12 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
NIENASYCENI 
☞ Tauron Arena Kraków
☞ 6 października 2022 r. 

BILETY ☞ https://bit.ly/Nienasyceni_Tauron
WYDARZENIE ☞ https://fb.me/e/1WzTzhC1Q
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.


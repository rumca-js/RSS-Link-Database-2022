# Source:Moon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg, language:en-US

## Why Disney Is Collapsing: The Coming Disney Crisis
 - [https://www.youtube.com/watch?v=Ps34BrekZds](https://www.youtube.com/watch?v=Ps34BrekZds)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg
 - date published: 2022-07-12 00:00:00+00:00

Get 15% off your purchase at Galaxy Lamps with code ‘moon’: https://galaxylamps.co/moon

🟢 Get exclusive access for my private unfiltered controversial videos that can't be released to the public: https://www.youtube.com/c/Moon-Real/join

Support the channel here (all money goes straight back into the channel):
►  Become a Patron:  https://www.patreon.com/MoonReal
► Follow my Twitter: https://twitter.com/MoonRealYT


Disney is worse than you thought. The Disney business model is collapsing making Disney trash and its why Disney is bad. Disney is now losing money, losing it's stock price, and struggling to make profits. Because Disney went woke. This is the rise and fall of Disney.This is why Disney is collapsing and is causing a coming crisis for Disney's business. This video will be analyse Disney stock crash, there stock market predictions, why Disney isn't making money.


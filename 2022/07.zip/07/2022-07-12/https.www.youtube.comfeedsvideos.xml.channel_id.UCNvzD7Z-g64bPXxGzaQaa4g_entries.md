# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Elden Ring: 10 NEW Things Players Have Discovered
 - [https://www.youtube.com/watch?v=3Q_Z7ABFo0w](https://www.youtube.com/watch?v=3Q_Z7ABFo0w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-07-13 00:00:00+00:00

Elden Ring (PC, PS5, PS4, Xbox Series X/S/One) is an incredible game that is still surprising people months after release. Here are some incredible discoveries made by fans.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Top 20 NEW Games of 2022 [Second Half]
 - [https://www.youtube.com/watch?v=WLXQQjHTE9I](https://www.youtube.com/watch?v=WLXQQjHTE9I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-07-12 00:00:00+00:00

The second half of 2022 is bringing tons of new game releases for PC, PS5, PS4, Xbox Series X/S/One, and Nintendo Switch. Here's everything big we're looking forward to.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:25 Evil West 
1:14 High on Life 
2:00 The Lord of the Rings: Gollum 
2:51 Stray
3:36 Marvel's Midnight Suns 
4:22 Skull and Bones 
5:08 Splatoon 3
5:36 Saints Row 
6:25 Pokémon Scarlet and Violet 
6:57 Atomic Heart 
7:33 Overwatch 2 
8:06 Xenoblade Chronicles 3 
8:42 Scorn 
9:32 Call of Duty: Modern Warfare II
10:14 Gotham Knights 
11:24 Crisis Core: FFVII Reunion 
12:03 The Callisto Protocol 
12:45 A Plague Tale: Requiem 
13:28 Hogwarts Legacy
14:24 God of War
15:22 BONUS


20 Evil West 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : September 20, 2022  



19 High on Life 

Platform : PC Xbox One XSX|S

Release Date : October 25, 2022 



18 The Lord of the Rings: Gollum 

Platform : PC PS4 PS5 Xbox One XSX|S September 1, 2022

Release Date : Switch ( Late 2022) 



17 Stray

Platform : PC PS4 PS5 

Release Date : 19 July 2022      



16 Marvel's Midnight Suns 

Platform : PC PS4 PS5 Xbox One XSX|S October 7, 2022

Release Date : Switch TBA 



15 Skull and Bones 

Platform : PC PS5 XSX|S STADIA LUNA

Release Date : November 8,  2022 



14 Splatoon 3

Platform : Switch 

Release Date : September 9, 2022 



13 Saints Row 

Platform : PC PS4 PS5 Xbox One XSX|S

Release Date : August 23, 2022 



12 Pokémon Scarlet and Violet 

Platform : Switch 

Release Date : November 18, 2022 



11 Atomic Heart 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : Q4, 2022 



10 Overwatch 2 

Platform : Switch PC PS4 PS5 Xbox One XSX|S 

Release Date : October 4, 2022 



9 Xenoblade Chronicles 3 

Platform : Switch 

Release Date : July 29, 2022  



8 Scorn 

Platform : PC XSX|S 

Release Date : 21 October 2022  



7 Call of Duty: Modern Warfare II

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : October 28, 2022  



6 Gotham Knights 

Platform : PC PS5 XSX|S 

Release Date : October 25, 2022  



5 Crisis Core: FFVII Reunion 

Platform : Switch PC PS4 PS5 Xbox One XSX|S 

Release Date : Late 2022



4 The Callisto Protocol 

Platform : PC PS4 PS5 Xbox One XSX|S 

December 2, 2022 



3 A Plague Tale: Requiem 

A Plague Tale: Requiem 

Platform : PC XSX|S PS5 (Switch cloud)

Release Date : Release Date : October 18, 2022 



2 Hogwarts Legacy

Platform : PC PS4 PS5 Xbox One XSX|S Switch 

Release Date : Q4 2022 



1 God of War

Platform : PS4 PS5 

Release Date : November 9, 2022 



BONUS 

The Last of Us Part I 

Platform : PS5 September 2, 2022 

Release Date : PC TBA 



Sons of the Forest 

Platform : PC 

Release Date : Oct 2022



Sonic Frontiers 

Platform : PC PS4 PS5 Xbox One XSX|S Switch 

Release Date : Q4 2022  



Outlast Trials 

Platform : PC 

Release Date : 2022 



Soul Hackers 2

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : August 26, 2022


# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## What It's Like Being a Sheep!
 - [https://www.youtube.com/watch?v=CMoStzUrSto](https://www.youtube.com/watch?v=CMoStzUrSto)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-07-12 00:00:00+00:00

Grab your Nootropics at https://nootopia.com/jp Use Code "AWAKEN" For a Deal

Check out my Freedom Merch here - https://awakenwithjp.com/shop

My NEW Reaction Channel - https://www.youtube.com/channel/UCbb5jNoRlRQ1UBjO_7fF_Iw

Upcoming LIVE shows - https://awakenwithjp.com/tour

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Here's what it's like being a sheep in today's world!

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com


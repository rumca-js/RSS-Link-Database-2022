# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## Cool & Unusual Tech Deals: Amazon Prime Day 2022 - IT'S OVER, YA BLEW IT
 - [https://www.youtube.com/watch?v=Rs2rY5J6HVY](https://www.youtube.com/watch?v=Rs2rY5J6HVY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2022-07-12 00:00:00+00:00

Amazon Links (Affiliate):
• 30 Day Free Trial: https://amzn.to/3h6gDrB
• Students 6 Month Trial: Use above link, then click "Are You a Student?"

🡇 Amazon Devices 🡇
• Amazon Echo Dot (4th Gen): https://amzn.to/3O2HCCw
• Amazon Echo (4th Gen): https://amzn.to/3RnCGv7
• Kindle Paperwhite 8GB: https://amzn.to/3O3sWTZ
• Kindle Paperwhite Signature: https://amzn.to/3yzNSMC
• Kindle Oasis: https://amzn.to/3PliFDn
• Ring Video Doorbell 4: https://amzn.to/3IzgutJ

🡇 Cool Tech Deals 🡇
• Apple TV 4K: https://amzn.to/3uFH136
• Elgato Stream Deck: https://amzn.to/3atX657
• Logitech G502: https://amzn.to/3ogCG2N
• Spectra479 Blue Blocking Glasses: https://amzn.to/3P7po4q
• Inateck USB 3.2 Gen2 Hub: https://amzn.to/3z1PfVR
• Stealtho Chair Wheels: https://amzn.to/3P5gioB
• Gooloo GT4000 Jump Starter: https://amzn.to/3uEJ7zV

🡇 Unusual or Specialty Tech Deals 🡇
• GVM RGB Lights (2 Pack): https://amzn.to/3Iyn6IU
• Nix Mini 2 Color Sensor: https://amzn.to/3RqBlDI
• Nix Pro 2 Color Sensor: https://amzn.to/3RuAOAx
• Fluke MT-8200 Cable Tester: https://amzn.to/3auObQU

🡇 Higher Ticket Items 🡇
• Roomba i7+ Robot Vacuum: https://amzn.to/3aw4PPS
• Roborock Q5+ Robot Vacuum: https://amzn.to/3v6jd8P
• LG 34GP83A Gaming Monitor: https://amzn.to/3z383nD

Note: The links above are Amazon affiliate links, which means I'll probably get a small (usually ~1-2%) commission that helps support the channel if you decide to buy the item. The commission does not come out of your pocket, but rather from Amazon's.

▼ Time Stamps: ▼
0:00 - Intro
0:34 - IMPORTANT Tips
1:46 - Amazon Devices
3:07 - Good & Cool Deals
5:05 - Unusual But Cool Gadgets
6:39 - Higher Ticket Items
7:55 - More Ideas


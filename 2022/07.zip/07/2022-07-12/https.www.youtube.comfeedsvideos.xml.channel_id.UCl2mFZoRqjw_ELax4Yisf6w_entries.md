# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## BMW charging 18/mo for heated seats - cars implementing subscription based microtransactions
 - [https://www.youtube.com/watch?v=qJdwbWc-n7g](https://www.youtube.com/watch?v=qJdwbWc-n7g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-07-12 00:00:00+00:00

https://www.motor1.com/news/597376/bmw-heated-seats-subscription/amp/

🔵 We fix Macbooks & offer free estimates. https://rossmanngroup.com
🔵 Send us your Macbook for repair! http://bit.ly/sendmacbook
🔵 We'll send you a box with a pre-paid shipping label for your repair! http://bit.ly/sendyourmacbook
🔵 We offer iPhone data recovery: http://bit.ly/2BDBX4G
🔵 We offer lab hard drive data recovery: http://bit.ly/labdatarecovery

👉 LEARN HOW TO DO THIS:
› In-person classes: https://bit.ly/classrg
› Beginner's guide: http://bit.ly/2k6uz84
› Support forum: $29/mo http://bit.ly/boardrepairforum

👉 CHIPS & COMPONENTS:
› http://bit.ly/2jaAOXM

👉 TOOLS USED:
✓ Soldering Irons:
› Louis' Hakko station(no tweezers): http://amzn.to/2cKkMyO 
› Paul's Hakko station(works with tweezers): http://amzn.to/2yMvWNy
› Micro Soldering Pencil: http://amzn.to/2d5MWUP
› Hot tweezers: http://amzn.to/2yMvZsZ
› Atten ST-862D hot air station with bent nozzles: https://bit.ly/atten862

✓ CHEAP HAKKO ALTERNATIVES:
› TS100 soldering iron: https://amzn.to/2Gy1Fqz
› Recommended tips: TS-C4: https://amzn.to/33s3jpW TS-KU https://amzn.to/2QsKT36

✓ Preferred Soldering Tips
› Fine: http://amzn.to/2d5MgPn 
› Flat: https://amzn.to/2JnsDBT 
› GPU wicking: http://amzn.to/2w8chtB
› Micro soldering tip: http://amzn.to/2qUSFDh

✓ Microscopes:
› Microscope: http://amzn.to/2iLrE16 
› Barlow lens: http://amzn.to/2yMKdKf
› LED light: http://amzn.to/2nzfPT2
› CHEAP alternative microscope: http://amzn.to/2rTlHbj

✓ Soldering/Repair Supplies:
› Solder: http://amzn.to/2cKkxUp
› Desoldering braid: http://bit.ly/2otflOX
› Flux: http://bit.ly/amtechflux
› Solder paste: http://bit.ly/amtechsolderpaste
› THICK insulated jumper wire: https://amzn.to/2rvtD0A
› THIN insulated jumper wire: https://amzn.to/2I47DQY
› Kapton tape: http://amzn.to/2yN0xuq
› Tweezers: http://amzn.to/2d5NBpi
› Blades: http://amzn.to/2ByWnvF
› Freeze Spray: http://amzn.to/2BySozw
› Conformal coating: http://bit.ly/greencoate
› Conformal coating curing pen: http://bit.ly/uvpen

✓ Diagnostic tools:
› USB amp meter: http://bit.ly/2B2Lu5W
› USB-C amp meter: http://bit.ly/usbcamp
› On-Screen multimeter: http://amzn.to/2jtgY9K 
› Multimeter Probes: http://bit.ly/fineprobes
› CHEAP multimeter: http://amzn.to/2zjkg8U
› Bench PSU: CSI3005P http://bit.ly/benchsupply
› Phoneboard: https://phoneboard.co
› Boardview software: https://pldaniels.com/flexbv/

✓ Ultrasonic Cleaning:
› ALL MACBOOKS & CELLPHONES: Crest P1200H-45: https://amzn.to/2ITSQdw
› PRE-TOUCHBAR MACBOOKS & CELLPHONES: Crest P500H-45: https://amzn.to/2Qrnhf8
› CELLPHONES ONLY: Crest P230H-45: https://amzn.to/2QsckKG
› Branson EC cleaning fluid: http://amzn.to/2cKlBrp

✓ Desk supplies:
› Desk: http://amzn.to/2yMShdZ
› Chair: https://amzn.to/2LB8bUB
› Fume Extractor: http://amzn.to/2d5MGoD
› Work mat: http://amzn.to/2yMtlTR
› Outlets: http://amzn.to/2yNsZwo
› Gloves: http://amzn.to/2iUfumS
› Durable lightning cable: http://amzn.to/2yNHzUt
› Fine tipped snippers: http://amzn.to/2HGt4XB

✓ Screwdrivers: 
› iPhone bottom screw: http://amzn.to/2yNwX8p
› Macbook bottom screw: http://amzn.to/2AKMdVb
› Torx T3: http://amzn.to/2zjtxxH
› Torx T5 http://amzn.to/2BLNDn4
› Torx T6 http://amzn.to/2B0XIfA
› Torx T8 http://amzn.to/2CpWp68
› Phillips #0: http://amzn.to/2AJaHhM
› Phillips #000: http://amzn.to/2yNqsCl

✓ RECORDING EQUIPMENT:
› Work cam: https://amzn.to/2QjHnt0
› Overhead cam: http://amzn.to/2eAH0oT
› Work mic: https://amzn.to/2WGIhzw
› Home mic: https://amzn.to/2xfampC
› Microscope camera: http://amzn.to/2icVQoG - mine is DISCONTINUED, closest one I can find. 
› HDMI capture: http://amzn.to/2iyGcle

👉 Discord: https://tinyurl.com/rossmatrix

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## Q&A w/ billionaire alt-tech investor/philanthropist Eron Wolf
 - [https://www.youtube.com/watch?v=OJPmbcU-Vzo](https://www.youtube.com/watch?v=OJPmbcU-Vzo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-07-12 00:00:00+00:00

FUTO Grant Program - https://futo.org/grants
FUTO Twitter - https://twitter.com/FUTO_Tech
FUTO Youtube channel - https://www.youtube.com/channel/UCIBNAd4nO5rk6G8YaEudqNw
FUTO Odysee - https://odysee.com/@FUTO:e
FUTO Minds - https://www.minds.com/futo/
FUTO Rokfin - https://rokfin.com/futo

00:00 - Intro 
00:42 - What is FUTO? Issues w/ big tech.  
07:34 - FUTO grant's program & open source projects 
11:25 - Thoughts on free market & libertarianism. 
14:55 - Principles of FUTO 
18:54 -  Political bias censoring in search
20:46 - Silicon Valley politics 
22:41 - Donations as a form of payment
24: 21 - Ads. 
24:49 - Digital Bill of Rights? 
25:45 - Balancing censorship & free speech? 
27:24 - Should coding be taught in schools?
28:03 - The future of quality, usable open source code. 
30:55 - Plantation business model
32:04 - Biggest mistake new companies & investors make?
33:03 - Is it possible for a decentralized, transparent project to be profitable? 
35:32 - Limits to intellectual property.
39:03 - Rob Braxman, privacy, degoogling phones.
41:04 - How did he earn the money to fund his projects? 
45:33 - How do people know that they can trust you? 
46:45 - IP discussion
49:08 - Starving artists 
49:51 - Nice Amigas
50:21 - Software vendor locks/subscription models
52:20 - Do you love the Raspberry Pi? 
53:21 - What can people locked into proprietary software do to support free software?
54:28 - Tabs or spaces? 
55:14 - Do you oppose software as a service altogether? i.e. photoshop
56:15 - How did you become aware of this channel/Right to Repair? 
57:05 - More on driving hard for privacy-oriented, open source phones and computers. 
59:08 - Apple on Right to Repair.
1:00:30 - PinePhone. 
1:01:34 - SaaS; cable TV subscription? 
1:01:50 - Paying for service is sometimes more annoying than piracy. 
1:04:20 - FSFE asking vendors be forced to open source firmware of end of life products
1:05:01 - ​Is it feasible to have algorithms which are transparent on sites like YouTube instead of this black box nobody properly understands? 
1:07:22 - But if YouTube’s algorithm was well known, everyone would exploit it.
1:08:08 - When was the last time you used a soldering iron? 
1:08:30 - What does FUTO stand for? 
1:08:49 - Thoughts on Framework. 
1:10:17 - Do you lift bro?
1:11:06 - ​What's one of your own FOSS projects that you’re particularly proud to have contributed code to? 
1:12:28 ​-Is the grant program open internationally? 
1:12:54 - Would Eron be interested in funding a FOSS project aiming to give back control of our most personal devices (smartphones) to the owners?
1:13:29 - What type of device would you like to see some company make an open repairable version of that doesn’t?
1:15:18 - Thought about doing minor grants, by posting reviews/lists/videos of software and uses they are good for? 
1:16:10 - What would be the ideal grant application to send in? What type of projects would get you the most excited?
1:17:01 - What is your preference for development operating system, IDE/editor and development language, or are you quite dynamic with your choice of tools to use? 
1:18:42 - You are OK with crypto, but do not want a project to be specifically tailored to a specific cryptocurrency.
1:20:38 - How long do you think copyright should last, if at all? 
1:21:33 - Would you support the battle to prevent meta/google/Nvidia-from having full control of the people who prefer VR to IRL?
1:22:42 - Do you believe governments foreign or domestic are influencing the direction companies are taking?
1:23:41 - What are your motivations for wanting to make the future better through creating open source software, vs buying a yacht? 
1:25:16 - Is there any future for modern computers without an IME? 
1:26:49 - Do you ever feel like you’re fighting a lost cause? 
1:28:12 - What can the general public do to prevent Silicon Valley from having so much control? 
1:29:18 - What do you think of having Microsoft as the root of trust for all SecureBoot and UEFI shims? Could a more open-system be run by say the Electronic Frontier Foundation or Free Software Foundation? 
1:30:31 - Is Eron paying Blizzard a WoW subscription, or using private Ascension servers? 
1:32:07 - How monolithic is the culture in Silicon Valley? 
1:33:13 - Thoughts on EFF.
​1:34:47 - Future of privacy, w/ asymmetric encryption likely to be broken soon with quantum computing? Govt could easily log every encrypted email not and decrypt in 5 years.
1:35:39 - Is TikTok a national security concern, & should it be banned? 
1:37:23 - How much financial success is determined by making the right choices, luck, or the family you are born into?
1:38:31 - Would you make a fundraiser site that is nonpartisan? Should crowdfunding platforms should be partisan? 
1:39:35 - Why shouldn’t we trust you?
1:39:58 - The homeless issue in California. 
1:41:12 - Outro!


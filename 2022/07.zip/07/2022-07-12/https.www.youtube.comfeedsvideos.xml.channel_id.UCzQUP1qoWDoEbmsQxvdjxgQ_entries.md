# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Paul Virzi's Dad Spotted a UFO in 1973
 - [https://www.youtube.com/watch?v=_TXH2QMoErE](https://www.youtube.com/watch?v=_TXH2QMoErE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-07-13 00:00:00+00:00

Taken from JRE #1843 w/Paul Virzi:
https://open.spotify.com/episode/3mBQbdt03bBJ1jY14Ff3Y1?si=1d1ad364d3b04446

## Reminiscing About Baseball's Steroid Era
 - [https://www.youtube.com/watch?v=s732OfLMorc](https://www.youtube.com/watch?v=s732OfLMorc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-07-13 00:00:00+00:00

Taken from JRE #1843 w/Paul Virzi:
https://open.spotify.com/episode/3mBQbdt03bBJ1jY14Ff3Y1?si=1d1ad364d3b04446

## Andrew Huberman on the Similarities in Brain Chemistry Between Mating and Aggression
 - [https://www.youtube.com/watch?v=kTqt_3YJBbs](https://www.youtube.com/watch?v=kTqt_3YJBbs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-07-12 00:00:00+00:00

Taken from JRE #1842 w/Andrew Huberman:
https://open.spotify.com/episode/2BGyj7ukaq8aA29BsA1Yuk?si=7694806046a64a8a


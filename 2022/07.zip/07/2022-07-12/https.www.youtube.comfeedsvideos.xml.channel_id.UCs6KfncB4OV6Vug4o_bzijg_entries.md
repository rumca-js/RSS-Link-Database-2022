# Source:Techlore, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCs6KfncB4OV6Vug4o_bzijg, language:en-US

## I’m Leaving Custom ROMs - Here’s Why.
 - [https://www.youtube.com/watch?v=LJXFqM2OC1Q](https://www.youtube.com/watch?v=LJXFqM2OC1Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCs6KfncB4OV6Vug4o_bzijg
 - date published: 2022-07-12 18:58:33+00:00

Here's why I (reluctantly) ditched my custom ROM for Stock Android! 
Threat Modeling Video: https://youtu.be/DHZRhboZhfI

As stressed in the video: This is part of my own personal journey and isn't necessarily a recommendation for all of you.

🔐 Our Website: https://techlore.tech
✉️ Techlore Dispatch & Blog: https://dispatch.techlore.tech
🕵 Go Incognito Course: https://techlore.tech/goincognito
📹 Odysee: https://odysee.com/@techlore:3
📹 PeerTube: https://tilvids.com/c/techlore_channel/videos

Connect with others in the privacy community:
💻 Our Forum: https://discuss.techlore.tech
Ⓜ️ Mastodon: https://mastodon.social/@techlore
👾 Discord: https://discord.techlore.tech

Support our mission to spread privacy to the masses:
💖 All Support Methods: https://techlore.tech/support
🧡 Patreon: https://www.patreon.com/techlore
🪙 Monero: 49H4jTvUY5zaX8qLpVBstJFR7ayTMxxU3UyWpGqUoBM4UzM2zwUHA2sJ9i3AhQYdaqhFmS8PDfWKn1Tea4SKU6haMTXG8qD

00:00 How I got here
00:52 First reason for switching
03:01 Second reason for switching
05:00 Third reason for switching
06:19 'But what about privacy concerns?'
06:38 'So do you still recommend ROMs?!'
#privacy #android #security


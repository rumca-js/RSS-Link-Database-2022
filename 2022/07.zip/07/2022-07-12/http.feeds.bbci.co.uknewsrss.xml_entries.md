# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Joe Biden heads to Middle East amid faltering US sway
 - [https://www.bbc.co.uk/news/world-middle-east-62133978?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-62133978?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 23:58:15+00:00

The US president's visit to the turbulent region may highlight the limits of American power.

## 'Flying my parrot is a reason to go out'
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-62063539?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-62063539?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 23:23:37+00:00

Chloe Brown has taught her harlequin macaw how to free fly in locations including the Peak District.

## CEO Secrets: How one company attracts more men
 - [https://www.bbc.co.uk/news/business-62120936?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62120936?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 23:15:11+00:00

Mary Ellen Iskenderian, president and CEO of non-profit organisation Women's World Banking, shares her business advice.

## Former airline worker: 'It would be like going back to an ex'
 - [https://www.bbc.co.uk/news/business-61830479?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61830479?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 23:13:05+00:00

Three people who used to work in aviation up until the Covid pandemic discuss whether they would return to the industry.

## Ukraine's rock warrior Slava Vakarchuk: 'We need to be angry'
 - [https://www.bbc.co.uk/news/world-europe-62137767?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62137767?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 23:05:27+00:00

Slava Vakarchuk is the lead singer of Okean Elzy, Ukraine's most popular rock band.

## Cost of living: The family who gave up a car to cycle every day
 - [https://www.bbc.co.uk/news/uk-wales-62136814?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-62136814?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 22:06:34+00:00

Lindsay, Simon and their two daughters say they've saved up to £400 a month by ditching their car.

## Euro 2022: Germany win Group B and move into quarter-finals with 2-0 win over Spain
 - [https://www.bbc.co.uk/sport/football/62126847?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62126847?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 21:27:57+00:00

Eight-time European champions Germany defeat Spain to secure top spot in Group B and avoid a Euro 2022 quarter-final tie with England.

## Euro 2022: Pernille Harder scores as Denmark beat Finland to keep hopes of progress alive
 - [https://www.bbc.co.uk/sport/football/62125687?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62125687?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 21:09:26+00:00

Pernille Harder's second-half goal ensures Denmark keep their hopes of progressing from Group B alive as they beat a determined Finland at Euro 2022.

## Euro 2022: Denmark's Lene Christensen pulls off match-winning save against Finland
 - [https://www.bbc.co.uk/sport/av/football/62139740?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/62139740?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 18:55:06+00:00

Watch Denmark's Lene Christensen pull off a remarkable save to help secure a 1-0 win against Finland at Euro 2022.

## Emmys 2022: Succession leads US TV award nominations
 - [https://www.bbc.co.uk/news/entertainment-arts-62140086?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62140086?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 18:09:05+00:00

The show leads the race for the US TV awards, with nominations for both Brian Cox and Jeremy Strong.

## Telford child sex abuse went on for generations, inquiry finds
 - [https://www.bbc.co.uk/news/uk-england-shropshire-61983584?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-shropshire-61983584?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 17:29:35+00:00

Agencies blamed children and not perpetrators for the abuse suffered in Telford, the report says.

## James Webb: Nasa space telescope delivers spectacular pictures
 - [https://www.bbc.co.uk/news/science-environment-62140044?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-62140044?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 15:31:40+00:00

A "stellar nursery" and a "cosmic dance" are among James Webb's first batch of colour images.

## Ukraine war: Iran plans to supply Russia with drones, US warns
 - [https://www.bbc.co.uk/news/world-us-canada-62130725?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62130725?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 07:58:54+00:00

A top US official says Iran is preparing to send weapons-capable drones to Russia for use in Ukraine.

## Speed limit to be lowered to 20mph in Wales
 - [https://www.bbc.co.uk/news/uk-wales-62020427?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-62020427?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 07:48:00+00:00

It is claimed Wales could be world's first nation to adopt a 20mph default limit in built-up areas.

## Train drivers very close to going on strike, union warns
 - [https://www.bbc.co.uk/news/business-62132711?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62132711?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 07:46:50+00:00

Aslef boss Mick Whelan says a walk-out could happen within weeks if pay talks with management fail.

## Sir Mo Farah reveals he was trafficked to the UK as a child
 - [https://www.bbc.co.uk/news/uk-62123886?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62123886?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 07:23:57+00:00

The Olympic star says the name Mohamed Farah was given to him by a stranger who flew him to the UK.

## Euro 2022: Why England fans are right to get excited - but players must stay grounded after 8-0 win
 - [https://www.bbc.co.uk/sport/football/62129143?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62129143?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 07:10:00+00:00

England's stunning performance against Norway rightly made fans excited but the players must remain focused as they prepare for the quarter-finals of the Euros.

## Shinzo Abe: Japanese mourners pay last respects to ex-PM at funeral
 - [https://www.bbc.co.uk/news/world-asia-62130794?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-62130794?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 06:55:05+00:00

Thousands showed up to pay their last respects to Japan's longest-serving prime minister.

## Manchester United and Frenkie de Jong: Senior club figures in Barcelona to break impasse
 - [https://www.bbc.co.uk/sport/football/62131753?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62131753?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 05:38:20+00:00

Senior Manchester United figures Richard Arnold and John Murtough are in Barcelona trying to break the impasse over the club's pursuit of Dutch midfielder Frenkie De Jong.

## Gary Speed: Wales manager's mother talks about his death
 - [https://www.bbc.co.uk/news/uk-wales-62053440?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-62053440?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 05:22:49+00:00

The mum of the former Wales football boss opens up more than a decade after he took his own life.

## Champions League: Witnesses raise new questions about chaos of Paris final
 - [https://www.bbc.co.uk/news/world-europe-62120782?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62120782?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 05:03:12+00:00

A BBC probe into the issues at the Stade de France hears evidence that contradicts French authorities.

## SAS killings: How a scandal was uncovered
 - [https://www.bbc.co.uk/news/uk-62083197?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62083197?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 05:00:34+00:00

Panorama brought a series of suspicious killings of civilians to light, after four years of detective work.

## SAS reports reveal troubling pattern of suspicious deaths in Afghanistan
 - [https://www.bbc.co.uk/news/uk-62083196?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62083196?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 05:00:17+00:00

Internal emails seen by the BBC show top special forces officers were aware of concerns over killings.

## The Papers: Sunak's tax pledge and Mo Farah revelations
 - [https://www.bbc.co.uk/news/blogs-the-papers-62130103?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-62130103?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 04:58:34+00:00

Expected tax cut vows by Rishi Sunak and Mo Farah's revelation that he was smuggled to the UK feature on the front pages.

## Roe v Wade: Abortion pills a new front in culture wars
 - [https://www.bbc.co.uk/news/world-us-canada-61973510?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-61973510?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 01:56:57+00:00

Abortion pills - the most common way to end pregnancies in the US - are in activists' crosshairs.

## Sri Lanka: Opposition leader ready to run for presidency
 - [https://www.bbc.co.uk/news/world-asia-62126321?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-62126321?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 01:01:49+00:00

Sajith Premadasa tells the BBC he plans to run for the presidency, after urgent talks with allies.

## Sex assault victims warn about home massage dangers
 - [https://www.bbc.co.uk/news/uk-62081247?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62081247?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 00:34:28+00:00

The BBC has spoken to women who say they were sexually assaulted during massage treatments.

## Sally Phillips on daring to star in a sex comedy film
 - [https://www.bbc.co.uk/news/entertainment-arts-62080757?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62080757?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 00:28:22+00:00

The actress on playing a woman who starts an all-male house cleaning business - with extras.

## The Big Plastic Count: Survey shows 'recycling doesn't work'
 - [https://www.bbc.co.uk/news/science-environment-62126757?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-62126757?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-12 00:19:32+00:00

Organisers estimate the UK throws out nearly 100 billion pieces of plastic each year.


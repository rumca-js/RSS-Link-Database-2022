# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Dosh - Mr. Rogers
 - [https://www.youtube.com/watch?v=L2UhSQgiD-Q](https://www.youtube.com/watch?v=L2UhSQgiD-Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-07-13 00:00:00+00:00

Minneapolis musician Martin Dosh performs an unreleased song called "Mr. Rogers" for The Current's LineCheck series.

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

## Craig Finn — three songs from 'A Legacy of Rentals' at The Current
 - [https://www.youtube.com/watch?v=3niiaK9kSZs](https://www.youtube.com/watch?v=3niiaK9kSZs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-07-12 00:00:00+00:00

After releasing "A Legacy of Rentals" — his fifth solo album — in May of this year, Craig Finn is now on tour in support of the record. His first show took place at the Turf Club in St. Paul on June 28, and on that day, Finn and his band The Uptown Controllers visited The Current studio for a session hosted by Ayisha Jaffer. Watch the songs Craig Finn and the Uptown Controllers performed in that session.  

Songs Performed
00:00 The Amarillo Kid
04:42 Birthdays
07:56 Due To Depart

Personnel
Craig Finn – vocals
Paul “Falcon" Valdez – drums
Patrick Doyle – guitar
Joseph Faught – bass
Nelson Devereaux – saxophone

Credits
Host – Ayisha Jaffer
Guest – Craig Finn 
Technical director – Evan Clark
Producer – Derrick Stevens
Digital producer – Luke Taylor 

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#craigfinn #steadycraig #thecurrent

## Dosh - If U Strike Me Down (Live for LineCheck)
 - [https://www.youtube.com/watch?v=lFo-73_RipY](https://www.youtube.com/watch?v=lFo-73_RipY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-07-12 00:00:00+00:00

Minneapolis musician Martin Dosh performs "If U Strike Me Down" from his 2021 album "Tomorrow 1972" for The Current's LineCheck series.

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

## Poliça - interview with Diane on The Local Show
 - [https://www.youtube.com/watch?v=vwH8ulAVdAo](https://www.youtube.com/watch?v=vwH8ulAVdAo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-07-12 00:00:00+00:00

Minneapolis art-pop band Poliça are known for innovation, forward-thinking artistry, and novel electronic soundscapes. The 11-year-old band’s new record, "Madness," takes them a step forward into the creative realm with producer Ryan Olson’s new anthropomorphic production tool AllOvers. Originally created as an art installation for the Massachusetts Museum of Contemporary Art with the help of sound artist Seth Rossetter, AllOvers was designed to ingest sounds, including conversations and environmental noise, and turn them into melodies and/or beats.

Not long after the release of "Madness," Poliça — Channy Leaneagh, vocals; Chris Bierden, bass; and Ben Ivascu and Drew Christopherson, drums — visited The Current studio for a session on The Local Show hosted by Diane. Watch the complete interview with the band, above. 

Host – Diane
Guest –Poliça 
Technical director – Evan Clark 
Producer – Jesse Wiza 
Digital producer – Luke Taylor

This activity is made possible in part by the Minnesota Legacy Amendment's Arts & Cultural Heritage Fund.
 
You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#poliça #thisispolica #thelocalshow


# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## END OF THE ECLIPSE - Berserk Vol. 13 [Part 1]
 - [https://www.youtube.com/watch?v=hVBPJrk_D0k](https://www.youtube.com/watch?v=hVBPJrk_D0k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-07-13 00:00:00+00:00

The end of the Eclipse! #berserk 
Berserk Deluxe Edition 5 - Vol 13, which includes the chapters:
"Storm of Death 1-2", "God of the Abyss", "Lifeblood", "Quickening", "Birth", "Afterglow of the Right Eye",  and "Escape". 

New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  


P.O. Box: PO Box 7874 Henrico, VA 23231

## The Law ~ Dresden Files REVIEW
 - [https://www.youtube.com/watch?v=DvqXi2r-Zkw](https://www.youtube.com/watch?v=DvqXi2r-Zkw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-07-12 00:00:00+00:00

My thoughts on the latest Dresden Files entry, The Law! 


New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene


Merch: https://www.designbyhumans.com/shop/FantasyNews/ 


Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p


Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  


P.O. Box: PO Box 7874 Henrico, VA 23231


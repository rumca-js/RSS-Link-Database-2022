# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## How streaming videos gives a Danish city hot water
 - [https://www.bbc.co.uk/news/technology-62076634?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62076634?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-07-12 15:59:30+00:00

A datacentre is cooling its servers while providing nearby residents with heating.

## Hands-on with the Nothing 1 phone
 - [https://www.bbc.co.uk/news/technology-62140444?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62140444?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-07-12 15:29:28+00:00

UK company Nothing's first handset features hundreds of LED lights and has had 200,000 pre-orders.


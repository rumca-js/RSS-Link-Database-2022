# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Rare Americans - Koncert (MUZO.FM)
 - [https://www.youtube.com/watch?v=UPQHeJaLMqk](https://www.youtube.com/watch?v=UPQHeJaLMqk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2022-07-13 00:00:00+00:00

Rare Americans na żywo w MUZO.FM. Zespół wykonał w naszym studiu wyjątkowe wersje utworów: Milk Man z płyty Rare Americans 2, Baggage z albumu Jamesy Boy & The Screw Loose Zoo i  z płyty Rare Americans. 

 0:00 Milk Man
 3:05 Baggage
 5:48 Balmoral Hotel

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Rare Americans: http://www.facebook.com/rareamericans
Instagram Rare Americans: http://www.instagram.com/rareamericans/
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm

## Rare Americans - Balmoral Hotel - live MUZO.FM
 - [https://www.youtube.com/watch?v=6k6WWTtUId0](https://www.youtube.com/watch?v=6k6WWTtUId0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2022-07-12 00:00:00+00:00

Rare Americans - Balmoral Hotel na żywo w MUZO.FM. Utwór pochodzi z debiutanckiej płyty zespołu zatytułowanej Rare Americans. 


Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Rare Americans: http://www.facebook.com/rareamericans
Instagram Rare Americans: http://www.instagram.com/rareamericans/
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


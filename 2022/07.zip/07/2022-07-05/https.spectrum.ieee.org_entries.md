## Today’s Robotic Surgery Turns Surgical Trainees Into Spectators - IEEE Spectrum
 - [https://spectrum.ieee.org/robotic-surgery](https://spectrum.ieee.org/robotic-surgery)
 - RSS feed: https://spectrum.ieee.org
 - date published: 2022-07-05 19:41:49.219146+00:00

Medical training in the robotics age leaves residents short on skills


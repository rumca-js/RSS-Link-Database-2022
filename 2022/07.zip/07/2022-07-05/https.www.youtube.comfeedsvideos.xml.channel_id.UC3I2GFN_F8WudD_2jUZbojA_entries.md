# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Yann Tiersen - 11 5 18  1 12  12 15 3 8 (Live on KEXP)
 - [https://www.youtube.com/watch?v=N9dgKp94wT4](https://www.youtube.com/watch?v=N9dgKp94wT4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-06 00:00:00+00:00

http://KEXP.ORG presents Yann Tiersen performing “11 5 18  1 12  12 15 3 8” live in the KEXP studio. Recorded June 13, 2022.

Yann Tiersen - Modular Synth / Octatrack
Jens Thomsen - MPC / Effects
Emilie Tiersen - Vocals

Host: Evie
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.yanntiersen.com
http://kexp.org

## Yann Tiersen - 13 1 18 25 6 5 1 20  17 21 9 14 17 21 9 19 (Live on KEXP)
 - [https://www.youtube.com/watch?v=h7rAaAWoFmM](https://www.youtube.com/watch?v=h7rAaAWoFmM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-06 00:00:00+00:00

http://KEXP.ORG presents Yann Tiersen performing “13 1 18 25 6 5 1 20  17 21 9 14 17 21 9 19 (feat. QUINQUIS)” live in the KEXP studio. Recorded June 13, 2022.

Yann Tiersen - Modular Synth / Octatrack
Jens Thomsen - MPC / Effects
Emilie Tiersen - Vocals

Host: Evie
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.yanntiersen.com
http://kexp.org

## Yann Tiersen - 16 15 21 12 12  2 15 10 5 18 (Live on KEXP)
 - [https://www.youtube.com/watch?v=A9HtDaMF0O4](https://www.youtube.com/watch?v=A9HtDaMF0O4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-06 00:00:00+00:00

http://KEXP.ORG presents Yann Tiersen performing “16 15 21 12 12  2 15 10 5 18” live in the KEXP studio. Recorded June 13, 2022.

Yann Tiersen - Modular Synth / Octatrack
Jens Thomsen - MPC / Effects
Emilie Tiersen - Vocals

Host: Evie
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.yanntiersen.com
http://kexp.org

## Yann Tiersen - 3 8 1 16 20 5 18  14 9 14 5 20 5 5 14 (Live on KEXP)
 - [https://www.youtube.com/watch?v=h-smwbA1zig](https://www.youtube.com/watch?v=h-smwbA1zig)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-06 00:00:00+00:00

http://KEXP.ORG presents Yann Tiersen performing “3 8 1 16 20 5 18  14 9 14 5 20 5 5 14” live in the KEXP studio. Recorded June 13, 2022.

Yann Tiersen - Modular Synth / Octatrack
Jens Thomsen - MPC / Effects
Emilie Tiersen - Vocals

Host: Evie
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.yanntiersen.com
http://kexp.org

## Yann Tiersen - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=pxTm2csHjSk](https://www.youtube.com/watch?v=pxTm2csHjSk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-06 00:00:00+00:00

http://KEXP.ORG presents Yann Tiersen performing live in the KEXP studio. Recorded June 13, 2022.

Songs:
16 15 21 12 12. 2 15 10 5 18
13 1 18 25  (6 5 1 20. 17 21 9 14 17 21 9 19)
11 5 18. 1 12. 12 15 3 8
3 8 1 16 20 5 18. 14 9 14 5 20 5 5 14

Yann Tiersen - Modular Synth / Octatrack
Jens Thomsen - MPC / Effects
Emilie Tiersen - Vocals

Host: Evie
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.yanntiersen.com
http://kexp.org

## Making Movies - Delilah (Live on KEXP)
 - [https://www.youtube.com/watch?v=vL7VF5zkdFM](https://www.youtube.com/watch?v=vL7VF5zkdFM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-05 00:00:00+00:00

http://KEXP.ORG presents Making Movies performing “Delilah” live in the KEXP studio. Recorded June 14, 2022.

Enrique Chi - Guitar / Vocals
Diego Chi - Bass / Vocals
Juan-Carlos Chaurand - Percussion / Keyboard / Vocals
Duncan Burnett - Drums

Host: Chilly
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://www.ilovelucius.com
http://kexp.org

## Making Movies - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=daUqwQC9JUs](https://www.youtube.com/watch?v=daUqwQC9JUs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-05 00:00:00+00:00

http://KEXP.ORG presents Making Movies performing live in the KEXP studio. Recorded June 14, 2022.

Songs:
Delilah
Sala De Los Pecadores
Porcelina
XOPA

Enrique Chi - Guitar / Vocals
Diego Chi - Bass / Vocals
Juan-Carlos Chaurand - Percussion / Keyboard / Vocals
Duncan Burnett - Drums

Host: Chilly
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://www.ilovelucius.com
http://kexp.org

## Making Movies - Porcelina (Live on KEXP)
 - [https://www.youtube.com/watch?v=lwZTgqS5Ivw](https://www.youtube.com/watch?v=lwZTgqS5Ivw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-05 00:00:00+00:00

http://KEXP.ORG presents Making Movies performing “Porcelina” live in the KEXP studio. Recorded June 14, 2022.

Enrique Chi - Guitar / Vocals
Diego Chi - Bass / Vocals
Juan-Carlos Chaurand - Percussion / Keyboard / Vocals
Duncan Burnett - Drums

Host: Chilly
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://www.ilovelucius.com
http://kexp.org

## Making Movies - Sala De Los Pecadores (Live on KEXP)
 - [https://www.youtube.com/watch?v=rok-BgdGNyA](https://www.youtube.com/watch?v=rok-BgdGNyA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-05 00:00:00+00:00

http://KEXP.ORG presents Making Movies performing “Sala De Los Pecadores” live in the KEXP studio. Recorded June 14, 2022.

Enrique Chi - Guitar / Vocals
Diego Chi - Bass / Vocals
Juan-Carlos Chaurand - Percussion / Keyboard / Vocals
Duncan Burnett - Drums

Host: Chilly
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://www.ilovelucius.com
http://kexp.org

## Making Movies - XOPA (Live on KEXP)
 - [https://www.youtube.com/watch?v=yrN0tySqeKg](https://www.youtube.com/watch?v=yrN0tySqeKg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-05 00:00:00+00:00

http://KEXP.ORG presents Making Movies performing “XOPA” live in the KEXP studio. Recorded June 14, 2022.

Enrique Chi - Guitar / Vocals
Diego Chi - Bass / Vocals
Juan-Carlos Chaurand - Percussion / Keyboard / Vocals
Duncan Burnett - Drums

Host: Chilly
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://www.ilovelucius.com
http://kexp.org


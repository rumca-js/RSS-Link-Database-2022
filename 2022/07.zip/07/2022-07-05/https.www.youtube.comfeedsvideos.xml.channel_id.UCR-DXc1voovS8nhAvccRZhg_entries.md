# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## They're using Raspberry Pis at the golf course now
 - [https://www.youtube.com/watch?v=xTo0j9H4i3Y](https://www.youtube.com/watch?v=xTo0j9H4i3Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2022-07-06 00:00:00+00:00

You never know where a Raspberry Pi will pop up! The driving range near my house is powered by a Pi now.

Support me on Patreon: https://www.patreon.com/geerlingguy
Sponsor me on GitHub: https://github.com/sponsors/geerlingguy
Merch: https://redshirtjeff.com
2nd Channel: https://www.youtube.com/c/GeerlingEngineering

#RaspberryPi #Golf


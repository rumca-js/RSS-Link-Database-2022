# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Suwalszczyzna - rowerem przez puszcze, góry i jeziora 🚴‍♂️💨 Wielka Podlaska Pętla Widokowa + Wigry
 - [https://www.youtube.com/watch?v=R9DsK2pxGrU](https://www.youtube.com/watch?v=R9DsK2pxGrU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2022-07-05 14:30:12+00:00

Książka "Rower to jest Świat" 👉 https://rowertojestswiat.pl/
Kurs filmowo-montażowy 👉 http://kursfilmowaniaimontazu.pl/

Suwalszczyzna był to najbardziej przeze mnie wyczekiwany wyjazd rowerowy tego lata.  Byłem tutaj nie raz, także z rowerem, ale nigdy nie przejechałem całej Suwalszczyzny. W końcu się udało czego efektem jest ten film pełen ciekawych miejsc na Suwalszczyźnie, ciekawostek o Suwalszczyźnie i pomysłów na Wasze własne wyjazdy. 

Odwiedzimy sobie Suwalski Park Krajobrazowy, który jest moim ulubionym miejscem na całym Podlasiu. Przejedziemy wzdłuż rzeki Czarna Hańcza, odwiedzimy Jezioro Hańcza, Mosty w Stańczykach (tak, wiem, że to już nie jest Suwalszczyzna!), a także wyskoczymy przez miasto Suwałki w kierunku Wigierskiego Parku narodowego, aby wokoło objechać Jezioro Wigry. Wszystko to oczywiście na rowerach.

►►Zachęcam do subskrypcji: http://bit.ly/2cmWbSO 

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

Muzyka : Nevaeh (na soundcloud) a także zasoby Artlist.

0:00 - Suwalszczyzna - ciekawe miejsca
1:22 - Dolina Czarnej Hańczy 
2:03 - głazowisko w Bachanowie
2:28 - wyjątkowe przejście dla pieszych
3:05 - jezioro w Turtulu
3:57 - kraina jeziorami słynąca
4:58 - Suwalski Park Krajobrazowy
5:46 - Góra Zamkowa
7:20 - Jezioro Hańcza
8:23 - jedyna taka rzecz w Europie Środkowej
8:49 - wschód Słońca nad Suwalszczyzną
9:23 - Puszcza Romincka
11:07 - wiadukty w Stańczykach
13:06 - Jezioro Wigry rowerem
17:13 - klasztor na środku jeziora
18:05 - Książka "Rower to jest świat"


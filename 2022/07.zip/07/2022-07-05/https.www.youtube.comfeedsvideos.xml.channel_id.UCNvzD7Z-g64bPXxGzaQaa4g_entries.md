# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Most DISAPPOINTING Games of 2022 [First Half]
 - [https://www.youtube.com/watch?v=msKOivZh8MU](https://www.youtube.com/watch?v=msKOivZh8MU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-07-06 00:00:00+00:00

2022 has already seen some great games, but we've also gotten plenty of misses. Here are the games that have disappointed us the most in this first half of the year.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro 
0:15 House of The Dead REMAKE
1:27 CHOCOBO GP
2:16 Vampire: The Masquerade - Swansong
3:34 Diablo Immortal
4:45 Dolmen
5:52 Dynasty Warriors 9 Empires
6:38 Babylon's Fall
7:57 CROSSFIRE X
9:47 Postal 4: No Regerts
11:05 Waifu Impact

## Starfield: 10 Things YOU NEED TO KNOW
 - [https://www.youtube.com/watch?v=Zu0V4oacsJU](https://www.youtube.com/watch?v=Zu0V4oacsJU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-07-05 00:00:00+00:00

Starfield (2023) is Bethesda's next big RPG following Skyrim and Fallout 4. Here's everything we know, as well as some speculation.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro 
0:23 HOW BIG?
2:20 BASE BUILDING
3:45 SHIP BUILDING
4:55 MORE SHIP INFO
6:01 FACTIONS
7:41 PERSUATION 
8:21 CHARACTER CREATION 
9:54 COMBAT 
11:38 COMPANIONS
12:46 GAME ENGINE, MOD SUPPORT, DLC


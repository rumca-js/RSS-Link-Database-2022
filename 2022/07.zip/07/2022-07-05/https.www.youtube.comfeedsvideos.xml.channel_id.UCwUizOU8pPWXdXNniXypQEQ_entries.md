# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Why We Need More Greta Thunberg
 - [https://www.youtube.com/watch?v=N7H_UZmaImA](https://www.youtube.com/watch?v=N7H_UZmaImA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-07-05 00:00:00+00:00

Grab your Black Out Sleep Mask at https://boncharge.com/jp Use Code "JP" for 15% Off!

Take a stand and get your Freedom Merch here - https://awakenwithjp.com/shop

My NEW Reaction Channel - https://www.youtube.com/channel/UCbb5jNoRlRQ1UBjO_7fF_Iw

Upcoming LIVE Shows - https://awakenwithjp.com/tour

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

You may be upset about how little Greta Thunberg you have been seeing lately. I'm here to change that with Greta Thunberg 2.0!

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
https://rumble.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com


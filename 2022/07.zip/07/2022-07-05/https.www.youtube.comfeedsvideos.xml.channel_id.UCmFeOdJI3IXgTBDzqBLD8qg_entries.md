# Source:Moon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg, language:en-US

## How Discord Changed Society Forever
 - [https://www.youtube.com/watch?v=xeJeyO7UeYo](https://www.youtube.com/watch?v=xeJeyO7UeYo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg
 - date published: 2022-07-06 00:00:00+00:00

🟢 Get exclusive access for my private unfiltered controversial videos that can't be released to the public: https://www.youtube.com/c/Moon-Real/join

Discord seems like just a simple app, but there's another side to Discord. A side that is truly disturbing..

Doxxing Server Part Taken From This Video: https://www.youtube.com/watch?v=0sWURjk8H6w&t=107s

Discord is an evil business and this video will explain everything bad about discord and why discord is bad. Discord is trash because it is damaging society by the way it makes money.
This is the dark side of discord. This is why this video will be exploring the dark of discord and discord's business model and how discord makes money through evil stuff. We will talk about Discord doxxing, discord mods, discord servers, discord stories, and Chris Chan.This is the discord iceberg.

Support the channel here (all money goes straight back into the channel):
►  Become a Patron:  https://www.patreon.com/MoonReal
► Follow my Twitter: https://twitter.com/MoonRealYT


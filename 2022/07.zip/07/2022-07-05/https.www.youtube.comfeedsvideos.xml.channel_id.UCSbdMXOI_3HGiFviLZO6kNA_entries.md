# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## VR’s BIGGEST Problem Right Now
 - [https://www.youtube.com/watch?v=5rZRvw7WTq8](https://www.youtube.com/watch?v=5rZRvw7WTq8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-07-05 00:00:00+00:00

Hello! Here is my analysis on VR game development and the industry right now. Turns out, VR Games are just RIDICULOUSLY hard to create- at least making a GOOD VR game. So many of the things that people have been relying on for decades just- don't apply to VR games. 

In my opinion right now the problem isn't that there aren't enough VR games, it's that VR game development cycles are so new and difficult. 

I spent the past year advising and working along side an indie VR game studio and learned a lot. 

Here is AEXLAB's game, VAIL:

It just entered closed beta, request access and join the discord:
Vail VR Steam: https://bit.ly/3NEiDFK
Vail VR Discord: https://bit.ly/3nrgFxD
TMG Casting Call: https://bit.ly/3I61HGL

My links:
MY LINKS:
Discord:
https://discord.gg/2hCGM9BYez
Twitch:
https://www.twitch.tv/thrilluwu
Twitter:
https://twitter.com/Thrilluwu
Patreon:
https://www.patreon.com/Thrillseeker


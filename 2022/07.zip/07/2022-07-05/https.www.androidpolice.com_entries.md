## Telegram reportedly surrendered user data to authorities despite insisting '0 bytes' had ever been shared
 - [https://www.androidpolice.com/telegram-germany-user-data-surrendered/](https://www.androidpolice.com/telegram-germany-user-data-surrendered/)
 - RSS feed: https://www.androidpolice.com
 - date published: 2022-07-05 06:44:28+00:00

Telegram reportedly surrendered user data to authorities despite insisting '0 bytes' had ever been shared


# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## Trying to Land a Plane (to Prove the Dunning-Kruger Effect)
 - [https://www.youtube.com/watch?v=2A7mblg5UKc](https://www.youtube.com/watch?v=2A7mblg5UKc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2022-07-06 00:00:00+00:00

SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub 
We’re on PATREON! Join the community https://www.patreon.com/itsokaytobesmart
↓↓↓ More info and sources below ↓↓↓

You may not be an expert, but perhaps you feel pretty confident that you could ride a motorcycle, or give someone a decent haircut - if you absolutely had to - right? Not so much, according to the psychological phenomenon known as the Dunning-Kruger Effect. Turns out we’re all at risk of being overconfident about something. Watch Joe put this theory to the test as he tries to land a 737 (in a simulator, of course). Oh, did we mention Joe's not a pilot?

References: https://sites.google.com/view/be-smart-dunning-kruger-effect/home 

-----------

Special thanks to our Brain Trust Patrons:

Mark Littlehale
Ali Freiburger
Mehdi Damou
Barbora Bei
Ken Board
Clinger-Hamilton Family
Attila Pix
Burt Humburg
Roy Lasris
dani bowman
David Johnston
Salih Arslan
Baerbel Winkler
Robert Young
Amy Sowada
Eric Meer
Dustin
Karen Haskell

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/


# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Three months in Russian captivity: How one Ukrainian got out
 - [https://www.cnn.com/videos/world/2022/07/05/ukraine-russian-captivity-paramedic-alex-marquardt-tsr-vpx.cnn](https://www.cnn.com/videos/world/2022/07/05/ukraine-russian-captivity-paramedic-alex-marquardt-tsr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-05 23:55:14+00:00

In her first interview since her release, a Ukrainian paramedic tells CNN's Alex Marquardt about her three months in Russian captivity.

## This is how the Akron police shooting of Jayland Walker unfolded
 - [https://www.cnn.com/videos/us/2022/07/05/jayland-walker-akron-police-timeline-lr-no-orig.cnn](https://www.cnn.com/videos/us/2022/07/05/jayland-walker-akron-police-timeline-lr-no-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-05 19:12:46+00:00

Jayland Walker suffered at least 60 wounds in a fatal shooting that occurred after Akron police attempted to stop him for traffic and equipment violations.

## Amanpour presses Hungarian FM on controversial response to Russia's invasion of Ukraine
 - [https://www.cnn.com/videos/tv/2022/07/05/amanpour-szijjrt.cnn](https://www.cnn.com/videos/tv/2022/07/05/amanpour-szijjrt.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-05 18:07:16+00:00

Christiane Amanpour speaks with Hungarian Foreign Minister Péter Szijjártó on Hungary's controversial response towards Russian aggression in Ukraine.

## Photographer shares powerful story behind this kiss
 - [https://www.cnn.com/style/article/dangelo-lovell-williams-photography-snap/index.html](https://www.cnn.com/style/article/dangelo-lovell-williams-photography-snap/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-05 18:05:15+00:00

As D'Angelo Lovell Williams posed for a kiss with a former partner, Glenn, in front of the camera, their faces each obscured by the black silk cloth of a backwards durag, the photographer had a famous painting in mind.

## Amber Heard's attorneys ask court to toss verdict in Johnny Depp defamation case
 - [https://www.cnn.com/2022/07/05/entertainment/johnny-depp-amber-heard-appeal/index.html](https://www.cnn.com/2022/07/05/entertainment/johnny-depp-amber-heard-appeal/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-05 18:02:26+00:00

Attorneys for Amber Heard have asked the court to throw out the verdict in the defamation trial with her ex husband Johnny Depp and either dismiss the case or order a new trial.

## See Penguin restart colony from scratch in Argentina
 - [https://www.cnn.com/videos/world/2022/06/28/penguin-colony-patagonia-desert-coast-origseriesfilms.cnn](https://www.cnn.com/videos/world/2022/06/28/penguin-colony-patagonia-desert-coast-origseriesfilms.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-05 17:16:45+00:00

There are thousands of Magellanic penguins in the El Pedral colony, said conservationist Popi García. Every spring these migratory waddlers return to breed. The new Original Series "Patagonia: Life on the Edge of the World" airs Sundays at 9 p.m. ET.

## Analysis: July 4 parade slaughter again shows nowhere is safe from America's mass killing contagion
 - [https://www.cnn.com/2022/07/05/politics/illinois-parade-mass-shooting-gun-violence-analysis/index.html](https://www.cnn.com/2022/07/05/politics/illinois-parade-mass-shooting-gun-violence-analysis/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-05 05:08:06+00:00

America's latest mass shooting turned a cherished July Fourth parade from a scene of patriotic joy into one of fear and death.

## Gunman fired on unsuspecting parade attendees from a rooftop, authorities say
 - [https://www.cnn.com/collections/illinois-shooting-07042022-intl/](https://www.cnn.com/collections/illinois-shooting-07042022-intl/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-05 04:06:52+00:00



## Is this the new normal for Australia's most populous state?
 - [https://www.cnn.com/2022/07/04/australia/sydney-floods-damage-evacuation-climate-australia-intl-hnk/index.html](https://www.cnn.com/2022/07/04/australia/sydney-floods-damage-evacuation-climate-australia-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-05 03:50:57+00:00

On a fine day, locals arrive on boats that motor up the Hawkesbury River in New South Wales to dine on the back deck of the Paradise Café.

## 2 law enforcement officers shot during a July 4th festival in Philadelphia, source says
 - [https://www.cnn.com/2022/07/04/us/philadelphia-july-fourth-festival-shooting/index.html](https://www.cnn.com/2022/07/04/us/philadelphia-july-fourth-festival-shooting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-05 03:35:06+00:00

Two police officers were shot during a July Fourth celebration in Philadelphia, a law enforcement source with knowledge of the situation told CNN.

## Paris' Eiffel Tower is reportedly badly in need of repairs
 - [https://www.cnn.com/travel/article/eiffel-tower-paris-needs-repairs/index.html](https://www.cnn.com/travel/article/eiffel-tower-paris-needs-repairs/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-05 03:31:57+00:00

The Eiffel Tower is riddled with rust and in need of full repairs, but instead it is being given a cosmetic 60 million euro paint job ahead of the 2024 Olympic Games in Paris, according to confidential reports cited by French magazine Marianne.

## Video shows the moment shots fired during Highland Park parade
 - [https://www.cnn.com/videos/us/2022/07/04/video-shooting-highland-park-illinois-july-4-tsr-vpx.cnn](https://www.cnn.com/videos/us/2022/07/04/video-shooting-highland-park-illinois-july-4-tsr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-05 02:57:44+00:00

A video shows the moment shots were fired into a Fourth of July parade in Highland Park, Illinois, which resulted in dozens injured and at least six dead.

## See spectacular finale of DC fireworks show
 - [https://www.cnn.com/videos/us/2022/07/05/july-4-fireworks-dc-greatest-showman-come-alive-vpx.cnn](https://www.cnn.com/videos/us/2022/07/05/july-4-fireworks-dc-greatest-showman-come-alive-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-05 02:14:44+00:00

Washington, DC's July 4th fireworks show ended with a bang as the US Air Force Band played "Come Alive" from the film "The Greatest Showman."

## Uzbekistan says 18 killed, hundreds wounded in unrest
 - [https://www.cnn.com/2022/07/04/asia/uzbekistan-violence-protests-karakalpakstan-intl-hnk/index.html](https://www.cnn.com/2022/07/04/asia/uzbekistan-violence-protests-karakalpakstan-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-05 02:12:12+00:00

Eighteen people were killed and 243 wounded during unrest in Uzbekistan's autonomous province of Karakalpakstan last week, Uzbek authorities said on Monday -- the worst bout of violence in the Central Asian nation in 17 years.

## Gunman fired on unsuspecting parade attendees from a rooftop, authorities say
 - [https://www.cnn.com/2022/07/04/us/highland-park-illinois-shooting-july-4-parade/index.html](https://www.cnn.com/2022/07/04/us/highland-park-illinois-shooting-july-4-parade/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-05 02:08:15+00:00

Robert E. Crimo III, a person of interest in a mass shooting at a parade that left six dead and sent more than two dozen people to hospitals, has been taken into custody near Lake Forest, Illinois, authorities said during a brief news conference Monday night.

## 'The Lost World': New book highlights Japan's abandoned rural spaces
 - [https://www.cnn.com/travel/article/maan-limburg-the-lost-world-japan/index.html](https://www.cnn.com/travel/article/maan-limburg-the-lost-world-japan/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-05 01:21:58+00:00

Simply saying the word "Japan" can bring up images of manga, maid cafes and neon lights.

## A Kentucky man has turned a pool of eels into his man cave
 - [https://www.cnn.com/videos/us/2022/07/05/eel-pit-garage-kentucky-man-moos-pkg-vpx.cnn](https://www.cnn.com/videos/us/2022/07/05/eel-pit-garage-kentucky-man-moos-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-05 00:56:31+00:00

A pet store manager from Kentucky has turned the rainwater cistern under his garage into an eel pit. CNN's Jeanne Moos reports the eels are reeling in fans.


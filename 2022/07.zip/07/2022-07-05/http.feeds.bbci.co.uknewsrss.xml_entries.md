# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## A one-off Bob Dylan recording could sell for £1m
 - [https://www.bbc.co.uk/news/entertainment-arts-62054616?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62054616?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 23:50:45+00:00

A new version of the star's 1960s classic Blowin' In The Wind is expected to make £1m at auction.

## Ukraine war: The Russian woman rescued from a Kyiv bomb site
 - [https://www.bbc.co.uk/news/world-europe-62044014?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62044014?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 23:36:36+00:00

Russian-born Ekaterina Volkova was injured in an air strike on her apartment that killed her Ukrainian husband.

## What does egg freezing have to do with your employer?
 - [https://www.bbc.co.uk/news/business-61925336?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61925336?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 23:29:06+00:00

More firms are offering so-called 'fertility benefits' but there could be hidden catches.

## CEO Secrets: Airtasker boss on his email regret
 - [https://www.bbc.co.uk/news/business-62050335?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62050335?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 23:14:04+00:00

Tim Fung, co-founder and CEO of Airtasker, shares his business advice for our CEO Secrets series.

## Two million workers free from National Insurance
 - [https://www.bbc.co.uk/news/business-62049263?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62049263?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 23:08:10+00:00

Employees can now earn £12,570 a year before paying National Insurance tax, up from £9,880.

## The Range pulls bikini and bride weight loss items
 - [https://www.bbc.co.uk/news/business-61881412?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61881412?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 23:01:51+00:00

Shoppers complained that dieting wall plaques to collect £1 for every pound lost body shame women.

## Cameron Norrie: Wimbledon semi-finalist unrecognised by barman but now watched by royalty
 - [https://www.bbc.co.uk/sport/tennis/62058706?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/62058706?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 21:36:03+00:00

After reaching the semi-finals of a Grand Slam for the first time, Britain's Cameron Norrie is finally starting to gain more recognition after his Wimbledon exploits.

## Rishi Sunak's and Sajid Javid's resignation letters in full
 - [https://www.bbc.co.uk/news/uk-politics-62058236?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62058236?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 20:42:00+00:00

How the chancellor and secretary of state for health told Boris Johnson they were quitting.

## Euro 2022: Who are the players to watch out for this summer?
 - [https://www.bbc.co.uk/sport/football/61868667?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/61868667?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 20:14:57+00:00

As Europe's best players come to England for this summer's Euros, BBC Sport picks out the stars who could shine.

## Wimbledon: Cameron Norrie beats David Goffin in five-set thriller to reach semi-finals
 - [https://www.bbc.co.uk/sport/av/tennis/62050635?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/tennis/62050635?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 19:53:27+00:00

Britain's Cameron Norrie reaches the Wimbledon semi-finals by fighting back to beat unseeded Belgian David Goffin in a five-set thriller.

## Three-legged ploughshare tortoise finds new life on rollers
 - [https://www.bbc.co.uk/news/uk-england-merseyside-62056851?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-62056851?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 18:55:13+00:00

Chester Zoo's new ploughshare tortoise Hope was rescued from smugglers and fitted with rollers.

## Chris Pincher: It was a mistake to appoint him - PM
 - [https://www.bbc.co.uk/news/uk-politics-62050672?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62050672?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 17:00:12+00:00

The PM says a complaint was made against Chris Pincher in the Foreign Office three years ago.

## Sydney floods aftermath: 'Everybody is traumatised'
 - [https://www.bbc.co.uk/news/world-australia-62054522?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-62054522?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 15:43:03+00:00

More than eight months of rain have fallen in the Sydney area over four days, turning roads into rivers.

## Weekend burst of exercise can be enough to stay fit
 - [https://www.bbc.co.uk/news/health-62040665?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-62040665?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 15:02:33+00:00

Weekend warriors who cram rather than space out their exercise quota do just fine, a study suggests.

## Euro 2022: Security, cameras and team suits - NI's trip to first major tournament 'feels real'
 - [https://www.bbc.co.uk/sport/football/62053752?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62053752?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 14:58:29+00:00

After getting a fanfare arrival in Southampton, Abbie Magee says Northern Ireland's journey over to England for Euro 2022 finally "feels real".

## Nick Kyrgios to appear in court over common assault allegation
 - [https://www.bbc.co.uk/sport/tennis/62052323?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/62052323?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 12:52:47+00:00

Wimbledon quarter-finalist Nick Kyrgios is set to appear in court in Australia next month in relation to an allegation of common assault.

## Christophe Galtier: Frenchman named Paris St-Germain boss after Mauricio Pochettino exit
 - [https://www.bbc.co.uk/sport/football/62050054?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62050054?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 12:47:48+00:00

Christophe Galtier is named Paris St-Germain manager after the departure of Mauricio Pochettino.

## England v India: Joe Root and Jonny Bairstow complete record chase at Edgbaston
 - [https://www.bbc.co.uk/sport/cricket/62031210?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/62031210?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 12:45:15+00:00

England nonchalantly complete a record chase of 378 to beat India in rapid time on the final morning of the fifth Test at Edgbaston.

## Prince Charles airs climate frustration on BBC Wales visit
 - [https://www.bbc.co.uk/news/uk-wales-62034657?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-62034657?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 12:43:54+00:00

The Prince of Wales is "frustrated" the climate crisis isn't mentioned more in weather coverage.

## Cost of living: How can I save money on my food shop?
 - [https://www.bbc.co.uk/news/uk-61798003?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61798003?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 12:40:51+00:00

The cost-of-living crisis continues to bite. Here are some things that can reduce the impact.

## India v England: Joe Root & Jonny Bairstow guide England to historic win
 - [https://www.bbc.co.uk/sport/av/cricket/62052984?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/62052984?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 12:28:14+00:00

Watch highlights as England complete a record chase of 378 to beat India in rapid time on the final morning of the fifth Test at Edgbaston.

## Chris Pincher: No 10 not telling the truth, says ex-senior civil servant
 - [https://www.bbc.co.uk/news/uk-politics-62047883?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62047883?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 12:23:29+00:00

Boris Johnson was briefed in person about an inquiry into Chris Pincher's behaviour, says a former top civil servant.

## Last Supper targeted by climate protesters at Royal Academy
 - [https://www.bbc.co.uk/news/uk-england-london-62050348?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-62050348?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 12:20:07+00:00

Four activists glued their hands to the frame of the Renaissance painting in the Piccadilly gallery.

## Wimbledon 2022: Kalin Ivanovski wins match point with underarm 'hot dog' trick-shot
 - [https://www.bbc.co.uk/sport/av/tennis/62050627?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/tennis/62050627?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 12:19:35+00:00

Kalin Ivanovski wins match point with a 'hot dog' underarm serve against Rodrigo Pacheco Mendez in the second round of the boys singles at Wimbledon.

## The sole survivor of a Russian shooting - he lived by playing dead
 - [https://www.bbc.co.uk/news/world-europe-62011689?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62011689?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 12:08:41+00:00

The extraordinary story of the sole survivor from a group of Ukrainians captured by Russian soldiers.

## UK economic outlook has deteriorated, Bank of England warns
 - [https://www.bbc.co.uk/news/business-62049990?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62049990?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 11:36:44+00:00

But banks are well-placed to weather even a severe economic downturn, the Bank of England says.

## Brittney Griner: US basketball star detained in Russia asks Biden for help
 - [https://www.bbc.co.uk/news/world-us-canada-62049164?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62049164?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 11:28:07+00:00

Brittney Griner says she's terrified she might not return to her own country.

## Mona Hammond: Trailblazing EastEnders actress dies aged 91
 - [https://www.bbc.co.uk/news/entertainment-arts-62048413?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62048413?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 11:16:23+00:00

She was best known for playing Blossom Jackson in the soap, as well as championing black theatre talent.

## Michael Sheen: I broke down hearing kids' care stories
 - [https://www.bbc.co.uk/news/uk-wales-61954808?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-61954808?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 10:51:23+00:00

Michael Sheen speaks to young people in care as part of a BBC investigation into the system.

## Shireen Abu Aqla: US report on journalist's death unacceptable, family says
 - [https://www.bbc.co.uk/news/world-middle-east-62048881?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-62048881?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 10:30:34+00:00

The US has concluded the journalist was likely to have been hit by unintentional Israeli gunfire.

## Tory MP Roger Gale on Boris Johnson handling Chris Pincher claims
 - [https://www.bbc.co.uk/news/uk-politics-62050666?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62050666?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 10:08:58+00:00

The prime minister has "trashed the reputation of a proud and honourable party" says a Tory MP.

## 'The PM has not been aware of specific allegations' - MP Therese Coffey
 - [https://www.bbc.co.uk/news/uk-politics-62048639?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62048639?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 09:52:43+00:00

The work and pensions secretary says the No 10 press office informed her about Boris Johnson's knowledge of allegations agaist Chris Pincher.

## Chris Mason: Can people believe what No 10 is saying?
 - [https://www.bbc.co.uk/news/uk-politics-62049696?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62049696?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 09:28:23+00:00

There is increasing exasperation, from the cabinet down, of the inability of No 10 to focus on the business of government.

## Will Quince: PM 'was not aware' of Pincher allegations
 - [https://www.bbc.co.uk/news/uk-politics-62049610?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62049610?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 09:26:29+00:00

The minister for children said he spoke to Number 10 and asked "firmly and clearly" what had happened.

## Who are 'terrorists' Turkey wants from Sweden and Finland?
 - [https://www.bbc.co.uk/news/world-europe-62027828?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62027828?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 09:25:53+00:00

The BBC speaks to three people sought in return for support of Swedish and Finnish Nato membership.

## Chris Pincher: PM was briefed says Simon McDonald
 - [https://www.bbc.co.uk/news/uk-politics-62048638?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62048638?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 09:22:54+00:00

A former senior civil servant says Boris Johnson was "briefed in person" about an investigation into Mr Pincher.

## Pentaquarks: scientists find new "exotic" configurations of quarks
 - [https://www.bbc.co.uk/news/science-environment-62027238?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-62027238?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 09:13:39+00:00

They hope they will help us understand the "strong force" that holds the insides of atoms together.

## Twelve religious group members arrested over Australian girl's death
 - [https://www.bbc.co.uk/news/world-australia-61991114?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-61991114?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 08:40:10+00:00

The 12 members of a religious group denied the girl medical treatment for six days, police say.

## Chris Pincher: Lord McDonald's letter in full
 - [https://www.bbc.co.uk/news/uk-politics-62047757?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62047757?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 08:10:52+00:00

The former top Foreign Office civil servant writes to the standards commissioner over MP Chris Pincher.

## Chris Pincher: PM briefing 'news to me' says Raab
 - [https://www.bbc.co.uk/news/uk-politics-62048637?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62048637?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 08:08:56+00:00

Dominic Raab was foreign secretary and Mr Pincher's boss when allegations were investigated in 2019.

## Euro 2022: Five great goals from five players to watch
 - [https://www.bbc.co.uk/sport/av/football/62044932?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/62044932?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 07:03:24+00:00

Watch great goals from players set to star at the Women's European Championship this summer, including England's Lauren Hemp and the Netherlands' Vivianne Miedema.

## Kelly Smith column: Why England must embrace Euros challenge
 - [https://www.bbc.co.uk/sport/football/62042159?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62042159?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 06:53:44+00:00

In Kelly Smith's first BBC Sport column, she discusses England's opening game of the Euros, why they cannot afford to lose and how they can go far in the tournament.

## Boy in sequined prom dress ‘living his best life’
 - [https://www.bbc.co.uk/news/uk-england-norfolk-62041127?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-norfolk-62041127?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 05:24:10+00:00

Korben "living his best life", photographed by his proud mum, has gained praise around the world.

## The Papers: Johnson 'did know about Pincher' and UK on go-slow
 - [https://www.bbc.co.uk/news/blogs-the-papers-62045508?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-62045508?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 05:05:44+00:00

Fresh questions about what the PM knew of the Chris Pincher claims feature in Tuesday's papers.

## Australia floods: 50,000 on evacuation alert after deluge hits Sydney
 - [https://www.bbc.co.uk/news/world-australia-61991112?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-61991112?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 02:42:15+00:00

Roads have been cut, houses are under water and thousands have been left without power.

## Frugal businessman captures young Nigerian hearts
 - [https://www.bbc.co.uk/news/world-africa-61865502?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-61865502?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 01:25:11+00:00

An army of social media users backs Peter Obi for Nigeria's presidency, but will that translate into votes?

## How the US Supreme Court is reshaping America
 - [https://www.bbc.co.uk/news/world-us-canada-62000677?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62000677?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 01:18:19+00:00

America's top court has issued decisions that have divided the country and challenged lawmakers.

## Avabai Wadia: The lawyer who became India’s family planning pioneer
 - [https://www.bbc.co.uk/news/world-asia-india-62033246?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-62033246?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 00:32:11+00:00

Avabai Wadia played a major role in India becoming the first country to officially promote family planning.

## Sri Lanka: 'I can’t afford milk for my babies'
 - [https://www.bbc.co.uk/news/world-asia-62032761?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-62032761?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 00:31:01+00:00

As fuel, food and medicines run out, Sri Lanka is on the brink of a humanitarian crisis, the UN warns.

## Climate change: 'Sand battery' could solve green energy's big problem
 - [https://www.bbc.co.uk/news/science-environment-61996520?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-61996520?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-05 00:12:10+00:00

A storage device made from sand may overcome the biggest issue in the transition to renewable energy.


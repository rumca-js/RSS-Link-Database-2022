# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Don’t Be Fooled
 - [https://www.youtube.com/watch?v=eslgiZhs0js](https://www.youtube.com/watch?v=eslgiZhs0js)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-07-06 00:00:00+00:00

This week I spoke with David Sirota - award-winning journalist & writer and founder of Investigative News Site ‘The Lever’. We spoke about the weaponisation of identity against universalism in the economic sphere, such as why economic giants like JP Morgan, Goldman Sachs & Wall Street put up flags in support for identity issues. #corporation #pride #banks 

Visit The Lever: https://www.levernews.com/
--------------------------------------------------------------------------------------------------------------------------
Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## They’re coming for you.
 - [https://www.youtube.com/watch?v=pXFe56ac7EQ](https://www.youtube.com/watch?v=pXFe56ac7EQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-07-05 00:00:00+00:00

Whatever you feel about Roe v Wade, Big Tech’s subsequent “content moderation” demonstrates that even if you support the idea of tech censorship now, sooner or later your views will be targeted. #roevwade #facebook #censorship 

References
https://jacobin.com/2022/06/facebook-antiabortion-pills-censorship-content-moderation-social-media
--------------------------------------------------------------------------------------------------------------------------
Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


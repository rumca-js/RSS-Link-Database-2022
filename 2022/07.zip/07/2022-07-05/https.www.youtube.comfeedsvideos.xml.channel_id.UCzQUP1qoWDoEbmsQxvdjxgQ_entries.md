# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Has Google Created Sentient AI?
 - [https://www.youtube.com/watch?v=RB-O0V9djEs](https://www.youtube.com/watch?v=RB-O0V9djEs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-07-06 00:00:00+00:00

Taken from JRE #1840 w/Marc Andreessen:
https://open.spotify.com/episode/2JDW5u8BlKHM5C5wInOT4u?si=141742e0e2b44a40

## Joe & Duncan Roast the Caveman movie "IceMan"
 - [https://www.youtube.com/watch?v=NwhXRAZW1xk](https://www.youtube.com/watch?v=NwhXRAZW1xk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-07-05 00:00:00+00:00

Taken from JRE #1839 w/Duncan Trussell:
https://open.spotify.com/episode/0k503tOyovs71ddjCCfmHA?si=f79302b75c4f4889

## Joe & Duncan Try to Learn About the Revolutionary War
 - [https://www.youtube.com/watch?v=vLh4Cj0jgRA](https://www.youtube.com/watch?v=vLh4Cj0jgRA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-07-05 00:00:00+00:00

Taken from JRE #1839 w/Duncan Trussell:
https://open.spotify.com/episode/0k503tOyovs71ddjCCfmHA?si=878bfb5e47a04b82


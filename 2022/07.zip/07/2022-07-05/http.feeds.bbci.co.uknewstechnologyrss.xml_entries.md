# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## NHS trials using drones to deliver chemotherapy drugs
 - [https://www.bbc.co.uk/news/uk-england-hampshire-62044754?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-hampshire-62044754?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-07-05 01:24:18+00:00

A pilot scheme will courier chemotherapy drugs from Portsmouth to the Isle of Wight, NHS England says.


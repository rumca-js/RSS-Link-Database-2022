# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## ROG Phone 6 Pro Review: Daily Driver Material!
 - [https://www.youtube.com/watch?v=dKq_xfCz3Jk](https://www.youtube.com/watch?v=dKq_xfCz3Jk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-07-05 00:00:00+00:00

The gaming phones are refining themselves into bona fide daily supercars. And it should, for €1,299

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Asus for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


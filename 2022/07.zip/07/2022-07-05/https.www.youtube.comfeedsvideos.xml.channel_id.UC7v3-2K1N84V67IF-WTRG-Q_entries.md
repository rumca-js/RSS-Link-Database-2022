# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Thor: Love and Thunder - Movie Review
 - [https://www.youtube.com/watch?v=lutYwPDTdh8](https://www.youtube.com/watch?v=lutYwPDTdh8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-07-05 00:00:00+00:00

Get the exclusive NordVPN deal here: https://nordvpn.com/jahns. It’s risk free with Nord’s 30 day money-back guarantee!
Thanks to NordVPN for sponsoring this video.

Taika Waititi returns to the MCU to give us the comedy/drama/space action adventure THOR: LOVE AND THUNDER! Do the elements mix together in a satisfying way? Here's my review!

#ThorLoveAndThunder


# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Conversion therapy: 'I thought God hated me because I was gay'
 - [https://www.bbc.co.uk/news/uk-england-essex-61816257?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-61816257?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 23:55:29+00:00

A Methodist minister tells of his struggle with sexuality and how he was sent for conversion therapy.

## Wimbledon: How does tennis work when you're blind?
 - [https://www.bbc.co.uk/news/disability-62041246?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/disability-62041246?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 23:05:48+00:00

Wimbledon brings tennis to the spotlight every summer, though how does the sport work when you're blind?

## Chris Mason: Why Labour's leader has made peace with Brexit
 - [https://www.bbc.co.uk/news/uk-politics-62045237?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62045237?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 22:12:27+00:00

Sir Keir Starmer's vow to "make Brexit work" feels like a moment for Labour after years of argument.

## Ian Poulter allowed to play Scottish Open after ban lifted - DP World Tour boss 'disappointed'
 - [https://www.bbc.co.uk/sport/golf/62035651?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/golf/62035651?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 20:48:39+00:00

Ian Poulter will be allowed to play in this week's Scottish Open after an appeal against his ban is upheld, to the "disappointment" of DP World Tour.

## Ukraine war: Putin presses on after Lysychansk capture
 - [https://www.bbc.co.uk/news/world-europe-62033619?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62033619?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 18:29:27+00:00

With Luhansk region entirely in Russia's hands, its president orders the offensive to be continued.

## Minions: Cinemas ban teens in suits over #gentleminions trend
 - [https://www.bbc.co.uk/news/uk-61988793?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61988793?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 18:27:35+00:00

Young people following the #gentleminions TikTok trend are accused of disturbing others.

## Big Zuu on breaking the mould for cookery shows
 - [https://www.bbc.co.uk/news/entertainment-arts-61549423?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-61549423?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 16:47:32+00:00

TV cook Big Zuu reflects on his Dave show's double Bafta win and the importance of representation.

## Belgorod: Fear and denial in Russian city hit by shells
 - [https://www.bbc.co.uk/news/world-europe-62042455?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62042455?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 16:00:12+00:00

Residents of Belgorod are divided on how to respond to Ukraine after the city was hit by explosions.

## F1 British Grand Prix: What is halo and how does it save lives?
 - [https://www.bbc.co.uk/news/newsbeat-62037334?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-62037334?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 15:15:14+00:00

Driver Zhou Guanyu says the halo device saved his life after a horror crash at Silverstone on Sunday.

## Ukraine war: What is Putin's plan now Luhansk has fallen?
 - [https://www.bbc.co.uk/news/world-europe-62040787?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62040787?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 14:26:35+00:00

The fall of the city of Lysychansk means the whole Luhansk region is now under Russian control.

## Commercial flight escorted by fighter jet after bomb hoax
 - [https://www.bbc.co.uk/news/world-europe-62036779?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62036779?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 13:47:21+00:00

A British holidaymaker was arrested after posting a bomb threat on social media.

## Christian Eriksen: Denmark midfielder agrees in principle to join Manchester United
 - [https://www.bbc.co.uk/sport/football/62037422?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62037422?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 12:16:15+00:00

Denmark midfielder Christian Eriksen agrees in principle to sign for Manchester United on a free transfer.

## Copenhagen shooting: Harry Styles fans praise Danish police for attack response
 - [https://www.bbc.co.uk/news/world-europe-62035582?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62035582?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 12:16:14+00:00

People near the scene of Sunday's shooting say police did a good job in getting them to safety.

## Fuel protests: Go-slow convoys cause motorway delays
 - [https://www.bbc.co.uk/news/uk-62034278?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62034278?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 12:15:06+00:00

Convoys of protesters are driving slowly on motorways as they call for fuel duty to be cut.

## Copenhagen shooting: Gunman charged in court with murder
 - [https://www.bbc.co.uk/news/world-europe-62034089?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62034089?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 12:13:39+00:00

The suspect had mental health issues and there is no indication of a terror motive, police say.

## Towie: Yazmin Oukhellou reportedly in hospital after crash which killed man
 - [https://www.bbc.co.uk/news/uk-england-essex-62033744?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-62033744?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 12:09:46+00:00

The Foreign Office says it is supporting the family of a British woman in hospital.

## EasyJet deputy quits after major flight disruption
 - [https://www.bbc.co.uk/news/business-62038384?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62038384?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 12:02:59+00:00

The move comes after the airline has been criticised for flight cancellations and disruption to schedules.

## Bedford: Buildings evacuated as gas explosion wrecks flats
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-62037078?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-62037078?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 11:58:59+00:00

An eyewitness describes seeing a person leaping from a second-floor window to escape.

## Tim Westwood: BBC reveals complaints against DJ
 - [https://www.bbc.co.uk/news/uk-62015958?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62015958?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 11:58:17+00:00

Police were involved after one of six bullying or sexual misconduct complaints, the corporation says.

## Kellogg's loses court case over sugary cereal supermarket offers
 - [https://www.bbc.co.uk/news/business-62034220?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62034220?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 11:38:06+00:00

It means products like Crunchy Nut Corn Flakes will not be allowed in end of aisle promotions.

## Wireless Festival experience 'upsetting' for disabled fans
 - [https://www.bbc.co.uk/news/newsbeat-62038374?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-62038374?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 11:26:24+00:00

Wheelchair users were faced with steep hills and obscured views of the stage at the music festival.

## The story behind Adele's Hyde Park Pride flag
 - [https://www.bbc.co.uk/news/uk-england-london-62038158?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-62038158?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 11:20:52+00:00

Dean William was approached by one of the star's team before Saturday's sold-out BST Hyde Park gig.

## Rescuers try to save stranded cargo ship near Sydney
 - [https://www.bbc.co.uk/news/world-australia-62037494?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-62037494?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 11:20:29+00:00

Teams have been deployed to rescue a cargo ship that is stranded off the coast of Australia.

## Marmolada glacier collapse in Italy kills six
 - [https://www.bbc.co.uk/news/world-europe-62029780?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62029780?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 11:16:33+00:00

Emergency officials said another nine people have been injured, and 19 remain missing.

## School dinners: Beef off the menu as costs rise
 - [https://www.bbc.co.uk/news/education-61882652?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-61882652?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 11:15:29+00:00

Menus have fewer options and some schools are switching to cheaper meat from abroad, caterers say.

## Barristers to strike every other week from August with no end date
 - [https://www.bbc.co.uk/news/uk-62009941?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62009941?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 11:03:11+00:00

The long-running dispute is over how much criminal barristers are paid for legal aid work.

## Women's European Championship: Relive the best moment of Euro 2017
 - [https://www.bbc.co.uk/sport/av/football/62015150?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/62015150?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 10:55:07+00:00

Watch the best moments from Euro 2017, including Jodie Taylor's opening-day hat-trick for England and Norway's shock win against Germany.

## England v India: Stuart Broad told to 'shut up' by umpire
 - [https://www.bbc.co.uk/sport/av/cricket/62037947?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/62037947?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 10:30:56+00:00

England's Stuart Broad is told to "shut up" by umpire Richard Kettleborough after one too many complaints during the rearranged fifth Test between England and India at Edgbaston.

## China: Buyout of UK's largest microchip plant raises concerns
 - [https://www.bbc.co.uk/news/world-62014792?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-62014792?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 09:22:53+00:00

Welsh microchip producer has become a front-line in the tech war between the West and China.

## Pink Ladies' Tractor Road Run helps breast cancer research
 - [https://www.bbc.co.uk/news/uk-england-norfolk-62030466?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-norfolk-62030466?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 06:21:42+00:00

More than 100 women drive miles on decorated tractors on a journey to raise £1m for a cancer charity.

## Jayland Walker: Ohio police release video of deadly suspect chase
 - [https://www.bbc.co.uk/news/world-us-canada-62032964?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62032964?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 05:35:44+00:00

Police say they believe Jayland Walker fired first before being shot more than 60 times by officers.

## 'I use my eating disorder experience to help others'
 - [https://www.bbc.co.uk/news/uk-england-london-61927941?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-61927941?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 05:12:38+00:00

Nicola Chan had non-purging bulimia and disordered eating, now she's helping others.

## BBC pundits predict Euro 2022: Can England go all the way?
 - [https://www.bbc.co.uk/sport/football/61820697?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/61820697?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 05:11:21+00:00

Who will win Euro 2022? Who will be the tournament's top goalscorer? Which team can cause an upset? BBC pundits predict what will happen at this summer's tournament.

## Terrence Higgins: A name that gave hope to those with HIV and Aids
 - [https://www.bbc.co.uk/news/uk-wales-61925013?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-61925013?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 05:01:29+00:00

Higgins' friends talk about the man whose death was the catalyst for change for people with HIV.

## Scientists discover new giant water lily species
 - [https://www.bbc.co.uk/news/science-environment-61725827?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-61725827?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-04 04:00:04+00:00

Scientists discover the first new species of giant water lily in more than a century.


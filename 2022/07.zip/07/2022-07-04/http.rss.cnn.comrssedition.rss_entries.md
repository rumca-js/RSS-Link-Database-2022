# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Her traumatic pregnancy experience may become a reality for many Americans
 - [https://www.cnn.com/videos/world/2022/07/04/ireland-abortion-restrictions-isa-soares-intl-vpx.cnn](https://www.cnn.com/videos/world/2022/07/04/ireland-abortion-restrictions-isa-soares-intl-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 23:45:15+00:00

Following the US Supreme Court's overturning of Roe vs. Wade, CNN's Isa Soares traveled to Ireland, which recently legalized abortions with restrictions, to speak with a woman about the trauma she experienced when her pregnancies took an unexpected turn.

## 'I'm terrified I might be here forever': Brittney Griner pens handwritten letter to Biden
 - [https://www.cnn.com/2022/07/04/politics/brittney-griner-letter-biden-white-house/index.html](https://www.cnn.com/2022/07/04/politics/brittney-griner-letter-biden-white-house/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 22:56:43+00:00

WNBA star Brittney Griner, in a handwritten letter to President Joe Biden, said she fears she will be detained in Russia indefinitely and pleaded with the President not to forget about her and other American detainees.

## Manhunt underway after at least 6 killed in Illinois July 4th parade shooting
 - [https://www.cnn.com/collections/guns/](https://www.cnn.com/collections/guns/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 21:15:14+00:00



## Chile's Constitutional Assembly presents proposal for new constitution to Chilean president
 - [https://www.cnn.com/2022/07/04/americas/chile-constitutional-assembly-proposal-intl/index.html](https://www.cnn.com/2022/07/04/americas/chile-constitutional-assembly-proposal-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 21:10:24+00:00

Chile's Constitutional Assembly presented President Gabriel Boric with a historic proposal for a new constitution for the South American country on Monday.

## Only a few people knew about this rare truffle. Until now
 - [https://www.cnn.com/videos/travel/2022/07/04/rare-truffle-appalachian-mountains-big-trip-orig.cnn](https://www.cnn.com/videos/travel/2022/07/04/rare-truffle-appalachian-mountains-big-trip-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 20:28:46+00:00

This rare truffle can only be found in two places in the world. Forager Alan Muskat shares the secret about how to try one in Asheville, NC.

## Tennis stars fined thousands for unsportsmanlike conduct at Wimbledon
 - [https://www.cnn.com/collections/intl-wimbledon-0704/](https://www.cnn.com/collections/intl-wimbledon-0704/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 20:19:16+00:00



## The Catholic Church once allowed for abortions. Everything changed in 1873
 - [https://www.cnn.com/videos/politics/2022/07/03/abortion-law-roe-v-wade-history-orig-dp-kj.cnn](https://www.cnn.com/videos/politics/2022/07/03/abortion-law-roe-v-wade-history-orig-dp-kj.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 20:10:29+00:00

Until the 1880s, abortions were morally acceptable and legal, with even the Catholic Church approving of the procedure before 'quickening.' Historians say the desire to ban the procedure had more to do with business than women's health.

## Brazil sees record Amazon deforestation in first half of 2022
 - [https://www.cnn.com/2022/07/04/americas/brazil-amazon-record-deforestation-intl/index.html](https://www.cnn.com/2022/07/04/americas/brazil-amazon-record-deforestation-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 20:10:06+00:00

Brazil's Amazon rainforest has been deforested by a record amount in the first half of 2022, according to the country's Space Research Institute (INPE).

## Kyrgios extends eventful Wimbledon run
 - [https://www.cnn.com/2022/07/04/tennis/nick-kyrgios-brandon-nakashima-wimbledon-spt-intl/index.html](https://www.cnn.com/2022/07/04/tennis/nick-kyrgios-brandon-nakashima-wimbledon-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 19:35:24+00:00

Nick Kyrgios continued his eventful run at Wimbledon with a 4-6 6-4 7-6 (7-2) 3-6 6-2 victory against Brandon Nakashima in the fourth round.

## 'Like a battle zone': Witness describes scary moment shots rang out at Highland Park parade
 - [https://www.cnn.com/videos/us/2022/07/04/highland-park-illinois-shooting-zoe-pawelczak-witness-sot-nr-broaddus-vpx.cnn](https://www.cnn.com/videos/us/2022/07/04/highland-park-illinois-shooting-zoe-pawelczak-witness-sot-nr-broaddus-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 19:10:50+00:00

A number of people were killed at a July 4th parade in Highland Park, Illinois, Highland Park police announced in a press conference. The suspect remains at large. CNN's Adrienne Broaddus talks to Zoe Pawelczak, a parade attendee who was present as the shooting occurred.

## US says Israeli military gunfire likely responsible for Shireen Abu Akleh's death but examination of bullet inconclusive
 - [https://www.cnn.com/2022/07/04/politics/shireen-abu-akleh-bullet-investigation-us-palestinian-authority/index.html](https://www.cnn.com/2022/07/04/politics/shireen-abu-akleh-bullet-investigation-us-palestinian-authority/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 18:44:42+00:00

An examination of the bullet that killed Al Jazeera correspondent and Palestinian-American citizen Shireen Abu Akleh "could not reach a definitive conclusion" regarding its origin, due to the condition of the bullet, but the US Security Coordinator has "concluded that gunfire from [Israel Defense Forces] positions was likely responsible" for her death, State Department spokesperson Ned Price said in a statement Monday.

## Copenhagen mall shooting suspect remanded in psychiatric care facility
 - [https://www.cnn.com/2022/07/03/europe/copenhagen-mall-shooting-intl/index.html](https://www.cnn.com/2022/07/03/europe/copenhagen-mall-shooting-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 18:39:35+00:00



## Officials: Black man suffered at least 60 wounds in fatal police shooting
 - [https://www.cnn.com/2022/07/03/us/jayland-walker-police-shooting-video/index.html](https://www.cnn.com/2022/07/03/us/jayland-walker-police-shooting-video/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 16:56:29+00:00

A 25-year-old Black man suffered at least 60 wounds when Akron, Ohio, police officers fatally shot him last week, Akron's police chief said, citing a medical examiner's report.

## Trump-backed secretary of state nominee makes shocking abortion remark
 - [https://www.cnn.com/videos/politics/2022/07/04/kristina-karamo-abortion-child-sacrifice-trump-michigan-secretary-of-state-nominee-newsroom-kaczynski-vpx.cnn](https://www.cnn.com/videos/politics/2022/07/04/kristina-karamo-abortion-child-sacrifice-trump-michigan-secretary-of-state-nominee-newsroom-kaczynski-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 16:36:17+00:00

CNN's KFile discovered troubling comments Michigan's Trump-backed secretary of state nominee Kristina Karamo made about abortions, comparing them to "child sacrifice" in her podcast. CNN reached out to her campaign to get a response and has not heard back.

## US-Iran tensions could heat up this summer
 - [https://www.cnn.com/2022/07/04/middleeast/iran-nuclear-talks-doha-mime-intl/index.html](https://www.cnn.com/2022/07/04/middleeast/iran-nuclear-talks-doha-mime-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 15:27:25+00:00

The United States and Iran could be heading for a summer of further escalation after indirect talks to restore the 2015 nuclear deal ended without any progress last week.

## Paris Fashion Week: How to watch the couture shows live
 - [https://www.cnn.com/style/article/paris-fashion-week-july-2023-couture-shows/index.html](https://www.cnn.com/style/article/paris-fashion-week-july-2023-couture-shows/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 15:04:46+00:00

Couture week returns this week to Paris with a four-day-long schedule promising reams of artistic, fantastical fashion.

## Inflation soars to nearly 80% in Turkey as food prices double
 - [https://www.cnn.com/2022/07/04/economy/turkey-inflation-food-energy/index.html](https://www.cnn.com/2022/07/04/economy/turkey-inflation-food-energy/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 14:52:38+00:00

Turkey's annual rate of inflation hit almost 80% in June — its highest level in about two decades.

## Cast of 'Heartstopper' sings Whitney Houston against anti-LGBT protesters in viral video
 - [https://www.cnn.com/2022/07/04/entertainment/heartstopper-cast-london-pride-trnd/index.html](https://www.cnn.com/2022/07/04/entertainment/heartstopper-cast-london-pride-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 14:49:27+00:00

The cast of Netflix's same-sex love story "Heartstopper" celebrated London Pride with a Whitney Houston dance party as they faced off with anti-LGBTQ protesters.

## See tornadoes touch down in southern China
 - [https://www.cnn.com/videos/world/2022/07/04/china-guangdong-province-tornadoes-lon-orig-na.cnn](https://www.cnn.com/videos/world/2022/07/04/china-guangdong-province-tornadoes-lon-orig-na.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 14:39:28+00:00

China's southern Guangdong province was hit with severe weather on July 2, including tornadoes and Typhoon Chaba.

## This giant waterlily is the biggest in the world -- and it's a newly identified species
 - [https://www.cnn.com/2022/07/04/world/giant-waterlily-victoria-boliviana-intl-scli-scn-gbr/index.html](https://www.cnn.com/2022/07/04/world/giant-waterlily-victoria-boliviana-intl-scli-scn-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 14:37:54+00:00

An enormous waterlily in London's Royal Botanic Gardens has been discovered to belong to an entirely new species, after 177 years in the gardens' herbarium.

## 17-year-old shark attack survivor describes her battle with the beast
 - [https://www.cnn.com/2022/07/04/us/shark-attack-survivor-florida/index.html](https://www.cnn.com/2022/07/04/us/shark-attack-survivor-florida/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 14:22:05+00:00

Addison Bethea was out hunting for scallops in the waters off Keaton Beach, Florida, on Thursday when a shark latched onto her flesh.

## Adele says she was 'shell of a person' after canceling Vegas residency
 - [https://www.cnn.com/2022/07/04/entertainment/adele-vegas-residency/index.html](https://www.cnn.com/2022/07/04/entertainment/adele-vegas-residency/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 14:15:47+00:00

Ticket holders weren't the only ones devastated when Adele had to cancel her Las Vegas residency.

## Tom Cruise turned 60 the day before America's birthday and it feels right
 - [https://www.cnn.com/2022/07/04/entertainment/tom-cruise-birthday/index.html](https://www.cnn.com/2022/07/04/entertainment/tom-cruise-birthday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 13:59:42+00:00

Tom Cruise turned 60 years old on July 3 and all we got him was a blockbuster movie.

## Pope Francis denies he is planning to resign soon
 - [https://www.cnn.com/2022/07/04/europe/pope-francis-resignation-denial-intl/index.html](https://www.cnn.com/2022/07/04/europe/pope-francis-resignation-denial-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 12:57:37+00:00

Pope Francis has dismissed reports that he plans to resign in the near future, saying he is on track to visit Canada this month and hopes to be able to go to Moscow and Kyiv as soon as possible after that.

## Wildlife crossings are a lifeline to Canada's grizzly bears
 - [https://www.cnn.com/2022/07/04/americas/grizzly-bear-wildlife-crossings-c2e-scn-spc-intl/index.html](https://www.cnn.com/2022/07/04/americas/grizzly-bear-wildlife-crossings-c2e-scn-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 10:58:14+00:00

How did the grizzly bear cross the road? With difficulty. It took Lingenpolter, a young male grizzly bear, 46 attempts to safely cross the Interstate 90 highway in Montana.

## Another major Chinese developer just defaulted on its debt
 - [https://www.cnn.com/2022/07/04/economy/chinese-developer-shimao-default-intl-hnk/index.html](https://www.cnn.com/2022/07/04/economy/chinese-developer-shimao-default-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 10:08:40+00:00

Another major Chinese developer has defaulted on its debt, dealing a new blow to the ailing real estate sector in the world's second largest economy.

## Russian hockey player detained in Russia for allegedly evading military service, reports say
 - [https://www.cnn.com/2022/07/04/sport/ivan-fedotov-detained-evading-military-service-spt-intl/index.html](https://www.cnn.com/2022/07/04/sport/ivan-fedotov-detained-evading-military-service-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 09:01:16+00:00

Russian goalkeeper Ivan Fedotov was detained in St. Petersburg on the request of the military prosecutor's office on Friday for evading military service, according to reports from Russian media outlets.

## Survivor from ship sunk in typhoon found after Hong Kong said 'miracle' needed
 - [https://www.cnn.com/2022/07/04/asia/hong-kong-china-typhoon-chaba-rescue-survivors-intl-hnk/index.html](https://www.cnn.com/2022/07/04/asia/hong-kong-china-typhoon-chaba-rescue-survivors-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 08:58:05+00:00

A rescue team from mainland China saved a crew member of a ship that broke in half and sank during Typhoon Chaba in the early hours of Monday morning -- just hours after their counterparts in Hong Kong said a "miracle" would be needed to find any more survivors.

## My transplant opened my eyes to the need for organ donors
 - [https://www.cnn.com/2022/07/04/health/organ-donation-liver-transplant-wellness/index.html](https://www.cnn.com/2022/07/04/health/organ-donation-liver-transplant-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 08:46:14+00:00

My CNN colleague Richard Roth recently needed a kidney transplant -- his second in nearly 25 years. The email announcing he'd gotten the organ and was so grateful for his donor made me smile and cry a little.

## Two women killed in Egypt Red Sea shark attacks
 - [https://www.cnn.com/2022/07/04/middleeast/two-women-killed-egypt-red-sea-attack-intl/index.html](https://www.cnn.com/2022/07/04/middleeast/two-women-killed-egypt-red-sea-attack-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 08:45:55+00:00

Two women were killed in shark attacks in Egypt's Red Sea, south of the city of Hurghada, the Egyptian Ministry of Environment said on Sunday.

## One of the theater world's most decorated directors dies at 97
 - [https://www.cnn.com/style/article/peter-brook-director-obit/index.html](https://www.cnn.com/style/article/peter-brook-director-obit/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 08:42:11+00:00

Director Peter Brook, whose ground-breaking stage productions transformed 20th-century theater, has died aged 97, according to his publisher, Nick Hern Books.

## Chinese F1 star says safety device saved his life during horrific crash
 - [https://www.cnn.com/2022/07/04/motorsport/zhou-guanyu-halo-saved-his-life-spt-intl/index.html](https://www.cnn.com/2022/07/04/motorsport/zhou-guanyu-halo-saved-his-life-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 08:38:20+00:00

Formula One driver Zhou Guanyu has credited his car's halo protection device for saving his life after he was involved in a horrific high-speed crash during the first lap of Sunday's British Grand Prix.

## China calls on Myanmar's junta to hold talks with opponents
 - [https://www.cnn.com/2022/07/04/asia/myanmar-china-wang-yi-junta-talks-intl-hnk/index.html](https://www.cnn.com/2022/07/04/asia/myanmar-china-wang-yi-junta-talks-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 08:09:39+00:00

China's Foreign Minister Wang Yi has called on Myanmar's junta leaders to talk to their opponents amid concerns over escalating violence and deteriorating human rights in the Southeast Asian country.

## 'Masterminds' behind brutal killing of Hindu tailor arrested, Indian police say
 - [https://www.cnn.com/2022/07/04/india/udaipur-killing-arrest-masterminds-india-intl-hnk/index.html](https://www.cnn.com/2022/07/04/india/udaipur-killing-arrest-masterminds-india-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 06:29:52+00:00

Indian police made fresh arrests at the weekend over the murder of a Hindu tailor in Rajasthan -- a crime that sparked tensions between the Hindu majority and Muslim minority and a clampdown on protests and the internet to prevent them from escalating.

## Copenhagen mall shooting suspect remanded in psychiatric care facility, police say
 - [https://www.cnn.com/collections/intl-0704-copenhagen/](https://www.cnn.com/collections/intl-0704-copenhagen/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 03:11:59+00:00



## Frank Lloyd Wright designed the Guggenheim Museum -- and this 12-year-old boy's dog house
 - [https://www.cnn.com/style/article/frank-lloyd-wright-dog-house-trnd/index.html](https://www.cnn.com/style/article/frank-lloyd-wright-dog-house-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-07-04 03:03:00+00:00

Famed American architect Frank Lloyd Wright designed iconic buildings like the Fallingwater house in Pennsylvania and the Guggenheim Museum in New York -- and he also designed a dog house for a 12-year-old boy who sent him a letter.


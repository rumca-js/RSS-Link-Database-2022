# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Sony Xperia 1 V: what we want to see
 - [https://www.techradar.com/news/sony-xperia-1-v](https://www.techradar.com/news/sony-xperia-1-v)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-07-04 17:30:35+00:00

The Sony Xperia 1 V could be the best phone of 2023 - but it will need these changes first.


# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Australia's devastating floods spur new warning systems
 - [https://www.bbc.co.uk/news/business-61717600?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61717600?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-07-04 23:06:59+00:00

Better data and real-time software is allowing companies to improve the precision of flood warnings.

## Army's YouTube and Twitter accounts hacked
 - [https://www.bbc.co.uk/news/uk-62030644?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62030644?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-07-04 02:26:57+00:00

The British Army says it is investigating after videos and posts for cryptocurrency appeared on its accounts.


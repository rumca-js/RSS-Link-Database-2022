# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Starfield: 10 Things YOU NEED TO KNOW
 - [https://www.youtube.com/watch?v=Zu0V4oacsJU](https://www.youtube.com/watch?v=Zu0V4oacsJU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-07-05 00:00:00+00:00

Starfield (2023) is Bethesda's next big RPG following Skyrim and Fallout 4. Here's everything we know, as well as some speculation.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro 
0:23 HOW BIG?
2:20 BASE BUILDING
3:45 SHIP BUILDING
4:55 MORE SHIP INFO
6:01 FACTIONS
7:41 PERSUATION 
8:21 CHARACTER CREATION 
9:54 COMBAT 
11:38 COMPANIONS
12:46 GAME ENGINE, MOD SUPPORT, DLC

## 10 Dumb Video Game Moves That Are TRULY INSANE
 - [https://www.youtube.com/watch?v=18QtVjjjYEQ](https://www.youtube.com/watch?v=18QtVjjjYEQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-07-04 00:00:00+00:00

Some gaming moves are super stupid but also extremely awesome. Yep, that's video games for you. Here are some of our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro 
0:20 Number 10 
1:43 Number 9 
3:30 Number 8
4:32 Number 7
5:42 Number 6
7:04 Number 5
8:01 Number 4 
9:15 Number 3 
10:16 Number 2
11:27 Number 1


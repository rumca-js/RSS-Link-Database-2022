# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Thor: Love and Thunder is a Fun but Ungodly Mess | Review
 - [https://www.youtube.com/watch?v=FtL05ornpO8](https://www.youtube.com/watch?v=FtL05ornpO8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-07-05 00:00:00+00:00

Darren Mooney reviews Thor: Love and Thunder for The Escapist.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Which Modern Games Will Stand the Test of Time? (ft. Skill Up) | Slightly Something Else
 - [https://www.youtube.com/watch?v=NHQ0v1sNcto](https://www.youtube.com/watch?v=NHQ0v1sNcto)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-07-04 00:00:00+00:00

This week on Slightly Something Else, Yahtzee, Marty and special guest SkillUp will be discussing which modern games they think will stand the test of time.

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag


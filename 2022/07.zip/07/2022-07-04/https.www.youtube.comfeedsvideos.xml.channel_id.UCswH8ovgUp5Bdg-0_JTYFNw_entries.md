# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## They’re coming for you.
 - [https://www.youtube.com/watch?v=pXFe56ac7EQ](https://www.youtube.com/watch?v=pXFe56ac7EQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-07-05 00:00:00+00:00

Whatever you feel about Roe v Wade, Big Tech’s subsequent “content moderation” demonstrates that even if you support the idea of tech censorship now, sooner or later your views will be targeted. #roevwade #facebook #censorship 

References
https://jacobin.com/2022/06/facebook-antiabortion-pills-censorship-content-moderation-social-media
--------------------------------------------------------------------------------------------------------------------------
Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## “Hang on, CIVIL WAR now?!” This is alarming.
 - [https://www.youtube.com/watch?v=QHF2srZrwoM](https://www.youtube.com/watch?v=QHF2srZrwoM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-07-04 00:00:00+00:00

Happy Independence Day! But as a new poll shows 44% of Americans believe the nation is headed toward another civil war, is the country more divided than ever? 
#independenceday #4thofjuly #civilwar #celebration 

References
https://danielpinchbeck.substack.com/p/is-civil-war-inevitable?utm_source=%2Fprofile%2F2728693-daniel-pinchbeck&utm_medium=reader2
--------------------------------------------------------------------------------------------------------------------------
Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


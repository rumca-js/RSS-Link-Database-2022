## Why Marvel's New Warriors Reboot Was Never Published
 - [https://www.cbr.com/what-happened-new-warriors-30th-anniversary-marvel/](https://www.cbr.com/what-happened-new-warriors-30th-anniversary-marvel/)
 - RSS feed: https://www.cbr.com
 - date published: 2022-07-04 06:57:11+00:00

Why Marvel's New Warriors Reboot Was Never Published


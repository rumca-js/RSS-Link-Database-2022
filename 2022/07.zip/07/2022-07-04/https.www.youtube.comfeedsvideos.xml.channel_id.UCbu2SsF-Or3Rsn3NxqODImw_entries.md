# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## GTA 6 & GTA Trilogy Changed Rockstar's Remaster Plans | GameSpot News
 - [https://www.youtube.com/watch?v=k_X9ratNENE](https://www.youtube.com/watch?v=k_X9ratNENE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-07-05 00:00:00+00:00

Rockstar is focusing on GTA 6, GTA 4 and Red Dead Redemption remasters are put on hold, news Call of Duty images leaks and Microsoft confirms Xbox 360 games are leaving Games with Gold. 
#GamingNews #GTA6 #CallofDuty 

Rockstar insider Tez2 recently claimed on Twitter that it is unlikely that Rockstar Games is moving forward with potential GTA 4 and Red Dead Redemption remasters. A report from Kotaku corroborates that neither of these remasters are moving ahead for now, and that all remakes have been "shelved" as the studio focuses on Grand Theft Auto 6. In a tweet replying to another user on Twitter, Tez2 also clarified that the remasters weren't in full production, more just something that was planned, with Rockstar "looking at the Trilogy to greenlight more remasters."

New Call of Duty images have surfaced online. The images seem to be a mix of screens from this year’s Modern Warfare 2 and an unannounced game from Treyarch, the developers of Black Ops. These leaked pics are the result of data mining from a recent Warzone Mobile update and fans have already started to speculate. One of the images that seems to be catching the most attention is the one labeled “Stealth”. This is because it contains a F-117 Nighthawk, a stealth aircraft that became synonymous with the Gulf War. 

Beginning in October, Games with Gold will no longer offer Xbox 360 games to download. Word of the change first surfaced in an email sent out to Dutch Xbox Live Gold subscribers (via Wario64). Xbox One games, however, will still be available each month. Xbox 360 Games with Gold titles will still be available for a redownload regardless of membership, as in the past. The program was originally introduced in 2013 for Xbox 360 consoles, and extended to Xbox One consoles in 2014 as a bonus for Xbox Live Gold subscribers.

STAMPS
00:00 - Intro
00:08 - GTA 6
01:53 - Call of Duty
02:58 - Xbox Games with Gold

## Best Games Of 2022 (So Far)
 - [https://www.youtube.com/watch?v=AvgTlF8kUPM](https://www.youtube.com/watch?v=AvgTlF8kUPM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-07-04 00:00:00+00:00

2022 has been packed full of great games, from huge blockbusters like Elden Ring to smaller titles that might have slipped under your radar.

00:00:00 - Intro
00:00:14 - Neon White
00:00:49 - The Quarry
00:01:20 - Kirby and the Forgotten Land
00:01:50 - Ghostwire: Tokyo
00:02:15 - Horizon: Forbidden West
00:02:45 - Tunic
00:03:21 - Elden Ring
00:03:54 - Stanley Parable: Ultra Deluxe
00:04:20 - Nintendo Switch Sports
00:04:43 - Destiny 2: The Witch Queen
00:05:06 - Nobody Saves The World
00:05:34 - Sniper Elite 5
00:05:54 - TMNT Shredder's Revenge
00:06:25 - Norco
00:06:57 - Monster Hunter Rise
00:07:52 - Outro


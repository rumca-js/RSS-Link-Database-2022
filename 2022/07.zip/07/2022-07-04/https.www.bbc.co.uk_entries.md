## Nigerian Ife head: Why UK police are holding a priceless sculpture - BBC News
 - [https://www.bbc.co.uk/news/world-africa-61826273](https://www.bbc.co.uk/news/world-africa-61826273)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2022-07-04 19:01:48.335883+00:00

Original Ife bronze heads, of which only some 20 survive, are thought to be about 700 years old.


# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## LIVE with Billy Boyd and Dominic Monaghan!
 - [https://www.youtube.com/watch?v=qmphKZCSghs](https://www.youtube.com/watch?v=qmphKZCSghs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-07-05 00:00:00+00:00

We'll be chatting LIVE with Billy Boyd and Dominic Monaghan about Lord of the Rings, their Friendship Onion Podcast, and more!

Check out their Friendship Onion YouTube channel: https://www.youtube.com/channel/UCM2SO69PhFRKKEYwGSV4sHQ

#lordoftherings #billyboyd #dominicmonaghan


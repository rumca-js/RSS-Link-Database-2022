# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Making Movies - Delilah (Live on KEXP)
 - [https://www.youtube.com/watch?v=vL7VF5zkdFM](https://www.youtube.com/watch?v=vL7VF5zkdFM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-05 00:00:00+00:00

http://KEXP.ORG presents Making Movies performing “Delilah” live in the KEXP studio. Recorded June 14, 2022.

Enrique Chi - Guitar / Vocals
Diego Chi - Bass / Vocals
Juan-Carlos Chaurand - Percussion / Keyboard / Vocals
Duncan Burnett - Drums

Host: Chilly
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://www.ilovelucius.com
http://kexp.org

## Making Movies - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=daUqwQC9JUs](https://www.youtube.com/watch?v=daUqwQC9JUs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-05 00:00:00+00:00

http://KEXP.ORG presents Making Movies performing live in the KEXP studio. Recorded June 14, 2022.

Songs:
Delilah
Sala De Los Pecadores
Porcelina
XOPA

Enrique Chi - Guitar / Vocals
Diego Chi - Bass / Vocals
Juan-Carlos Chaurand - Percussion / Keyboard / Vocals
Duncan Burnett - Drums

Host: Chilly
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://www.ilovelucius.com
http://kexp.org

## Making Movies - Porcelina (Live on KEXP)
 - [https://www.youtube.com/watch?v=lwZTgqS5Ivw](https://www.youtube.com/watch?v=lwZTgqS5Ivw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-05 00:00:00+00:00

http://KEXP.ORG presents Making Movies performing “Porcelina” live in the KEXP studio. Recorded June 14, 2022.

Enrique Chi - Guitar / Vocals
Diego Chi - Bass / Vocals
Juan-Carlos Chaurand - Percussion / Keyboard / Vocals
Duncan Burnett - Drums

Host: Chilly
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://www.ilovelucius.com
http://kexp.org

## Making Movies - Sala De Los Pecadores (Live on KEXP)
 - [https://www.youtube.com/watch?v=rok-BgdGNyA](https://www.youtube.com/watch?v=rok-BgdGNyA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-05 00:00:00+00:00

http://KEXP.ORG presents Making Movies performing “Sala De Los Pecadores” live in the KEXP studio. Recorded June 14, 2022.

Enrique Chi - Guitar / Vocals
Diego Chi - Bass / Vocals
Juan-Carlos Chaurand - Percussion / Keyboard / Vocals
Duncan Burnett - Drums

Host: Chilly
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://www.ilovelucius.com
http://kexp.org

## Making Movies - XOPA (Live on KEXP)
 - [https://www.youtube.com/watch?v=yrN0tySqeKg](https://www.youtube.com/watch?v=yrN0tySqeKg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-05 00:00:00+00:00

http://KEXP.ORG presents Making Movies performing “XOPA” live in the KEXP studio. Recorded June 14, 2022.

Enrique Chi - Guitar / Vocals
Diego Chi - Bass / Vocals
Juan-Carlos Chaurand - Percussion / Keyboard / Vocals
Duncan Burnett - Drums

Host: Chilly
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://www.ilovelucius.com
http://kexp.org


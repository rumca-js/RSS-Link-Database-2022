# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Wheel of Time & House of the Dragon Trailers!🐉 Dark Souls book?📖 Fallout Show Image☢️-FANTASY NEWS
 - [https://www.youtube.com/watch?v=ifMwV-J7Zxc](https://www.youtube.com/watch?v=ifMwV-J7Zxc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-07-22 00:00:00+00:00

Let's jump into the fantasy news! 
Check out the always loyal and devoted CAMPFIRE: https://www.campfirewriting.com?utm_source=youtube&utm_medium=video&utm_campaign=DG_Q3_22  


New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene


Merch: https://www.designbyhumans.com/shop/FantasyNews/ 


Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p


Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  


P.O. Box: PO Box 7874 Henrico, VA 23231


00:00 intro
00:40 Fonda Lee cover reveal: https://twitter.com/TorDotComPub/status/1549031315306975234 
01:13 Last Unicorn Special edition: https://store.gollancz.co.uk/products/the-last-unicorn?_pos=1&_sid=a083cfdf2&_ss=r 
01:42 Dark souls Lore: https://kotaku.com/dark-souls-lore-story-books-maps-guide-miyazaki-1849181099 
03:07 House of Dragons First Look: https://www.youtube.com/watch?v=DotnJ7tTA34&ab_channel=HBOMax 
04:15: Campfire: https://www.campfirewriting.com?utm_source=youtube&utm_medium=video&utm_campaign=DG_Q3_22 
05:14 D&D Trailer: https://www.youtube.com/watch?v=_PNTMAEYCQ0&t=6s&ab_channel=RottenTomatoesTrailers 
06:21 Wheel of Time Trailer: https://www.youtube.com/watch?v=S9OKqDS_MC4&ab_channel=IGN 
07:48 Oppenheimer Poster: https://twitter.com/DiscussingFilm/status/1550091069186097153?t=8qDDSo5v2W2XHrXISlpILA&s=19 
08:28 EEAAO Re-release: https://deadline.com/2022/07/everything-everywhere-all-at-once-theatrical-re-relesae-1235072766/ 
08:49 Fallout images: https://www.thegamer.com/fallout-set-image-reveals-super-duper-mart/ 
10:12 Resident Evil Ratings: https://www.nme.com/news/tv/resident-evil-one-of-netflixs-worst-rated-shows-ever-3271752 
11:45 New Alien game: https://twitter.com/DiscussingFilm/status/1547691645365207046

## Awakening to a Nightmare - Berserk Vol. 13 [Part 2] and Vol. 14 [Part 1]
 - [https://www.youtube.com/watch?v=fXeCaL7te1k](https://www.youtube.com/watch?v=fXeCaL7te1k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-07-21 00:00:00+00:00

Let's jump into the aftermath of Eclipse for #berserk. 
This video covers Berserk Deluxe Edition 5 - Vol 13 [Part 2] and Vol 14 [Part 1].
This includes the chapters "Awakening to a Nightmare", "The Sprint", and "Vow of Retaliation" as well as "Demon Infant". 

New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231


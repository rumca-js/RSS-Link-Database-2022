# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Los Bitchos - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=8M3u0Pfg1Ko](https://www.youtube.com/watch?v=8M3u0Pfg1Ko)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-22 00:00:00+00:00

http://KEXP.ORG presents Los Bitchos performing live in the KEXP studio. Recorded June 30, 2022.

Songs:
Lindsay Goes to Mykonos
The Link Is About To Die
Pista (Fresh Start)
Las Panteras

Serra Petale - Guitar / Percussion / Vocals
Agustina Ruiz - Synth / Keytar
Josefine Jonsson - Bass / Percussion
Nic Crawshaw - Drums
Ryan Fitzgibbon - Guitar

Host: Chilly
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Ettie Wahl
Editor: Jim Beckmann

https://losbitchos.com
http://kexp.org

## Los Bitchos - Las Panteras (Live on KEXP)
 - [https://www.youtube.com/watch?v=XitTOCl2LeQ](https://www.youtube.com/watch?v=XitTOCl2LeQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-22 00:00:00+00:00

http://KEXP.ORG presents Los Bitchos performing “Las Panteras” live in the KEXP studio. Recorded June 30, 2022.

Serra Petale - Guitar / Percussion / Vocals
Agustina Ruiz - Synth / Keytar
Josefine Jonsson - Bass / Percussion
Nic Crawshaw - Drums
Ryan Fitzgibbon - Guitar

Host: Chilly
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Ettie Wahl
Editor: Jim Beckmann

https://losbitchos.com
http://kexp.org

## Los Bitchos - Lindsay Goes to Mykonos (Live on KEXP)
 - [https://www.youtube.com/watch?v=6nudHlNOaJo](https://www.youtube.com/watch?v=6nudHlNOaJo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-22 00:00:00+00:00

http://KEXP.ORG presents Los Bitchos performing “Lindsay Goes to Mykonos” live in the KEXP studio. Recorded June 30, 2022.

Serra Petale - Guitar / Percussion / Vocals
Agustina Ruiz - Synth / Keytar
Josefine Jonsson - Bass / Percussion
Nic Crawshaw - Drums
Ryan Fitzgibbon - Guitar

Host: Chilly
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Ettie Wahl
Editor: Jim Beckmann

https://losbitchos.com
http://kexp.org

## Los Bitchos - Pista (Fresh Start) (Live on KEXP)
 - [https://www.youtube.com/watch?v=iWCtaWTDBYg](https://www.youtube.com/watch?v=iWCtaWTDBYg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-22 00:00:00+00:00

http://KEXP.ORG presents Los Bitchos performing “Pista (Fresh Start)” live in the KEXP studio. Recorded June 30, 2022.

Serra Petale - Guitar / Percussion / Vocals
Agustina Ruiz - Synth / Keytar
Josefine Jonsson - Bass / Percussion
Nic Crawshaw - Drums
Ryan Fitzgibbon - Guitar

Host: Chilly
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Ettie Wahl
Editor: Jim Beckmann

https://losbitchos.com
http://kexp.org

## Los Bitchos - The Link Is About To Die (Live on KEXP)
 - [https://www.youtube.com/watch?v=Z9gAOz8F3xc](https://www.youtube.com/watch?v=Z9gAOz8F3xc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-22 00:00:00+00:00

http://KEXP.ORG presents Los Bitchos performing “The Link Is About To Die” live in the KEXP studio. Recorded June 30, 2022.

Serra Petale - Guitar / Percussion / Vocals
Agustina Ruiz - Synth / Keytar
Josefine Jonsson - Bass / Percussion
Nic Crawshaw - Drums
Ryan Fitzgibbon - Guitar

Host: Chilly
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Ettie Wahl
Editor: Jim Beckmann

https://losbitchos.com
http://kexp.org

## Haviah Mighty - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=vyOlvvtt2-Y](https://www.youtube.com/watch?v=vyOlvvtt2-Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-21 00:00:00+00:00

http://KEXP.ORG presents Haviah Mighty performing live in the KEXP studio. Recorded June 29, 2022.

Songs:
In Women Colour
So So
VVS
Protest

Haviah Mighty - Vocals
Dem Ones - DJ

Host: Miss Ashley
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Ettie Wahl
Editor: Scott Holpainen

https://haviahmighty.ca
http://kexp.org

## Haviah Mighty - In Women Colour (Live on KEXP)
 - [https://www.youtube.com/watch?v=6WgwbuTK6aw](https://www.youtube.com/watch?v=6WgwbuTK6aw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-21 00:00:00+00:00

http://KEXP.ORG presents Haviah Mighty performing “In Women Colour” live in the KEXP studio. Recorded June 29, 2022.

Haviah Mighty - Vocals
Dem Ones - DJ

Host: Miss Ashley
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Ettie Wahl
Editor: Scott Holpainen

https://haviahmighty.ca
http://kexp.org

## Haviah Mighty - Protest (Live on KEXP)
 - [https://www.youtube.com/watch?v=vtOxix0rmYY](https://www.youtube.com/watch?v=vtOxix0rmYY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-21 00:00:00+00:00

http://KEXP.ORG presents Haviah Mighty performing “Protest” live in the KEXP studio. Recorded June 29, 2022.

Haviah Mighty - Vocals
Dem Ones - DJ

Host: Miss Ashley
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Ettie Wahl
Editor: Scott Holpainen

https://haviahmighty.ca
http://kexp.org

## Haviah Mighty - So So (Live on KEXP)
 - [https://www.youtube.com/watch?v=agqOZ_tXx9s](https://www.youtube.com/watch?v=agqOZ_tXx9s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-21 00:00:00+00:00

http://KEXP.ORG presents Haviah Mighty performing “So So” live in the KEXP studio. Recorded June 29, 2022.

Haviah Mighty - Vocals
Dem Ones - DJ

Host: Miss Ashley
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Ettie Wahl
Editor: Scott Holpainen

https://haviahmighty.ca
http://kexp.org

## Haviah Mighty - VVS (Live on KEXP)
 - [https://www.youtube.com/watch?v=i_ATJa2jJJU](https://www.youtube.com/watch?v=i_ATJa2jJJU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-21 00:00:00+00:00

http://KEXP.ORG presents Haviah Mighty performing “VVS” live in the KEXP studio. Recorded June 29, 2022.

Haviah Mighty - Vocals
Dem Ones - DJ

Host: Miss Ashley
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Ettie Wahl
Editor: Scott Holpainen

https://haviahmighty.ca
http://kexp.org


# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## Why You're Not Successful
 - [https://www.youtube.com/watch?v=Cfm4KkZB5BU](https://www.youtube.com/watch?v=Cfm4KkZB5BU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2022-07-22 00:00:00+00:00

Which matters more: talent or training? Hard work or circumstance?
Huge thanks to Netflix for sponsoring this episode! The Gray Man is out on July 22, 2022
#TheGrayMan @Netflix 

Join our science mailing list: https://bit.ly/34fWU27

FOLLOW US!
Instagram: https://instagram.com/asapscience​​
Facebook: https://facebook.com/asapscience​​
Twitter: https://twitter.com/asapscience​​
TikTok: @AsapSCIENCE 

Written by: Mitchell Moffit 
Edited by: Luka Šarlija

Sources & Further Reading:

"Range"
Book by: David Epstein
https://davidepstein.com/the-range/

The Sports Gene: Inside the Science of Extraordinary Athletic Performance
Book by: David Epstein
http://thesportsgene.com/


# Source:Moon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg, language:en-US

## Google: The Most Evil Business In The World
 - [https://www.youtube.com/watch?v=mVQ_lNiWJoE](https://www.youtube.com/watch?v=mVQ_lNiWJoE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg
 - date published: 2022-07-22 00:00:00+00:00

Play World of Warships here: https://wo.ws/3cdcQtp
Thank you World of Warships for sponsoring this video.
During registration use the code FIRE to get for free: 200 doubloons, 1 million credits, the Premium Battleship Tier 5 - USS Texas, and 7 Days Premium Account. 
Applicable to new users only.

🟢 Get exclusive access for my private unfiltered controversial videos that can't be released to the public: https://www.youtube.com/c/Moon-Real/join

Support the channel here (all money goes straight back into the channel):
►  Become a Patron:  https://www.patreon.com/MoonReal
► Follow my Twitter: https://twitter.com/MoonRealYT

00:00 - Google's Evil
01:12 - Origins
03:25 - The Rise
06:00 - World of Warships
07:07 - The Dark Turn
12:43 - Censorship
15:38 - Sentient AI


Google is worse than you thought. The Google business model is collapsing making Google trash and its why Google is bad. Google is destroying society with there deep mind ai, google ai is sentient. Along with Google's censorship. This is the rise and fall of Google. Google was a CIA project. This is why I hate google and google's business. This video will be analyse Google and how Google really makes money.


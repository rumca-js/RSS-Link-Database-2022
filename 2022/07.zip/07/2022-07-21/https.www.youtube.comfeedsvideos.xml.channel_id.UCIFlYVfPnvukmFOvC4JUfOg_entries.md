## #23 To już OSTATNIE 2 hajki z @vlogcasha i początek końca tej serii
 - [https://www.youtube.com/watch?v=7yzzq3-23Pw](https://www.youtube.com/watch?v=7yzzq3-23Pw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIFlYVfPnvukmFOvC4JUfOg
 - date published: 2022-07-22 00:00:00+00:00

Zaczynamy w Grand Canyon  a kończymy w Zion. Smutek, rozczarowanie a nawet lekka depresja ale nie poddajemy się i kończymy tę serie z przytupem.
🧗🏻Wesprzyj moje przygody na patronite: https://patronite.pl/Nejtan
📷 Instagram: https://www.instagram.com/nejthan
📜 Napisz do mnie: swiatwedlugnejtana@gmail.com
🎵 Muzyka: https://share.epidemicsound.com/m7uq26

2022 Trip z  @vlogcasha   po Florydzie https://bit.ly/3uueZGV
2021 Trip z  @vlogcasha    po zachodzie Usa i Alaska
https://bit.ly/3D6ClpI
#swiatwedlugnejtana #nejtan


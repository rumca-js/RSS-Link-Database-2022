# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## FREE VR Games for Quest 2 you NEED to Try (+ SteamVR)
 - [https://www.youtube.com/watch?v=0fvGeyqaoyY](https://www.youtube.com/watch?v=0fvGeyqaoyY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-07-21 00:00:00+00:00

I think we're all feelin the VR content draught, but I've been digging for some games that are awesome, but won't destroy your wallet
Here are some of the best FREE VR applications I have found. Of course I added VRChat and RecRoom, both things you can live in forever- but there's about 17 other ones that are simply awesome. This video actually took LONGER than I expected because i was too busy playing them, SO! Go play some free VR Games, all you have to lose is time. 

A lot of these games are either free on SteamVR or are on Oculus App Lab- available for Quest 2, but some of them are straight up store games. All you have to do is search for them! No sideloading needed. 


MY OUTRO MUSIC:
https://youtu.be/u6JwgNQDVfI

MY LINKS:
Discord:
https://discord.gg/2hCGM9BYez
Twitch:
https://www.twitch.tv/thrilluwu
Twitter:
https://twitter.com/Thrilluwu
Patreon:
https://www.patreon.com/Thrillseeker

TIMESTAMPS:
00:00 FREE VR GAMES
01:16 MUST HAVE SOCIAL VR GAMES
03:49 The Free Games- Finally
12:24 Did I miss any?

Links for all of the games:
Rec Room
https://www.oculus.com/deeplink/?action=view&path=app/2173678582678296&ref=oculus_desktop
https://store.steampowered.com/app/471710/Rec_Room/

VRChat
https://www.oculus.com/deeplink/?action=view&path=app/1856672347794301&ref=oculus_desktop
https://store.steampowered.com/app/438100/VRChat/

Gorilla Tag
https://www.oculus.com/deeplink/?action=view&path=app/4979055762136823&ref=oculus_desktop
https://store.steampowered.com/app/1533390/Gorilla_Tag/

Bigscreen
https://www.oculus.com/deeplink/?action=view&path=app/2497738113633933&ref=oculus_desktop
https://store.steampowered.com/app/457550/Bigscreen_Beta/

Battle Talent
https://www.oculus.com/deeplink/?action=view&path=app/4410602018966965&ref=oculus_desktop
https://store.steampowered.com/app/1331510/Battle_Talent/

Pavlov Shack
https://www.oculus.com/deeplink/?action=view&path=app/3649611198468269&ref=oculus_desktop

Liminal
https://www.oculus.com/deeplink/?action=view&path=app/3158342884265828&ref=oculus_desktop
https://store.steampowered.com/app/1453730/Liminal/

Gun Raiders
https://www.oculus.com/deeplink/?action=view&path=app/3982869578392875&ref=oculus_desktop

Open Brush
https://www.oculus.com/deeplink/?action=view&path=app/3600360710032222&ref=oculus_desktop
https://store.steampowered.com/app/1634870/Open_Brush/

Gravity Sketch
https://www.oculus.com/deeplink/?action=view&path=app/1587090851394426&ref=oculus_desktop
https://store.steampowered.com/app/551370/Gravity_Sketch/

Moon Rider
https://moonrider.xyz/

Kizuna AI
https://www.oculus.com/deeplink/?action=view&path=app/3857024597703276&ref=oculus_desktop

Hibow
https://www.oculus.com/deeplink/?action=view&path=app/3687705861311054&ref=oculus_desktop
https://store.steampowered.com/app/737630/Hibow/

Ancient Dungeon
https://www.oculus.com/deeplink/?action=view&path=app/4897577166950223&ref=oculus_desktop
https://store.steampowered.com/app/1125240/Ancient_Dungeon/

Mission ISS
https://www.oculus.com/deeplink/?action=view&path=app/2094303753986147&ref=oculus_desktop

Goliath: Playing With Reality
https://www.oculus.com/deeplink/?action=view&path=app/3432432656819712&ref=oculus_desktop

Echo VR
https://www.oculus.com/deeplink/?action=view&path=app/2215004568539258&ref=oculus_desktop

Tripp
https://www.oculus.com/deeplink/?action=view&path=app/2173576192720129&ref=oculus_desktop

Bait
https://www.oculus.com/deeplink/?action=view&path=app/2082595615120854&ref=oculus_desktop

Gym Class Basketball 
https://www.oculus.com/deeplink/?action=view&path=app/3661420607275144&ref=oculus_desktop

Tea For God 
https://www.oculus.com/deeplink/?action=view&path=app/3762343440541585&ref=oculus_desktop
https://store.steampowered.com/app/1764400/Tea_For_God/#:~:text=Tea%20For%20God%20is%20a,and%20a%20roguelite%20shooter%2Dexplorer


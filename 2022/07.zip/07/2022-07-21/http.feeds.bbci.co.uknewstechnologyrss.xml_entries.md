# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## The YouTuber who built a career from true crime and make-up
 - [https://www.bbc.co.uk/news/business-61948546?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61948546?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-07-21 23:13:41+00:00

Bailey Sarian dabbled in YouTube for years before a chance idea led to a new profession.

## Whisky makers are turning their backs on peat
 - [https://www.bbc.co.uk/news/business-61596047?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61596047?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-07-21 23:05:04+00:00

Burning peat has long been a way of adding flavour to whisky but some are now rejected that process.

## China ride-hailing giant Didi fined $1.2bn after probe
 - [https://www.bbc.co.uk/news/business-62248513?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62248513?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-07-21 06:59:51+00:00

The country's cyber security watchdog launched a probe into the firm just days after its US listing.

## Elon Musk's Tesla sells most of its Bitcoin holdings
 - [https://www.bbc.co.uk/news/business-62246367?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62246367?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-07-21 03:07:55+00:00

The announcement comes as the value of the world's biggest cryptocurrency has plunged.


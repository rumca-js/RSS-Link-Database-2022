# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## The M2 MacBook Air Is Compromised
 - [https://www.youtube.com/watch?v=R2R_63XhFjM](https://www.youtube.com/watch?v=R2R_63XhFjM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2022-07-22 00:00:00+00:00

The new M2 MacBook Air is being heralded for its new design and cutting-edge performance. But it doesn't come without some compromises—and I question if Apple couldn't have done more. Is Apple playing things too safe now?

Pick up an M2 MacBook Air - https://amzn.to/3B9Kz1E
Pick up an M1 MacBook Air - https://amzn.to/3RVgxof
Pick up some Apple accessories to support the channel - https://amzn.to/3ojJX1N

Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq


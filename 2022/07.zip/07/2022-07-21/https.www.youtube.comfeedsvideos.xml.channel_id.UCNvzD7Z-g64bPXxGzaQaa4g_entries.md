# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## UBISOFT CANCELS 4 GAMES, BIG NEW MMO ANNOUNCED & MORE
 - [https://www.youtube.com/watch?v=m3u8K1WAjIE](https://www.youtube.com/watch?v=m3u8K1WAjIE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-07-22 00:00:00+00:00

Sponsored by Casetify. Level up your tech accessories with Casetify! Go to http://www.casetify.com/gameranx today to save 15% off your order!

A bunch of updates on Ubisoft games, a great new PlayStation exclusive, a new feature coming to Xbox, and more in a week full of gaming news.

Jake on Instagram: https://bit.ly/3uUh9Ot

Jake on twitter: https://bit.ly/3gdkPqD​​​​




 ~~~~STORIES~~~~




Ubisoft cancels 4 games
https://www.gamespot.com/articles/ubisoft-cancels-four-games-including-splinter-cell-vr-and-ghost-recon-frontline/1100-6505722/

AC Japan update
https://www.gamespot.com/articles/assassins-creed-game-project-red-revealed-in-leak-may-be-set-in-asia-and-included-with-infinity/1100-6505734/?ServiceType=facebook_page&TheTime=2022-07-21T20%3A39%3A58&ftag=GSS-05-10aaa0a&UniqueID=49349420-0935-11ED-9E6E-31C3923C408C&PostType=link&fbclid=IwAR2--6AHATDYRrUyKdaQsE7azST-jkaGUPkMQdReQd5ucdDu1oXkUcSG9W0

Last of Us Part 1 new
https://youtu.be/uRKIWQUucj0


Soulframe (fantasy MMO melee combat)
https://youtu.be/rrMGRvuxsuA


No Man’s Sky update ‘Endurance’
https://youtu.be/JSvwcneTNu4

Gotham Knights batgirl trailer 
https://youtu.be/M7auo0Mpzns


Live A Live
https://youtu.be/ufcRP8MIjFY

As Dusk Falls
https://youtu.be/CJMMit46-Us

Stray
https://youtu.be/-Wj479wiMg8



PlayStation Plus Extra and Premium now have seven-day free trial
https://www.eurogamer.net/playstation-plus-extra-and-premium-now-have-seven-day-free-trial

Next gears of War
https://www.tweaktown.com/news/87496/new-gears-of-war-game-in-development-at-the-coalition-may-be-6/index.html


Discord Xbox
https://www.ign.com/articles/xbox-discord-voice-integration-announced

Minecraft dunks NFTs
https://www.theverge.com/2022/7/20/23272152/minecraft-mojang-blocks-rejects-nfts


Mortal Kombat movie sequel
https://deadline.com/2022/07/mortal-kombat-sequel-simon-mcquoid-1235073203/

## 10 HARDEST Elden Ring Bosses That Require Incredible Skill
 - [https://www.youtube.com/watch?v=kMsCGpTqcc0](https://www.youtube.com/watch?v=kMsCGpTqcc0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-07-21 00:00:00+00:00

Elden Ring (PC, PS5, PS4, Xbox Series X/S/One) is basically the king of bosses. Here are some of the most challenging.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro 
0:13 Margit, The Fell Omen
2:02 Fire Giant
4:02 Starscourge Radahn
6:06 Full-grown Fallingstar Beast
7:29 Mohg, Lord of Blood
9:12 Astel, Naturalborn of the Void
10:18 Godfrey, First Elden Lord / Hoarah Loux
11:28 Godskin Duo
12:57 Radagon of the Golden Order / Elden Beas
14:20 Malenia, Blade of Miquella


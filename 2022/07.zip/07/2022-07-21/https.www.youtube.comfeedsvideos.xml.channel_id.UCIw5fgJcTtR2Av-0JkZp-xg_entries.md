# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## "Cowbell Fever" (now with MORE COWBELL)
 - [https://www.youtube.com/watch?v=PoDbOCC7VG4](https://www.youtube.com/watch?v=PoDbOCC7VG4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2022-07-22 00:00:00+00:00

You asked for it.
Support my music on Patreon: https://www.patreon.com/yuriwong 
Created on @teenageengineering OP-1
and completed in Logic Pro X using stock plugins and instruments.

"“I got a fever, and the only prescription is more cowbell.”


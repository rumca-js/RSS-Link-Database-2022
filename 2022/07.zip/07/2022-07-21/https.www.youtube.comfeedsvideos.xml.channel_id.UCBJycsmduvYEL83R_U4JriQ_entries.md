# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Google Pixel 6A Review: Can You Feel It?
 - [https://www.youtube.com/watch?v=UsD87v8F914](https://www.youtube.com/watch?v=UsD87v8F914)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-07-21 00:00:00+00:00

Pixel 6A is Google's new budget option with one looming flaw.

Giving the Pixel a second chance: https://youtu.be/MiTG1ride7s
Dress up your smartphone with dbrand at http://dbrand.com/ninja-pixels
Buy the Google Pixel 6a from our affiliates at https://geni.us/tZlGtax

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds: https://lnk.to/jordynedmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Google for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Oops, China learned how to make good chips
 - [https://www.youtube.com/watch?v=m9UfaY69bxA](https://www.youtube.com/watch?v=m9UfaY69bxA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2022-07-22 00:00:00+00:00

Visit https://brilliant.org/TFC/ to get started learning STEM for free, and the first 200 people will get 20% off their annual premium subscription - Sponsored by Brilliant.
 
 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  
 
►►► This video ◄◄◄  
 
This week Qualcomm announced new 4nm wearable chips called the Snapdragon W5 Gen 1 and W5+ Gen 1,  Sony and Minecraft's Mojang said no to NFTs, and China's SMIC chip fab shipped 7nm bitcoin miners with a process they copied from TSMC, potentially overtaking the US & EU.
 
Episode 106
 
This video on Nebula: https://nebula.app/videos/the-friday-checkout-oops-china-learned-how-to-make-good-chips

Pixel Review (Kilian's channel, Orbit): https://www.youtube.com/watch?v=aNagPzyVias
LTT Intel GPUs: https://www.youtube.com/watch?v=45n5pnEyw9o&t=270s
Asianometry 7nm EUV: https://www.youtube.com/watch?v=Th4E-0VFaEA&t=40s
 
 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  
 
►►► TechAltar links ◄◄◄  
 
Merch:  
http://enthusiast.store   
 
Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  
 
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
 
►►► Attributions & Time stamps◄◄◄
 
Writing & Research: Tristan Rayner
Music by Edemski: https://soundcloud.com/edemski 
 
0:00 Intro
0:22 Release highlights
2:36 Qualcomm wearable chips
5:03 No to NFTs
6:12 7nm Chinese chips!


# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## Google wants to REPLACE LINUX?, GNOME 43, and Unreal Engine on Linux  - Linux and Open Source News
 - [https://www.youtube.com/watch?v=KoncJlonKSQ](https://www.youtube.com/watch?v=KoncJlonKSQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2022-07-21 00:00:00+00:00

Get 100$ credit for your own Linux and gaming server: https://www.linode.com/linuxexperiment 
Grab a brand new laptop or desktop running Linux:https://www.tuxedocomputers.com/


👏 SUPPORT THE CHANNEL:
Get access to a weekly podcast, vote on the next topics I cover, and get your name in the credits:

YouTube: https://www.youtube.com/channel/UC5UAwBUum7CPN5buc-_N1Fw/join
Patreon: https://www.patreon.com/thelinuxexperiment

Or, you can donate whatever you want: https://paypal.me/thelinuxexp?locale.x=fr_FR

📹 MORE VIDEOS FROM ME
Linux news in Shorts format: https://www.youtube.com/channel/UCtZp0mK9IBrpS2-jNzMZmoA
Gaming on Linux: https://www.youtube.com/channel/UCaw_Lz7oifDb-PZCAcZ07kw
I'm also on ODYSEE: https://odysee.com/$/invite/@TheLinuxExperiment:e

🏆 FOLLOW ME ELSEWHERE:
Twitter : http://twitter.com/thelinuxEXP
Mastodon: https://mastodon.social/web/@thelinuxEXP
Pixelfed: https://pixelfed.social/TLENick
Discord: https://discord.gg/xK7ukavWmQ

📷 GEAR I USE:
Sony Alpha A6600 Mirrorless Camera: https://amzn.to/30zKyn7
Sigma 56mm Fixed Prime Lens: https://amzn.to/3aRvK5l
Logitech MX Master 3 Mouse: https://amzn.to/3BVI0Od
Bluetooth Space Grey Mac Keyboard: https://amzn.to/3jcJETZ
Logitech Brio 4K Webcam: https://amzn.to/3jgeTh9
LG Curved Ultrawide Monitor: https://amzn.to/3pcTVDH
Logitech White Speakers: https://amzn.to/3n6wSb0
Xbox Controller: https://amzn.to/3BWmIA3
*Amazon Links are affiliate codes and generate small commissions to support the channel*

This video is distributed under the Creative Commons Share Alike license.

#linux #opensource #news

00:00 Intro
00:44 100$ free credit for your own Linux or Gaming server
01:42 Fuchsia will run Linux and Android binaries to replace Linux
02:54 Rocky Linux 9 is released
04:07 ChromeOS Flex is now available for every PC or Mac
05:06 GNOME 43 alpha is out
06:21 Huge week for GNOME, with tons of updates
07:54 KDE Weekly Updates
08:56 Epic Games joins the Open3D Foundation
10:00 Unreal Engine now has a binary download for Linux
11:10 Bottles moves to Soda, their own fork of Proton
12:21 Ayaneo launches their own linux based gaming OS
13:32 4000 games on Deck, temps warning, Steam on Teslas, and Wine
15:04 Grab a laptop or desktop that's fully Linux compatible
16:11 Support the channel




Fuchsia, Google's new OS, might replace Linux on their devices, as it's stated to run Android and Linux apps
https://9to5google.com/2022/07/15/android-removes-fuchsia-code-starnix/

Rocky Linux 9 was released
https://rockylinux.org/news/rocky-linux-9-0-ga-release/

Google released ChromeOS Flex for all PCs
https://www.theverge.com/2022/7/14/23215019/google-chrome-os-flex-operating-system-pc-mac-available

GNOME 43 alpha is out now
https://9to5linux.com/gnome-43-alpha-released-to-kick-off-guadec-2022-in-guadalajara-mexico

Big GNOME updates to libadwaita, GTK, and their core apps
https://thisweek.gnome.org/posts/2022/07/twig-52/

KDE updates Dolphin and a lot of other apps
https://pointieststick.com/2022/07/15/this-week-in-kde-some-nice-improvements/

Epic Games joins the Open3D foundation board
https://www.linux.com/news/the-open-3d-foundation-welcomes-epic-games-as-a-premier-member-to-unleash-the-creativity-of-artists-everywhere/

Unreal Engine now has a Linux binary
https://www.gamingonlinux.com/2022/07/unreal-engine-5-editor-quietly-gets-a-proper-linux-version/

Bottles moves to Soda, their own proton fork
https://www.gamingonlinux.com/2022/07/wine-manager-bottles-default-runner-now-based-on-valves-wine-fork-and-proton/

Ayaneo annonces AyaneoOS, based on Linux
https://www.gamingonlinux.com/2022/07/ayaneo-to-have-their-own-ayaneo-os-based-on-linux/


4000 games on Deck, Valve issues temperature warnings for the Deck warning, Steam on Teslas, and Wine 7.13
https://www.gamingonlinux.com/2022/07/steam-deck-hits-over-4000-titles-marked-either-verified-or-playable/

https://www.gamingonlinux.com/2022/07/valve-warns-about-steam-deck-temperatures-plus-a-deck-beta-update-out/

https://www.gamingonlinux.com/2022/07/tesla-to-demo-steam-for-more-in-car-gaming-soon-using-linux-proton/

https://www.winehq.org/announce/7.13


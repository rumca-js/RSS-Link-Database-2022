# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## LIVE from Comic-Con! Talking Tolkien, Rings of Power, & More!
 - [https://www.youtube.com/watch?v=PN1zUiyEj_Y](https://www.youtube.com/watch?v=PN1zUiyEj_Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-07-22 00:00:00+00:00

I'll be streaming LIVE from theonering.net's party at San Diego Comic-Con to breakdown the Rings of Power panel, Middle-earth sights from SDCC, and more!

#sdcc #comiccon #lordoftherings

## Rings of Power SDCC Trailer BREAKDOWN | Lord of the Rings on Prime
 - [https://www.youtube.com/watch?v=FmDMm-wWK6I](https://www.youtube.com/watch?v=FmDMm-wWK6I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-07-22 00:00:00+00:00

We have ANOTHER trailer for Rings of Power!  I was in the SDCC crowd at Hall H to experience it (and other things) live.  I'll talk about those other clips on tonight's stream, but here's my breakdown of the trailer itself!

#theringsofpower #lordoftherings #lotronprime


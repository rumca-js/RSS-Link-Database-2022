# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Craig Finn – Due To Depart (Live at The Current)
 - [https://www.youtube.com/watch?v=t1JQu1Cb6yk](https://www.youtube.com/watch?v=t1JQu1Cb6yk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-07-22 00:00:00+00:00

After releasing "A Legacy of Rentals" — his fifth solo album — in May of this year, Craig Finn is now on tour in support of the record. Watch Craig Finn and the Uptown Controllers perform "Due To Depart" from the new album. 

Personnel
Craig Finn – vocals
Paul “Falcon" Valdez – drums
Patrick Doyle – guitar
Joseph Faught – bass
Nelson Devereaux – saxophone

Credits
Host – Ayisha Jaffer
Guest – Craig Finn 
Technical director – Evan Clark
Producer – Derrick Stevens
Digital producer – Luke Taylor 

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#craigfinn #steadycraig #thecurrent

## Bombino – Adounia (Live at Rock the Garden 2022)
 - [https://www.youtube.com/watch?v=YWFLDfXrX1s](https://www.youtube.com/watch?v=YWFLDfXrX1s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-07-21 00:00:00+00:00

Watch Bombino and his band performing "Adounia" from their set recorded live at Rock the Garden 2022 in Minneapolis.

Personnel
Bombino – lead guitar
Youba Dia – bass
Kawisan Mohammed – rhythm guitar
Corey Wilhelm – drums

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#bombino #rockthegarden #adounia


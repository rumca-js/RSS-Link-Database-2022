# Source:Cercle, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ, language:en-US

## Hania Rani live at Invalides, in Paris, France for Cercle
 - [https://www.youtube.com/watch?v=J5oZ80Daduc](https://www.youtube.com/watch?v=J5oZ80Daduc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ
 - date published: 2022-07-21 14:00:12+00:00

Hania Rani playing live from the royal courtyard of the Invalides, in Paris, France for Cercle. 

☞ Support us and get access to exclusive videos & perks: https://Cercle.lnk.to/Patreon
☞ Listen to our playlists, tracks & sets: https://Cercle.lnk.to/Playlists
☞ Subscribe to our newsletter to know about our next shows: https://Cercle.lnk.to/Members
☞ Subscribe to our YouTube channel: https://Cercle.lnk.to/ytcercle

☞  Cercle Records
WhoMadeWho - Abu Simbel (Hania Rani Invalides version): https://Cercle.lnk.to/abusimbelhaniarani

☞  Hania Rani
https://open.spotify.com/artist/14YzutUdMwS9yTnI0IFBaD

48°51'23.6"N 2°18'45.6"E

Video credits:

Artist: Hania Rani
Band: Ziemowit Klimek, Wojciech Warmijak, Adam Jełowick, Kacper Krupa, Jarosław Kawałek
Venue: Cour d’Honneur des Invalides, France
Produced by Cercle
Executive producers: Derek Barbolla & Philippe Tuchmann
Film directed by: Pol Souchier & Derek Barbolla
Director of photography & Post-production: Mathieu Glissant (Saison Unique Production)
Cameramen: Mathieu Glissant, Mickaël Fidjili, Quentin Souchier, Jérémie Tridard, Augustin Thai
Production team: Anaïs De Framond, Dan Aufseesser, Armand Prouhèze
Technical Manager: Aurélien Moisan
Sound (onsite): Timothée Renard, Kévin de Waard
Live sound engineer / recording: Agata Dankowska
Monitor engineer / recording / mix & master: Maciej Kuśnierz
Lights: Gauthier Guerisse, Quentin Enguerrand
Photo: Maxime Chermat, Geoffrey Hubbel
Regie: Yan Karpinski, Patrick Demangue, Laurent Isnard
Communication: Pol Souchier, Lola Lebrati and Emie Monnier
Graphic Design: Anaëlle Rouquette
Label Manager: Clémence Maillard
Finance: Andy Cheremond, Kevin Benisty


______

Official Partners: 
Hotel des Invalides
Musée de l’Armée
Eau Neuve


Special thanks to:
Le général de corps d’armée Christophe Abad, gouverneur militaire de Paris
Le général de division Henry de Medlege, directeur du musée de l’Armée
Carlo Garrè
Monika Ignaczewska
Stéphanie Froger
Julien Cohen-Tanugi
Julie Brisset
Jean Flute
Hugo Feret
Fabrice Marchand
Ludovic Bouchard
Gondwana Records
WhoMadeWho

Hania Rani Appears courtesy of Gondwana Records
______

This artistic performance has been recorded live.

Tracklist:

00:00:00 I'll Never Find Your Soul - Hania Rani 
00:12:16 Esja
00:20:35 Tennen - Hania Rani
00:27:52 Leaving - Hania Rani 
00:33:24 Buka - Hania Rani 
00:39:58 Ghosts - Hania Rani
00:44:22 Unreleased
00:48:11 WhoMadeWho - Abu Simbel (Hania Rani Invalides Version)
00:54:53 Zero Hour - Hania Rani
01:02:29 Come Back Home - Hania Rani
01:08:00 Hawaii Oslo - Hania Rani
01:14:20 Come Back Home - Hania Rani
01:20:16 Don’t Break My Heart - Hania Rani 
01:26:29 Interview 

______

Follow us on http://www.cercle.io


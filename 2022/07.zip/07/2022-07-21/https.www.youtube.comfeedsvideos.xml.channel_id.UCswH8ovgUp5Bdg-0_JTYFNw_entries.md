# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## We Are F*cked
 - [https://www.youtube.com/watch?v=xTn5tqSJC30](https://www.youtube.com/watch?v=xTn5tqSJC30)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-07-22 00:00:00+00:00

Is censorship in the US now worse than it is in Russia? I spoke to legendary philosopher Noam Chomsky about censorship under the present government, and how the pandemic and the war in Ukraine has highlighted its creep. #media #cnn #chomsky 
--------------------------------------------------------------------------------------------------------------------------
Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Vandana Shiva: “THIS Is How We Beat The Great Reset"
 - [https://www.youtube.com/watch?v=pJzbdcHQ4-A](https://www.youtube.com/watch?v=pJzbdcHQ4-A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-07-21 00:00:00+00:00

Renowned environmental activist and author, Vandana Shiva, joined me at our first ever live  community event in Hay-On-Wye. We spoke about how the mainstream media have framed the Dutch Farmer protests, the hidden land grab agenda and how data is not the highest evidence for living, a good healthy body is!
--------------------------------------------------------------------------------------------------------------------------
Register for The Free Prescreening of ‘The Seeds Of Vandana Shiva’ here: https://core.live/movies/the-seeds-of-vandana-shiva
--------------------------------------------------------------------------------------------------------------------------
Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Pizza Party!!!! Modular Performance (Sweaty)
 - [https://www.youtube.com/watch?v=oVJIMuQwqF4](https://www.youtube.com/watch?v=oVJIMuQwqF4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2022-07-22 00:00:00+00:00

Watch the walkthrough of this rack here: https://youtu.be/VPThzPF2oZ4

This is my pizza party rack, based around the Bastl Pizza oscillator, TC Helicon Perform VE, and Roland TR-8s. I have a show coming up at the Ice Box Arcade in Seattle on July 26th with EZBOT and Mikey303 and you should come because this is what I'm doing and it's pretty fun and there are games and friends. Hope you enjoy my hot pizza sweats. Come see this live at Ice Box Arcade in Fremont on the 26th of July 2022 at 7pm if you're nasty.

Gear in this video (affiliate links that help the channel!):

Pamela's New Workout: https://shrsl.com/38qt7
XAOC Moska: https://bit.ly/3wLmmZZ
Erica Synths Sample Drum: https://shrsl.com/38qtl
Mutable Instruments Plaits: https://bit.ly/3sGjDi1
Mutable Instruments Tides: https://shrsl.com/3lb6n
Mutable Instruments Stages: https://bit.ly/2UuhQRz
Bastl Pizza: https://shrsl.com/3lb6q
Bastl Ikarie: https://bit.ly/3wjn6qm
NANO Quart: https://bit.ly/3OUAYPU
VPME Euclidian Circles: https://bit.ly/3QW5dHU
WMD Arpitecht: https://shrsl.com/3lb6s 
Qu-Bit Prism: https://shrsl.com/38qws
Tip Top Z5000: https://shrsl.com/3c0xr
Make Noise Mimeophon: https://bit.ly/3yYFyW5
TC Helicon Perform VE: https://amzn.to/3v2KUzk
Roland TR8s: https://amzn.to/3b0xH2S

00:00 hello
00:47 01
04:39 02
07:36 03
10:16 04
14:30 05
18:51 06
22:54 07
27:00 08
29:12 09
33:09 10
36:42 11

Join me on Patreon and get access to music, presets, samples, and a great community.
Join Patreon:  http://bit.ly/rmrpatreon

Find my music here: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
YouTube Music: https://bit.ly/3PZQ4ol
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia


# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Ksiądz gra w grę || A Plague Tale: Innocence [06] Wielorakie zło
 - [https://www.youtube.com/watch?v=C4E0Qgshd8w](https://www.youtube.com/watch?v=C4E0Qgshd8w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-22 00:00:00+00:00

​@Langustanapalmie     #ksiadzgrawgre #ksiądzgrawgrę #aplaguetaleinnocence 

________________________________________
NIENASYCENI 
☞ Tauron Arena Kraków
☞ 6 października 2022 r. 

BILETY ☞ https://bit.ly/Nienasyceni_Tauron
WYDARZENIE ☞ https://fb.me/e/1WzTzhC1Q
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Judyty || Rozdział 11
 - [https://www.youtube.com/watch?v=hl4M-17-vnM](https://www.youtube.com/watch?v=hl4M-17-vnM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-22 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## NIESZCZĘŚNI [#10] Jak przyjąć i ofiarować cierpienie
 - [https://www.youtube.com/watch?v=GBg3UoVcy04](https://www.youtube.com/watch?v=GBg3UoVcy04)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-22 00:00:00+00:00

Tekstem na dziś jest Męka Pana Jezusa. Zajrzyj do opisu Męki Pańskiej w dowolnej z Ewangelii.

Zdjęcia i montaż: Marcin Jończyk
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#1151] Tęsknota
 - [https://www.youtube.com/watch?v=LIwsi86GDyc](https://www.youtube.com/watch?v=LIwsi86GDyc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-22 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
NIENASYCENI 
☞ Tauron Arena Kraków
☞ 6 października 2022 r. 

BILETY ☞ https://bit.ly/Nienasyceni_Tauron
WYDARZENIE ☞ https://fb.me/e/1WzTzhC1Q
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ksiądz gra w grę || Stray [01] Samotność pokonana
 - [https://www.youtube.com/watch?v=-DNohA5-rm4](https://www.youtube.com/watch?v=-DNohA5-rm4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-21 00:00:00+00:00

@langustanapalmie #ksiadzgrawgre #ksiądzgrawgrę #stray 
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Judyty || Rozdział 10
 - [https://www.youtube.com/watch?v=BYSyzI_qezw](https://www.youtube.com/watch?v=BYSyzI_qezw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-21 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## NIESZCZĘŚNI [#09] Złamane serce
 - [https://www.youtube.com/watch?v=NZ-Q4nx9d8Y](https://www.youtube.com/watch?v=NZ-Q4nx9d8Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-21 00:00:00+00:00

PIĄTKOWA seria w czwartek, czyli przypomnienie i seria dla NIESZCZĘSNYCH.

[J 4, 1-42) 
A kiedy Pan dowiedział się, że faryzeusze usłyszeli, iż Jezus pozyskuje sobie więcej uczniów i chrzci więcej niż Jan - chociaż w rzeczywistości sam Jezus nie chrzcił, lecz Jego uczniowie - opuścił Judeę i odszedł znów do Galilei. Trzeba Mu było przejść przez Samarię. Przybył więc do miasteczka samarytańskiego, zwanego Sychar, w pobliżu pola, które [niegdyś] dał Jakub synowi swemu, Józefowi.  Było tam źródło Jakuba. Jezus zmęczony drogą siedział sobie przy studni. Było to około szóstej godziny. Nadeszła [tam] kobieta z Samarii, aby zaczerpnąć wody. Jezus rzekł do niej: «Daj Mi pić!» Jego uczniowie bowiem udali się przedtem do miasta dla zakupienia żywności. Na to rzekła do Niego Samarytanka: «Jakżeż Ty będąc Żydem, prosisz mnie, Samarytankę, bym Ci dała się napić?» Żydzi bowiem z Samarytanami unikają się nawzajem.  Jezus odpowiedział jej na to: «O, gdybyś znała dar Boży i [wiedziała], kim jest Ten, kto ci mówi: "Daj Mi się napić" - prosiłabyś Go wówczas, a dałby ci wody żywej».  Powiedziała do Niego kobieta: «Panie, nie masz czerpaka, a studnia jest głęboka. Skądże więc weźmiesz wody żywej?  Czy Ty jesteś większy od ojca naszego Jakuba, który dał nam tę studnię, z której pił i on sam, i jego synowie i jego bydło?» W odpowiedzi na to rzekł do niej Jezus: «Każdy, kto pije tę wodę, znów będzie pragnął.  Kto zaś będzie pił wodę, którą Ja mu dam, nie będzie pragnął na wieki, lecz woda, którą Ja mu dam, stanie się w nim źródłem wody wytryskającej ku życiu wiecznemu». Rzekła do Niego kobieta: «Daj mi tej wody, abym już nie pragnęła i nie przychodziła tu czerpać». A On jej odpowiedział: «Idź, zawołaj swego męża i wróć tutaj!» A kobieta odrzekła Mu na to: «Nie mam męża». Rzekł do niej Jezus: «Dobrze powiedziałaś: Nie mam męża. Miałaś bowiem pięciu mężów, a ten, którego masz teraz, nie jest twoim mężem. To powiedziałaś zgodnie z prawdą». Rzekła do Niego kobieta: «Panie, widzę, że jesteś prorokiem. Ojcowie nasi oddawali cześć Bogu na tej górze, a wy mówicie, że w Jerozolimie jest miejsce, gdzie należy czcić Boga». Odpowiedział jej Jezus: «Wierz Mi, kobieto, że nadchodzi godzina, kiedy ani na tej górze, ani w Jerozolimie nie będziecie czcili Ojca. Wy czcicie to, czego nie znacie, my czcimy to, co znamy, ponieważ zbawienie bierze początek od Żydów. Nadchodzi jednak godzina, owszem już jest, kiedy to prawdziwi czciciele będą oddawać cześć Ojcu w Duchu i prawdzie, a takich to czcicieli chce mieć Ojciec. Bóg jest duchem: potrzeba więc, by czciciele Jego oddawali Mu cześć w Duchu i prawdzie». Rzekła do Niego kobieta: «Wiem, że przyjdzie Mesjasz, zwany Chrystusem. A kiedy On przyjdzie, objawi nam wszystko». Powiedział do niej Jezus: «Jestem nim Ja, który z tobą mówię». Na to przyszli Jego uczniowie i dziwili się, że rozmawiał z kobietą. Jednakże żaden nie powiedział: «Czego od niej chcesz? - lub: - Czemu z nią rozmawiasz?» Kobieta zaś zostawiła swój dzban i odeszła do miasta. I mówiła tam ludziom: «Pójdźcie, zobaczcie człowieka, który mi powiedział wszystko, co uczyniłam: Czyż On nie jest Mesjaszem?» Wyszli z miasta i szli do Niego. Tymczasem prosili Go uczniowie, mówiąc: «Rabbi, jedz!» On im rzekł: «Ja mam do jedzenia pokarm, o którym wy nie wiecie». Mówili więc uczniowie jeden do drugiego: «Czyż Mu kto przyniósł coś do zjedzenia?» Powiedział im Jezus: «Moim pokarmem jest wypełnić wolę Tego, który Mnie posłał, i wykonać Jego dzieło.  Czyż nie mówicie: "Jeszcze cztery miesiące, a nadejdą żniwa?" Oto powiadam wam: Podnieście oczy i popatrzcie na pola, jak bieleją na żniwo. Żniwiarz otrzymuje już zapłatę i zbiera plon na życie wieczne, tak iż siewca cieszy się razem ze żniwiarzem. Tu bowiem okazuje się prawdziwym powiedzenie: Jeden sieje, a drugi zbiera. Ja was wysłałem żąć to, nad czym wyście się nie natrudzili. Inni się natrudzili, a w ich trud wyście weszli». Wielu Samarytan z owego miasta zaczęło w Niego wierzyć dzięki słowu kobiety świadczącej: «Powiedział mi wszystko, co uczyniłam». Kiedy więc Samarytanie przybyli do Niego, prosili Go, aby u nich pozostał. Pozostał tam zatem dwa dni.  I o wiele więcej ich uwierzyło na Jego słowo, a do tej kobiety mówili: «Wierzymy już nie dzięki twemu opowiadaniu, na własne bowiem uszy usłyszeliśmy i jesteśmy przekonani, że On prawdziwie jest Zbawicielem świata». 


@Langustanapalmie 
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

Zapraszamy.

## Wstawaki [#1150] Charlie
 - [https://www.youtube.com/watch?v=MT_8Yq9tcXg](https://www.youtube.com/watch?v=MT_8Yq9tcXg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-21 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
NIENASYCENI 
☞ Tauron Arena Kraków
☞ 6 października 2022 r. 

BILETY ☞ https://bit.ly/Nienasyceni_Tauron
WYDARZENIE ☞ https://fb.me/e/1WzTzhC1Q
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.


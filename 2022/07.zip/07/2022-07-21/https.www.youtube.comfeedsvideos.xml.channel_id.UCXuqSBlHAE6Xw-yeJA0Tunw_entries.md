# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Overpriced Computers! - WAN Show July 22, 2022
 - [https://www.youtube.com/watch?v=WiKmNbPLNh8](https://www.youtube.com/watch?v=WiKmNbPLNh8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-07-22 00:00:00+00:00

Check out Corsair's HS65 Surround Wired Gaming Headset at https://lmg.gg/HS65WAN

Get 50% off (up to $200) your annual Zoho Desk subscription at: https://lmg.gg/zohodeskwan (US Only)

Immerse yourself in Quill’s newest adventures in the enhanced version of Moss: Book II now available on the META Quest 2 VR headset at: https://lmg.gg/MOSS

WHALE LAN Event Tickets: https://lmg.gg/YXc4U

Podcast Download: TBD

Timestamps (Thanks NoKi1119: 

0:00 Chapters.
1:13 Intro.
1:48 Superchats and bits are ignored, use merch messages.
2:22 Topic #1: OverKill computers, now with financing...
    3:53 Reviewing computer projects and configurator.
    6:40 Project "Unknown", custom request form & pricing.
   8:16 Comparing to Maingear, cooling, colors & configs.
   12:50 Maingear's pricing to upgrade SSD.
    15:40 Linus's system specfication, comparing to OverKill.
   17:02 Linus on the costs of watercooling.
   19:48 TikTokker compares pricing to expensive companies.
   22:20 OverKill's response, customers on delays & NDA.
   25:20 OverKill PC giveaways on patreon; is it a lottery?
   26:46 OverKill sends a cease & desist to a TikTokker.
   27:48 Marine vet of OverKill goes on TikTok.
   30:32 A neutral take on the system integrator & website.
   32:56 Alex's notes on the topic, mentioning Intel.
34:02 Topic #2: Discord & voice chatting is now on Xbox.
   36:22 Luke on not supporting APIs for third-party apps.
   38:46 Cross-playing, browser apps are not native apps.
40:02 Merch Messages #1 ft. Colton.
   40:16 Biggest ask from the 40 series cards.
   42:18 Thoughts on LMG Autobench going open-source.
   45:30 Labs expectation, success and failure.
   47:02 Products besides the socks to be excited about.
   48:50 LTTStore Linus sandals idea.
   49:40 Labs data & sphere of influence.
52:28 LTTStore swim trunks, a great photo shoot.
   55:20 LTTStore mystery cable ties, backpack reviews.
   59:04 Verification for the backpack.
1:00:34 Merch Messages #2.
   1:00:44 Pick for a competition game for Whale LAN.
   1:03:56 LMG dedicated workshop for maker content idea.
    1:05:14 Unbiased benchmark reviews for vacuums idea.
   1:07:03 Luke's future if he didn't go to NCIX.
   1:10:50 Linus owes The Spiffing Bret a tea-powered PC.
   1:13:30 Linus not able to watch Backstreet Boys live.
   1:14:30 Intel ARC for Linux as a good value.
1:15:32 Sponsors.
   1:15:56 Corsair HS65 surround wired headset.
   1:17:03 Zoho Desk CRM customer service.
   1:17:52 PolyArc ft. Linus screwing up the spot.
1:18:40 Merch Messages #3.
   1:19:10 What infuriates Linus.
   1:20:26 WAN topics that stand out, IRL rocket league.
   1:22:32 Linus's favorite type of cheese.
Cont. Sponsors.
   1:23:48 PolyArc Moss: Book II on Meta Quest 2.
1:24:56 Topic #3: Hive "fights" climate change via e-waste.
1:27:58 Topic #4: FUTO on taking back control of PCs.
   1:30:35 FUTO's projects, GrapheneOS.
1:32:36 Topic #5: Robot dog with an assault rifle.
   1:35:26 Discussing modern warfare.
1:36:28 Topic #6: Emails with allegations against Linus.
   1:38:26 Linus's reply & his relationship history.
1:44:42 Merch Messages #4.
   1:44:50 Plans for AddOns on the LTTStore backpack.
   1:46:20 Testing desk-mats & tempered glass.
   1:47:12 Plans to collaborate with GN & Labs.
   1:48:44 Display cable testing incorporated into Labs.
   1:50:11 Colton reads a curated message to himself.
   1:50:56 Favorite game franchise.
1:51:48 Outro.

## I’m a Genius - Apple Self Service Repair Program
 - [https://www.youtube.com/watch?v=mdYzVaC6HSQ](https://www.youtube.com/watch?v=mdYzVaC6HSQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-07-21 00:00:00+00:00

Try Vultr today with an exclusive 30-day $150 code for signing up at https://getvultr.com/ltt

Spice up your cabling and save 10% on CableMod products on Amazon with code 10CABLEMOD at https://geni.us/bL1uF

We ordered a bunch of Apple self-repair tools so today Linus will try to repair and iPhone screen while discussing the merits and pitfalls of Apple's foray into Right to Repair...

Discuss on the forum: https://linustechtips.com/topic/1444709-i%E2%80%99m-a-genius-apple-self-repair/

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:09 How it used to be
2:00 What's new
2:42 What can be repaired?
3:20 How to get tools
4:59 LET'S TRY IT
7:32 How to get parts
8:42 Why you won't do this
11:48 is this for Repair Shops?
12:19 Final Thoughts
14:00 Outro


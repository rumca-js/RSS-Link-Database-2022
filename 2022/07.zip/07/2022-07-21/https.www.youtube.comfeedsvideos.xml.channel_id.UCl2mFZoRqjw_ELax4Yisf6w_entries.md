# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## NYC street after five minutes of rain
 - [https://www.youtube.com/watch?v=5dSGi18yUqU](https://www.youtube.com/watch?v=5dSGi18yUqU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-07-21 00:00:00+00:00




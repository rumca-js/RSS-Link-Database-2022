# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## I had grief panic attacks in school - but I was lucky
 - [https://www.bbc.co.uk/news/education-62036584?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-62036584?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 23:55:16+00:00

Rising costs and a spike in demand after lockdown are putting pressure on support services.

## Richard Osman to embark on new series of crime novels
 - [https://www.bbc.co.uk/news/entertainment-arts-62238308?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62238308?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 23:54:19+00:00

The author and Pointless star says he is working on a new Da Vinci Code-style crime caper.

## What UK aid cut means for one South Sudan hospital
 - [https://www.bbc.co.uk/news/world-africa-62244845?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-62244845?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 23:39:37+00:00

One of the few doctors serving 1.3 million people may have to leave because he would lose his salary.

## Ukraine war: Family given sight back settle into Polish life
 - [https://www.bbc.co.uk/news/world-europe-62189546?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62189546?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 23:24:13+00:00

Five-year-old twins who were blinded by a missile attack update us on life in Poland after surgery.

## ‘I can’t forget her'- Myanmar’s soldiers admit atrocities
 - [https://www.bbc.co.uk/news/world-asia-62208882?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-62208882?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 23:07:27+00:00

Soldiers in the Myanmar military have admitted to killing, torturing and raping civilians.

## Comic-Con returns in-person to San Diego after pandemic
 - [https://www.bbc.co.uk/news/entertainment-arts-62229956?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62229956?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 23:03:35+00:00

More than 100,000 fans are gathering in San Diego for Comic-Con.

## Euros 2022: Ella Toone says England want to make fans proud
 - [https://www.bbc.co.uk/sport/football/62260782?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62260782?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 22:40:19+00:00

Ella Toone says England want to keep making the fans proud with victory in their Euro 2022 semi-final.

## Germany 2-0 Austria: Eight-time champions reach semi-finals
 - [https://www.bbc.co.uk/sport/football/62241096?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62241096?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 22:09:44+00:00

Germany booked their place in the semi-finals of the European Women's Championship with a narrow victory over Austria at Brentford's Community Stadium.

## Europe wildfires: Are they linked to climate change?
 - [https://www.bbc.co.uk/news/58159451?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/58159451?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 19:03:57+00:00

A series of wildfires across the Europe has caused alarm - how do they compare with previous years?

## Euro 2022: England success bringing more fans to games
 - [https://www.bbc.co.uk/news/newsbeat-62251878?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-62251878?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 15:36:01+00:00

England fans say Euro 2022 has seen crowds and interest in matches reach previously unseen heights.

## Quiz of the week: How did Boris Johnson sign off from PMQs?
 - [https://www.bbc.co.uk/news/world-62253293?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-62253293?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 15:27:08+00:00

How closely have you been paying attention to what's been going on over the past seven days?

## Nord Stream: Key Russian pipeline resumes pumping gas to Europe
 - [https://www.bbc.co.uk/news/world-europe-62249015?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62249015?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 12:25:36+00:00

There had been fears Moscow would not restart flows in response to sanctions over the Ukraine war.

## Cost-of-living help offered with discount supermarket deals
 - [https://www.bbc.co.uk/news/uk-politics-62252239?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62252239?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 12:16:28+00:00

Cut-price meals are among the deals but Labour says the government campaign doesn't go far enough.

## Neutron star chaser: Telescope spots dead suns crash
 - [https://www.bbc.co.uk/news/science-environment-61911047?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-61911047?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 12:00:37+00:00

Scientists develop a telescope to detect violent collisions of dead suns known as neutron stars.

## Partygate: Boris Johnson may face by-election if found to have misled MPs
 - [https://www.bbc.co.uk/news/uk-politics-62252046?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62252046?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 11:58:25+00:00

Outgoing Prime Minister Boris Johnson is facing a Parliamentary inquiry into his conduct.

## We will learn lessons before next pandemic - inquiry
 - [https://www.bbc.co.uk/news/health-62250899?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-62250899?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 11:40:14+00:00

The UK public inquiry launches with the promise of a robust look into whether more could have been done.

## BBC to pay damages to former royal nanny Tiggy Legge-Bourke
 - [https://www.bbc.co.uk/news/uk-62250479?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62250479?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 11:37:07+00:00

The BBC apologises to Princes William and Harry's ex-nanny over false claims made about her to obtain an interview with Diana.

## Italian PM Mario Draghi resigns after week of turmoil
 - [https://www.bbc.co.uk/news/world-europe-62249050?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62249050?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 11:20:53+00:00

He headed a unity government for 18 months, but three parties refused to back him in a key vote.

## Ukraine war: CIA chief says no intelligence that Putin is in bad health
 - [https://www.bbc.co.uk/news/world-europe-62246914?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62246914?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 10:34:33+00:00

William Burns said there was no evidence to suggest rumours of Putin's ill health were true.

## Supreme Court date for indyref2 case set for 11 October
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-62250988?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-62250988?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 10:27:25+00:00

UK Supreme Court judges will consider whether Holyrood can legally hold a second Scottish vote.

## Euro 2022: England v Spain quarter-final draws biggest TV audience of Euros so far
 - [https://www.bbc.co.uk/sport/football/62251265?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62251265?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 09:43:20+00:00

A peak television audience of 7.6 million watched England's dramatic extra-time win against Spain in the Euro 2022 quarter-final on BBC One.

## Euro 2022: Sarina Wiegman's 'plan for every scenario' paying off for England
 - [https://www.bbc.co.uk/sport/football/62246303?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62246303?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 09:41:50+00:00

Manager Sarina Wiegman played a key role in England's quarter-final win over Spain - so can her meticulous planning and ruthlessness take England all the way at Euro 2022?

## Spanish bull run: Three dead in 24 hours in Valencia hospitals
 - [https://www.bbc.co.uk/news/world-europe-62249049?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62249049?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 08:18:56+00:00

The men had all been wounded recently during the Valencia region's annual festival.

## Inflation pushes UK government interest costs in June to fresh record
 - [https://www.bbc.co.uk/news/business-62240775?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62240775?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 08:03:43+00:00

Interest payments made on government debt hit the highest level on record in June as inflation surged.

## World Athletics Championships: Eilish McColgan and Jessica Judd reach 5,000m final
 - [https://www.bbc.co.uk/sport/athletics/62248777?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/athletics/62248777?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 07:07:46+00:00

Britain's Eilish McColgan and Jessica Judd reach the 5,000m final at the World Championships in Oregon, but medal hope Max Burgin withdraws injured from the 800m.

## Tom Aspinall: How MMA heavyweight went from having £20 in the bank to headlining UFC
 - [https://www.bbc.co.uk/sport/av/mixed-martial-arts/62244193?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/mixed-martial-arts/62244193?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 06:11:27+00:00

British heavyweight fighter Tom Aspinall tells how he went from having £20 in the bank to being a UFC headliner.

## Euro 2022: A summer like no other for the town of Leigh
 - [https://www.bbc.co.uk/sport/football/62181948?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62181948?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 06:06:25+00:00

Leigh was not an obvious venue choice for Euro 2022, but the Greater Manchester town has pulled out all the stops to play its part in this summer's European Women's Championship success.

## Bloody Friday: What happened in Belfast on 21 July 1972?
 - [https://www.bbc.co.uk/news/uk-northern-ireland-62135584?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-62135584?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 05:24:20+00:00

A total of 19 IRA bombs exploded across Belfast in little over an hour on 21 July 1972.

## The bottlenecks on alternative routes to export Ukrainian grain
 - [https://www.bbc.co.uk/news/world-europe-62211433?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62211433?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 05:09:51+00:00

The struggle in Hungary and Romania to transport and store Ukrainian grains amid Russia's blockade.

## Tory leadership: The two finalists have just weeks to charm the membership
 - [https://www.bbc.co.uk/news/uk-politics-62247506?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62247506?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 05:06:27+00:00

Rishi Sunak and Liz Truss will both feel they have something to prove before voters start casting their ballots.

## Baidu unveils new self-driving taxi in China
 - [https://www.bbc.co.uk/news/technology-62237612?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62237612?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 02:06:59+00:00

Baidu says its latest robo-taxi has the road skills of a driver with 20 years' experience.

## World Athletics Championships: Watch as Bigfoot the mascot challenges Alison dos Santos to dance-off
 - [https://www.bbc.co.uk/sport/av/athletics/62247387?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/athletics/62247387?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 01:55:46+00:00

Watch as World Athletics Championships Oregon22 mascot Legend the Bigfoot challenges hurdles gold medallist Alison dos Santos to a dance-off.

## Paraorchestra: 'Headlining Bluedot could be the start of serious change'
 - [https://www.bbc.co.uk/news/uk-england-manchester-62041185?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-62041185?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 00:08:42+00:00

Paraorchestra say headlining Bluedot festival will be a defining moment for disabled musicians.

## UK heatwave: How are homeless people in Ipswich coping?
 - [https://www.bbc.co.uk/news/uk-england-suffolk-62237844?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-suffolk-62237844?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-07-21 00:07:35+00:00

How have homeless people fared amid the soaring heat and what is being done to support them?


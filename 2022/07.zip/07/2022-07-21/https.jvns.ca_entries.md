## What happens when you press a key in your terminal?
 - [https://jvns.ca/blog/2022/07/20/pseudoterminals/](https://jvns.ca/blog/2022/07/20/pseudoterminals/)
 - RSS feed: https://jvns.ca
 - date published: 2022-07-21 08:43:53.587576+00:00

What happens when you press a key in your terminal?


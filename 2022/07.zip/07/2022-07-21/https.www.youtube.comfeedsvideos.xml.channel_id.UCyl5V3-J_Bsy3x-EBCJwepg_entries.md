# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## FreedomFest Special: We Ask Crazy Libertarians The 10 Questions
 - [https://www.youtube.com/watch?v=F4vjg7bp__o](https://www.youtube.com/watch?v=F4vjg7bp__o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-07-22 00:00:00+00:00

The Babylon Bee crew wandered FreedomFest and asked those crazy liberty-loving folks questions like "What book would you add to the Bible?", "Do you prefer cigars or pipes?", and, of course, "Would you do us a solid and accept Jesus as your Lord and Savior?" Here are the most interesting or insane responses we got!

Don't forget to subscribe to the new Babylon Bee Podcast channel: https://www.youtube.com/channel/UCWHeOvQs6p-9KcMtvV0sNmQ

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## The Bee Weekly: FreedomFest and The Best Video Games Ever
 - [https://www.youtube.com/watch?v=UsNUVaJlqz8](https://www.youtube.com/watch?v=UsNUVaJlqz8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-07-22 00:00:00+00:00

Enjoy an 82% discount and 3 months free with the most trusted VPN provider, Private Internet Access at our link: https://www.privateinternetaccess.com/offer/TheBabylonBee_v12qjfi

This week at The Babylon Bee, the guys review their crazy weekend in Las Vegas at FreedomFest because what happens in Vegas echoes in eternity. They also talk about good Samaritans who use guns and run into burning buildings, repent of not knowing the fish slapping dance, and discuss the top ten greatest video games of all time. Travis is back with a vengeance this episode.

This episode is also brought to you by these sponsors bringing you Fake News You Can Trust:
BetterHelp: http://betterhelp.com/babylonbee
My Patriot Supply: http://preparewithbee.com
ABIDE app: http://abide.co/babylon
Allegiance Gold: http://allegiancegold.com/bee

The Babylon Bee crew also talks about the news of the week like Brandon Falls being a historical landmark now, NPR deciding to open up a brand new disinformation wing, and Joe Biden wandering around the Middle East asking for Jafar. There’s also more Sizzler facts, a Weakly News with Claire filling in for Adam, and Bee Radio with Austin Robertson. Kyle sits down with Andrew Crapuchettes, from Red Balloon, who is trying to connect freedom-loving employers with people who just want to work without compromising their beliefs and values. Last but not least, the guys at The Babylon Bee set in stone their top ten video games of all time. 

The Babylon Bee Podcast channel is breaking up! Make sure to follow the podcast at the new YouTube channel: https://www.youtube.com/channel/UCWHeOvQs6p-9KcMtvV0sNmQ?sub_confirmation=1

Check out Red Balloon: https://www.redballoon.work/

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Senator Rand Paul Sits Down With The Babylon Bee
 - [https://www.youtube.com/watch?v=0CpPDCtJa7E](https://www.youtube.com/watch?v=0CpPDCtJa7E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-07-21 00:00:00+00:00

Senator Rand Paul met with the guys from The Babylon Bee to talk about fake news, hair care tips, and how he really feels about Dr. Fauci.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


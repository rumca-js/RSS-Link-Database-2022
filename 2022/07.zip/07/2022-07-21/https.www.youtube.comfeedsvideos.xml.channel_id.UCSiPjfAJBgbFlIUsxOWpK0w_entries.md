# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## French song with synths // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=A1ZQsHVmXG8](https://www.youtube.com/watch?v=A1ZQsHVmXG8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2022-07-21 00:00:00+00:00

Trying to write more in French :)

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

À Los Angeles is an original song by Pomplamoose.

MUSICIAN CREDITS
Vocals: Nataly Dawn
Synthesizer: Jack Conte, Swatkins, & Karina DePiano
Drums: Ben Rose

AUDIO CREDITS
Engineer: Bill Mims
Assistant Engineer: Jack Corbett
Mixing/Mastering: Yianni AP
Producer: Ben Rose

VIDEO CREDITS
Director: Dom Fera
DP: Ryan Blewett
Camera Operators: Austin Hughes & Riley Donavan
Gaffer: Nash White
PA/Wardrobe: Alex Allen
Video Editor/Colorist: Dominic Mercurio

Recorded live in Los Angeles, CA.

LYRICS (French / English)
À Los Angeles / To Los Angeles

Non pas les heures / No, not the hours
Ce sont les secondes que je compte / It’s the seconds that I count
Et j’ai plus peur / And I’m not afraid anymore
Je me promène seule récemment / I walk alone recently

Les somnambules / The sleepwalkers
Ils savent tous où est la fête / They all know where the party’s at
Et je te vois plus / And I don’t see you anymore
Mais je sais bien où tu dois être / But I have a pretty good idea where you are

À Los Angeles / In Los Angeles
Quand reviendras-tu / When will you return
À Los Angeles / To Los Angeles
À Los Angeles / In Los Angeles
Quand reviendras-tu / When will you return
Ah Los Angeles / Ah Los Angeles

Non pas les heures / No, not the hours
Ce sont les secondes que je compte / It’s the seconds that I count
Et j’ai plus peur / And I’m not afraid anymore
Je me promène seule récemment / I walk alone recently
Complètement seule / Completely alone


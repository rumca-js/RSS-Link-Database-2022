## TeamViewer installs suspicious font only useful for web fingerprinting | Ctrl blog
 - [https://www.ctrl.blog/entry/teamviewer-font-privacy.html](https://www.ctrl.blog/entry/teamviewer-font-privacy.html)
 - RSS feed: https://www.ctrl.blog
 - date published: 2022-07-21 08:49:50.577258+00:00

A weird almost unreadable font file bundled with TeamViewer for Windows software lets website detect if you’ve installed the software. Raises privacy concerns.


# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## Why No One Can Agree What’s REALLY the Tallest Mountain
 - [https://www.youtube.com/watch?v=biNMRQJXvfs](https://www.youtube.com/watch?v=biNMRQJXvfs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2022-07-22 00:00:00+00:00

SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub 
We’re on PATREON! Join the community https://www.patreon.com/itsokaytobesmart
↓↓↓ More info and sources below ↓↓↓

Check out Far Out on @pbsterra : https://youtu.be/jpUjze3v_6c 
Check out Why Am I Like This? on @pbsterra : https://youtu.be/eWzBNfBnFys

What's the tallest mountain on Earth? It might seem like an easy question to answer, but in reality it's one that brings up more NEW questions than answers. It turns out that the way we measure mountains rests on a lot of approximations, assumptions, and averages. And when you dig into those, there's several contenders for the tallest mountain, each with their own good case for the title. So, which mountain do YOU think should take the throne?

References: https://sites.google.com/view/references-tallest-mountain/home

Special thanks to our Brain Trust Patrons:

paul andre bouis
Mark Littlehale
Ali Freiburger
Mehdi Damou
Barbora Bei
Ken Board
Clinger-Hamilton Family
Attila Pix
Burt Humburg
Roy Lasris
dani bowman
David Johnston
Salih Arslan
Baerbel Winkler
Robert Young
Amy Sowada
Eric Meer
Dustin
Karen Haskell

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/


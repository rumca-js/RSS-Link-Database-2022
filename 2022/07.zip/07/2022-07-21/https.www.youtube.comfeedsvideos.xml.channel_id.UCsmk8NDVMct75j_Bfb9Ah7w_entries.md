# Source:Virtual Reality Oasis, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsmk8NDVMct75j_Bfb9Ah7w, language:en-US

## Moss Book II Is Beautiful On Quest 2
 - [https://www.youtube.com/watch?v=O6OAFXDocGQ](https://www.youtube.com/watch?v=O6OAFXDocGQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsmk8NDVMct75j_Bfb9Ah7w
 - date published: 2022-07-21 17:00:17+00:00

Moss Book 2 is now available on Quest 2 and it's wonderful! I'll be avoiding any major spoilers in this gameplay and review video.

You can check out Moss Book II on Quest 2 here;
https://www.oculus.com/experiences/quest/4395292760584049

You can buy Moss and Moss Book 2 as a bundle on Quest 2 here;
https://www.oculus.com/experiences/quest/453765813234698

You can check out Moss Book II on PSVR here;
https://www.playstation.com/en-gb/games/moss-book-ii

Let me know if you're excited for Moss Book II on the Quest 2 in the comments below...

Thanks for watching []-) 

VR HEADSETS:
Oculus Quest 2: https://bit.ly/3iHPFWs
Valve Index: http://bit.ly/2v8hZhi

VR ACCESSORIES:
VR Cover: https://bit.ly/3okrLmq
Mamut VR Grips: http://bit.ly/3aE3G32
Widmo Prescription Lenses: http://bit.ly/2W0BTGf
ProTube: http://bit.ly/2sujHb3

FOLLOW ME: 
Subscribe: http://bit.ly/2VeBqfJ
Memberships: http://bit.ly/2MVWxRl
Discord: https://discord.gg/NN9TGrv
Twitter: https://twitter.com/vr_oasis
Instagram: https://instagram.com/virtualrealityoasis
Facebook: https://facebook.com/virtualrealityoasis
FReality Podcast: http://bit.ly/39HdVUj
Website: http://virtualrealityoasis.com/
Email: contact@virtualrealityoasis.com

#MossBookII #Quest2 #VR


# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## W.I.T.C.H. - Chifundo (Live on KEXP)
 - [https://www.youtube.com/watch?v=9GcCaf2DrYc](https://www.youtube.com/watch?v=9GcCaf2DrYc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-08 00:00:00+00:00

http://KEXP.ORG presents W.I.T.C.H. performing “Chifundo” live in the KEXP studio. Recorded June 16, 2022.

Emmanuel Jagari Chanda - Vocals
Patrick Mwondela - Keys
Jacco Gardner - Bass
JJ Whitefield - Guitar
Nico Mauskovic - Drums
Stefan Lilov - Guitar
Alain Sandri - Percussion

Host: Eva Walker
Audio Engineer: Julian Martlew
Audio Mixer: Jacco Gardner
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

http://weintendtocausehavoc.com
https://www.instagram.com/weintendtocausehavoc
http://kexp.org

## W.I.T.C.H. - Evil Woman (Live on KEXP)
 - [https://www.youtube.com/watch?v=A6l-4gdF03w](https://www.youtube.com/watch?v=A6l-4gdF03w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-08 00:00:00+00:00

http://KEXP.ORG presents W.I.T.C.H. performing “Evil Woman” live in the KEXP studio. Recorded June 16, 2022.

Emmanuel Jagari Chanda - Vocals
Patrick Mwondela - Keys
Jacco Gardner - Bass
JJ Whitefield - Guitar
Nico Mauskovic - Drums
Stefan Lilov - Guitar
Alain Sandri - Percussion

Host: Eva Walker
Audio Engineer: Julian Martlew
Audio Mixer: Jacco Gardner
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

http://weintendtocausehavoc.com
https://www.instagram.com/weintendtocausehavoc
http://kexp.org

## W.I.T.C.H. - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=WAMt8ivs5mE](https://www.youtube.com/watch?v=WAMt8ivs5mE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-08 00:00:00+00:00

http://KEXP.ORG presents W.I.T.C.H. performing live in the KEXP studio. Recorded June 16, 2022.

Songs:
Waile
Living In The Past
Chifundo
Evil Woman

Emmanuel Jagari Chanda - Vocals
Patrick Mwondela - Keys
Jacco Gardner - Bass
JJ Whitefield - Guitar
Nico Mauskovic - Drums
Stefan Lilov - Guitar
Alain Sandri - Percussion

Host: Eva Walker
Audio Engineer: Julian Martlew
Audio Mixer: Jacco Gardner
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

http://weintendtocausehavoc.com
https://www.instagram.com/weintendtocausehavoc
http://kexp.org

## W.I.T.C.H. - Living In The Past (Live on KEXP)
 - [https://www.youtube.com/watch?v=GuIanhu3Oo4](https://www.youtube.com/watch?v=GuIanhu3Oo4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-08 00:00:00+00:00

http://KEXP.ORG presents W.I.T.C.H. performing “Living In The Past” live in the KEXP studio. Recorded June 16, 2022.

Emmanuel Jagari Chanda - Vocals
Patrick Mwondela - Keys
Jacco Gardner - Bass
JJ Whitefield - Guitar
Nico Mauskovic - Drums
Stefan Lilov - Guitar
Alain Sandri - Percussion

Host: Eva Walker
Audio Engineer: Julian Martlew
Audio Mixer: Jacco Gardner
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

http://weintendtocausehavoc.com
https://www.instagram.com/weintendtocausehavoc
http://kexp.org

## W.I.T.C.H. - Waile (Live on KEXP)
 - [https://www.youtube.com/watch?v=azUwrutMDzs](https://www.youtube.com/watch?v=azUwrutMDzs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-07-08 00:00:00+00:00

http://KEXP.ORG presents W.I.T.C.H. performing “Waile” live in the KEXP studio. Recorded June 16, 2022.

Emmanuel Jagari Chanda - Vocals
Patrick Mwondela - Keys
Jacco Gardner - Bass
JJ Whitefield - Guitar
Nico Mauskovic - Drums
Stefan Lilov - Guitar
Alain Sandri - Percussion

Host: Eva Walker
Audio Engineer: Julian Martlew
Audio Mixer: Jacco Gardner
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

http://weintendtocausehavoc.com
https://www.instagram.com/weintendtocausehavoc
http://kexp.org


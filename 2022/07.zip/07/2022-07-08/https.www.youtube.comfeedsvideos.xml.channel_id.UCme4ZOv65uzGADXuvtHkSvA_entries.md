# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## CNN [#296] Miłość musi iść z prawdą
 - [https://www.youtube.com/watch?v=IEZo-Bb5iQ8](https://www.youtube.com/watch?v=IEZo-Bb5iQ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-09 00:00:00+00:00

#cnn #dobrewiadomości    @Langustanapalmie 

Kazanko do okienka, czyli komentarz do niedzielnych czytań.

Niedziela, XIV Tydzień zwykły, Rok C, II
Piętnasta Niedziela zwykła

1. czytanie (Pwt 30, 10-14)

Mojżesz powiedział do ludu:
«Będziesz słuchał głosu Pana, Boga swego, przestrzegając Jego poleceń i postanowień zapisanych w księdze tego Prawa; wrócisz do Pana, Boga swego, z całego swego serca i z całej swej duszy.
Polecenie to bowiem, które Ja ci dzisiaj daję, nie przekracza twych możliwości i nie jest poza twoim zasięgiem. Nie jest w niebiosach, by można było powiedzieć: „Któż dla nas wstąpi do nieba i przyniesie je nam, a będziemy słuchać i wypełnimy je”. I nie jest za morzem, aby można było powiedzieć: „Któż dla nas uda się za morze i przyniesie je nam, a będziemy słuchać i wypełnimy je”.
Słowo to bowiem jest bardzo blisko ciebie: w twych ustach i w twoim sercu, byś je mógł wypełnić».

2. czytanie (Kol 1, 15-20)

Chrystus Jezus jest obrazem Boga niewidzialnego – Pierworodnym wobec każdego stworzenia, bo w Nim zostało wszystko stworzone: i to, co w niebiosach, i to, co na ziemi, byty widzialne i niewidzialne, czy to Trony, czy Panowania, czy Zwierzchności, czy Władze. Wszystko przez Niego i dla Niego zostało stworzone. On jest przed wszystkim i wszystko w Nim ma istnienie.
I On jest Głową Ciała – Kościoła. On jest Początkiem. Pierworodnym spośród umarłych, aby sam zyskał pierwszeństwo we wszystkim. Zechciał bowiem Bóg, aby w Nim zamieszkała cała Pełnia i aby przez Niego znów pojednać wszystko z sobą: przez Niego – i to, co na ziemi, i to, co w niebiosach, wprowadziwszy pokój przez krew Jego krzyża.

Ewangelia (Łk 10, 25-37)

Powstał jakiś uczony w Prawie i wystawiając Jezusa na próbę, zapytał: «Nauczycielu, co mam czynić, aby osiągnąć życie wieczne?»
Jezus mu odpowiedział: «Co jest napisane w Prawie? Jak czytasz?»
On rzekł: «Będziesz miłował Pana, Boga swego, całym swoim sercem, całą swoją duszą, całą swoją mocą i całym swoim umysłem; a swego bliźniego jak siebie samego».
Jezus rzekł do niego: «Dobrze odpowiedziałeś. To czyń, a będziesz żył».
Lecz on, chcąc się usprawiedliwić, zapytał Jezusa: «A kto jest moim bliźnim?»
Jezus, nawiązując do tego, rzekł: «Pewien człowiek schodził z Jeruzalem do Jerycha i wpadł w ręce zbójców. Ci nie tylko go obdarli, lecz jeszcze rany mu zadali i zostawiwszy na pół umarłego, odeszli. Przypadkiem przechodził tą drogą pewien kapłan; zobaczył go i minął. Tak samo lewita, gdy przyszedł na to miejsce i zobaczył go, minął.
Pewien zaś Samarytanin, wędrując, przyszedł również na to miejsce. Gdy go zobaczył, wzruszył się głęboko: podszedł do niego i opatrzył mu rany, zalewając je oliwą i winem; potem wsadził go na swoje bydlę, zawiózł do gospody i pielęgnował go. Następnego zaś dnia wyjął dwa denary, dał gospodarzowi i rzekł: „Miej o nim staranie, a jeśli co więcej wydasz, ja oddam tobie, gdy będę wracał”.
Kto z tych trzech okazał się według ciebie bliźnim tego, który wpadł w ręce zbójców?»
On odpowiedział: «Ten, który mu okazał miłosierdzie».
Jezus mu rzekł: «Idź i ty czyń podobnie!»

________________________________________

Niedzielnik*. Komentarze do czytań na uroczystości:
→ https://wdrodze.pl/produkt/niedzielnik-komentarze-do-czytan-na-uroczystosci/
________________________________________
NIENASYCENI 
☞ Tauron Arena Kraków
☞ 6 października 2022 r. 

BILETY ☞ https://bit.ly/Nienasyceni_Tauron
WYDARZENIE ☞ https://fb.me/e/1WzTzhC1Q
________________________________________

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

________________________________________

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Tobiasza || Rozdział 12
 - [https://www.youtube.com/watch?v=-h4OK7p6_SA](https://www.youtube.com/watch?v=-h4OK7p6_SA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-09 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#1140] Zgoda
 - [https://www.youtube.com/watch?v=_HfloYy51Ww](https://www.youtube.com/watch?v=_HfloYy51Ww)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-09 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
NIENASYCENI 
☞ Tauron Arena Kraków
☞ 6 października 2022 r. 

BILETY ☞ https://bit.ly/Nienasyceni_Tauron
WYDARZENIE ☞ https://fb.me/e/1WzTzhC1Q
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Chodź na pielgrzymkę!
 - [https://www.youtube.com/watch?v=LuLE_TVjzJw](https://www.youtube.com/watch?v=LuLE_TVjzJw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-08 00:00:00+00:00

#pielgrzymka #pokuta @Langustanapalmie @Dominikanieplportal 

Tutaj link do zapisów: https://pielgrzymka.dominikanie.pl/zapisy

NIENASYCENI 
☞ Tauron Arena Kraków
☞ 6 października 2022 r. 

BILETY ☞ https://bit.ly/Nienasyceni_Tauron
WYDARZENIE ☞ https://fb.me/e/1WzTzhC1Q
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Tobiasza || Rozdział 11
 - [https://www.youtube.com/watch?v=R3NyeMOGN04](https://www.youtube.com/watch?v=R3NyeMOGN04)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-08 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Langusta ma wolne i powroty serii
 - [https://www.youtube.com/watch?v=UZ9AA2IUZ6c](https://www.youtube.com/watch?v=UZ9AA2IUZ6c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-08 00:00:00+00:00

@Langustanapalmie  #urlop

NIENASYCENI 
☞ Tauron Arena Kraków
☞ 6 października 2022 r. 

BILETY ☞ https://bit.ly/Nienasyceni_Tauron
WYDARZENIE ☞ https://fb.me/e/1WzTzhC1Q
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#1139] Względy
 - [https://www.youtube.com/watch?v=OvyVT7FyWPg](https://www.youtube.com/watch?v=OvyVT7FyWPg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-07-08 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
NIENASYCENI 
☞ Tauron Arena Kraków
☞ 6 października 2022 r. 

BILETY ☞ https://bit.ly/Nienasyceni_Tauron
WYDARZENIE ☞ https://fb.me/e/1WzTzhC1Q
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.


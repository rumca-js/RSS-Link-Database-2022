# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## All Aboard the SSF Zephyr
 - [https://www.youtube.com/watch?v=qwraWQNLN4Q](https://www.youtube.com/watch?v=qwraWQNLN4Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2022-07-08 00:00:00+00:00

This video is sponsored by Patchwerks! Get a Zephyr or whatever else you may desire from Seattle's synthesizer and community store: https://shrsl.com/3lp8i

00:00 intro
01:23 front panel walkthrough with sound demos
05:16 patch example 01
05:37 fm and sync sound demo
06:30 zmod sync patch demo
07:40 envelope modulation demo
10:54 patchwerks!
11:46 percall rhythmic modulation demo
14:04 glassy bell-like tones
16:24 slow grind full patch
18:04 zephyr as a lead
20:11 final thoughts
21:40 outro jam

Join the Patreon and get access to music, presets, samples, and a great community.
Join Patreon:  http://bit.ly/rmrpatreon

Find my music here: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
YouTube Music: https://bit.ly/3PZQ4ol
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia


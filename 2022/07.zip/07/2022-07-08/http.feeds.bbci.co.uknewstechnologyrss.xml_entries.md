# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Neill Blomkamp: Why I am making video game Off The Grid
 - [https://www.bbc.co.uk/news/technology-61979994?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-61979994?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-07-08 10:39:37+00:00

The free-to-play game, featuring a narrative element, will see 150 players fight to be the last one.


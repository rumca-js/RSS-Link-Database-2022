# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Thor: Love And Thunder - It's Hot Garbage
 - [https://www.youtube.com/watch?v=IHMS7eVOGTE](https://www.youtube.com/watch?v=IHMS7eVOGTE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-07-08 00:00:00+00:00

Thor Love And Thunder is a bit of a mess, blighted by a bad script, unfunny jokes and headache-inducing visuals. Join me as I do my best to sift through the garbage and review it. 

Want to help support this channel? 
Check out my books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8/ref=dp_byline_cont_pop_ebooks_1
Subscribe on Patreon: https://www.patreon.com/TheCriticalDrinker
Subscribe on Subscribestar: https://www.subscribestar.com/the-critical-drinker


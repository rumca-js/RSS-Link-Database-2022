# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## The World's Largest Smartphone Camera! Xiaomi 12S Ultra
 - [https://www.youtube.com/watch?v=lYPe4MsALk4](https://www.youtube.com/watch?v=lYPe4MsALk4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-07-08 00:00:00+00:00

Xiaomi 12S Ultra has a truly incredible camera... sometimes

1-inch Sensors aren't actually 1 inch: https://youtu.be/-njHjebtIg4

MKBHD Merch: http://shop.MKBHD.com

Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Xiaomi for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


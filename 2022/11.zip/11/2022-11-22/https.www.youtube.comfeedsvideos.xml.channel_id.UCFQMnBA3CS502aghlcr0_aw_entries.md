# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## This Wasn't an Accident
 - [https://www.youtube.com/watch?v=FDqhM7vHR2o](https://www.youtube.com/watch?v=FDqhM7vHR2o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2022-11-22 03:18:17+00:00

It just got so much worse. 
Follow Coffeezilla: 
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
► Facebook: https://www.facebook.com/Coffeezilla-102981089132662
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&amp;list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&amp;index=1
Credits: 
3D Artist: Ed Leszczynski https://twitter.com/LeszczynskiEd
Video Editor: Harry Bagg  https://twitter.com/HarryRBagg
Virtual Production Software: Aximmetry https://aximmetry.com/

This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.


# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Ruda Maleniecka. Nietrzeźwy wójt wziął udział w sesji rady gminy? Tłumaczy, że tego dnia miał urlop
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29170874,ruda-maleniecka-nietrzezwy-wojt-wzial-udzial-w-sesji-rady-gminy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29170874,ruda-maleniecka-nietrzezwy-wojt-wzial-udzial-w-sesji-rady-gminy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-22 19:29:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3b/d1/1b/z29171003M,Urzad-gminy-w-Rudzie-Malenieckiej.jpg" vspace="2" />Wójt gminy Ruda Maleniecka miał wziąć udział w sesji rady gminy pod wpływem alkoholu. Jak tłumaczył Leszek K., tego dnia był na urlopie, a w spotkaniu uczestniczył jako gość. - Mój błąd, że przyszedłem - komentował wójt.

## Łuków. Zabójstwo komorniczki. Sprawca miał dług w innej kancelarii
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29170953,lukow-zabojstwo-komorniczki-sprawca-mial-dlug-w-innej-kancelarii.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29170953,lukow-zabojstwo-komorniczki-sprawca-mial-dlug-w-innej-kancelarii.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-22 19:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e7/ce/1b/z29156839M,Lukow--Interwencja-policji-z-uzyciem-broni.jpg" vspace="2" />42-latek podejrzany o zabójstwo komornik w Łukowie miał dług, ale w innej kanclearii komorniczej. Zamordowana kobieta nie prowadziła wobec niego czynnego postępowania, a poprzednie zakończyły się spłatą długu. Wcześniej mężczyzna miał siać zamęt w pozostałych kancelariach komorniczych w Łukowie - informuje PAP.

## Pabianice. Trucizna ukryta w kawałkach kiełbasy "czyha" na psy. Nagroda za wskazanie truciciela
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29170320,pabianice.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29170320,pabianice.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-22 17:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e7/d1/1b/z29170407M,Zdjecie-ilustracyjne.jpg" vspace="2" />W łódzkich Pabianicach grasuje truciciel, który wziął sobie na celownik lokalne psy. W różnych częściach miasta rozrzuca kiełbasę, w której ukrywa kapsułki zawierające żrącą substancję. Policjanci wszczęli już dochodzenie w tej sprawie. Za wskazanie truciciela czworonogów wyznaczono nagrodę.

## Neo-Nówka znów uderza w rząd PiS. Były ryby pływające pod prąd i rtęć w Odrze ze zbitych termometrów
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29169217,neo-nowka-znow-uderza-w-rzad-pis-przypomnieli-o-martwych-rybach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29169217,neo-nowka-znow-uderza-w-rzad-pis-przypomnieli-o-martwych-rybach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-22 15:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9e/d1/1b/z29170078M,Neo-Nowka-znow-uderza-w-rzad-PiS--Przypomnieli-o-m.jpg" vspace="2" />Kabaret Neo-Nówka znów wbił szpilę PiS. Przy okazji swojego jubileuszu komicy przypomnieli widzom o katastrofie ekologicznej na Odrze. Wskazali "winnych".

## Młodzież Wszechpolska przerwała spotkanie z ukraińską pisarką, "apele" policji nie pomogły. "Hańba!" [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29169501,krakow-spotkanie-z-ukrainska-pisarka-oksana-zabuzko-przerwane.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29169501,krakow-spotkanie-z-ukrainska-pisarka-oksana-zabuzko-przerwane.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-22 14:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bf/d1/1b/z29169855M,Protest-narodowcow-na-spotkaniu-z-Oksana-Zabuzko.jpg" vspace="2" />"Hańba, hańba", "Bandera, won za Don!" - takimi okrzykami narodowcy z Młodzieży Wszechpolskiej w poniedziałek przerwali spotkanie ukraińskiej pisarki Oksany Zabużko w Międzynarodowym Centrum Kultury w Krakowie. Była to reakcja na przyznanie jej literackiej nagrody im. Stanisława Vincenza. Ostatecznie organizatorzy zdecydowali o zakończeniu spotkania, a pisarce nie udało się zabrać głosu. Skomentowała zdarzenie dzień później.

## Konin. Zbyt szybko jechał autem. Podpadł pod nowy przepis o recydywie. Zapłaci 6 tys. zł mandatu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29169671,konin-po-raz-kolejny-zbyt-szybko-jechal-swoim-samochodem-22-latek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29169671,konin-po-raz-kolejny-zbyt-szybko-jechal-swoim-samochodem-22-latek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-22 14:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c8/d1/1b/z29169864M,Po-raz-kolejny-otrzymal-jechal-za-szybko--Musi-zap.jpg" vspace="2" />Policjanci z Konina zatrzymali do kontroli 22-latka. Mężczyzna najwyraźniej bardzo się spieszył, ponieważ jechał aż o 66 km/h za szybko. Okazało się, że kierowca złamał przepisy w ramach recydywy. 22-latek za to i inne wykroczenia łącznie otrzymał 6 tys. zł mandatu.

## Kujawsko-pomorskie. Ksiądz spowodował wypadek. Miał ponad dwa promile. Zapłaci grzywnę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29169181,kujawsko-pomorskie-ksiadz-spowodowal-wypadek-mial-ponad-dwa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29169181,kujawsko-pomorskie-ksiadz-spowodowal-wypadek-mial-ponad-dwa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-22 13:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/44/cd/1b/z29151556M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />Ksiądz Paweł Ś. w listopadzie 2021 roku spowodował groźny wypadek. Duchowny miał ponad 2,5 promila alkoholu w organizmie. Duszpasterz trzeźwości musi zapłacić 1,5 tys. zł grzywny.

## Znany baca Andrzej "Zięba" Gal nie żyje. Przed laty odwiedził go Jan Paweł II
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29167991,andrzej-zieba-gal-z-witowa-nie-zyje-w-1983-r-odwiedzil-go.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29167991,andrzej-zieba-gal-z-witowa-nie-zyje-w-1983-r-odwiedzil-go.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-22 13:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f6/d1/1b/z29169142M,Szalas-pasterski--ktory-odwiedzil-papiez-w-1983-r-.jpg" vspace="2" />Andrzej "Zięba" Gal z Witowa nie żyje. Baca gościł u siebie papieża Jana Pawła II i częstował go podhalańskimi wyrobami. - Szałas poświęcił, pomodlili my się, siedli, dali mu oscypki, żentycę - relacjonował 11 lat temu.

## Dwulatka mieszkała z mamą w namiocie w Gdańsku. Była wychłodzona i głodna
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29168205,bezdomna-kobieta-mieszkala-z-dwuletnia-coreczka-w-namiocie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29168205,bezdomna-kobieta-mieszkala-z-dwuletnia-coreczka-w-namiocie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-22 12:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e8/d1/1b/z29168616M,Bezdomna-kobieta-mieszkala-z-dwuletnia-coreczka-w-.jpg" vspace="2" />Młoda matka mieszkała w namiocie wraz ze swoją dwuletnią dziewczynką na terenie zalesionym na gdańskiej Zaspie. Po wstępnym badaniu lekarz stwierdził, że dziecko jest wychłodzone, głodne i ma infekcję górnych dróg oddechowych. Matce grozi więzienie.

## Andrzej Duda znów wkręcony przez Rosjan. Miał rozmawiać z Macronem. Jest komentarz kancelarii
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29168263,andrzej-duda-znow-wkrecony-przez-rosjan-mial-rozmawiac-z-macronem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29168263,andrzej-duda-znow-wkrecony-przez-rosjan-mial-rozmawiac-z-macronem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-22 11:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/72/d1/1b/z29168498M,Andrzej-Duda--zdjecie-ilustracyjne-.jpg" vspace="2" />Rosyjscy blogerzy Władimir Kuzniecow i Aleksiej Stolarow po raz kolejny dodzwonili się do Andrzeja Dudy. Prezydent był przekonany, że rozmawia z przywódcą Francji - Emmanuelem Macronem.

## Resort Czarnka wprowadzi nowy przedmiot. Inflacja wykreślona z obowiązkowego programu nauczania
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29167118,resort-czarnka-wprowadzi-nowy-przedmiot-inflacja-wykreslona.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29167118,resort-czarnka-wprowadzi-nowy-przedmiot-inflacja-wykreslona.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-22 08:58:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b0/92/1b/z28912048M,Minister-Edukacji-i-Nauki-Przemyslaw-Czarnek-podcz.jpg" vspace="2" />Zagadnienia związane z inflacją nie znajdą się w obowiązkowym programie biznesu i zarządzania - nowego przedmiotu, który w szkołach średnich zastąpi podstawy przedsiębiorczości - zwraca uwagę Onet. - Wykreślanie takich treści to sprzyjanie analfabetyzmowi ekonomicznemu młodych Polaków - ocenił w rozmowie z portalem prof. Mariusz Sokołowicz z Uniwersytetu Łódzkiego.

## Podlasie. Myśliwy zastrzelił dwa łosie. Tłumaczył, że pomylił je z dzikami
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29167288,podlasie-mysliwy-zastrzelil-dwa-losie-tlumaczyl-ze-pomylil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29167288,podlasie-mysliwy-zastrzelil-dwa-losie-tlumaczyl-ze-pomylil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-22 08:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/dc/ba/18/z25927900M,Los.jpg" vspace="2" />W okolicy miejscowości Grądy Woniecko w gminie Rutki (woj. podlaskie) myśliwy zastrzelił dwa łosie podczas polowania. Mężczyzna tłumaczył, że pomylił łosie z dzikami. 72-latkowi grozi do pięciu lat więzienia.

## Katowice. 13 tysięcy mieszkań będzie we wtorek pozbawionych ciepła. Jak długo potrwa przerwa?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29167065,katowice-we-wtorek-wystapi-przerwa-w-dostawie-ciepla-do-poludniowych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29167065,katowice-we-wtorek-wystapi-przerwa-w-dostawie-ciepla-do-poludniowych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-22 08:41:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1e/d0/1b/z29167390M,Przerwa-w-dostawie-ciepla-moze-potrwac-nawet-20-go.jpg" vspace="2" />Na wtorek 22 listopada spółka Tauron Ciepło zapowiedziała wyłączenie dostaw ciepła do południowych dzielnic Katowic. Tylko części z tych dzielnic dotyczy komunikat. Powodem są prace nad usunięciem poważnej nieszczelności głównego rurociągu magistralnego.

## Wybuch w Przewodowie. Prezydent Litwy: Potrzebujemy wyraźnych działań ze strony NATO
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29167061,prezydent-litwy-potrzebujemy-wyraznych-dzialan-ze-strony-nato.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29167061,prezydent-litwy-potrzebujemy-wyraznych-dzialan-ze-strony-nato.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-22 07:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1e/d0/1b/z29167134M,Gitanas-Nauseda--zdjecie-ilustracyjne-.jpg" vspace="2" />- Incydent rakietowy w Polsce na nowo definiuje wojnę na Ukrainie - powiedział prezydent Litwy Gitanas Nauseda. Jak stwierdził, potrzebne są wyraźne działania ze strony NATO i wzmocnienie wschodniej flanki, bo mogą ucierpieć kraje niezaangażowane bezpośrednio w konflikt.

## Pogoda. IMGW wydał alerty: Ślisko w wielu regionach. Kolejna noc również mroźna
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29167067,pogoda-niewielkie-ocieplenie-w-dzien-mrozna-noc-slisko-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29167067,pogoda-niewielkie-ocieplenie-w-dzien-mrozna-noc-slisko-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-22 06:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0a/d0/1b/z29167114M,Pogoda--Niewielkie-ocieplenie-w-dzien--mrozna-noc-.jpg" vspace="2" />Nad Polskę napływa cieplejsze powietrze z zachodu. We wtorek w prawie w całym kraju temperatura maksymalna wzrośnie powyżej zera stopni Celsjusza.

## Wilczyński grozi pracownikom, którzy wypowiadali się w naszym tekście. Żąda pół miliona złotych rekompensaty
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29122815,wilczynski-grozi-pracownikom-ktorzy-wypowiadali-sie-w-naszym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29122815,wilczynski-grozi-pracownikom-ktorzy-wypowiadali-sie-w-naszym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-22 05:17:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/dd/c6/1b/z29123293M,Jakub-Wilczynski-grozi-swoim-bylym-pracownikom.jpg" vspace="2" />Po publikacji naszego tekstu o agresji, przemocy i terrorze w lokalach gastronomicznych Jakuba Wilczyńskiego, otrzymaliśmy dziesiątki relacji od innych pokrzywdzonych osób. Mają wspólny mianownik. To strach. Wilczyński wysłał do niektórych byłych pracowników pisma przedsądowe, w których domaga się nie tylko "usunięcia nieprawdziwych informacji" z ich profili, ale także zadośćuczynienia wysokości pół miliona złotych. Interpelację poselską w tej sprawie złożyła partia Razem.


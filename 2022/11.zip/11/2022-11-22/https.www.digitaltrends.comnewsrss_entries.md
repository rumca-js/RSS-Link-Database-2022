# Source:Digital Trends, URL:https://www.digitaltrends.com/news/rss, language:en-US

## World Cup: FIFA app made U.S. soccer fans’ tickets disappear
 - [https://www.digitaltrends.com/news/world-cup-fifa-app-made-us-soccer-fans-tickets-disappear/](https://www.digitaltrends.com/news/world-cup-fifa-app-made-us-soccer-fans-tickets-disappear/)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2022-11-22 06:03:48.214466+00:00

The Middle East's first World Cup got off to a rocky start on Monday after some fans were left unable to access their digital tickets after FIFA's app crashed.

## Drone show mishap sees flying machines drop out of the sky
 - [https://www.digitaltrends.com/news/drone-show-mishap-flying-machines-drop-out-of-sky/](https://www.digitaltrends.com/news/drone-show-mishap-flying-machines-drop-out-of-sky/)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2022-11-22 06:03:48.206089+00:00

A drone-based light show turned chaotic after some of the flying machines began falling out of the sky and crashing into the water during the performance.


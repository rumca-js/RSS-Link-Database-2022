# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## FTX: Court says Sam Bankman-Fried ran FTX as a 'personal fiefdom'
 - [https://www.bbc.co.uk/news/business-63720310?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63720310?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-11-22 20:31:34+00:00

FTX's collapse was described in court as "one of most abrupt and difficult" in corporate America.

## Instagram 'wrong' to take down drill music video
 - [https://www.bbc.co.uk/news/technology-63719116?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-63719116?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-11-22 17:46:46+00:00

Meta's independent appeals body criticises the decision to remove the video and says it must be reinstated.

## Apple and Google face gaming and mobile browser probe
 - [https://www.bbc.co.uk/news/technology-63718495?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-63718495?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-11-22 17:15:29+00:00

The UK competition watchdog launches a market investigation into cloud gaming and mobile browsers.

## US tech layoffs: India workers face painful exit from the US
 - [https://www.bbc.co.uk/news/world-asia-india-63658535?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-63658535?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-11-22 00:09:44+00:00

Indians are among thousands of educated and skilled immigrant workers laid off by US tech giants.


# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## SPAC shareholders agree to delay merger with Trump media company
 - [https://www.washingtonpost.com/technology/2022/11/22/merger-trump-media-company-spac-delayed-after-shareholder-vote/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/11/22/merger-trump-media-company-spac-delayed-after-shareholder-vote/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-11-22 19:48:32+00:00

The move buys time as federal regulators investigate the proposed merger that would take the parent of Truth Social public.

## Advertisers are dropping Twitter. Musk can’t afford to lose any more.
 - [https://www.washingtonpost.com/technology/2022/11/22/twitter-advertiser-exodus-musk/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/11/22/twitter-advertiser-exodus-musk/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-11-22 15:13:19+00:00

Dozens of top Twitter advertisers, including 14 of the top 50, have stopped advertising in the few weeks since Elon Musk’s chaotic acquisition of the social media company.

## There will never be anything like Twitter again
 - [https://www.washingtonpost.com/technology/2022/11/22/musk-twitter-dead-idea/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/11/22/musk-twitter-dead-idea/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-11-22 12:30:40+00:00

The struggles of Facebook and Twitter spell the end of the central ideal of social media as a common gathering places for all to gather and listen.

## French regulator warns Twitter of legal duty to moderate misinformation, hate
 - [https://www.washingtonpost.com/technology/2022/11/22/twitter-france-regulator-musk-content-moderation/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/11/22/twitter-france-regulator-musk-content-moderation/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-11-22 11:56:34+00:00

The letter from France's audiovisual and digital regulator Arcom comes as Twitter, under Elon Musk's ownership, has laid off half of its staff.

## Musk’s ‘free speech’ agenda dismantles safety work at Twitter, insiders say
 - [https://www.washingtonpost.com/technology/2022/11/22/elon-musk-twitter-content-moderations/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/11/22/elon-musk-twitter-content-moderations/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-11-22 08:07:41+00:00

Musk arrived at Twitter with a key priority: restore the Babylon Bee.


# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Danny Brown on The Downside of Rap
 - [https://www.youtube.com/watch?v=tCTpie2xivQ](https://www.youtube.com/watch?v=tCTpie2xivQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-11-23 00:00:00+00:00

Taken from JRE #1902 w/Danny Brown:
https://open.spotify.com/episode/2auNrZZKoraDKSE74SpLR6?si=fcd674945a5f4a86

## Author Steven Pressfield on Ego Causing Procrastination; Being a Force of Nature
 - [https://www.youtube.com/watch?v=gaCiKQbMLcY](https://www.youtube.com/watch?v=gaCiKQbMLcY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-11-22 00:00:00+00:00

Taken from JRE #1901 w/Steven Pressfield:
https://open.spotify.com/episode/0sI2Z9HoNdB9RkXw3765qi?si=70044652539d4bc1


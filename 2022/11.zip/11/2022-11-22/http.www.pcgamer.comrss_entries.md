# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## Darktide's 1.0.7 patch makes progress on crashes, lets you fix your ugly face
 - [https://www.pcgamer.com/darktides-107-patch-makes-progress-on-crashes-lets-you-fix-your-ugly-face](https://www.pcgamer.com/darktides-107-patch-makes-progress-on-crashes-lets-you-fix-your-ugly-face)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 23:32:19+00:00

Expect to see improved stability, and haircuts.

## Marvel's Avengers designer removed as spokesperson over offensive tweets
 - [https://www.pcgamer.com/marvels-avengers-designer-removed-as-spokesperson-over-offensive-tweets](https://www.pcgamer.com/marvels-avengers-designer-removed-as-spokesperson-over-offensive-tweets)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 23:30:39+00:00

Brian Waggoner has been a public face for Marvel's Avengers since joining Crystal Dynamics in 2021.

## 12 great gaming laptops for the holidays
 - [https://www.pcgamer.com/12-laptops-holidays](https://www.pcgamer.com/12-laptops-holidays)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 23:26:19+00:00

A dozen Intel and Nvidia-powered gaming laptops to consider for yourself or someone on your list this year.

## How Warhammer 40K: Darktide handles grimoires and scriptures
 - [https://www.pcgamer.com/warhammer-40k-darktide-grimoire-scripture-locations-guide](https://www.pcgamer.com/warhammer-40k-darktide-grimoire-scripture-locations-guide)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 23:14:36+00:00

Things have changed since Vermintide: here's what you need to know about Darktide's bonus items.

## This budget Black Friday gaming PC doesn't look like every other gaming PC
 - [https://www.pcgamer.com/this-budget-black-friday-gaming-pc-doesnt-look-like-every-other-gaming-pc](https://www.pcgamer.com/this-budget-black-friday-gaming-pc-doesnt-look-like-every-other-gaming-pc)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 23:00:12+00:00

For under $1,000, Cyberpower has a stellar white gaming PC.

## Need for Speed Unbound system requirements and unlock times revealed
 - [https://www.pcgamer.com/need-for-speed-unbound-pc-system-requirements](https://www.pcgamer.com/need-for-speed-unbound-pc-system-requirements)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 21:46:53+00:00

The new NFS is out next week.

## Weird West is now playable in first-person thanks to official mod support
 - [https://www.pcgamer.com/weird-west-is-now-playable-in-first-person-thanks-to-official-mod-support](https://www.pcgamer.com/weird-west-is-now-playable-in-first-person-thanks-to-official-mod-support)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 20:08:34+00:00

A handful of mods for the isometric Wild West immersive sim are already available.

## The legal war over Disco Elysium reaches Disco Elysium levels of complexity
 - [https://www.pcgamer.com/the-legal-war-over-disco-elysium-reaches-disco-elysium-levels-of-complexity](https://www.pcgamer.com/the-legal-war-over-disco-elysium-reaches-disco-elysium-levels-of-complexity)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 19:11:18+00:00

Don't you wish there was a decent cop around here?

## These Black Friday AMD graphics card deals have me seriously reconsidering my 8-year allegiance to Nvidia
 - [https://www.pcgamer.com/these-black-friday-amd-graphics-card-deals-have-me-seriously-reconsidering-my-8-year-allegiance-to-nvidia](https://www.pcgamer.com/these-black-friday-amd-graphics-card-deals-have-me-seriously-reconsidering-my-8-year-allegiance-to-nvidia)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 18:53:36+00:00

I don't need to trace my rays anyway.

## The Steam Autumn sale is live now
 - [https://www.pcgamer.com/the-steam-autumn-sale-is-live-now](https://www.pcgamer.com/the-steam-autumn-sale-is-live-now)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 18:33:47+00:00

Shopping season is go.

## One of our favorite wireless headsets is 40% off for Black Friday
 - [https://www.pcgamer.com/one-of-our-favorite-wireless-headsets-is-40-off-for-black-friday](https://www.pcgamer.com/one-of-our-favorite-wireless-headsets-is-40-off-for-black-friday)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 18:03:17+00:00

The Steelseries Arctis 7X is down to just $90.

## My favourite wireless gaming headset is £50 off right now
 - [https://www.pcgamer.com/my-favourite-wireless-gaming-headset-is-pound50-off-right-now](https://www.pcgamer.com/my-favourite-wireless-gaming-headset-is-pound50-off-right-now)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 17:13:15+00:00

I've been using the Razer Barracuda across all my devices lately.

## Signalis review
 - [https://www.pcgamer.com/signalis-review](https://www.pcgamer.com/signalis-review)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 17:10:58+00:00

One of the best psychological sci-fi chillers in years.

## The best way to get Curios in Warhammer 40K: Darktide
 - [https://www.pcgamer.com/warhammer-40000-darktide-curios](https://www.pcgamer.com/warhammer-40000-darktide-curios)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 16:28:23+00:00

Equip these talismans for powerful boons.

## Former Tripwire CEO tells Tucker Carlson that cancel culture 'destroyed' him
 - [https://www.pcgamer.com/former-tripwire-ceo-tells-tucker-carlson-that-cancel-culture-destroyed-him](https://www.pcgamer.com/former-tripwire-ceo-tells-tucker-carlson-that-cancel-culture-destroyed-him)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 15:55:50+00:00

John Gibson, who stepped down as CEO after making anti-abortion comments on social media, appeared in a recent episode of Tucker Carlson Tonight.

## My tiny hands are all over the best 60% gaming keyboard in the Black Friday sales
 - [https://www.pcgamer.com/my-tiny-hands-are-all-over-the-best-60-gaming-keyboard-in-the-black-friday-sales](https://www.pcgamer.com/my-tiny-hands-are-all-over-the-best-60-gaming-keyboard-in-the-black-friday-sales)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 15:38:43+00:00

The best 60% keyboard has never been cheaper.

## After calling online games 'spiritual opium,' China says youth have now kicked the habit
 - [https://www.pcgamer.com/after-calling-online-games-spiritual-opium-china-says-youth-have-now-kicked-the-habit](https://www.pcgamer.com/after-calling-online-games-spiritual-opium-china-says-youth-have-now-kicked-the-habit)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 15:31:42+00:00

A new report from a state-affiliated gaming association is another sign that China's gaming crackdown might be easing.

## Here's how to watch the 40th annual Golden Joystick Awards
 - [https://www.pcgamer.com/heres-how-to-watch-the-40th-annual-golden-joystick-awards](https://www.pcgamer.com/heres-how-to-watch-the-40th-annual-golden-joystick-awards)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 14:49:19+00:00

The gaming Oscars take place today.

## Suspicious: Marvin the Martian joins Multiversus just as Bugs Bunny gets nerfed
 - [https://www.pcgamer.com/suspicious-marvin-the-martian-joins-multiversus-just-as-bugs-bunny-gets-nerfed](https://www.pcgamer.com/suspicious-marvin-the-martian-joins-multiversus-just-as-bugs-bunny-gets-nerfed)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 14:35:59+00:00

"Oh, drat these computers."

## Valheim Wisp guide: How to craft the blue lights you see in the Mistlands
 - [https://www.pcgamer.com/valheim-wisp-fountain-torches-blue-lights-mistlands](https://www.pcgamer.com/valheim-wisp-fountain-torches-blue-lights-mistlands)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 14:07:35+00:00

Standard torches won't help you see through the Mistlands. You'll need a new resource called Wisp, plus an item from Yagluth.

## So I can main a necromancer in Valheim now
 - [https://www.pcgamer.com/so-i-can-main-a-necromancer-in-valheim-now](https://www.pcgamer.com/so-i-can-main-a-necromancer-in-valheim-now)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 14:07:21+00:00

Magic is arriving with Valheim's Mistlands update and it's an absolute blast.

## How to play the Valheim Mistlands update on the public test branch
 - [https://www.pcgamer.com/valheim-mistlands-public-test-branch](https://www.pcgamer.com/valheim-mistlands-public-test-branch)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 14:07:16+00:00

You can try out the Valheim Mistlands update by swapping to the public test branch instead of waiting for the main release.

## The Valheim Mistlands update has so much more in it than just a new biome
 - [https://www.pcgamer.com/valheim-mistlands-update-new-biome](https://www.pcgamer.com/valheim-mistlands-update-new-biome)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 14:07:09+00:00

The new biome is now available on Valheim's test branch, and it's packed full of surprising new features.

## Calling all Vikings! The Valheim Mistlands update is now live on the public test branch
 - [https://www.pcgamer.com/calling-all-vikings-the-valheim-mistlands-update-is-now-live-on-the-public-test-branch](https://www.pcgamer.com/calling-all-vikings-the-valheim-mistlands-update-is-now-live-on-the-public-test-branch)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 14:06:56+00:00

You can finally explore Valheim's long-awaited new biome on the co-op survival game's test branch.

## Floodland review
 - [https://www.pcgamer.com/floodland-review](https://www.pcgamer.com/floodland-review)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 14:05:22+00:00

Beginning at the end in this soggy city builder.

## Warhammer 40,000: Chaos Gate - Daemonhunters' first DLC has Dreadnoughts aplenty
 - [https://www.pcgamer.com/warhammer-40000-chaos-gate-daemonhunters-first-dlc-has-dreadnoughts-aplenty](https://www.pcgamer.com/warhammer-40000-chaos-gate-daemonhunters-first-dlc-has-dreadnoughts-aplenty)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 14:00:00+00:00

And also more floating skulls, if you’re into that sort of thing

## Fortnite crossover gives a taste of open world Rocket League—something Psyonix once considered
 - [https://www.pcgamer.com/fortnite-crossover-gives-us-a-taste-of-open-world-rocket-leaguesomething-psyonix-once-considered](https://www.pcgamer.com/fortnite-crossover-gives-us-a-taste-of-open-world-rocket-leaguesomething-psyonix-once-considered)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 13:46:52+00:00

High octane stuff.

## Cyber Monday graphics card deals 2022: the best prices on pesky pixel pushers
 - [https://www.pcgamer.com/cyber-monday-graphics-card-deals](https://www.pcgamer.com/cyber-monday-graphics-card-deals)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 13:43:33+00:00

Buying a new graphics card can be a minefield, so we'll be on hand to guide you in what actually is a good GPU deal this year.

## Cyber Monday gaming keyboard and mouse deals 2022: majestic mechanicals and righteous rodents
 - [https://www.pcgamer.com/cyber-monday-keyboard-mouse-deals](https://www.pcgamer.com/cyber-monday-keyboard-mouse-deals)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 13:00:20+00:00

The best Cyber Monday deals on gaming mice and gaming keyboards from Razer, Corsair, Logitech, Drop and the rest.

## Brace yourself, Steam's Black Friday discounts will kick off with today's autumn sale
 - [https://www.pcgamer.com/brace-yourself-steams-black-friday-discounts-will-kick-off-with-todays-autumn-sale](https://www.pcgamer.com/brace-yourself-steams-black-friday-discounts-will-kick-off-with-todays-autumn-sale)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 12:58:17+00:00

Money is fake, only videogames are real.

## Warzone 2 has amassed over 25 million players in under a week
 - [https://www.pcgamer.com/call-of-duty-warzone-2-player-count](https://www.pcgamer.com/call-of-duty-warzone-2-player-count)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 12:49:18+00:00

Al Mazrah has been attracting faces new and old.

## Cyber Monday gaming headset deals 2022: giving the gift of great audio this deals season
 - [https://www.pcgamer.com/cyber-monday-gaming-headset-deals](https://www.pcgamer.com/cyber-monday-gaming-headset-deals)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 12:45:42+00:00

Sound can be an easily overlooked area of gaming, but there's no excuse with some of the best gaming headsets on sale right now.

## Cyber Monday gaming chair deals 2022: savings on Secretlab, Herman Miller and more
 - [https://www.pcgamer.com/cyber-monday-gaming-chair-deals](https://www.pcgamer.com/cyber-monday-gaming-chair-deals)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 12:34:40+00:00

As we shift gears from Black Friday to Cyber Monday there will still be discounts on the most lustrous of gaming chairs.

## Modern Warfare 2 players are turning into lethal orangutans with new 'G Walking' glitch
 - [https://www.pcgamer.com/modern-warfare-2-players-are-turning-into-lethal-orangutans-with-new-g-walking-glitch](https://www.pcgamer.com/modern-warfare-2-players-are-turning-into-lethal-orangutans-with-new-g-walking-glitch)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 11:22:34+00:00

Four legs, full clip, can't lose.

## Today's Wordle answer and hint for Tuesday, November 22
 - [https://www.pcgamer.com/wordle-521-answer-november-22](https://www.pcgamer.com/wordle-521-answer-november-22)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 08:05:46+00:00

Wordle today: The solution and a hint for the #521 puzzle.

## Devolver Digital releases Athletic Club apparel with serious indie drip
 - [https://www.pcgamer.com/devolver-digital-releases-athletic-club-apparel-with-serious-indie-drip](https://www.pcgamer.com/devolver-digital-releases-athletic-club-apparel-with-serious-indie-drip)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 04:31:04+00:00

"The Rooster likes hurting people - with sports."

## Warzone 2's scariest weapon is a flying bomb, and that's OK
 - [https://www.pcgamer.com/call-of-duty-warzone-2-bomb-drone-deadliest-weapon](https://www.pcgamer.com/call-of-duty-warzone-2-bomb-drone-deadliest-weapon)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-22 00:15:01+00:00

Sometimes the scary, overpowered weapon is the one from real life.


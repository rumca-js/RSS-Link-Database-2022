# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Propaganda you can trust! — Join me Live
 - [https://www.youtube.com/watch?v=6FP514cKj9s](https://www.youtube.com/watch?v=6FP514cKj9s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-11-23 00:00:00+00:00

Come join me live to dive into highlights from this week and to piss on the dreams of tyrants with our liberty. But most importantly, I’ll be responding to your comments and questions so come ready ;) 

Going LIVE Wednesday, Nov 23 @ 6PM CT.

Chat then!

## What Big Pharma is Like Now
 - [https://www.youtube.com/watch?v=Pbw5Iuc5Li0](https://www.youtube.com/watch?v=Pbw5Iuc5Li0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-11-22 00:00:00+00:00

Get your Infrared Sauna Blanket at https://boncharge.com/jp 
Shop the Black Friday sale until November 30th when all products are 25% off! 

Be the first to see my Comedy Special at https://pleasecensorthis.locals.com

Get your Freedom Merch Here - https://bit.ly/3SqObSZ

Upcoming LIVE shows - https://awakenwithjp.com/pages/tour

Get updates from me via email here: https://awakenwithjp.com/joinme

What big pharma companies are like now...

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
https://rumble.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com


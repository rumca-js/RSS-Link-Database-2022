# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## OSEES - A Foul Form (Live on KEXP)
 - [https://www.youtube.com/watch?v=Y6g_x6FnHJA](https://www.youtube.com/watch?v=Y6g_x6FnHJA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-11-22 00:00:00+00:00

http://KEXP.ORG presents OSEES performing “A Foul Form” live in the KEXP studio. Recorded September 12, 2022.

John Dwyer - Guitar / Vocals
Tim Hellman - Bass
Dan Rincon - Drums
Paul Quattrone - Drums
Tom Dolas - Keys

Host: Troy Nelson
Audio Engineer: Jon Roberts
Audio Mixer: John Dwyer
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Luke Knecht, Matt Ogaz & Ettie Wahl
Editor: Jim Beckmann

https://www.theeohsees.com
http://kexp.org

## OSEES - Fucking Kill Me (Live on KEXP)
 - [https://www.youtube.com/watch?v=sobkWqgwvok](https://www.youtube.com/watch?v=sobkWqgwvok)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-11-22 00:00:00+00:00

http://KEXP.ORG presents OSEES performing “Fucking Kill Me” live in the KEXP studio. Recorded September 12, 2022.

John Dwyer - Guitar / Vocals
Tim Hellman - Bass
Dan Rincon - Drums
Paul Quattrone - Drums
Tom Dolas - Keys

Host: Troy Nelson
Audio Engineer: Jon Roberts
Audio Mixer: John Dwyer
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Luke Knecht, Matt Ogaz & Ettie Wahl
Editor: Jim Beckmann

https://www.theeohsees.com
http://kexp.org

## OSEES - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=bH5MGZ6QTI0](https://www.youtube.com/watch?v=bH5MGZ6QTI0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-11-22 00:00:00+00:00

http://KEXP.ORG presents OSEES performing live in the KEXP studio. Recorded September 12, 2022.

Songs:
Funeral Solution
Scum Show
Fucking Kill Me
A Foul Form
Scramble Suit II
If I Had My Way

John Dwyer - Guitar / Vocals
Tim Hellman - Bass
Dan Rincon - Drums
Paul Quattrone - Drums
Tom Dolas - Keys

Host: Troy Nelson
Audio Engineer: Jon Roberts
Audio Mixer: John Dwyer
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Luke Knecht, Matt Ogaz & Ettie Wahl
Editor: Jim Beckmann

https://www.theeohsees.com
http://kexp.org

## OSEES - Funeral Solution (Live on KEXP)
 - [https://www.youtube.com/watch?v=kRSFKVuvJwE](https://www.youtube.com/watch?v=kRSFKVuvJwE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-11-22 00:00:00+00:00

http://KEXP.ORG presents OSEES performing “Funeral Solution” live in the KEXP studio. Recorded September 12, 2022.

John Dwyer - Guitar / Vocals
Tim Hellman - Bass
Dan Rincon - Drums
Paul Quattrone - Drums
Tom Dolas - Keys

Host: Troy Nelson
Audio Engineer: Jon Roberts
Audio Mixer: John Dwyer
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Luke Knecht, Matt Ogaz & Ettie Wahl
Editor: Jim Beckmann

https://www.theeohsees.com
http://kexp.org

## OSEES - Scramble Suit II / If I Had My Way (Live on KEXP)
 - [https://www.youtube.com/watch?v=paKnD4guEyg](https://www.youtube.com/watch?v=paKnD4guEyg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-11-22 00:00:00+00:00

http://KEXP.ORG presents OSEES performing "Scramble Suit II" and "If I Had My Way"  live in the KEXP studio. Recorded September 12, 2022.

John Dwyer - Guitar / Vocals
Tim Hellman - Bass
Dan Rincon - Drums
Paul Quattrone - Drums
Tom Dolas - Keys

Host: Troy Nelson
Audio Engineer: Jon Roberts
Audio Mixer: John Dwyer
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Luke Knecht, Matt Ogaz & Ettie Wahl
Editor: Jim Beckmann

https://www.theeohsees.com
http://kexp.org

## OSEES - Scum Show (Live on KEXP)
 - [https://www.youtube.com/watch?v=3dv5lgykFSw](https://www.youtube.com/watch?v=3dv5lgykFSw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-11-22 00:00:00+00:00

http://KEXP.ORG presents OSEES performing “Scum Show” live in the KEXP studio. Recorded September 12, 2022.

John Dwyer - Guitar / Vocals
Tim Hellman - Bass
Dan Rincon - Drums
Paul Quattrone - Drums
Tom Dolas - Keys

Host: Troy Nelson
Audio Engineer: Jon Roberts
Audio Mixer: John Dwyer
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Luke Knecht, Matt Ogaz & Ettie Wahl
Editor: Jim Beckmann

https://www.theeohsees.com
http://kexp.org


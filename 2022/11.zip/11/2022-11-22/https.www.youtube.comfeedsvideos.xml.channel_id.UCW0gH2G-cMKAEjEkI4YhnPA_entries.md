# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Unboxing an AUTHENTIC Gandalf Cloak | Lord of the Rings Collectibles Review
 - [https://www.youtube.com/watch?v=OSinyH-Pfkw](https://www.youtube.com/watch?v=OSinyH-Pfkw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-11-22 00:00:00+00:00

https://stansborough.co.nz/
10% Off Coupon Code: NERD22
*Site prices are in New Zealand Dollars*

Authentic Gandalf Lord of the Rings Cloak, created from the actual fabric that was designed and woven by Stansborough for Peter Jackson’s original Trilogy and used for His Wizard cloak in the Movie Trilogy. Patterned and designs from the original piece to be licensed as an authentic Tolkien Character. The unique copyright Stansborough textiles are individually hand crafted collectable pieces. The designs are traditionally woven on historic looms (from the 1890’s)then hand finished and individually created by our Artisan team. The yarns used to weave this product, are spun from our rare grey sheep wool, unique in the world, and used to weave many fabrics for the LOTR, Hobbit and many other movies. Stansborough creates its own textiles for a range of clients worldwide and was delighted to have their exclusive designs used to create the special costumes for the Lord of the Rings Trilogy,so long ago.  Natural, sustainable, biodegradable and no chemicals are used in the processing or creation of these incredible products. A must have piece for every true Lord of the Rings Fan and Follower. Match up with a Gandalf Hat, Magic Silver Scarf or Gloves, authentic pieces also avail from Stansborough.

#gandalf #lordoftherings #unboxing


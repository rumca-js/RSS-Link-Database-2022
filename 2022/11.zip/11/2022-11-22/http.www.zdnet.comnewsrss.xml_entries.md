# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## David's guide to surviving Thanksgiving (2022 edition)
 - [https://www.zdnet.com/article/davids-guide-to-surviving-thanksgiving/#ftag=RSSbaffb68](https://www.zdnet.com/article/davids-guide-to-surviving-thanksgiving/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 22:26:00+00:00

Learn about dark meat turkey, Jedi family management skills, and a little tech. Plus some tips about how to have and enjoy a non-traditional holiday.

## The perfect $16 USB-C tester for your repair kit (and how to use it)
 - [https://www.zdnet.com/home-and-office/the-perfect-usb-c-tester-for-your-repair-toolbox-for-just-16/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/the-perfect-usb-c-tester-for-your-repair-toolbox-for-just-16/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 22:09:00+00:00

This tester is everything you need to test USB-C ports, chargers, and power banks, and at a price that's not going to break the bank.

## The best Amazon tech holiday gift ideas of 2022
 - [https://www.zdnet.com/home-and-office/best-amazon-gift/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/best-amazon-gift/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 20:09:00+00:00

Amazon has you covered this holiday season with techy gift ideas for everyone on your list. We've put together a list of the best tech gifts we could find, from high-tech toys to fitness trackers and even vlogging gear.

## Apple AirPods 3 vs. AirPods Pro (1st Gen): Which earbuds are better?
 - [https://www.zdnet.com/article/apple-airpods-3-vs-airpods-pro-which-wireless-earbuds-are-better/#ftag=RSSbaffb68](https://www.zdnet.com/article/apple-airpods-3-vs-airpods-pro-which-wireless-earbuds-are-better/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 19:32:00+00:00

It's a festive face-off between Apple's AirPods 3 and AirPods Pro (1st Gen). Here's our take on which earbuds reign supreme and all the reasons why.

## TV gift guide: 12 TVs that make great gifts in 2022
 - [https://www.zdnet.com/home-and-office/home-entertainment/tv-gift-guide/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/tv-gift-guide/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 19:32:00+00:00

If you're looking to splurge on a new television for a family member or friend, check these TVs to match your picture with your price point.

## Black Friday 2022 deal: NordPass Premium password manager is 50% off
 - [https://www.zdnet.com/article/nordpass-premium-password-manager-cyber-sale-black-friday-2022-deal/#ftag=RSSbaffb68](https://www.zdnet.com/article/nordpass-premium-password-manager-cyber-sale-black-friday-2022-deal/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 19:26:28+00:00

Limited-time Cyber Sale offer: NordPass Premium is $1.49 per month when buying the two-year plan.

## This clever laptop mount turns your phone into a second screen
 - [https://www.zdnet.com/home-and-office/this-clever-laptop-mount-turns-your-phone-into-a-second-screen/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/this-clever-laptop-mount-turns-your-phone-into-a-second-screen/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 18:37:29+00:00

Rolling Square's Edge kit is perfect for people wanting to work more efficiently on the go.

## Save $700 on the 55-inch Samsung Ark
 - [https://www.zdnet.com/home-and-office/home-entertainment/samsung-ark-deal-coupon-promo-code/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/samsung-ark-deal-coupon-promo-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 18:27:00+00:00

Samsung's biggest gaming monitor features the ability to rotate, and you can score it for $700 off during Black Friday.

## 17+ Black Friday Samsung deals: Save today $300 on Galaxy S22 Ultra, $1,800 on 85-inch TV
 - [https://www.zdnet.com/article/early-samsung-black-friday-deals-november-22-2022/#ftag=RSSbaffb68](https://www.zdnet.com/article/early-samsung-black-friday-deals-november-22-2022/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 18:15:00+00:00

Calling all Samsung fans! Let this early Black Friday deals hub serve as your home ground for the latest and best savings on Samsung Galaxy smartphones, wearables, TVs, appliances, and more.

## 20+ best Black Friday smartphone deals: Save today on top iPhone and Android phones
 - [https://www.zdnet.com/article/early-black-friday-smartphone-deals-november-22-2022/#ftag=RSSbaffb68](https://www.zdnet.com/article/early-black-friday-smartphone-deals-november-22-2022/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 18:09:00+00:00

If you held off on upgrading your smartphone until the holiday shopping season, your patience is finally being rewarded. These are the best early Black Friday deals that will save you hundreds on prime-time handsets.

## Digital trends in sports and entertainment industries: Customer experience drives investments
 - [https://www.zdnet.com/article/digital-trends-in-sports-and-entertainment-industries-customer-experience-drives-investments/#ftag=RSSbaffb68](https://www.zdnet.com/article/digital-trends-in-sports-and-entertainment-industries-customer-experience-drives-investments/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 17:49:17+00:00

Digital transformation priorities in the sports and entertainment industries are focused on improving the customer experience with real-time and hyper-personalized services.

## Framework Chromebook review: The most repairable, future-proof laptop yet
 - [https://www.zdnet.com/article/framework-chromebook-review-the-most-repairable-future-proof-laptop-yet/#ftag=RSSbaffb68](https://www.zdnet.com/article/framework-chromebook-review-the-most-repairable-future-proof-laptop-yet/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 16:00:00+00:00

Framework's highly customizable hardware with Google's ChromeOS is a winning combination for my pro-consumer heart.

## Black Friday security bundle: Arlo's ultimate kit is $400 off
 - [https://www.zdnet.com/home-and-office/smart-home/arlo-security-bundle-deal-coupon-promo-code/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-home/arlo-security-bundle-deal-coupon-promo-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 15:03:00+00:00

Protect your home this holiday season with an excellent security system. Right now, Arlo is offering $400 off a security bundle that includes everything you need.

## Warning: This scam starts with a fake invoice. It could end with crooks stealing your data
 - [https://www.zdnet.com/article/warning-this-scam-starts-with-a-fake-invoice-it-could-end-with-crooks-stealing-your-data/#ftag=RSSbaffb68](https://www.zdnet.com/article/warning-this-scam-starts-with-a-fake-invoice-it-could-end-with-crooks-stealing-your-data/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 14:42:16+00:00

Social engineering and phony call centers are used to trick victims into installing remote software. Then the gang steals data and threatens to leak it.

## After the Moon flyby, what's next for NASA's Artemis I Orion spacecraft?
 - [https://www.zdnet.com/article/after-the-moon-flyby-whats-next-for-nasas-artemis-i-orion-spacecraft/#ftag=RSSbaffb68](https://www.zdnet.com/article/after-the-moon-flyby-whats-next-for-nasas-artemis-i-orion-spacecraft/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 14:18:27+00:00

Now that Orion has passed the Moon, the spacecraft is being maneuvred into a distant retrograde orbit.

## Black Friday 2022 monitor deal: LG 24-inch gaming display is only $109
 - [https://www.zdnet.com/home-and-office/home-entertainment/black-friday-2022-monitor-deal-lg-24-inch-gaming-display-sale-coupon-code/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/black-friday-2022-monitor-deal-lg-24-inch-gaming-display-sale-coupon-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 14:16:00+00:00

Right now, LG's budget-friendly gaming monitor is 45% off at Walmart leading up to Black Friday.

## Ukrainian startups are doing everything they can to keep working. But it isn't easy
 - [https://www.zdnet.com/article/ukrainian-startups-are-doing-everything-they-can-to-keep-working-but-it-isnt-easy/#ftag=RSSbaffb68](https://www.zdnet.com/article/ukrainian-startups-are-doing-everything-they-can-to-keep-working-but-it-isnt-easy/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 13:41:27+00:00

Many Ukrainian startups continue to operate despite damage to critical infrastructure in the country.

## How to connect Bluetooth headphones to a Mac
 - [https://www.zdnet.com/article/how-to-connect-bluetooth-headphones-to-a-mac/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-connect-bluetooth-headphones-to-a-mac/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 13:30:22+00:00

Videoconferencing has become a new norm in the workplace, but there's nothing more awkward than your meeting blasting throughout a quiet office because your headphones won't connect. Here's an easy three-step solution.

## Tech in 2023: 6 new priorities for your shortlist
 - [https://www.zdnet.com/article/tech-in-2023-6-new-priorities-for-your-shortlist/#ftag=RSSbaffb68](https://www.zdnet.com/article/tech-in-2023-6-new-priorities-for-your-shortlist/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 13:00:21+00:00

Here's what the experts think will be the big tech trends for 2023.

## Elon Musk says Twitter's Blue Verified relaunch is delayed
 - [https://www.zdnet.com/article/elon-musk-says-twitters-blue-verified-relaunch-is-delayed/#ftag=RSSbaffb68](https://www.zdnet.com/article/elon-musk-says-twitters-blue-verified-relaunch-is-delayed/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 11:44:17+00:00

Twitter chief Elon Musk eyes a different color checkmark for people and organisations.

## Broadband availability: This new map can help you find out what services are available
 - [https://www.zdnet.com/home-and-office/networking/broadband-availability-this-new-map-can-help-you-find-out-what-services-are-available/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/networking/broadband-availability-this-new-map-can-help-you-find-out-what-services-are-available/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 10:55:39+00:00

The FCC has released its new broadband availability maps and will let residents challenge availability claims by ISPs.

## Black Friday security bundle: Arlo's ultimate kit is $400 off
 - [https://www.zdnet.com/home-and-office/black-friday-security-bundle-arlos-ultimate-kit-deal-sale-coupon-code/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/black-friday-security-bundle-arlos-ultimate-kit-deal-sale-coupon-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 10:10:53+00:00

Arlo is offering $400 off a security bundle with everything you could need to protect your home.

## Black Friday deal: Walmart's LG gaming monitor is only $109
 - [https://www.zdnet.com/home-and-office/black-friday-deal-walmart-offers-lg-gaming-monitor-deal-sale-coupon-code/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/black-friday-deal-walmart-offers-lg-gaming-monitor-deal-sale-coupon-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 10:05:46+00:00

LG's budget-friendly gaming monitor is now 45% off on the run-up to Black Friday.

## Fixing the next big tech skills shortage will need a quantum leap
 - [https://www.zdnet.com/article/fixing-the-next-big-tech-skills-shortage-will-need-a-quantum-leap/#ftag=RSSbaffb68](https://www.zdnet.com/article/fixing-the-next-big-tech-skills-shortage-will-need-a-quantum-leap/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 10:01:31+00:00

Quantum computing companies need talent. But you don't need a PhD to work in technology's most exciting field.

## Crypto exchange urges Singapore to implement 'practical' regulation on back of FTX collapse
 - [https://www.zdnet.com/article/crypto-exchange-urges-singapore-to-implement-practical-regulation-on-back-of-ftx-collapse/#ftag=RSSbaffb68](https://www.zdnet.com/article/crypto-exchange-urges-singapore-to-implement-practical-regulation-on-back-of-ftx-collapse/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 09:01:00+00:00

Independent Reserve wants Singapore to lift its ban on cryptocurrency advertising, urging instead for a regulatory framework that protects consumers, but industry regulator MAS has rebuffed criticism it should have done more amidst the FTX debacle.

## Black Friday 2022 gaming PC deal: HP Omen 25L is $390 off
 - [https://www.zdnet.com/article/black-friday-2022-gaming-pc-deal-hp-omen-25l-coupon-promo-code/#ftag=RSSbaffb68](https://www.zdnet.com/article/black-friday-2022-gaming-pc-deal-hp-omen-25l-coupon-promo-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 06:29:00+00:00

If you want a one-stop shop for all of your gaming needs, saving $390 on this great HP desktop model is the first place to start.

## Black Friday 2022 tablet deal: Save $300 on Microsoft Surface Pro X
 - [https://www.zdnet.com/article/black-friday-2022-tablet-deal-microsoft-surface-pro-x-coupon-promo-code-sale/#ftag=RSSbaffb68](https://www.zdnet.com/article/black-friday-2022-tablet-deal-microsoft-surface-pro-x-coupon-promo-code-sale/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 06:29:00+00:00

With 8GB RAM and 128GB storage, this tablet comes with everything you need to study and excel.

## Black Friday 2022 monitor deal: Samsung's 49-inch Mini LED display is a steal at 35% off
 - [https://www.zdnet.com/article/black-friday-2022-curved-monitor-deal-samsung-uhd-mini-led-display-sale-coupon-promo-code/#ftag=RSSbaffb68](https://www.zdnet.com/article/black-friday-2022-curved-monitor-deal-samsung-uhd-mini-led-display-sale-coupon-promo-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 06:10:00+00:00

Enjoy an immersive gaming experience at 35% off, thanks to its 49-inch 4K UHD Mini LED curved display.

## Black Friday 2022 laptop deal: Lenovo Flex 3 touchscreen Chromebook is only $99
 - [https://www.zdnet.com/article/black-friday-2022-laptop-deal-lenovo-flex-3-touchscreen-chromebook-coupon-promo-code-sale/#ftag=RSSbaffb68](https://www.zdnet.com/article/black-friday-2022-laptop-deal-lenovo-flex-3-touchscreen-chromebook-coupon-promo-code-sale/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 05:58:00+00:00

For under $100, you can get a chromebook for your computing needs, be it travel or just surfing the internet at home.

## Black Friday 2022 TV deal: Sony's 55-inch A80K Google TV is nearly half off
 - [https://www.zdnet.com/home-and-office/home-entertainment/black-friday-2022-tv-deal-sony-55-inch-a80k-oled-tv-promo-code-coupon/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/black-friday-2022-tv-deal-sony-55-inch-a80k-oled-tv-promo-code-coupon/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 05:53:00+00:00

Upgrade your movie nights this fall with an excellent OLED TV. Right now, Sony's 55-inch OLED Smart TV is on sale for 44% off.

## LG Chem to spend $3.2 billion on cathode plant in the US for EV batteries
 - [https://www.zdnet.com/article/lg-chem-to-spend-3-2-billion-on-cathode-plant-in-the-us-for-ev-batteries/#ftag=RSSbaffb68](https://www.zdnet.com/article/lg-chem-to-spend-3-2-billion-on-cathode-plant-in-the-us-for-ev-batteries/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 04:54:05+00:00

The parent company of EV battery maker LG Energy Solution is responding to the US's initiative to localize key supply chains.

## 20+ best Black Friday streaming deals 2022: Save on Roku, Fire TV, Paramount+, and more
 - [https://www.zdnet.com/home-and-office/home-entertainment/black-friday-streaming-deals-november-22-2022/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/black-friday-streaming-deals-november-22-2022/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 04:51:00+00:00

Save on memberships, streaming devices, smart TVs, projectors, and more this Black Friday. Upgrade your entertainment options on a budget.

## 10+ Black Friday 2022 fitness deals: Save today 50% on Lululemon smart mirror and more exercise equipment
 - [https://www.zdnet.com/article/early-black-friday-fitness-deals-november-21-2022/#ftag=RSSbaffb68](https://www.zdnet.com/article/early-black-friday-fitness-deals-november-21-2022/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 03:17:00+00:00

Stay healthy this holiday season with the best early Black Friday fitness deals on home gym equipment and exercise bikes. Right now, you can already save $750 on a Lululemon Smart Mirror.

## 10+ Black Friday 2022 fitness deals: Save today 50% on Lululemon smart mirror and more exercise equipment
 - [https://www.zdnet.com/article/early-black-friday-fitness-deals-november-22-2022/#ftag=RSSbaffb68](https://www.zdnet.com/article/early-black-friday-fitness-deals-november-22-2022/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 03:17:00+00:00

Stay healthy this holiday season with the best early Black Friday fitness deals on home gym equipment and exercise bikes. Right now, you can already save $750 on a Lululemon Smart Mirror.

## 10+ best Black Friday Chromebook deals 2022: HP, Samsung, Acer, and more laptops on sale today
 - [https://www.zdnet.com/article/early-black-friday-chromebook-deals-november-21-2022/#ftag=RSSbaffb68](https://www.zdnet.com/article/early-black-friday-chromebook-deals-november-21-2022/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 03:04:00+00:00

Chromebooks are perfect for everything -- from classroom work and web browsing to streaming movies and working on the go. But with laptops seeing a price increase over the years, it's hard to find the perfect laptop without breaking the bank. Here are our top picks.

## 10+ best Black Friday Chromebook deals 2022: HP, Samsung, Acer, and more laptops on sale today
 - [https://www.zdnet.com/article/early-black-friday-chromebook-deals-november-22-2022/#ftag=RSSbaffb68](https://www.zdnet.com/article/early-black-friday-chromebook-deals-november-22-2022/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 03:04:00+00:00

Chromebooks are perfect for everything -- from classroom work and web browsing to streaming movies and working on the go. But with laptops seeing a price increase over the years, it's hard to find the perfect laptop without breaking the bank. Here are our top picks.

## 15+ best smartwatch Black Friday deals 2022: Save today on Apple Watch, Galaxy Watch, and Fitbit
 - [https://www.zdnet.com/article/early-black-friday-smartwatch-deals-november-21-2022/#ftag=RSSbaffb68](https://www.zdnet.com/article/early-black-friday-smartwatch-deals-november-21-2022/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 02:47:00+00:00

These days, you can get access to thousands of deals online nearly a month before Black Friday. Check out these early deals on smartwatches from the comfort of your own home this holiday season.

## 20+ best Black Friday security camera deals 2022: Save today 50% on Blink and Arlo bundles
 - [https://www.zdnet.com/home-and-office/smart-home/early-black-friday-security-camera-deals-november-21-2022/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-home/early-black-friday-security-camera-deals-november-21-2022/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 02:46:00+00:00

Looking for some extra peace of mind at home but don't want to pay full price? You can save on security cameras right now if you know where to look.

## 10+ best Newegg Black Friday deals 2022: Save today on gaming PCs, laptops, and monitors
 - [https://www.zdnet.com/article/early-newegg-black-friday-deals-november-21-2022/#ftag=RSSbaffb68](https://www.zdnet.com/article/early-newegg-black-friday-deals-november-21-2022/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 02:45:00+00:00

Before this Black Friday, Newegg is offering loads of deals on everything from sound systems to gaming PCs. Some come with a bonus Black Friday price guarantee.

## 40+ best Costco Black Friday deals 2022: Save on TVs, laptops, tablets, and more today
 - [https://www.zdnet.com/home-and-office/early-costco-black-friday-deals-november-21-2022/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/early-costco-black-friday-deals-november-21-2022/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 02:38:00+00:00

Costco doesn't disappoint when it comes to savings, and it's continuing the tradition for Black Friday 2022. But you don't have to wait; ZDNET gathered the best deals at Costco right now.

## 20+ best Black Friday smartphone deals: Save today on top iPhone and Android phones
 - [https://www.zdnet.com/article/early-black-friday-smartphone-deals-november-21-2022/#ftag=RSSbaffb68](https://www.zdnet.com/article/early-black-friday-smartphone-deals-november-21-2022/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-22 02:24:00+00:00

If you held off on upgrading your smartphone until the holiday shopping season, your patience is finally being rewarded. These are the best early Black Friday deals that will save you hundreds on prime-time handsets.


# Source:Lifehacker, URL:https://lifehacker.com/rss, language:en-US

## What's New on Prime Video in December 2022
 - [https://lifehacker.com/whats-new-on-prime-video-in-december-2022-1849814629](https://lifehacker.com/whats-new-on-prime-video-in-december-2022-1849814629)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-22 22:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--NyKUURoL--/c_fit,fl_progressive,q_80,w_636/12bf2f9c4165f453166a20420e1c977e.jpg" /><p>Back in my day, TV shows had the decency to return from hiatus every September, like clockwork. In the streaming arena, that clock is broken. Shows return whenever they feel like it. Two half-length seasons six weeks apart? A full year between seasons, with all episodes dropping on the same day? Sure, why not. Take…</p><p><a href="https://lifehacker.com/whats-new-on-prime-video-in-december-2022-1849814629">Read more...</a></p>

## Why Black Friday Is a Bad Day to Impulse Buy Electronics
 - [https://lifehacker.com/why-black-friday-is-a-bad-day-to-impulse-buy-electronic-1849814063](https://lifehacker.com/why-black-friday-is-a-bad-day-to-impulse-buy-electronic-1849814063)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-22 22:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--l_ulSydx--/c_fit,fl_progressive,q_80,w_636/7e6cea41309801d0f2bd07a476b1e667.jpg" /><p>Food, clothes, home goods: If you can buy it, chances are there’s a <a href="https://lifehacker.com/the-best-black-friday-food-deals-and-freebies-1849803447">Black Friday deal</a> being advertised for it. But just because you’re snagging something with a so-called Black Friday markdown doesn’t mean you’re actually getting the best deal in the long run. With electronics in particular, the cheap price tag might…</p><p><a href="https://lifehacker.com/why-black-friday-is-a-bad-day-to-impulse-buy-electronic-1849814063">Read more...</a></p>

## 10 Common Thanksgiving Stains (and How to Remove Them)
 - [https://lifehacker.com/10-common-thanksgiving-stains-and-how-to-remove-them-1849813939](https://lifehacker.com/10-common-thanksgiving-stains-and-how-to-remove-them-1849813939)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-22 21:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--3mWh42my--/c_fit,fl_progressive,q_80,w_636/281e3016c8986ab44efd9875c669c07d.jpg" /><p>Thanksgiving is almost here, which means you’re probably already <a href="https://lifehacker.com/15-ways-to-simplify-your-post-thanksgiving-cleanup-1849781695">cleaning</a> your house and <a href="https://lifehacker.com/all-the-ways-a-cooler-or-three-will-help-you-survive-1849785357">prepping</a> the meal. It’s a lot of work...but then you get to enjoy the eating. Yay! But then you have to focus on cleaning again. Boo! <br /><br />The trouble with Thanksgiving is that it  involves so many super delicious foods  that just so…</p><p><a href="https://lifehacker.com/10-common-thanksgiving-stains-and-how-to-remove-them-1849813939">Read more...</a></p>

## Add a Wee Emoji to Your iPhone’s Clock, Because You Deserve a Little Happiness
 - [https://lifehacker.com/add-a-wee-emoji-to-your-iphone-s-clock-because-you-des-1849813558](https://lifehacker.com/add-a-wee-emoji-to-your-iphone-s-clock-because-you-des-1849813558)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-22 20:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--AvDpav6U--/c_fit,fl_progressive,q_80,w_636/93d259e4c58d998b8a3281e61172cdfb.jpg" /><p>It’s true iOS isn’t <em>as</em> customizable as Android, but the gap is much narrower than it used to be. These days, your can <a href="https://lifehacker.com/all-the-ways-you-can-customize-your-iphone-s-lock-scree-1849310427">personalize your iPhone’s Lock Screen</a>, <a href="https://lifehacker.com/how-to-customize-your-iphone-home-screen-in-ios-14-1845450222">change your app icons to anything you like</a>, and even <a href="https://lifehacker.com/add-a-digital-pet-to-your-iphone-1849553713">add a digital pet to the Dynamic Island</a>. If you’re in the market for yet another iPhone customization hack,…</p><p><a href="https://lifehacker.com/add-a-wee-emoji-to-your-iphone-s-clock-because-you-des-1849813558">Read more...</a></p>

## These Easy Batch-Baked Eggs Are Perfect for Thanksgiving Morning
 - [https://lifehacker.com/these-easy-batch-baked-eggs-are-perfect-for-thanksgivin-1849813715](https://lifehacker.com/these-easy-batch-baked-eggs-are-perfect-for-thanksgivin-1849813715)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-22 20:03:02+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--lIc8LPUq--/c_fit,fl_progressive,q_80,w_636/7ed90928a3ad59f512d2a784941203a8.jpg" /><p>Thanksgiving is coming in hot, and for some households, dinner prep will be non-stop from 5 a.m. until the forks hit the plate. I know some will claim to fast until the big meal, but I don’t ever think you should hit the court without warming up first: There’s no shame in Thanksgiving breakfast, but there <em>is</em> a lack of…</p><p><a href="https://lifehacker.com/these-easy-batch-baked-eggs-are-perfect-for-thanksgivin-1849813715">Read more...</a></p>

## Every Samsung Phone Has a Hidden Chihuahua for Some Reason
 - [https://lifehacker.com/every-samsung-phone-has-a-hidden-chihuahua-for-some-rea-1849812864](https://lifehacker.com/every-samsung-phone-has-a-hidden-chihuahua-for-some-rea-1849812864)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-22 19:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--wJFUnOXH--/c_fit,fl_progressive,q_80,w_636/c2c0725a5bd599444d67d2c1a29ce721.jpg" /><p>I’m not trying to bullshit you. If you have a Samsung Galaxy—virtually any one of them—then you have a hidden chihuahua on your phone.  You would never stumble upon it, which is why you’ve likely never seen nor known about it, but it’s there, lurking, ready to greet you at a moment’s notice.<br /></p><p><a href="https://lifehacker.com/every-samsung-phone-has-a-hidden-chihuahua-for-some-rea-1849812864">Read more...</a></p>

## What's New on Hulu in December 2022
 - [https://lifehacker.com/whats-new-on-hulu-in-december-2022-1849813413](https://lifehacker.com/whats-new-on-hulu-in-december-2022-1849813413)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-22 19:04:02+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--c7-KuZQ9--/c_fit,fl_progressive,q_80,w_636/ea33250a059d52cbb8a4f3abd7e6a18f.jpg" /><p>Octavia Butler, the venerable science fiction writer and futurist, died unexpectedly in 2006. That spared her from witnessing just how terrifyingly prescient was her 1993 post-apocalyptic novel <em>The Parable of the Sower.</em> But it also robbed her of seeing her work, once relegated to the fringes of genre fiction, embraced…</p><p><a href="https://lifehacker.com/whats-new-on-hulu-in-december-2022-1849813413">Read more...</a></p>

## How to Tell If an Ex Is ‘Winter Coating’ You This Holiday Season
 - [https://lifehacker.com/how-to-tell-if-an-ex-is-winter-coating-you-this-holid-1849811113](https://lifehacker.com/how-to-tell-if-an-ex-is-winter-coating-you-this-holid-1849811113)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-22 18:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--M8DIQh30--/c_fit,fl_progressive,q_80,w_636/67e0ff567f019c218b4e78153e9932a9.jpg" /><p>The holiday season is ripe with nostalgia, so it’s not totally surprising that you might receive a text from a curious ex during this time. An innocent text is one thing but if an ex comes strolling back into your life, wanting to rekindle things as soon as the nights get a little colder, you might be on the receiving…</p><p><a href="https://lifehacker.com/how-to-tell-if-an-ex-is-winter-coating-you-this-holid-1849811113">Read more...</a></p>

## No, Space Heaters Aren’t Really Cheaper Than Turning Up the Thermostat
 - [https://lifehacker.com/no-space-heaters-aren-t-really-cheaper-than-turning-up-1849810019](https://lifehacker.com/no-space-heaters-aren-t-really-cheaper-than-turning-up-1849810019)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-22 18:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--m2XY9-UW--/c_fit,fl_progressive,q_80,w_636/8ba082652ccd8283072719b33f30dfc3.jpg" /><p>We’re in for <a href="https://www.weforum.org/agenda/2022/10/heating-energy-united-states-cost-of-living/" rel="noopener noreferrer" target="_blank">expensive gas bills this winter</a>. Whenever I so much as <em>think</em> about turning up the thermostat, I can hear my dad’s voice telling me to put on another sweater instead. But when sweaters don’t suffice, I turn to my trusty, cheap, easy-to-use space heater to cut costs on my central heating. But how much money…</p><p><a href="https://lifehacker.com/no-space-heaters-aren-t-really-cheaper-than-turning-up-1849810019">Read more...</a></p>

## Improve Your Safari Browsing Experience With These Automatic Redirects
 - [https://lifehacker.com/improve-your-safari-browsing-experience-with-these-auto-1849812013](https://lifehacker.com/improve-your-safari-browsing-experience-with-these-auto-1849812013)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-22 17:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--kkYP0qSE--/c_fit,fl_progressive,q_80,w_636/b4c211e4075cbbe5e0e602445ca53294.jpg" /><p>Browsing the internet has its perils. Some websites are borderline unusable thanks to pop-ups, ads, or poor design. If you encounter these sites frequently, automatic redirects can help take you to a better place (on the internet, at least).<br /></p><p><a href="https://lifehacker.com/improve-your-safari-browsing-experience-with-these-auto-1849812013">Read more...</a></p>

## What's New on Netflix in December 2022
 - [https://lifehacker.com/whats-new-on-netflix-in-december-2022-1849812600](https://lifehacker.com/whats-new-on-netflix-in-december-2022-1849812600)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-22 17:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--o4gMsWMn--/c_fit,fl_progressive,q_80,w_636/b2240cc537c6733beaaaa03e27e4558d.jpg" /><p>Back in the old days, when theaters still made actual money showing movies that weren’t part of a “cinematic universe,” December was the best time of year to be a cinema junkie. That was when, in the final weeks of the year, studios would release all of their most lavishly produced, high-minded star vehicles, in the…</p><p><a href="https://lifehacker.com/whats-new-on-netflix-in-december-2022-1849812600">Read more...</a></p>

## 10 of the Best Subscription Kits to Give Kids This Year
 - [https://lifehacker.com/10-of-the-best-subscription-kits-to-give-kids-this-year-1849812007](https://lifehacker.com/10-of-the-best-subscription-kits-to-give-kids-this-year-1849812007)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-22 16:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--PeLkfa5N--/c_fit,fl_progressive,q_80,w_636/ceefccbe2cf6c0bd0709c9be532d8868.jpg" /><p>It can make your heart sink when you realize the holiday gift you searched for all month is already gathering dust just after New Year’s. How often does the latest fad your kid is obsessed with end up as another flop headed to Goodwill Instead of risking bodily harm this holiday season for something plush or plasticy…</p><p><a href="https://lifehacker.com/10-of-the-best-subscription-kits-to-give-kids-this-year-1849812007">Read more...</a></p>

## Don’t Just Roast Your Turkey, Roulade It
 - [https://lifehacker.com/don-t-just-roast-your-turkey-roulade-it-1849811890](https://lifehacker.com/don-t-just-roast-your-turkey-roulade-it-1849811890)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-22 16:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--k05KO2zQ--/c_fit,fl_progressive,q_80,w_636/314b92d48627fff65639e5ab0e1e10bb.jpg" /><p>Wrestling a whole turkey body into a roasting pan (or <a href="https://lifehacker.com/don-t-cook-your-turkey-in-a-roasting-pan-1849757979">rather, onto a wire rack</a>), isn’t for everyone. Even I, a seasoned professional, have to steel myself for the gory moments of cutting through bone when I spatchcock a bird, and I would be totally OK with never having to smash in a breast bone again. If you have…</p><p><a href="https://lifehacker.com/don-t-just-roast-your-turkey-roulade-it-1849811890">Read more...</a></p>

## 10 of the Most Banned Books (and What We Can Learn From Them)
 - [https://lifehacker.com/10-of-the-most-banned-books-and-what-we-can-learn-from-1849810897](https://lifehacker.com/10-of-the-most-banned-books-and-what-we-can-learn-from-1849810897)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-22 15:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--HjWqkwC2--/c_fit,fl_progressive,q_80,w_636/967cd66e36d9b72c96f0bb38215fcdd6.jpg" /><p>2021 was a banner year for calls to ban books. According to the <a href="https://www.ala.org/news/press-releases/2022/09/ala-releases-preliminary-data-2022-book-bans#:~:text=In%202021,%20ALA%20reported%20729,library%20resources%20targeted%20multiple%20titles." rel="noopener noreferrer" target="_blank">American Library Association,</a> there were 729 attempts to censor libraries, targeting 1,597 books—the highest amount since the ALA started keeping track 20 years ago. Most of these were school libraries.<br /></p><p><a href="https://lifehacker.com/10-of-the-most-banned-books-and-what-we-can-learn-from-1849810897">Read more...</a></p>

## Stop Following New Finance 'Trends'
 - [https://lifehacker.com/stop-following-new-finance-trends-1849809947](https://lifehacker.com/stop-following-new-finance-trends-1849809947)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-22 15:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--CBi3sCQE--/c_fit,fl_progressive,q_80,w_636/384772d93cfece72772e2154978f9180.jpg" /><p>Whether it’s investing in the newest cryptocurrency, or eyeing some type of “<em>make money while doing nothing!</em>” scheme, it can be hard to resist all the shiny “new” finance trends that constantly pop up. Often, though, these trends aren’t actually all that new—and even if they are, it’s important to look for signs that…</p><p><a href="https://lifehacker.com/stop-following-new-finance-trends-1849809947">Read more...</a></p>

## What's New on Disney+ in December 2022
 - [https://lifehacker.com/whats-new-on-disney-in-december-2022-1849811792](https://lifehacker.com/whats-new-on-disney-in-december-2022-1849811792)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-22 14:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--HlQrPaoK--/c_fit,fl_progressive,q_80,w_636/f7f22cee1d42fa675761303c933a6c0b.jpg" /><p>The first <em>National Treasure </em>film was released in 2004, an archeological dive into the United States’ founding myths that played sort of like a louder, dumber Indiana Jones crossed with <em>The Da Vinci Code</em>. Of course it was a hit, prompting the creation of a sequel and no doubt funding the purchase of <a href="https://financebuzz.com/finance-nicolas-cage-buying-spree" rel="noopener noreferrer" target="_blank">several additional…</a></p><p><a href="https://lifehacker.com/whats-new-on-disney-in-december-2022-1849811792">Read more...</a></p>

## How to Curse Your Enemies
 - [https://lifehacker.com/how-to-curse-your-enemies-1849791469](https://lifehacker.com/how-to-curse-your-enemies-1849791469)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-22 14:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--XOb5h4ok--/c_fit,fl_progressive,q_80,w_636/4feee1fde52255626f75aac46059ae32.png" /><p>So you want to lay a curse on your enemies? I’m not going to judge—I’m sure they deserve it. But if you want to hex, jinx, bedevil, imprecate, and otherwise lay down powerful gris-gris on your foes, you better do it <em>right. </em>So follow our no-nonsense guide to practical cursing using two of history’s most famous methods…</p><p><a href="https://lifehacker.com/how-to-curse-your-enemies-1849791469">Read more...</a></p>


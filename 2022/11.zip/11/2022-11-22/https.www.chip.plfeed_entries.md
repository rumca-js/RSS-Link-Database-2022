# Source:Chip.pl, URL:https://www.chip.pl/feed, language:pl-PL

## Sztuczna inteligencja mistrzem dyplomacji. Powoli możemy czuć się zagrożeni
 - [https://www.chip.pl/2022/11/sztuczna-inteligencja-gra-diplomacy](https://www.chip.pl/2022/11/sztuczna-inteligencja-gra-diplomacy)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-22 20:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="770" src="https://konto.chip.pl/wp-content/uploads/2022/10/robot.jpg" style="margin-bottom: 10px;" width="1300" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/10/robot.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Sztuczna inteligencja na różne sposoby wykazywała już wyższość nad naszym gatunkiem, choć w wielu dziedzinach pozostaje (jeszcze) za ludźmi. Jedną z tych, w których powoli nas natomiast dogania może być dyplomacja. Jak się okazuje, za potencjalnym przełomem stoją przedstawiciele laboratorium sztucznej inteligencji zwanego Meta AI. Wykorzystali w tym celu narzędzie CICERO, pierwsze o wydajności na [&#8230;]</p>

## Założyłem konto na Mastodon. Prawie nic nie kumam, ale podoba mi się
 - [https://www.chip.pl/2022/11/wszedlem-w-mastodon-nie-kumam-jeszcze](https://www.chip.pl/2022/11/wszedlem-w-mastodon-nie-kumam-jeszcze)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-22 19:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1006" src="https://konto.chip.pl/wp-content/uploads/2022/11/mastodon-jak-dziala-1.jpg" style="margin-bottom: 10px;" width="1789" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/mastodon-jak-dziala-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Powoli kończy mi się popcorn. Pożeram go kubełkami, obserwując poczynania Elona Muska w filmie sensacyjnym pt. &#8220;Kochanie, kupiłem Twittera&#8220;. Przy tej okazji zdecydowałem się sprawdzić co przyciąga ludzi do Mastodona, nabierającej popularności alternatywy dla popularnego &#8220;ćwierkacza&#8221;. Mijają dwa tygodnie i wiecie co? Rozumiem pewnie z 1/10 tego jak to działa, ale po raz pierwszy od [&#8230;]</p>

## Amerykanie zbroją się przeciwko cukrzycy. Pierwszy lek wstrzymujący rozwój cukrzycy już dostępny
 - [https://www.chip.pl/2022/11/lek-wstrzymujacy-rozwoj-cukrzycy](https://www.chip.pl/2022/11/lek-wstrzymujacy-rozwoj-cukrzycy)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-22 18:00:00+00:00

<img alt="lek wstrzymujący rozwój cukrzycy typu 1" class="attachment-full size-full wp-post-image" height="1673" src="https://konto.chip.pl/wp-content/uploads/2022/01/insulina-cukrzyca-zastrzyk.jpg" style="margin-bottom: 10px;" width="2507" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/01/insulina-cukrzyca-zastrzyk.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Rynek medycyny w Stanach Zjednoczonych zaliczył właśnie wielki przełom po tym, jak oficjalnie zatwierdzono wprowadzenie pierwszego leku wstrzymującego rozwój cukrzycy typu pierwszego. Mowa o przeciwdziałaniu rozwojowi przewlekłej choroby zarówno u dzieci, jak i dorosłych. Lek wstrzymujący rozwój cukrzycy typu 1 jest już dostępny w USA Cukrzyca typu pierwszego jest zaliczana do chorób autoimmunologicznych, w przypadku [&#8230;]</p>

## Hasło &#8220;hasło&#8221; nadal na topie. Podpowiadamy, jak wymyślić hasło, którego nie złamie trzylatek
 - [https://www.chip.pl/2022/11/jak-wymyslic-silne-haslo-najgorsze-hasla-2022-roku](https://www.chip.pl/2022/11/jak-wymyslic-silne-haslo-najgorsze-hasla-2022-roku)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-22 17:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2021/11/cyberbezpieczenstwo-rola-bankow.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2021/11/cyberbezpieczenstwo-rola-bankow.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Żyjemy w dobie ciągłego zagrożenia różnego rodzaju cyberatakami i choć nie zawsze jesteśmy w stanie się przed nimi obronić, to jest kilka sposobów na zminimalizowanie ryzyka. Jednym z nich jest z pewnością ustawianie silnych haseł i chociaż w Internecie trąbi się o tym na lewo i prawo od wielu lat, to nadal zatrważająca ilość osób [&#8230;]</p>

## Tak wygląda prawdziwe premium. Vivo X90 Pro+ powala urodą i możliwościami
 - [https://www.chip.pl/2022/11/vivo-x90-premiera-specyfikacja-ceny](https://www.chip.pl/2022/11/vivo-x90-premiera-specyfikacja-ceny)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-22 16:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="689" src="https://konto.chip.pl/wp-content/uploads/2022/11/vivo-x90-premiera-2.jpg" style="margin-bottom: 10px;" width="1200" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/vivo-x90-premiera-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Zgodnie z zapowiedzią, Vivo zaprezentowało dzisiaj swoją najnowszą flagową serię jednocześnie dostarczając na rynek pierwszy na świecie smartfon wyposażony w układ Snapdragon 8 Gen 2. Wykorzystany chipset nie jest jednak jedynym, na co warto zwrócić uwagę w serii Vivo X90. Seria Vivo X90 składa się z trzech smartfonów &#8211; X90, X90 Pro i X90 Pro+. [&#8230;]</p>

## Rząd chce zainstalować aplikacje na twoim smartfonie. Ustawa nie ma sensu, ale jest &#8211; można odtrąbić sukces
 - [https://www.chip.pl/2022/11/rzadowe-aplikacje-obowiazek-instalowania-rso-mswia](https://www.chip.pl/2022/11/rzadowe-aplikacje-obowiazek-instalowania-rso-mswia)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-22 15:56:20+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="982" src="https://konto.chip.pl/wp-content/uploads/2022/11/aplikacje-rzadowe-obowiazek-1.jpg" style="margin-bottom: 10px;" width="1745" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/aplikacje-rzadowe-obowiazek-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>MSWiA nie porzuciło pomysłu instalowania rządowych aplikacji na nowych smartfonach. Ministerstwo chyba w końcu zrozumiało, że wszyscy autoryzowani sprzedawcy nie są w stanie tego wykonać, więc zmienia ustawę i zrzuca ten obowiązek na operatorów. Rządowe aplikacje na każdym nowym smartfonie Przypomnijmy, że cała sprawa zrobiła się głośna na początku września. Nowy projekt ustawy o ochronie [&#8230;]</p>

## Test Xiaomi Redmi Pad – sprawdzamy, co potrafi pierwszy tablet z certyfikatem SGS Low Visual Fatigue
 - [https://www.chip.pl/2022/11/test-xiaomi-redmi-pad-recenzja-specyfikacja](https://www.chip.pl/2022/11/test-xiaomi-redmi-pad-recenzja-specyfikacja)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-22 15:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="816" src="https://konto.chip.pl/wp-content/uploads/2022/11/20221118_105535.jpg" style="margin-bottom: 10px;" width="1450" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/20221118_105535.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Xiaomi Redmi Pad zadebiutował na rynku całkiem niedawno, bo w październiku. W założeniu ma być to porządny, ale i niedrogi tablet do codziennego użytku. Czy faktycznie dobrze spełnia się w tej roli i czym jest tajemniczy certyfikat SGS? Specyfikacja Xiaomi Redmi Pad Co w zestawie? Kupując Xiaomi Redmi Pad w pudełku, poza samym tabletem znajdziemy [&#8230;]</p>

## Użyj tylko taśmy dwustronnej, a wygenerujesz prąd. Podczas eksperymentu zaświeciło się 476 żarówek
 - [https://www.chip.pl/2022/11/prad-z-tasmy-klejacej-diody](https://www.chip.pl/2022/11/prad-z-tasmy-klejacej-diody)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-22 14:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2022/11/scissors-2116979_1920.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/scissors-2116979_1920.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Sposobów, na jakie można wygenerować prąd elektryczny, jest niezliczona ilość, ale o dwustronnej taśmie klejącej jeszcze nie pomyślał nikt. Amerykańscy naukowcy stworzyli model generatora tryboelektrycznego, który był w stanie zaświecić 476 żarówek LED. Jak oni tego dokonali? Na łamach ASC Omega pojawiła się praca naukowa badaczy z Uniwersytetu Alabama, którzy wykonali generator tryboelektryczny oparty na [&#8230;]</p>

## Steam Deck rozłożony na łopatki. OneXPlayer 2 łączy potężne podzespoły i wygodę Nintendo Switcha
 - [https://www.chip.pl/2022/11/nowy-handheld-onexplayer-2](https://www.chip.pl/2022/11/nowy-handheld-onexplayer-2)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-22 13:30:00+00:00

<img alt="Nowy handheld dla graczy OneXPlayer 2" class="attachment-full size-full wp-post-image" height="1100" src="https://konto.chip.pl/wp-content/uploads/2022/11/Steam-Deck-rozlozony-na-lopatki.-Nowy-handheld-dla-graczy-OneXPlayer-2-ustapi-jednak-propozycji-Valve-w-najwazniejszym-1.jpg" style="margin-bottom: 10px;" width="2272" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/Steam-Deck-rozlozony-na-lopatki.-Nowy-handheld-dla-graczy-OneXPlayer-2-ustapi-jednak-propozycji-Valve-w-najwazniejszym-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Przez ostatni rok firma Valve jest na językach wszystkich graczy, którzy patrzą z uwielbieniem na handheldy, czyli takie &#8220;ultraprzenośne komputery-konsole&#8221;. Steam Deck podbił rynek i choć do konsol pokroju Nintendo Switch mu daleko, to sprzedał się na tyle dobrze, że Valve już planuje wydać jego drugą generację. Zanim to jednak nastąpi, obecny Steam Deck będzie [&#8230;]</p>

## I co, może rybki do tego? Połączenie komputera z akwarium jest dokładnie tak głupie, jak się wydaje
 - [https://www.chip.pl/2022/11/obudowa-z-akwarium-test](https://www.chip.pl/2022/11/obudowa-z-akwarium-test)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-22 11:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="902" src="https://konto.chip.pl/wp-content/uploads/2022/11/I-co-moze-rybki-do-tego-Przy-tej-obudowie-twoja-stara-moze-sie-schowac.jpg" style="margin-bottom: 10px;" width="1600" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/I-co-moze-rybki-do-tego-Przy-tej-obudowie-twoja-stara-moze-sie-schowac.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Akwarystyka to jedna z tych dziedzin, które po prostu nie mogą iść w parze z technologią komputerową. Tak przynajmniej podpowiada rozsądek, bo już w sierpniu świat dowiedział się o obudowie MetalFish Y2 Fish Tank Chassis, czyli obudowy komputerowej z dodatkiem pełnoprawnego akwarium. Właśnie przetestował ją serwis PC Watch, dochodząc do ciekawych, choć niezbyt odkrywczych wniosków. [&#8230;]</p>

## Głośniki w twoim następnym samochodzie mogą być niewidzialne. LG już nad tym pracuje
 - [https://www.chip.pl/2022/11/lg-display-glosniki-samochodowe](https://www.chip.pl/2022/11/lg-display-glosniki-samochodowe)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-22 10:00:00+00:00

<img alt="głośniki samochodowe od LG Display" class="attachment-full size-full wp-post-image" height="739" src="https://konto.chip.pl/wp-content/uploads/2022/11/Niewidzialne-glosniki-samochodowe-od-LG-Display-czyli-obietnica-systemow-audio-nowej-generacji-1.jpg" style="margin-bottom: 10px;" width="1239" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/Niewidzialne-glosniki-samochodowe-od-LG-Display-czyli-obietnica-systemow-audio-nowej-generacji-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>LG Display chwali się swoim najnowszym osiągnięciem. Stworzyła bowiem &#8220;niewidzialne głośniki samochodowe&#8221; o nazwie Thin Actuator Sound Solution. Do niewidzialnych wprawdzie bardzo im daleko, ale i tak są bardziej innowacyjne, niż na pierwszy rzut oka może się wydawać. Wielkie, ciężkie i energochłonne. Głośniki samochodowe muszą doczekać się zmian i to właśnie proponuje LG Display System [&#8230;]</p>

## Naładujesz swojego elektryka szybciej, niż myślisz. Akumulatory eTechnology rzucają wyzwanie tradycyjnemu tankowaniu
 - [https://www.chip.pl/2022/11/akumulatory-etechnology-morand-ultrakondensator](https://www.chip.pl/2022/11/akumulatory-etechnology-morand-ultrakondensator)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-22 09:04:00+00:00

<img alt="Akumulatory eTechnology" class="attachment-full size-full wp-post-image" height="1059" src="https://konto.chip.pl/wp-content/uploads/2022/11/Ladowanie-samochodu-elektrycznego-kilkaset-sekund.-Akumulatory-eTechnology-z-cechami-ultrakondensatorow-obiecuja-wiele-2.jpg" style="margin-bottom: 10px;" width="1911" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/Ladowanie-samochodu-elektrycznego-kilkaset-sekund.-Akumulatory-eTechnology-z-cechami-ultrakondensatorow-obiecuja-wiele-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Co powiecie na wyjątkowy rodzaj akumulatorów, łączących pojemność tradycyjnych ogniw chemicznych i szybkość ładowania ultrakondensatorów? To właśnie obiecuje firma Morand pod postacią akumulatorów eTechnology, z którymi proces ładowania samochodu elektrycznego mierzylibyśmy w sekundach, a nie minutach. Wyjątkowy rodzaj akumulatorów pod nazwą o równie wyjątkowej spuściźnie, czyli eTechnology od firmy Morand Morand może przypominać o kimś [&#8230;]</p>

## Pływające panele słoneczne robią wrażenie, ale te potrafią coś jeszcze
 - [https://www.chip.pl/2022/11/plywajace-panele-sloneczne-solarisfloat](https://www.chip.pl/2022/11/plywajace-panele-sloneczne-solarisfloat)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-22 08:00:18+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="671" src="https://konto.chip.pl/wp-content/uploads/2022/11/panele-1.jpg" style="margin-bottom: 10px;" width="1300" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/panele-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Panele słoneczne mogą być zarówno statyczne, jak i przebywać w ciągłym ruchu. W grę wchodzi nawet wynoszenie ich na orbitę, gdzie mogłyby zbierać energię przez całą dobę. Na uwagę bez wątpienia zasługuje też pomysł portugalskiej firmy SolarisFloat. Jej przedstawiciele zaprojektowali bowiem swego rodzaju pływającą wyspę, którą tworzą właśnie panele słoneczne. O ile jednak technologia pływających [&#8230;]</p>

## Nadchodzą komputery kwantowe. To zasługa konkretnego rozwiązania
 - [https://www.chip.pl/2022/11/komputery-kwantowe-kubity-nadprzewodnikowe](https://www.chip.pl/2022/11/komputery-kwantowe-kubity-nadprzewodnikowe)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-22 05:00:37+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="866" src="https://konto.chip.pl/wp-content/uploads/2022/09/komputer-kwantowy.jpg" style="margin-bottom: 10px;" width="1300" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/09/komputer-kwantowy.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Komputery kwantowe mają zrewolucjonizować świat nauki, choć te obecnie istniejące trudno określić mianem faktycznie wykorzystywanych maszyn. Być może zmieni się to dzięki nowym dokonaniom rosyjskich naukowców. Z czego najlepiej wykonywać procesory do komputerów kwantowych? Wśród kandydatów wymienia się na przykład elektrony, fotony, jony, nadprzewodniki czy tranzystory kwantowe. Nadprzewodnikowe kubity zyskały do w ostatnich latach sporą [&#8230;]</p>

## Rosja grozi światu arsenałem jądrowym. Państwo pokazało Szatana na szeregu szczegółowych zdjęć
 - [https://www.chip.pl/2022/11/rosja-pocisk-jadrowy-szatan-zdjecia](https://www.chip.pl/2022/11/rosja-pocisk-jadrowy-szatan-zdjecia)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-22 05:00:00+00:00

<img alt="Rosyjski Szatan na zdjęciach" class="attachment-full size-full wp-post-image" height="1076" src="https://konto.chip.pl/wp-content/uploads/2022/11/Rosja-grozi-swiatu-arsenalem-jadrowym.-Panstwo-pokazalo-Szatana-na-szeregu-szczegolowych-zdjec-1.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/Rosja-grozi-swiatu-arsenalem-jadrowym.-Panstwo-pokazalo-Szatana-na-szeregu-szczegolowych-zdjec-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Rosja znów się wygraża. Jak bowiem inaczej można nazwać świadome udostępnienie przez tamtejsze media państwowe zdjęć swojego międzykontynentalnego pocisku balistycznego SS-18 Mod 5 Satan, zwanego też mianem R-36M2? Sam jego widok może robić wrażenie i choć to, co zobaczycie na zdjęciach, ma raczej wydźwięk propagandowy i zapewne ma za zadanie pokazać światu, że Rosja jednak [&#8230;]</p>


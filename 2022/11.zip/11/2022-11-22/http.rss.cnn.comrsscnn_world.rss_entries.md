# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## Shocked Iranian medics leak stories of protesters raped in detention
 - [https://www.cnn.com/interactive/2022/11/middleeast/iran-protests-sexual-assault/](https://www.cnn.com/interactive/2022/11/middleeast/iran-protests-sexual-assault/)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-11-22 19:03:13.681204+00:00



## Colombia's drug problem is worse than ever. But it has a radical solution
 - [https://www.cnn.com/2022/11/22/americas/colombia-coco-decriminalize-intl-latam/index.html](https://www.cnn.com/2022/11/22/americas/colombia-coco-decriminalize-intl-latam/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-11-22 18:45:13+00:00

When Gustavo Petro, Colombia's first progressive president, took office in August, he laid out an ambitious agenda.

## Gunmen abduct more than 100 in Nigeria's Zamfara state
 - [https://www.cnn.com/2022/11/22/africa/gunmen-abduct-hundred-nigeria-intl/index.html](https://www.cnn.com/2022/11/22/africa/gunmen-abduct-hundred-nigeria-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-11-22 14:18:24+00:00

More than 100 people, including women and children, were abducted when gunmen raided four villages in Nigeria's northwestern Zamfara state on Sunday, the information commissioner and residents said on Monday.

## A group of uninhabited Indonesian islands is about to hit the auction block
 - [https://www.cnn.com/travel/article/widi-reserve-islands-indonesia-intl-hnk/index.html](https://www.cnn.com/travel/article/widi-reserve-islands-indonesia-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-11-22 10:46:12+00:00

A group of Indonesian islands known as the Widi Reserve is about to go up for auction in what could be one of the most eye-popping real estate sales to ever take place in Asia.

## Bob Iger moves fast to dismantle Chapek's reorganization of Disney
 - [https://www.cnn.com/2022/11/21/media/bob-iger-bob-chapek-disney-reliable-sources/index.html](https://www.cnn.com/2022/11/21/media/bob-iger-bob-chapek-disney-reliable-sources/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-11-22 03:38:36+00:00

One day after the shock announcement of Bob Iger's return to Disney, and the resulting ouster of his successor-turned-predecessor Bob Chapek, an astonished Hollywood is grappling with what exactly the move will mean for the entertainment behemoth's short-term and long-term future.

## More than 100 migrants rescued from overloaded vessel before it hit sand bar in Florida Keys, Coast Guard says
 - [https://www.cnn.com/2022/11/21/us/migrants-rescued-overloaded-vessel-florida-keys/index.html](https://www.cnn.com/2022/11/21/us/migrants-rescued-overloaded-vessel-florida-keys/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-11-22 03:06:46+00:00

More than 100 people were rescued from an overloaded vessel before it hit a sand bar in the Florida Keys, according to the US Coast Guard.


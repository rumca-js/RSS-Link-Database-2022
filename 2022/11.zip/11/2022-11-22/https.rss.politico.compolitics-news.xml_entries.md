# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en-US

## Trump’s Jan. 6 supporters feted at his Mar-a-Lago campaign launch
 - [https://www.politico.com/news/2022/11/22/trumps-jan-6-supporters-feted-at-his-mar-a-lago-campaign-launch-00070456](https://www.politico.com/news/2022/11/22/trumps-jan-6-supporters-feted-at-his-mar-a-lago-campaign-launch-00070456)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2022-11-22 11:11:00+00:00

Several MAGA personalities and Trump world figures with ties to the Jan. 6 rally were fixtures at the launch of his 2024 campaign at his private Palm Beach club.


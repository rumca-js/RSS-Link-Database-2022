# Source:Forbs - innovation, URL:https://www.forbes.com/innovation/feed2, language:en-US

## How Every Team Can Win The ‘Rocket League’ Championship Series Fall Major - North American Region
 - [https://www.forbes.com/sites/maxthielmeyer/2022/11/22/how-every-team-can-win-the-rocket-league-championship-series-fall-majornorth-american-region/](https://www.forbes.com/sites/maxthielmeyer/2022/11/22/how-every-team-can-win-the-rocket-league-championship-series-fall-majornorth-american-region/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 23:02:30+00:00

Recap, open, cup invitational for each region rotterdam only second lan since xxx each team, points, key wins, notes North America Gen. G Mobil 1 Racing Seed: 1st - 44 points Gen. G have consistently been at the top of the North American region all season long, taking home second place in both th...

## Our Nation's Chronic Disease Epidemic Is Getting Worse So, Who's Responsible?
 - [https://www.forbes.com/sites/ritanumerof/2022/11/22/our-nations-chronic-disease-epidemic-is-getting-worse-so-whos-responsible/](https://www.forbes.com/sites/ritanumerof/2022/11/22/our-nations-chronic-disease-epidemic-is-getting-worse-so-whos-responsible/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 22:51:16+00:00

Clearly, we have a healthcare epidemic on our hands. So, what’s the problem? For those living with chronic conditions, a fractured U.S. healthcare delivery system that prioritizes profits over patient outcomes has left them in the lurch.

## Twitter Alternative Mastodon Has Security Issues
 - [https://www.forbes.com/sites/petersuciu/2022/11/22/twitter-alternative-mastodon-has-security-issues/](https://www.forbes.com/sites/petersuciu/2022/11/22/twitter-alternative-mastodon-has-security-issues/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 22:15:49+00:00

Though the interface is similar to Twitter, it isn't run by a single entity or company.

## HP Cuts More Than 4,000 Jobs—Here Are The Biggest U.S. Layoffs This Year
 - [https://www.forbes.com/sites/brianbushard/2022/11/22/hp-cuts-more-than-4000-jobs-here-are-the-biggest-us-layoffs-this-year/](https://www.forbes.com/sites/brianbushard/2022/11/22/hp-cuts-more-than-4000-jobs-here-are-the-biggest-us-layoffs-this-year/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 21:50:06+00:00

Forbes is tracking the biggest layoffs in the U.S. this year as companies react to fears of a looming recession.

## Antioxidant-Rich Foods—Like Kale, Tea, Broccoli—Could Slow Rate Of Memory Decline, Study Suggests
 - [https://www.forbes.com/sites/tylerroush/2022/11/22/antioxidant-rich-foods-like-kale-tea-broccoli-could-slow-rate-of-memory-decline-study-suggests/](https://www.forbes.com/sites/tylerroush/2022/11/22/antioxidant-rich-foods-like-kale-tea-broccoli-could-slow-rate-of-memory-decline-study-suggests/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 21:00:22+00:00

A group of over 950 people was followed and tested for an average of seven years.

## Developing Countries Need Modern Energy, Not Climate Reparations
 - [https://www.forbes.com/sites/dianafurchtgott-roth/2022/11/22/developing-countries-need-modern-energy-not-climate-reparations/](https://www.forbes.com/sites/dianafurchtgott-roth/2022/11/22/developing-countries-need-modern-energy-not-climate-reparations/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 19:32:12+00:00

It is difficult to draw a causal correlation between damages from specific weather-related disasters in developing countries and Western emissions.

## Hundreds Of Social Media Videos With Billions Of Views Show Wild Animals Being Tortured, Report Finds
 - [https://www.forbes.com/sites/rashishrivastava/2022/11/22/hundreds-of-social-media-videos-with-billions-of-views-show-wild-animals-being-tortured-report-finds/](https://www.forbes.com/sites/rashishrivastava/2022/11/22/hundreds-of-social-media-videos-with-billions-of-views-show-wild-animals-being-tortured-report-finds/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 18:18:50+00:00

Animal cruelty on social media platforms isn’t new, but hundreds of videos on social media platforms like Facebook and YouTube of wild animals being kept as pets in hostile environments have been going viral in the past year, a new report finds.

## 16 Skills And Specialties Tech Leaders Are Looking For In 2023
 - [https://www.forbes.com/sites/forbestechcouncil/2022/11/22/16-skills-and-specialties-tech-leaders-are-looking-for-in-2023/](https://www.forbes.com/sites/forbestechcouncil/2022/11/22/16-skills-and-specialties-tech-leaders-are-looking-for-in-2023/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 18:15:00+00:00

Whether a company is a tech producer or simply a tech user, its team must be fluent in the latest tech developments as well as the hard and soft skills a fast-paced workplace requires.

## Running Power Comes To The Garmin Fenix 7 And Others: How It Works
 - [https://www.forbes.com/sites/andrewwilliams/2022/11/22/running-power-comes-to-the-garmin-fenix-7-and-others-how-it-works/](https://www.forbes.com/sites/andrewwilliams/2022/11/22/running-power-comes-to-the-garmin-fenix-7-and-others-how-it-works/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 18:13:38+00:00

Garmin has added the running power stat to many of its high-end watches in a software update.

## Senators Seek Disaster Declaration After Crab Season Cancelled
 - [https://www.forbes.com/sites/priyashukla/2022/11/22/senators-seek-disaster-declaration-after-crab-season-cancelled/](https://www.forbes.com/sites/priyashukla/2022/11/22/senators-seek-disaster-declaration-after-crab-season-cancelled/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 17:45:00+00:00

With crab season cancelled off the coast of the northwestern United States this year, Senators are asking for disaster relief funds to support the fishing industry.

## Apple Watch Parkinson’s Disease Tracking App Cleared By The FDA
 - [https://www.forbes.com/sites/andrewwilliams/2022/11/22/apple-watch-parkinsons-disease-tracking-app-cleared-by-the-fda/](https://www.forbes.com/sites/andrewwilliams/2022/11/22/apple-watch-parkinsons-disease-tracking-app-cleared-by-the-fda/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 17:40:37+00:00

Parky is an app for Apple Watch that tracks symptoms of Parkinson’s Disease, and it has just been cleared by the FDA according to its developer H2o Therapeutics.

## Trump Creates A Strategy Problem For Twitter
 - [https://www.forbes.com/sites/tedladd/2022/11/22/trump-creates-a-strategy-problem-for-twitter/](https://www.forbes.com/sites/tedladd/2022/11/22/trump-creates-a-strategy-problem-for-twitter/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 17:06:50+00:00

Not all users on a platform are equal. By inviting former President Trump to actively participate in Twitter, CEO Elon Musk has made a consequential strategic decision.

## How Sam Bankman-Fried Sold The Bahamas An Empty Crypto Dream
 - [https://www.forbes.com/sites/sarahemerson/2022/11/22/sam-bankman-fried-ftx-bahamas/](https://www.forbes.com/sites/sarahemerson/2022/11/22/sam-bankman-fried-ftx-bahamas/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 16:47:11+00:00

The FTX founder blew into the island nation with promises of prosperity and philanthropy. After he allegedly oversaw the use of customer deposits to fuel risky crypto trading, Bankman-Fried’s empire collapsed — and Bahamians are reeling from yet another scandal.

## What’s the Forecast For Silicon Valley – And The Cloud?
 - [https://www.forbes.com/sites/rscottraynovich/2022/11/22/whats-the-forecast-for-silicon-valley--and-the-cloud/](https://www.forbes.com/sites/rscottraynovich/2022/11/22/whats-the-forecast-for-silicon-valley--and-the-cloud/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 16:46:35+00:00

Walmart is thought of by many as a low-end retail brand, but it is in fact one of the most digitally sophisticated retailers on the planet.

## A Psychologist Offers Advice On How To Reclaim Yourself After Sexual Trauma
 - [https://www.forbes.com/sites/traversmark/2022/11/22/a-psychologist-offers-advice-on-how-to-reclaim-yourself-after-sexual-trauma/](https://www.forbes.com/sites/traversmark/2022/11/22/a-psychologist-offers-advice-on-how-to-reclaim-yourself-after-sexual-trauma/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 16:36:57+00:00

Experiences of sexual trauma can be devastating but there is hope. Here is how you can start the journey of recovery.

## Moon’s Far Side Marks Astronomy’s Final Frontier, Says Big Bang Cosmologist
 - [https://www.forbes.com/sites/brucedorminey/2022/11/22/moons-far-side-marks-astronomys-final-frontier-says-big-bang-cosmologist/](https://www.forbes.com/sites/brucedorminey/2022/11/22/moons-far-side-marks-astronomys-final-frontier-says-big-bang-cosmologist/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 16:08:50+00:00

Cosmologist Joseph Silk argues in new book that astronomy from the lunar far side is humanity’s best hope for making sense of the early universe.

## Google Pixel Watch Review: Tied With Samsung’s Galaxy Watch 5 As The Best Android Smartwatch
 - [https://www.forbes.com/sites/bensin/2022/11/22/google-pixel-watch-review-tied-with-samsungs-galaxy-watch-5-as-the-best-android-smartwatch/](https://www.forbes.com/sites/bensin/2022/11/22/google-pixel-watch-review-tied-with-samsungs-galaxy-watch-5-as-the-best-android-smartwatch/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 15:35:05+00:00

The Google Pixel Watch is a long-awaited wearable and it mostly lives up to the hype.

## How Will EVs Handle The Thanksgiving Crunch?
 - [https://www.forbes.com/sites/bradtempleton/2022/11/22/how-will-evs-handle-the-thanksgiving-crunch/](https://www.forbes.com/sites/bradtempleton/2022/11/22/how-will-evs-handle-the-thanksgiving-crunch/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 15:13:27+00:00

In the USA, the upcoming Thanksgiving weekend will see a post-covid new surge of long distance travel on Wednesday and Sunday afternoons.  EVs had some hiccups in 2019, so what might happen in 2022?

## How To Make Data Privacy Changes Work For Your Digital Marketing Strategy
 - [https://www.forbes.com/sites/garydrenik/2022/11/22/how-to-make-data-privacy-changes-work-for-your-digital-marketing-strategy/](https://www.forbes.com/sites/garydrenik/2022/11/22/how-to-make-data-privacy-changes-work-for-your-digital-marketing-strategy/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 15:00:00+00:00

The death of the internet cookie has been a long-talked-about inevitability. The move, which will upend how ads are targeted on websites, has many debating about the future of digital advertising. Savvy marketers, however, are shifting their focus to first-party data and zero-party data.

## The Case For Apple Releasing An MR/AR Headset In 2023
 - [https://www.forbes.com/sites/timbajarin/2022/11/22/the-case-for-apple-releasing-an-mrar-headset-in-2023/](https://www.forbes.com/sites/timbajarin/2022/11/22/the-case-for-apple-releasing-an-mrar-headset-in-2023/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 15:00:00+00:00

There has been a lot of industry buzz recently suggesting Apple will bring out its first MR/AR headset in 2023.

## Will Congress Restore The Tax Incentive For Research Spending?
 - [https://www.forbes.com/sites/lynnmucenskikeck/2022/11/22/will-the-new-congress-continue-to-stifle-domestic-rd-investment/](https://www.forbes.com/sites/lynnmucenskikeck/2022/11/22/will-the-new-congress-continue-to-stifle-domestic-rd-investment/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 15:00:00+00:00

Businesses making investments in research are baffled that the current federal tax law severely limits tax incentives for innovation.  Concerns loom over whether Congress will be able to compromise before the negative economic impact sets in.

## Fortnite’s Chapter 3 Fracture Finale Event Revealed, May Be 40 Minutes
 - [https://www.forbes.com/sites/paultassi/2022/11/22/fortnites-chapter-3-fracture-finale-event-revealed-may-be-40-minutes/](https://www.forbes.com/sites/paultassi/2022/11/22/fortnites-chapter-3-fracture-finale-event-revealed-may-be-40-minutes/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 14:39:33+00:00

Fortnite has begun to official tease its Chapter 3 finale event, Fracture, including a preview of apparently what is going to happen in new artwork, seen above The Fracture event appears like it will, unsurprisingly, destroy t...

## How Artificial Intelligence Is Helping Improve Medical Processes
 - [https://www.forbes.com/sites/forbestechcouncil/2022/11/22/how-artificial-intelligence-is-helping-improve-medical-processes/](https://www.forbes.com/sites/forbestechcouncil/2022/11/22/how-artificial-intelligence-is-helping-improve-medical-processes/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 14:30:00+00:00

Every health center should consider the use of AI for the benefit of its processes so it can adapt to the modern world and its accelerated pace.

## Twitter Alternative ‘Hive Social’ Is Having A Viral Sign-Up Moment
 - [https://www.forbes.com/sites/paultassi/2022/11/22/twitter-alternative-hive-social-is-having-a-viral-sign-up-moment/](https://www.forbes.com/sites/paultassi/2022/11/22/twitter-alternative-hive-social-is-having-a-viral-sign-up-moment/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 14:24:51+00:00

What is Hive Social, the new Twitter replacement app?

## Upskilling Employees Today For A Successful Tomorrow
 - [https://www.forbes.com/sites/forbestechcouncil/2022/11/22/upskilling-employees-today-for-a-successful-tomorrow/](https://www.forbes.com/sites/forbestechcouncil/2022/11/22/upskilling-employees-today-for-a-successful-tomorrow/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 14:15:00+00:00

Upskilling the workforce has become essential in the wake of the pandemic, and it seems beneficial for employers and employees alike.

## Destiny 2’s Refugee Crisis Comes Full Circle In Today’s Community Event
 - [https://www.forbes.com/sites/paultassi/2022/11/22/destiny-2s-refugee-crisis-comes-full-circle-in-todays-community-event/](https://www.forbes.com/sites/paultassi/2022/11/22/destiny-2s-refugee-crisis-comes-full-circle-in-todays-community-event/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 14:14:04+00:00

At reset today Destiny 2 is having players farm a bunch of currencies and donate ones they have to help rebuild the Eliksni Quarter, which his where we’ve taken in a bunch of Fallen refugees, members of House Light, led by Mithrax and his daughter, Eido.

## Tech Watchdog Demands U.K. Antitrust Investigation Of Amazon’s iRobot Buyout
 - [https://www.forbes.com/sites/richardnieva/2022/11/22/amazon-irobot-roomba-foxglove-antitrust/](https://www.forbes.com/sites/richardnieva/2022/11/22/amazon-irobot-roomba-foxglove-antitrust/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 14:00:00+00:00

The $1.7 billion acquisition will give Amazon an unfair edge in the smart home industry, the nonprofit Foxglove said.

## Why The Winners In Technology Industries Are The Ones ‘Making Hard Things Easy’
 - [https://www.forbes.com/sites/forbestechcouncil/2022/11/22/why-the-winners-in-technology-industries-are-the-ones-making-hard-things-easy/](https://www.forbes.com/sites/forbestechcouncil/2022/11/22/why-the-winners-in-technology-industries-are-the-ones-making-hard-things-easy/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 14:00:00+00:00

The winners of the future will be those who make hard things possible and easy—particularly when it comes to technology.

## Russia Is Betting On Trench Warfare — But Ukrainian Drones Change The Odds
 - [https://www.forbes.com/sites/davidhambling/2022/11/22/russia-is-betting-on-trench-warfare---but-ukrainian-drones-change-the-odds/](https://www.forbes.com/sites/davidhambling/2022/11/22/russia-is-betting-on-trench-warfare---but-ukrainian-drones-change-the-odds/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 13:49:14+00:00

Russia is building an extensive network of static defenses to stop further Ukrainian advances. But trench warfare, so effective in WW1, is no match for precision drone bombing.

## Winter Soldier Revealed In ‘Marvel’s Avengers’ And Oh God What’s Wrong With Him
 - [https://www.forbes.com/sites/paultassi/2022/11/22/winter-soldier-revealed-in-marvels-avengers-and-oh-god-whats-wrong-with-him/](https://www.forbes.com/sites/paultassi/2022/11/22/winter-soldier-revealed-in-marvels-avengers-and-oh-god-whats-wrong-with-him/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 13:46:37+00:00

Winter Soldier is heading to Marvel's Avengers but he just looks...wrong

## Health Care And Trusted Access Management: Rethinking Process And Implementation
 - [https://www.forbes.com/sites/forbestechcouncil/2022/11/22/health-care-and-trusted-access-management-rethinking-process-and-implementation/](https://www.forbes.com/sites/forbestechcouncil/2022/11/22/health-care-and-trusted-access-management-rethinking-process-and-implementation/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 13:45:00+00:00

Health care providers, support staff and patients should feel safe when dealing with already stressful health issues.

## Are Magic: The Gathering The Brothers’ War Collector Boosters Worth The Money?
 - [https://www.forbes.com/sites/curtissilver/2022/11/22/are-magic-the-gathering-the-brothers-war-collector-boosters-worth-the-money/](https://www.forbes.com/sites/curtissilver/2022/11/22/are-magic-the-gathering-the-brothers-war-collector-boosters-worth-the-money/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 13:38:40+00:00

Magic: The Gathering Brothers' War expansion has been on store shelves for a bit over a week now. Are the Collector Boosters worth the money?

## How Going Digital Can Help Campuses Reduce Food Waste
 - [https://www.forbes.com/sites/forbestechcouncil/2022/11/22/how-going-digital-can-help-campuses-reduce-food-waste/](https://www.forbes.com/sites/forbestechcouncil/2022/11/22/how-going-digital-can-help-campuses-reduce-food-waste/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 13:30:00+00:00

From smaller cafeterias on campus to the large dining halls of dormitories, the amount of food wasted is a key cause of concern. A simple technology intervention can make a big difference in reducing food wastage and mitigating the environmental impact caused due to food waste.

## Redpanda Launches Cloud-Based Streaming Platform
 - [https://www.forbes.com/sites/waynerash/2022/11/22/redpanda-launches-cloud-based-streaming-platform/](https://www.forbes.com/sites/waynerash/2022/11/22/redpanda-launches-cloud-based-streaming-platform/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 13:30:00+00:00

As data streaming has become a critical part of business operations, makers of data streaming management and analysis software have had to up their performance game as well.

## Retailers: Quip Customers With Tools For A Positive Online Shopping Experience
 - [https://www.forbes.com/sites/forrester/2022/11/22/site-features-that-make-shopping-easy-this-holiday-season/](https://www.forbes.com/sites/forrester/2022/11/22/site-features-that-make-shopping-easy-this-holiday-season/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 13:30:00+00:00

One in five US consumers plan to avoid in-store shopping this holiday season.

## 14 Smart Ways To ‘Trim The Fat’ From Your Business’ Tech Budget
 - [https://www.forbes.com/sites/forbestechcouncil/2022/11/22/14-smart-ways-to-trim-the-fat-from-your-business-tech-budget/](https://www.forbes.com/sites/forbestechcouncil/2022/11/22/14-smart-ways-to-trim-the-fat-from-your-business-tech-budget/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 13:15:00+00:00

Looking for areas where they’re overspending is especially challenging for tech leaders, who must trim costs while continuing to fund new initiatives and essential internal tech functions.

## Rising Up In A Downturn: The Role Of Innovation Amid Market Uncertainty
 - [https://www.forbes.com/sites/forbestechcouncil/2022/11/22/rising-up-in-a-downturn-the-role-of-innovation-amid-market-uncertainty/](https://www.forbes.com/sites/forbestechcouncil/2022/11/22/rising-up-in-a-downturn-the-role-of-innovation-amid-market-uncertainty/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 13:15:00+00:00

Given today’s current events, it is important that entrepreneurs understand how today’s economic climate can be transformed into tomorrow’s surge of innovation.

## Why Sony Is Never Going To Take Any ‘Call Of Duty’ Deal Xbox Offers
 - [https://www.forbes.com/sites/paultassi/2022/11/22/why-sony-is-never-going-to-take-any-call-of-duty-deal-xbox-offers/](https://www.forbes.com/sites/paultassi/2022/11/22/why-sony-is-never-going-to-take-any-call-of-duty-deal-xbox-offers/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 13:11:51+00:00

A short while after Microsoft said they were open to a longer term contract with Sony to ensure, in writing, that Call of Duty would continue appearing on the platform for a long time, we now know exactly just how long Microsoft ...

## Revisiting The U.S. Cyberspace Solarium Commission Report
 - [https://www.forbes.com/sites/forbestechcouncil/2022/11/22/revisiting-the-us-cyberspace-solarium-commission-report/](https://www.forbes.com/sites/forbestechcouncil/2022/11/22/revisiting-the-us-cyberspace-solarium-commission-report/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 13:00:00+00:00

Our world changes quickly, but the goals and recommendations of the Cyberspace Solarium Commission were drafted with an eye on the future of cybersecurity.

## Sustainability In Midsize Companies: Finding The Way To Competitive Supply Chains
 - [https://www.forbes.com/sites/sap/2022/11/22/sustainability-in-midsize-companies-finding-the-way-to-competitive-supply-chains/](https://www.forbes.com/sites/sap/2022/11/22/sustainability-in-midsize-companies-finding-the-way-to-competitive-supply-chains/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 12:48:06+00:00

Midsize companies with supply chains that quickly incorporate sustainability and the circular economy into their plans for growing revenue, increasing efficiency, and mitigating risk are well-positioned to differentiate themselves and gain a competitive advantage."

## How Does Healthcare Cybersecurity Compare To Other Industries?
 - [https://www.forbes.com/sites/forbestechcouncil/2022/11/22/how-does-healthcare-cybersecurity-compare-to-other-industries/](https://www.forbes.com/sites/forbestechcouncil/2022/11/22/how-does-healthcare-cybersecurity-compare-to-other-industries/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 12:45:00+00:00

As rapidly as technology is changing, attackers are strategizing and changing just as quickly. To even begin future-proofing the delivery of care, a robust strategy rooted in business value and tied to people, processes and technology is critical.

## A (Software) Bug’s Life
 - [https://www.forbes.com/sites/adrianbridgwater/2022/11/22/a-software-bugs-life/](https://www.forbes.com/sites/adrianbridgwater/2022/11/22/a-software-bugs-life/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 12:35:22+00:00

Software has bugs. Like any major piece of engineering, any building or construction and any architected thing, the likelihood and presence of flaws and snags is almost inevitable.

## Five Accelerators To Keep In Mind For A Successful Enterprise Data Platform Strategy
 - [https://www.forbes.com/sites/forbestechcouncil/2022/11/22/five-accelerators-to-keep-in-mind-for-a-successful-enterprise-data-platform-strategy/](https://www.forbes.com/sites/forbestechcouncil/2022/11/22/five-accelerators-to-keep-in-mind-for-a-successful-enterprise-data-platform-strategy/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 12:30:00+00:00

Here are five accelerators to keep in mind for a successful enterprise data platform strategy.

## Why Technical Maturity Is Critical In 2023
 - [https://www.forbes.com/sites/forbestechcouncil/2022/11/22/why-technical-maturity-is-critical-in-2023/](https://www.forbes.com/sites/forbestechcouncil/2022/11/22/why-technical-maturity-is-critical-in-2023/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 12:15:00+00:00

No matter where you are in your technical maturity, you invested in technology in the past that now likely needs maturing.

## Checking In—The Hotel Industry Embraces Higher-Tech Hospitality
 - [https://www.forbes.com/sites/forbestechcouncil/2022/11/22/checking-in-the-hotel-industry-embraces-higher-tech-hospitality/](https://www.forbes.com/sites/forbestechcouncil/2022/11/22/checking-in-the-hotel-industry-embraces-higher-tech-hospitality/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 12:00:00+00:00

But while the appeal of travel endures, hoteliers must invest in smart capabilities and devices to meet new customer expectations, but also reduce expenses, reduce environmental impact and lighten staffing requirements.

## Who Is Watching Your Data?
 - [https://www.forbes.com/sites/forbestechcouncil/2022/11/22/who-is-watching-your-data/](https://www.forbes.com/sites/forbestechcouncil/2022/11/22/who-is-watching-your-data/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 11:45:00+00:00

Data observability is an emerging concept and is often mentioned in the same breath as data quality. Both are key to healthy, trusted data—but they are not the same.

## How Development Teams Can Approach A Security Reset Amid Deglobalization
 - [https://www.forbes.com/sites/forbestechcouncil/2022/11/22/how-development-teams-can-approach-a-security-reset-amid-deglobalization/](https://www.forbes.com/sites/forbestechcouncil/2022/11/22/how-development-teams-can-approach-a-security-reset-amid-deglobalization/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 11:30:00+00:00

Deglobalization warrants a hard look by development organizations, particularly when it comes to questions like insider threats and supply chain risks.

## With A New CEO, An Adult Has Arrived To Clean Up The FTX Mess
 - [https://www.forbes.com/sites/amyfeldman/2022/11/22/with-a-new-ceo-an-adult-has-arrived-to-clean-up-the-ftx-mess/](https://www.forbes.com/sites/amyfeldman/2022/11/22/with-a-new-ceo-an-adult-has-arrived-to-clean-up-the-ftx-mess/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 11:30:00+00:00

John J. Ray III, a veteran of Enron, Fruit of the Loom and other bankruptcies, now must pick up the shattered pieces from Sam Bankman-Fried’s chaotic reign.

## How Virtual Power Plants Have Gone From Geek To Must-Have Chic
 - [https://www.forbes.com/sites/jamiehailstone/2022/11/22/how-virtual-power-plants-have-gone-from-geek-to-must-have-chic/](https://www.forbes.com/sites/jamiehailstone/2022/11/22/how-virtual-power-plants-have-gone-from-geek-to-must-have-chic/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 11:20:52+00:00

One of the companies at the forefront of this revolution is Swell Energy, which has just announced it has raised $120 million to further its virtual power plant programs.

## Why Capitalism Today And The Internet Have Not Improved The Human Condition
 - [https://www.forbes.com/sites/forbestechcouncil/2022/11/22/why-capitalism-today-and-the-internet-have-not-improved-the-human-condition/](https://www.forbes.com/sites/forbestechcouncil/2022/11/22/why-capitalism-today-and-the-internet-have-not-improved-the-human-condition/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 11:15:00+00:00

Acting impulsively isn’t a wise strategy for a social media platform takeover, so it certainly isn’t a viable approach in sectors like DeepTech, AI, biotech, fintech and healthcare.

## Understanding Mobile Field Service Management
 - [https://www.forbes.com/sites/forbestechcouncil/2022/11/22/understanding-mobile-field-service-management/](https://www.forbes.com/sites/forbestechcouncil/2022/11/22/understanding-mobile-field-service-management/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 11:00:00+00:00

The smartphone has changed the way field services are being delivered and managed, creating an opportunity for small and mid-sized service companies to expand their footprint and revenues.

## Meta Sued Over Data Retention For 'Forced' Personal Ads
 - [https://www.forbes.com/sites/emmawoollacott/2022/11/22/meta-sued-over-data-retention-for-forced-personal-ads/](https://www.forbes.com/sites/emmawoollacott/2022/11/22/meta-sued-over-data-retention-for-forced-personal-ads/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 10:57:13+00:00

A human rights campaigner is suing Meta in the UK's high court in a case that could have serious implications for other social media sites and search engines.

## Leading From Home - How To Navigate Digital Culture Challenges
 - [https://www.forbes.com/sites/mikehughes1/2022/11/22/leading-from-homehow-to-navigate-digital-culture-challenges/](https://www.forbes.com/sites/mikehughes1/2022/11/22/leading-from-homehow-to-navigate-digital-culture-challenges/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 10:51:36+00:00

It is often said that a company’s biggest problem exists between the chair and the keyboard. Leaders must communicate and collaborate to shift traditional mindsets, spark innovation and retain talent. After all, digital transformation is only possible with a cultural shift.

## Victrola’s Two New Wireless Speakers Are Solid And Stylish Performers
 - [https://www.forbes.com/sites/marksparrow/2022/11/22/victrolas-two-new-wireless-speakers-are-solid-and-stylish-performers/](https://www.forbes.com/sites/marksparrow/2022/11/22/victrolas-two-new-wireless-speakers-are-solid-and-stylish-performers/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 10:07:03+00:00

Victrola may conjure up images of old-school gramophone players, but there's nothing old-fashioned about these two new Bluetooth speakers which are out just in time for the Christmas period.

## Can You Transplant A Brain Into A Young New Body? And Would You?
 - [https://www.forbes.com/sites/alexzhavoronkov/2022/11/22/can-you-transplant-a-brain-into-a-young-new-body-and-would-you/](https://www.forbes.com/sites/alexzhavoronkov/2022/11/22/can-you-transplant-a-brain-into-a-young-new-body-and-would-you/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 09:07:52+00:00

Imagine that you can grow a clone with the level of intelligence below the level of a turkey or a chicken with the perfectly-exercised body. Would you consider swapping your brain with this perfect and unconscious clone? 
Surprisingly, many professionals would not even think twice.

## Innovation Showdown: Crypto And Meta Vs. Industry 4.0
 - [https://www.forbes.com/sites/marcoannunziata/2022/11/22/innovation-showdown-crypto-and-meta-vs-industry-40/](https://www.forbes.com/sites/marcoannunziata/2022/11/22/innovation-showdown-crypto-and-meta-vs-industry-40/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 08:59:36+00:00

As crypto and digital tech giants face reality, digital-industrial innovation has a chance to prove its mettle and boost economic growth, just when its contribution is most needed.

## Serious Antibiotic Resistant Infections Inching Up In England
 - [https://www.forbes.com/sites/katherinehignett/2022/11/22/antibiotic-resistant-infections-inching-up-in-england/](https://www.forbes.com/sites/katherinehignett/2022/11/22/antibiotic-resistant-infections-inching-up-in-england/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 08:44:10+00:00

Health officials have warned the number of severe antibiotic resisitant infections is on the rise, following a fall over the pandemic.

## NDAA Section 889: Can Lawmakers Withstand Semiconductor Lobby Onslaught Against National Security?
 - [https://www.forbes.com/sites/roslynlayton/2022/11/22/ndaa-section-889-can-lawmakers-withstand-semiconductor-lobby-onslaught-against-national-security/](https://www.forbes.com/sites/roslynlayton/2022/11/22/ndaa-section-889-can-lawmakers-withstand-semiconductor-lobby-onslaught-against-national-security/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 07:51:34+00:00

The bill is a no-brainer to protect Americans and fulfill the rule of law, but putting people above profits sometimes conflicts with corporate preferences.

## New ‘Died Suddenly’ Film Pushes Unfounded Depopulation Claims About Covid-19 Vaccine
 - [https://www.forbes.com/sites/brucelee/2022/11/22/new-died-suddenly-film-pushes-unfounded-depopulation-claims-about-covid-19-vaccine/](https://www.forbes.com/sites/brucelee/2022/11/22/new-died-suddenly-film-pushes-unfounded-depopulation-claims-about-covid-19-vaccine/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 06:42:26+00:00

The film, which premiered on Twitter Monday, spends much of its hour and eight minute run time suggesting that many people have been dying suddenly after getting Covid-19 vaccines.

## Researchers Devise Method For Enhancing The Lifespan Of E-Scooters
 - [https://www.forbes.com/sites/jonathankeane/2022/11/22/researchers-devise-method-for-enhancing-the-lifespan-of-e-scooters/](https://www.forbes.com/sites/jonathankeane/2022/11/22/researchers-devise-method-for-enhancing-the-lifespan-of-e-scooters/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 06:00:00+00:00

A new report has called on e-scooter companies to be more open and transparent about the lifespan and durability of their vehicles.

## Today’s ‘Quordle’ Answers And Clues For Tuesday, November 22
 - [https://www.forbes.com/sites/krisholt/2022/11/22/todays-quordle-answers-and-clues-for-tuesday-november-22/](https://www.forbes.com/sites/krisholt/2022/11/22/todays-quordle-answers-and-clues-for-tuesday-november-22/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 05:29:30+00:00

Some hints and the solution for today's 'Quordle' are just ahead.

## Today’s ‘Heardle’ Answer And Clues For Tuesday, November 22
 - [https://www.forbes.com/sites/krisholt/2022/11/22/todays-heardle-answer-and-clues-for-tuesday-november-22/](https://www.forbes.com/sites/krisholt/2022/11/22/todays-heardle-answer-and-clues-for-tuesday-november-22/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 05:18:03+00:00

Here's today's 'Heardle' song, along with some hints.

## U.S. Commerce Secretary To Attend Ceremony At TSMC’s New $12 Billion Chip Plant In Arizona On Dec. 6; Biden Invited
 - [https://www.forbes.com/sites/russellflannery/2022/11/22/us-commerce-secretary-to-attend-ceremony-at-tsmcs-new-12-billion-chip-plant-in-arizona-on-dec-6-biden-invited/](https://www.forbes.com/sites/russellflannery/2022/11/22/us-commerce-secretary-to-attend-ceremony-at-tsmcs-new-12-billion-chip-plant-in-arizona-on-dec-6-biden-invited/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 05:09:31+00:00

Investment is part of U.S. push to increase domestic chip production

## Today’s Wordle #521 Hints, Clues And Answer For Tuesday, November 22nd
 - [https://www.forbes.com/sites/erikkain/2022/11/21/todays-wordle-521-hints-clues-and-answer-for-tuesday-november-22nd/](https://www.forbes.com/sites/erikkain/2022/11/21/todays-wordle-521-hints-clues-and-answer-for-tuesday-november-22nd/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 03:37:14+00:00

How to solve today's Wordle.

## A ‘Secret’ Spectacular Solar Eclipse Is Coming Soon And You Need To Make Plans Now
 - [https://www.forbes.com/sites/jamiecartereurope/2022/11/21/a-weird-kind-of-eclipse-is-coming-to-planet-earth-next-year-and-you-need-to-make-plans-now/](https://www.forbes.com/sites/jamiecartereurope/2022/11/21/a-weird-kind-of-eclipse-is-coming-to-planet-earth-next-year-and-you-need-to-make-plans-now/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-22 01:00:00+00:00

What is a hybrid solar eclipse? This rare event happens only a handful of times each century and is a jaw-dropping sight.


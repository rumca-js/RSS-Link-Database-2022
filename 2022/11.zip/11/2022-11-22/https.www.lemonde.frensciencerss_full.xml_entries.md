# Source:Le Monde - science, URL:https://www.lemonde.fr/en/science/rss_full.xml, language:en-US

## 'France's failure to innovate has significantly contributed to its loss of competitiveness'
 - [https://www.lemonde.fr/en/opinion/article/2022/11/22/france-s-failure-to-innovate-has-significantly-contributed-to-its-loss-of-competitiveness_6005138_23.html](https://www.lemonde.fr/en/opinion/article/2022/11/22/france-s-failure-to-innovate-has-significantly-contributed-to-its-loss-of-competitiveness_6005138_23.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2022-11-22 06:00:13+00:00

In an op-ed, economists Philippe Aghion and Céline Antonin advocate a strong increase in funding and compensation for French research.

## European Space Program: 'The universal presence of space in our daily lives makes it a tool of sovereignty and a powerful lever for growth'
 - [https://www.lemonde.fr/en/opinion/article/2022/11/22/european-space-program-the-universal-presence-of-space-in-our-daily-lives-makes-it-a-tool-of-sovereignty-and-a-powerful-lever-for-growth_6005130_23.html](https://www.lemonde.fr/en/opinion/article/2022/11/22/european-space-program-the-universal-presence-of-space-in-our-daily-lives-makes-it-a-tool-of-sovereignty-and-a-powerful-lever-for-growth_6005130_23.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2022-11-22 04:05:20+00:00

Philippe Baptiste, President and CEO of the French National Centre for Space Studies, discusses the economic, scientific, military and environmental considerations for the European Space Agency (ESA), whose budget will be discussed on November 22 and 23.


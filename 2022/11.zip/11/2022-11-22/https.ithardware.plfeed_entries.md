# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Wystartował Steam Autumn Sale 2022. Oto ciekawe promocje Jesiennej Wyprzedaży
 - [https://ithardware.pl/aktualnosci/wystartowal_steam_autumn_sale_2022_oto_ciekawe_promocje_jesiennej_wyprzedazy-24487.html](https://ithardware.pl/aktualnosci/wystartowal_steam_autumn_sale_2022_oto_ciekawe_promocje_jesiennej_wyprzedazy-24487.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 22:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/24487_1.jpg" />            Steam wystartował z jesienną wyprzedażą, w ramach kt&oacute;rej przeceniono sporo gier. Nietrudno jednak nie odnieść wrażenia, że Valve od lat nie potrafi przygotować konkretnych promocji, jak jest tym razem?

Jesienna wyprzedaż 2022 ruszyła...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wystartowal_steam_autumn_sale_2022_oto_ciekawe_promocje_jesiennej_wyprzedazy-24487.html">https://ithardware.pl/aktualnosci/wystartowal_steam_autumn_sale_2022_oto_ciekawe_promocje_jesiennej_wyprzedazy-24487.html</a></p>

## Sony walczy z grami shovelware. Z PlayStation Store zniknąć mają farmy platyn
 - [https://ithardware.pl/aktualnosci/sony_walczy_z_grami_shovelware_z_playstation_store_zniknac_maja_farmy_platyn-24486.html](https://ithardware.pl/aktualnosci/sony_walczy_z_grami_shovelware_z_playstation_store_zniknac_maja_farmy_platyn-24486.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 21:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/24486_1.jpg" />            Sony walczy&nbsp;z grami, kt&oacute;re kopiują rzeczy z innych produkcji i używają ich w swoich projektach, w efekcie są one do siebie bliźniaczo podobne.

Jak wynika z listu wysłanego do deweloper&oacute;w gier, Sony będzie usuwać z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/sony_walczy_z_grami_shovelware_z_playstation_store_zniknac_maja_farmy_platyn-24486.html">https://ithardware.pl/aktualnosci/sony_walczy_z_grami_shovelware_z_playstation_store_zniknac_maja_farmy_platyn-24486.html</a></p>

## Oto najpopularniejsze hasła w 2022 roku
 - [https://ithardware.pl/aktualnosci/oto_najpopularniejsze_hasla_w_2022_roku-24485.html](https://ithardware.pl/aktualnosci/oto_najpopularniejsze_hasla_w_2022_roku-24485.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 20:19:18+00:00

<img src="https://ithardware.pl/artykuly/min/24485_1.jpg" />            Poznaliśmy najpopularniejsze hasła w 2022 roku. Na podium nadal są doskonale znane hasła, kt&oacute;re nie podnoszą poziomu bezpieczeństwa.

Firma NordPass przedstawiła listę najpopularniejszych haseł 2022 roku. Pierwsze miejsce zajęło...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/oto_najpopularniejsze_hasla_w_2022_roku-24485.html">https://ithardware.pl/aktualnosci/oto_najpopularniejsze_hasla_w_2022_roku-24485.html</a></p>

## AMD oficjalnie obniża ceny procesorów Ryzen 5000 i Ryzen 7000
 - [https://ithardware.pl/aktualnosci/amd_oficjalnie_obniza_ceny_procesorow_ryzen_5000_i_ryzen_7000-24484.html](https://ithardware.pl/aktualnosci/amd_oficjalnie_obniza_ceny_procesorow_ryzen_5000_i_ryzen_7000-24484.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 15:10:10+00:00

<img src="https://ithardware.pl/artykuly/min/24484_1.jpg" />            Czekaliście na jeszcze większe obniżki cenowe sprzętu od AMD? Z okazji Black Friday gigant z Santa Clara postanowił obniżyć ceny niemal wszystkich swoich produkt&oacute;w sygnowanych marką Ryzen. Obniżki sięgają nawet kilkudziesięciu...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_oficjalnie_obniza_ceny_procesorow_ryzen_5000_i_ryzen_7000-24484.html">https://ithardware.pl/aktualnosci/amd_oficjalnie_obniza_ceny_procesorow_ryzen_5000_i_ryzen_7000-24484.html</a></p>

## Wiemy, kiedy Intel może wprowadzić procesory 13. generacji z zablokowanym mnożnikiem i chipset B760
 - [https://ithardware.pl/aktualnosci/wiemy_kiedy_intel_moze_wprowadzic_procesory_13_generacji_z_zablokowanym_mnoznikiem_i_chipset_b760-24482.html](https://ithardware.pl/aktualnosci/wiemy_kiedy_intel_moze_wprowadzic_procesory_13_generacji_z_zablokowanym_mnoznikiem_i_chipset_b760-24482.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 14:40:20+00:00

<img src="https://ithardware.pl/artykuly/min/24482_1.jpg" />            Nowe doniesienia sugerują, że Intel wprowadzi swoje&nbsp;procesory 13. generacji z zablokowanym mnożnikiem podczas targ&oacute;w CES 2023, a dokładniej 3 stycznia. Łączenie mamy zobaczyć 16 modeli, kt&oacute;re będą cechować się niższym TDP...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wiemy_kiedy_intel_moze_wprowadzic_procesory_13_generacji_z_zablokowanym_mnoznikiem_i_chipset_b760-24482.html">https://ithardware.pl/aktualnosci/wiemy_kiedy_intel_moze_wprowadzic_procesory_13_generacji_z_zablokowanym_mnoznikiem_i_chipset_b760-24482.html</a></p>

## Francja wyrzuca Office 365 i Google Workspace ze szkół
 - [https://ithardware.pl/aktualnosci/francja_nie_zgadza_sie_na_office_365_i_google_workspace_w_szkolach-24483.html](https://ithardware.pl/aktualnosci/francja_nie_zgadza_sie_na_office_365_i_google_workspace_w_szkolach-24483.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 14:04:30+00:00

<img src="https://ithardware.pl/artykuly/min/24483_1.jpg" />            Francuski minister edukacji narodowej poinformował, że bezpłatne wersje Microsoft Office 365 i Google Workplace nie powinny być używane w szkołach, a wszelkie dotychczasowe postępowania plac&oacute;wek zostaną zrewidowane. Działanie te...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/francja_nie_zgadza_sie_na_office_365_i_google_workspace_w_szkolach-24483.html">https://ithardware.pl/aktualnosci/francja_nie_zgadza_sie_na_office_365_i_google_workspace_w_szkolach-24483.html</a></p>

## Samsung zmaga się z niskim uzyskiem procesu 3 nm GAA. Pomóc może amerykańska firma
 - [https://ithardware.pl/aktualnosci/samsung_zmaga_sie_z_niskim_uzyskiem_procesu_3_nm_gaa_pomoc_moze_amerykanska_firma-24480.html](https://ithardware.pl/aktualnosci/samsung_zmaga_sie_z_niskim_uzyskiem_procesu_3_nm_gaa_pomoc_moze_amerykanska_firma-24480.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 13:43:10+00:00

<img src="https://ithardware.pl/artykuly/min/24480_1.jpg" />            Mimo opracowania przez Samsunga technologii 3 nm GAA, firma nie jest jeszcze w pełni gotowa do masowej produkcji. Powodem jest bardzo niski uzysk, kt&oacute;ry wynosi zaledwie 20%. Koreańczycy planują uporać się z tym problemem przy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/samsung_zmaga_sie_z_niskim_uzyskiem_procesu_3_nm_gaa_pomoc_moze_amerykanska_firma-24480.html">https://ithardware.pl/aktualnosci/samsung_zmaga_sie_z_niskim_uzyskiem_procesu_3_nm_gaa_pomoc_moze_amerykanska_firma-24480.html</a></p>

## LG Display prezentuje grające panele, które mają zrewolucjonizować audio w samochodach
 - [https://ithardware.pl/aktualnosci/lg_display_prezentuje_grajace_panele_ktore_maja_zrewolucjonizowac_audio_w_samochodach-24476.html](https://ithardware.pl/aktualnosci/lg_display_prezentuje_grajace_panele_ktore_maja_zrewolucjonizowac_audio_w_samochodach-24476.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 13:10:01+00:00

<img src="https://ithardware.pl/artykuly/min/24476_1.jpg" />            LG Display niedawno pochwaliło się elastycznymi, rozciągliwymi wyświetlaczami LCD, ale koreański gigant nie zamierza na tym poprzestawać i właśnie zaprezentował kolejne innowacyjne rozwiązanie, a mianowicie supercienki panel robiący za...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/lg_display_prezentuje_grajace_panele_ktore_maja_zrewolucjonizowac_audio_w_samochodach-24476.html">https://ithardware.pl/aktualnosci/lg_display_prezentuje_grajace_panele_ktore_maja_zrewolucjonizowac_audio_w_samochodach-24476.html</a></p>

## Płyta główna MSI B660M Mortar MAX WIFI pozwala podkręcić Core i5-13600K do 5,8 GHz
 - [https://ithardware.pl/aktualnosci/plyta_glowna_msi_b660m_mortar_max_wifi_pozwala_podkrecic_core_i5_13600k_do_5_8_ghz-24475.html](https://ithardware.pl/aktualnosci/plyta_glowna_msi_b660m_mortar_max_wifi_pozwala_podkrecic_core_i5_13600k_do_5_8_ghz-24475.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 12:45:01+00:00

<img src="https://ithardware.pl/artykuly/min/24475_1.png" />            Procesory Intel Core 13. generacji (Raptor Lake) spotkały się z ciepłym przyjęciem, ale podobnie jak w poprzedniej generacji, płyty gł&oacute;wne Z790 są jedyną platformą oficjalnie obsługującą możliwości podkręcania CPU. MSI przygotowało...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/plyta_glowna_msi_b660m_mortar_max_wifi_pozwala_podkrecic_core_i5_13600k_do_5_8_ghz-24475.html">https://ithardware.pl/aktualnosci/plyta_glowna_msi_b660m_mortar_max_wifi_pozwala_podkrecic_core_i5_13600k_do_5_8_ghz-24475.html</a></p>

## Tesla będzie jednym z największych klientów TSMC? Samsung przegrał walkę o produkcję chipów
 - [https://ithardware.pl/aktualnosci/tesla_bedzie_jednym_z_najwiekszych_klientow_tsmc_samsung_przegral_walke_o_produkcje_chipow-24481.html](https://ithardware.pl/aktualnosci/tesla_bedzie_jednym_z_najwiekszych_klientow_tsmc_samsung_przegral_walke_o_produkcje_chipow-24481.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 12:22:30+00:00

<img src="https://ithardware.pl/artykuly/min/24481_1.jpg" />            Tesla podobno złożyła ogromne zam&oacute;wienie na komponenty do komputera nowej generacji w pełni autonomicznego pojazdu u tajwańskiego giganta TSMC.&nbsp;Zam&oacute;wienie jest tak duże, że może uczynić Teslę jednym z największych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tesla_bedzie_jednym_z_najwiekszych_klientow_tsmc_samsung_przegral_walke_o_produkcje_chipow-24481.html">https://ithardware.pl/aktualnosci/tesla_bedzie_jednym_z_najwiekszych_klientow_tsmc_samsung_przegral_walke_o_produkcje_chipow-24481.html</a></p>

## Samsung 980, czyli jak przyspieszyć swój komputer, nie wydając fortuny
 - [https://ithardware.pl/poradniki/samsung_980_poradnik-24326.html](https://ithardware.pl/poradniki/samsung_980_poradnik-24326.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 11:46:30+00:00

<img src="https://ithardware.pl/artykuly/min/24326_1.jpg" />            Komputer ma już nieco lat na karku i nie działa tak sprawnie, jak tego oczekujecie? A może kupując PC kilka lat temu, musieliście iść na pewne kompromisy, kt&oacute;re obejmowały pamięć masową? W obu przypadkach warto zastanowić się nad...
            <p>Pełna wersja strony <a href="https://ithardware.pl/poradniki/samsung_980_poradnik-24326.html">https://ithardware.pl/poradniki/samsung_980_poradnik-24326.html</a></p>

## W tym roku będzie na świecie 3,2 mld graczy, ale przychody branży zaliczą pierwszy spadek od 15 lat
 - [https://ithardware.pl/aktualnosci/w_tym_roku_bedzie_na_swiecie_3_2_mld_graczy_ale_przychody_branzy_zalicza_pierwszy_spadek_od_15_lat-24474.html](https://ithardware.pl/aktualnosci/w_tym_roku_bedzie_na_swiecie_3_2_mld_graczy_ale_przychody_branzy_zalicza_pierwszy_spadek_od_15_lat-24474.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 11:06:01+00:00

<img src="https://ithardware.pl/artykuly/min/24474_1.jpg" />            Jeszcze w latach 90. ubiegłego roku gry wideo uznawane były za bardziej niszową rozrywkę dla dzieci i nastolatk&oacute;w. Obecnie ich postrzeganie radykalnie się zmieniło (choć wciąż nie brakuje stereotyp&oacute;w), a według najnowszych danych,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/w_tym_roku_bedzie_na_swiecie_3_2_mld_graczy_ale_przychody_branzy_zalicza_pierwszy_spadek_od_15_lat-24474.html">https://ithardware.pl/aktualnosci/w_tym_roku_bedzie_na_swiecie_3_2_mld_graczy_ale_przychody_branzy_zalicza_pierwszy_spadek_od_15_lat-24474.html</a></p>

## Czeka nas podwyżka cen chipów? Wafle krzemowe TSMC 3 nm będą znacznie droższe od 5 nm
 - [https://ithardware.pl/aktualnosci/czeka_nas_podwyzka_cen_chipow_wafle_krzemowe_tsmc_3_nm_beda_znacznie_drozsze_od_5_nm-24478.html](https://ithardware.pl/aktualnosci/czeka_nas_podwyzka_cen_chipow_wafle_krzemowe_tsmc_3_nm_beda_znacznie_drozsze_od_5_nm-24478.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 11:03:30+00:00

<img src="https://ithardware.pl/artykuly/min/24478_1.jpg" />            Jak wskazują najnowsze doniesienia, TSMC zamierza podnieść cenę za wafle krzemowe 3 nm do poziomu 20 tys. dolar&oacute;w. M&oacute;wimy zatem o podwyżce rzędu 25% w stosunku to technologii 5 nm. Oznacza to, że kolejna generacja kart graficznych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/czeka_nas_podwyzka_cen_chipow_wafle_krzemowe_tsmc_3_nm_beda_znacznie_drozsze_od_5_nm-24478.html">https://ithardware.pl/aktualnosci/czeka_nas_podwyzka_cen_chipow_wafle_krzemowe_tsmc_3_nm_beda_znacznie_drozsze_od_5_nm-24478.html</a></p>

## OneXPlayer 2 zapowiedziane. Nowy handheld z CPU Intel Raptor Lake lub AMD Ryzen 7 6800U
 - [https://ithardware.pl/aktualnosci/onexplayer_2_zapowiedziane_nowy_handheld_z_cpu_intel_raptor_lake_lub_amd_ryzen_7_6800u-24473.html](https://ithardware.pl/aktualnosci/onexplayer_2_zapowiedziane_nowy_handheld_z_cpu_intel_raptor_lake_lub_amd_ryzen_7_6800u-24473.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 10:31:01+00:00

<img src="https://ithardware.pl/artykuly/min/24473_1.jpg" />            Przedsprzedaż konsoli przenośnej OneXPlayer 2 rozpocznie się jeszcze w tym tygodniu, a jej producent potwierdził właśnie wstępne informacje na temat jej specyfikacji.&nbsp;

Wbrew temu, co może sugerować nazwa, nie jest to druga konsola od...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/onexplayer_2_zapowiedziane_nowy_handheld_z_cpu_intel_raptor_lake_lub_amd_ryzen_7_6800u-24473.html">https://ithardware.pl/aktualnosci/onexplayer_2_zapowiedziane_nowy_handheld_z_cpu_intel_raptor_lake_lub_amd_ryzen_7_6800u-24473.html</a></p>

## Heroes of Might & Magic 3 jako gra planszowa. Polskie studio zebrało już ponad 2 mln USD
 - [https://ithardware.pl/aktualnosci/heroes_of_might_magic_3_jako_gra_planszowa_polskie_studio_zebralo_juz_ponad_2_mln_usd-24467.html](https://ithardware.pl/aktualnosci/heroes_of_might_magic_3_jako_gra_planszowa_polskie_studio_zebralo_juz_ponad_2_mln_usd-24467.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 10:17:20+00:00

<img src="https://ithardware.pl/artykuly/min/24467_1.jpg" />            Polskie studio Archon stworzyło grę planszową opartą na legendarnej grze komputerowej Heroes of Might &amp; Magic 3. Autorzy zebrali już ponad 2 miliony dolar&oacute;w na projekt.

Heroes of Might &amp; Magic 3&nbsp;to jedna z najsłynniejszych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/heroes_of_might_magic_3_jako_gra_planszowa_polskie_studio_zebralo_juz_ponad_2_mln_usd-24467.html">https://ithardware.pl/aktualnosci/heroes_of_might_magic_3_jako_gra_planszowa_polskie_studio_zebralo_juz_ponad_2_mln_usd-24467.html</a></p>

## Aktywiści atakują Elona Muska za przywrócenie konta Donalda Tumpa na Twitterze
 - [https://ithardware.pl/aktualnosci/aktywisci_atakuja_elona_muska_za_przywrocenie_konta_donalda_tumpa_na_twitterze-24479.html](https://ithardware.pl/aktualnosci/aktywisci_atakuja_elona_muska_za_przywrocenie_konta_donalda_tumpa_na_twitterze-24479.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 09:51:50+00:00

<img src="https://ithardware.pl/artykuly/min/24479_1.jpg" />            Grupa aktywist&oacute;w Free Press oraz&nbsp;NAACP krytykuje&nbsp;Twittera&nbsp;za przywr&oacute;cenie konta byłego prezydenta&nbsp;Donalda Trumpa.&nbsp;Grupa stwierdziła, że&nbsp;​​Elon Musk&nbsp;złamał obietnicę niepodejmowania takich decyzji...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/aktywisci_atakuja_elona_muska_za_przywrocenie_konta_donalda_tumpa_na_twitterze-24479.html">https://ithardware.pl/aktualnosci/aktywisci_atakuja_elona_muska_za_przywrocenie_konta_donalda_tumpa_na_twitterze-24479.html</a></p>

## Nie zabraknie kart graficznych Radeon RX 7900 na premierę. AMD podobno szykuje duży zapas
 - [https://ithardware.pl/aktualnosci/nie_zabraknie_kart_graficznych_radeon_rx_7900_na_premiere_amd_podobno_szykuje_duzy_zapas-24472.html](https://ithardware.pl/aktualnosci/nie_zabraknie_kart_graficznych_radeon_rx_7900_na_premiere_amd_podobno_szykuje_duzy_zapas-24472.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 09:12:01+00:00

<img src="https://ithardware.pl/artykuly/min/24472_1.jpg" />            Według nieoficjalnych doniesień AMD przygotowuje duży zapas kart graficznych Radeon RX 7900 &bdquo;RDNA 3&rdquo; na ich premierę, kt&oacute;ra planowana jest w połowie przyszłego miesiąca.&nbsp;

W artykule opublikowanym przez MyDrivers,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nie_zabraknie_kart_graficznych_radeon_rx_7900_na_premiere_amd_podobno_szykuje_duzy_zapas-24472.html">https://ithardware.pl/aktualnosci/nie_zabraknie_kart_graficznych_radeon_rx_7900_na_premiere_amd_podobno_szykuje_duzy_zapas-24472.html</a></p>

## Black Friday z iiyama. Świetne monitory w obniżonych cenach!
 - [https://ithardware.pl/aktualnosci/black_friday_z_iiyama_swietne_monitory_w_obnizonych_cenach-24477.html](https://ithardware.pl/aktualnosci/black_friday_z_iiyama_swietne_monitory_w_obnizonych_cenach-24477.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 08:39:11+00:00

<img src="https://ithardware.pl/artykuly/min/24477_1.jpg" />            Black Friday i Cyber Monday to znakomity spos&oacute;b, by zaoszczędzić sporą sumkę pieniędzy podczas zakup&oacute;w urządzeń elektronicznych. iiyama, czyli jeden z największych producent&oacute;w monitor&oacute;w komputerowych na świecie, rusza...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/black_friday_z_iiyama_swietne_monitory_w_obnizonych_cenach-24477.html">https://ithardware.pl/aktualnosci/black_friday_z_iiyama_swietne_monitory_w_obnizonych_cenach-24477.html</a></p>

## Postal 3 zniknął ze sprzedaży na Steam. Powodem "DRM i ogólna jakość"
 - [https://ithardware.pl/aktualnosci/postal_3_zniknal_ze_sprzedazy_na_steam_przez_drm_i_ogolna_jakosc-24470.html](https://ithardware.pl/aktualnosci/postal_3_zniknal_ze_sprzedazy_na_steam_przez_drm_i_ogolna_jakosc-24470.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 08:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/24470_1.jpg" />            Postal 3 zadebiutował ponad dekadę temu wyłącznie na PC. Gra nie jest już dostępna w sprzedaży na Steam, o czym poinformowali tw&oacute;rcy poprzednich części gry. Jaki jest pow&oacute;d usunięcia produkcji?

Studio ogłosiło, iż decyzja o...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/postal_3_zniknal_ze_sprzedazy_na_steam_przez_drm_i_ogolna_jakosc-24470.html">https://ithardware.pl/aktualnosci/postal_3_zniknal_ze_sprzedazy_na_steam_przez_drm_i_ogolna_jakosc-24470.html</a></p>

## Philips 27B1U7903 - wysokiej klasy monitor IPS MiniLED 4K do profesjonalnych zastosowań
 - [https://ithardware.pl/aktualnosci/philips_27b1u7903_wysokiej_klasy_monitor_ips_miniled_4k_do_profesjonalnych_zastosowan-24471.html](https://ithardware.pl/aktualnosci/philips_27b1u7903_wysokiej_klasy_monitor_ips_miniled_4k_do_profesjonalnych_zastosowan-24471.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 08:07:40+00:00

<img src="https://ithardware.pl/artykuly/min/24471_1.jpg" />            MMD, producent monitor&oacute;w marki Philips, zaprezentował sw&oacute;j najnowszy model, przeznaczony m.in. do profesjonalnych zadań graficznych. Ten nosi nazwę 27B1U7903 i stanowi rozszerzenie serii Brilliance 7000. W wyświetlaczu zastosowano...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/philips_27b1u7903_wysokiej_klasy_monitor_ips_miniled_4k_do_profesjonalnych_zastosowan-24471.html">https://ithardware.pl/aktualnosci/philips_27b1u7903_wysokiej_klasy_monitor_ips_miniled_4k_do_profesjonalnych_zastosowan-24471.html</a></p>

## GeForce RTX 3060 Ti z pamięcią GDDR6X ma całkowicie zastąpić wariant z GDDR6
 - [https://ithardware.pl/aktualnosci/geforce_rtx_3060_ti_z_pamiecia_gddr6x_ma_calkowicie_zastapic_wariant_z_gddr6-24469.html](https://ithardware.pl/aktualnosci/geforce_rtx_3060_ti_z_pamiecia_gddr6x_ma_calkowicie_zastapic_wariant_z_gddr6-24469.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-22 07:13:23+00:00

<img src="https://ithardware.pl/artykuly/min/24469_1.jpg" />            Jak donoszą chińskie media (za VideoCardz), NVIDIA zamierza całkowicie zastąpić karty graficzne GeForce RTX 3060 Ti z pamięciami GDDR6 ulepszonym wariantem z kośćmi GDDR6X.

W zeszłym miesiącu NVIDIA oficjalnie zaprezentowała karty graficzne...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/geforce_rtx_3060_ti_z_pamiecia_gddr6x_ma_calkowicie_zastapic_wariant_z_gddr6-24469.html">https://ithardware.pl/aktualnosci/geforce_rtx_3060_ti_z_pamiecia_gddr6x_ma_calkowicie_zastapic_wariant_z_gddr6-24469.html</a></p>


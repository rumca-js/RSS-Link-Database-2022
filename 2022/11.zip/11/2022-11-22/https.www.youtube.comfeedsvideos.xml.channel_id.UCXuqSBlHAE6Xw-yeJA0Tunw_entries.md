# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I Bought the Two FASTEST CPUs... but I'm Only Keeping the Winner - 13900K vs 7950X
 - [https://www.youtube.com/watch?v=sF9MrFyEF5E](https://www.youtube.com/watch?v=sF9MrFyEF5E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-11-23 00:00:00+00:00

Check out MSI's holiday deals and the #TYMSI giveaway at https://msi.gm/3NzyMO3

Try SimpleMDM FREE for 30 days on unlimited devices at https://lmg.gg/SimpleMDMSept

Linus is going to upgrade to the next generation, but does he stick with AMD or has Intel clawed their way back on top? We built overkill computers for each team and drag raced them in his favorite games to determine the winner.

Discuss on the forum: https://linustechtips.com/topic/1469551-i-need-a-new-cpu/

Buy a Corsair 5000D Airflow Case: https://geni.us/PXITxIN

Buy an H150i Elite Capellix 360mm AIO Cooler: https://geni.us/cAQEwrx

Buy a Seasonic Prime TX-1300 PSU: https://geni.us/dqrj0hS

Buy a Sabrent Rocket 4+ 8TB NVMe SSD: https://geni.us/AmCm

Buy an RTX 4090 Founders Edition: https://geni.us/yxLdP

Buy a Ryzen 9 7950x: https://geni.us/wx18H

Buy an ASUS ROG Crosshair X670E Extreme: https://geni.us/zbkzuY3

Buy a Kit of G.Skill Trident Z5 Neo RGB (2x32GB): https://geni.us/eUUHMj

Buy a Kit of G.Skill Trident Z5 RGB (2x16GB): https://geni.us/Rde1y

Buy a Intel Core i9 13900k: https://geni.us/lryA82u

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:10 Who Builds What
3::00 Motherboards
5:30 Overkill SSD
6:25 Cooling
7:24 GPU
9:05 PSU
9:50 Memory
11:12 Boot
13:10 CSGO
15:10 Anno
16:45 Halo
17:20 Choose
19:25 Outro

## We Downgraded our Computers – Switching to Intel Arc Pt. 1
 - [https://www.youtube.com/watch?v=5nI0AI8k8cU](https://www.youtube.com/watch?v=5nI0AI8k8cU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-11-22 00:00:00+00:00

Vessi is giving away a pair of socks of your choice to the first 100 shoes sold using code SocksLinusTechTips at http://Vessi.com/LinusTechTips

Get Unlimited Data for $25/month at https://l.boostmobile.com/1hovqg

For the first time on this channel we're performing a downgrade.. so Linus and Luke can try Intel Arc!  

Discuss on the forum: https://linustechtips.com/topic/1469334-we-downgraded-our-computers-%E2%80%93-switching-to-intel-arc-pt-1/

Buy an Intel Arc A770: https://geni.us/AChNbx
Buy a Logitech G Cloud: https://geni.us/l6AJu

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 - A New GPU!!!!!!
1:15 - Boost Mobile
1:35 - VR PC Removal
4:20 - Linus personal rig removal
7:18 - Removing water cooled RTX 3090
9:35 - The Depinnining
14:33 - It's Arc Time! (problems)
22:35 - Vessi!
23:16 - Outro


# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## The Unexpected Measure that Makes the Modern World Tick
 - [https://www.youtube.com/watch?v=mg9yc7_7BWc](https://www.youtube.com/watch?v=mg9yc7_7BWc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2022-11-22 16:29:03+00:00

Check out Serving Up Science on @PBSFood : https://youtu.be/Mi84o9ZKuXs
We’re on PATREON! Join the community https://www.patreon.com/itsokaytobesmart
↓↓↓ More info and sources below ↓↓↓

All of modern society relies upon a seemingly simple but surprisingly complex unit of measurement: the second. But knowing exactly what a “second” is is more complicated than you might think!

SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub 

Thank you to the following for helpful discussions and research for this episode:
Geoff Chester - U.S. Naval Observatory
Judah Levine - National Institute of Standards and Technology
Jeffrey Sherman - National Institute of Standards and Technology
Elizabeth Donley - National Institute of Standards and Technology

-----------

High fives to all our Brain Trust Patrons:

paul andre bouis
Mark Littlehale
Ali Freiburger
Mehdi Damou
Barbora Bei
Burt Humburg
Roy Lasris
dani bowman
David Johnston
Salih Arslan
Baerbel Winkler
Robert Young
Eric Meer
Dustin
Karen Haskell


Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/


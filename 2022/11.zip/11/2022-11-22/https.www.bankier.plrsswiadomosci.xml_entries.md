# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Zaznania podatkowe Donalda Trumpa i jego spółek trafią do Kongresu
 - [https://www.bankier.pl/wiadomosc/Zaznania-podatkowe-Donalda-Trumpa-i-jego-spolek-trafia-do-Kongresu-8444288.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zaznania-podatkowe-Donalda-Trumpa-i-jego-spolek-trafia-do-Kongresu-8444288.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 21:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/c/589a21ca98e670-948-568-0-51-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sąd Najwyższy USA odrzucił we wtorek wniosek byłego prezydenta Donalda Trumpa, by zablokować dostęp komisji finansów Izby Reprezentantów do zeznań podatkowych jego i jego spółek. To zakończenie trwającej od 2019 batalii prawnej.</p>

## S&P500 powrócił do 4 000 punktów. Solidne wzrosty w Ameryce
 - [https://www.bankier.pl/wiadomosc/S-P500-powrocil-do-4-000-punktow-8444281.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/S-P500-powrocil-do-4-000-punktow-8444281.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 21:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/a/d4b6b9268337b3-948-568-150-157-2850-1709.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wtorkowa sesja na nowojorskich giełdach przyniosła przeszło
jednoprocentowe wzrosty głównych indeksów. Inwestorzy analizowali dane spływające z sektora detalicznego.</p>

## Prezydent Bolsonaro nie odpuszcza. Złożył skargę na wybory w Brazylii
 - [https://www.bankier.pl/wiadomosc/Prezydent-Bolsonaro-nie-odpuszczal-Zlozyl-skarge-na-wybory-w-Brazylii-8444277.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezydent-Bolsonaro-nie-odpuszczal-Zlozyl-skarge-na-wybory-w-Brazylii-8444277.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 20:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/a/4244e786253284-945-560-0-357-2200-1319.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Brazylii Jair Bolsonaro zakwestionował część wyników wyborów prezydenckich z października, w których przegrał z lewicowym rywalem, Luizem Inacio Lulą da Silvą, i złożył w sądzie skargę domagając się weryfikacji wyników - podała we wtorek agencja Reutera.</p>

## ZWZ CD Projektu będzie decydować ws. ustanowienia nowego programu motywacyjnego
 - [https://www.bankier.pl/wiadomosc/ZWZ-CD-Projektu-bedzie-decydowac-ws-ustanowienia-nowego-programu-motywacyjnego-8444275.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/ZWZ-CD-Projektu-bedzie-decydowac-ws-ustanowienia-nowego-programu-motywacyjnego-8444275.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 20:52:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/c/06019c6492cf63-948-568-0-22-1805-1082.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />ZWZ CD Projektu, zwołane na 20 grudnia, będzie decydować w sprawie ustanowienia programu motywacyjnego na lata obrotowe 2023-2027 - wynika z projektów uchwał. Jednocześnie akcjonariusze mają zdecydować w sprawie zaniechania realizacji programu motywacyjnego na lata 2020-
2025 i uchylenia dotyczących go uchwał WZ.</p>

## Zadośćuczynienie za smog. Starcie RPO z Prokuratorem Generalnym
 - [https://www.bankier.pl/wiadomosc/Zadoscuczynienie-za-smog-Starcie-RPO-z-Prokuratorem-Generalnym-8444266.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zadoscuczynienie-za-smog-Starcie-RPO-z-Prokuratorem-Generalnym-8444266.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 20:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/d/238996c4a4693e-948-568-0-662-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />O odrzucenie skargi nadzwyczajnej Prokuratora Generalnego dotyczącej głośnej sprawy zadośćuczynienia za smog wniósł do Sądu Najwyższego RPO Marcin Wiącek. Jednocześnie chce on, aby SN zajął się problemem, czy dopuszczalna jest skarga nadzwyczajna "w interesie Skarbu Państwa".</p>

## Zysk netto grupy GPW w III kw. wyniósł 31,1 mln zł, powyżej konsensusu
 - [https://www.bankier.pl/wiadomosc/Zysk-netto-grupy-GPW-w-III-kw-wyniosl-31-1-mln-zl-powyzej-konsensusu-8444263.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zysk-netto-grupy-GPW-w-III-kw-wyniosl-31-1-mln-zl-powyzej-konsensusu-8444263.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 20:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/7/6002bf98f2266b-945-560-25-56-1706-1023.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zysk netto grupy GPW w trzecim kwartale 2022 roku spadł rdr o 14 proc., do 31,1 mln zł  - poinformowała spółka w raporcie okresowym. Wynik netto okazał się wyższy o 6,6 proc. od zakładanego przez analityków zysku na poziomie 29,4 mln zł.</p>

## Niemcy przestają robić zakupy? Inflacja zaciska im pas
 - [https://www.bankier.pl/wiadomosc/Niemcy-przestaja-robic-zakupy-Inflacja-zaciska-im-pas-8444222.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Niemcy-przestaja-robic-zakupy-Inflacja-zaciska-im-pas-8444222.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 17:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/2/88203018b0306a-948-567-0-67-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad trzy czwarte konsumentów w Niemczech musi obecnie ograniczyć zakupy, wynika z badania Future Consumer Index firmy doradczej EY, z którym zapoznał się portal dziennika "Welt". Jednocześnie co drugi z respondentów twierdzi, że z powodu gwałtownie rosnących cen może kupić tylko rzeczy niezbędne do życia.</p>

## "Nadzwyczajnych zysków w energetyce nie ma". PGE pokazał wyniki
 - [https://www.bankier.pl/wiadomosc/Zysk-netto-j-d-PGE-w-III-kw-wyniosl-654-mln-zl-zgodnie-z-wczesniejszymi-szacunkami-8444220.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zysk-netto-j-d-PGE-w-III-kw-wyniosl-654-mln-zl-zgodnie-z-wczesniejszymi-szacunkami-8444220.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 17:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/f/9ba54db9abe559-948-567-0-40-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zysk netto jednostki dominującej grupy PGE wyniósł w trzecim kwartale 2022 roku 654 mln zł wobec 561 mln zł zysku rok wcześniej - podała spółka w raporcie kwartalnym. PGE szacowała wcześniej skonsolidowany wynik netto j.d. właśnie na około 654 mln zł.</p>

## Drożej niż proponowała Polska. Zachód chce ustanowienie limitu ceny rosyjskiej ropy
 - [https://www.bankier.pl/wiadomosc/Drozej-niz-proponowala-Polska-Zachod-chce-ustanowienie-limitu-ceny-rosyjskiej-ropy-8444217.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Drozej-niz-proponowala-Polska-Zachod-chce-ustanowienie-limitu-ceny-rosyjskiej-ropy-8444217.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 17:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/5/ada76e728af27d-945-560-7-3-1492-895.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />USA i zachodni sojusznicy rozważają ustanowienie limitu ceny rosyjskiej ropy naftowej na poziomie 60 dol. za baryłkę, a decyzja w tej sprawie może zapaść już w środę - podał we wtorek "Wall Street Journal". Według dziennika, Polska opowiadała się za znacznie niższą kwotą ok. 20 dolarów.</p>

## Reuters: Powstający w Polsce port CPK poprawi wojskową logistykę w Europie Środkowej
 - [https://www.bankier.pl/wiadomosc/Reuters-Powstajacy-w-Polsce-port-CPK-poprawi-wojskowa-logistyke-w-Europie-Srodkowej-8444193.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Reuters-Powstajacy-w-Polsce-port-CPK-poprawi-wojskowa-logistyke-w-Europie-Srodkowej-8444193.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 17:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/7/64cd23226aa3b1-948-568-0-0-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Powstający w Polsce CPK poprawi wojskową logistykę w Europie Środkowej w sytuacji, kiedy według byłego dowódcy armii USA w Europie, gen. Bena Hodgesa, "brakuje zdolności transportowej i infrastruktury, która umożliwiałaby szybkie przemieszczanie się sił NATO po Europie" - informuje agencja Reutera.</p>

## Białoruś „weryfikuje dane” poborowych. Zastrzega, że nie jest to mobilizacja
 - [https://www.bankier.pl/wiadomosc/Bialorus-weryfikuje-dane-poborowych-Zastrzega-ze-nie-jest-to-mobilizacja-8444176.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bialorus-weryfikuje-dane-poborowych-Zastrzega-ze-nie-jest-to-mobilizacja-8444176.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 16:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/e/cf0e9452e30c53-948-568-0-95-1472-883.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ministerstwo obrony Białorusi kontynuuje weryfikację danych osób podlegających obowiązkowi służby wojskowej. Według zapowiedzi do końca roku inspekcja danych obejmie wszystkich poborowych. Resort zaznacza przy tym, że „insynuacje na temat ukrytej mobilizacji to dezinformacja”.</p>

## Pułap cenowy dla gazu. Unia chce zapobiec zawirowaniom na rynku gazu
 - [https://www.bankier.pl/wiadomosc/Pulap-cenowy-dla-gazu-Unia-chce-zapobiec-zawirowaniom-na-rynku-gazu-8444159.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pulap-cenowy-dla-gazu-Unia-chce-zapobiec-zawirowaniom-na-rynku-gazu-8444159.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 16:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/1/e707ac8815541b-948-568-0-1286-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komisja Europejska zaproponowała we wtorek wprowadzenie rozwiązania regulacyjnego, które miałoby zapobiegać nagłym i nadmiernym wzrostom cen gazu. Pułap cenowy proponowany przez Komisję dotyczyłby instrumentów pochodnych TTF z miesięcznym wyprzedzeniem i zostałby ustanowiony na poziomie 275 euro za MWh.</p>

## Co dalej z KPO? Premier i prezes zmienią zdanie
 - [https://www.bankier.pl/wiadomosc/Co-dalej-z-KPO-Premier-i-prezes-zmienia-zdanie-8444129.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Co-dalej-z-KPO-Premier-i-prezes-zmienia-zdanie-8444129.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 16:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/7/e5b4060ec2a480-948-568-0-0-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dyskusja w sprawie Krajowego Planu Odbudowy z Polską trwa. To nie jest szantaż – powiedział na posiedzeniu połączonych komisji Parlamentu Europejskiego w Strasburgu komisarz ds. gospodarczych Paolo Gentiloni. „Czy państwo czekacie na zmianę rządu w Polsce?” – pytał Komisję Europejską europoseł Bogdan Rzońca (PiS)</p>

## Lepsza postawa GPW na tle Europy. WIG20 znów powyżej 1700 pkt.
 - [https://www.bankier.pl/wiadomosc/Lepsza-postawa-GPW-na-tle-Europy-WIG20-znow-powyzej-1700-pkt-8444106.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lepsza-postawa-GPW-na-tle-Europy-WIG20-znow-powyzej-1700-pkt-8444106.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 16:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/8/20ec54012a8c87-948-568-10-138-2032-1219.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na zakończenie dnia indeksy na GPW zanotowały wyraźne zwyżki z przewodnią rolą portfela największych spółek. Warszawska giełda była mocniejsza w we wtorek od większości rynków bazowych i wpisywała się we wzrosty koszyka rynków wschodzących. W tle pojawiły się też doniesienia o zmianie postawy rządu ws. pieniędzy z KPO.</p>

## PiS dopiął swego. Wybory samorządowe przełożone
 - [https://www.bankier.pl/wiadomosc/Pozniejszy-termin-wyborow-samorzadowych-Prezydent-podpisal-ustawe-8444125.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pozniejszy-termin-wyborow-samorzadowych-Prezydent-podpisal-ustawe-8444125.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 15:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/b/ce4aa6b7461935-948-568-0-146-1632-979.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Andrzej Duda podpisał we wtorek ustawę, która wydłuża kadencję samorządów do 30 kwietnia 2024 r. Ma ona na celu rozdzielenie dat wyborów parlamentarnych i samorządowych. Zgodnie z wcześniejszym kalendarzem wyborczym jedne i drugie miały odbyć się jesienią 2023 r.</p>

## Stadion Narodowy w naprawie. Zamontowany zostanie bypass
 - [https://www.bankier.pl/wiadomosc/Naprawa-Stadionu-Narodowego-Zamontowany-zostanie-bypass-8444120.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Naprawa-Stadionu-Narodowego-Zamontowany-zostanie-bypass-8444120.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 15:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/9/febb0b65700d4e-948-568-0-448-3990-2394.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Trwa produkcja bypassu, który pozwoli na zabezpieczenie uszkodzonego elementu konstrukcji dachu Stadionu Narodowego. Bypass zostanie dostarczony najpewniej w piątek - przekazała rzeczniczka PGE Narodowego Małgorzata Bajer. Stadion z powodu wykrycia uszkodzenia jest zamknięty dla odwiedzających.</p>

## Kijów obawia się ponownego ataku. Rosja szykuje nową mobilizację?
 - [https://www.bankier.pl/wiadomosc/Kijow-obawia-sie-ponownego-ataku-Rosja-szykuje-nowa-mobilizacje-8444079.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kijow-obawia-sie-ponownego-ataku-Rosja-szykuje-nowa-mobilizacje-8444079.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 15:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/6/5972307c7c2ef4-948-568-0-0-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Były bokserski mistrz świata Wołodymyr Kliczko obawia się ponownego rosyjskiego ataku na Kijów najpóźniej wiosną przyszłego roku. Z kolei Rosja przygotowuje się do nowej fali mobilizacji w styczniu 2023 r., a plan przewiduje powołanie od 500 tys. do 700 tys. rezerwistów. </p>

## Caritas z komisarzem nadzwyczajnym. Papież zdymisjonował przewodniczącego
 - [https://www.bankier.pl/wiadomosc/Caritas-z-komisarzem-nadzwyczajnym-Papiez-zdymisjonowal-przewodniczacego-8444040.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Caritas-z-komisarzem-nadzwyczajnym-Papiez-zdymisjonowal-przewodniczacego-8444040.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 14:29:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/2/758c9062863d6e-948-568-0-79-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Papież Franciszek mianował nadzwyczajnego komisarza Caritas Internationalis, czyli federacji wszystkich krajowych organizacji Caritas. Na mocy ogłoszonego we wtorek dekretu stanowisko przewodniczącego utracił kardynał Luis Antonio Tagle z Filipin oraz jego zastępcy i sekretarz generalny.</p>

## "Użyjemy czołgów tak szybko, jak to możliwe". Konflikt między Turcją a Kurdami eskaluje
 - [https://www.bankier.pl/wiadomosc/Eskalacja-konfliktu-miedzy-Turcja-a-Kurdami-Erdogan-zapowiada-uzycie-czolgow-8444030.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Eskalacja-konfliktu-miedzy-Turcja-a-Kurdami-Erdogan-zapowiada-uzycie-czolgow-8444030.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 14:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/4/3a3e51d8545c1c-948-568-0-218-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Tureckie siły zbrojne użyją przeciw kurdyjskim bojownikom czołgów i wojsk lądowych tak szybko, jak to możliwe - oświadczył we wtorek prezydent Turcji Recep Tayyip Erdogan. Operacja odwetowa Ankary przeciw Kurdom w północnej Syrii i Iraku trwa od kilku dni.</p>

## Kryptowalutowi oszuści zatrzymani w Estonii. Ukradli ponad 500 mln dolarów
 - [https://www.bankier.pl/wiadomosc/Kryptowalutowi-oszusci-zatrzymani-w-Estonii-Ukradli-ponad-500-mln-dolarow-8443994.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kryptowalutowi-oszusci-zatrzymani-w-Estonii-Ukradli-ponad-500-mln-dolarow-8443994.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 13:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/d/e5b6f6bf91bdce-948-569-295-375-1566-940.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Estońska policja we współpracy z amerykańskim Federalnym Biurem Śledczym (FBI) aresztowały Siergieja Potapienko i Iwana Turogina podejrzanych o oszustwo kryptowalutowe o wartości 575 milionów dolarów - poinformował estoński portal ERR.</p>

## Lewiatan: wzrost przeciętnego zatrudnienia to efekt wzmożonego naboru m.in. w gastronomii
 - [https://www.bankier.pl/wiadomosc/Lewiatan-wzrost-przecietnego-zatrudnienia-to-efekt-wzmozonego-naboru-m-in-w-gastronomii-8443993.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lewiatan-wzrost-przecietnego-zatrudnienia-to-efekt-wzmozonego-naboru-m-in-w-gastronomii-8443993.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 13:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/d/40e1484ca943dc-948-568-0-80-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wzrost przeciętnego zatrudnienia w październiku wynikał w głównej mierze ze wzmożonego naboru w gastronomii i zakwaterowaniu - wskazał we wtorek ekspert ekonomiczny Konfederacji Lewiatan Mariusz Zielonka w komentarzu do danych GUS. Jak ocenił, wieszczenie kryzysu na rynku pracy było przedwczesne.</p>

## Unia zaostrza oceny ryzyka odnośnie infrastruktury krytycznej
 - [https://www.bankier.pl/wiadomosc/Unia-zaostrza-oceny-ryzyka-odnosnie-infrastruktury-krytycznej-8443979.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Unia-zaostrza-oceny-ryzyka-odnosnie-infrastruktury-krytycznej-8443979.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 13:21:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/4/a185924dd9ea80-948-568-0-336-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PE zatwierdził nowe zasady ochrony unijnej infrastruktury krytycznej. Nowa dyrektywa obejmuje jedenaście kluczowych sektorów, w tym sektor infrastruktury cyfrowej, gospodarki wodnej, żywności i zdrowia.</p>

## Inflacja z rekordami, a Narodowy Bank Węgier pozostawia niezmienione stopy
 - [https://www.bankier.pl/wiadomosc/Inflacja-z-rekordami-a-Narodowy-Bank-Wegier-pozostawia-niezmienione-stopy-8443967.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-z-rekordami-a-Narodowy-Bank-Wegier-pozostawia-niezmienione-stopy-8443967.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 13:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/7/b0d4a656f9b367-948-567-25-0-975-584.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Narodowy Bank Węgier (MNB) utrzymał we wtorek referencyjną, 3-miesięczną depozytową stopę na niezmienionym poziomie 13,00 proc. - poinformował bank po zakończeniu posiedzenia. Decyzja była zgodna z oczekiwaniami analityków.</p>

## Mocna sesja Ten Square Games. Wyniki potwierdzają zdolność generowania gotówki
 - [https://www.bankier.pl/wiadomosc/Mocna-sesja-Ten-Square-Games-Wyniki-potwierdzaja-zdolnosc-generowania-gotowki-8443956.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mocna-sesja-Ten-Square-Games-Wyniki-potwierdzaja-zdolnosc-generowania-gotowki-8443956.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 12:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/2/0a5acd199d33c6-945-567-15-11-933-560.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kurs Ten Square Games rośnie we wtorkowym handlu w dwucyfrowej skali. Spółka pokazała wyniki za III kwartał. Silne przepływy pieniężne i zdolność generowania gotówki to mocne strony pokazanego raportu – uważają eksperci. Zarząd na konferencji poinformował, że w 2023 r. zaprezentuje plany rozwoju na najbliższe lata. </p>

## Wahania na rynku zbóż. Izba podała dane
 - [https://www.bankier.pl/wiadomosc/Wahania-na-rynku-zboz-Izba-podala-dane-8443953.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wahania-na-rynku-zboz-Izba-podala-dane-8443953.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 12:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/9/8df1e998a58495-948-568-53-0-1811-1086.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Polsce spadły ceny zbóż przeznaczonych na eksport, jak i na potrzeby krajowe - informuje Izba Zbożowo-Paszowa. Na ten spadek wpływ miały m.in. zniżkujące ceny zbóż na giełdach światowych, a także zaawansowane zbiory kukurydzy oraz umocnienie złotego do np. dolara - dodano.</p>

## Ukraina uderza w oligarchów. Rewizje w firmie energetycznej
 - [https://www.bankier.pl/wiadomosc/Ukraina-przeprowadza-rewizje-w-firmie-energetycznej-Ma-zwiazki-z-oligarchami-8443923.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ukraina-przeprowadza-rewizje-w-firmie-energetycznej-Ma-zwiazki-z-oligarchami-8443923.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 12:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/c/6b9e46dacabd3f-948-568-0-39-1773-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Służba Bezpieczeństwa Ukrainy (SBU) prowadzi rewizje w firmie VS Energy, której właścicielami są oligarchowie z Rosji, firma ta zajmuje 10 proc. rynku energetycznego Ukrainy - poinformował we wtorek portal Ukraińska Prawda, powołując się na źródło w SBU.</p>

## Manipulacje w handlu na Milisystemie? W radzie nadzorczej jest Jakub Błaszczykowski
 - [https://www.bankier.pl/wiadomosc/Manipulacje-w-handlu-na-Milisystemie-W-radzie-nadzorczej-jest-Jakub-Blaszczykowski-8443857.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Manipulacje-w-handlu-na-Milisystemie-W-radzie-nadzorczej-jest-Jakub-Blaszczykowski-8443857.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 11:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/d/ff908d119c49aa-945-560-45-11-4455-2672.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ciąg dalszy sprawy  związanej ze spółką, w której akcjonariuszem i członkiem rady nadzorczej jest Jakub Błaszczykowski. Jej notowania na NewConnect po dwóch miesiącach zostały odwieszone, ale dochodzenie KNF-u ustaliło możliwość manipulacji w handlu akcjami przez tzw. spółdzielnię.</p>

## Oszuści znów zadzwonili do Andrzeja Dudy. Podawali się za prezydenta Francji
 - [https://www.bankier.pl/wiadomosc/Oszusci-znow-zadzwonili-do-Andrzeja-Dudy-Podawali-sie-za-prezydenta-Francji-8443882.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Oszusci-znow-zadzwonili-do-Andrzeja-Dudy-Podawali-sie-za-prezydenta-Francji-8443882.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 11:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/1/9ca9ff416384b7-948-568-0-75-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Doszło do połączenia telefonicznego prezydenta Andrzeja Dudy z osobą podającą się za prezydenta Francji Emanuela Macrona; po tym połączeniu Kancelaria Prezydenta niezwłocznie podjęła we współpracy z odpowiednimi służbami działania wyjaśniające - poinformowała we wtorek KPRP.</p>

## Czworo naukowców z Polski laureatami prestiżowych grantów ERC
 - [https://www.bankier.pl/wiadomosc/Czworo-naukowcow-z-Polski-laureatami-prestizowych-grantow-ERC-8443879.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czworo-naukowcow-z-Polski-laureatami-prestizowych-grantow-ERC-8443879.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 11:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/5/baf2b08ab696ab-937-562-12-0-937-562.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Czworo naukowców z Polski znalazło się w gronie 408 laureatów ERC Starting Grants - prestiżowych grantów przyznawanych przez Europejską Radę ds. Badań Naukowych (ERC). Dwójka badaczy reprezentuje UMK z Torunia, i po jednym Uniwersytet Jagielloński oraz Instytutu Biologii Doświadczalnej im. M. Nenckiego PAN.</p>

## 8 miliardów euro na innowacje. Wkrótce ruszają pierwsze konkursy dla firm
 - [https://www.bankier.pl/wiadomosc/8-miliardow-euro-na-innowacje-Wkrotce-ruszaja-pierwsze-konkursy-dla-firm-8443806.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/8-miliardow-euro-na-innowacje-Wkrotce-ruszaja-pierwsze-konkursy-dla-firm-8443806.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/c/2a9ffef1e9a479-945-560-0-116-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przedsiębiorcy z niecierpliwością wyczekują uruchomienia kolejnych środków z Funduszy Europejskich. W nowej perspektywie finansowania największe dotacje na innowacje będą pochodziły z programu Fundusze Europejskie dla Nowoczesnej Gospodarki (FENG). Resort funduszy zapowiada, że pierwsze konkursy ruszą już w pierwszym kwartale 2023 roku.  </p>

## Węgiel z PGG. Zmiany w logowaniu do e-sklepu - tylko przez profil zaufany, eDowód lub bank
 - [https://www.bankier.pl/wiadomosc/Wegiel-z-PGG-Zmiany-w-logowaniu-do-e-sklepu-tylko-przez-profil-zaufany-eDowod-lub-bank-8443864.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wegiel-z-PGG-Zmiany-w-logowaniu-do-e-sklepu-tylko-przez-profil-zaufany-eDowod-lub-bank-8443864.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 10:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/9/e37c6b0245d6a2-948-568-0-44-1775-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od najbliższego czwartku rejestracja i logowanie do sklepu internetowego Polskiej Grupy Górniczej (PGG) będą możliwe tylko za pomocą systemu identyfikacji elektronicznej login.gov.pl, czyli z potwierdzeniem tożsamości przez profil zaufany, eDowód czy konto bankowe - podała spółka.</p>

## Eksplozja rakiety w Przewodowie. Reporter Associated Press zwolniony po podaniu błędnej informacji
 - [https://www.bankier.pl/wiadomosc/Eksplozja-rakiety-w-Przewodowie-Reporter-Associated-Press-zwolniony-po-podaniu-blednej-informacji-8443841.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Eksplozja-rakiety-w-Przewodowie-Reporter-Associated-Press-zwolniony-po-podaniu-blednej-informacji-8443841.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 10:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/7/2f3ab645af6269-948-568-0-66-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Amerykańska agencja prasowa Associated Press zwolniła reportera, który podał informację błędnie sugerującą, że to Rosja wystrzeliła pocisk, który spadł w Polsce, powodując śmierć dwóch osób w Przewodowie - podał dziennik "Washington Post". "Kiedy nasze standardy zostają złamane, musimy powziąć kroki konieczne do ochrony integralności wiadomości" - poinformowała AP w oświadczeniu przekazanym PAP.</p>

## Analityk: Okres relatywnej słabości polskiej giełdy już miną
 - [https://www.bankier.pl/wiadomosc/Analityk-Okres-relatywnej-slabosci-polskiej-gieldy-juz-mina-8443835.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Analityk-Okres-relatywnej-slabosci-polskiej-gieldy-juz-mina-8443835.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 10:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/da5e84de8e0693-945-560-0-82-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Okres relatywnej słabości polskiej giełdy już minął. Na rynku widać zarówno szanse, jak i zagrożenia, jednak na ten moment bilans jest dodatni - ocenił w rozmowie z PAP Biznes Łukasz Siwek, zarządzający funduszami akcji w Skarbiec TFI. Jego zdaniem najbliższe miesiące warto wykorzystać na systematyczne zakupy akcji, a najwięcej okazji można znaleźć wśród małych i średnich spółek.</p>

## Sasin: Kopalnie nie będą wygaszane zgodnie z umową ws. górnictwa. Ona musi być zmieniona
 - [https://www.bankier.pl/wiadomosc/Sasin-Kopalnie-nie-beda-wygaszane-zgodnie-z-umowa-ws-gornictwa-Ona-musi-byc-zmieniona-8443836.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sasin-Kopalnie-nie-beda-wygaszane-zgodnie-z-umowa-ws-gornictwa-Ona-musi-byc-zmieniona-8443836.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 10:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/a/2ff99517593661-948-568-0-252-3878-2326.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Umowa musi być zmieniona, bo zmieniły się warunki w stosunku do czasu, kiedy była zawierana - mówił we wtorek minister aktywów państwowych Jacek Sasin, odnosząc się do umowy społecznej ws. górnictwa. Zapewnił, że kopalnie nie będą wygaszane według zawartego w niej harmonogramu.</p>

## Dwucyfrowa inflacja i podwyżki stóp do połowy 2023 roku. Prognozy OECD dla Polski
 - [https://www.bankier.pl/wiadomosc/Dwucyfrowa-inflacja-i-podwyzki-stop-do-polowy-2023-roku-Prognozy-OECD-dla-Polski-8443828.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dwucyfrowa-inflacja-i-podwyzki-stop-do-polowy-2023-roku-Prognozy-OECD-dla-Polski-8443828.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 10:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/4/d78c2320c5eb73-948-568-0-84-1772-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />OECD prognozuje, że PKB w Polsce w 2023 r. wzrośnie o 0,9 proc., a inflacja CPI wyniesie 10,8 proc. - wynika z najnowszej edycji raportu "Economic Outlook". Ekonomiści OECD szacują, że w 2024 r. wzrost gospodarczy przyspieszy do 2,4 proc., a wskaźnik CPI wyniesie 6,6 proc. Ryzyka dla prognoz wzrostu są skierowane w dół.</p>

## Kolejne zmiany w alimentach natychmiastowych. Sąd poinformuje o podwyżce świadczenia
 - [https://www.bankier.pl/wiadomosc/Alimenty-natychmiastowe-Resort-sprawiedliwosci-wprowadza-kolejne-zmiany-8443708.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Alimenty-natychmiastowe-Resort-sprawiedliwosci-wprowadza-kolejne-zmiany-8443708.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 09:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/7/5e2b0f5b9e4135-948-568-0-84-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />
Choć pierwsze zapowiedzi padły jeszcze w 2019 roku, instytucja alimentów natychmiastowych wciąż czeka na zielone światło. Co więcej, Ministerstwo Sprawiedliwości wprowadziło właśnie kolejne zmiany do projektu nowelizacji Kodeksu rodzinnego i opiekuńczego. Czy z punktu widzenia ubiegających się o świadczenie będzie to zmiana na plus? 



</p>

## Inflacja producencka w Polsce w końcu zaczęła hamować
 - [https://www.bankier.pl/wiadomosc/Inflacja-producencka-w-Polsce-w-koncu-zaczela-hamowac-8443755.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-producencka-w-Polsce-w-koncu-zaczela-hamowac-8443755.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 09:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/f/ad0c0246e012b5-937-562-62-0-937-562.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Inflacja producencka w Polsce zwalniała w październiku drugi miesiąc z 
rzędu. Niestety nadal utrzymuje się na bardzo wysokim poziomie.</p>

## Polski przemysł hamuje, a będzie gorzej
 - [https://www.bankier.pl/wiadomosc/Polski-przemysl-hamuje-a-bedzie-gorzej-8443756.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polski-przemysl-hamuje-a-bedzie-gorzej-8443756.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 09:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/a/57e45054d23fa7-948-568-0-67-1896-1137.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po trzech miesiącach wzrostów wyrównanej sezonowo produkcji 
przemysłowej w październiku zmniejszyła się ona w porównaniu do 
poprzedniego miesiąca.</p>

## Sasin o przywróceniu VAT-u m.in. na paliwa: zrobimy wszystko, by Polacy jak najmniej to odczuli
 - [https://www.bankier.pl/wiadomosc/Sasin-o-przywroceniu-VAT-u-m-in-na-paliwa-zrobimy-wszystko-by-Polacy-jak-najmniej-to-odczuli-8443810.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sasin-o-przywroceniu-VAT-u-m-in-na-paliwa-zrobimy-wszystko-by-Polacy-jak-najmniej-to-odczuli-8443810.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 09:27:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/e/81c2e39348e376-948-568-0-22-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zrobimy wszystko, by Polacy jak najmniej to odczuli - zapewnił we wtorek minister aktywów państwowych Jacek Sasin pytany, co stanie się z cenami paliw od nowego roku, gdy przywrócony zostanie na nie VAT. Dodał, że zaapeluje do spółek Skarbu Państwa, by redukowały zyski, aby ceny wzrosły jak najmniej.</p>

## Iran rozpoczął wzbogacanie uranu do 60 proc.
 - [https://www.bankier.pl/wiadomosc/Iran-rozpoczal-wzbogacanie-uranu-do-60-proc-8443804.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Iran-rozpoczal-wzbogacanie-uranu-do-60-proc-8443804.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 09:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/c/1131c825c1a997-945-567-16-0-3235-1941.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W podziemnych zakładach Fordo w środkowym Iranie rozpoczęto wzbogacanie uranu do 60 proc. w odpowiedzi na rezolucję Międzynarodowej Agencji Energii Atomowej (MAEA), wzywającą Iran do większej współpracy - podał we wtorek Reuters, powołując się na irańską agencję SNN.</p>

## Rekordowy spadek realnych płac. Inflacja pożera podwyżki
 - [https://www.bankier.pl/wiadomosc/Przecietne-wynagrodzenie-i-zatrudnienie-pazdziernik-2022-8443773.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przecietne-wynagrodzenie-i-zatrudnienie-pazdziernik-2022-8443773.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 09:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/c/f1c95820b677fa-948-568-0-48-1772-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nominalnie „średnia krajowa” w październiku była o
kilkanaście procent wyższa niż rok wcześniej. Lecz po uwzględnieniu inflacji odnotowaliśmy rekordowy realny spadek wynagrodzeń w sektorze przedsiębiorstw.</p>

## Patkowski: Na ten moment możemy nie zakładać recesji
 - [https://www.bankier.pl/wiadomosc/Patkowski-Wzrost-PKB-Polski-w-2023-roku-moze-wyniesc-1-proc-lub-powyzej-8443795.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Patkowski-Wzrost-PKB-Polski-w-2023-roku-moze-wyniesc-1-proc-lub-powyzej-8443795.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 09:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/7/be496293649b1b-948-568-0-0-2987-1792.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wzrost PKB Polski w 2023 r. może wynieść 1 proc. lub powyżej 1 proc. - powiedział w Studiu PAP wiceminister finansów, Piotr Patkowski.</p>

## Będzie kolejna edycja programu "Mój prąd". Znamy datę
 - [https://www.bankier.pl/wiadomosc/Bedzie-kolejna-edycja-programu-Moj-prad-Znamy-date-8443772.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bedzie-kolejna-edycja-programu-Moj-prad-Znamy-date-8443772.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 08:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/9/74c620a92020e1-948-567-0-42-980-587.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W grudniu ruszy kolejna edycja programu wsparcia mikroinstalacji "Mój Prąd" - poinformowała minister klimatu i środowiska Anna Moskwa.</p>

## Złoty przestał się umacniać. Dolar odrabia straty
 - [https://www.bankier.pl/wiadomosc/Zloty-przestal-sie-umacniac-Dolar-odrabia-straty-8443763.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zloty-przestal-sie-umacniac-Dolar-odrabia-straty-8443763.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 08:52:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/a/0e888407c97a1f-948-568-4-95-1727-1036.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kurs euro nie przełamał poziomów wsparcia i zaczął korygować
jesienne spadki. Na rzecz słabszego złotego działa umocnienie dolara
amerykańskiego.</p>

## Allegro nie poddaje się inflacji. Spółka wycofuje się ze wcześniejszych zapowiedzi
 - [https://www.bankier.pl/wiadomosc/Zmiany-w-Allegro-Smart-Ile-kosztuje-ceny-dostaw-8443741.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zmiany-w-Allegro-Smart-Ile-kosztuje-ceny-dostaw-8443741.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 08:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/4/7315d8b38b2ca4-948-568-0-25-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Allegro poinformowało na początku listopada, że usługa Allegro Smart!
 będzie droższa i wzrośnie wartość minimalna zamówień z darmową 
przesyłką. Teraz spółka wycofawała się z jednej zmiany, która miała 
wejść w życie - klauzuli waloryzacyjnej.</p>

## Disney ma nowego szefa. Stery przejmuje Bob Iger
 - [https://www.bankier.pl/wiadomosc/Disney-zmienia-szefa-Na-etat-CEO-wraca-Bob-Iger-8443716.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Disney-zmienia-szefa-Na-etat-CEO-wraca-Bob-Iger-8443716.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 08:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/c/3b39f3d643cf43-948-568-0-245-1750-1049.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Disney ma nowego-starego szefa. Za stery The Walt Disney Company wraca Robert Iger, który z końcem poprzedniego roku przeszedł na emeryturę. Iger zastąpi na stanowisku prezesa zarządu Boba Chapka i przeprowadzi firmę przez "coraz bardziej złożony okres transformację branży" - mówi przewodnicząca zarządu Disneya.</p>

## Rząd szuka pieniędzy. Jedno ze źródeł wysycha
 - [https://www.bankier.pl/wiadomosc/Rzad-szuka-pieniedzy-Jedno-ze-zrodel-wysycha-8443724.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-szuka-pieniedzy-Jedno-ze-zrodel-wysycha-8443724.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 08:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/0/50a224a2b79f9d-948-568-30-157-2970-1781.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Raptem 850 mln zł netto pozyskało we wrześniu Ministerstwo Finansów ze 
sprzedaży obligacji oszczędnościowych. Papiery detaliczne przestały być 
istotnym źródłem finansowania budżetu państwa.</p>

## Polska nie wpuści Ławrowa na szczyt OBWE w Łodzi. Wiceszef MSZ tłumaczy
 - [https://www.bankier.pl/wiadomosc/Polska-nie-wpusci-Lawrowa-na-szczyt-OBWE-w-Lodzi-Wiceszef-MSZ-tlumaczy-8443707.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-nie-wpusci-Lawrowa-na-szczyt-OBWE-w-Lodzi-Wiceszef-MSZ-tlumaczy-8443707.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 07:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/8/2fc8f2cab2146a-948-568-5-46-2042-1225.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rosję na szczycie OBWE będzie reprezentował jej stały przedstawiciel przy tej organizacji; czym innym jest obecność ambasadora, a czym innym szefa MSZ, postaci tak kontrowersyjnej jak Siergiej Ławrow - powiedział wiceszef MSZ Marcin Przydacz.</p>

## Pyszne.pl ze związkiem zawodowym jako pierwsza firma w sektorze. Dostawcy jedzenia walczą o swoje prawa
 - [https://www.bankier.pl/wiadomosc/Zwiazek-zawodowy-w-Pyszne-pl-8443679.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zwiazek-zawodowy-w-Pyszne-pl-8443679.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 07:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/5/eb14e02c01891c-948-568-0-101-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pyszne.pl, jako pierwsz firma w tym sektorze, utworzyła związek zawodowy. "To przecieranie szlaków w Europie i poza granicami naszego 
kontynentu wśród pracowników platformowych" - komentuje Ogólnopolskie Porozumienie Związków Zawodowych.</p>

## Belgowie mogą wybrać 4-dniowy tydzień pracy. Ale i tak przepracują blisko 40 w tygodniu
 - [https://www.bankier.pl/wiadomosc/Belgowie-moga-wybrac-4-dniowy-tydzien-pracy-Ale-i-tak-przepracuja-blisko-40-w-tygodniu-8443695.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Belgowie-moga-wybrac-4-dniowy-tydzien-pracy-Ale-i-tak-przepracuja-blisko-40-w-tygodniu-8443695.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 07:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/7/2068afdc54681b-948-568-0-91-1672-1003.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rząd Belgii oficjalnie dał obywatelom wybór, czy chcą pracować cztery dni w tygodniu czy pięć, jednak zgodnie z regulacją, która weszła w życie w poniedziałek, liczba godzin pracy niezależnie od wybranej opcji niemal się nie zmieni - poinformował portal Euronews.</p>

## W skradzionej torbie miało być złoto po dziadku. Policja znalazła narkotyki
 - [https://www.bankier.pl/wiadomosc/W-skradzionej-torbie-mialo-byc-zloto-po-dziadku-Policja-znalazla-narkotyki-8443662.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-skradzionej-torbie-mialo-byc-zloto-po-dziadku-Policja-znalazla-narkotyki-8443662.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 06:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/e/50b4fcdacfda77-948-568-4-4-1512-907.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Policjanci z warszawskiej Woli prowadzili sprawę napaści, podczas której miało zostać skradzione złoto. Jednak okazało się, że zamiast złota w tobie było ponad 10 kilogramów marihuany. Dodatkowo funkcjonariusze zabezpieczyli kolejne 20 kg narkotyków. Zatrzymano trzech mężczyzn.</p>

## Odwet zamiast kary. Prawnicy ostro o reformie Kodeksu karnego
 - [https://www.bankier.pl/wiadomosc/Odwet-zamiast-kary-Prawnicy-ostro-o-reformie-Kodeksu-karnego-8443650.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Odwet-zamiast-kary-Prawnicy-ostro-o-reformie-Kodeksu-karnego-8443650.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 05:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/6/9a36fb1fe46efc-948-568-11-34-4588-2753.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Eksperci krytykują nowelę prawa karnego Zbigniewa Ziobry. Decyzja w rękach prezydenta – pisze wtorkowa „Rz”.</p>

## Rośnie zadłużenie serwisów napraw. W niektórych przypadkach nawet o 600 proc.
 - [https://www.bankier.pl/wiadomosc/Rosnie-zadluzenie-serwisow-napraw-W-niektorych-przypadkach-nawet-o-600-proc-8443635.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosnie-zadluzenie-serwisow-napraw-W-niektorych-przypadkach-nawet-o-600-proc-8443635.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 05:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/f/5f2b0bb21f2cf4-948-568-62-0-1809-1085.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zadłużenie warsztatów i serwisów napraw wzrosło z ok. 58 mln zł w 2021 r. do 149 mln zł we wrześniu br. - wynika z danych Rejestru Dłużników BIG InfoMonitor. Najwyższe długi mają punkty napraw komputerów i sprzętu gospodarstwa domowego.</p>

## Ekspertka: W ostatniej dekadzie polski sektor kosmiczny imponująco się rozwinął
 - [https://www.bankier.pl/wiadomosc/Ekspertka-W-ostatniej-dekadzie-polski-sektor-kosmiczny-imponujaco-sie-rozwinal-8443632.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ekspertka-W-ostatniej-dekadzie-polski-sektor-kosmiczny-imponujaco-sie-rozwinal-8443632.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 05:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/7/c8554688d8849f-948-568-0-90-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />10 lat temu na polskim rynku było ok. 30 podmiotów związanych z działalnością kosmiczną, dziś mówimy o nawet 400 firmach, jednostkach badawczych i instytucjach naukowych - wskazała PAP dyrektor generalna Sener Polska Beatriz Pérez. Obecnie w tym sektorze pracuje w Polsce 12 tys. osób - dodała.</p>

## We wtorek GUS poda dane o płacach w październiku. PKO BP: spodziewamy się hamowania
 - [https://www.bankier.pl/wiadomosc/We-wtorek-GUS-poda-dane-o-placach-w-pazdzierniku-PKO-BP-spodziewamy-sie-hamowania-8443630.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/We-wtorek-GUS-poda-dane-o-placach-w-pazdzierniku-PKO-BP-spodziewamy-sie-hamowania-8443630.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 05:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/5/dbd305698e600d-948-567-0-42-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W październiku spodziewamy się wzrostu zatrudniania o 2,2 proc. r/r i wyhamowania wzrostu płac do 13,8 proc. - powiedział PAP główny ekonomista PKO Banku Polskiego Piotr Bujak. Dodał, że mniejsza inflacja PPI przełoży się na niższy wzrost cen na poziomie konsumenckim.</p>

## Ale Meksyk! "Efekt tequili" i mundialowa klątwa Polaków
 - [https://www.bankier.pl/wiadomosc/Ale-Meksyk-Efekt-tequili-i-mundialowa-klatwa-Polakow-8443135.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ale-Meksyk-Efekt-tequili-i-mundialowa-klatwa-Polakow-8443135.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/d/5f1d6e3483e5d6-948-568-0-135-2000-1200.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Meksyk to kraj pełen kontrastów, ekonomicznych 
wzlotów i
upadków oraz zmagający się z krwawą wojną narkotykową. Dziesiąte 
najludniejsze
państwo świata to popularna turystyczna destynacja z plażami Morza 
Karaibskiego czy piramidami Majów i Azteków. To także ojczyzna tequili, 
której efekt w latach
90. odczuwalny był nawet w Argentynie.</p>

## Korekta napłynęła na rynek najmu, choć nie wszędzie
 - [https://www.bankier.pl/wiadomosc/Ceny-ofertowe-wynajmu-mieszkan-listopad-2022-Bankier-pl-8443191.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-ofertowe-wynajmu-mieszkan-listopad-2022-Bankier-pl-8443191.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/6/f1ac79fb8a2df5-948-568-0-14-2900-1739.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po wielu miesiącach podwyżek średnich cen ofertowych najmu mieszkań październik przyniósł zmianę kierunku, w którym zaczęły podążać stawki – wynika z danych Bankier.pl udostępnionych przez serwis nieruchomości Otodom. </p>

## Projekty NFT, metaverse, tokenizacja oparta na blockchain. Zobacz piąty odcinek Akademii Blockchain
 - [https://www.bankier.pl/wiadomosc/Projekty-NFT-metaverse-tokenizacja-oparta-na-blockchain-Akademia-Blockchain-5-8430691.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Projekty-NFT-metaverse-tokenizacja-oparta-na-blockchain-Akademia-Blockchain-5-8430691.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/4/f9a242f2094a13-948-568-62-4-1792-1075.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />NFT, Metaverse - co wypada dziś wiedzieć o tych pojęciach? Jaką przyszłość mogą nam zafundować? Między innymi o tym w piątym odcinku Akademii Blockchain, edukacyjnego programu wideo dostępnego na Bankier.pl.</p>

## Ranking lokat rocznych. Najlepsza oferta da zarobić 8 proc., ale nie wszystkim
 - [https://www.bankier.pl/wiadomosc/Najlepsze-lokaty-bankowe-na-12-miesiecy-listopad-2022-Ranking-Bankier-pl-8443334.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najlepsze-lokaty-bankowe-na-12-miesiecy-listopad-2022-Ranking-Bankier-pl-8443334.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-22 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/0/a6853bceb38dd0-948-568-0-129-2475-1484.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Lokując środki na 12 miesięcy, można uzyskać oprocentowanie w wysokości do 8 proc. w skali roku. Wybór najlepszej lokaty wiąże się jednak z koniecznością spełnienia dodatkowych warunków. Najwyższa stawka na depozycie bez tzw. haczyków na ten termin 7,50 proc. w skali roku.</p>


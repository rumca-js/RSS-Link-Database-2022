# Source:China Insights, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug, language:en-US

## Scary! CCP is to impose a communal lifestyle. A planned economy is about to go full swing
 - [https://www.youtube.com/watch?v=0KY29wZD1mg](https://www.youtube.com/watch?v=0KY29wZD1mg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug
 - date published: 2022-11-22 18:45:10+00:00

On October 31st, 2022, China's Ministry of Housing and Construction and Ministry of Civil Affairs issued a joint notice requesting each city & region to select three to five communities to start a pilot project of building "a complete community." The plan is to implement the idea nationwide in two years' time. It’s to construct  "large packages" of essential services, including communal canteens. Previously, we reported that the Chinese government has been expanding supply and distribution cooperatives throughout the country. These are all signs that the planned economy version 2.0 is starting up in China after the 20th National Congress of the Chinese Communist Party ended.   
It showed that the Communist Party at that time wanted not only to implement a system of full and unrestricted public ownership in order to control the political and economic life of the entire society but also to impose a communal lifestyle, forcing its way into the private sphere and controlling the decisions of individual life.

Have questions? Do you have something to share with us about China? We want to hear from you! 

#chinainsights #chinaeconomy  #chinanews

Email: Cinsights.subscription@gmail.com
Facebook www.facebook.com/EyesOnChina.

Your support allows us to produce more high-quality videos. 
Consider donating at https://www.paypal.com/paypalme/ChinaInsights

Copyright @ China Insights 2021. Any illegal reproduction of this content in any form will result in immediate action against the person(s) concerned.


# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Badania: Coraz groźniejsze infekcje bakteryjne. Niemal osiem milionów zgonów w ciągu roku
 - [https://wydarzenia.interia.pl/zagranica/news-badania-coraz-grozniejsze-infekcje-bakteryjne-niemal-osiem-m,nId,6427479](https://wydarzenia.interia.pl/zagranica/news-badania-coraz-grozniejsze-infekcje-bakteryjne-niemal-osiem-m,nId,6427479)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2022-11-22 18:38:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-badania-coraz-grozniejsze-infekcje-bakteryjne-niemal-osiem-m,nId,6427479"><img align="left" alt="Badania: Coraz groźniejsze infekcje bakteryjne. Niemal osiem milionów zgonów w ciągu roku" src="https://i.iplsc.com/badania-coraz-grozniejsze-infekcje-bakteryjne-niemal-osiem-m/000514EYAYY2DN5S-C321.jpg" /></a>Za jedną ósmą śmierci na świecie odpowiadają infekcje bakteryjne. To druga najczęstsza przyczyna zgonów w skali całego globu - wynika z międzynarodowego badania, które przeprowadzono przy użyciu danych za 2019 rok. Wyniki opublikowano w renomowanym czasopiśmie medycznym &quot;The Lancet&quot;. Naukowcy zwracają uwagę, że istotnym problemem staje się odporność bakterii na antybiotyki.</p><br clear="all" />


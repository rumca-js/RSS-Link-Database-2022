# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "Pracowaliśmy nad tym przez miesiąc"
 - [https://eurosport.tvn24.pl/ochoa-rozszyfrowa--lewandowskiego---pracowali-my-nad-tym-przez-miesi-c-,1125807.html?source=rss](https://eurosport.tvn24.pl/ochoa-rozszyfrowa--lewandowskiego---pracowali-my-nad-tym-przez-miesi-c-,1125807.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 21:41:17+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-46evp2-ochoa-vs-lewandowski-gora-meksykanin/alternates/LANDSCAPE_1280" />
    Guillermo Ochoa bohaterem Meksyku.

## Popis mistrzów świata. Stracony gol tylko ich rozjuszył
 - [https://eurosport.tvn24.pl/popis-mistrz-w--wiata--stracony-gol-tylko-ich-rozjuszy-,1125793.html?source=rss](https://eurosport.tvn24.pl/popis-mistrz-w--wiata--stracony-gol-tylko-ich-rozjuszy-,1125793.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 21:06:33+00:00

<img alt="Popis mistrzów świata. Stracony gol tylko ich rozjuszył" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fwz4ph-fra/alternates/LANDSCAPE_1280" />
    Mistrzowie świata rozpoczęli walkę o obronę tytułu od efektownego zwycięstwa.

## Karne na mundialach zmorą Polaków. Wstydliwa statystyka
 - [https://eurosport.tvn24.pl/karne-na-mundialach-zmor--polak-w--wstydliwa-statystyka,1125767.html?source=rss](https://eurosport.tvn24.pl/karne-na-mundialach-zmor--polak-w--wstydliwa-statystyka,1125767.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 20:41:45+00:00

<img alt="Karne na mundialach zmorą Polaków. Wstydliwa statystyka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0mjx7m-mid-epa10321021-6232365/alternates/LANDSCAPE_1280" />
    Niewykorzystany karny Roberta Lewandowskiego nie umknął statystykom.

## "Lewandowski poskromiony, stał się bohaterem tragicznym"
 - [https://eurosport.tvn24.pl/-lewandowski-poskromiony--sta--si--bohaterem-tragicznym-,1125784.html?source=rss](https://eurosport.tvn24.pl/-lewandowski-poskromiony--sta--si--bohaterem-tragicznym-,1125784.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 20:06:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-39a3oo-polska-zremisowala-z-meksykiem-00-6232323/alternates/LANDSCAPE_1280" />
    Inaczej być nie mogło, Robert Lewandowski na ustach europejskich mediów po pierwszym meczu Polaków na mundialu.

## Szczęsny: przez cały mecz mieliśmy kontrolę
 - [https://eurosport.tvn24.pl/szcz-sny--przez-ca-y-mecz-mieli-my-kontrol-,1125787.html?source=rss](https://eurosport.tvn24.pl/szcz-sny--przez-ca-y-mecz-mieli-my-kontrol-,1125787.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 19:56:39+00:00

<img alt="Szczęsny: przez cały mecz mieliśmy kontrolę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vkj5hs-szczesny/alternates/LANDSCAPE_1280" />
    Skomentował remis z Meksykiem.

## Lewandowski przeprasza
 - [https://eurosport.tvn24.pl/lewandowski-o-przestrzelonym-karnym---szkoda--przepraszam-,1125774.html?source=rss](https://eurosport.tvn24.pl/lewandowski-o-przestrzelonym-karnym---szkoda--przepraszam-,1125774.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 19:38:41+00:00

<img alt="Lewandowski przeprasza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cd4v5r-lewandowski-6232306/alternates/LANDSCAPE_1280" />
    Robert Lewandowski nie mógł być zadowolony po meczu Polski z Meksykiem.

## Lewandowski przeprasza
 - [https://eurosport.tvn24.pl/lewandowski-o-zmarnowanym-karnym---szkoda--przepraszam-,1125774.html?source=rss](https://eurosport.tvn24.pl/lewandowski-o-zmarnowanym-karnym---szkoda--przepraszam-,1125774.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 19:38:41+00:00

<img alt="Lewandowski przeprasza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-18wms5-lewandowski-6232306/alternates/LANDSCAPE_1280" />
    Robert Lewandowski nie mógł być zadowolony po meczu Polski z Meksykiem.

## Rosja w regionie Arktyki. "Mamy do czynienia z jawnym, bardzo widocznym działaniem"
 - [https://fakty.tvn24.pl/rosja-zwi-ksza-aktywno---w-regionie-arktyki---mamy-do-czynienia-z-jawnym--bardzo-widocznym-dzia-aniem-,1125796.html?source=rss](https://fakty.tvn24.pl/rosja-zwi-ksza-aktywno---w-regionie-arktyki---mamy-do-czynienia-z-jawnym--bardzo-widocznym-dzia-aniem-,1125796.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 19:12:00+00:00

<img alt="Rosja w regionie Arktyki. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-02hsxq-rosja-zwieksza-aktywnosc-w-regionie-arktyki-mamy-do-czynienia-z-jawnym-bardzo-widocznym-dzialaniem/alternates/LANDSCAPE_1280" />
    Materiał "Faktów o Świecie" TVN24 BiS.

## Potrafią podejść tak blisko, że słyszą rozmowy. CNN o elitarnym ukraińskim oddziale
 - [https://fakty.tvn24.pl/odpowiadaj--za-identyfikacj--i-likwidacj--wroga--ekipa-cnn-mog-a-obserwowa--prac--elitarnego-ukrai-skiego-oddzia-u,1125799.html?source=rss](https://fakty.tvn24.pl/odpowiadaj--za-identyfikacj--i-likwidacj--wroga--ekipa-cnn-mog-a-obserwowa--prac--elitarnego-ukrai-skiego-oddzia-u,1125799.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 19:11:00+00:00

<img alt="Potrafią podejść tak blisko, że słyszą rozmowy. CNN o elitarnym ukraińskim oddziale" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e5r3fk-odpowiadaja-za-identyfikacje-i-likwidacje-wroga-ekipa-cnn-mogla-obserwowac-prace-elitarnego-ukrainskiego-oddzialu/alternates/LANDSCAPE_1280" />
    Odpowiada za identyfikację i likwidację wroga.

## Obrońcy tytułu wchodzą do gry
 - [https://eurosport.tvn24.pl/mundial-2022--francja---australia--wynik-i-relacja-na--ywo,1125738.html?source=rss](https://eurosport.tvn24.pl/mundial-2022--francja---australia--wynik-i-relacja-na--ywo,1125738.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 18:52:00+00:00

<img alt="Obrońcy tytułu wchodzą do gry " src="https://tvn24.pl/najnowsze/cdn-zdjecie-i4shbe-francja-australia/alternates/LANDSCAPE_1280" />
    Francja - Australia w kolejnym meczu mundialu.

## Michniewicz: nie mam pretensji do Roberta
 - [https://eurosport.tvn24.pl/michniewicz--nie-mam-pretensji-do-roberta,1125739.html?source=rss](https://eurosport.tvn24.pl/michniewicz--nie-mam-pretensji-do-roberta,1125739.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 18:18:57+00:00

<img alt="Michniewicz: nie mam pretensji do Roberta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lim6z4-michniewicz/alternates/LANDSCAPE_1280" />
    Skomentował remis Polaków w pierwszym meczu mistrzostw świata.

## Manchester United pożegnał Ronaldo
 - [https://eurosport.tvn24.pl/rozstanie-w-trakcie-mundialu--manchester-united-po-egna--ronaldo,1125736.html?source=rss](https://eurosport.tvn24.pl/rozstanie-w-trakcie-mundialu--manchester-united-po-egna--ronaldo,1125736.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 18:12:58+00:00

<img alt="Manchester United pożegnał Ronaldo" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h6tm4x-cristiano-ronaldo-nie-jest-juz-pilkarzem-mu/alternates/LANDSCAPE_1280" />
    Stało się. Portugalczyk odchodzi.

## Oceny Polaków po meczu z Meksykiem. Pozostał wielki niedosyt
 - [https://eurosport.tvn24.pl/ocenili-my-polak-w-po-meczu-z-meksykiem--pozosta--wielki-niedosyt,1125733.html?source=rss](https://eurosport.tvn24.pl/ocenili-my-polak-w-po-meczu-z-meksykiem--pozosta--wielki-niedosyt,1125733.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 18:08:22+00:00

<img alt="Oceny Polaków po meczu z Meksykiem. Pozostał wielki niedosyt" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gw4lvy-polska-w-meczu-z-meksykiem/alternates/LANDSCAPE_1280" />
    Biało-Czerwoni bezbramkowo zremisowali w swoim pierwszym meczu mistrzostw świata w Katarze.

## Zmarnowany karny Lewandowskiego. Przykry pierwszy mecz Polaków w Katarze
 - [https://eurosport.tvn24.pl/zmarnowany-karny-lewandowskiego--przykry-pierwszy-mecz-polak-w-w-katarze,1125694.html?source=rss](https://eurosport.tvn24.pl/zmarnowany-karny-lewandowskiego--przykry-pierwszy-mecz-polak-w-w-katarze,1125694.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 17:57:00+00:00

<img alt="Zmarnowany karny Lewandowskiego. Przykry pierwszy mecz Polaków w Katarze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zaicw5-lewy-6232190/alternates/LANDSCAPE_1280" />
    Piłkarska reprezentacja Polski po bardzo nerwowym meczu zremisowała z Meksykiem 0:0 w swoim pierwszym występie na mistrzostwach świata w Katarze. Biało-Czerwoni skupili się w tym spotkaniu przede wszystkim na destrukcji, a jedyną, kapitalną okazję na gola zmarnował Robert Lewandowski.

## Rzut karny to jego specjalność. Lewandowski tym razem zawiódł
 - [https://eurosport.tvn24.pl/rzut-karny-to-jego-specjalno----lewandowski-tym-razem-zawi-d-,1125705.html?source=rss](https://eurosport.tvn24.pl/rzut-karny-to-jego-specjalno----lewandowski-tym-razem-zawi-d-,1125705.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 17:40:28+00:00

<img alt="Rzut karny to jego specjalność. Lewandowski tym razem zawiódł" src="https://tvn24.pl/najnowsze/cdn-zdjecie-p9sgp9-lewandowski/alternates/LANDSCAPE_1280" />
    Robert Lewandowski niezwykle rzadko myli się, strzelając z jedenastu metrów. Niestety, ten gorszy moment przytrafił mu się w trakcie spotkania z Meksykiem.

## VAR wyciągnął pomocną dłoń. Polacy nie skorzystali
 - [https://eurosport.tvn24.pl/var-wyci-gn---pomocn--d-o---polacy-nie-skorzystali,1125730.html?source=rss](https://eurosport.tvn24.pl/var-wyci-gn---pomocn--d-o---polacy-nie-skorzystali,1125730.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 17:25:45+00:00

<img alt="VAR wyciągnął pomocną dłoń. Polacy nie skorzystali" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cb9yw7-sedzia-posilkowal-sie-wideoweryfikacja/alternates/LANDSCAPE_1280" />
    Wideoweryfikacja, tak przydatna w ostatnich latach na futbolowych boiskach, mogła pomóc reprezentacji Polski w meczu z Meksykiem na mundialu.

## Jedna "klątwa" zdjęta. Pierwszy taki przypadek polskiej reprezentacji w XXI wieku
 - [https://eurosport.tvn24.pl/jedna--kl-twa--zdj-ta--pierwszy-taki-przypadek-polskiej-reprezentacji-w-xxi-wieku,1125685.html?source=rss](https://eurosport.tvn24.pl/jedna--kl-twa--zdj-ta--pierwszy-taki-przypadek-polskiej-reprezentacji-w-xxi-wieku,1125685.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 17:11:00+00:00

<img alt="Jedna " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1mvenv-polacy-nie-stracili-gola-w-pierwszej-polowie-meczu-z-meksykiem/alternates/LANDSCAPE_1280" />
    Reprezentacja Polski remisowała bezbramkowo po pierwszej połowie spotkania z Meksykiem na mistrzostwach świata w Katarze.

## Messi skomentował wpadkę Argentyny
 - [https://eurosport.tvn24.pl/messi-skomentowa--wpadk--argentyny,1125711.html?source=rss](https://eurosport.tvn24.pl/messi-skomentowa--wpadk--argentyny,1125711.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 17:00:15+00:00

<img alt="Messi skomentował wpadkę Argentyny" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5lt30w-leo-messi-i-argentyna-pokonani/alternates/LANDSCAPE_1280" />
    W jej pierwszym meczu mundialu z Arabią Saudyjską (1:2).

## Przytomne zachowanie Szczęsnego. Uchronił nas przed stratą gola
 - [https://eurosport.tvn24.pl/przytomne-zachowanie-szcz-snego--uchroni--nas-przed-strat--gola,1125718.html?source=rss](https://eurosport.tvn24.pl/przytomne-zachowanie-szcz-snego--uchroni--nas-przed-strat--gola,1125718.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 16:40:58+00:00

<img alt="Przytomne zachowanie Szczęsnego. Uchronił nas przed stratą gola" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tw4n08-szczesny/alternates/LANDSCAPE_1280" />
    Meksyk w meczu z Polską na mistrzostwach świata pokazał, że potrafi być groźny.

## Sensacji na mundialu było wiele, ale to pierwsza taka od 72 lat
 - [https://eurosport.tvn24.pl/sensacji-na-mundialu-by-o-wiele--ale-to-pierwsza-taka-od-72-lat,1125702.html?source=rss](https://eurosport.tvn24.pl/sensacji-na-mundialu-by-o-wiele--ale-to-pierwsza-taka-od-72-lat,1125702.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 15:52:16+00:00

<img alt="Sensacji na mundialu było wiele, ale to pierwsza taka od 72 lat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-iiu8uc-sensacji-w-pilkarskich-mistrzostwach-swiata-nie-brakowalo/alternates/LANDSCAPE_1280" />
    Nie tak Argentyńczycy chcieli trafić na czołówki światowych mediów.

## Gramy z Meksykiem. Czas spełnić marzenia
 - [https://eurosport.tvn24.pl/polska---meksyk-na-mundialu-w-katarze--wynik-meczu-i-relacja-na--ywo,1125693.html?source=rss](https://eurosport.tvn24.pl/polska---meksyk-na-mundialu-w-katarze--wynik-meczu-i-relacja-na--ywo,1125693.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 15:40:00+00:00

<img alt="Gramy z Meksykiem. Czas spełnić marzenia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kfvcnd-polska-meksyk-relacja/alternates/LANDSCAPE_1280" />
    Na ten mecz grupy C mistrzostw świata w Katarze czekano od dawna.

## Słupek i nieuznany gol. Pierwszy taki mecz w Katarze
 - [https://eurosport.tvn24.pl/mundial-2022--s-upek-i-nieuznany-gol--pierwszy-taki-mecz-w-katarze,1125666.html?source=rss](https://eurosport.tvn24.pl/mundial-2022--s-upek-i-nieuznany-gol--pierwszy-taki-mecz-w-katarze,1125666.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 15:02:09+00:00

<img alt="Słupek i nieuznany gol. Pierwszy taki mecz w Katarze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-noypfp-joachim-andersen-i-issam-jebali-w-walce-o-pilke/alternates/LANDSCAPE_1280" />
    Mecz Danii i Tunezji zainaugurował rozgrywki w grupie D na mistrzostwach świata w Katarze.

## Smutek w szatni Argentyny. "To bardzo boli"
 - [https://eurosport.tvn24.pl/smutek-w-szatni-argentyny---to-bardzo-boli-,1125677.html?source=rss](https://eurosport.tvn24.pl/smutek-w-szatni-argentyny---to-bardzo-boli-,1125677.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 14:55:41+00:00

<img alt="Smutek w szatni Argentyny. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-u3ksrn-lautaro-martinez-w-meczu-argentyna-arabia-saudyjska/alternates/LANDSCAPE_1280" />
    Mają czego żałować.

## Skład Polaków na Meksyk. Jest zaskoczenie
 - [https://eurosport.tvn24.pl/mundial-2022--polska---meksyk--oficjalny-sk-ad-polak-w-na-mecz-mistrzostw--wiata,1125673.html?source=rss](https://eurosport.tvn24.pl/mundial-2022--polska---meksyk--oficjalny-sk-ad-polak-w-na-mecz-mistrzostw--wiata,1125673.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 14:29:41+00:00

<img alt="Skład Polaków na Meksyk. Jest zaskoczenie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8lckxm-sklad-polakow-6231911/alternates/LANDSCAPE_1280" />
    Poznaliśmy wyjściową jedenastkę Biało-Czerwonych na ich pierwszy mecz mistrzostw świata.

## Argentyńczycy przybici po "jednej z największych sensacji w historii"
 - [https://eurosport.tvn24.pl/argenty-czycy-przybici-po--jednej-z-najwi-kszych-sensacji-w-historii-,1125661.html?source=rss](https://eurosport.tvn24.pl/argenty-czycy-przybici-po--jednej-z-najwi-kszych-sensacji-w-historii-,1125661.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 14:22:59+00:00

<img alt="Argentyńczycy przybici po " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qnwhp2-argentyna-w-szoku-po-sensacyjnej-porazce/alternates/LANDSCAPE_1280" />
    Niedowierzający Leo Messi trzymający się za głowę - taki obrazek dominuje w argentyńskich mediach.

## Fatalne zderzenie obrońcy z bramkarzem
 - [https://eurosport.tvn24.pl/mundial-2022--fatalne-zderzenie-obro-cy-z-bramkarzem--saudyjczyk-opu-ci--muraw--na-noszach,1125655.html?source=rss](https://eurosport.tvn24.pl/mundial-2022--fatalne-zderzenie-obro-cy-z-bramkarzem--saudyjczyk-opu-ci--muraw--na-noszach,1125655.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 13:52:00+00:00

<img alt="Fatalne zderzenie obrońcy z bramkarzem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n30b3m-zderzenie-zawodnika-arabii-saudyjskiej/alternates/LANDSCAPE_1280" />
    Saudyjczyk opuścił murawę na noszach.

## Frekwencja wyższa niż pojemność stadionów. Absurd goni absurd w Katarze
 - [https://eurosport.tvn24.pl/frekwencja-wy-sza-ni--pojemno----absurd-goni-absurd-w-katarze,1125623.html?source=rss](https://eurosport.tvn24.pl/frekwencja-wy-sza-ni--pojemno----absurd-goni-absurd-w-katarze,1125623.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 13:22:00+00:00

<img alt="Frekwencja wyższa niż pojemność stadionów. Absurd goni absurd w Katarze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-z0up31-wolne-miejsca-podczas-meczu-ms-pomiedzy-katarem-a-ekwadorem/alternates/LANDSCAPE_1280" />
    Kontrowersje wokół mistrzostw świata.

## Piłkarskie szachy na otwarcie grupy D
 - [https://eurosport.tvn24.pl/mundial-2022--dania---tunezja--wynik-i-relacja-na--ywo,1125659.html?source=rss](https://eurosport.tvn24.pl/mundial-2022--dania---tunezja--wynik-i-relacja-na--ywo,1125659.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 13:00:00+00:00

<img alt="Piłkarskie szachy na otwarcie grupy D" src="https://tvn24.pl/najnowsze/cdn-zdjecie-znw6ci-dania-rozpoczyna-mundial-6231699/alternates/LANDSCAPE_1280" />
    Wynik i relacja na żywo w eurosport.pl

## Sensacja to mało powiedziane. Argentyna pokonana przez Arabię Saudyjską
 - [https://eurosport.tvn24.pl/sensacja-to-ma-o-powiedziane--argentyna-pokonana-przez-arabi--saudyjsk-,1125651.html?source=rss](https://eurosport.tvn24.pl/sensacja-to-ma-o-powiedziane--argentyna-pokonana-przez-arabi--saudyjsk-,1125651.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 12:08:00+00:00

<img alt="Sensacja to mało powiedziane. Argentyna pokonana przez Arabię Saudyjską" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tph9py-argentyna-grala-z-arabia-saudyjska-6231605/alternates/LANDSCAPE_1280" />
    Mundial 2022. Trzeci dzień piłkarskich mistrzostw świata i pierwsza gigantyczna niespodzianka. Kreowana na jednego z faworytów turnieju Argentyna przegrała w Lusail z Arabią Saudyjską 1:2. W popołudniowym meczu grupy C Polska zmierzy się z Meksykiem.

## Do awansu mogą wystarczyć nawet dwa punkty. Jak to możliwe? Scenariusze
 - [https://eurosport.tvn24.pl/mundial-2022--z-naszej-grupy-mo-na-awansowa--nawet-z-dwoma-punktami--scenariusze-dla-polski,1125505.html?source=rss](https://eurosport.tvn24.pl/mundial-2022--z-naszej-grupy-mo-na-awansowa--nawet-z-dwoma-punktami--scenariusze-dla-polski,1125505.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 11:01:00+00:00

<img alt="Do awansu mogą wystarczyć nawet dwa punkty. Jak to możliwe? Scenariusze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zyp1fx-polska/alternates/LANDSCAPE_1280" />
    Wyliczanie matematycznych szans na awans z grupy to polska specjalność.

## Messi dołączył do legend
 - [https://eurosport.tvn24.pl/mundial-2022--messi-rozpocz---strzelanie-w-katarze--dzi-ki-bramce-do--czy--do-legend,1125647.html?source=rss](https://eurosport.tvn24.pl/mundial-2022--messi-rozpocz---strzelanie-w-katarze--dzi-ki-bramce-do--czy--do-legend,1125647.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 10:53:00+00:00

<img alt="Messi dołączył do legend" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3zmqel-lionel-messi-strzelil-gola-w-meczu-argentyna-arabia-saudyjska/alternates/LANDSCAPE_1280" />
    Lionel Messi błyskawicznie otworzył strzeleckie konto na mistrzostwach świata w Katarze.

## Zagadkowe zdjęcia reprezentacji Walii
 - [https://eurosport.tvn24.pl/mundial-2022--zagadkowe-zdj-cia-reprezentacji-walii--nie-ma-w-tym-wielkiej-historii,1125626.html?source=rss](https://eurosport.tvn24.pl/mundial-2022--zagadkowe-zdj-cia-reprezentacji-walii--nie-ma-w-tym-wielkiej-historii,1125626.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 10:45:00+00:00

<img alt="Zagadkowe zdjęcia reprezentacji Walii" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9dkbrd-reprezentacja-walii-przed-meczem-z-usa/alternates/LANDSCAPE_1280" />
    Jaka kryje się za tym historia?

## Wystarczyły dwa dni i rekord mundialu pobity
 - [https://eurosport.tvn24.pl/wystarczy-y-dwa-dni-i-rekord-mundialu-pobity,1125620.html?source=rss](https://eurosport.tvn24.pl/wystarczy-y-dwa-dni-i-rekord-mundialu-pobity,1125620.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 10:13:00+00:00

<img alt="Wystarczyły dwa dni i rekord mundialu pobity" src="https://tvn24.pl/najnowsze/cdn-zdjecie-npk9il-mecz-anglikow-z-iranem-z-kilku-powodow-okazal-sie-rekordowy/alternates/LANDSCAPE_1280" />
    Mimo że w fazie grupowej mistrzostw świata nie ma mowy o dogrywkach.

## Grają grupowi rywale Polaków
 - [https://eurosport.tvn24.pl/argentyna---arabia-saudyjska--wynik-na--ywo-i-relacja,1125644.html?source=rss](https://eurosport.tvn24.pl/argentyna---arabia-saudyjska--wynik-na--ywo-i-relacja,1125644.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 09:59:00+00:00

<img alt="Grają grupowi rywale Polaków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oz363h-argentynczycy-zaczynaja-mundial/alternates/LANDSCAPE_1280" />
    Relacja na żywo w eurosport.pl.

## Kobiety w obsadzie meczu Polaków. Jedna z nich z doświadczeniem w Lidze Mistrzów
 - [https://eurosport.tvn24.pl/mundial-2022--kobiety-w-obsadzie-meczu-polak-w--jedna-z-nich-z-do-wiadczeniem-w-lidze-mistrz-w,1125640.html?source=rss](https://eurosport.tvn24.pl/mundial-2022--kobiety-w-obsadzie-meczu-polak-w--jedna-z-nich-z-do-wiadczeniem-w-lidze-mistrz-w,1125640.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 09:51:00+00:00

<img alt="Kobiety w obsadzie meczu Polaków. Jedna z nich z doświadczeniem w Lidze Mistrzów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qr4a8z-stephanie-frappart-bedzie-pelnic-role-sedzi-technicznej-w-meczu-polska-meksyk/alternates/LANDSCAPE_1280" />
    To Francuzka Stephanie Frappart.

## Lato ostrzega. "To nie są frajerzy, proszę zapamiętać te słowa"
 - [https://eurosport.tvn24.pl/lato-zakocha--si--w-meksyku--strzela--argentynie---o--prezencik-i-pyk-do-pustej-bramki-na-1-0-,1125493.html?source=rss](https://eurosport.tvn24.pl/lato-zakocha--si--w-meksyku--strzela--argentynie---o--prezencik-i-pyk-do-pustej-bramki-na-1-0-,1125493.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 09:10:00+00:00

<img alt="Lato ostrzega. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-0c78b2-lato/alternates/LANDSCAPE_1280" />
    Grzegorz Lato w rozmowie z Rafałem Kazimierczakiem.

## Polska domem Meksykanina. "Dla nas są trzy świętości: matka, Matka Boska i futbol"
 - [https://eurosport.tvn24.pl/polska-domem-meksykanina---dla-nas-s--trzy--wi-to-ci--matka--matka-boska-i-futbol-,1124775.html?source=rss](https://eurosport.tvn24.pl/polska-domem-meksykanina---dla-nas-s--trzy--wi-to-ci--matka--matka-boska-i-futbol-,1124775.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 08:53:00+00:00

<img alt="Polska domem Meksykanina. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ayp14z-huerta-beltran-na-meczu-meksyk-wlochy-podczas-ms-u-20-w-gdyni/alternates/LANDSCAPE_1280" />
    Mecz Polski z Meksykiem jest dla niego spełnieniem marzeń.

## Piękny gest Anglika po strzelonym golu. Obiecał to przed mundialem
 - [https://eurosport.tvn24.pl/pi-kny-gest-anglika-po-strzelonym-golu--obieca--to-przed-mundialem,1125573.html?source=rss](https://eurosport.tvn24.pl/pi-kny-gest-anglika-po-strzelonym-golu--obieca--to-przed-mundialem,1125573.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 08:02:00+00:00

<img alt="Piękny gest Anglika po strzelonym golu. Obiecał to przed mundialem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-o8ifnh-jack-grealish-zaprezentowal-specjalna-cieszynke/alternates/LANDSCAPE_1280" />
    Jack Grealish spełnił obietnicę.

## Jak zagrają Polska i Meksyk? Przewidywane składy
 - [https://eurosport.tvn24.pl/mundial-2022--jak-zagraj--polska-i-meksyk--przewidywane-sk-ady,1125577.html?source=rss](https://eurosport.tvn24.pl/mundial-2022--jak-zagraj--polska-i-meksyk--przewidywane-sk-ady,1125577.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 07:47:00+00:00

<img alt="Jak zagrają Polska i Meksyk? Przewidywane składy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-amdp1g-reprezentacja-polski-podczas-treningu-w-katarze/alternates/LANDSCAPE_1280" />
    To już dziś.

## Trzeci dzień mistrzostw świata. Kto zagra w Katarze?
 - [https://eurosport.tvn24.pl/mundial-2022--trzeci-dzie--mistrzostw--wiata--kto-dzi--zagra-w-katarze-,1125531.html?source=rss](https://eurosport.tvn24.pl/mundial-2022--trzeci-dzie--mistrzostw--wiata--kto-dzi--zagra-w-katarze-,1125531.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 05:23:48+00:00

<img alt="Trzeci dzień mistrzostw świata. Kto zagra w Katarze?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-istpih-rusza-rywalizacja-w-mundialowej-grupie-c/alternates/LANDSCAPE_1280" />
    Piłkarskie mistrzostwa świata w Katarze rozkręcają się na całego.

## "Są mniejszością językową, mają własną historię, kulturę i sposób myślenia". Walczą z wykluczeniem
 - [https://tvn24.pl/polska/glusi-walcza-ze-stereotypami-i-wykluczeniem-wykluczenie-gluchych-w-polsce-6230710?source=rss](https://tvn24.pl/polska/glusi-walcza-ze-stereotypami-i-wykluczeniem-wykluczenie-gluchych-w-polsce-6230710?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 05:20:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-p7xdg9-gluchy-shutterstock2107085402-6230658/alternates/LANDSCAPE_1280" />
    Osoby głuche w Polsce. Materiał magazynu "Polska i Świat".

## Polacy zaczynają mundial
 - [https://eurosport.tvn24.pl/w-ko-cu-wygra--na-inauguracj---polacy-zaczynaj--mundial,1125588.html?source=rss](https://eurosport.tvn24.pl/w-ko-cu-wygra--na-inauguracj---polacy-zaczynaj--mundial,1125588.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-22 05:13:00+00:00

<img alt="Polacy zaczynają mundial" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0ieu5y-polacy-zaczynaja-mundial-meczem-z-meksykiem/alternates/LANDSCAPE_1280" />
    W końcu wygrać na inaugurację.


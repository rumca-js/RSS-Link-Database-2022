# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## 10 Actually Useful Tech Gadgets Under $50 - (You Didn't Know You Needed)
 - [https://www.youtube.com/watch?v=gwREJr4lu8I](https://www.youtube.com/watch?v=gwREJr4lu8I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2022-11-23 00:00:00+00:00

Did you find any of these useful? 🤔

Amazon Product Links (Affiliate):
• Alex Tech Cable Sleeves ⇨ https://amzn.to/3V0A9bn
• AirSquares Cleaning Putty ⇨ https://amzn.to/3V1FKhR
• Precision Cleaning Swabs ⇨ https://amzn.to/3i8DsyX
• ZTS-Mini Battery Tester ⇨ https://amzn.to/3i7n7dP
• Digital USB Microscope ⇨ https://amzn.to/3EBhFaN
• XPOWER AC Air Duster ⇨ https://amzn.to/3GGgJo1
• Sunpollo Battery Air Duster ⇨ https://amzn.to/3i900iO
• Kingsdun Tweezers ⇨ https://amzn.to/3GKcUy7
• Glorious Gaming Wrist Rest ⇨ https://amzn.to/3i7nhSt
• 3M Foot Rest ⇨ https://amzn.to/3i5xtuD
• Stealtho Caster Wheels ⇨ https://amzn.to/3V5H0k0

Note: The links above are Amazon affiliate links, which means I'll probably get a small (usually ~1-2%) commission that helps support the channel if you decide to buy the item. The commission does not come out of your pocket, but rather from Amazon's.

▼ Time Stamps: ▼
0:00 - Intro
0:23 - Alex Tech Cable Sleeves
1:08 - AirSquares Cleaning Putty
2:00 - Precision Cleaning Swabs
2:26 - ZTS Pulse Load Battery Tester
4:17 - Digital USB Microscope
5:22 - XPower Corded Air Duster
6:01 - Sunpollo Battery Powered Air Duster
7:20 - Kingsdun Precision Tweezers Set
8:18 - Anti Static Bags
8:48 - Glorious Gaming Keyboard Wrist Rest
9:20 - Desk Foot Rest
10:27 - Stealtho Chair Caster Wheels

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬


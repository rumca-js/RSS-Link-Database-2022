## Syphilis in England, 2019 to 2021 - GOV.UK
 - [https://www.gov.uk/government/publications/syphilis-quarterly-data-for-england/syphilis-in-england-2019-to-2021](https://www.gov.uk/government/publications/syphilis-quarterly-data-for-england/syphilis-in-england-2019-to-2021)
 - RSS feed: https://www.gov.uk
 - date published: 2022-11-22 19:53:13+00:00

Syphilis in England, 2019 to 2021 - GOV.UK


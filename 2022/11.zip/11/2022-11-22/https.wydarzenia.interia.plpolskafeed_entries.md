# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Mundial 2022. Prezydent oglądał mecz wspólnie z żołnierzami
 - [https://wydarzenia.interia.pl/kraj/news-mundial-2022-prezydent-ogladal-mecz-wspolnie-z-zolnierzami,nId,6427223](https://wydarzenia.interia.pl/kraj/news-mundial-2022-prezydent-ogladal-mecz-wspolnie-z-zolnierzami,nId,6427223)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-11-22 16:00:58+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-mundial-2022-prezydent-ogladal-mecz-wspolnie-z-zolnierzami,nId,6427223"><img align="left" alt="Mundial 2022. Prezydent oglądał mecz wspólnie z żołnierzami" src="https://i.iplsc.com/mundial-2022-prezydent-ogladal-mecz-wspolnie-z-zolnierzami/000GDN7CPBD0WIVV-C321.jpg" /></a>Prezydent i minister obrony oglądali mecz polskiej reprezentacji wspólnie z żołnierzami. Kibicowali wraz z wojskowymi, którzy służą na Podlasiu, zabezpieczając polską granicę. Premier udał się natomiast do Węgrowa, gdzie kibicował wspólnie z młodymi sportowcami.</p><br clear="all" />

## Posypią się mandaty. Wyciekł e-mail z nowymi wytycznymi
 - [https://wydarzenia.interia.pl/news-posypia-sie-mandaty-wyciekl-e-mail-z-nowymi-wytycznymi,nId,6426957](https://wydarzenia.interia.pl/news-posypia-sie-mandaty-wyciekl-e-mail-z-nowymi-wytycznymi,nId,6426957)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-11-22 11:59:00+00:00

<p><a href="https://wydarzenia.interia.pl/news-posypia-sie-mandaty-wyciekl-e-mail-z-nowymi-wytycznymi,nId,6426957"><img align="left" alt="Posypią się mandaty. Wyciekł e-mail z nowymi wytycznymi" src="https://i.iplsc.com/posypia-sie-mandaty-wyciekl-e-mail-z-nowymi-wytycznymi/000GDL15UEETXAL4-C321.jpg" /></a>Jak ustaliła Interia, Państwowa Inspekcja Pracy domaga się od swoich inspektorów, aby wlepiali kontrolowanym przedsiębiorcom wyższe kary. &quot;Więcej mandatów i najlepiej wyższych niż 1000 zł&quot; - w korespondencji ze swoim zespołem pisze wprost jeden z łódzkich nadinspektorów. - Takie funkcjonowanie instytucji pokazuje, że państwo się psuje - uważa prof. Jacek Męcina, specjalista z zakresu prawa pracy i członek Rady Ochrony Pracy.</p><br clear="all" />

## Te zawody mogą przejść na wcześniejszą emeryturę. Pracujesz w jednym z nich?
 - [https://wydarzenia.interia.pl/kraj/news-te-zawody-moga-przejsc-na-wczesniejsza-emeryture-pracujesz-w,nId,6424989](https://wydarzenia.interia.pl/kraj/news-te-zawody-moga-przejsc-na-wczesniejsza-emeryture-pracujesz-w,nId,6424989)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-11-22 11:03:59+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-te-zawody-moga-przejsc-na-wczesniejsza-emeryture-pracujesz-w,nId,6424989"><img align="left" alt="Te zawody mogą przejść na wcześniejszą emeryturę. Pracujesz w jednym z nich?" src="https://i.iplsc.com/te-zawody-moga-przejsc-na-wczesniejsza-emeryture-pracujesz-w/000GDFY9G8UKAQWD-C321.jpg" /></a>Zasady przejścia na emeryturę w Polsce ulegały przez lata pewnym zmianom. Obecnie nie jest wymagany staż pracy do otrzymania wynagrodzenia. Liczy się wyłącznie wiek. Ile wynosi wiek emerytalny dla kobiet i mężczyzn? Czy w każdej profesji wymagania są identyczne? </p><br clear="all" />

## Teraz łatwiej wybudujesz dom. W 2023 roku szykują się duże zmiany w prawie
 - [https://wydarzenia.interia.pl/kraj/news-teraz-latwiej-wybudujesz-dom-w-2023-roku-szykuja-sie-duze-zm,nId,6419598](https://wydarzenia.interia.pl/kraj/news-teraz-latwiej-wybudujesz-dom-w-2023-roku-szykuja-sie-duze-zm,nId,6419598)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-11-22 06:08:32+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-teraz-latwiej-wybudujesz-dom-w-2023-roku-szykuja-sie-duze-zm,nId,6419598"><img align="left" alt="Teraz łatwiej wybudujesz dom. W 2023 roku szykują się duże zmiany w prawie" src="https://i.iplsc.com/teraz-latwiej-wybudujesz-dom-w-2023-roku-szykuja-sie-duze-zm/000434FP5RFSP94T-C321.jpg" /></a>W przyszłym roku w życie wchodzi nowelizacja Prawa budowalnego, a wraz z nią sporo ważnych zmian. Dotyczą one m.in. możliwości budowy domów jednorodzinnych bez pozwolenia, cyfryzacji procesu inwestycyjnego czy likwidacji niezbędnej do tej pory zgody na użytkowanie. Większość z nich zacznie obowiązywać już od 1 stycznia 2023 r.</p><br clear="all" />


# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Against Parasite Publishers: Making Journals Free
 - [https://zenodo.org/record/7212922](https://zenodo.org/record/7212922)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 23:45:12+00:00

<p>Article URL: <a href="https://zenodo.org/record/7212922">https://zenodo.org/record/7212922</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33713170">https://news.ycombinator.com/item?id=33713170</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## The Twitter Advertiser Exodus
 - [https://caterina.net/2022/11/21/the-twitter-advertiser-exodus/](https://caterina.net/2022/11/21/the-twitter-advertiser-exodus/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 23:41:32+00:00

<p>Article URL: <a href="https://caterina.net/2022/11/21/the-twitter-advertiser-exodus/">https://caterina.net/2022/11/21/the-twitter-advertiser-exodus/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33713142">https://news.ycombinator.com/item?id=33713142</a></p>
<p>Points: 28</p>
<p># Comments: 1</p>

## AP fired reporter after dangerous blunder. Slack chats reveal chaotic process
 - [https://www.semafor.com/article/11/22/2022/ap-fired-a-reporter-after-a-dangerous-blunder-slack-messages-reveal-a-chaotic-process](https://www.semafor.com/article/11/22/2022/ap-fired-a-reporter-after-a-dangerous-blunder-slack-messages-reveal-a-chaotic-process)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 23:25:54+00:00

<p>Article URL: <a href="https://www.semafor.com/article/11/22/2022/ap-fired-a-reporter-after-a-dangerous-blunder-slack-messages-reveal-a-chaotic-process">https://www.semafor.com/article/11/22/2022/ap-fired-a-reporter-after-a-dangerous-blunder-slack-messages-reveal-a-chaotic-process</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33712999">https://news.ycombinator.com/item?id=33712999</a></p>
<p>Points: 32</p>
<p># Comments: 15</p>

## LPD: Libertarian Police Department (2014)
 - [https://www.newyorker.com/humor/daily-shouts/l-p-d-libertarian-police-department](https://www.newyorker.com/humor/daily-shouts/l-p-d-libertarian-police-department)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 22:50:49+00:00

<p>Article URL: <a href="https://www.newyorker.com/humor/daily-shouts/l-p-d-libertarian-police-department">https://www.newyorker.com/humor/daily-shouts/l-p-d-libertarian-police-department</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33712685">https://news.ycombinator.com/item?id=33712685</a></p>
<p>Points: 59</p>
<p># Comments: 11</p>

## WebAssembly back end merged into GHC
 - [https://www.tweag.io/blog/2022-11-22-wasm-backend-merged-in-ghc/](https://www.tweag.io/blog/2022-11-22-wasm-backend-merged-in-ghc/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 22:31:51+00:00

<p>Article URL: <a href="https://www.tweag.io/blog/2022-11-22-wasm-backend-merged-in-ghc/">https://www.tweag.io/blog/2022-11-22-wasm-backend-merged-in-ghc/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33712490">https://news.ycombinator.com/item?id=33712490</a></p>
<p>Points: 22</p>
<p># Comments: 0</p>

## NASA Uses RISC-V Vector Spec to Soup Up Space Computers
 - [https://www.eetimes.com/nasa-uses-risc-v-vector-spec-to-soup-up-space-computers/](https://www.eetimes.com/nasa-uses-risc-v-vector-spec-to-soup-up-space-computers/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 21:47:06+00:00

<p>Article URL: <a href="https://www.eetimes.com/nasa-uses-risc-v-vector-spec-to-soup-up-space-computers/">https://www.eetimes.com/nasa-uses-risc-v-vector-spec-to-soup-up-space-computers/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33711987">https://news.ycombinator.com/item?id=33711987</a></p>
<p>Points: 24</p>
<p># Comments: 1</p>

## Show HN: Visualising real-time Sydney bus congestion with Marey charts
 - [https://jakecoppinger.com/2022/11/visualising-sydney-bus-congestion-with-marey-charts/](https://jakecoppinger.com/2022/11/visualising-sydney-bus-congestion-with-marey-charts/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 21:46:31+00:00

<p>Article URL: <a href="https://jakecoppinger.com/2022/11/visualising-sydney-bus-congestion-with-marey-charts/">https://jakecoppinger.com/2022/11/visualising-sydney-bus-congestion-with-marey-charts/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33711981">https://news.ycombinator.com/item?id=33711981</a></p>
<p>Points: 17</p>
<p># Comments: 6</p>

## Why Gratitude Is the Secret Weapon for Attracting More Opportunities
 - [https://www.exaltitude.io/blogs/why-gratitude-is-the-secret-weapon-for-attracting-more-opportunities-and-creating-positive-change](https://www.exaltitude.io/blogs/why-gratitude-is-the-secret-weapon-for-attracting-more-opportunities-and-creating-positive-change)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 21:34:37+00:00

<p>Article URL: <a href="https://www.exaltitude.io/blogs/why-gratitude-is-the-secret-weapon-for-attracting-more-opportunities-and-creating-positive-change">https://www.exaltitude.io/blogs/why-gratitude-is-the-secret-weapon-for-attracting-more-opportunities-and-creating-positive-change</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33711839">https://news.ycombinator.com/item?id=33711839</a></p>
<p>Points: 27</p>
<p># Comments: 3</p>

## Decades of Air Pollution Undermine the Immune System
 - [https://www.cuimc.columbia.edu/news/decades-air-pollution-undermine-immune-system](https://www.cuimc.columbia.edu/news/decades-air-pollution-undermine-immune-system)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 21:22:55+00:00

<p>Article URL: <a href="https://www.cuimc.columbia.edu/news/decades-air-pollution-undermine-immune-system">https://www.cuimc.columbia.edu/news/decades-air-pollution-undermine-immune-system</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33711699">https://news.ycombinator.com/item?id=33711699</a></p>
<p>Points: 48</p>
<p># Comments: 7</p>

## RimWorld: A sci fi colony SIM driven by an intelligent AI storyteller
 - [https://rimworldgame.com/](https://rimworldgame.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 21:16:14+00:00

<p>Article URL: <a href="https://rimworldgame.com/">https://rimworldgame.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33711623">https://news.ycombinator.com/item?id=33711623</a></p>
<p>Points: 29</p>
<p># Comments: 11</p>

## Building the fastest Lua interpreter.. automatically
 - [https://sillycross.github.io/2022/11/22/2022-11-22/](https://sillycross.github.io/2022/11/22/2022-11-22/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 21:11:37+00:00

<p>Article URL: <a href="https://sillycross.github.io/2022/11/22/2022-11-22/">https://sillycross.github.io/2022/11/22/2022-11-22/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33711583">https://news.ycombinator.com/item?id=33711583</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## Show HN: CodeLink: create links to blocks of code in your IDE
 - [https://codelink.dev/](https://codelink.dev/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 21:03:02+00:00

<p>Small team down here in South New Zealand just launched CodeLink. In short its an IDE (VSCode/JetBrains) plugin that lets you share blocks of code that link directly to the code inside your IDE or repo. We use it all the time and think its pretty nifty tech that lets you understand someone’s code in context very quickly.  we’re hoping to keep refining it to make it better and more useful.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33711480">https://news.ycombinator.com/item?id=33711480</a></p>
<p>Points: 20</p>
<p># Comments: 4</p>

## Avenue (YC W21) Is Hiring Software Engineers in NYC (React/TypeScript/TRPC)
 - [https://jobs.ashbyhq.com/avenue/f4e8842d-83ae-413a-9ee3-d20c2b39380a](https://jobs.ashbyhq.com/avenue/f4e8842d-83ae-413a-9ee3-d20c2b39380a)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 21:00:50+00:00

<p>Article URL: <a href="https://jobs.ashbyhq.com/avenue/f4e8842d-83ae-413a-9ee3-d20c2b39380a">https://jobs.ashbyhq.com/avenue/f4e8842d-83ae-413a-9ee3-d20c2b39380a</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33711451">https://news.ycombinator.com/item?id=33711451</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Dwarf Fortress – randomly generated, persistent fantasy world
 - [http://www.bay12games.com/dwarves/features.html](http://www.bay12games.com/dwarves/features.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 20:45:12+00:00

<p>Article URL: <a href="http://www.bay12games.com/dwarves/features.html">http://www.bay12games.com/dwarves/features.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33711253">https://news.ycombinator.com/item?id=33711253</a></p>
<p>Points: 195</p>
<p># Comments: 41</p>

## 22-11-22 22:11:22
 - [https://news.ycombinator.com/item?id=33711205](https://news.ycombinator.com/item?id=33711205)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 20:41:37+00:00

<p>A palindrome date, time and datetime (:</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33711205">https://news.ycombinator.com/item?id=33711205</a></p>
<p>Points: 56</p>
<p># Comments: 25</p>

## Bullshit Software Projects
 - [https://earthly.dev/blog/bullshit-software-projects/](https://earthly.dev/blog/bullshit-software-projects/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 19:08:45+00:00

<p>Article URL: <a href="https://earthly.dev/blog/bullshit-software-projects/">https://earthly.dev/blog/bullshit-software-projects/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33709783">https://news.ycombinator.com/item?id=33709783</a></p>
<p>Points: 51</p>
<p># Comments: 19</p>

## Show HN: Hoku – The app that makes group travel simple
 - [https://hoku.travel/](https://hoku.travel/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 18:45:31+00:00

<p>Article URL: <a href="https://hoku.travel/">https://hoku.travel/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33709389">https://news.ycombinator.com/item?id=33709389</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## Adobe now requires you to purchase a subscription to rotate PDF pages
 - [https://merveilles.town/@vladh/109388897488336869](https://merveilles.town/@vladh/109388897488336869)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 18:36:12+00:00

<p>Article URL: <a href="https://merveilles.town/@vladh/109388897488336869">https://merveilles.town/@vladh/109388897488336869</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33709255">https://news.ycombinator.com/item?id=33709255</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## VSCode-Neovim: Use embedded Neovim in VSCode without emulation
 - [https://github.com/vscode-neovim/vscode-neovim](https://github.com/vscode-neovim/vscode-neovim)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 18:21:56+00:00

<p>Article URL: <a href="https://github.com/vscode-neovim/vscode-neovim">https://github.com/vscode-neovim/vscode-neovim</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33709013">https://news.ycombinator.com/item?id=33709013</a></p>
<p>Points: 31</p>
<p># Comments: 2</p>

## Deterministic Linux for controlled testing and software bug-finding
 - [https://developers.facebook.com/blog/post/2022/11/22/hermit-deterministic-linux-testing/](https://developers.facebook.com/blog/post/2022/11/22/hermit-deterministic-linux-testing/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 18:12:52+00:00

<p>Article URL: <a href="https://developers.facebook.com/blog/post/2022/11/22/hermit-deterministic-linux-testing/">https://developers.facebook.com/blog/post/2022/11/22/hermit-deterministic-linux-testing/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33708867">https://news.ycombinator.com/item?id=33708867</a></p>
<p>Points: 21</p>
<p># Comments: 6</p>

## Matthias Wandel woodworks his way to 1.72M subscribers
 - [https://www.cbc.ca/news/canada/new-brunswick/matthias-wandel-fredericton-woodworker-1.6659038](https://www.cbc.ca/news/canada/new-brunswick/matthias-wandel-fredericton-woodworker-1.6659038)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 18:11:11+00:00

<p>Article URL: <a href="https://www.cbc.ca/news/canada/new-brunswick/matthias-wandel-fredericton-woodworker-1.6659038">https://www.cbc.ca/news/canada/new-brunswick/matthias-wandel-fredericton-woodworker-1.6659038</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33708851">https://news.ycombinator.com/item?id=33708851</a></p>
<p>Points: 47</p>
<p># Comments: 14</p>

## The Rise of the Non-Working Class
 - [https://www.iwf.org/2022/09/14/nicholas-eberstadt-on-the-rising-non-working-class/](https://www.iwf.org/2022/09/14/nicholas-eberstadt-on-the-rising-non-working-class/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 17:59:18+00:00

<p>Article URL: <a href="https://www.iwf.org/2022/09/14/nicholas-eberstadt-on-the-rising-non-working-class/">https://www.iwf.org/2022/09/14/nicholas-eberstadt-on-the-rising-non-working-class/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33708701">https://news.ycombinator.com/item?id=33708701</a></p>
<p>Points: 46</p>
<p># Comments: 28</p>

## Effective Altruism Is about Getting Rich with a Clean Conscience
 - [https://www.nileshonly.com/effective-altruism-is-about-getting-rich-with-a-clean-conscience](https://www.nileshonly.com/effective-altruism-is-about-getting-rich-with-a-clean-conscience)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 17:47:43+00:00

<p>Article URL: <a href="https://www.nileshonly.com/effective-altruism-is-about-getting-rich-with-a-clean-conscience">https://www.nileshonly.com/effective-altruism-is-about-getting-rich-with-a-clean-conscience</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33708575">https://news.ycombinator.com/item?id=33708575</a></p>
<p>Points: 8</p>
<p># Comments: 4</p>

## Web 3.0 – An Arrogant and Treacherous Successor Doomed to Fail
 - [https://g147.medium.com/introducing-web-3-0-an-arrogant-treacherous-successor-doomed-to-fail-8b90529bb7be](https://g147.medium.com/introducing-web-3-0-an-arrogant-treacherous-successor-doomed-to-fail-8b90529bb7be)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 17:26:36+00:00

<p>Article URL: <a href="https://g147.medium.com/introducing-web-3-0-an-arrogant-treacherous-successor-doomed-to-fail-8b90529bb7be">https://g147.medium.com/introducing-web-3-0-an-arrogant-treacherous-successor-doomed-to-fail-8b90529bb7be</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33708320">https://news.ycombinator.com/item?id=33708320</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Barclays using TeamViewer font to warn customers
 - [https://old.reddit.com/r/UKPersonalFinance/comments/z1uvo8/this_felt_like_a_scam_how_did_my_bank_know_what/](https://old.reddit.com/r/UKPersonalFinance/comments/z1uvo8/this_felt_like_a_scam_how_did_my_bank_know_what/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 17:08:23+00:00

<p>Article URL: <a href="https://old.reddit.com/r/UKPersonalFinance/comments/z1uvo8/this_felt_like_a_scam_how_did_my_bank_know_what/">https://old.reddit.com/r/UKPersonalFinance/comments/z1uvo8/this_felt_like_a_scam_how_did_my_bank_know_what/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33708060">https://news.ycombinator.com/item?id=33708060</a></p>
<p>Points: 28</p>
<p># Comments: 3</p>

## Finley (YC W21) is hiring across all teams to build capital markets software
 - [https://news.ycombinator.com/item?id=33707952](https://news.ycombinator.com/item?id=33707952)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 17:01:05+00:00

<p>Imagine running a retail business without knowing how much you're paying your wholesaler for goods. Or running a restaurant without looking at the price of your ingredients. Or constructing homes without looking at the price of raw materials... you get the idea.<p>That lack of transparency would be frightening, but hey, things could still work out, right?<p>Well, let's up the stakes.<p>Imagine that, on top of not knowing exactly how much you were paying for your *inputs*, you also didn't know if you would have consistent and continued *access* to your wholesaler, your food supplier, or your building materials. That would almost certainly induce high blood pressure, stomach ulcers, and mild insomnia.<p>In the world of private credit (this is basically business credit for *all* companies that aren't publicly traded behemoths or small businesses), it's not only normal but *expected* that getting and maintaining access to debt capital (one of the key inputs for running any business!) will be opaque, error-prone, and hard to operationalize. In other words, supply chain uncertainty is the dismal reality in middle-market finance.<p>Private credit is enormous (add up all the VC dollars spent last year and you'd still be short of the amount of private credit issued over the same period), unavoidable, and broken.<p>That means credit access--the fuel or primary *financial input* for most medium-sized businesses--is hard to price, access, report on, and predict.<p>And yet it doesn't have to be that way; the data and operational issues of private credit have been solved in other domains (e.g., CRMs for Sales, infrastructure tooling for devs, EMRs for hospitals). What's missing is a software layer for business finance.<p>Finley has built the system of record for private credit. We plug into all borrower source systems and automate reporting and analysis for private credit lenders. The result is full transparency into the *cost* and *availability* of capital.<p>We're a team of builders, designers, finance experts, engineers, and systems thinkers from top companies in finance and technology, and we're backed by leading investors like Y Combinator and Bain Capital Ventures.<p>We're two years into our journey and our software helps companies manage over $3 billion in private credit, but it's still Day 1.<p>The challenges we're taking on will reshape the economy over the next decade, and we'd love to partner with team members who share our passion for innovation and company-building.<p>To learn more, check out our Careers page here: <a href="https://www.finleycms.com/careers/" rel="nofollow">https://www.finleycms.com/careers/</a></p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33707952">https://news.ycombinator.com/item?id=33707952</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Ask HN: How do you start a startup in your 30s when you have wife/kids/mortgage?
 - [https://news.ycombinator.com/item?id=33707889](https://news.ycombinator.com/item?id=33707889)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 16:56:52+00:00

<p>I want to start my own company, but Im not sure how to pay my bills while looking for product-market-fit.<p>I have a well paying job now, and I am pretty sure I would throw my marriage into chaos if I told my wife I was leaving my job to pursue a start up. Shes not stupid, she knows start ups have like a 90% failure rate.<p>So the question is: how do I continue my current standard of living for my family while working on a startup?<p>Are all startups at my age generally side hustles that become profitable enough to quit my day job?<p>Does anyone here have experience with this?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33707889">https://news.ycombinator.com/item?id=33707889</a></p>
<p>Points: 64</p>
<p># Comments: 70</p>

## Are tech stocks now good value?
 - [https://www.economist.com/finance-and-economics/2022/11/10/are-tech-stocks-now-good-value](https://www.economist.com/finance-and-economics/2022/11/10/are-tech-stocks-now-good-value)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 16:05:26+00:00

<p>Article URL: <a href="https://www.economist.com/finance-and-economics/2022/11/10/are-tech-stocks-now-good-value">https://www.economist.com/finance-and-economics/2022/11/10/are-tech-stocks-now-good-value</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33707221">https://news.ycombinator.com/item?id=33707221</a></p>
<p>Points: 26</p>
<p># Comments: 31</p>

## November 2022 Progress Report
 - [https://asahilinux.org/2022/11/november-2022-report/](https://asahilinux.org/2022/11/november-2022-report/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 15:56:50+00:00

<p>Article URL: <a href="https://asahilinux.org/2022/11/november-2022-report/">https://asahilinux.org/2022/11/november-2022-report/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33707115">https://news.ycombinator.com/item?id=33707115</a></p>
<p>Points: 51</p>
<p># Comments: 10</p>

## The Perks of a High-Documentation, Low-Meeting Work Culture
 - [https://www.tremendous.com/blog/the-perks-of-a-high-documentation-low-meeting-work-culture](https://www.tremendous.com/blog/the-perks-of-a-high-documentation-low-meeting-work-culture)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 15:50:26+00:00

<p>Article URL: <a href="https://www.tremendous.com/blog/the-perks-of-a-high-documentation-low-meeting-work-culture">https://www.tremendous.com/blog/the-perks-of-a-high-documentation-low-meeting-work-culture</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33707022">https://news.ycombinator.com/item?id=33707022</a></p>
<p>Points: 22</p>
<p># Comments: 6</p>

## Is SBF Going to Prison?
 - [https://sbfgoestoprison.com/](https://sbfgoestoprison.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 15:50:13+00:00

<p>Article URL: <a href="https://sbfgoestoprison.com/">https://sbfgoestoprison.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33707018">https://news.ycombinator.com/item?id=33707018</a></p>
<p>Points: 10</p>
<p># Comments: 3</p>

## Human-level play in the game of Diplomacy by combining language models
 - [https://www.science.org/doi/10.1126/science.ade9097](https://www.science.org/doi/10.1126/science.ade9097)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 15:47:33+00:00

<p>Article URL: <a href="https://www.science.org/doi/10.1126/science.ade9097">https://www.science.org/doi/10.1126/science.ade9097</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33706997">https://news.ycombinator.com/item?id=33706997</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## Quickadd: A Python library for extracting date and time from natural language
 - [https://github.com/Acreom/quickadd](https://github.com/Acreom/quickadd)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 15:32:02+00:00

<p>Article URL: <a href="https://github.com/Acreom/quickadd">https://github.com/Acreom/quickadd</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33706831">https://news.ycombinator.com/item?id=33706831</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Human-Level Play in Diplomacy Combining Language Models with Strategic Reasoning
 - [https://ai.facebook.com/blog/cicero-ai-negotiates-persuades-and-cooperates-with-people/](https://ai.facebook.com/blog/cicero-ai-negotiates-persuades-and-cooperates-with-people/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 15:24:17+00:00

<p>Article URL: <a href="https://ai.facebook.com/blog/cicero-ai-negotiates-persuades-and-cooperates-with-people/">https://ai.facebook.com/blog/cicero-ai-negotiates-persuades-and-cooperates-with-people/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33706750">https://news.ycombinator.com/item?id=33706750</a></p>
<p>Points: 45</p>
<p># Comments: 6</p>

## Retrofitting null-safety onto Java at Meta
 - [https://engineering.fb.com/2022/11/22/developer-tools/meta-java-nullsafe/](https://engineering.fb.com/2022/11/22/developer-tools/meta-java-nullsafe/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 15:21:21+00:00

<p>Article URL: <a href="https://engineering.fb.com/2022/11/22/developer-tools/meta-java-nullsafe/">https://engineering.fb.com/2022/11/22/developer-tools/meta-java-nullsafe/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33706721">https://news.ycombinator.com/item?id=33706721</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## Brotli-G: A GPU compression/decompression standard for digital assets
 - [https://gpuopen.com/brotli-g-sdk-announce/](https://gpuopen.com/brotli-g-sdk-announce/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 14:49:32+00:00

<p>Article URL: <a href="https://gpuopen.com/brotli-g-sdk-announce/">https://gpuopen.com/brotli-g-sdk-announce/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33706380">https://news.ycombinator.com/item?id=33706380</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## Cobalt – a stripped down Chromium for apps, Linux and embedded systems
 - [https://cobalt.dev/overview.html](https://cobalt.dev/overview.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 14:34:09+00:00

<p>Article URL: <a href="https://cobalt.dev/overview.html">https://cobalt.dev/overview.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33706197">https://news.ycombinator.com/item?id=33706197</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Improving Firefox stability with this one weird trick
 - [https://hacks.mozilla.org/2022/11/improving-firefox-stability-with-this-one-weird-trick/](https://hacks.mozilla.org/2022/11/improving-firefox-stability-with-this-one-weird-trick/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 14:26:42+00:00

<p>Article URL: <a href="https://hacks.mozilla.org/2022/11/improving-firefox-stability-with-this-one-weird-trick/">https://hacks.mozilla.org/2022/11/improving-firefox-stability-with-this-one-weird-trick/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33706117">https://news.ycombinator.com/item?id=33706117</a></p>
<p>Points: 29</p>
<p># Comments: 11</p>

## Rhasspy – Offline private voice assistant for many human languages
 - [https://github.com/rhasspy/rhasspy](https://github.com/rhasspy/rhasspy)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 14:11:14+00:00

<p>Article URL: <a href="https://github.com/rhasspy/rhasspy">https://github.com/rhasspy/rhasspy</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33705938">https://news.ycombinator.com/item?id=33705938</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## Dimming the Sun to Cool the Planet
 - [https://www.newyorker.com/news/daily-comment/dimming-the-sun-to-cool-the-planet-is-a-desperate-idea-yet-were-inching-toward-it](https://www.newyorker.com/news/daily-comment/dimming-the-sun-to-cool-the-planet-is-a-desperate-idea-yet-were-inching-toward-it)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 13:26:38+00:00

<p>Article URL: <a href="https://www.newyorker.com/news/daily-comment/dimming-the-sun-to-cool-the-planet-is-a-desperate-idea-yet-were-inching-toward-it">https://www.newyorker.com/news/daily-comment/dimming-the-sun-to-cool-the-planet-is-a-desperate-idea-yet-were-inching-toward-it</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33705494">https://news.ycombinator.com/item?id=33705494</a></p>
<p>Points: 4</p>
<p># Comments: 3</p>

## Hanami 2.0
 - [https://hanamirb.org/blog/2022/11/22/announcing-hanami-200/](https://hanamirb.org/blog/2022/11/22/announcing-hanami-200/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 12:57:29+00:00

<p>Article URL: <a href="https://hanamirb.org/blog/2022/11/22/announcing-hanami-200/">https://hanamirb.org/blog/2022/11/22/announcing-hanami-200/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33705249">https://news.ycombinator.com/item?id=33705249</a></p>
<p>Points: 22</p>
<p># Comments: 2</p>

## Please restore our registers when you’re done with them
 - [https://randomascii.wordpress.com/2022/11/21/please-restore-our-registers-when-youre-done-with-them/](https://randomascii.wordpress.com/2022/11/21/please-restore-our-registers-when-youre-done-with-them/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 12:53:23+00:00

<p>Article URL: <a href="https://randomascii.wordpress.com/2022/11/21/please-restore-our-registers-when-youre-done-with-them/">https://randomascii.wordpress.com/2022/11/21/please-restore-our-registers-when-youre-done-with-them/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33705209">https://news.ycombinator.com/item?id=33705209</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Show HN: JXL.js – JPEG XL Decoder in JavaScript Using WebAssembly in Web Worker
 - [https://github.com/niutech/jxl.js](https://github.com/niutech/jxl.js)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 12:37:34+00:00

<p>Article URL: <a href="https://github.com/niutech/jxl.js">https://github.com/niutech/jxl.js</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33705087">https://news.ycombinator.com/item?id=33705087</a></p>
<p>Points: 19</p>
<p># Comments: 6</p>

## Self Hosting a Google Maps Alternative with OpenStreetMap
 - [https://wcedmisten.fyi/post/self-hosting-osm/](https://wcedmisten.fyi/post/self-hosting-osm/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 12:00:24+00:00

<p>Article URL: <a href="https://wcedmisten.fyi/post/self-hosting-osm/">https://wcedmisten.fyi/post/self-hosting-osm/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33704801">https://news.ycombinator.com/item?id=33704801</a></p>
<p>Points: 13</p>
<p># Comments: 2</p>

## Frog: OCR Tool for Linux
 - [https://tenderowl.com/work/frog/](https://tenderowl.com/work/frog/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 11:10:25+00:00

<p>Article URL: <a href="https://tenderowl.com/work/frog/">https://tenderowl.com/work/frog/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33704483">https://news.ycombinator.com/item?id=33704483</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Turing Machine in Prolog (2017)
 - [https://www.metalevel.at/prolog/showcases/turing.pl](https://www.metalevel.at/prolog/showcases/turing.pl)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 10:51:58+00:00

<p>Article URL: <a href="https://www.metalevel.at/prolog/showcases/turing.pl">https://www.metalevel.at/prolog/showcases/turing.pl</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33704347">https://news.ycombinator.com/item?id=33704347</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Extremely Linear Git History
 - [https://westling.dev/b/extremely-linear-git](https://westling.dev/b/extremely-linear-git)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 10:43:30+00:00

<p>Article URL: <a href="https://westling.dev/b/extremely-linear-git">https://westling.dev/b/extremely-linear-git</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33704297">https://news.ycombinator.com/item?id=33704297</a></p>
<p>Points: 79</p>
<p># Comments: 34</p>

## D2 is now open source – a modern language that turns text to diagrams
 - [https://github.com/terrastruct/d2](https://github.com/terrastruct/d2)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 10:37:11+00:00

<p>Article URL: <a href="https://github.com/terrastruct/d2">https://github.com/terrastruct/d2</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33704254">https://news.ycombinator.com/item?id=33704254</a></p>
<p>Points: 23</p>
<p># Comments: 4</p>

## Subtractive Color Mixture Computation
 - [http://scottburns.us/subtractive-color-mixture/](http://scottburns.us/subtractive-color-mixture/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 10:28:42+00:00

<p>Article URL: <a href="http://scottburns.us/subtractive-color-mixture/">http://scottburns.us/subtractive-color-mixture/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33704197">https://news.ycombinator.com/item?id=33704197</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Considering C99 for Curl
 - [https://daniel.haxx.se/blog/2022/11/17/considering-c99-for-curl/](https://daniel.haxx.se/blog/2022/11/17/considering-c99-for-curl/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 10:05:26+00:00

<p>Article URL: <a href="https://daniel.haxx.se/blog/2022/11/17/considering-c99-for-curl/">https://daniel.haxx.se/blog/2022/11/17/considering-c99-for-curl/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33704054">https://news.ycombinator.com/item?id=33704054</a></p>
<p>Points: 30</p>
<p># Comments: 1</p>

## Mycroft – open source voice assistant
 - [https://mycroft.ai/](https://mycroft.ai/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 09:54:38+00:00

<p>Article URL: <a href="https://mycroft.ai/">https://mycroft.ai/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33703979">https://news.ycombinator.com/item?id=33703979</a></p>
<p>Points: 29</p>
<p># Comments: 7</p>

## TinyLLama – A Tiny x86 Retrocomputer
 - [https://github.com/eivindbohler/tinyllama](https://github.com/eivindbohler/tinyllama)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 07:33:47+00:00

<p>Article URL: <a href="https://github.com/eivindbohler/tinyllama">https://github.com/eivindbohler/tinyllama</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33703096">https://news.ycombinator.com/item?id=33703096</a></p>
<p>Points: 14</p>
<p># Comments: 0</p>

## Oh, the Places Your Apple ID Will Go
 - [https://pxlnv.com/blog/oh-the-places-your-apple-id-will-go/](https://pxlnv.com/blog/oh-the-places-your-apple-id-will-go/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 06:45:48+00:00

<p>Article URL: <a href="https://pxlnv.com/blog/oh-the-places-your-apple-id-will-go/">https://pxlnv.com/blog/oh-the-places-your-apple-id-will-go/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33702830">https://news.ycombinator.com/item?id=33702830</a></p>
<p>Points: 31</p>
<p># Comments: 4</p>

## Win for Open-Source Legally: Settlement Reached in Stockfish vs. ChessBase
 - [https://lichess.org/blog/Y3u1mRAAACIApBVn/settlement-reached-in-stockfish-v-chessbase](https://lichess.org/blog/Y3u1mRAAACIApBVn/settlement-reached-in-stockfish-v-chessbase)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 06:39:28+00:00

<p>Article URL: <a href="https://lichess.org/blog/Y3u1mRAAACIApBVn/settlement-reached-in-stockfish-v-chessbase">https://lichess.org/blog/Y3u1mRAAACIApBVn/settlement-reached-in-stockfish-v-chessbase</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33702790">https://news.ycombinator.com/item?id=33702790</a></p>
<p>Points: 14</p>
<p># Comments: 4</p>

## An autistic man was surfing the internet on his dad’s sofa, then the FBI arrived
 - [https://www.economist.com/1843/2022/11/21/an-autistic-man-was-surfing-the-internet-on-his-dads-sofa-then-the-fbi-turned-up](https://www.economist.com/1843/2022/11/21/an-autistic-man-was-surfing-the-internet-on-his-dads-sofa-then-the-fbi-turned-up)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 06:18:20+00:00

<p>Article URL: <a href="https://www.economist.com/1843/2022/11/21/an-autistic-man-was-surfing-the-internet-on-his-dads-sofa-then-the-fbi-turned-up">https://www.economist.com/1843/2022/11/21/an-autistic-man-was-surfing-the-internet-on-his-dads-sofa-then-the-fbi-turned-up</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33702645">https://news.ycombinator.com/item?id=33702645</a></p>
<p>Points: 22</p>
<p># Comments: 2</p>

## Telling It Like It Is in Plain English (Calling SBF a Fraud in March)
 - [https://jeffreycarter.substack.com/p/telling-it-like-it-is](https://jeffreycarter.substack.com/p/telling-it-like-it-is)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 05:47:11+00:00

<p>Article URL: <a href="https://jeffreycarter.substack.com/p/telling-it-like-it-is">https://jeffreycarter.substack.com/p/telling-it-like-it-is</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33702485">https://news.ycombinator.com/item?id=33702485</a></p>
<p>Points: 11</p>
<p># Comments: 3</p>

## Perlisms – “Epigrams in Programming”
 - [http://www.cs.yale.edu/homes/perlis-alan/quotes.html](http://www.cs.yale.edu/homes/perlis-alan/quotes.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 04:59:40+00:00

<p>Article URL: <a href="http://www.cs.yale.edu/homes/perlis-alan/quotes.html">http://www.cs.yale.edu/homes/perlis-alan/quotes.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33702150">https://news.ycombinator.com/item?id=33702150</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## TinyGL 0.4.1
 - [https://bellard.org/TinyGL/](https://bellard.org/TinyGL/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 04:18:41+00:00

<p>Article URL: <a href="https://bellard.org/TinyGL/">https://bellard.org/TinyGL/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33701826">https://news.ycombinator.com/item?id=33701826</a></p>
<p>Points: 31</p>
<p># Comments: 3</p>

## Always use [closed, open) intervals
 - [https://fhur.me/posts/always-use-closed-open-intervals](https://fhur.me/posts/always-use-closed-open-intervals)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 04:02:15+00:00

<p>Article URL: <a href="https://fhur.me/posts/always-use-closed-open-intervals">https://fhur.me/posts/always-use-closed-open-intervals</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33701687">https://news.ycombinator.com/item?id=33701687</a></p>
<p>Points: 21</p>
<p># Comments: 10</p>

## AP fires reporter behind retracted ‘Russian missiles’ story
 - [https://www.thedailybeast.com/ap-fires-reporter-behind-retracted-russian-missiles-story](https://www.thedailybeast.com/ap-fires-reporter-behind-retracted-russian-missiles-story)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 03:26:08+00:00

<p>Article URL: <a href="https://www.thedailybeast.com/ap-fires-reporter-behind-retracted-russian-missiles-story">https://www.thedailybeast.com/ap-fires-reporter-behind-retracted-russian-missiles-story</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33701410">https://news.ycombinator.com/item?id=33701410</a></p>
<p>Points: 14</p>
<p># Comments: 3</p>

## Why Twitter didn’t go down: From a real Twitter SRE
 - [https://matthewtejo.substack.com/p/why-twitter-didnt-go-down-from-a](https://matthewtejo.substack.com/p/why-twitter-didnt-go-down-from-a)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 03:20:20+00:00

<p>Article URL: <a href="https://matthewtejo.substack.com/p/why-twitter-didnt-go-down-from-a">https://matthewtejo.substack.com/p/why-twitter-didnt-go-down-from-a</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33701371">https://news.ycombinator.com/item?id=33701371</a></p>
<p>Points: 79</p>
<p># Comments: 24</p>

## Show HN: Comparing Open Source Projects
 - [https://ossrank.com/compare](https://ossrank.com/compare)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 02:38:52+00:00

<p>We just pushed out <a href="http://ossrank.com/compare" rel="nofollow">http://ossrank.com/compare</a> which allows you to compare commit and contributor velocity for a group of OSS projects.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33701073">https://news.ycombinator.com/item?id=33701073</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## One wierd trick can save Californians $37
 - [https://news.ycombinator.com/item?id=33701036](https://news.ycombinator.com/item?id=33701036)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 02:33:29+00:00

<p>If you're in California, you may have received a "California Middle Class Tax Refund" gift card, in the form of a VISA debit card. This is a "stimulus program" payment.<p>The debit card comes with fees. Lots of fees. About 3%, plus a $7 charge. Plus, by activating the card, you authorize My Banking Direct, a service of New York Community Bank, to use your financial info for marketing purposes.<p>But there's a way out. Hidden down in the fine print, in what looks like 8 point type, is "If you do not agree to all the Cardholder Agreement terms, you should cancel the card by calling customer service and request the funds be issued to you in the form of a paper check".<p>Now it gets interesting. There's a number to call, 1-800-240-0223. It leads to a phone message system, of course. First, there's press 1 for English, 2 for Spanish. Then a long spiel about the cards and payments, which you can't skip. Then you get a list of options, 1 through 8.<p>None of those options is customer service. Some try to trick you into activating the card, by typing in the number and your Social Security number, before they will tell you anything.<p>So how do you get a check? That's the trick. And here's the answer, from KCRA-TV.[1] "If you received a card, you can call 800-542-9332 and select option 9 to speak to an agent." This seems to lead to the same phone menu as the number on the notice. No Option 9 is listed. But if you press 9, you get sent to customer service.<p>Now, that's not the end. Now you get to talk to a voice recognition system, which asks what you want. It rejects "send check" and "cancel card". After two tries, it hangs up on you, and you have to start over.<p>But it does, it turns out, recognize "customer service". Which, finally, gets you to the hold queue for a human. The first human said her computer was down and she couldn't issue a check. On the next try, the human hung up when I asked for the company's business name and address.  On the third try, the human actually did the transaction, or at least pretended to. I asked for a transaction ID, which was not offered, and was grudgingly given one. In 10 days to 2 weeks, I am supposed to get a check.<p>Now <i>that's</i> a dark pattern.<p>New York Community Bank has a rating of one star with the Better Business Bureau. They probably make at least $150 million off the fees from California alone.<p>[1] https://www.kcra.com/article/california-middle-class-tax-refund-debit-card-explainer/41860421</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33701036">https://news.ycombinator.com/item?id=33701036</a></p>
<p>Points: 17</p>
<p># Comments: 3</p>

## Deus Ex: Human Revolution in (up to) gigapixel panoramas
 - [https://joumxyzptlk.de/deusex_panorama.html](https://joumxyzptlk.de/deusex_panorama.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 02:27:31+00:00

<p>Article URL: <a href="https://joumxyzptlk.de/deusex_panorama.html">https://joumxyzptlk.de/deusex_panorama.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33701003">https://news.ycombinator.com/item?id=33701003</a></p>
<p>Points: 15</p>
<p># Comments: 5</p>

## Amazon Alexa is a “colossal failure,” on pace to lose $10B this year
 - [https://arstechnica.com/gadgets/2022/11/amazon-alexa-is-a-colossal-failure-on-pace-to-lose-10-billion-this-year/](https://arstechnica.com/gadgets/2022/11/amazon-alexa-is-a-colossal-failure-on-pace-to-lose-10-billion-this-year/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 01:52:54+00:00

<p>Article URL: <a href="https://arstechnica.com/gadgets/2022/11/amazon-alexa-is-a-colossal-failure-on-pace-to-lose-10-billion-this-year/">https://arstechnica.com/gadgets/2022/11/amazon-alexa-is-a-colossal-failure-on-pace-to-lose-10-billion-this-year/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33700792">https://news.ycombinator.com/item?id=33700792</a></p>
<p>Points: 29</p>
<p># Comments: 9</p>

## Basics of Concrete Barriers
 - [https://highways.dot.gov/public-roads/marchapril-2000/basics-concrete-barriers](https://highways.dot.gov/public-roads/marchapril-2000/basics-concrete-barriers)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 00:55:03+00:00

<p>Article URL: <a href="https://highways.dot.gov/public-roads/marchapril-2000/basics-concrete-barriers">https://highways.dot.gov/public-roads/marchapril-2000/basics-concrete-barriers</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33700415">https://news.ycombinator.com/item?id=33700415</a></p>
<p>Points: 14</p>
<p># Comments: 3</p>

## Show HN: Wiretap – Transparent WireGuard proxy server without root
 - [https://github.com/sandialabs/wiretap](https://github.com/sandialabs/wiretap)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-22 00:21:42+00:00

<p>Article URL: <a href="https://github.com/sandialabs/wiretap">https://github.com/sandialabs/wiretap</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33700136">https://news.ycombinator.com/item?id=33700136</a></p>
<p>Points: 10</p>
<p># Comments: 2</p>


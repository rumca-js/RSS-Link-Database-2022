# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## Here’s Proof Hate Speech Is More Viral on Elon Musk’s Twitter
 - [https://www.wired.com/story/heres-proof-hate-speech-is-more-viral-on-elon-musks-twitter/](https://www.wired.com/story/heres-proof-hate-speech-is-more-viral-on-elon-musks-twitter/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2022-11-22 23:13:38+00:00

Researchers monitoring a “firehose” of public tweets found signs of increasing toxicity—before Elon Musk reversed bans on Trump and other divisive figures.

## The Race To Save Sam Bankman-Fried’s Other Crypto Exchange
 - [https://www.wired.com/story/ftx-serum-crypto-exchange/](https://www.wired.com/story/ftx-serum-crypto-exchange/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2022-11-22 16:59:39+00:00

Following the collapse of FTX, a group of volunteers has gathered to try and salvage Serum. But the work is far from straightforward.


# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Georgia Voting Numbers Do Indeed Show Youth Surge
 - [https://theintercept.com/2022/11/22/midterm-elections-young-voters-turnout-georgia/](https://theintercept.com/2022/11/22/midterm-elections-young-voters-turnout-georgia/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2022-11-22 19:17:36+00:00

<p>The number of young voters in Georgia more than doubled since 2014, counter to the narrative provided by David Shor.</p>
<p>The post <a href="https://theintercept.com/2022/11/22/midterm-elections-young-voters-turnout-georgia/" rel="nofollow">Georgia Voting Numbers Do Indeed Show Youth Surge</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## Elon Musk’s “Free Speech” Twitter Is Still Censoring DDoSecrets
 - [https://theintercept.com/2022/11/22/elon-musk-twitter-censor-ddosecrets/](https://theintercept.com/2022/11/22/elon-musk-twitter-censor-ddosecrets/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2022-11-22 17:00:14+00:00

<p>Twitter has censored the website of nonprofit transparency collective Distributed Denial of Secrets for more than two years.</p>
<p>The post <a href="https://theintercept.com/2022/11/22/elon-musk-twitter-censor-ddosecrets/" rel="nofollow">Elon Musk’s “Free Speech” Twitter Is Still Censoring DDoSecrets</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>


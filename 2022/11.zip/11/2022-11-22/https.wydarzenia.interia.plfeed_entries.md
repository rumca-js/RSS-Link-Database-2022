# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Zełenski: W Ukrainie powstało 4 tys. "Punktów Niezłomności"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-w-ukrainie-powstalo-4-tys-punktow-niezlomnosci,nId,6427580](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-w-ukrainie-powstalo-4-tys-punktow-niezlomnosci,nId,6427580)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 22:40:30+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-w-ukrainie-powstalo-4-tys-punktow-niezlomnosci,nId,6427580"><img align="left" alt="Zełenski: W Ukrainie powstało 4 tys. &quot;Punktów Niezłomności&quot;" src="https://i.iplsc.com/zelenski-w-ukrainie-powstalo-4-tys-punktow-niezlomnosci/000GDP9SUNQPDQNY-C321.jpg" /></a>Prezydent Ukrainy Wołodymyr Zełenski we wtorek wieczorem w swoim regularnym wystąpieniu w mediach społecznościowych poinformował o uruchomieniu w całym kraju &quot;punktów niezłomności&quot;, gdzie w razie masowych rosyjskich nalotów obywatele będą mogli uzyskać niezbędną pomoc. Wyjaśniał, że &quot;są tam wszystkie podstawowe media: prąd, sieć komórkowa i Internet, ogrzewanie, woda, apteczka. Całkowicie za darmo i przez całą dobę&quot;.
</p><br clear="all" />

## Holandia: Złodziej ukrył się w sklepie z pościelą. Złapał go święty Mikołaj
 - [https://wydarzenia.interia.pl/zagranica/news-holandia-zlodziej-ukryl-sie-w-sklepie-z-posciela-zlapal-go-s,nId,6427574](https://wydarzenia.interia.pl/zagranica/news-holandia-zlodziej-ukryl-sie-w-sklepie-z-posciela-zlapal-go-s,nId,6427574)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 21:50:51+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-holandia-zlodziej-ukryl-sie-w-sklepie-z-posciela-zlapal-go-s,nId,6427574"><img align="left" alt="Holandia: Złodziej ukrył się w sklepie z pościelą. Złapał go święty Mikołaj" src="https://i.iplsc.com/holandia-zlodziej-ukryl-sie-w-sklepie-z-posciela-zlapal-go-s/000GDP50IP1YS48T-C321.jpg" /></a>Sinterklaas - holenderski święty Mikołaj, który spełnia dziecięce marzenia - w tym roku pomógł także policji w Almelo. Podczas przedświątecznego spotkania z dziećmi spostrzegł, że personel sklepu żelaznego ściga złodzieja. Włączył się do akcji i chwilę później schwytał 34-letniego uciekiniera. Aby przekazać go w ręce służb, unieruchomił go na łóżku i skuł kajdankami.</p><br clear="all" />

## Wpadka propagandy. Ojciec Putina "zginął" 10 lat przed narodzinami syna
 - [https://wydarzenia.interia.pl/zagranica/news-wpadka-propagandy-ojciec-putina-zginal-10-lat-przed-narodzin,nId,6427557](https://wydarzenia.interia.pl/zagranica/news-wpadka-propagandy-ojciec-putina-zginal-10-lat-przed-narodzin,nId,6427557)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 21:11:16+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wpadka-propagandy-ojciec-putina-zginal-10-lat-przed-narodzin,nId,6427557"><img align="left" alt="Wpadka propagandy. Ojciec Putina &quot;zginął&quot; 10 lat przed narodzinami syna" src="https://i.iplsc.com/wpadka-propagandy-ojciec-putina-zginal-10-lat-przed-narodzin/000GDOXB1HEIFMUG-C321.jpg" /></a>Rosyjscy propagandyści &quot;zabłysnęli&quot; po raz kolejny. Chcieli najprawdopodobniej pokazać ojca Władimira Putina w dobrym świetle i nieco podnieść jego zasługi. Bohater, który zginął na froncie, walcząc za Rosję, brzmi zdecydowanie patriotyczne. Tak więc w rosyjskim reportażu ojciec prezydenta Rosji zginął w czasie walk o Leningrad. 10 lat przed narodzinami syna.</p><br clear="all" />

## Indie: Pies niósł w pysku ciało noworodka. Ktoś mógł je porzucić
 - [https://wydarzenia.interia.pl/zagranica/news-indie-pies-niosl-w-pysku-cialo-noworodka-ktos-mogl-je-porzuc,nId,6427551](https://wydarzenia.interia.pl/zagranica/news-indie-pies-niosl-w-pysku-cialo-noworodka-ktos-mogl-je-porzuc,nId,6427551)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 20:33:53+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-indie-pies-niosl-w-pysku-cialo-noworodka-ktos-mogl-je-porzuc,nId,6427551"><img align="left" alt="Indie: Pies niósł w pysku ciało noworodka. Ktoś mógł je porzucić" src="https://i.iplsc.com/indie-pies-niosl-w-pysku-cialo-noworodka-ktos-mogl-je-porzuc/000CR91NSRGWBQU2-C321.jpg" /></a>Psa niosącego w pysku nieżyjącego noworodka zauważyli pracownicy parkingu przy indyjskim szpitalu. Nie wiadomo, w jaki sposób zwierzę znalazło ciało, ani kim byli rodzice dziecka. Dyrekcja szpitala sugeruje, że bliscy - zamiast godnie pochować noworodka - mogli porzucić jego zwłoki.</p><br clear="all" />

## A jednak Iran to robi. Instytucje biją na alarm
 - [https://wydarzenia.interia.pl/zagranica/news-a-jednak-iran-to-robi-instytucje-bija-na-alarm,nId,6427553](https://wydarzenia.interia.pl/zagranica/news-a-jednak-iran-to-robi-instytucje-bija-na-alarm,nId,6427553)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 20:30:30+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-a-jednak-iran-to-robi-instytucje-bija-na-alarm,nId,6427553"><img align="left" alt="A jednak Iran to robi. Instytucje biją na alarm" src="https://i.iplsc.com/a-jednak-iran-to-robi-instytucje-bija-na-alarm/00096VL0LE8X05TO-C321.jpg" /></a>Iran rozpoczął wzbogacanie uranu do 60 proc. - alarmuje Międzynarodowa Agencja Energii Atomowej. Do sprawy odniosło się kilka państw, które potępiły rząd w Teheranie za rozwój programu nuklearnego.</p><br clear="all" />

## Co się wydarzyło w Makiejewce? Jest stanowisko ukraińskiej prokuratury
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-co-sie-wydarzylo-w-makiejewce-jest-stanowisko-ukrainskiej-pr,nId,6427530](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-co-sie-wydarzylo-w-makiejewce-jest-stanowisko-ukrainskiej-pr,nId,6427530)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 20:19:44+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-co-sie-wydarzylo-w-makiejewce-jest-stanowisko-ukrainskiej-pr,nId,6427530"><img align="left" alt="Co się wydarzyło w Makiejewce? Jest stanowisko ukraińskiej prokuratury" src="https://i.iplsc.com/co-sie-wydarzylo-w-makiejewce-jest-stanowisko-ukrainskiej-pr/000GDOMWDBF7Q4DJ-C321.jpg" /></a>Co się wydarzyło w Makiejewce? W internecie pojawiły się dwa filmy i dwie wersje zdarzeń: rosyjska i ukraińska. We wtorek stanowisko w sprawie zajęła ukraińska Prokuratura Generalna. Poinformowała o postępowaniu przygotowawczym. Zarzuca Rosjanom wiarołomstwo.</p><br clear="all" />

## Niemcy: Kościół katolicki nie zwolni z pracy za jednopłciowe małżeństwo
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-kosciol-katolicki-nie-zwolni-z-pracy-za-jednoplciowe-,nId,6427507](https://wydarzenia.interia.pl/zagranica/news-niemcy-kosciol-katolicki-nie-zwolni-z-pracy-za-jednoplciowe-,nId,6427507)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 19:24:48+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-kosciol-katolicki-nie-zwolni-z-pracy-za-jednoplciowe-,nId,6427507"><img align="left" alt="Niemcy: Kościół katolicki nie zwolni z pracy za jednopłciowe małżeństwo" src="https://i.iplsc.com/niemcy-kosciol-katolicki-nie-zwolni-z-pracy-za-jednoplciowe/000GDOIA7AR3210W-C321.jpg" /></a>Małżeństwo jednopłciowe lub ślub po rozwodzie nie przerwą kariery pracowników Kościoła katolickiego w Niemczech. To przełomowa decyzja, z której zadowoleni są zarówno politycy, jak i kościelne organizacje. Zdaniem arcybiskupa Hamburga zmiany w kanonicznym prawie są &quot;ważne i niezbędne&quot;.</p><br clear="all" />

## Coraz groźniejsze infekcje bakteryjne. Niemal osiem milionów zgonów w ciągu roku
 - [https://wydarzenia.interia.pl/zagranica/news-coraz-grozniejsze-infekcje-bakteryjne-niemal-osiem-milionow-,nId,6427479](https://wydarzenia.interia.pl/zagranica/news-coraz-grozniejsze-infekcje-bakteryjne-niemal-osiem-milionow-,nId,6427479)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 18:38:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-coraz-grozniejsze-infekcje-bakteryjne-niemal-osiem-milionow-,nId,6427479"><img align="left" alt="Coraz groźniejsze infekcje bakteryjne. Niemal osiem milionów zgonów w ciągu roku" src="https://i.iplsc.com/coraz-grozniejsze-infekcje-bakteryjne-niemal-osiem-milionow/000514EYAYY2DN5S-C321.jpg" /></a>Za jedną ósmą śmierci na świecie odpowiadają infekcje bakteryjne. To druga najczęstsza przyczyna zgonów w skali całego globu - wynika z międzynarodowego badania, które przeprowadzono przy użyciu danych za 2019 rok. Wyniki opublikowano w renomowanym czasopiśmie medycznym &quot;The Lancet&quot;. Naukowcy zwracają uwagę, że istotnym problemem staje się odporność bakterii na antybiotyki.</p><br clear="all" />

## USA: Kłótnia na stacji benzynowej. Potłukł słoik, kasjerka wyjęła broń
 - [https://wydarzenia.interia.pl/zagranica/news-usa-klotnia-na-stacji-benzynowej-potlukl-sloik-kasjerka-wyje,nId,6427481](https://wydarzenia.interia.pl/zagranica/news-usa-klotnia-na-stacji-benzynowej-potlukl-sloik-kasjerka-wyje,nId,6427481)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 18:32:59+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-klotnia-na-stacji-benzynowej-potlukl-sloik-kasjerka-wyje,nId,6427481"><img align="left" alt="USA: Kłótnia na stacji benzynowej. Potłukł słoik, kasjerka wyjęła broń" src="https://i.iplsc.com/usa-klotnia-na-stacji-benzynowej-potlukl-sloik-kasjerka-wyje/000GDO9B5J9R21XN-C321.jpg" /></a>Pracownica stacji benzynowej w Teksasie w USA otworzyła ogień do klienta, z którym wcześniej się pokłóciła. W trakcie awantury, zanim mężczyzna wyszedł ze stacji, miał celowo rozbić słoik salsy, co jeszcze bardziej rozzłościło 22-latkę, która sięgnęła ostatecznie po broń.</p><br clear="all" />

## Interwencja straży miejskiej. 14-latki popiły leki wódką
 - [https://wydarzenia.interia.pl/mazowieckie/news-interwencja-strazy-miejskiej-14-latki-popily-leki-wodka,nId,6427480](https://wydarzenia.interia.pl/mazowieckie/news-interwencja-strazy-miejskiej-14-latki-popily-leki-wodka,nId,6427480)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 18:22:50+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-interwencja-strazy-miejskiej-14-latki-popily-leki-wodka,nId,6427480"><img align="left" alt="Interwencja straży miejskiej. 14-latki popiły leki wódką" src="https://i.iplsc.com/interwencja-strazy-miejskiej-14-latki-popily-leki-wodka/000GDO7X6RDKQ211-C321.jpg" /></a>Stołeczni strażnicy miejscy otrzymali zgłoszenie o dwóch nietrzeźwych osobach na jednym z warszawskich podwórek. Jak się okazało, 14-latki popiły leki przeciwpadaczkowe wódką. Lekarz zdecydował, że muszą trafić do szpitala.</p><br clear="all" />

## Spokojne małżeństwo zatrzymane przez antyterrorystów. To rosyjscy szpiedzy
 - [https://wydarzenia.interia.pl/zagranica/news-spokojne-malzenstwo-zatrzymane-przez-antyterrorystow-to-rosy,nId,6427458](https://wydarzenia.interia.pl/zagranica/news-spokojne-malzenstwo-zatrzymane-przez-antyterrorystow-to-rosy,nId,6427458)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 17:58:09+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-spokojne-malzenstwo-zatrzymane-przez-antyterrorystow-to-rosy,nId,6427458"><img align="left" alt="Spokojne małżeństwo zatrzymane przez antyterrorystów. To rosyjscy szpiedzy" src="https://i.iplsc.com/spokojne-malzenstwo-zatrzymane-przez-antyterrorystow-to-rosy/000GDO55M742XJX1-C321.jpg" /></a>Małżeństwo z Rosji, które wiodło pozornie spokojne życie na przedmieściach Sztokholmu miało od lat prowadzić działalność szpiegowską przeciwko Szwecji - podejrzewa Szwedzka Służba Bezpieczeństwa. We wtorek o świcie antyterroryści zeskoczyli ze śmigłowców i aresztowali rosyjskich agentów. </p><br clear="all" />

## Kiedy Polska zostanie mistrzem świata w piłce nożnej?
 - [https://wydarzenia.interia.pl/felietony/kuisz/news-kiedy-polska-zostanie-mistrzem-swiata-w-pilce-noznej,nId,6427457](https://wydarzenia.interia.pl/felietony/kuisz/news-kiedy-polska-zostanie-mistrzem-swiata-w-pilce-noznej,nId,6427457)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 17:54:58+00:00

<p><a href="https://wydarzenia.interia.pl/felietony/kuisz/news-kiedy-polska-zostanie-mistrzem-swiata-w-pilce-noznej,nId,6427457"><img align="left" alt="Kiedy Polska zostanie mistrzem świata w piłce nożnej?" src="https://i.iplsc.com/kiedy-polska-zostanie-mistrzem-swiata-w-pilce-noznej/000GDO2F0JQ38X08-C321.jpg" /></a>I oto pierwszy mecz polskiej drużyny w Katarze. Udział w takich turniejach ma sens, jeśli, przynajmniej hipotetycznie, zakłada się wygraną. Czy nasza ekipa futbolowa ma szanse kiedykolwiek zostać mistrzem świata? Tak - ale z dużym &quot;ALE&quot;. Dość popatrzeć na spotkanie z Meksykiem. </p><br clear="all" />

## Śnieg i pioruny nad Sztokholmem. Burza obudziła mieszkańców
 - [https://wydarzenia.interia.pl/zagranica/news-snieg-i-pioruny-nad-sztokholmem-burza-obudzila-mieszkancow,nId,6427391](https://wydarzenia.interia.pl/zagranica/news-snieg-i-pioruny-nad-sztokholmem-burza-obudzila-mieszkancow,nId,6427391)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 17:37:08+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-snieg-i-pioruny-nad-sztokholmem-burza-obudzila-mieszkancow,nId,6427391"><img align="left" alt="Śnieg i pioruny nad Sztokholmem. Burza obudziła mieszkańców" src="https://i.iplsc.com/snieg-i-pioruny-nad-sztokholmem-burza-obudzila-mieszkancow/000GDO2GBAJWWVNO-C321.jpg" /></a>Mieszkający w stolicy Szwecji - Sztokholmie - dotychczas nieczęsto mieli okazję zetknąć się z burzą, która łączy ze sobą opady śniegu i pokazy elektrycznych wyładowań. Taką okazję mieli pod koniec weekendu, jednak nie wszyscy byli zadowoleni. Nawałnica przeszła nad metropolią w środku nocy.</p><br clear="all" />

## Irak: Potężna eksplozja gazu. Zginęli policjanci, którzy ewakuowali rannych
 - [https://wydarzenia.interia.pl/zagranica/news-irak-potezna-eksplozja-gazu-zgineli-policjanci-ktorzy-ewakuo,nId,6427446](https://wydarzenia.interia.pl/zagranica/news-irak-potezna-eksplozja-gazu-zgineli-policjanci-ktorzy-ewakuo,nId,6427446)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 17:34:50+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-irak-potezna-eksplozja-gazu-zgineli-policjanci-ktorzy-ewakuo,nId,6427446"><img align="left" alt="Irak: Potężna eksplozja gazu. Zginęli policjanci, którzy ewakuowali rannych" src="https://i.iplsc.com/irak-potezna-eksplozja-gazu-zgineli-policjanci-ktorzy-ewakuo/000GDNZJOEXJVSDG-C321.jpg" /></a>Pięć osób zginęło, a 40 zostało rannych po wybuchu gazu w irackim Dahuk. W sieci pojawiły się dramatyczne nagrania z akcji ratunkowej. Lokalne władze zakazały korzystania z ciekłego gazu do użytku domowego.</p><br clear="all" />

## Ukraina: Syn dowódcy UPA nie żyje. Jurij Szuchewycz zmarł w Niemczech
 - [https://wydarzenia.interia.pl/zagranica/news-ukraina-syn-dowodcy-upa-nie-zyje-jurij-szuchewycz-zmarl-w-ni,nId,6427442](https://wydarzenia.interia.pl/zagranica/news-ukraina-syn-dowodcy-upa-nie-zyje-jurij-szuchewycz-zmarl-w-ni,nId,6427442)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 17:29:15+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ukraina-syn-dowodcy-upa-nie-zyje-jurij-szuchewycz-zmarl-w-ni,nId,6427442"><img align="left" alt="Ukraina: Syn dowódcy UPA nie żyje. Jurij Szuchewycz zmarł w Niemczech" src="https://i.iplsc.com/ukraina-syn-dowodcy-upa-nie-zyje-jurij-szuchewycz-zmarl-w-ni/000GDNX893MWPT2T-C321.jpg" /></a>W wieku 89 lat zmarł Jurij Szuchewycz - dysydent, długoletni więzień polityczny sowieckich Gułagów, syn naczelnego dowódcy Ukraińskiej Powstańczej Armii (UPA) Romana Szuchewycza - poinformował we wtorek na Telegramie mer Lwowa Andrij Sadowy. Według doniesień mediów Szuchewycz zmarł w nocy 22 listopada w Niemczech, gdzie przechodził leczenie.</p><br clear="all" />

## Zabójstwo komornik w Łukowie. Sprawca miał dług w innej kancelarii
 - [https://wydarzenia.interia.pl/kraj/news-zabojstwo-komornik-w-lukowie-sprawca-mial-dlug-w-innej-kance,nId,6427293](https://wydarzenia.interia.pl/kraj/news-zabojstwo-komornik-w-lukowie-sprawca-mial-dlug-w-innej-kance,nId,6427293)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 17:23:30+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zabojstwo-komornik-w-lukowie-sprawca-mial-dlug-w-innej-kance,nId,6427293"><img align="left" alt="Zabójstwo komornik w Łukowie. Sprawca miał dług w innej kancelarii" src="https://i.iplsc.com/zabojstwo-komornik-w-lukowie-sprawca-mial-dlug-w-innej-kance/0003BI58QKNJUMK1-C321.jpg" /></a>Podejrzany o zabójstwo 44-letniej komornik miał dług, ale u innego urzędnika. Zamordowana kobieta i jej kancelaria nie prowadziła czynności komorniczych wobec sprawcy. Karol M., zanim dotarł do kancelarii ofiary, miał siać zamęt w pozostałych kancelariach komorniczych w Łukowie.</p><br clear="all" />

## "Rosjanie są zmęczeni wojną". Kreml przeprowadził badanie
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-sa-zmeczeni-wojna-kreml-przeprowadzil-badanie,nId,6427289](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-sa-zmeczeni-wojna-kreml-przeprowadzil-badanie,nId,6427289)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 17:01:40+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-sa-zmeczeni-wojna-kreml-przeprowadzil-badanie,nId,6427289"><img align="left" alt="&quot;Rosjanie są zmęczeni wojną&quot;. Kreml przeprowadził badanie" src="https://i.iplsc.com/rosjanie-sa-zmeczeni-wojna-kreml-przeprowadzil-badanie/000FMFPT3FXD15KE-C321.jpg" /></a>&quot;57 proc. Rosjan jest zmęczonych wojną w Ukrainie&quot; - pisze niezależny rosyjski portal Meduza, powołując się na niejawne badania, które Kreml miał przeprowadzić w kilku regionach Rosji na początku listopada. - To nie jest całkowita opozycja, czy sprzeciw wobec operacji wojskowej. To raczej zobojętnienie i apatia - mówiło dziennikarzom anonimowe źródło w Moskwie.</p><br clear="all" />

## Erdogan grozi Kurdom. "Użyjemy czołgów i wojsk lądowych"
 - [https://wydarzenia.interia.pl/zagranica/news-erdogan-grozi-kurdom-uzyjemy-czolgow-i-wojsk-ladowych,nId,6427241](https://wydarzenia.interia.pl/zagranica/news-erdogan-grozi-kurdom-uzyjemy-czolgow-i-wojsk-ladowych,nId,6427241)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 16:12:30+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-erdogan-grozi-kurdom-uzyjemy-czolgow-i-wojsk-ladowych,nId,6427241"><img align="left" alt="Erdogan grozi Kurdom. &quot;Użyjemy czołgów i wojsk lądowych&quot;" src="https://i.iplsc.com/erdogan-grozi-kurdom-uzyjemy-czolgow-i-wojsk-ladowych/0009C10TLGLJY62P-C321.jpg" /></a>- Tureckie siły zbrojne użyją przeciw kurdyjskim bojownikom czołgów i wojsk lądowych tak szybko, jak to możliwe - zapowiadał we wtorek prezydent Turcji Recep Tayyip Erdogan. To operacja odwetowa Ankary przeciw Kurdom w północnej Syrii i Iraku, która trwa od kilku dni. </p><br clear="all" />

## Granica polsko-białoruska. Zakaz przebywania ponownie wydłużony
 - [https://wydarzenia.interia.pl/podlaskie/news-granica-polsko-bialoruska-zakaz-przebywania-ponownie-wydluzo,nId,6427264](https://wydarzenia.interia.pl/podlaskie/news-granica-polsko-bialoruska-zakaz-przebywania-ponownie-wydluzo,nId,6427264)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 16:11:52+00:00

<p><a href="https://wydarzenia.interia.pl/podlaskie/news-granica-polsko-bialoruska-zakaz-przebywania-ponownie-wydluzo,nId,6427264"><img align="left" alt="Granica polsko-białoruska. Zakaz przebywania ponownie wydłużony" src="https://i.iplsc.com/granica-polsko-bialoruska-zakaz-przebywania-ponownie-wydluzo/000GDNC3TGSMS5CA-C321.jpg" /></a>Najwcześniej 1 stycznia 2023 roku przestanie obowiązywać zakaz zbliżania się do granicy polsko-białoruskiej w Podlaskiem na odległość mniejszą niż dwieście metrów. Trwa tam budowa zapory. We wtorek wojewoda podpisał rozporządzenie przedłużające obowiązywanie restrykcji, o co wnioskowała Straż Graniczna. Możliwe, że pod koniec roku czas obowiązywania zakazu ponownie zostanie wydłużony.</p><br clear="all" />

## Mundial 2022. Prezydent ogląda mecz wspólnie z żołnierzami
 - [https://wydarzenia.interia.pl/kraj/news-mundial-2022-prezydent-oglada-mecz-wspolnie-z-zolnierzami,nId,6427223](https://wydarzenia.interia.pl/kraj/news-mundial-2022-prezydent-oglada-mecz-wspolnie-z-zolnierzami,nId,6427223)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 16:00:58+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-mundial-2022-prezydent-oglada-mecz-wspolnie-z-zolnierzami,nId,6427223"><img align="left" alt="Mundial 2022. Prezydent ogląda mecz wspólnie z żołnierzami" src="https://i.iplsc.com/mundial-2022-prezydent-oglada-mecz-wspolnie-z-zolnierzami/000GDN5M4DHA2DSS-C321.jpg" /></a>Prezydent i minister obrony oglądają mecz polskiej reprezentacji wspólnie z żołnierzami. Kibicują wraz z wojskowymi, którzy służą na Podlasiu, zabezpieczając polską granicę.</p><br clear="all" />

## Polscy policjanci będą pomagać na mistrzostwach świata w Katarze
 - [https://wydarzenia.interia.pl/zagranica/news-polscy-policjanci-beda-pomagac-na-mistrzostwach-swiata-w-kat,nId,6427232](https://wydarzenia.interia.pl/zagranica/news-polscy-policjanci-beda-pomagac-na-mistrzostwach-swiata-w-kat,nId,6427232)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 15:49:45+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-polscy-policjanci-beda-pomagac-na-mistrzostwach-swiata-w-kat,nId,6427232"><img align="left" alt="Polscy policjanci będą pomagać na mistrzostwach świata w Katarze" src="https://i.iplsc.com/polscy-policjanci-beda-pomagac-na-mistrzostwach-swiata-w-kat/000GDN1V1RQG2VC0-C321.jpg" /></a>- Skierowaliśmy na Mistrzostwa Świata w Piłce Nożnej do Kataru siedmiu policjantów biegle władających językiem angielskim. Będą pomagać polskim kibicom - poinformował rzecznik Komendanta Głównego Policji insp. Mariusz Ciarka. Zapewnił przy tym, że funkcjonariusze będą w Katarze pomagać naszym obywatelom co najmniej do momentu zakończenia gry przez Biało-Czerwonych.</p><br clear="all" />

## Hamował i spowodował wypadek. Wszystko się nagrało
 - [https://wydarzenia.interia.pl/kujawsko-pomorskie/news-hamowal-i-spowodowal-wypadek-wszystko-sie-nagralo,nId,6427212](https://wydarzenia.interia.pl/kujawsko-pomorskie/news-hamowal-i-spowodowal-wypadek-wszystko-sie-nagralo,nId,6427212)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 15:38:59+00:00

<p><a href="https://wydarzenia.interia.pl/kujawsko-pomorskie/news-hamowal-i-spowodowal-wypadek-wszystko-sie-nagralo,nId,6427212"><img align="left" alt="Hamował i spowodował wypadek. Wszystko się nagrało" src="https://i.iplsc.com/hamowal-i-spowodowal-wypadek-wszystko-sie-nagralo/000GDMWLK8IVTKEC-C321.jpg" /></a>Gdyby nie kamerka drogowa, sprawca zdarzenia mógłby dowodzić, że jest ofiarą wypadku. Tymczasem wszystko się nagrało i sprawą kierowcy z Warszawy, który &quot;celowo i złośliwie&quot; zahamował, doprowadzając do wypadku, zajmie się sąd.</p><br clear="all" />

## Dłuższa kadencja samorządów. Prezydent podpisał ustawę
 - [https://wydarzenia.interia.pl/kraj/news-dluzsza-kadencja-samorzadow-prezydent-podpisal-ustawe,nId,6427228](https://wydarzenia.interia.pl/kraj/news-dluzsza-kadencja-samorzadow-prezydent-podpisal-ustawe,nId,6427228)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 15:31:31+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-dluzsza-kadencja-samorzadow-prezydent-podpisal-ustawe,nId,6427228"><img align="left" alt="Dłuższa kadencja samorządów. Prezydent podpisał ustawę" src="https://i.iplsc.com/dluzsza-kadencja-samorzadow-prezydent-podpisal-ustawe/000DWR2I55CBIP0V-C321.jpg" /></a>Jak poinformowała Kancelaria Prezydenta, Andrzej Duda podpisał ustawę o przedłużeniu kadencji samorządów. Wybory władz lokalnych odbędą się 30 kwietnia 2024 roku.</p><br clear="all" />

## Firma oburzona na FIFA. Przestaje sponsorować niemieckich piłkarzy
 - [https://wydarzenia.interia.pl/autor/tomasz-lejman/news-firma-oburzona-na-fifa-przestaje-sponsorowac-niemieckich-pil,nId,6427213](https://wydarzenia.interia.pl/autor/tomasz-lejman/news-firma-oburzona-na-fifa-przestaje-sponsorowac-niemieckich-pil,nId,6427213)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 15:30:23+00:00

<p><a href="https://wydarzenia.interia.pl/autor/tomasz-lejman/news-firma-oburzona-na-fifa-przestaje-sponsorowac-niemieckich-pil,nId,6427213"><img align="left" alt="Firma oburzona na FIFA. Przestaje sponsorować niemieckich piłkarzy" src="https://i.iplsc.com/firma-oburzona-na-fifa-przestaje-sponsorowac-niemieckich-pil/000GDN0VIHYD10WM-C321.jpg" /></a>Niemiecki koncern REWE, właściciel ponad 3500 supermarketów, wycofuje się ze skutkiem natychmiastowym ze współpracy z niemiecką federacją piłkarską DFB. W tle skandalu jest opaska &quot;One Love&quot;, którą kapitan reprezentacji RFN Manuel Neuer miał nosić podczas mundialu. W poniedziałek FIFA zagroziła Niemcom, że jeżeli piłkarz pojawi się na murawie z symbolicznym kolorowym sercem, drużynie grozić będą sankcje. Sponsor jest oburzony działaniami FIFA, a nieoficjalnie nie jest zadowolony, iż niemiecka federacja ugięła się pod naciskami tej światowej....</p><br clear="all" />

## Czołowe zderzenie polskiego autokaru z mercedesem. Kierowca nietrzeźwy
 - [https://wydarzenia.interia.pl/zagranica/news-czolowe-zderzenie-polskiego-autokaru-z-mercedesem-kierowca-n,nId,6427187](https://wydarzenia.interia.pl/zagranica/news-czolowe-zderzenie-polskiego-autokaru-z-mercedesem-kierowca-n,nId,6427187)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 15:14:18+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-czolowe-zderzenie-polskiego-autokaru-z-mercedesem-kierowca-n,nId,6427187"><img align="left" alt="Czołowe zderzenie polskiego autokaru z mercedesem. Kierowca nietrzeźwy" src="https://i.iplsc.com/czolowe-zderzenie-polskiego-autokaru-z-mercedesem-kierowca-n/000CTNH6W657NM87-C321.jpg" /></a>Polski autobus na autostradzie w Niemczech zderzył się czołowo z samochodem osobowym marki Mercedes. W wyniku wypadku ranne zostały dwie osoby. &quot;Na miejscu okazało się, że 54-letni kierowca autobusu znajdował się pod wpływem alkoholu&quot; - podaje portal TAG24.</p><br clear="all" />

## Marznący deszcz sparaliżował Moskwę. Korki i odwołane loty
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-marznacy-deszcz-sparalizowal-moskwe-korki-i-odwolane-loty,nId,6427204](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-marznacy-deszcz-sparalizowal-moskwe-korki-i-odwolane-loty,nId,6427204)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 15:02:23+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-marznacy-deszcz-sparalizowal-moskwe-korki-i-odwolane-loty,nId,6427204"><img align="left" alt="Marznący deszcz sparaliżował Moskwę. Korki i odwołane loty" src="https://i.iplsc.com/marznacy-deszcz-sparalizowal-moskwe-korki-i-odwolane-loty/000GDMVFDG9UKAQS-C321.jpg" /></a>Opady marznącego deszczu sparaliżowały Moskwę. Niezależny rosyjski portal &quot;Meduza&quot; informował, że korki tworzyły się w ośmiu krytycznych dla miasta punktach, a departament transportu apelował, by zostawić auta w domu. Około 30 lotów z lotnisk w Moskwie zostało odwołanych lub opóźnionych. Chwilowo zmniejszono też częstotliwość kursowania pociągów metra. Na jednej ze stacji... wyłączono zasilanie.</p><br clear="all" />

## Samorządowcy triumfują na Śląsku. "PiS jest tam, gdzie jego miejsce"
 - [https://wydarzenia.interia.pl/kraj/news-samorzadowcy-triumfuja-na-slasku-pis-jest-tam-gdzie-jego-mie,nId,6427126](https://wydarzenia.interia.pl/kraj/news-samorzadowcy-triumfuja-na-slasku-pis-jest-tam-gdzie-jego-mie,nId,6427126)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 14:51:30+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-samorzadowcy-triumfuja-na-slasku-pis-jest-tam-gdzie-jego-mie,nId,6427126"><img align="left" alt="Samorządowcy triumfują na Śląsku. &quot;PiS jest tam, gdzie jego miejsce&quot;" src="https://i.iplsc.com/samorzadowcy-triumfuja-na-slasku-pis-jest-tam-gdzie-jego-mie/000GDLT8KMFCEYM9-C321.jpg" /></a>Nie milkną echa po zmianie władzy w śląskim sejmiku wojewódzkim i porażce Prawa i Sprawiedliwości, które straciło tam władzę. Sprawę komentowali zwycięzcy samorządowcy podczas wtorkowej konferencji prasowej. - Od wielu miesięcy mówili, że pieniądze z Unii są potrzebne, że samorząd nie powinien być okradany z pieniędzy - mówił Rafał Trzaskowski. - PiS jest dzisiaj opozycją. Jest tam, gdzie jego miejsce - dodał Arkadiusz Chęciński. </p><br clear="all" />

## Gigantyczna złota rybka. Wędkarz miał niesamowite szczęście
 - [https://wydarzenia.interia.pl/zagranica/news-gigantyczna-zlota-rybka-wedkarz-mial-niesamowite-szczescie,nId,6427154](https://wydarzenia.interia.pl/zagranica/news-gigantyczna-zlota-rybka-wedkarz-mial-niesamowite-szczescie,nId,6427154)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 14:46:46+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-gigantyczna-zlota-rybka-wedkarz-mial-niesamowite-szczescie,nId,6427154"><img align="left" alt="Gigantyczna złota rybka. Wędkarz miał niesamowite szczęście" src="https://i.iplsc.com/gigantyczna-zlota-rybka-wedkarz-mial-niesamowite-szczescie/000GDLU8FEO99HNV-C321.jpg" /></a>Brytyjski wędkarz swoją zdobycz złapał na haczyk we francuskim łowisku. Gigantyczny pomarańczowy okaz potocznie określany &quot;złotą rybką&quot; został nazwany Marchewką. Ważył 30,5 kg i po pamiątkowej sesji zdjęciowej został wypuszczony do wody.</p><br clear="all" />

## Dymisje w Caritas Internationalis. Watykaniści zaskoczeni decyzją papieża
 - [https://wydarzenia.interia.pl/zagranica/news-dymisje-w-caritas-internationalis-watykanisci-zaskoczeni-dec,nId,6427184](https://wydarzenia.interia.pl/zagranica/news-dymisje-w-caritas-internationalis-watykanisci-zaskoczeni-dec,nId,6427184)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 14:46:33+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-dymisje-w-caritas-internationalis-watykanisci-zaskoczeni-dec,nId,6427184"><img align="left" alt="Dymisje w Caritas Internationalis. Watykaniści zaskoczeni decyzją papieża" src="https://i.iplsc.com/dymisje-w-caritas-internationalis-watykanisci-zaskoczeni-dec/0009TDK8VR7Q5I2U-C321.jpg" /></a>Takich zmian nie spodziewali się nawet pilnie śledzący to, co dzieje się w Watykanie. We wtorek papież Franciszek zdymisjonował kardynała Luisa Antonia Tagle ze stanowiska przewodniczącego Caritas Internationalis. Dotychczasowe posady w tej kościelnej organizacji humanitarnej stracili też jego zastępcy oraz sekretarz generalny. Stolica Apostolska podała, kto zastąpi dotychczasowego szefa.</p><br clear="all" />

## Tyle zapłacimy za Burgera Drwala. Nadchodzą "ceny grozy"?
 - [https://wydarzenia.interia.pl/kraj/news-tyle-zaplacimy-za-burgera-drwala-nadchodza-ceny-grozy,nId,6427141](https://wydarzenia.interia.pl/kraj/news-tyle-zaplacimy-za-burgera-drwala-nadchodza-ceny-grozy,nId,6427141)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 14:19:10+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tyle-zaplacimy-za-burgera-drwala-nadchodza-ceny-grozy,nId,6427141"><img align="left" alt="Tyle zapłacimy za Burgera Drwala. Nadchodzą &quot;ceny grozy&quot;?" src="https://i.iplsc.com/tyle-zaplacimy-za-burgera-drwala-nadchodza-ceny-grozy/000GDLSWK0AGGXD2-C321.jpg" /></a>&quot;Drwala też dotknęła inflacja&quot; - wynika z internetowego przecieku. Chodzi o Burger Drwala, czyli sezonową kanapkę w Mcdonald's, która cieszy się wyjątkowo dużą popularnością w jesienno-zimowe wieczory. Czy tak pozostanie także w tym sezonie? Z doniesień wynika, że gości restauracji odstraszyć mogą przede wszystkim ceny słynnego burgera. Te mają się zwiększyć nawet o 33 proc. Kiedy powróci &quot;legendarny&quot; już &quot;Drwal&quot;? Znamy datę premiery.</p><br clear="all" />

## Sekretarka z obozu Stutthof przed sądem. Niemcy żądają kary
 - [https://wydarzenia.interia.pl/zagranica/news-sekretarka-z-obozu-stutthof-przed-sadem-niemcy-zadaja-kary,nId,6427107](https://wydarzenia.interia.pl/zagranica/news-sekretarka-z-obozu-stutthof-przed-sadem-niemcy-zadaja-kary,nId,6427107)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 14:15:55+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-sekretarka-z-obozu-stutthof-przed-sadem-niemcy-zadaja-kary,nId,6427107"><img align="left" alt="Sekretarka z obozu Stutthof przed sądem. Niemcy żądają kary" src="https://i.iplsc.com/sekretarka-z-obozu-stutthof-przed-sadem-niemcy-zadaja-kary/000GDLLV4W8HNUDA-C321.jpg" /></a>W Niemczech trwa proces byłej sekretarki w niemieckim obozie koncentracyjnym Stutthof. 97-latka jest oskarżona o pomoc w tysiącach okrutnych morderstw. Prokuratura zażądała kary dwóch lat więzienia w zawieszeniu.  </p><br clear="all" />

## To nie był przypadek. W Zabrzu spłonęło kilkanaście aut
 - [https://wydarzenia.interia.pl/slaskie/news-to-nie-byl-przypadek-w-zabrzu-splonelo-kilkanascie-aut,nId,6427135](https://wydarzenia.interia.pl/slaskie/news-to-nie-byl-przypadek-w-zabrzu-splonelo-kilkanascie-aut,nId,6427135)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 13:57:52+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-to-nie-byl-przypadek-w-zabrzu-splonelo-kilkanascie-aut,nId,6427135"><img align="left" alt="To nie był przypadek. W Zabrzu spłonęło kilkanaście aut" src="https://i.iplsc.com/to-nie-byl-przypadek-w-zabrzu-splonelo-kilkanascie-aut/000GDLS105RG1RSM-C321.jpg" /></a>20 aut zostało podpalonych w Zabrzu na Śląsku w nocy z poniedziałku na wtorek. Jak wynika z informacji służb, część z pojazdów została całkowicie zniszczona. Trwa szacowanie strat. Pewne jest jednak jedno - to nie przypadek, a za podpaleniami ma stać jedna osoba.</p><br clear="all" />

## Skandal na cmentarzu w Łodzi. Z grobu zniknął drogocenny zegarek
 - [https://wydarzenia.interia.pl/lodzkie/news-skandal-na-cmentarzu-w-lodzi-z-grobu-zniknal-drogocenny-zega,nId,6427091](https://wydarzenia.interia.pl/lodzkie/news-skandal-na-cmentarzu-w-lodzi-z-grobu-zniknal-drogocenny-zega,nId,6427091)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 13:53:12+00:00

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-skandal-na-cmentarzu-w-lodzi-z-grobu-zniknal-drogocenny-zega,nId,6427091"><img align="left" alt="Skandal na cmentarzu w Łodzi. Z grobu zniknął drogocenny zegarek" src="https://i.iplsc.com/skandal-na-cmentarzu-w-lodzi-z-grobu-zniknal-drogocenny-zega/000GDLHU8Q4DIIXA-C321.jpg" /></a>Złoty zegarek obsadzony diamentami oraz złota spinka padły łupem cmentarnego złodzieja, który okradł jeden z grobowców na łódzkiej nekropolii. Policja rozpoczęła w tej sprawie dochodzenie, a rodzina zmarłego wyznaczyła nagrodę za wskazanie sprawcy w wysokości 30 tys. złotych.</p><br clear="all" />

## Wielka Brytania: Gwałt w toalecie w McDonaldzie. Zatrzymano nastolatka
 - [https://wydarzenia.interia.pl/zagranica/news-wielka-brytania-gwalt-w-toalecie-w-mcdonaldzie-zatrzymano-na,nId,6427127](https://wydarzenia.interia.pl/zagranica/news-wielka-brytania-gwalt-w-toalecie-w-mcdonaldzie-zatrzymano-na,nId,6427127)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 13:52:15+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wielka-brytania-gwalt-w-toalecie-w-mcdonaldzie-zatrzymano-na,nId,6427127"><img align="left" alt="Wielka Brytania: Gwałt w toalecie w McDonaldzie. Zatrzymano nastolatka" src="https://i.iplsc.com/wielka-brytania-gwalt-w-toalecie-w-mcdonaldzie-zatrzymano-na/000GDLQWTKFGXE8V-C321.jpg" /></a>Brytyjska policja wszczęła dochodzenie w sprawie gwałtu na 20-letniej kobiecie, do którego miało dojść w restauracji McDonald's w Telford w pobliżu Birmingham. W sprawie zatrzymano 19-letniego mężczyznę, który wyszedł na wolność po wpłaceniu kaucji. W celu ustalenia okoliczności wydarzeń, policja prosi o pomoc świadków zdarzenia.</p><br clear="all" />

## Siostra Kim Dzong Una uderza w ONZ. "Najtwardsza odpowiedź"
 - [https://wydarzenia.interia.pl/zagranica/news-siostra-kim-dzong-una-uderza-w-onz-najtwardsza-odpowiedz,nId,6427101](https://wydarzenia.interia.pl/zagranica/news-siostra-kim-dzong-una-uderza-w-onz-najtwardsza-odpowiedz,nId,6427101)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 13:32:42+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-siostra-kim-dzong-una-uderza-w-onz-najtwardsza-odpowiedz,nId,6427101"><img align="left" alt="Siostra Kim Dzong Una uderza w ONZ. &quot;Najtwardsza odpowiedź&quot;" src="https://i.iplsc.com/siostra-kim-dzong-una-uderza-w-onz-najtwardsza-odpowiedz/00085Y2A3PAAJX2J-C321.jpg" /></a>Siostra dyktatora z Korei Północnej grozi ONZ. Kim Jo Dzong skrytykowała rząd USA, a także Organizację Narodów Zjednoczonych za przeprowadzenie posiedzenia w sprawie ostatnich prób rakietowych Kim Dzong Una. Siostra Kima zagroziła władzom w Waszyngtonie &quot;najtwardszą odpowiedzią&quot;.</p><br clear="all" />

## Sensacyjna wolta na Śląsku. "Tusk powiedział mi: rób, co chcesz"
 - [https://wydarzenia.interia.pl/autor/lukasz-szpyrka/news-sensacyjna-wolta-na-slasku-tusk-powiedzial-mi-rob-co-chcesz,nId,6427071](https://wydarzenia.interia.pl/autor/lukasz-szpyrka/news-sensacyjna-wolta-na-slasku-tusk-powiedzial-mi-rob-co-chcesz,nId,6427071)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 13:20:20+00:00

<p><a href="https://wydarzenia.interia.pl/autor/lukasz-szpyrka/news-sensacyjna-wolta-na-slasku-tusk-powiedzial-mi-rob-co-chcesz,nId,6427071"><img align="left" alt="Sensacyjna wolta na Śląsku. &quot;Tusk powiedział mi: rób, co chcesz&quot;" src="https://i.iplsc.com/sensacyjna-wolta-na-slasku-tusk-powiedzial-mi-rob-co-chcesz/000GDLDSWL9IVSFS-C321.jpg" /></a>Opozycja, po czterech latach, odbiła PiS-owi sejmik województwa śląskiego. - Poniedziałkowe wydarzenia to była tylko formalność - mówi Interii prezydent Sosnowca Arkadiusz Chęciński, który wraz z prezydentem Tychów Andrzejem Dziubą stoi za sukcesem opozycji. - Donald Tusk powiedział mi: rób co chcesz, masz otwartą drogę - zdradza Chęciński.</p><br clear="all" />

## Wysoki komisarz ONZ ds. praw człowieka: Sytuacja w Iranie jest krytyczna
 - [https://wydarzenia.interia.pl/zagranica/news-wysoki-komisarz-onz-ds-praw-czlowieka-sytuacja-w-iranie-jest,nId,6427049](https://wydarzenia.interia.pl/zagranica/news-wysoki-komisarz-onz-ds-praw-czlowieka-sytuacja-w-iranie-jest,nId,6427049)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 13:15:36+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wysoki-komisarz-onz-ds-praw-czlowieka-sytuacja-w-iranie-jest,nId,6427049"><img align="left" alt="Wysoki komisarz ONZ ds. praw człowieka: Sytuacja w Iranie jest krytyczna  " src="https://i.iplsc.com/wysoki-komisarz-onz-ds-praw-czlowieka-sytuacja-w-iranie-jest/000GDLDJCUB2ACT6-C321.jpg" /></a>Na skutek krwawego tłumienia przez władze protestów w Iranie zginęło już kilkaset osób. Volker Tuerk - wysoki komisarz ONZ ds. praw człowieka - ocenia sytuację jako &quot;krytyczną&quot;. Rada ONZ rozważy wszczęcie międzynarodowego śledztwa w tej sprawie.  </p><br clear="all" />

## Makabryczny wypadek. Samochód "ciągnął" ciało seniorki przez 8 km
 - [https://wydarzenia.interia.pl/zagranica/news-makabryczny-wypadek-samochod-ciagnal-cialo-seniorki-przez-8-,nId,6427067](https://wydarzenia.interia.pl/zagranica/news-makabryczny-wypadek-samochod-ciagnal-cialo-seniorki-przez-8-,nId,6427067)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 12:58:50+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-makabryczny-wypadek-samochod-ciagnal-cialo-seniorki-przez-8-,nId,6427067"><img align="left" alt="Makabryczny wypadek. Samochód &quot;ciągnął&quot; ciało seniorki przez 8 km" src="https://i.iplsc.com/makabryczny-wypadek-samochod-ciagnal-cialo-seniorki-przez-8/000GDLDWISJBVK53-C321.jpg" /></a>Do dramatycznego zdarzenia drogowego doszło we włoskiej miejscowości Marzocca. W psa prowadzonego przez 81-letnią pieszą wjechał kierowca, zabijając zwierzę na miejscu. Gdy kobieta próbowała ratować pupila, potrącił ją kolejny nadjeżdżający pojazd. Kierowca SUV-a nawet się nie zatrzymał - ciało seniorki znaleziono 8 km od miejsca pierwszego wypadku.</p><br clear="all" />

## Bruce Lee zmarł, bo pił za dużo wody? Tak twierdzą naukowcy
 - [https://wydarzenia.interia.pl/zagranica/news-bruce-lee-zmarl-bo-pil-za-duzo-wody-tak-twierdza-naukowcy,nId,6427014](https://wydarzenia.interia.pl/zagranica/news-bruce-lee-zmarl-bo-pil-za-duzo-wody-tak-twierdza-naukowcy,nId,6427014)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 12:45:51+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bruce-lee-zmarl-bo-pil-za-duzo-wody-tak-twierdza-naukowcy,nId,6427014"><img align="left" alt="Bruce Lee zmarł, bo pił za dużo wody? Tak twierdzą naukowcy" src="https://i.iplsc.com/bruce-lee-zmarl-bo-pil-za-duzo-wody-tak-twierdza-naukowcy/000GDL1VTFLPRRLN-C321.jpg" /></a>Legenda kung fu, Bruce Lee, mógł umrzeć z powodu wypicia zbyt dużej ilości wody - twierdzą hiszpańscy naukowcy niemal pół wieku po śmierci aktora filmów akcji.</p><br clear="all" />

## Amerykański polityk: Należy zwiększyć liczebność sił NATO w Polsce
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-amerykanski-polityk-nalezy-zwiekszyc-liczebnosc-sil-nato-w-p,nId,6427050](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-amerykanski-polityk-nalezy-zwiekszyc-liczebnosc-sil-nato-w-p,nId,6427050)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 12:36:27+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-amerykanski-polityk-nalezy-zwiekszyc-liczebnosc-sil-nato-w-p,nId,6427050"><img align="left" alt="Amerykański polityk: Należy zwiększyć liczebność sił NATO w Polsce" src="https://i.iplsc.com/amerykanski-polityk-nalezy-zwiekszyc-liczebnosc-sil-nato-w-p/000GDLB5YE3A6YCV-C321.jpg" /></a>Sojusz Północnoatlantycki powinien zwiększyć liczebność wojsk stacjonujących w Polsce - powiedział Gerald Connolly, przewodniczący Zgromadzenia Parlamentarnego NATO, które od piątku do poniedziałku obradowało w Madrycie. Amerykanin dodał, że wojna w Ukrainie nie zakończy się szybko. </p><br clear="all" />

## Czeski generał: Musimy być gotowi na wojnę na dużą skalę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-czeski-general-musimy-byc-gotowi-na-wojne-na-duza-skale,nId,6427044](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-czeski-general-musimy-byc-gotowi-na-wojne-na-duza-skale,nId,6427044)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 12:31:44+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-czeski-general-musimy-byc-gotowi-na-wojne-na-duza-skale,nId,6427044"><img align="left" alt="Czeski generał: Musimy być gotowi na wojnę na dużą skalę" src="https://i.iplsc.com/czeski-general-musimy-byc-gotowi-na-wojne-na-duza-skale/000GDLAVPOCN9CVI-C321.jpg" /></a>Jeśli dojdzie do starcia między Rosją a NATO, czeskie wojsko będzie jego uczestnikiem od pierwszej minuty - powiedział we wtorek szef sztabu generalnego Czech gen. Kamil Rzehka na dorocznej odprawie dowództwa. - Czeska armia musi przygotować się do wojny na dużą skalę z zaawansowanym przeciwnikiem - dodał. Prezydent Milosz Zeman, który brał udział w naradzie, potwierdził swoje pełne poparcie dla Ukrainy.</p><br clear="all" />

## "Szokująca decyzja" w Berlinie. Chodzi o wypowiedź o "50 holokaustach"
 - [https://wydarzenia.interia.pl/zagranica/news-szokujaca-decyzja-w-berlinie-chodzi-o-wypowiedz-o-50-holokau,nId,6427037](https://wydarzenia.interia.pl/zagranica/news-szokujaca-decyzja-w-berlinie-chodzi-o-wypowiedz-o-50-holokau,nId,6427037)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 12:24:21+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-szokujaca-decyzja-w-berlinie-chodzi-o-wypowiedz-o-50-holokau,nId,6427037"><img align="left" alt="&quot;Szokująca decyzja&quot; w Berlinie. Chodzi o wypowiedź o &quot;50 holokaustach&quot; " src="https://i.iplsc.com/szokujaca-decyzja-w-berlinie-chodzi-o-wypowiedz-o-50-holokau/0007PPYO56EH8R38-C321.jpg" /></a>W dwustronicowym uzasadnieniu, do którego dotarł &quot;Bild&quot;, berlińska prokuratura wyjaśnia niepodjęcie śledztwa w sprawie Mahmuda Abbasa. Przywódca Autonomii Palestyńskiej oskarżył Izrael o popełnienie &quot;50 holokaustów&quot;. &quot;To szokująca decyzja&quot; - ostro komentuje &quot;Bild&quot;.</p><br clear="all" />

## Posypią się kary dla przedsiębiorców. Dotarliśmy do wewnętrznych wytycznych
 - [https://wydarzenia.interia.pl/news-posypia-sie-kary-dla-przedsiebiorcow-dotarlismy-do-wewnetrzn,nId,6426957](https://wydarzenia.interia.pl/news-posypia-sie-kary-dla-przedsiebiorcow-dotarlismy-do-wewnetrzn,nId,6426957)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 11:59:00+00:00

<p><a href="https://wydarzenia.interia.pl/news-posypia-sie-kary-dla-przedsiebiorcow-dotarlismy-do-wewnetrzn,nId,6426957"><img align="left" alt="Posypią się kary dla przedsiębiorców. Dotarliśmy do wewnętrznych wytycznych" src="https://i.iplsc.com/posypia-sie-kary-dla-przedsiebiorcow-dotarlismy-do-wewnetrzn/000GDL15UEETXAL4-C321.jpg" /></a>Jak ustaliła Interia, Państwowa Inspekcja Pracy domaga się od swoich inspektorów, aby wlepiali kontrolowanym przedsiębiorcom wyższe kary. &quot;Więcej mandatów i najlepiej wyższych niż 1000 zł&quot; - w korespondencji ze swoim zespołem pisze wprost jeden z łódzkich nadinspektorów. - Takie funkcjonowanie instytucji pokazuje, że państwo się psuje - uważa prof. Jacek Męcina, specjalista z zakresu prawa pracy i członek Rady Ochrony Pracy.</p><br clear="all" />

## Litwa usunie pomnik z cmentarza sowieckich żołnierzy. Mimo sprzeciwu ONZ
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-litwa-usunie-pomnik-z-cmentarza-sowieckich-zolnierzy-mimo-sp,nId,6426966](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-litwa-usunie-pomnik-z-cmentarza-sowieckich-zolnierzy-mimo-sp,nId,6426966)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 11:53:09+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-litwa-usunie-pomnik-z-cmentarza-sowieckich-zolnierzy-mimo-sp,nId,6426966"><img align="left" alt="Litwa usunie pomnik z cmentarza sowieckich żołnierzy. Mimo sprzeciwu ONZ" src="https://i.iplsc.com/litwa-usunie-pomnik-z-cmentarza-sowieckich-zolnierzy-mimo-sp/000GDKVTUJ67KAQT-C321.jpg" /></a>Komitet Praw Człowieka ONZ nie wyraził zgody na usunięcie pomnika żołnierzy radzieckich na Cmentarzu Antokolskim w Wilnie, argumentując, że leżą pod nim pochowani polegli. Mer litewskiej stolicy oświadczył jednak we wtorek, że demontaż monumentu wkrótce się rozpocznie, bo organ Narodów Zjednoczonych został wprowadzony w błąd. &quot;Wojna toczy się teraz, więc nie będziemy czekać (aż sprawa się wyjaśni)&quot; - powiedział Remigijus Szimaszius.</p><br clear="all" />

## Działaczka Razem oburzona zarobkami Lewandowskiego. Teraz "wyjaśnia"
 - [https://wydarzenia.interia.pl/kraj/news-dzialaczka-razem-oburzona-zarobkami-lewandowskiego-teraz-wyj,nId,6426992](https://wydarzenia.interia.pl/kraj/news-dzialaczka-razem-oburzona-zarobkami-lewandowskiego-teraz-wyj,nId,6426992)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 11:53:05+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-dzialaczka-razem-oburzona-zarobkami-lewandowskiego-teraz-wyj,nId,6426992"><img align="left" alt="Działaczka Razem oburzona zarobkami Lewandowskiego. Teraz &quot;wyjaśnia&quot;" src="https://i.iplsc.com/dzialaczka-razem-oburzona-zarobkami-lewandowskiego-teraz-wyj/000GDKZALS7LE8Y8-C321.jpg" /></a>Robert i Anna Lewandowscy wsparli Centrum Zdrowia Dziecka, a ich wpłata pozwoliła na zakup sprzętu o wartości pół miliona złotych. Za swój gest kapitan reprezentacji Polski w piłce nożnej spotkał się z nieoczekiwaną krytyką ze strony działaczki partii Razem Doroty Spyrki, która wykorzystała sytuację, by zwrócić uwagę na wysokie zarobki piłkarzy. Po fali krytyki ze strony internautów, Spyrka postanowiła &quot;wytłumaczyć&quot; swój komentarz w serii wpisów.</p><br clear="all" />

## Chciała wejść na stadion. Kazano jej zdjąć tęczowy kapelusz
 - [https://wydarzenia.interia.pl/zagranica/news-chciala-wejsc-na-stadion-kazano-jej-zdjac-teczowy-kapelusz,nId,6426936](https://wydarzenia.interia.pl/zagranica/news-chciala-wejsc-na-stadion-kazano-jej-zdjac-teczowy-kapelusz,nId,6426936)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 11:48:06+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chciala-wejsc-na-stadion-kazano-jej-zdjac-teczowy-kapelusz,nId,6426936"><img align="left" alt="Chciała wejść na stadion. Kazano jej zdjąć tęczowy kapelusz" src="https://i.iplsc.com/chciala-wejsc-na-stadion-kazano-jej-zdjac-teczowy-kapelusz/000GDKP2KD6RCE0R-C321.jpg" /></a>Laura McAllister, była walijska piłkarka, przedstawiła w internecie relację z kłopotliwej sytuacji, do której doszło w trakcie kontroli przed meczem narodowej drużyny na mistrzostwach świata w Katarze. Ochrona poprosiła ją o zdjęcie kolorowej czapki, zakazując wejścia na stadion w tym nakryciu głowy. Całe zdarzenie zostało nagrane.</p><br clear="all" />

## Bydgoszcz: Niemowlę znalezione w Oknie Życia
 - [https://wydarzenia.interia.pl/kujawsko-pomorskie/news-bydgoszcz-niemowle-znalezione-w-oknie-zycia,nId,6426978](https://wydarzenia.interia.pl/kujawsko-pomorskie/news-bydgoszcz-niemowle-znalezione-w-oknie-zycia,nId,6426978)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 11:39:48+00:00

<p><a href="https://wydarzenia.interia.pl/kujawsko-pomorskie/news-bydgoszcz-niemowle-znalezione-w-oknie-zycia,nId,6426978"><img align="left" alt="Bydgoszcz: Niemowlę znalezione w Oknie Życia" src="https://i.iplsc.com/bydgoszcz-niemowle-znalezione-w-oknie-zycia/000CVVGCD7W1BJSD-C321.jpg" /></a>Trzymiesięczne dziecko zostało znalezione w Oknie Życia w Bydgoszczy. Niemowlę znalazły dyżurujące tego dnia siostry klaryski. Zdrowy chłopiec został już przewieziony do szpitala na rutynowe badania. Teraz czeka na &quot;nowy etap&quot; życia.</p><br clear="all" />

## Fałszywy telefon do Andrzeja Dudy. Myślał, że rozmawia z prezydentem Francji
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-falszywy-telefon-do-andrzeja-dudy-myslal-ze-rozmawia-z-prezy,nId,6426953](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-falszywy-telefon-do-andrzeja-dudy-myslal-ze-rozmawia-z-prezy,nId,6426953)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 11:25:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-falszywy-telefon-do-andrzeja-dudy-myslal-ze-rozmawia-z-prezy,nId,6426953"><img align="left" alt="Fałszywy telefon do Andrzeja Dudy. Myślał, że rozmawia z prezydentem Francji" src="https://i.iplsc.com/falszywy-telefon-do-andrzeja-dudy-myslal-ze-rozmawia-z-prezy/000GDKTWNE4B8APR-C321.jpg" /></a>Prezydent RP Andrzej Duda miał rozmawiać z osobami podającymi się za prezydenta Francji Emmaunela Macrona. Pałac Prezydencki wydał w tej sprawie oświadczenie. &quot;W trakcie połączenia Prezydent Andrzej Duda zorientował się po nietypowym sposobie prowadzenia rozmowy przez rozmówcę, że mogło dojść do próby oszustwa i zakończył rozmowę&quot; - czytamy w komunikacie.
 </p><br clear="all" />

## Niż Denise nad Morzem Śródziemnym. Do Polski dotrze pod koniec tygodnia
 - [https://wydarzenia.interia.pl/kraj/news-niz-denise-nad-morzem-srodziemnym-do-polski-dotrze-pod-konie,nId,6426900](https://wydarzenia.interia.pl/kraj/news-niz-denise-nad-morzem-srodziemnym-do-polski-dotrze-pod-konie,nId,6426900)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 11:12:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-niz-denise-nad-morzem-srodziemnym-do-polski-dotrze-pod-konie,nId,6426900"><img align="left" alt="Niż Denise nad Morzem Śródziemnym. Do Polski dotrze pod koniec tygodnia" src="https://i.iplsc.com/niz-denise-nad-morzem-srodziemnym-do-polski-dotrze-pod-konie/000GDKMXLOKR9XXX-C321.jpg" /></a>Na południu Europy utworzył się niż Denise. Pojawią się śnieżyce, wichury i burze. Pod koniec tygodnia ma on dotrzeć do Polski. W nocy ze środy na czwartek w południowej i wschodniej części kraju przyniesie obfite opady śniegu.</p><br clear="all" />

## Viktor Orban wywołał skandal na meczu. Chodzi o jego szalik
 - [https://wydarzenia.interia.pl/zagranica/news-viktor-orban-wywolal-skandal-na-meczu-chodzi-o-jego-szalik,nId,6426864](https://wydarzenia.interia.pl/zagranica/news-viktor-orban-wywolal-skandal-na-meczu-chodzi-o-jego-szalik,nId,6426864)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 10:58:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-viktor-orban-wywolal-skandal-na-meczu-chodzi-o-jego-szalik,nId,6426864"><img align="left" alt="Viktor Orban wywołał skandal na meczu. Chodzi o jego szalik" src="https://i.iplsc.com/viktor-orban-wywolal-skandal-na-meczu-chodzi-o-jego-szalik/0007V8X2N72N6UQ9-C321.jpg" /></a>W piątek podczas meczu reprezentacji piłkarskiej premier Węgier Viktor Orban pokazał się publicznie w szaliku z symbolem &quot;Wielkich Węgier&quot;. Chodzi o mapę, która przedstawia granice kraju obejmujące tereny należące do sąsiednich państw. Rumuński europoseł nazwał gest szefa węgierskiego rządu rewizjonistycznym. &quot;Orban powinien zostać ukarany i odizolowany przez przywódców UE w Radzie Europejskiej&quot; - napisał Alin Mituța na Twitterze.</p><br clear="all" />

## Gdańsk. Bezdomna mieszkała z córką w lesie. Dwulatka w szpitalu
 - [https://wydarzenia.interia.pl/pomorskie/news-gdansk-bezdomna-mieszkala-z-corka-w-lesie-dwulatka-w-szpital,nId,6426917](https://wydarzenia.interia.pl/pomorskie/news-gdansk-bezdomna-mieszkala-z-corka-w-lesie-dwulatka-w-szpital,nId,6426917)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 10:33:25+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-gdansk-bezdomna-mieszkala-z-corka-w-lesie-dwulatka-w-szpital,nId,6426917"><img align="left" alt="Gdańsk. Bezdomna mieszkała z córką w lesie. Dwulatka w szpitalu" src="https://i.iplsc.com/gdansk-bezdomna-mieszkala-z-corka-w-lesie-dwulatka-w-szpital/000GDKNC4EPDPF20-C321.jpg" /></a>24-letnia bezdomna matka mieszkała w lesie z dwuletnią córką. Ze namiotu wydobywał się dym papierosowy, jednak wejścia do środka &quot;strzegli&quot; inni bezdomni. Jak się okazało, przebywającego tam dziecko było wygłodzone i ubrane jedynie w koszulkę z krótkim rękawem.</p><br clear="all" />

## Cztery dni pracy i trzy dni weekendu? Zmiany w kodeksie pracy
 - [https://wydarzenia.interia.pl/kraj/news-cztery-dni-pracy-i-trzy-dni-weekendu-zmiany-w-kodeksie-pracy,nId,6426832](https://wydarzenia.interia.pl/kraj/news-cztery-dni-pracy-i-trzy-dni-weekendu-zmiany-w-kodeksie-pracy,nId,6426832)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 10:30:03+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-cztery-dni-pracy-i-trzy-dni-weekendu-zmiany-w-kodeksie-pracy,nId,6426832"><img align="left" alt="Cztery dni pracy i trzy dni weekendu? Zmiany w kodeksie pracy " src="https://i.iplsc.com/cztery-dni-pracy-i-trzy-dni-weekendu-zmiany-w-kodeksie-pracy/000GDK3CEPF0OG8U-C321.jpg" /></a>Tydzień pracy ma zostać skrócony przy zachowaniu tego samego wynagrodzenia - wynika z projektu ustawy nowelizującego Kodeks pracy. Nie wiadomo jeszcze, w jaki sposób zostanie to ujednolicone przez ustawodawcę. W grę wchodzą cztery dni pracy i trzy dni weekendu lub zmniejszenie wymiaru czasu wykonywania obowiązków z 40 do 35 godzin. Projekt nowych przepisów znalazł się już w Sejmie.</p><br clear="all" />

## Będzie nowa edycja programu "Mój prąd". Minister zdradza szczegóły
 - [https://wydarzenia.interia.pl/kraj/news-bedzie-nowa-edycja-programu-moj-prad-minister-zdradza-szczeg,nId,6426910](https://wydarzenia.interia.pl/kraj/news-bedzie-nowa-edycja-programu-moj-prad-minister-zdradza-szczeg,nId,6426910)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 10:26:30+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-bedzie-nowa-edycja-programu-moj-prad-minister-zdradza-szczeg,nId,6426910"><img align="left" alt="Będzie nowa edycja programu &quot;Mój prąd&quot;. Minister zdradza szczegóły" src="https://i.iplsc.com/bedzie-nowa-edycja-programu-moj-prad-minister-zdradza-szczeg/000GDKJOJDBHFQG2-C321.jpg" /></a>Anna Moskwa, minister klimatu i środowiska, zapowiedziała, że w grudniu ruszy nowa edycja programu “Mój Prąd”, który wspiera rozwój energetyki prosumenckiej. O dofinansowanie mogą się ubiegać indywidualni prosumenci oraz magazyny energii. </p><br clear="all" />

## Miał rozmawiać "z duchem pacjentki". Nagranie ze szpitala obiegło sieć
 - [https://wydarzenia.interia.pl/zagranica/news-mial-rozmawiac-z-duchem-pacjentki-nagranie-ze-szpitala-obieg,nId,6426908](https://wydarzenia.interia.pl/zagranica/news-mial-rozmawiac-z-duchem-pacjentki-nagranie-ze-szpitala-obieg,nId,6426908)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 10:25:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-mial-rozmawiac-z-duchem-pacjentki-nagranie-ze-szpitala-obieg,nId,6426908"><img align="left" alt="Miał rozmawiać &quot;z duchem pacjentki&quot;. Nagranie ze szpitala obiegło sieć" src="https://i.iplsc.com/mial-rozmawiac-z-duchem-pacjentki-nagranie-ze-szpitala-obieg/000GDKK2KJ0DWHP2-C321.jpg" /></a>Automatyczne drzwi otwierają się, ale nikt przez nie przechodzi. Następnie ochroniarz szpitala &quot;wita się&quot; z osobą, której nie widać na kamerach monitoringu i prowadzi ją do gabinetu lekarza. Nagranie, na którym pracownik rzekomo przywitał się z duchem zmarłej pacjentki obiegło media społecznościowe. Władze szpitala zapewniają, że sprawa jest wyjaśniana, ale już teraz mają proste wytłumaczenie &quot;zjawiska paranormalnego&quot;.</p><br clear="all" />

## Wielka Brytania przekazuje Ukrainie nowszą wersję pocisku Brimstone
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wielka-brytania-przekazuje-ukrainie-nowsza-wersje-pocisku-br,nId,6426866](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wielka-brytania-przekazuje-ukrainie-nowsza-wersje-pocisku-br,nId,6426866)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 10:10:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wielka-brytania-przekazuje-ukrainie-nowsza-wersje-pocisku-br,nId,6426866"><img align="left" alt="Wielka Brytania przekazuje Ukrainie nowszą wersję pocisku Brimstone " src="https://i.iplsc.com/wielka-brytania-przekazuje-ukrainie-nowsza-wersje-pocisku-br/000GDKARO6SI7FLO-C321.jpg" /></a>Brytyjczycy wyślą na Ukrainę pociski Brimstone 2. To nowa, bardziej zaawansowana wersja laserowo naprowadzanego pocisku, o dwukrotnie większym zasięgu niż podstawowy model.</p><br clear="all" />

## Trzaskowski o Chełstowskim: To nigdy nie był PiS-owski aparatczyk
 - [https://wydarzenia.interia.pl/kraj/news-trzaskowski-o-chelstowskim-to-nigdy-nie-byl-pis-owski-aparat,nId,6426876](https://wydarzenia.interia.pl/kraj/news-trzaskowski-o-chelstowskim-to-nigdy-nie-byl-pis-owski-aparat,nId,6426876)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 09:55:21+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-trzaskowski-o-chelstowskim-to-nigdy-nie-byl-pis-owski-aparat,nId,6426876"><img align="left" alt="Trzaskowski o Chełstowskim: To nigdy nie był PiS-owski aparatczyk" src="https://i.iplsc.com/trzaskowski-o-chelstowskim-to-nigdy-nie-byl-pis-owski-aparat/000FOON2UMJX06UT-C321.jpg" /></a>- To nigdy nie był taki klasyczny PiS-owski aparatczyk. To samorządowiec z krwi i kości - mówił Rafał Trzaskowski, prezydent Warszawy o marszałku woj. śląskiego Jakubie Chełstowskim. Polityk założył klub &quot;Tak! Dla Polski&quot;, odbierając jednocześnie większość PiS-owi w sejmiku woj. śląskiego.</p><br clear="all" />

## Można dostać nawet 10 tys. zł pomocy. Nowy termin składania wniosków
 - [https://wydarzenia.interia.pl/kraj/news-mozna-dostac-nawet-10-tys-zl-pomocy-nowy-termin-skladania-wn,nId,6424817](https://wydarzenia.interia.pl/kraj/news-mozna-dostac-nawet-10-tys-zl-pomocy-nowy-termin-skladania-wn,nId,6424817)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 09:33:07+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-mozna-dostac-nawet-10-tys-zl-pomocy-nowy-termin-skladania-wn,nId,6424817"><img align="left" alt="Można dostać nawet 10 tys. zł pomocy. Nowy termin składania wniosków" src="https://i.iplsc.com/mozna-dostac-nawet-10-tys-zl-pomocy-nowy-termin-skladania-wn/000G604KERMUFJGM-C321.jpg" /></a>Termin składania wniosków o pomoc suszową 2022 został wydłużony z powodu awarii aplikacji niezbędnej do uzyskania protokołu. Zgodnie z nowym rozporządzeniem polscy rolnicy, którzy ponieśli straty w gospodarstwach z powodu niekorzystnych zjawisk atmosferycznych, mogą ubiegać się o rekompensaty do końca listopada. Otrzymanie pieniędzy nie będzie jednak łatwe z uwagi na nowe wytyczne Ministerstwa Rolnictwa i Rozwoju Wsi. </p><br clear="all" />

## Ta grupa może liczyć nawet na 10 tys. zł pomocy. Jest nowy termin składania wniosków
 - [https://wydarzenia.interia.pl/kraj/news-ta-grupa-moze-liczyc-nawet-na-10-tys-zl-pomocy-jest-nowy-ter,nId,6424817](https://wydarzenia.interia.pl/kraj/news-ta-grupa-moze-liczyc-nawet-na-10-tys-zl-pomocy-jest-nowy-ter,nId,6424817)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 09:33:07+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ta-grupa-moze-liczyc-nawet-na-10-tys-zl-pomocy-jest-nowy-ter,nId,6424817"><img align="left" alt="Ta grupa może liczyć nawet na 10 tys. zł pomocy. Jest nowy termin składania wniosków" src="https://i.iplsc.com/ta-grupa-moze-liczyc-nawet-na-10-tys-zl-pomocy-jest-nowy-ter/000G604KERMUFJGM-C321.jpg" /></a>Termin składania wniosków o pomoc suszową 2022 został wydłużony z powodu awarii aplikacji niezbędnej do uzyskania protokołu. Zgodnie z nowym rozporządzeniem polscy rolnicy, którzy ponieśli straty w gospodarstwach z powodu niekorzystnych zjawisk atmosferycznych, mogą ubiegać się o rekompensaty do końca listopada. Otrzymanie pieniędzy nie będzie jednak łatwe z uwagi na nowe wytyczne Ministerstwa Rolnictwa i Rozwoju Wsi. </p><br clear="all" />

## Były senator Józef Pinior prawomocnie skazany
 - [https://wydarzenia.interia.pl/kraj/news-byly-senator-jozef-pinior-prawomocnie-skazany,nId,6426852](https://wydarzenia.interia.pl/kraj/news-byly-senator-jozef-pinior-prawomocnie-skazany,nId,6426852)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 09:28:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-byly-senator-jozef-pinior-prawomocnie-skazany,nId,6426852"><img align="left" alt="Były senator Józef Pinior prawomocnie skazany" src="https://i.iplsc.com/byly-senator-jozef-pinior-prawomocnie-skazany/000GDKBFVLCWK3TS-C321.jpg" /></a>Józef Pinior, były senator, działacz dolnośląskiej &quot;Solidarności&quot; został prawomocnie skazany na 8 miesięcy pozbawienia wolności - orzekł Sąd Okręgowy we Wrocławiu. Kara jednak jest zawieszona na okres roku próby. Sąd obniżył wyrok z pierwszej instancji. Byłego senatora uznano winnym fałszerstw w zeznaniach majątkowych.</p><br clear="all" />

## Pirat drogowy na wiadukcie. Nie chciał stać w korku, pojechał chodnikiem
 - [https://wydarzenia.interia.pl/mazowieckie/news-pirat-drogowy-na-wiadukcie-nie-chcial-stac-w-korku-pojechal-,nId,6426766](https://wydarzenia.interia.pl/mazowieckie/news-pirat-drogowy-na-wiadukcie-nie-chcial-stac-w-korku-pojechal-,nId,6426766)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 09:22:08+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-pirat-drogowy-na-wiadukcie-nie-chcial-stac-w-korku-pojechal-,nId,6426766"><img align="left" alt="Pirat drogowy na wiadukcie. Nie chciał stać w korku, pojechał chodnikiem" src="https://i.iplsc.com/pirat-drogowy-na-wiadukcie-nie-chcial-stac-w-korku-pojechal/000GDJNCKSCAE6P0-C321.jpg" /></a>Gdyby nie nagranie, trudno byłoby uwierzyć w tę sytuację. Kierowcy z Warszawy tak się spieszyło, że aby uniknąć stania w korku, wybrał alternatywną trasę. Prowadziła ona... chodnikiem na wiadukcie. Jego zachowanie było bardzo niebezpieczne - wąskim przejściem szła w tym samym momencie kobieta, która musiała ustąpić piratowi drogowemu. Bezmyślne zachowanie udokumentował inny, jadący tuż obok uczestnik ruchu.</p><br clear="all" />

## Belgowie mogą wybrać, czy wolą pracować cztery czy pięć dni w tygodniu
 - [https://wydarzenia.interia.pl/zagranica/news-belgowie-moga-wybrac-czy-wola-pracowac-cztery-czy-piec-dni-w,nId,6426789](https://wydarzenia.interia.pl/zagranica/news-belgowie-moga-wybrac-czy-wola-pracowac-cztery-czy-piec-dni-w,nId,6426789)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 08:58:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-belgowie-moga-wybrac-czy-wola-pracowac-cztery-czy-piec-dni-w,nId,6426789"><img align="left" alt="Belgowie mogą wybrać, czy wolą pracować cztery czy pięć dni w tygodniu" src="https://i.iplsc.com/belgowie-moga-wybrac-czy-wola-pracowac-cztery-czy-piec-dni-w/000GDJWQE4GV2N7X-C321.jpg" /></a>Decyzją rządu Belgowie będą zdecydować się na czterodniowy tydzień pracy zamiast pięciodniowego. Jednak w obu wariantach przepracują podobną liczbę godzin.</p><br clear="all" />

## Ciężarówka w rowie. Przyczyną było zderzenie się lusterkami z innym autem
 - [https://wydarzenia.interia.pl/lubelskie/news-ciezarowka-w-rowie-przyczyna-bylo-zderzenie-sie-lusterkami-z,nId,6426821](https://wydarzenia.interia.pl/lubelskie/news-ciezarowka-w-rowie-przyczyna-bylo-zderzenie-sie-lusterkami-z,nId,6426821)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 08:55:53+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-ciezarowka-w-rowie-przyczyna-bylo-zderzenie-sie-lusterkami-z,nId,6426821"><img align="left" alt="Ciężarówka w rowie. Przyczyną było zderzenie się lusterkami z innym autem" src="https://i.iplsc.com/ciezarowka-w-rowie-przyczyna-bylo-zderzenie-sie-lusterkami-z/000GDK0F310VGMS5-C321.jpg" /></a>Samochód ciężarowy z ładunkiem rzepaku wpadł do rowu. Prawdopodobną przyczyną wypadku było zderzenie się lusterkami z innym pojazdem ciężarowym - przekazała policja. Funkcjonariusze ustalają szczegółowe okoliczności wypadku.</p><br clear="all" />

## "NYT" potwierdza autentyczność nagrań z zastrzelonymi Rosjanami
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nyt-potwierdza-autentycznosc-nagran-z-zastrzelonymi-rosjanam,nId,6426803](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nyt-potwierdza-autentycznosc-nagran-z-zastrzelonymi-rosjanam,nId,6426803)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 08:38:38+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nyt-potwierdza-autentycznosc-nagran-z-zastrzelonymi-rosjanam,nId,6426803"><img align="left" alt="&quot;NYT&quot; potwierdza autentyczność nagrań z zastrzelonymi Rosjanami" src="https://i.iplsc.com/nyt-potwierdza-autentycznosc-nagran-z-zastrzelonymi-rosjanam/000GDJXT6AWPT1M5-C321.jpg" /></a>Dziennik &quot;New York Times&quot; potwierdził autentyczność nagrań, które dokumentują zastrzelenie rosyjskich żołnierzy we wsi Makiejewka w obwodzie ługańskim. Według władz Kremla - ukraińskie wojsko popełniło zbrodnie wojenne zabijając wojskowych, którzy zdążyli się poddać. Kijów zaprzecza zarzutom. Tłumaczy, że Rosjanie udali kapitulację i wykorzystali moment do otwarcia ognia, co widać na jednym z nagrań. Ukraińcy mieli działać w samoobronie.</p><br clear="all" />

## Straż Graniczna: 55 osób próbowało przekroczyć granicę polsko-białoruską
 - [https://wydarzenia.interia.pl/podlaskie/news-straz-graniczna-55-osob-probowalo-przekroczyc-granice-polsko,nId,6426770](https://wydarzenia.interia.pl/podlaskie/news-straz-graniczna-55-osob-probowalo-przekroczyc-granice-polsko,nId,6426770)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 08:26:00+00:00

<p><a href="https://wydarzenia.interia.pl/podlaskie/news-straz-graniczna-55-osob-probowalo-przekroczyc-granice-polsko,nId,6426770"><img align="left" alt="Straż Graniczna: 55 osób próbowało przekroczyć granicę polsko-białoruską" src="https://i.iplsc.com/straz-graniczna-55-osob-probowalo-przekroczyc-granice-polsko/000GDJPTMBNEYQQI-C321.jpg" /></a>Minionej doby 55 cudzoziemców podjęło próbę przedostania się z Białorusi do Polski - poinformowała Straż Graniczna. Niektórzy z nich próbowali przeprawić się przez rzekę. Dane SG przekazują, że od początku listopada zarejestrowano ponad 1,6 tys. prób nielegalnego przekroczenia granicy.</p><br clear="all" />

## Wyrok za wypadek autobusu w stolicy. Siedem lat więzienia dla kierowcy
 - [https://wydarzenia.interia.pl/mazowieckie/news-wyrok-za-wypadek-autobusu-w-stolicy-siedem-lat-wiezienia-dla,nId,6426780](https://wydarzenia.interia.pl/mazowieckie/news-wyrok-za-wypadek-autobusu-w-stolicy-siedem-lat-wiezienia-dla,nId,6426780)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 08:19:00+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-wyrok-za-wypadek-autobusu-w-stolicy-siedem-lat-wiezienia-dla,nId,6426780"><img align="left" alt="Wyrok za wypadek autobusu w stolicy. Siedem lat więzienia dla kierowcy" src="https://i.iplsc.com/wyrok-za-wypadek-autobusu-w-stolicy-siedem-lat-wiezienia-dla/000GDJSPSNVIVVUJ-C321.jpg" /></a>Wyrok w procesie kierowcy, który spowodował w Warszawie w 2020 wypadek autobusu na moście Grota-Roweckiego. Pojazd spadł z wiaduktu, zginęła pasażerka, wielu podróżnych zostało rannych. Warszawski sąd skazał Tomasza U. na siedem lat więzienia i dożywotni zakaz prowadzenia wszelkich pojazdów.</p><br clear="all" />

## Błaszczak o nominacji dla Melnyka: Cieszy się z niej lokator Kremla
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-blaszczak-o-nominacji-dla-melnyka-cieszy-sie-z-niej-lokator-,nId,6426746](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-blaszczak-o-nominacji-dla-melnyka-cieszy-sie-z-niej-lokator-,nId,6426746)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 07:45:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-blaszczak-o-nominacji-dla-melnyka-cieszy-sie-z-niej-lokator-,nId,6426746"><img align="left" alt="Błaszczak o nominacji dla Melnyka: Cieszy się z niej lokator Kremla" src="https://i.iplsc.com/blaszczak-o-nominacji-dla-melnyka-cieszy-sie-z-niej-lokator/000GDJH6IPYQTV0E-C321.jpg" /></a>To zła decyzja, uważam, że oprócz samego zainteresowanego, z tej decyzji cieszy się jeszcze jeden, lokator Kremla - powiedział wicepremier i szef MON Mariusz Błaszczak o mianowaniu Andrija Melnyka na wiceszefa MSZ Ukrainy. - To zły sygnał - dodał minister.</p><br clear="all" />

## Agencja AP zwolniła reportera, który podał fałszywą informację o Przewodowie
 - [https://wydarzenia.interia.pl/zagranica/news-agencja-ap-zwolnila-reportera-ktory-podal-falszywa-informacj,nId,6426755](https://wydarzenia.interia.pl/zagranica/news-agencja-ap-zwolnila-reportera-ktory-podal-falszywa-informacj,nId,6426755)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 07:40:22+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-agencja-ap-zwolnila-reportera-ktory-podal-falszywa-informacj,nId,6426755"><img align="left" alt="Agencja AP zwolniła reportera, który podał fałszywą informację o Przewodowie" src="https://i.iplsc.com/agencja-ap-zwolnila-reportera-ktory-podal-falszywa-informacj/000GDJJQYJWUMK1D-C321.jpg" /></a>Dziennikarz Associated Press James LaPorta podał nieprawdziwą informację, sugerującą po wybuchu w Przewodowie, że Rosja przeprowadziła atak rakietowy na Polskę. Został zwolniony. </p><br clear="all" />

## Tragiczny wypadek. 18-latek kierował, 13-latka zginęła na miejscu
 - [https://wydarzenia.interia.pl/lubelskie/news-tragiczny-wypadek-18-latek-kierowal-13-latka-zginela-na-miej,nId,6426753](https://wydarzenia.interia.pl/lubelskie/news-tragiczny-wypadek-18-latek-kierowal-13-latka-zginela-na-miej,nId,6426753)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 07:38:47+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-tragiczny-wypadek-18-latek-kierowal-13-latka-zginela-na-miej,nId,6426753"><img align="left" alt="Tragiczny wypadek. 18-latek kierował, 13-latka zginęła na miejscu" src="https://i.iplsc.com/tragiczny-wypadek-18-latek-kierowal-13-latka-zginela-na-miej/000GDJH758R5ELUG-C321.jpg" /></a>18-latek zjechał na pobocze i uderzył samochodem w drzewo. Na miejscu zginęła 13-letnia pasażerka - przekazała policja. Kierowca auta z poważnymi obrażeniami ciała został przewieziony do szpitala.</p><br clear="all" />

## "Pasażerowie mają obawy". Rzecznik PiS pyta o bilety PKP Intercity
 - [https://wydarzenia.interia.pl/raporty/raport-transport-publiczny/aktualnosci/news-pasazerowie-maja-obawy-rzecznik-pis-pyta-o-bilety-pkp-interc,nId,6425312](https://wydarzenia.interia.pl/raporty/raport-transport-publiczny/aktualnosci/news-pasazerowie-maja-obawy-rzecznik-pis-pyta-o-bilety-pkp-interc,nId,6425312)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 07:07:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-transport-publiczny/aktualnosci/news-pasazerowie-maja-obawy-rzecznik-pis-pyta-o-bilety-pkp-interc,nId,6425312"><img align="left" alt="&quot;Pasażerowie mają obawy&quot;. Rzecznik PiS pyta o bilety PKP Intercity" src="https://i.iplsc.com/pasazerowie-maja-obawy-rzecznik-pis-pyta-o-bilety-pkp-interc/000GDHLHFV7D97AQ-C321.jpg" /></a>Gdy bilet na PKP Intercity kupujemy przez internet, musimy podać imię i nazwisko, a w pociągu pokazać konduktorowi dokument tożsamości - nawet jeśli nie przysługują nam zniżki. Jeżeli jednak w podróż zabierzemy bilet wydany w kasie, to nasza tożsamość pozostanie tajemnicą. Rzecznik PiS Radosław Fogiel alarmuje, że &quot;pasażerowie mają obawy dotyczące prywatności&quot;, a przewoźnik na łamach Interii tłumaczy, że w ten sposób chroni się przed oszustami.</p><br clear="all" />

## Rosjanie palili ciała żołnierzy na śmietnisku? Odkrycie w Chersoniu
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-palili-ciala-zolnierzy-na-smietnisku-odkrycie-w-che,nId,6426702](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-palili-ciala-zolnierzy-na-smietnisku-odkrycie-w-che,nId,6426702)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 07:03:06+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-palili-ciala-zolnierzy-na-smietnisku-odkrycie-w-che,nId,6426702"><img align="left" alt="Rosjanie palili ciała żołnierzy na śmietnisku? Odkrycie w Chersoniu" src="https://i.iplsc.com/rosjanie-palili-ciala-zolnierzy-na-smietnisku-odkrycie-w-che/000GDIP9CN99MBSY-C321.jpg" /></a>Korespondent brytyjskiego dziennika &quot;The Guardian&quot; dotarł w wyzwolonym Chersoniu do świadków, którzy twierdzą, że Rosjanie palili na miejscowym wysypisku zwłoki zabitych w walce żołnierzy. Ciała w czarnych workach były zwożone ciężarówkami, a następnie w najbardziej odludnej części składowiska. Zdaniem gazety Kreml, pozbywając się ciał w ten sposób, ukrywa rzeczywistą skale wojennych strat, których doznał podczas inwazji na Ukrainę.</p><br clear="all" />

## Znaleziono cztery ciała i jednego rannego na farmie. Podejrzany na wolności
 - [https://wydarzenia.interia.pl/zagranica/news-znaleziono-cztery-ciala-i-jednego-rannego-na-farmie-podejrza,nId,6426714](https://wydarzenia.interia.pl/zagranica/news-znaleziono-cztery-ciala-i-jednego-rannego-na-farmie-podejrza,nId,6426714)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 06:58:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-znaleziono-cztery-ciala-i-jednego-rannego-na-farmie-podejrza,nId,6426714"><img align="left" alt="Znaleziono cztery ciała i jednego rannego na farmie. Podejrzany na wolności" src="https://i.iplsc.com/znaleziono-cztery-ciala-i-jednego-rannego-na-farmie-podejrza/000GDIR7I9TC7Y8C-C321.jpg" /></a>Na farmie marihuany w Oklahomie w USA znaleziono cztery ciała i jedną ciężko ranną osobę. Policja przybyła tam na wezwanie dotyczące przetrzymywania zakładników. Media przekazały, że sprawca pozostaje na wolności.</p><br clear="all" />

## Lekarz Atletico Madryt poproszony o pomoc w sprawie kolana papieża
 - [https://wydarzenia.interia.pl/zagranica/news-lekarz-atletico-madryt-poproszony-o-pomoc-w-sprawie-kolana-p,nId,6426725](https://wydarzenia.interia.pl/zagranica/news-lekarz-atletico-madryt-poproszony-o-pomoc-w-sprawie-kolana-p,nId,6426725)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 06:52:55+00:00

<p>86-letni papież Franciszek zmaga się z dotkliwym bólem kolana, porusza się na wózku lub lasce, ale nie chce poddać się operacji. Stolica Apostolska zwróciła się do lekarza hiszpańskiego klubu piłkarskiego z prośbą o konsultację. </p><br clear="all" />

## Budowa domu na nowych zasadach. W 2023 roku szykują się duże zmiany w prawie
 - [https://wydarzenia.interia.pl/kraj/news-budowa-domu-na-nowych-zasadach-w-2023-roku-szykuja-sie-duze-,nId,6419598](https://wydarzenia.interia.pl/kraj/news-budowa-domu-na-nowych-zasadach-w-2023-roku-szykuja-sie-duze-,nId,6419598)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 06:08:32+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-budowa-domu-na-nowych-zasadach-w-2023-roku-szykuja-sie-duze-,nId,6419598"><img align="left" alt="Budowa domu na nowych zasadach. W 2023 roku szykują się duże zmiany w prawie" src="https://i.iplsc.com/budowa-domu-na-nowych-zasadach-w-2023-roku-szykuja-sie-duze/000GCXN6CNDSYGDG-C321.jpg" /></a>W przyszłym roku w życie wchodzi nowelizacja Prawa budowalnego, a wraz z nią sporo ważnych zmian. Dotyczą one m.in. możliwości budowy domów jednorodzinnych bez pozwolenia, cyfryzacji procesu inwestycyjnego czy likwidacji niezbędnej do tej pory zgody na użytkowanie. Większość z nich zacznie obowiązywać już od 1 stycznia 2023 r.</p><br clear="all" />

## Mateusz Morawiecki: Jeśli Ukraina przegra, Rosja skieruje agresję na Polskę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-mateusz-morawiecki-jesli-ukraina-przegra-rosja-skieruje-agre,nId,6426699](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-mateusz-morawiecki-jesli-ukraina-przegra-rosja-skieruje-agre,nId,6426699)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 05:55:49+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-mateusz-morawiecki-jesli-ukraina-przegra-rosja-skieruje-agre,nId,6426699"><img align="left" alt="Mateusz Morawiecki: Jeśli Ukraina przegra, Rosja skieruje agresję na Polskę" src="https://i.iplsc.com/mateusz-morawiecki-jesli-ukraina-przegra-rosja-skieruje-agre/000GDIO04B72PG7K-C321.jpg" /></a>&quot;Jedynym odpowiedzialnym za tragedię w Przewodowie jest Rosja&quot; - napisał premier Mateusz Morawiecki. Dodał, że jeśli padnie Kijów, to Kreml skieruje swoją agresję na Polskę. &quot;Aby uniknąć wojny, należy wspierać zwycięstwo Ukrainy&quot; - zauważył szef rządu.</p><br clear="all" />

## "Nowe rozdanie jest wielką nadzieją dla Śląska". PiS traci większość w sejmiku
 - [https://wydarzenia.interia.pl/slaskie/news-nowe-rozdanie-jest-wielka-nadzieja-dla-slaska-pis-traci-wiek,nId,6426695](https://wydarzenia.interia.pl/slaskie/news-nowe-rozdanie-jest-wielka-nadzieja-dla-slaska-pis-traci-wiek,nId,6426695)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 05:18:58+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-nowe-rozdanie-jest-wielka-nadzieja-dla-slaska-pis-traci-wiek,nId,6426695"><img align="left" alt="&quot;Nowe rozdanie jest wielką nadzieją dla Śląska&quot;. PiS traci większość w sejmiku" src="https://i.iplsc.com/nowe-rozdanie-jest-wielka-nadzieja-dla-slaska-pis-traci-wiek/000GDINM3NY002BF-C321.jpg" /></a>- Mam duże oczekiwania, że nadamy nowego polotu - powiedział marszałek województwa śląskiego Jakub Chełstowski. Polityk zakończył współpracę z PiS i stworzył koalicję z dotychczasową opozycją. Chełstowski zauważył, że &quot;na te cztery lata trzy były wyjątkowo dobre&quot;.</p><br clear="all" />

## WHO o tegorocznej zimie w Ukrainie. "Życie milionów ludzi zagrożone"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-who-o-tegorocznej-zimie-w-ukrainie-zycie-milionow-ludzi-zagr,nId,6426694](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-who-o-tegorocznej-zimie-w-ukrainie-zycie-milionow-ludzi-zagr,nId,6426694)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-22 05:11:20+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-who-o-tegorocznej-zimie-w-ukrainie-zycie-milionow-ludzi-zagr,nId,6426694"><img align="left" alt="WHO o tegorocznej zimie w Ukrainie. &quot;Życie milionów ludzi zagrożone&quot;" src="https://i.iplsc.com/who-o-tegorocznej-zimie-w-ukrainie-zycie-milionow-ludzi-zagr/000GDILTGO6P4GYG-C321.jpg" /></a>- Zimno będzie zabijać - mówił w poniedziałek w Kijowie dyrektor regionalny Światowej Organizacji Zdrowia (WHO) na Europę i przypomniał, że 10 milionów ludzi nie ma tam prądu. - Zima będzie potężnym sprawdzianem dla ukraińskiej służby zdrowia i wspierającej Ukrainę światowej społeczności. Będzie chodziło o przeżycie - dodał dr Hans Henri Kluge.</p><br clear="all" />


# Source:Epoch Times Tech, URL:https://www.theepochtimes.com/c-tech/feed/, language:en-US

## Elon Musk Delaying Twitter Blue Checkmark Launch, May Offer Different Colors for Organizations
 - [https://www.theepochtimes.com/elon-musk-delaying-twitter-blue-checkmark-launch-may-offer-different-colors-for-organizations_4879760.html](https://www.theepochtimes.com/elon-musk-delaying-twitter-blue-checkmark-launch-may-offer-different-colors-for-organizations_4879760.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-11-22 20:02:42+00:00

Twitter logo and a photo of Elon Musk are displayed through a magnifier in this illustration taken on Oct. 27, 2022. (Dado Ruvic/Reuters)

## TSMC Planning Advanced Chip Production in Arizona, Says Company’s Founder
 - [https://www.theepochtimes.com/tsmc-planning-advanced-chip-production-in-arizona-says-companys-founder_4876291.html](https://www.theepochtimes.com/tsmc-planning-advanced-chip-production-in-arizona-says-companys-founder_4876291.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-11-22 07:17:49+00:00

Taiwan's APEC representative and TSMC founder Morris Chang speaks at a news conference after his return to Taipei, Taiwan, on Nov. 21, 2022. (Ann Wang/Reuters)

## Tesla Safety at Center of South Korean Trial Over Fiery, Fatal Crash
 - [https://www.theepochtimes.com/tesla-safety-at-center-of-south-korean-trial-over-fiery-fatal-crash_4876671.html](https://www.theepochtimes.com/tesla-safety-at-center-of-south-korean-trial-over-fiery-fatal-crash_4876671.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-11-22 03:54:42+00:00

The logo of Tesla in Taipei, Taiwan, on Aug. 11, 2017. (Tyrone Siu/Reuters)

## Children’s Privacy on Facebook Tightens
 - [https://www.theepochtimes.com/childrens-privacy-on-facebook-tightens_4878143.html](https://www.theepochtimes.com/childrens-privacy-on-facebook-tightens_4878143.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-11-22 02:12:58+00:00

A 3D-printed Facebook like button in front of the Facebook logo in an illustration taken on Oct. 25, 2017. (Dado Ruvic/Illustration/Reuters)


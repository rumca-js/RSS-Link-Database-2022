# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Watch Power Rangers' Touching Tribute to Jason David Frank
 - [https://gizmodo.com/jason-david-frank-power-rangers-official-tribute-1849814709](https://gizmodo.com/jason-david-frank-power-rangers-official-tribute-1849814709)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 23:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--O2vKQlhw--/c_fit,fl_progressive,q_80,w_636/118069069cc20b195f596a90d0f677f5.jpg" /><p><em>Power Rangers</em> fans across the world are still in shock from the sudden passing of <em>Mighty Morphin</em>’ star <a href="https://gizmodo.com/obituary-jason-david-frank-power-rangers-1849806348">Jason David Frank</a> this past weekend at the age of 49, with tributes rolling in from across the worlds of <a href="https://gizmodo.com/the-original-power-rangers-movie-is-a-glorious-tribute-1828639981"><em>Power Rangers</em></a> and <a href="https://gizmodo.com/zyuranger-30th-anniversary-power-rangers-1848573478"><em>Super Sentai</em></a> to honor the actor—including a touching new video from Hasbro.<br /></p><p><a href="https://gizmodo.com/jason-david-frank-power-rangers-official-tribute-1849814709">Read more...</a></p>

## The Walking Dead Finale Originally Had a Different Ending
 - [https://gizmodo.com/walking-dead-finale-amc-rick-michonne-flash-forward-1849814461](https://gizmodo.com/walking-dead-finale-amc-rick-michonne-flash-forward-1849814461)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 22:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--DHnqQmSo--/c_fit,fl_progressive,q_80,w_636/8305dd380e5257a3d1fbe1e5a1950e7d.jpg" /><p>Did you hear? <em>The Walking Dead</em>, one of our generation’s <a href="https://gizmodo.com/the-walking-dead-final-episode-first-pictures-amc-1849778240">defining television shows</a>, <a href="https://gizmodo.com/walking-dead-series-finale-recap-rest-in-peace-s11-ep24-1849811134">ended this past weekend</a>. Besides wrapping up as many core stories as it could, the big reveal was something our own Rob Bricken <a href="https://gizmodo.com/walking-dead-series-finale-recap-rest-in-peace-s11-ep24-1849811134">described as</a> “all that anyone still watching the show wanted to see.” However, the ending you saw was not…</p><p><a href="https://gizmodo.com/walking-dead-finale-amc-rick-michonne-flash-forward-1849814461">Read more...</a></p>

## Philippine Navy Says China Forcibly Seized Suspected Rocket Debris
 - [https://gizmodo.com/china-accused-seizing-rocket-debris-filipino-navy-1849813689](https://gizmodo.com/china-accused-seizing-rocket-debris-filipino-navy-1849813689)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 22:13:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ivmJuenl--/c_fit,fl_progressive,q_80,w_636/5c17b05446f8ccb4353aae111f2165c1.jpg" /><p>According to Philippines military officials, China’s coast guard forcibly blocked a Philippine naval boat on Sunday as it was towing suspected rocket debris from the South China Sea to the Philippine-occupied Thitu island, the Associated Press <a href="https://apnews.com/article/china-navy-philippines-manila-south-sea-ee4c0a7b080a27ad559105a44bdfcf31" rel="noopener noreferrer" target="_blank">reported</a>.<br /></p><p><a href="https://gizmodo.com/china-accused-seizing-rocket-debris-filipino-navy-1849813689">Read more...</a></p>

## Florida Manatees Are Starving En Masse. Conservation Groups Want Them Back on Endangered List
 - [https://gizmodo.com/florida-manatees-endangered-list-petition-1849814051](https://gizmodo.com/florida-manatees-endangered-list-petition-1849814051)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 21:59:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--K_29RTHT--/c_fit,fl_progressive,q_80,w_636/230fa6c9361872b245f60c3a0cf22c90.jpg" /><p>Environmental groups launched a petition on Monday to once again list manatees as endangered, as hundreds of the beloved sea cows die from starvation.</p><p><a href="https://gizmodo.com/florida-manatees-endangered-list-petition-1849814051">Read more...</a></p>

## The Amazing Art and Toys We Loved at Designer Con 2022
 - [https://gizmodo.com/designercon-2022-highlights-star-wars-marvel-halloween-1849808738](https://gizmodo.com/designercon-2022-highlights-star-wars-marvel-halloween-1849808738)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 21:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--c7lqIXye--/c_fit,fl_progressive,q_80,w_636/59f553e15b6a13005a738b6fddf0da97.jpg" /><p>Imagine a place where monsters live with robots. Where the pinkest, prettiest thing you’ve ever seen is right next to the darkest and most gruesome. A place where <a href="https://gizmodo.com/the-best-of-io9s-concept-art-week-5570195">art, pop culture</a>, and <a href="https://gizmodo.com/you-may-remember-this-weeks-toys-from-such-films-as-1849706186">collectibles collide</a> like asteroids into a planet. That place is the annual Designer Con, and it’s the coolest place you’ve ever been.</p><p><a href="https://gizmodo.com/designercon-2022-highlights-star-wars-marvel-halloween-1849808738">Read more...</a></p>

## Webb Telescope Reveals Noxious Atmosphere of a Planet 700 Light-Years Away
 - [https://gizmodo.com/webb-exoplanet-atmosphere-wasp-39b-1849813296](https://gizmodo.com/webb-exoplanet-atmosphere-wasp-39b-1849813296)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 21:42:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--GBpZEk7w--/c_fit,fl_progressive,q_80,w_636/01527ee2a49f816eaa2c5e8a19db96ef.jpg" /><p>Astrophysicists on Earth are <a href="https://gizmodo.com/webb-telescope-cardon-dioxide-exoplanet-wasp39b-1849456443">no strangers</a> to WASP-39b, an exoplanet orbiting a star about 700 light-years from Earth, though they’ve never actually seen it directly. Now, the Webb Space Telescope has offered fresh insight into this distant world: Its observations have revealed the recipe list for the planet’s toxic…</p><p><a href="https://gizmodo.com/webb-exoplanet-atmosphere-wasp-39b-1849813296">Read more...</a></p>

## Meta AI Bot Contributed to Fake Research and Nonsense Before Being Pulled Offline
 - [https://gizmodo.com/meta-ai-bot-galactica-1849813665](https://gizmodo.com/meta-ai-bot-galactica-1849813665)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 21:25:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--YklDC2-Q--/c_fit,fl_progressive,q_80,w_636/6657b17060d229f5e73de0589b354ad9.jpg" /><p><a href="https://gizmodo.com/meta-ai-cicero-diplomacy-gaming-1849811840">Meta</a> paused its <a href="https://galactica.org/" rel="noopener noreferrer" target="_blank">Artificial Intelligence (AI) bot last week</a>, only two days after it went live to the public. The bot, called Galactica, was trained “on 106 billion tokens of open-access scientific text and data. This includes papers, textbooks, scientific websites, encyclopedias, reference material, knowledge bases,…</p><p><a href="https://gizmodo.com/meta-ai-bot-galactica-1849813665">Read more...</a></p>

## UK Regulators Want Apple to Open its App Store Doors to Cloud Gaming
 - [https://gizmodo.com/apple-google-uk-investigation-cma-xbox-cloud-gaming-ios-1849814144](https://gizmodo.com/apple-google-uk-investigation-cma-xbox-cloud-gaming-ios-1849814144)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 21:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--1bAZHqMK--/c_fit,fl_progressive,q_80,w_636/12abdd0dae0f920813ebfcb387272a8d.jpg" /><p>Apple’s walled garden is a nice place to be if you want a no-fuss experience with technology. But the bushy greens and red roses don’t necessarily indicate you’re getting the most out of the device in your hand. The UK’s Competition and Markets Authority (CMA), a governmental entity, has launched an investigation into…</p><p><a href="https://gizmodo.com/apple-google-uk-investigation-cma-xbox-cloud-gaming-ios-1849814144">Read more...</a></p>

## Strange World Is a Wonderfully Weird and Fantastic Family Adventure
 - [https://gizmodo.com/strange-world-review-disney-animation-jake-gyllenhaal-1849810962](https://gizmodo.com/strange-world-review-disney-animation-jake-gyllenhaal-1849810962)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 21:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--dqDvMZAv--/c_fit,fl_progressive,q_80,w_636/d0e236489deecb1a1e46944d61a9b79a.jpg" /><p>From the team behind <a href="https://gizmodo.com/the-one-thing-about-raya-and-the-last-dragon-that-never-1846367826"><em>Raya and the Last Dragon</em></a> comes <em>Strange World</em>: <a href="https://gizmodo.com/ariana-debose-wish-disney-animation-fairytale-d23-expo-1849526298">Walt Disney Animation Studios</a>’ latest feature, an eccentrically excellent pulp sci-fi adventure. It’s a wonderfully weird gem that I hope springboards into serialized tales about the Clade family that anchors the film. </p><p><a href="https://gizmodo.com/strange-world-review-disney-animation-jake-gyllenhaal-1849810962">Read more...</a></p>

## WikiLeaks' Website Is Falling Apart
 - [https://gizmodo.com/wikileaks-julian-assange-1849813101](https://gizmodo.com/wikileaks-julian-assange-1849813101)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 21:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--FHWKldSl--/c_fit,fl_progressive,q_80,w_636/f6eea4362d87a4fd018deed5d4cfeaee.jpg" /><p>For a period of time in the 2000s and 2010s, WikiLeaks was a name synonymous with whistleblowing. The non-profit organization’s website was <em>the place </em>on the internet for information that someone, somewhere didn’t want you to see. But now, much of that information appears to have vanished. WikiLeaks’ website is full of…</p><p><a href="https://gizmodo.com/wikileaks-julian-assange-1849813101">Read more...</a></p>

## Ticketmaster Will Now Have to Explain Itself to Lawmakers Following Taylor Swift Ticket Disaster
 - [https://gizmodo.com/taylor-swift-ticketmaster-concert-congress-1849813281](https://gizmodo.com/taylor-swift-ticketmaster-concert-congress-1849813281)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 20:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Pc-ktx35--/c_fit,fl_progressive,q_80,w_636/1ad06d2c2ea55620497d8e915dc3f37b.jpg" /><p>The fallout continues from last week’s Ticketmaster fiasco as Taylor Swift fans scrambled to buy tickets to the popstar’s upcoming The Eras Tour. The surge promptly <a href="https://gizmodo.com/taylor-swifts-tour-presale-breaks-ticketmaster-1849784615">crashed Ticketmaster’s website</a>. In the aftermath, <a href="https://gizmodo.com/taylor-swift-ticketmaster-anti-hero-swifties-1849803128">an echoing battlecry</a> from fans, musicians, and politicians emerged against Ticketmaster for their…</p><p><a href="https://gizmodo.com/taylor-swift-ticketmaster-concert-congress-1849813281">Read more...</a></p>

## Does Beyond Meat Have a Mold Problem?
 - [https://gizmodo.com/does-beyond-meat-have-a-mold-problem-1849813838](https://gizmodo.com/does-beyond-meat-have-a-mold-problem-1849813838)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 20:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--7sxOjiGN--/c_fit,fl_progressive,q_80,w_636/5f122f92a20175e779a26f7c97b35fef.jpg" /><p><a href="https://gizmodo.com/does-beyond-meat-have-a-mold-problem-1849813838">Read more...</a></p>

## Watch Live as SpaceX Attempts to Launch Its New Cargo Capsule to the ISS
 - [https://gizmodo.com/spacex-nasa-launch-new-cargo-capsule-iss-1849812452](https://gizmodo.com/spacex-nasa-launch-new-cargo-capsule-iss-1849812452)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 20:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--CWoY02Db--/c_fit,fl_progressive,q_80,w_636/1b738c03c4d6aded2a401dc2c5298dff.jpg" /><p>NASA is gearing up to launch a cargo mission to the International Space Station, delivering supplies and a new batch of experiments aboard a brand new SpaceX Dragon capsule.</p><p><a href="https://gizmodo.com/spacex-nasa-launch-new-cargo-capsule-iss-1849812452">Read more...</a></p>

## Hideaki Anno's Ultraman Fan Film Is Now Officially Streaming
 - [https://gizmodo.com/hideaki-anno-ultraman-fan-film-streaming-japan-1849813788](https://gizmodo.com/hideaki-anno-ultraman-fan-film-streaming-japan-1849813788)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 20:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--RmI4juBo--/c_fit,fl_progressive,q_80,w_636/3033618ce4d3e57e2e4fd3bb54973c3d.png" /><p><a href="https://gizmodo.com/shin-ultraman-interview-fantastic-fest-shinji-higuchi-1849587822"><em>Shin Ultraman</em></a> is the <a href="https://gizmodo.com/hideaki-anno-shin-ultraman-mocap-vfx-1849135131">realization of a dream</a> generations in the making for <a href="https://gizmodo.com/the-radical-sincerity-of-evangelions-final-end-1847498562"><em>Neon Genesis Evangelion</em>’s Hideaki Anno</a>—working with Shinji Higuchi to craft his own spin on the legendary franchise that inspired legions of his own work. And now, it’s getting even easier to see just how long Anno has been influenced by <em>Ultraman</em>…</p><p><a href="https://gizmodo.com/hideaki-anno-ultraman-fan-film-streaming-japan-1849813788">Read more...</a></p>

## NASA Downplays Launch Pad Damage Caused by SLS Rocket
 - [https://gizmodo.com/sls-launch-pad-damage-nasa-1849812062](https://gizmodo.com/sls-launch-pad-damage-nasa-1849812062)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 19:55:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--_m_VUv40--/c_fit,fl_progressive,q_80,w_636/e87438485db2ac1dd6a809df552ec21a.png" /><p>A scorched platform, fried cameras, broken pipes, and a busted elevator are among the casualties of last week’s launch of NASA’s SLS rocket. Mobile Launcher 1 and Launch Complex 39B at Kennedy Space Center will require repairs, but NASA says they’ll be ready for the next Artemis mission.</p><p><a href="https://gizmodo.com/sls-launch-pad-damage-nasa-1849812062">Read more...</a></p>

## China 'Resolves' Gaming Addiction So It May No Longer Need Pesky Industry Regulations
 - [https://gizmodo.com/china-gaming-addiction-xbox-video-games-1849813395](https://gizmodo.com/china-gaming-addiction-xbox-video-games-1849813395)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 19:35:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--whWN9iWh--/c_fit,fl_progressive,q_80,w_636/dcdc1c128ceaa53ac0908588ae97f957.jpg" /><p>“Solving” gaming addiction sounds as easy as easy as “solving” alcoholism, but China’s state-affiliated body overseeing video games seems about ready to call recent efforts at curbing gaming use among children a “success.” </p><p><a href="https://gizmodo.com/china-gaming-addiction-xbox-video-games-1849813395">Read more...</a></p>

## How Does Ghostbusters Merchandise Get Made?
 - [https://gizmodo.com/ghostbusters-merchandise-afterlife-sony-evp-hasbro-toys-1849803172](https://gizmodo.com/ghostbusters-merchandise-afterlife-sony-evp-hasbro-toys-1849803172)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 19:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s---fgLGIcG--/c_fit,fl_progressive,q_80,w_636/de144ceb1c88b22bf600bf724cf5071f.jpg" /><p>Let’s say you’re making a big movie and you want to make sure it’s supported by merchandise. <a href="https://gizmodo.com/these-are-some-of-the-best-looking-ghostbusters-toys-ev-1841815272">Who ya gonna call?</a> Well, for <em>Ghostbusters</em>, one option is Jamie Stevens. An executive vice president at Sony Pictures Entertainment, Stevens oversees <a href="https://gizmodo.com/new-ghostbuster-afterlife-toys-include-figures-ghost-1847362335">worldwide consumer products</a> for Sony Pictures film and television, as well as…</p><p><a href="https://gizmodo.com/ghostbusters-merchandise-afterlife-sony-evp-hasbro-toys-1849803172">Read more...</a></p>

## Trump's Truth Social Gifted Nearly One More Year to Finalize Shady SPAC Merger After Shareholder Vote
 - [https://gizmodo.com/trump-truth-social-spac-merger-twitter-1849813269](https://gizmodo.com/trump-truth-social-spac-merger-twitter-1849813269)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 18:50:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Pc6Tk5Yy--/c_fit,fl_progressive,q_80,w_636/3765fe6d2ff7238de08efa0da6edbe09.jpg" /><p>The shell company <a href="https://gizmodo.com/trump-truth-social-spac-1849499408">struggling</a> to take Donald Trump’s Trump Media and Technology Group public just bought itself some desperately needed time. Thanks to a new shareholder vote, Digital World Acquisition Corp (DWAC) will now have until September 8, 2023 to complete its merger with the Truth Social parent company</p><p><a href="https://gizmodo.com/trump-truth-social-spac-merger-twitter-1849813269">Read more...</a></p>

## Elon Musk's Wealth Drops by $8.6 Billion in One Day
 - [https://gizmodo.com/elon-musk-billionaire-tesla-wealth-twitter-spacex-1849812120](https://gizmodo.com/elon-musk-billionaire-tesla-wealth-twitter-spacex-1849812120)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 18:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--e_hOPyOz--/c_fit,fl_progressive,q_80,w_636/a975b6d8078bdba7ef29d5c64e645a55.jpg" /><p><a href="https://gizmodo.com/elon-musk-tesla-twitter-lawsuit-1849791653">Tesla</a>, <a href="https://gizmodo.com/spacex-twitter-ads-elon-musk-1849779141">SpaceX</a>, and <a href="https://gizmodo.com/tech/twitter">Twitter</a> CEO Elon Musk saw his wealth plummet by $100 billion dollars this year, bringing his net worth to somewhere between $170 billion and $182 billion, according to estimates from <a href="https://www.bloomberg.com/billionaires/profiles/elon-r-musk/?leadSource=uverify%20wall" rel="noopener noreferrer" target="_blank">Bloomberg</a> and <a href="https://www.forbes.com/profile/elon-musk/?sh=6b2da84a7999" rel="noopener noreferrer" target="_blank">Forbes</a>. That’s down from an estimated $340 billion in November 2021. The drop comes as <a href="https://gizmodo.com/tesla-bitcoin-q2-earnings-elon-musk-1849201112">Tesla shares…</a></p><p><a href="https://gizmodo.com/elon-musk-billionaire-tesla-wealth-twitter-spacex-1849812120">Read more...</a></p>

## Martin Scorsese's Goncharov (1973) Is the Greatest Mafia Movie Never Made
 - [https://gizmodo.com/scorsese-goncharov-1973-tumblr-explained-mafia-movie-1849812229](https://gizmodo.com/scorsese-goncharov-1973-tumblr-explained-mafia-movie-1849812229)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 18:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--HuWYPi16--/c_fit,fl_progressive,q_80,w_636/82b9b5996843a13e375338faff52a043.png" /><p>If you were online, and specifically on Tumblr, over the weekend of November 18-20, you’ve definitely heard of <em>Goncharov (1973</em>). Widely considered one of <a href="https://gizmodo.com/check-out-the-overhead-shots-of-martin-scorsese-nsfw-1789576733">Martin Scorsese</a>’s lost masterpieces of Mafia cinema, it was released in 1973 but suppressed in the states for various reasons. Alternatively, it was never released.…</p><p><a href="https://gizmodo.com/scorsese-goncharov-1973-tumblr-explained-mafia-movie-1849812229">Read more...</a></p>

## In Memory of @BPDeezNutzz, the Best GreenTrolling Account to Ever Grace Twitter
 - [https://gizmodo.com/bpdeeznutzz-twitter-account-suspended-1849802206](https://gizmodo.com/bpdeeznutzz-twitter-account-suspended-1849802206)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 18:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--vVPV2A6D--/c_fit,fl_progressive,q_80,w_636/a92b8ce8d2d05eaccd0c78c2f6c8ceb0.jpg" /><p>Twitter’s recent effort to get rid of parody accounts has suspended @BPDeezNutzz, an account that ruthlessly taunted <a href="https://gizmodo.com/bp-worries-a-green-coronavirus-recovery-could-kill-its-1844050906">oil and gas giant BP</a>.<br /></p><p><a href="https://gizmodo.com/bpdeeznutzz-twitter-account-suspended-1849802206">Read more...</a></p>

## Play With an Interactive Map of the Observable Universe
 - [https://gizmodo.com/play-with-an-interactive-map-of-the-observable-universe-1849812056](https://gizmodo.com/play-with-an-interactive-map-of-the-observable-universe-1849812056)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 17:50:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--9TVUUu8R--/c_fit,fl_progressive,q_80,w_636/a54b40be20b79eb76546c24d27892c9c.png" /><p>Astronomers have compiled 15 years’ worth of data from the <a href="https://sloan.org/programs/research/sloan-digital-sky-survey" rel="noopener noreferrer" target="_blank">Sloan Digital Sky Survey</a> into an interactive map of the observable universe.<br /></p><p><a href="https://gizmodo.com/play-with-an-interactive-map-of-the-observable-universe-1849812056">Read more...</a></p>

## Mini Macintosh USB-C Charger Now Has a Working Screen That Shows Your Power Use
 - [https://gizmodo.com/macintosh-usb-c-charger-working-screen-matrix-shargeek-1849812346](https://gizmodo.com/macintosh-usb-c-charger-working-screen-matrix-shargeek-1849812346)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 17:40:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--yFkMSuna--/c_fit,fl_progressive,q_80,w_636/4d2458155684b96da548ade310cd0806.jpg" /><p>Once limited to being giant plastic bricks over-crowding the power strips hidden under our desks, chargers have come a long way in just a few years, shrinking dramatically, gaining new abilities, and some personality to boot. If you’re a die-hard Mac fan, you probably won’t want to hide <a href="https://www.indiegogo.com/projects/shargeek-the-first-67w-charger-with-power-display#/" rel="noopener noreferrer" target="_blank">Shargeek’s latest creation</a>…</p><p><a href="https://gizmodo.com/macintosh-usb-c-charger-working-screen-matrix-shargeek-1849812346">Read more...</a></p>

## Meta Has Been Lapping Up User’s Financial Info Sent Directly from Tax Filing Sites
 - [https://gizmodo.com/meta-h-r-block-tax-filings-facebook-data-1849811961](https://gizmodo.com/meta-h-r-block-tax-filings-facebook-data-1849811961)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 17:35:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--wjYymOxi--/c_fit,fl_progressive,q_80,w_636/7f73dc347f5594956b0d05abeb723bd7.jpg" /><p>The ravenous data machine never stops looking for ways to feed, but it seems for some time now the beast has been snacking on users’ financial data taken directly from their tax filings. After the machine’s had its fill on users income data, filing status, dependents’ names, refund amount, and more, it’s been…</p><p><a href="https://gizmodo.com/meta-h-r-block-tax-filings-facebook-data-1849811961">Read more...</a></p>

## New List of the Most Dangerous Pathogens Will Include ‘Disease X,’ the Likely Next Pandemic
 - [https://gizmodo.com/who-list-most-dangerous-viruses-bacteria-disease-x-1849812551](https://gizmodo.com/who-list-most-dangerous-viruses-bacteria-disease-x-1849812551)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 17:27:31+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--esYtpapS--/c_fit,fl_progressive,q_80,w_636/e25af20799febe80e31a826dbb297b2f.jpg" /><p>The World Health Organization is creating an updated list of the globe’s most dangerous microbes. The public health agency will recruit over 300 scientists to work on the list. They will consider known germs across dozens of virus and bacteria families. One automatic inclusion will be “Disease X,” the moniker given to…</p><p><a href="https://gizmodo.com/who-list-most-dangerous-viruses-bacteria-disease-x-1849812551">Read more...</a></p>

## Avatar: The Way of Water Needs to Make $2 Billion to Break Even
 - [https://gizmodo.com/avatar-2-way-of-water-james-cameron-billion-box-office-1849812098](https://gizmodo.com/avatar-2-way-of-water-james-cameron-billion-box-office-1849812098)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 17:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Mkf5w5dF--/c_fit,fl_progressive,q_80,w_636/5416d16410cd39257f2c05a5ed55a1ee.jpg" /><p>Here’s something you probably don’t want to hear if you’re a high-powered movie executive for <em>Avatar</em> producer 20th Century or their new corporate overlords at Disney: director <a href="https://gizmodo.com/james-cameron-avatar-2-release-date-disney-fox-pandora-1849559989">James Cameron</a> to calling his own sequel, <a href="https://gizmodo.com/avatar-2-character-posters-way-of-water-james-cameron-1849809606"><em>The Way of Water</em></a>, “the worst business case in movie history.” But that’s apparently what he did!<br /></p><p><a href="https://gizmodo.com/avatar-2-way-of-water-james-cameron-billion-box-office-1849812098">Read more...</a></p>

## Tampax’s Tweet Sexualizing Women on Their Periods Is Revolting
 - [https://gizmodo.com/tampax-dm-in-them-tweet-sexualizing-periods-revolting-1849811566](https://gizmodo.com/tampax-dm-in-them-tweet-sexualizing-periods-revolting-1849811566)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 16:37:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--70EJPHus--/c_fit,fl_progressive,q_80,w_636/7f3e0081546d6dd29d71b97b3f5a9baf.png" /><p>Tampax, one of the world’s foremost tampon brands, apparently wanted to join in on the seemingly endless conversation on Twitter about <a href="https://gizmodo.com/elon-musk-twitter-down-hardcore-plan-resignations-1849800362">how the platform</a> is going to <a href="https://gizmodo.com/elon-musk-twitter-ye-donald-trump-andrew-tate-1849808496">die at the hands</a> of its new <del>overlord</del> owner, <a href="https://gizmodo.com/elon-musk-email-be-part-of-hardcore-twitter-or-leave-1849789128">Elon Musk</a>. However, what was probably intended as a snarky joke has ended up being the newest addition to the…</p><p><a href="https://gizmodo.com/tampax-dm-in-them-tweet-sexualizing-periods-revolting-1849811566">Read more...</a></p>

## The Walking Dead Has Finally Died
 - [https://gizmodo.com/walking-dead-series-finale-recap-rest-in-peace-s11-ep24-1849811134](https://gizmodo.com/walking-dead-series-finale-recap-rest-in-peace-s11-ep24-1849811134)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 16:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--IAg6ivGL--/c_fit,fl_progressive,q_80,w_636/14b7f785056a98d5f893071d64c4cab1.jpg" /><p>Friends, zombies, countrymen, lend me your ears! I have come to bury <a href="https://gizmodo.com/open-channel-walking-dead-memory-amc-1849806010"><em>The Walking Dead</em></a>, not to praise it. I haven’t come to trash-talk it either, actually. But it feels important to note that the zombified version of <em>TWD</em> that has been shambling around our TV screens for years has had its skull crushed and its brains…</p><p><a href="https://gizmodo.com/walking-dead-series-finale-recap-rest-in-peace-s11-ep24-1849811134">Read more...</a></p>

## 10 Antivax Lies to Watch Out for This Holiday
 - [https://gizmodo.com/10-antivax-lies-to-watch-out-for-this-holiday-1848113384](https://gizmodo.com/10-antivax-lies-to-watch-out-for-this-holiday-1848113384)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 16:02:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--R76a3y-w--/c_fit,fl_progressive,q_80,w_636/78dbf9a636185a24cf16e078481ad524.jpg" /><p>For many people, family gatherings at the holidays mean suffering through painful conversations with antivax relatives. While there may be little sense in trying to change anyone’s mind, here are some common antivax talking points about the covid-19 vaccines to be aware of.</p><p><a href="https://gizmodo.com/10-antivax-lies-to-watch-out-for-this-holiday-1848113384">Read more...</a></p>

## FTX and Sam Bankman-Fried's Parents Reportedly Bought Millions of Dollars Worth of Bahamas Property
 - [https://gizmodo.com/ftx-bahamas-property-crypto-sam-bankman-fried-1849811876](https://gizmodo.com/ftx-bahamas-property-crypto-sam-bankman-fried-1849811876)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 15:55:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--gMV9Mkpl--/c_fit,fl_progressive,q_80,w_636/b1c8eae2f4f04fbe8cbec07b8c0f96e3.jpg" /><p><a href="https://gizmodo.com/ftx-crypto-sam-bankman-fried-binance-1849768382">Sam Bankman-Fried</a>, the former CEO and founder of FTX, has been having a rough couple of weeks. With his reputation on the line amidst the <a href="https://gizmodo.com/doj-sec-investigating-ftx-bitcoin-price-crypto-plunges-1849766102">collapse of the massive cryptocurrency exchange</a>, a new report indicates that FTX  and Bankman-Fried’s own parents purchased a collective 19 properties  in the Bahamas over the past…</p><p><a href="https://gizmodo.com/ftx-bahamas-property-crypto-sam-bankman-fried-1849811876">Read more...</a></p>

## Bliss Out to This View of NASA's SLS Launching in Super-Slow Motion
 - [https://gizmodo.com/slow-motion-video-sls-rocket-launch-nasa-1849811819](https://gizmodo.com/slow-motion-video-sls-rocket-launch-nasa-1849811819)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 15:46:00+00:00

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--dmxc3PYN--/c_fit,fl_progressive,q_80,w_636/a8ac8b479b7a818ad993e68fcfff5a52.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--Gma6huYU--/c_fit,fl_progressive,q_80,w_636/a8ac8b479b7a818ad993e68fcfff5a52.mp4" type="video/mp4" /></video><p>NASA has <a href="https://www.youtube.com/watch?v=aWCCNYJV3Zw" rel="noopener noreferrer" target="_blank">released</a> a stunning slow motion video showing its new Space Launch System rocket blasting off from Kennedy Space Center last week. <br /></p><p><a href="https://gizmodo.com/slow-motion-video-sls-rocket-launch-nasa-1849811819">Read more...</a></p>

## Behind the Choice of the New Black Panther
 - [https://gizmodo.com/behind-the-choice-of-the-new-black-panther-1849812112](https://gizmodo.com/behind-the-choice-of-the-new-black-panther-1849812112)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 15:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--k8S12KJt--/c_fit,fl_progressive,q_80,w_636/ef7e44169caab6f919e20c5b6322396d.jpg" /><p><a href="https://gizmodo.com/behind-the-choice-of-the-new-black-panther-1849812112">Read more...</a></p>

## Elon Musk Delays $8 Blue Check Twitter Verification Again, This Time Indefinitely
 - [https://gizmodo.com/elon-musk-blue-checkmark-verified-twitter-1849811765](https://gizmodo.com/elon-musk-blue-checkmark-verified-twitter-1849811765)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 15:35:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--_s2s_WjF--/c_fit,fl_progressive,q_80,w_636/669dc4c94c3c9cc229c71af084f69ee4.jpg" /><p>Another day, another bit of  news broadcast from Elon Musk’s Twitter account. The social platform’s owner and CEO posted that, once again, he would be delaying the final rollout of his paid verification system on the site.<br /></p><p><a href="https://gizmodo.com/elon-musk-blue-checkmark-verified-twitter-1849811765">Read more...</a></p>

## More Details About Phoebe Waller-Bridge's Mysterious Indiana Jones 5 Character
 - [https://gizmodo.com/indiana-jones-5-phoebe-waller-bridge-helena-plot-1849806575](https://gizmodo.com/indiana-jones-5-phoebe-waller-bridge-helena-plot-1849806575)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 15:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--RjQVOYQ8--/c_fit,fl_progressive,q_80,w_636/14ca192adafeb59d41bb8dc0ec9abd0e.png" /><p><em>Ant-Man and the Wasp: Quantumania</em> teases Kang’s arrival. Filming has wrapped on <em>Star Trek: Discovery</em> season 5. New <em>M3GAN</em> footage turns up the pressure. Plus, what’s coming on <em>Chainsaw Man</em> this week, and a new look at <em>The Walking Dead: Dead City</em>. Spoilers, away!<br /></p><p><a href="https://gizmodo.com/indiana-jones-5-phoebe-waller-bridge-helena-plot-1849806575">Read more...</a></p>

## Hundreds of Arizona Households Set to Be Without Water by End of Year
 - [https://gizmodo.com/rio-verde-foothills-arizona-running-out-of-water-1849809657](https://gizmodo.com/rio-verde-foothills-arizona-running-out-of-water-1849809657)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 15:10:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--04Ul0s6U--/c_fit,fl_progressive,q_80,w_636/32b7622729aa86f90de1c659a6a4ead7.jpg" /><p>More than 500 households in the rural Arizona desert are set to be without running water starting January, 1 2023, as <a href="https://www.nbcnews.com/news/us-news/faucets-poised-run-dry-hundreds-arizona-residents-years-end-rcna57550" rel="noopener noreferrer" target="_blank">first reported</a> by NBC News. The homes, located in Rio Verde Foothills—an affluent, unincorporated community in the state’s Maricopa County, were built without complying to Arizona’s usual <a href="https://new.azwater.gov/aaws" rel="noopener noreferrer" target="_blank">100-year…</a></p><p><a href="https://gizmodo.com/rio-verde-foothills-arizona-running-out-of-water-1849809657">Read more...</a></p>

## Meta's 'Cicero' AI Trounced Humans at Diplomacy Without Revealing Its True Identity
 - [https://gizmodo.com/meta-ai-cicero-diplomacy-gaming-1849811840](https://gizmodo.com/meta-ai-cicero-diplomacy-gaming-1849811840)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 15:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--lOs_vygl--/c_fit,fl_progressive,q_80,w_636/d4d2fe6ffa6d57ed90a7cf11b9e3439d.jpg" /><p>Ever since IBM’s Deep Blue artificial intelligence system <a href="https://gizmodo.com/remembering-deep-blues-surprising-chess-triumph-over-a-1685073520">defeated</a> world chess champion Garry Kasparov at his own game in 1997, humanity has watched, haplessly, year after year as our code based underlings vanquish us in ever more <a href="https://gizmodo.com/lee-sedol-loses-final-go-match-making-it-a-4-1-victory-1764954190">complicated</a> <a href="https://gizmodo.com/ai-bot-is-the-first-to-play-starcraft-ii-at-the-grandma-1839471798">games</a>. There’s a catch though. While AI bots increasingly excel at trumping…</p><p><a href="https://gizmodo.com/meta-ai-cicero-diplomacy-gaming-1849811840">Read more...</a></p>

## The Xbox 360 Controller is Back, and Now it Natively Works With Modern Consoles
 - [https://gizmodo.com/hyperkin-xenon-xbox-360-controller-on-series-s-x-pc-1849807817](https://gizmodo.com/hyperkin-xenon-xbox-360-controller-on-series-s-x-pc-1849807817)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 14:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--aQRGkYvp--/c_fit,fl_progressive,q_80,w_636/b9b62a4843152adac29f85e9ab1502f5.jpg" /><p>You never forget your first game console, but like the bond between a newborn and parent, the bond between a gamer and their first <em>controller</em> is even stronger, forging muscle memories that will last a lifetime. And if your first console happened to be the Xbox 360, you might be thrilled to learn that Hyperkin is…</p><p><a href="https://gizmodo.com/hyperkin-xenon-xbox-360-controller-on-series-s-x-pc-1849807817">Read more...</a></p>

## Why Do We Love the Music We Love?
 - [https://gizmodo.com/music-neuroscience-susan-rogers-book-1849801399](https://gizmodo.com/music-neuroscience-susan-rogers-book-1849801399)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 13:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s---3I0uUvq--/c_fit,fl_progressive,q_80,w_636/2d4af5d52f2824965fc632476de2b387.jpg" /><p>If you’ve ever made a playlist—for yourself or someone else—you’ve done the delicate dance of music curation. By what logic did you order the songs? What nearly made it on, but got left out, and why?<br /></p><p><a href="https://gizmodo.com/music-neuroscience-susan-rogers-book-1849801399">Read more...</a></p>

## An iCloud Feature Is Enabling a $65 Million Scam, New Research Says
 - [https://gizmodo.com/apple-icloud-private-relay-ad-fraud-scam-research-1849803510](https://gizmodo.com/apple-icloud-private-relay-ad-fraud-scam-research-1849803510)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 12:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--y0JQIlTC--/c_fit,fl_progressive,q_80,w_636/499b7292d2664dbd9563807d909b2e38.jpg" /><p>As you read this, there’s an army of bots pretending to be Apple  users surfing the web and looking at ads, according to new research shared exclusively with Gizmodo. The ad fraud scheme is weaponizing a privacy feature called Private Relay, coopting a vast swath of traffic to show ads to robots and costing…</p><p><a href="https://gizmodo.com/apple-icloud-private-relay-ad-fraud-scam-research-1849803510">Read more...</a></p>

## Bitcoin Price Slides to Two-Year Low as Fears Persist Over FTX Contagion
 - [https://gizmodo.com/bitcoin-price-slides-fears-persist-ftx-contagion-eth-1849811382](https://gizmodo.com/bitcoin-price-slides-fears-persist-ftx-contagion-eth-1849811382)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 11:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Hp4XbMlz--/c_fit,fl_progressive,q_80,w_636/e20e15c2c69269e8476e99a9a8e9ed9a.png" /><p>The price of Bitcoin slid to just $15,680 on Tuesday morning, the lowest level in over two years for the cryptocurrency. And most people expect the price to continue to fall substantially as traders worry the fallout from the implosion of FTX, once the second largest crypto platform in the world, could have more…</p><p><a href="https://gizmodo.com/bitcoin-price-slides-fears-persist-ftx-contagion-eth-1849811382">Read more...</a></p>

## Avatar: The Way of Water's Latest Trailer Is Pure James Cameron
 - [https://gizmodo.com/new-avatar-2-trailer-james-cameron-pandora-fox-disney-1849810435](https://gizmodo.com/new-avatar-2-trailer-james-cameron-pandora-fox-disney-1849810435)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 02:55:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--8kll7Ckw--/c_fit,fl_progressive,q_80,w_636/f90efb97f4e976cf4c8c3a9a075352d1.jpg" /><p>In James Cameron’s career to this point, he’s made exactly three sequels. One, <a href="https://gizmodo.com/all-5-piranha-movies-ranked-1847173845"><em>Piranha II</em></a><em>,</em> was his first film. It gets a pass. The other two, <a href="https://gizmodo.com/james-cameron-explains-why-the-original-aliens-poster-i-1848196917"><em>Aliens</em></a> and <a href="https://gizmodo.com/how-terminator-2-judgment-day-changed-the-blockbuster-1798318855"><em>Terminator 2: Judgment Day</em></a>, are inarguably two of the best sequels ever made. That’s why, with only a few short weeks to Cameron’s next film—another sequel—you’d be…</p><p><a href="https://gizmodo.com/new-avatar-2-trailer-james-cameron-pandora-fox-disney-1849810435">Read more...</a></p>

## Star Wars: The High Republic - Convergence Audiobook Excerpt
 - [https://gizmodo.com/star-wars-the-high-republic-convergence-audiobook-1849809065](https://gizmodo.com/star-wars-the-high-republic-convergence-audiobook-1849809065)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-22 00:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--YcyYEfuJ--/c_fit,fl_progressive,q_80,w_636/1909e50d072afbef065437748ef60bf1.jpg" /><p><a href="https://gizmodo.com/star-wars-the-high-republic-convergence-audiobook-1849809065">Read more...</a></p>


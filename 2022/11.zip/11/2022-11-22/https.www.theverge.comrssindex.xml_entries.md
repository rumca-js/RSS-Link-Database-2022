# Source:The Verge, URL:https://www.theverge.com/rss/index.xml, language:en-US

## The best Black Friday Google deals you can get
 - [https://www.theverge.com/23473576/black-friday-2022-google-deals-cyber-monday-pixel-watch-buds-nest-chromecast](https://www.theverge.com/23473576/black-friday-2022-google-deals-cyber-monday-pixel-watch-buds-nest-chromecast)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 23:05:00+00:00

<figure>
      <img alt="Pixel 7 and 7 Pro from the back" src="https://cdn.vox-cdn.com/thumbor/1xxGiAY1EzcrVylQDVn7paNRoSA=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71663874/226337_Pixel_7_and_7_Pro_AKrales_0494.0.jpg" />
        <figcaption><em>The Pixel 7 (left) and Pixel 7 Pro (right) are some of the many big Google deals going on.</em> | Photo by Amelia Holowaty Krales / The Verge</figcaption>
    </figure>

  <p id="c3yzvp">It’s a good time to be in the market for some new Google hardware. Google recently kicked off its Black Friday sales promotions on its store, and that set off a chain reaction of the same or better deals being offered all over. While some products on sale are mainstays that see frequent discounts (like the Nest Mini smart speaker for $19.99), there are also excellent deals on the latest flagship phones and accessories. For example, the Pixel 7 Pro is on sale for $749, and the new Pixel Watch is $50 off.</p>
<p id="LVnPFx">This may just be the tip of the iceberg of this season’s Black Friday sales, as there are all kinds of other early deals worth your attention. So we’ll forgive you if you need a moment to digest it all, but the good thing about these...</p>
  <p>
    <a href="https://www.theverge.com/23473576/black-friday-2022-google-deals-cyber-monday-pixel-watch-buds-nest-chromecast">Continue reading&hellip;</a>
  </p>

## The best Black Friday deals on gaming laptops
 - [https://www.theverge.com/23472236/black-friday-2022-gaming-laptop-deals-cyber-monday-acer-asus-alienware-dell](https://www.theverge.com/23472236/black-friday-2022-gaming-laptop-deals-cyber-monday-acer-asus-alienware-dell)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 22:28:49+00:00

<figure>
      <img alt="A white Asus thin gaming laptop on a green fabric surface, displaying a big Asus logo on a predominantly purple desktop background" src="https://cdn.vox-cdn.com/thumbor/naI_LDtxgD4rwGrIvcOuDGKD4bQ=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71663695/akrales_220215_5022_0166.0.jpg" />
        <figcaption><em>The Asus ROG Zephyrus G14.</em> | Photo by Amelia Holowaty Krales / The Verge</figcaption>
    </figure>

  <p id="I2pLUq">You’re not just looking for a workhorse. You want a laptop that’s got <em>game</em>. Maybe that means frame rates, maybe even a high-refresh-rate screen for enhanced responsiveness in less demanding games. But above all, you want bang for the buck. That’s why you’re buying right now, during <a href="https://www.theverge.com/23437426/black-friday-guide-cyber-monday-tech-gadgets-2022">Black Friday</a> week, when some of the best deals (and <a href="https://www.theverge.com/2022/7/13/23207152/worst-amazon-prime-day-deals-2022">a bunch of predatory fake ones</a>) show up.</p>
<p id="TUcSSS">These are the deals that caught my eye — the ones I might consider myself or recommend to a friend, depending on their needs and budget. Let’s start with the least expensive and go from there! </p>
<h2 id="xKkxgg">The best Black Friday gaming laptop deals</h2>
<div id="9er8Gj"><div></div></div>
<ul>
<li id="JrTQv6">
<a href="https://click.linksynergy.com/deeplink?id=nOD/rLJHOac&amp;mid=44583&amp;u1=Verge&amp;murl=https%3A%2F%2Fwww.newegg.com%2Fp%2FN82E16834233534" rel="sponsored nofollow noopener" target="_blank">The <strong>Gigabyte A5 K1</strong> is $729 at Newegg</a> ($470 off) or <a href="https://shop-links.co/ciyD4hNF4jU" rel="sponsored nofollow noopener" target="_blank">$749 at Best Buy</a>, a killer deal for midrange specs — an RTX 3060 (130W) and Ryzen...</li>
</ul>
  <p>
    <a href="https://www.theverge.com/23472236/black-friday-2022-gaming-laptop-deals-cyber-monday-acer-asus-alienware-dell">Continue reading&hellip;</a>
  </p>

## The best Black Friday deals on Apple devices
 - [https://www.theverge.com/23466789/apple-black-friday-2022-deals-cyber-monday-macbook-ipad-airtags-watch](https://www.theverge.com/23466789/apple-black-friday-2022-deals-cyber-monday-macbook-ipad-airtags-watch)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 21:29:13+00:00

<figure>
      <img alt="Nike watchface on Series 8." src="https://cdn.vox-cdn.com/thumbor/q1m6UhaF8lpod8bO4QZtkC7fYw8=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71663443/226266226266_APPLE_WATCH_8_SE_PHO_akrales_0685.0.jpg" />
        <figcaption><em>The Apple Watch Series 8 is $50 off in time for Black Friday.</em> | Photo by Amelia Holowaty Krales / The Verge</figcaption>
    </figure>

  <p id="Hk67zM">Plenty of tech is on sale for <a href="https://www.theverge.com/23437426/black-friday-guide-cyber-monday-tech-gadgets-2022">Black Friday and Cyber Monday</a> including Apple products. Below, we’ve compiled the best Black Friday deals on Apple devices that we could find, including laptops, iPads, Apple Watches, AirPods, and more. We’ll be keeping an eye out for iPhone deals as well, though we’ll likely see carrier discounts on Black Friday and not actual price cuts on hardware.</p>
<h2 id="WSKkjO">The best Black Friday iPad deals</h2>
<p id="7KNLnl">It’s a great time to buy an iPad. The <strong>base iPad from 2021 with a Lightning connector</strong> is a good value <a href="https://www.amazon.com/2021-Apple-10-2-inch-iPad-Wi-Fi/dp/B09G9FPHY6/?tag=theverge02-20" rel="sponsored nofollow noopener" target="_blank">for $269.99</a>. The $100 discount that brings the <a href="https://www.theverge.com/22696652/ipad-mini-2021-6th-gen-review"><strong>2021 iPad Mini</strong></a><strong> with a USB-C connector</strong> down to <a href="https://www.amazon.com/2021-Apple-iPad-Mini-Wi-Fi/dp/B09G91LXFP/?tag=theverge02-20" rel="sponsored nofollow noopener" target="_blank">$399.99 is good</a>, too, even though that deal isn’t new. If you’re looking for a high-end option, the <a href="https://www.theverge.com/22442084/ipad-pro-2021-review-features-screen-mini-led-m1-processor"><strong>2021 12.9-inch iPad Pro</strong></a><strong> with the M1...</strong></p>
  <p>
    <a href="https://www.theverge.com/23466789/apple-black-friday-2022-deals-cyber-monday-macbook-ipad-airtags-watch">Continue reading&hellip;</a>
  </p>

## The Best Black Friday deals on Amazon devices
 - [https://www.theverge.com/23466621/black-friday-2022-amazon-deals-cyber-monday-kindle-paperwhite-echo-dot-deal-sale](https://www.theverge.com/23466621/black-friday-2022-amazon-deals-cyber-monday-kindle-paperwhite-echo-dot-deal-sale)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 20:56:33+00:00

<figure>
      <img alt="An Echo Dot on a counter displaying the letters AYLO, as in TAYLOR SWIFT" src="https://cdn.vox-cdn.com/thumbor/Gk6i2YPJw4RdI30q1EIkUpeFrIQ=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71663293/226372_Echo_Dot_Clock_5th_Gen_J_0005.0.jpg" />
        <figcaption><em>Amazon just released its fifth-gen Echo Dot last month, but it’s already half off.</em> | Photo by Jennifer Pattison Tuohy / The Verge</figcaption>
    </figure>

  <p id="CwvCjH">Don’t worry if you missed out on the steep Amazon device discounts we saw during July’s Amazon’s Prime Day and October’s Prime Early Access Sale: Black Friday is here, and the deals in some cases are even better. With the holiday season just around the corner, the timing’s perfect, too, as even popular presents like the <a href="https://www.amazon.com/All-new-Kindle-Paperwhite-adjustable-Ad-Supported/dp/B08KTZ8249?tag=theverge02-20" rel="sponsored nofollow noopener" target="_blank">Kindle Paperwhite</a> are on sale at new all-time low prices. Even better, we’re even seeing some of the first significant discounts on Amazon’s recently launched tech, like the <a href="https://www.amazon.com/dp/B09B8V1LZ3?tag=theverge02-20" rel="sponsored nofollow noopener" target="_blank">fifth-gen Echo Dot</a>, which just came out last month and is already half off. </p>
<div><aside id="Kkpg7W"><div></div></aside></div>
<p id="GOxkNN">For your convenience, we’ve curated all the best deals you can currently get on Amazon devices in this post. If you want to save even more, though, be sure to check out our...</p>
  <p>
    <a href="https://www.theverge.com/23466621/black-friday-2022-amazon-deals-cyber-monday-kindle-paperwhite-echo-dot-deal-sale">Continue reading&hellip;</a>
  </p>

## Vivo’s X90 Pro Plus is the first phone with a Snapdragon 8 Gen 2 chipset
 - [https://www.theverge.com/2022/11/22/23473530/vivo-x90-qualcomm-snapdragon-8-gen-2](https://www.theverge.com/2022/11/22/23473530/vivo-x90-qualcomm-snapdragon-8-gen-2)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 20:38:45+00:00

<figure>
      <img alt="Vivo X90 Pro in red and black options with rear camera bump shown." src="https://cdn.vox-cdn.com/thumbor/eH6r3m2TsfeVuF9krsHGBanmOhg=/0x66:1562x1107/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71663245/x90_pro_plus.0.jpg" />
        <figcaption><em>The X stands for extreme, indeed.</em> | Image: Vivo</figcaption>
    </figure>

  <p id="4Pj7jL">Vivo <a href="https://www.vivo.com.cn/brand/news/detail?id=1108&amp;type=0">announced a trio of new flagship phones</a> today, and sitting at the top is the X90 Pro Plus, complete with <a href="https://www.theverge.com/2022/11/15/23458241/qualcomm-snapdragon-8-gen-2-chipset-processor-x70-5g-dynamic-spatial-audio">the brand-new Snapdragon 8 Gen 2 chipset announced just last week</a>. The 8 Gen 2 is expected to appear in plenty of Android flagships over the next year, including <a href="https://www.theverge.com/2022/9/28/23376318/galaxy-s23-plus-leaked-render-onleaks-three-cameras-6-1-6-6-inch-screen-2023">Samsung’s S23 series</a>, but the X90 Pro Plus has the honor of being the very first to market. It also includes some serious camera hardware, putting it up there with the most ambitious smartphone cameras to date. Unfortunately for us, it’s only launching in the Chinese market for now.</p>
<p id="2wtsEX">Vivo doesn’t outright name the X90 Pro Plus’ chipset as the 8 Gen 2, likely because of its partnership with MediaTek, but looking at the specs, you can connect the dots. The other two models...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23473530/vivo-x90-qualcomm-snapdragon-8-gen-2">Continue reading&hellip;</a>
  </p>

## Kia’s rebrand has left many people wondering who ‘KN’ is
 - [https://www.theverge.com/2022/11/22/23473452/kia-rebrand-kn-car-google-searches](https://www.theverge.com/2022/11/22/23473452/kia-rebrand-kn-car-google-searches)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 19:25:16+00:00

<figure>
      <img alt="Photo of the Kia EV6, showing the redesigned logo on its hatch." src="https://cdn.vox-cdn.com/thumbor/XvBLOmo0AAEFgybdx9xWBPoOQrQ=/357x304:1683x1188/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71662970/rbaldwin_220217_5051_0009.0.jpg" />
        <figcaption><em>What do you see when you look at this logo?</em> | Photo by Roberto Baldwin for The Verge</figcaption>
    </figure>

  <p id="u5nOLW">When I see <a href="https://www.thedrive.com/news/38599/youre-not-crazy-heres-why-kias-new-logo-looks-crooked">the relatively new Kia logo</a>, which is just the brand’s name but in an extremely angular, scrunched-up font with a seemingly connected “I” and <a href="https://www.theautopian.com/the-new-kia-logo-is-confusing-thousands-of-people-and-were-issuing-a-technical-service-bulletin-to-fix-it/">middle line-less “A,”</a> the first thing that comes to mind is “wow, that makes sense on a <a href="https://www.theverge.com/22960060/kia-ev6-review-electric-specs-price">state-of-the-art EV</a> but feels laughably out-of-place on <a href="https://www.youtube.com/watch?v=Fn_htHFC4cw">this minivan</a>.” But apparently, there are many, many people whose reaction is more along the lines of “wait... what does that say?”</p>
<p id="qtidYN">Each month, there are around 30,000 web searches for “KN car,” according to <a href="https://twitter.com/shwinnabego/status/1593377511030792197">data posted by ad agency owner Ashwinn Krishnaswamy</a> on Twitter. The spike in searches — which seems to come from people trying to figure out if they’d missed the launch of an entirely new car company — started early last year, right around the...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23473452/kia-rebrand-kn-car-google-searches">Continue reading&hellip;</a>
  </p>

## Marvel Snap introduces new cards and a way to get the cards you want
 - [https://www.theverge.com/2022/11/22/23473633/marvel-snap-new-cards-collectors-tokens](https://www.theverge.com/2022/11/22/23473633/marvel-snap-new-cards-collectors-tokens)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 19:19:37+00:00

<figure>
      <img alt="Graphic from Marvel Snap highlighting the Thanos and Galactus cards and the new currency Collectors Tokens" src="https://cdn.vox-cdn.com/thumbor/zS8g3J0gUV7dS6M70iDdZi4F2uc=/41x0:716x450/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71662946/758611840447_s607004.0.png" />
        <figcaption>Image: Second Dinner</figcaption>
    </figure>

  <p id="JOSTpf"><a href="https://www.theverge.com/23437497/marvel-snap-developer-design-interview-mobile-steam">The developers behind <em>Marvel Snap</em></a> keep giving the people what they want. <a href="https://www.marvelsnap.com/newsdetail?id=7168728561379973894">In a blog post</a>, the developers announced that in the next patch, they’re adding a slew of new cards and a way for players to get the cards they’ve been pining for.</p>
<p id="DzWcio">Right now, <a href="https://www.theverge.com/2022/11/19/23466357/marvel-snap-tips-collection-level-card-pools">the way you earn cards in <em>Marvel Snap</em></a> is by making your way up the collection rank ladder. Every so often, you’ll be rewarded with a new card from a specific pool at random. Random is all fun and good as it forces players to get creative in how they construct their decks so everyone isn’t running the same high-powered cards. But it still kinda sucks when you could craft the perfect deck to drive your enemies from you wailing and screaming if only you had that one card. (<a href="https://marvelsnapzone.com/cards/wong/">Wong</a>, I need Wong!)</p>
<p id="l8LtIj">C...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23473633/marvel-snap-new-cards-collectors-tokens">Continue reading&hellip;</a>
  </p>

## California’s last operating nuclear plant just got a $1.1 billion lifeline
 - [https://www.theverge.com/2022/11/22/23473116/diablo-canyon-nuclear-power-plant-california-energy-department-biden-funding](https://www.theverge.com/2022/11/22/23473116/diablo-canyon-nuclear-power-plant-california-energy-department-biden-funding)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 18:00:18+00:00

<figure>
      <img alt="Diablo Canyon nuclear power plant sits on cliffs next to the ocean." src="https://cdn.vox-cdn.com/thumbor/BHm1LcynULkR_vlP9jxFpsasifc=/0x85:5186x3542/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71662527/1356860583.0.jpg" />
        <figcaption><em>Aerial view of the Diablo Canyon, the only operational nuclear plant left in California.</em> | Photo by George Rose / Getty Images</figcaption>
    </figure>

  <p id="nikBzs">The Department of Energy extended a $1.1 billion lifeline to California’s embattled Diablo Canyon nuclear power plant. Diablo Canyon has become a major flashpoint over what kinds of energy are considered “clean” and what risks policymakers are willing to take to reach their climate goals.</p>
<p id="QBPHIH">The $1.1 billion in funding, <a href="https://www.energy.gov/articles/biden-harris-administration-announces-major-investment-preserve-americas-clean-nuclear">announced</a> yesterday, comes from a $6 billion Civil Nuclear Credit program made possible by the <a href="https://www.theverge.com/2021/11/15/22783684/biden-infrastructure-bill-bipartisan-broadband-ev-electrical-grid-climate">Bipartisan Infrastructure Law</a> Congress passed last year. Diablo Canyon is the first power plant to be awarded credits from the program, which aims to extend the lives of reactors in danger of closing down.</p>
<p id="LGpZZq">The two nuclear reactors at Diablo Canyon were slated to be decommissioned one by one in 2024 and 2025, when their operating...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23473116/diablo-canyon-nuclear-power-plant-california-energy-department-biden-funding">Continue reading&hellip;</a>
  </p>

## NASA’s Orion spacecraft makes close flyby of the Moon and heads on to orbit
 - [https://www.theverge.com/2022/11/22/23473444/artemis-1-orion-flyby-moon](https://www.theverge.com/2022/11/22/23473444/artemis-1-orion-flyby-moon)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 17:46:16+00:00

<figure>
      <img alt="A white spacecraft with NASA’s logo in red is on the left with the disc of the moon in the center." src="https://cdn.vox-cdn.com/thumbor/mSD4BJnQ-8XX94pPZFn9n0X5u-o=/0x100:1536x1124/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71662406/art001e000269_1536x1152.0.jpeg" />
        <figcaption><em>NASA’s Orion capsule snaps a selfie, with the far side of the Moon in the background.</em> | Image: NASA</figcaption>
    </figure>

  <p id="VV4RW1">NASA’s Orion spacecraft has made it past the Moon as part of the uncrewed Artemis I mission, firing its engines to pass within 81 miles of the lunar surface, and is operating with high accuracy. </p>
<p id="7YPnoH">The spacecraft performed an outbound powered flyby burn yesterday, Monday, November 21st, completing its closest flyby. The engines “all worked perfectly,” said Judd Frieling, a flight director at NASA’s Johnson Space Center, in a press conference. With three trajectory correction burns performed, the spacecraft has now fired all three of its thruster types: its large orbital maneuvering system engine, small reaction control system thrusters, and medium-sized auxiliary engines.</p>
<p id="O125Y3">Now Orion is traveling onward to its next target, a distant...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23473444/artemis-1-orion-flyby-moon">Continue reading&hellip;</a>
  </p>

## Last.fm turns 20 and now has a following on Discord
 - [https://www.theverge.com/2022/11/22/23473358/lastfm-discord-bot-neil-young-spotify](https://www.theverge.com/2022/11/22/23473358/lastfm-discord-bot-neil-young-spotify)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 17:30:00+00:00

<figure>
      <img alt="last.fm logo" src="https://cdn.vox-cdn.com/thumbor/GRVT7nCOfq-z_Y77_eR1lDEACCE=/0x17:1000x684/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71662312/Last.fm_Logo_Red.0.jpg" />
    </figure>

  <p id="qME2qN"><em>This is Hot Pod, The Verge’s newsletter about podcasting and the audio industry. </em><a href="https://www.theverge.com/pages/hot-pod-podcast-audio-newsletter"><em>Sign up here</em></a><em> for more.</em></p>
<hr class="p-entry-hr" id="P42dau" />
<p id="aYk9Un">Thanksgiving is almost here, and I’ve already eaten half a bag of King’s Hawaiian rolls. I’m looking forward to signing off, seeing family, and eating a lot more bread later this week. But for now: podcasts. Or music, actually — most of this week’s news is about streaming music and what we listen to. And mostly, this week’s newsletter is about a service I have very fond memories of, even if I haven’t used it in many, many years.</p>
<p id="EfvZic">Today, we’ve got a check-in on Last.fm and its burgeoning presence on Discord, an update on Neil Young on Spotify, a new audio editing tool from Anchor, and an expansion of Spotify’s audiobook efforts.</p>
<p id="U1ArRT">A quick...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23473358/lastfm-discord-bot-neil-young-spotify">Continue reading&hellip;</a>
  </p>

## Netflix’s heist series Kaleidoscope can be watched in any order
 - [https://www.theverge.com/2022/11/22/23473254/netflix-kaleidoscope-non-linear-crime-series-trailer-date](https://www.theverge.com/2022/11/22/23473254/netflix-kaleidoscope-non-linear-crime-series-trailer-date)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 16:24:38+00:00

<figure>
      <img alt="A photo of Giancarlo Esposito in the Netflix series Kaleidoscope." src="https://cdn.vox-cdn.com/thumbor/ofAFcqAcZYcw9yzzA4LLNUiC9y8=/0x0:3600x2400/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71661992/KALEIDOSCOPE_Red_Unit_00992RC.0.jpg" />
        <figcaption>Giancarlo Esposito in Kaleidoscope. | Image: Netflix</figcaption>
    </figure>

  <p id="1KF2OK">There are <em>a lot</em> of crime shows on Netflix, but the upcoming series <em>Kaleidoscope</em> offers something a little different: the option to watch in whatever order you want. The nonlinear series is a heist drama that stars Giancarlo Esposito, Paz Vega, and Tati Gabrielle and is loosely based on a true story. Here’s the basic setup:</p>
<blockquote><p id="s5yBkO">Spanning 25 years, <em>Kaleidoscope</em> is an all-new anthology series following a crew of masterful thieves and their attempt to crack a seemingly unbreakable vault for the biggest payday in history. Guarded by the world’s most powerful corporate security team, and with law enforcement on the case, every episode reveals a piece of an elaborate puzzle of corruption, greed, vengeance, scheming, loyalties and betrayals. How did...</p></blockquote>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23473254/netflix-kaleidoscope-non-linear-crime-series-trailer-date">Continue reading&hellip;</a>
  </p>

## Everyone thinks Apple’s negotiations with the NFL are dragging on
 - [https://www.theverge.com/2022/11/22/23471824/apple-nfl-negotiations-sunday-ticket-dragging-on](https://www.theverge.com/2022/11/22/23471824/apple-nfl-negotiations-sunday-ticket-dragging-on)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 16:10:27+00:00

<figure>
      <img alt="The NFL logo on a yellow and red background" src="https://cdn.vox-cdn.com/thumbor/W-HiqTnBy9TD1GOS9Kl8_VD_oJw=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71661943/acastro_STK099_NFL_02.0.jpg" />
        <figcaption>Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="xgrOMT">While Apple’s still the “front-runner” when it comes to securing the rights to the NFL Sunday Ticket, negotiations are taking unexpectedly long. That’s according to <a href="https://go.redirectingat.com?id=66960X1514734&amp;xs=1&amp;url=https%3A%2F%2Ftheathletic.com%2F3907524%2F2022%2F11%2F18%2Fnfl-sunday-ticket-apple-directv%2F&amp;referrer=theverge.com&amp;sref=https%3A%2F%2Fwww.theverge.com%2F2022%2F11%2F22%2F23471824%2Fapple-nfl-negotiations-sunday-ticket-dragging-on" rel="sponsored nofollow noopener" target="_blank">a report from <em>The Athletic</em></a> (<a href="https://9to5mac.com/2022/11/21/nfl-sunday-ticket-apple-taking-streaming-football-negotiations-into-overtime-over-rights-to-the-unknown/">via <em>9to5Mac</em></a>), which indicates things have slowed down because Apple may be looking to score the rights to more than just the football games.</p>
<p id="ZXxH9L">The rights to NFL Sunday Ticket — which DirecTV has held for nearly three decades — expire after this football season. <a href="https://www.npr.org/2022/09/04/1120952699/apple-amazon-and-google-are-in-a-bidding-war-to-acquire-the-nfl-sunday-ticket">Amazon, YouTube</a>, and <a href="https://www.cnbc.com/2022/06/24/disney-apple-and-amazon-keep-waiting-as-nfl-considers-sunday-ticket-offers.html">Disney</a> are also said to have placed bids to secure the rights to the out-of-market games package, which the NFL reportedly wants $3.5 billion for.</p>
<p id="ZWQ1bv">But <em>The Athletic</em> reports that Apple expected it would gain the rights to aspects not specifically mentioned in its contract...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23471824/apple-nfl-negotiations-sunday-ticket-dragging-on">Continue reading&hellip;</a>
  </p>

## Are crypto bros really selling their Lamborghinis?
 - [https://www.theverge.com/2022/11/22/23466319/crypto-collapse-exotic-car-lamborghini-gwagon-sale](https://www.theverge.com/2022/11/22/23466319/crypto-collapse-exotic-car-lamborghini-gwagon-sale)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 15:41:53+00:00

<figure>
      <img alt="Lamborghini Huracan ST hood" src="https://cdn.vox-cdn.com/thumbor/3etZQTx_SMuZByVyVYGncTK78eo=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71661768/ahawkins_211006_4810_0015.0.jpg" />
        <figcaption>Photo by Andrew Hawkins / The Verge</figcaption>
    </figure>

  <p id="gCUg6B">Cryptocurrency traders <a href="https://digiday.com/marketing/lambo-lamborghini-became-status-brand-crypto-boom/">love Lamborghinis</a>. Hang out in the parking lot of any Bitcoin conference or lurk around on Instagram, and you’ll see plenty of evidence of this. So with crypto prices plummeting and <a href="https://www.theverge.com/2022/11/15/23459268/sam-bankman-fried-ftx-bankruptcy-crypto-lobbying-washington">high-profile exchanges like FTX</a> collapsing, it stands to reason that the used car lots would be overflowing with six-figure Italian supercars, right?</p>
<p id="TqpRXg">It’s a nice theory, and while there is some evidence that the exotic car market is seeing a slight uptick in appraisals and used models for sale, it may be too early to conclusively connect it to the collapse in crypto. </p>
<p id="njboJJ">Yeah, I know. Buzzkill. But that said, there is certainly some interesting data out there, so let’s dive into it. </p>
<div id="bfbiPq">
<blockquote class="instagram-media"><div style="padding: 16px;"> <a href="https://www.instagram.com/p/CeZBpyxst2A/?utm_source=ig_embed&amp;utm_campaign=loading" style="line-height: 0; padding: 0 0; text-align: center; text-decoration: none; width: 100%;" target="_blank"> <div style="display: flex;"> <div style="background-color: #F4F4F4; border-radius: 50%; height: 40px; margin-right: 14px; width: 40px;"></div> <div style="display: flex;"> <div style="background-color: #F4F4F4; border-radius: 4px; height: 14px; margin-bottom: 6px; width: 100px;"></div> <div style="background-color: #F4F4F4; border-radius: 4px; height: 14px; width: 60px;"></div>
</div>
</div>
<div style="padding: 19% 0;"></div> <div style="display: block; height: 50px; margin: 0 auto 12px; width: 50px;"></div>
<div style="padding-top: 8px;"> <div style="color: #3897f0; font-family: Arial,sans-serif; font-size: 14px; font-style: normal; font-weight: 550; line-height: 18px;">View this post on Instagram</div>
</div>
<div style="padding: 12.5% 0;"></div> <div style="display: flex; margin-bottom: 14px;">
<div> <div></div> <div></div> <div></div>
</div>
<div style="margin-left: 8px;"> <div style="background-color: #F4F4F4; border-radius: 50%; height: 20px; width: 20px;"></div> <div></div>
</div>
<div style="margin-left: auto;"> <div></div> <div></div> <div></div>
...</div>
</div></a>
</div></blockquote>
</div>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23466319/crypto-collapse-exotic-car-lamborghini-gwagon-sale">Continue reading&hellip;</a>
  </p>

## Tee up with golf in Nintendo Switch Sports
 - [https://www.theverge.com/2022/11/22/23473083/nintendo-switch-sports-golf-update-free](https://www.theverge.com/2022/11/22/23473083/nintendo-switch-sports-golf-update-free)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 15:02:10+00:00

<figure>
      <img alt="Screenshot from Nintendo Switch Sports featuring a blue-haired boy teeing up to swing on the green." src="https://cdn.vox-cdn.com/thumbor/i8ypFaFnCjPtDj6KhBHzAdPVyds=/0x0:759x506/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71661582/ezgif.com_gif_maker__15_.0.jpg" />
        <figcaption>Image: Nintendo</figcaption>
    </figure>

  <p id="QuSRoe">Listen up, birdies and bogeys. Today, <a href="https://nintendoswitchsports.nintendo.com/en/news/#!/get-ready-to-step-up-to-the-tee-on-nov-28">Nintendo announced</a> that golf is finally coming to <a href="https://www.theverge.com/2022/4/27/23044617/nintendo-switch-sports-wii-sports-party-game"><em>Nintendo Switch Sports</em></a>. The free update launches on November 28th and will include 21 holes from the <em>Wii Sports </em>games. The update also includes a survival golf game mode, which sounds so much more fun than actual golf.</p>
<p id="f7K4RQ">The <em>Nintendo Switch Sports</em> golf update is right on time as quirky golf games seem to be all the rage, with <a href="https://www.polygon.com/reviews/23308582/cursed-to-golf-impressions-review-ps4-ps5-xbox-one-series-x-windows-pc-nintendo-switch"><em>Cursed to Golf</em></a>, <em>Golf Story,</em> and <em>What the Golf</em> exploding in popularity. </p>
<p id="fEDqFj">Golf was not included in the base <em>Nintendo Switch Sports</em> game and was sorely missed by <em>Wii Sports</em> golf fans (including a couple of my colleagues at <em>The Verge</em>). Since its spring launch, <em>Nintendo Switch Sports</em> got a free update that <a href="https://www.theverge.com/2022/7/22/23274023/nintendo-switch-sports-free-update-soccer-kick-mode">improved soccer’s motion...</a></p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23473083/nintendo-switch-sports-golf-update-free">Continue reading&hellip;</a>
  </p>

## Hyperkin is remaking the Xbox 360 controller for modern consoles and PC
 - [https://www.theverge.com/2022/11/22/23473019/hyperkin-xbox-360-controller-xenon-remake-features](https://www.theverge.com/2022/11/22/23473019/hyperkin-xbox-360-controller-xenon-remake-features)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 14:30:00+00:00

<figure>
      <img alt="A render of a white Xbox 360 controller." src="https://cdn.vox-cdn.com/thumbor/XacbiNvt8cp_wZJaMZ5s66DAxec=/0x0:1223x815/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71661418/Xenon_White_Transparent.0.png" />
        <figcaption><em>An early render of the Xenon controller in the original Xbox 360 white. It will also come in black, pink, and red.</em> | Image: Hyperkin</figcaption>
    </figure>

  <p id="7j4dbR">Hyperkin is introducing an officially licensed remake of Microsoft’s original Xbox 360 controller, which looks poised to bring the 2005 nostalgia trip to modern Xbox consoles and Windows PCs. The Xenon controller, named after the Xbox 360’s first internal development codename, brings back the 17-year-old design and modernizes things with Menu, View, and Share buttons, as well as a 3.5mm headphone jack and detachable USB-C cable. In addition to the original white, it will come in black, pink, and red.</p>
<p id="zjFNsB">Pricing and availability have not been announced yet, but if <a href="https://www.theverge.com/circuitbreaker/2017/6/12/15780554/microsoft-xbox-one-x-controller-original-the-duke-all-hail-hyperkin">Hyperkin’s $70 Duke</a> controller remake is any indication, this may be quite a faithful and somewhat pricey recreation. Perhaps even too faithful in some small aspects, as these...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23473019/hyperkin-xbox-360-controller-xenon-remake-features">Continue reading&hellip;</a>
  </p>

## There’s a huge amount of new (and expensive) tech behind Avatar: The Way of Water
 - [https://www.theverge.com/23473033/avatar-way-of-water-trailer-technology-james-cameron](https://www.theverge.com/23473033/avatar-way-of-water-trailer-technology-james-cameron)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 14:24:54+00:00

<figure>
      <img alt="A still image from Avatar: The Way of Water" src="https://cdn.vox-cdn.com/thumbor/oNcNiraixUnKWKwKLWeMXlORx4g=/214x0:1834x1080/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71661408/Avatar_Way_of_Water.0.jpg" />
        <figcaption>Avatar: The Way of Water<em> is out December 16th.</em> | Screenshot:&nbsp;<em>Avatar: The Way of Water</em></figcaption>
    </figure>

  <p id="YZIqxo">There’s a new trailer out for <em>Avatar: The Way of Water, </em>the upcoming film from James Cameron that is also the sequel to the highest-grossing movie of all time. It’s as visually spectacular as you’d expect while also diving a bit deeper into the family-first story at the heart of the film. Here it is — it’s fun!</p>
<div id="pik6sF"><div style="width: 100%; height: 0; padding-bottom: 56.25%;"></div></div>
<p id="5w7nDk">However you feel about <em>Avatar</em> as a story (if you even remember the story at all), there’s no denying the technical achievements Cameron and his crew pulled off to make these movies happen. And <a href="https://www.gq.com/story/james-cameron-profile-men-of-the-year-2022">in an excellent new <em>GQ </em>profile</a>, Cameron explains the AI, algorithms, entirely new cameras, and all sorts of other tech behind this one:</p>
<blockquote><p id="wBTQb7">The process for how Cameron builds the <em>Avatar</em> films is complex; it involves creating a data-rich but...</p></blockquote>
  <p>
    <a href="https://www.theverge.com/23473033/avatar-way-of-water-trailer-technology-james-cameron">Continue reading&hellip;</a>
  </p>

## Amazon’s latest Kindle Paperwhite is down to its lowest price to date
 - [https://www.theverge.com/2022/11/22/23471338/kindle-paperwhite-apple-watch-black-friday-deals-sonos-sl-anker-soundcore-earbuds](https://www.theverge.com/2022/11/22/23471338/kindle-paperwhite-apple-watch-black-friday-deals-sonos-sl-anker-soundcore-earbuds)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 14:14:12+00:00

<figure>
      <img alt="The Kindle Paperwhite e-reader turned on resting on a bunch of analog books." src="https://cdn.vox-cdn.com/thumbor/9V0IBbcX-LKZEjIFHeFLmqWUviM=/0x227:1360x1134/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71661377/cgartenberg_211020_4819_0006_2.0.jpg" />
        <figcaption><em>The latest Kindle Paperwhite starts at $94.99 instead of $139.99 at Amazon. </em> | Image: Amazon</figcaption>
    </figure>

  <p id="YZmYZ8">Want to gift the bibliophile in your life something a little more creative than, well, a book? Amazon’s latest <strong>Kindle Paperwhite</strong> makes for a great gift, one that may not stay in stock for long when <a href="https://www.theverge.com/23437426/black-friday-guide-cyber-monday-tech-gadgets-2022">Black Friday</a> officially lands on Friday. Thankfully, the ad-supported version with 8GB of storage is available right now for $94.99 instead of $139.99 at <a href="https://www.amazon.com/All-new-Kindle-Paperwhite-adjustable-Ad-Supported/dp/B08KTZ8249?tag=theverge02-20" rel="sponsored nofollow noopener" target="_blank">Amazon</a>, <a href="https://shop-links.co/ciycYljJ6RW" rel="sponsored nofollow noopener" target="_blank">Best Buy</a>, and <a href="https://goto.target.com/c/1141873/1521182/2092?subId1=TheVergeDailyDealsNov21222&amp;u=https%3A%2F%2Fwww.target.com%2Fp%2Famazon-kindle-paperwhite-6-8-34-8gb-e-reader-with-adjustable-warm-light-black%2F-%2FA-84609459%3Fref%3Dtgt_adv_XS000000%26AFID%3Dgoogle_pla_df%26fndsrc%3Dtgtao%26DFA%3D71700000014846099%26CPNG%3DPLA_Electronics%252BShopping_Brand%257CElectronics_Ecomm_Hardlines%26adgroup%3DSC_Electronics%26LID%3D700000001170770pgs%26LNM%3DPRODUCT_GROUP%26network%3Dg%26device%3Dc%26location%3D9031583%26targetid%3Dpla-82462110169%26ds_rl%3D1246978%26ds_rl%3D1248099%26gclid%3DCj0KCQiA4OybBhCzARIsAIcfn9leJW0tjKxf2Pkq9MR_6wJbm_WmzWC6DWiEavmTiPggBY9GfIem1jsaAjVmEALw_wcB%26gclsrc%3Daw.ds" rel="sponsored nofollow noopener" target="_blank">Target</a>, while the ad-free version is <a href="https://www.amazon.com/All-new-Kindle-Paperwhite-adjustable-Ad-Supported/dp/B09RD7XM9X?tag=theverge02-20" rel="sponsored nofollow noopener" target="_blank">on sale at Amazon for just $10 more</a>.</p>
<div class="c-float-left c-float-hang"><aside id="hJNl66"><div></div></aside></div>
<p id="d51Ao3">Although we can’t be sure that Amazon’s terrific e-reader won’t drop further in price in the run-up to Black Friday or on the actual shopping holiday, the current sale price represents an all-time low on the 2021 Paperwhite. It's a terrific e-reader (even at full price), with months-long battery...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23471338/kindle-paperwhite-apple-watch-black-friday-deals-sonos-sl-anker-soundcore-earbuds">Continue reading&hellip;</a>
  </p>

## Wyze’s new BR30 smart bulb is designed for downlighting
 - [https://www.theverge.com/2022/11/22/23472919/wyze-bulb-color-br30-price-features](https://www.theverge.com/2022/11/22/23472919/wyze-bulb-color-br30-price-features)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 14:05:25+00:00

<figure>
      <img alt="A living room with purple downlighting." src="https://cdn.vox-cdn.com/thumbor/SRRlPGZ1ocfuHLXxs5LSoRVpRcA=/125x0:1745x1080/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71661356/Wyze_Bulb_Color_BR30_5.0.jpg" />
        <figcaption><em>Wyze launches a new BR30 smart light bulb.</em> | Image: Wyze</figcaption>
    </figure>

  <p id="Xtpq5a">Wyze’s new<a href="https://go.redirectingat.com?id=66960X1514734&amp;xs=1&amp;url=https%3A%2F%2Fwww.wyze.com%2Fproducts%2Fwyze-bulb-color-br30&amp;referrer=theverge.com&amp;sref=https%3A%2F%2Fwww.theverge.com%2F2022%2F11%2F22%2F23472919%2Fwyze-bulb-color-br30-price-features" rel="sponsored nofollow noopener" target="_blank"> Wi-Fi BR30 color bulb</a> fills a gap in the budget smart home company’s lighting lineup — recessed can lighting. BR30s generally fit into holes in your ceiling and, with their directional light, are great for larger rooms such as kitchens and living areas. The new bulbs <a href="https://go.redirectingat.com?id=66960X1514734&amp;xs=1&amp;url=https%3A%2F%2Fwww.wyze.com%2Fproducts%2Fwyze-bulb-color-br30&amp;referrer=theverge.com&amp;sref=https%3A%2F%2Fwww.theverge.com%2F2022%2F11%2F22%2F23472919%2Fwyze-bulb-color-br30-price-features" rel="sponsored nofollow noopener" target="_blank">cost $23.99 plus $5.99 shipping</a> for a two-pack or as low as $12.50 per bulb in a four-pack (plus shipping), making the Wyze Bulb Color BR30 a well-priced, if not spectacular bargain. </p>
<p id="xvvdjK">Comparatively, Philips Hue’s color <a href="https://www.amazon.com/Philips-Hue-Bluetooth-Compatible-578096/dp/B0B9ZXFBN1?tag=theverge02-20" rel="sponsored nofollow noopener" target="_blank">BR30s go for $100 for two</a>, but you can find good, budget Wi-Fi BR30 bulbs in two-packs from the likes of <a href="https://www.amazon.com/WiZ-Connected-Compatible-Assistant-Required/dp/B09XWR6JY1?tag=theverge02-20" rel="sponsored nofollow noopener" target="_blank">Wiz ($28)</a> and <a href="https://www.amazon.com/Sengled-Recessed-Equivalent-Changing-Required/dp/B097CYHRZJ?tag=theverge02-20" rel="sponsored nofollow noopener" target="_blank">Sengled ($35)</a>. Both of those have lower lumen outputs, though, making Wyze the brighter budget bulb.</p>
<p id="gjnKOJ">The Wyze bulbs work with...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23472919/wyze-bulb-color-br30-price-features">Continue reading&hellip;</a>
  </p>

## What to expect at Fortnite’s ‘otherworldly and unexpected’ chapter 3 finale
 - [https://www.theverge.com/2022/11/22/23471758/fortnite-chapter-3-finale-fracture-live-event](https://www.theverge.com/2022/11/22/23471758/fortnite-chapter-3-finale-fracture-live-event)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 14:00:33+00:00

<figure>
      <img alt="Key art for Fortnite’s “Fracture” live event." src="https://cdn.vox-cdn.com/thumbor/EUBTbsfwFXPmCcCInueLXqm2EGM=/150x0:1770x1080/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71661343/Fracture___Key_Art_EN.0.jpg" />
        <figcaption>Image: Epic Games</figcaption>
    </figure>

  <p id="B5Tkbf">The third chapter of <em>Fortnite</em> is ending with a live event — and it kicks off very soon. Today, developer Epic Games provided some details on the event, which is called “<a href="https://www.epicgames.com/fortnite/en-US/news/the-fortnite-fracture-chapter-3-finale-event-play-it-on-december-3">Fracture</a>” and starts at 4PM ET on December 3rd. As with past live events, you only have one chance to check it out. You’ll be able to log in 30 minutes before it kicks off, and Epic also says you should still be able to hop on while the event is in progress, which will apparently be until 4:40PM ET, and you can be solo or in a group with up to four friends.</p>
<div class="c-float-left c-float-hang"><aside id="UhCPPB"><div></div></aside></div>
<p id="KT5l7P">Of course, we don’t have many details about what the actual live experience will be like. The fun of these is experiencing them live in the moment. Epic does say that “Fracture” will be “an otherworldly and unexpected...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23471758/fortnite-chapter-3-finale-fracture-live-event">Continue reading&hellip;</a>
  </p>

## The only constant at Elon Musk’s Twitter is chaos
 - [https://www.theverge.com/2022/11/22/23472498/elon-musk-layoffs-chaos-trump-moderation-code-reviews](https://www.theverge.com/2022/11/22/23472498/elon-musk-layoffs-chaos-trump-moderation-code-reviews)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 14:00:00+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/15VDLkkOHzJiz6HCCKSvjAeKJuA=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71661268/STK171_VRG_Illo_16_Normand_ElonMusk_16.0.jpg" />
        <figcaption>Laura Normand / The Verge</figcaption>
    </figure>


  		 <p>From restoring Trump to continuous layoffs, more scenes from inside Elon Musk’s Twitter</p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23472498/elon-musk-layoffs-chaos-trump-moderation-code-reviews">Continue reading&hellip;</a>
  </p>

## The best noise-canceling headphones to buy right now
 - [https://www.theverge.com/21345733/best-noise-canceling-headphones](https://www.theverge.com/21345733/best-noise-canceling-headphones)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 13:30:03+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/1Yi9sFXnZ3b-FYYS4HNbyWq5zLc=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/67126629/DSCF7916.15.jpg" />
        <figcaption><em>Sony’s WH-1000XM5 headphones have an all-new design.</em> | Photo by Chris Welch / The Verge</figcaption>
    </figure>


  		 <p>Get some peace and quiet with the best noise-canceling headphones for a variety of uses</p>
  <p>
    <a href="https://www.theverge.com/21345733/best-noise-canceling-headphones">Continue reading&hellip;</a>
  </p>

## DJI introduces new O3 Air FPV camera, starting at $229
 - [https://www.theverge.com/2022/11/22/23472970/dji-o3-air-fpv-camera-drone-flight-goggles-announcement-price](https://www.theverge.com/2022/11/22/23472970/dji-o3-air-fpv-camera-drone-flight-goggles-announcement-price)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 13:00:11+00:00

<figure>
      <img alt="A lifestyle shot of the DJI O3 Air FPV camera on a clear mount in front of a blue skyline." src="https://cdn.vox-cdn.com/thumbor/qy1RZQM_PH3VDGhjLofy25F8mJs=/312x122:2934x1870/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71661118/DJI_O3_Air.0.jpg" />
        <figcaption><em>The new DJI O3 Air FPV camera can capture video at 4K/60 fps and transmit a live video feed from up to 10 km away.</em> | Image: DJI</figcaption>
    </figure>

  <p id="rJCvjW">DJI has introduced the O3 Air Unit, its latest combined first-person view camera and transmission system for drone pilots looking to explore FPV racing and experiences.</p>
<p id="Nmm5jb">The O3 Air Unit uses a 1/1.7-inch sensor to capture video at 4K/60 fps. A 155° field-of-view is available, but only when the aspect ratio is set to 4:3 and recording quality is reduced to 2.7K at 50/60fps or 1080p at 50fps/60fps. Footage can be stabilized with DJI’s RockSteady technology and shot in D-Cinelike, DJI’s unique video color profile that preserves shadows, highlights, and mid-tones for post-production.</p>
  <figure class="e-image">
        
      <cite>Image: DJI</cite>
      <figcaption><em>The O3 Air Unit costs $229 and includes the Camera Module, Transmission Module, Antenna, and 3-in-1 cable.</em></figcaption>
  </figure>
<p id="Gzf6Sq">The unit’s 2T2R...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23472970/dji-o3-air-fpv-camera-drone-flight-goggles-announcement-price">Continue reading&hellip;</a>
  </p>

## Instagram should have rejected police pressure to ban rap song, says Oversight Board
 - [https://www.theverge.com/2022/11/22/23471355/meta-oversight-board-drill-music-uk-instagram-decision](https://www.theverge.com/2022/11/22/23471355/meta-oversight-board-drill-music-uk-instagram-decision)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 13:00:00+00:00

<figure>
      <img alt="Instagram logo" src="https://cdn.vox-cdn.com/thumbor/9o8Ej9WlxLQKIgAUw9TmRtwSLD8=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71661021/acastro_STK070__01.0.jpg" />
        <figcaption>Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="b7uhHl">The Meta Oversight Board says the company shouldn’t have accepted police demands to remove drill music — a rap genre some politicians and officials have blamed for gang violence — from its platform. The board says Instagram erred in banning a UK drill song after a request from London’s Metropolitan Police.</p>
<p id="Kycgmb">Additionally, the board is pushing Meta to offer more transparency about its relationship with law enforcement in the future, as well as stronger consideration of a work’s artistic context. Meta must reverse the ban and respond to policy recommendations within 60 days.</p>
<p id="76T5kp">The board’s decision, published today, covers <a href="https://www.insider.com/meta-uk-drill-music-video-chinx-law-enforcement-takedown-request-2022-8">a January incident</a> over a song called “Secrets Not Safe” by musician Chinx (OS). Police emailed Meta a request soon after...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23471355/meta-oversight-board-drill-music-uk-instagram-decision">Continue reading&hellip;</a>
  </p>

## Lyft is recycling its e-bike and scooter batteries with ex-Tesla founder’s firm
 - [https://www.theverge.com/2022/11/22/23471884/lyft-redwood-materials-battery-recycle-ebike-scooter](https://www.theverge.com/2022/11/22/23471884/lyft-redwood-materials-battery-recycle-ebike-scooter)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 13:00:00+00:00

<figure>
      <img alt="Citibike bike sharing station, Manhattan, New York City" src="https://cdn.vox-cdn.com/thumbor/k0WqXwTHWgJp01cs721yLAXlYvU=/0x168:4032x2856/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71661032/1405850104.0.jpg" />
        <figcaption>Photo by: Lindsey Nicholson / UCG / Universal Images Group via Getty Images</figcaption>
    </figure>

  <p id="KjCukE">Lyft is partnering with Redwood Materials, a battery recycling company founded by a former Tesla executive, to ensure its fleet of shared e-bikes and scooters have a second life. </p>
<p id="1U7gEv">It’s a noteworthy deal considering Lyft’s status as the <a href="https://go.redirectingat.com/?id=66960X1514734&amp;xs=1&amp;url=https%3A%2F%2Fwww.lyft.com%2Fblog%2Fposts%2Fmeet-lyfts-new-ebike&amp;referrer=theverge.com&amp;xcust=___vg__p_22693596__t_w__r_https://www.google.com/__d_D" rel="sponsored nofollow noopener" target="_blank">largest electric bike-share operator in North America</a> thanks to its bike-share business, including the extremely popular Citi Bike in New York City. The company claims that Citi Bike was the “25th most-ridden transit network in the United States.”</p>
<p id="duzafy">Redwood Materials was founded in 2017 by Jeffrey “JB” Straubel, a co-founder and former chief technology officer of Tesla. In addition to breaking down scrap from Tesla’s battery-making process with Panasonic, Redwood also recycles EV batteries from <a href="https://www.theverge.com/2021/9/22/22687116/ford-redwood-materials-electric-vehicle-battery-recycling-jb-straubel">Ford</a>, <a href="https://www.theverge.com/2022/6/21/23177039/toyota-redwood-materials-ev-battery-recycling-partnership-prius">Toyota</a>,...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23471884/lyft-redwood-materials-battery-recycle-ebike-scooter">Continue reading&hellip;</a>
  </p>

## Tax filing websites have been sending users’ financial information to Facebook
 - [https://www.theverge.com/2022/11/22/23471842/facebook-hr-block-taxact-taxslayer-info-sharing](https://www.theverge.com/2022/11/22/23471842/facebook-hr-block-taxact-taxslayer-info-sharing)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 13:00:00+00:00

<figure>
      <img alt="An illustration of Facebook’s thumbs-up hand holding a magnifying glass to tax forms." src="https://cdn.vox-cdn.com/thumbor/4F-mHUak38I3rK2JvX-6CV_BLkE=/250x0:2950x1800/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71661088/pixel_tax_site_final__1_.0.jpg" />
        <figcaption>Image: Gabriel Hongsdusit</figcaption>
    </figure>

  <p id="aDGzTG">Major tax filing services such as H&amp;R Block, TaxAct, and TaxSlayer have been quietly transmitting sensitive financial information to Facebook when Americans file their taxes online, <em>The Markup</em> has learned.</p>
<p id="wYT0hZ">The <a href="https://github.com/the-markup/meta-pixel-taxes">data</a>, sent through widely used code called the Meta Pixel, includes not only information like names and email addresses but often even more detailed information, including data on users’ income, filing status, refund amounts, and dependents’ college scholarship amounts. </p>
<div class="c-float-left c-float-hang"><div id="ysFNpz"><div></div></div></div>
<p id="lE7wJc">The information sent to Facebook can be used by the company to power its advertising algorithms and is gathered regardless of whether the person using the tax filing service has an account on Facebook or other platforms operated by its owner Meta. </p>
<p id="cHnd71">Each year, the...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23471842/facebook-hr-block-taxact-taxslayer-info-sharing">Continue reading&hellip;</a>
  </p>

## Even PowerPoint succumbs to portrait mode
 - [https://www.theverge.com/2022/11/22/23472914/microsoft-powerpoint-portrait-mode-ios-app-tiktok](https://www.theverge.com/2022/11/22/23472914/microsoft-powerpoint-portrait-mode-ios-app-tiktok)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 11:19:14+00:00

<figure>
      <img alt="A screenshot demonstrating how to access portrait mode on Powerpoint for iPad" src="https://cdn.vox-cdn.com/thumbor/4XcwGZXCrdR1F-olRhaaHFRAILU=/100x0:3100x2000/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71660789/Microsoft_Powerpoint_iOS_app_portrait_mode.0.jpg" />
        <figcaption><em>Office Insiders can now create slides in portrait mode in PowerPoint for iOS on iPads and iPhones.</em> | Image: Microsoft</figcaption>
    </figure>

  <p id="yIHkTp">Microsoft is introducing the ability to <a href="https://insider.office.com/en-us/blog/create-slides-in-portrait-mode-on-powerpoint-for-ios">create slides in portrait mode</a> in its mobile PowerPoint app. The feature is available in public beta via the <a href="https://insider.office.com/en-us/">Microsoft Office Insider program</a> (running Version 2.68 or later) and is currently limited to iPhone and iPad devices.</p>
<p id="S8YWbx">The increased demand for portrait mode content has been driven by the popularity of TikTok, Instagram Reels, and YouTube Shorts. As people have adjusted to consuming content in their phone’s native vertical orientation, tools optimized for portrait content creation have to follow suit.</p>
  <figure class="e-image">
        
      <cite>Image: Microsoft</cite>
      <figcaption><em>The new Portrait Mode orientation can be accessed from the Design tab.</em></figcaption>
  </figure>
<p id="G5BUhg">Microsoft acknowledged this “shift towards mobile-first content creation”...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23472914/microsoft-powerpoint-portrait-mode-ios-app-tiktok">Continue reading&hellip;</a>
  </p>

## Tuesday’s top tech news: Twitter rebuilds
 - [https://www.theverge.com/2022/11/22/23472912/november-22-2022-tech-news-liveblog](https://www.theverge.com/2022/11/22/23472912/november-22-2022-tech-news-liveblog)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 11:09:38+00:00

<figure>
      <img alt="Elon Musk shown looking downward in front of upside-down Twitter logos." src="https://cdn.vox-cdn.com/thumbor/Kv6cyVRB6CJFck8PFxXgHg8CQjk=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71660781/STK171_VRG_Illo_1_Normand_ElonMusk_001.0.jpg" />
        <figcaption>Illustration by Laura Normand / The Verge</figcaption>
    </figure>

  <p>After cutting two-thirds of its workforce, Elon Musk’s Twitter is ready to hire.</p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23472912/november-22-2022-tech-news-liveblog">Continue reading&hellip;</a>
  </p>

## Musk antagonist George Hotz hired to fix Twitter search — he’s got 12 weeks
 - [https://www.theverge.com/2022/11/22/23472869/george-hotz-twitter-internship-search-elon-musk-self-driving-cars](https://www.theverge.com/2022/11/22/23472869/george-hotz-twitter-internship-search-elon-musk-self-driving-cars)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 10:13:04+00:00

<figure>
      <img alt="Comm.ai team" src="https://cdn.vox-cdn.com/thumbor/p2FqrAtM6kU44Jvgrby5DY9-vCQ=/0x0:1500x1000/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71660693/mzelenko_230516_1078_0037.0.0.jpg" />
        <figcaption><em>Hotz demonstrating his former company’s advanced driver assistance technology.</em> | Photo by Michael Zelenko / The Verge</figcaption>
    </figure>

  <p id="qMqiz5">George Hotz, the <a href="https://www.engadget.com/2008-02-08-out-of-the-box-1-1-3-iphones-now-software-unlockable.html">noted iPhone hacker</a> who was reported to have once turned down a job at Tesla working on its driver-assistance technology, has <a href="https://twitter.com/realGeorgeHotz/status/1594906882027552773">embarked upon a 12-week “internship” at Twitter</a> under Elon Musk’s leadership. Hotz said <a href="https://twitter.com/realGeorgeHotz/status/1594906882027552773">his priority at the social media company</a> is to fix its search feature, as well as to remove the prompt that prevents you from browsing the service on the web without logging in.</p>
<p id="F4llIh">The internship came about after Hotz expressed support for Musk’s “extremely hardcore” ultimatum to Twitter’s employees, which demanded that they work “long hours at high intensity” or else depart the company. Hotz said that “<a href="https://twitter.com/realGeorgeHotz/status/1592945472519680001">this is the attitude that builds incredible things</a>” and that he’d be willing to do an internship at the company....</p>
  <p>
    <a href="https://www.theverge.com/2022/11/22/23472869/george-hotz-twitter-internship-search-elon-musk-self-driving-cars">Continue reading&hellip;</a>
  </p>

## Twitter is making DMs encrypted and adding video, voice chat, per Elon Musk
 - [https://www.theverge.com/2022/11/21/23472174/twitter-dms-encrypted-elon-musk-voice-video-calling](https://www.theverge.com/2022/11/21/23472174/twitter-dms-encrypted-elon-musk-voice-video-calling)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 02:30:42+00:00

<figure>
      <img alt="An illustration of the Twitter logo" src="https://cdn.vox-cdn.com/thumbor/6kBqimyOvt-iCvNDVhv2okF4ey4=/0x0:3000x2000/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71659917/acastro_STK050_04.0.jpg" />
        <figcaption>Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="TvAhZo">Twitter’s new owner, Elon Musk, has been public about his desire to improve how the social network’s direct messages work. In a meeting with employees today, he spelled out exactly what that looks like.</p>
<p id="6MmlUD">Framed by presentation slides titled “Twitter 2.0” at Twitter’s San Fransisco headquarters on Monday, Musk told employees that the company would encrypt DMs and work to add encrypted video and voice calling between accounts, according to a recording of the meeting obtained by <em>The Verge</em>. </p>
<p id="Z8NlgY">“We want to enable users to be able to communicate without being concerned about their privacy, [or] without being concerned about a data breach at Twitter causing all of their DMs to hit the web, or think that maybe someone at Twitter could be spying on...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/21/23472174/twitter-dms-encrypted-elon-musk-voice-video-calling">Continue reading&hellip;</a>
  </p>

## Domino’s is building an all-electric pizza delivery fleet with Chevy Bolts
 - [https://www.theverge.com/2022/11/21/23472002/dominos-chevy-bolt-ev-pizza-delivery-fleet-rollout](https://www.theverge.com/2022/11/21/23472002/dominos-chevy-bolt-ev-pizza-delivery-fleet-rollout)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 01:24:25+00:00

<figure>
      <img alt="Two chevy bolt ev cars, wrapped in domino’s artwork are parked in front of a domino’s pizza store with one of the cars hooked up to a charger." src="https://cdn.vox-cdn.com/thumbor/uraUyO3VeLJ8RJ6ethB54sPF1bs=/0x1:2048x1366/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71659802/Dominos_Chevy_Bolt_EVs_08.0.jpg" />
        <figcaption><em>Domino’s outfitted Chevy Bolts.</em> | Image: Domino’s</figcaption>
    </figure>

  <p id="1PMpbG">Domino’s is gearing up to put <a href="https://ir.dominos.com/news-releases/news-release-details/dominosr-roll-out-nationwide-fleet-800-chevy-boltr-electric">more than 800 all-electric pizza delivery vehicles into service</a> in the coming months, starting with over 100 of them rolling out in November. The company went with the compact Chevy Bolt EV and is wrapping the vehicles with custom branding but no other bells and whistles — just combustion-free deliveries (via <a href="https://electrek.co/2022/11/21/dominos-acquires-800-chevy-bolts-evs-for-delivery-fleet/"><em>electrek</em></a>).</p>
<p id="Lo1Jmp">Domino will have a fleet of 855 new electric vehicles, to be exact, and while that’s not quite enough to reach <a href="https://ir.dominos.com/static-files/4daec873-268e-4456-b541-3871f28288e2">all 6,135 of the pizza shops in the US</a>, it's more than the Chevy Spark-based (gas version) ones it built with <a href="https://www.theverge.com/2015/10/21/9587270/dominos-dxp-delivery-car-chevy-spark-pizza">custom pizza warming oven doors</a> in 2015. Those were called the Domino’s DXP, and only 155 of them were made. For the new Bolts, drivers will need to toss the HeatWave bags in...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/21/23472002/dominos-chevy-bolt-ev-pizza-delivery-fleet-rollout">Continue reading&hellip;</a>
  </p>

## Twitter won’t restart paid verification until ‘significant impersonations’ stop, Elon Musk tells employees
 - [https://www.theverge.com/2022/11/21/23472184/elon-musk-twitter-paid-verification-relaunch-delay-impersonations](https://www.theverge.com/2022/11/21/23472184/elon-musk-twitter-paid-verification-relaunch-delay-impersonations)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 00:31:11+00:00

<figure>
      <img alt="An illustration of the Twitter logo." src="https://cdn.vox-cdn.com/thumbor/zQLVeU7EwVTBQLHivgfUFyqWqvM=/0x0:3000x2000/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71659669/acastro_STK050_06.5.jpg" />
        <figcaption>Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="InvXEX">Elon Musk told Twitter employees on Monday that the company won’t relaunch its paid verification subscription, Twitter Blue, until “we’re confident about significant impersonations not happening,” according to a recording of his remarks obtained by <em>The Verge</em>.</p>
<p id="iN7NAx">Musk said last week that his $8 per month Blue subscription <a href="https://www.theverge.com/2022/11/15/23461244/twitter-blue-relaunch-verification-elon-musk">would be made available again on November 29th</a>. But in the meeting with employees, he said the timing of the launch was unclear: “We might launch it next week. We might not. But we’re not going to launch until there’s high confidence in protecting against those significant impersonations.”</p>
<p id="Le0vLW">After taking over Twitter, Musk’s first big change was to quickly introduce the ability for users to buy a blue checkmark through...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/21/23472184/elon-musk-twitter-paid-verification-relaunch-delay-impersonations">Continue reading&hellip;</a>
  </p>

## Apple changed how reading books works in iOS 16, and I may never be happy again
 - [https://www.theverge.com/2022/11/21/23471306/apple-books-ios-16-page-flip-animation-sucks](https://www.theverge.com/2022/11/21/23471306/apple-books-ios-16-page-flip-animation-sucks)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-11-22 00:00:00+00:00

<figure>
      <img alt="Nilay Patel holds an iPhone 14 Pro in his hands." src="https://cdn.vox-cdn.com/thumbor/fy-1OSl08rP0neOAsPVBx3gB7kM=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71659548/226270_iPHONE_14_PHO_akrales_0030.0.jpg" />
        <figcaption><em>Am I being dramatic? Yes. Has this change made me read on my phone less? Also yes.</em> | Photo by Amelia Holowaty Krales / The Verge</figcaption>
    </figure>

  <p id="NwS67V">Apple Books has been my main reading app for years for one very specific reason: its page-turning animation is far and away the best in the business. Unfortunately, that went away with iOS 16 and has been replaced by a new animation that makes it feel like you’re moving cards through a deck instead of leafing through a digitized version of paper. And despite the fact that I’ve been trying to get used to the change since I got onto the beta in July, I still feel like Apple’s destroyed one of the last ways that my phone brought joy into my life.</p>
<p id="ed6BLz">For those unfamiliar with Apple’s Books app (formerly known as iBooks), I’ll try to explain the hole that’s suddenly been punched into my reading life. Before iOS 16, the app would play a...</p>
  <p>
    <a href="https://www.theverge.com/2022/11/21/23471306/apple-books-ios-16-page-flip-animation-sucks">Continue reading&hellip;</a>
  </p>


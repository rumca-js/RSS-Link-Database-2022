# Source:Ryan Reynolds, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg, language:en-US

## Will & Ryan Dance Rehearsal
 - [https://www.youtube.com/watch?v=XHfpqbKzfxY](https://www.youtube.com/watch?v=XHfpqbKzfxY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2022-11-23 00:00:00+00:00

You’ve got to be willing to be bad at something if you want to be… slightly less bad at it? Here’s Will Ferrell and I proving that point! We’re so humbled by all the love for #Spirited on Apple TV Plus. 

https://apple.co/spirited


# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## CNN analysts break down what could be revealed in Trump's tax returns
 - [https://www.cnn.com/videos/politics/2022/11/22/scotus-trump-tax-returns-ruling-eisen-mccabe-sot-sr-vpx.cnn](https://www.cnn.com/videos/politics/2022/11/22/scotus-trump-tax-returns-ruling-eisen-mccabe-sot-sr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 23:59:52+00:00

CNN legal analyst Norm Eisen and CNN senior law enforcement analyst and former FBI Deputy Director Andrew McCabe break down the implications of the Supreme Court ruling that cleared the way for Congress to obtain former President Donald Trump's tax returns.

## Boris Johnson: Blaming Brexit for the weak economy is 'nonsense'
 - [https://www.cnn.com/videos/business/2022/11/22/boris-johnson-richard-quest-brexit-uk-economy-interview-sot-qmb-intl-vpx.cnn](https://www.cnn.com/videos/business/2022/11/22/boris-johnson-richard-quest-brexit-uk-economy-interview-sot-qmb-intl-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 23:40:12+00:00

Former British Prime Minister Boris Johnson talked to CNN's Richard Quest about Brexit and the current state of the UK economy.

## Analysis: A worrisome poll number for Donald Trump
 - [https://www.cnn.com/2022/11/22/politics/trump-poll-president-republican-desantis/index.html](https://www.cnn.com/2022/11/22/politics/trump-poll-president-republican-desantis/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 23:31:43+00:00

Donald Trump is running for president. But according to a new Quinnipiac University national poll, a whole lot of people wish he wasn't.

## After a slow start, France dominates Australia
 - [https://www.cnn.com/sport/live-news/world-cup-11-22-22/h_ebd6a745767074785bffab4bd2f85a6a](https://www.cnn.com/sport/live-news/world-cup-11-22-22/h_ebd6a745767074785bffab4bd2f85a6a)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 23:03:21.432278+00:00



## Manchester United owners exploring potential sale of famed club
 - [https://www.cnn.com/2022/11/22/football/manchester-united-glazers-sale-explored-spt-intl/index.html](https://www.cnn.com/2022/11/22/football/manchester-united-glazers-sale-explored-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 22:45:11+00:00

Manchester United's owners announced their intention on Tuesday to explore the sale of the iconic club, saying a "process to explore strategic alternatives" had begun.

## 'Love Actually' cast to reunite for 20th anniversary TV special
 - [https://www.cnn.com/2022/11/22/entertainment/love-actually-20th-anniversary-abc-special/index.html](https://www.cnn.com/2022/11/22/entertainment/love-actually-20th-anniversary-abc-special/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 22:33:54+00:00

One of the most beloved modern Christmas classics is turning 20 next year, and to mark the occasion, cast members from the landmark 2003 romantic comedy "Love Actually" are reuniting for a TV special to air on ABC next week, the network announced Tuesday.

## World Cup 2022: France vs. Australia
 - [https://edition.cnn.com/webview/sport/live-news/world-cup-11-22-22/index.html](https://edition.cnn.com/webview/sport/live-news/world-cup-11-22-22/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 21:03:18.356164+00:00



## America's Black soldiers had to fight racism too
 - [https://www.cnn.com/2022/11/22/opinions/devotion-half-american-black-soldiers-patriotism-tisby/index.html](https://www.cnn.com/2022/11/22/opinions/devotion-half-american-black-soldiers-patriotism-tisby/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 20:46:16+00:00

As a young man in the 1960s, my uncle joined the Air Force. Like so many before and since, flying enraptured him. The ability to transcend our natural ground-bound state and soar among the clouds in a machine slicing the air at hundreds of miles an hour thrilled his imagination.

## 'FIFA have made me feel excluded:' Sole gay top flight player hits out on Qatar armband ban
 - [https://www.cnn.com/videos/tv/2022/11/22/amanpour-cavallo.cnn](https://www.cnn.com/videos/tv/2022/11/22/amanpour-cavallo.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 20:36:00+00:00

Christiane Amanpour speaks with Australian Josh Cavallo, one of the few professional footballers to come out as homosexual, on FIFA's decision to ban players from wearing OneLove rainbow armbands at the World Cup in Qatar.

## Saudi Arabia's victory over Argentina greatest upset in World Cup history
 - [https://www.cnn.com/2022/11/22/football/saudi-arabia-argentina-world-cup-upsets-spt-intl/index.html](https://www.cnn.com/2022/11/22/football/saudi-arabia-argentina-world-cup-upsets-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 20:18:23+00:00

• LIVE: France defeats Australia 4-1
• What fans can't do in Qatar

## Supreme Court clears way for House to get Trump's taxes
 - [https://www.cnn.com/2022/11/22/politics/supreme-court-clears-way-for-house-to-get-trumps-taxes/index.html](https://www.cnn.com/2022/11/22/politics/supreme-court-clears-way-for-house-to-get-trumps-taxes/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 20:12:00+00:00

The Supreme Court on Tuesday cleared the way for the release of former President Donald Trump's tax returns to a Democratic-led House committee.

## Nuclear watchdog says Iran enriching up to 60% at underground Fordow nuclear facility
 - [https://www.cnn.com/2022/11/22/middleeast/iaea-iran-enrichment-fordow-intl/index.html](https://www.cnn.com/2022/11/22/middleeast/iaea-iran-enrichment-fordow-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 19:35:32+00:00

Iran has begun producing uranium enriched up to 60% in its underground Fordow nuclear facility, the International Atomic Energy Agency's (IAEA) Director General Rafael Grossi said on Tuesday, bringing the country closer to weapons grade material.

## 'A reverse exorcism:' Late night hosts joke about Elon Musk reinstating Trump's Twitter
 - [https://www.cnn.com/videos/media/2022/11/22/elon-musk-trump-twitter-late-night-reaction-cprog-orig-ht.cnn-business](https://www.cnn.com/videos/media/2022/11/22/elon-musk-trump-twitter-late-night-reaction-cprog-orig-ht.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 19:33:19+00:00

Late night hosts cracked jokes about Twitter CEO Elon Musk's decision to restore Donald Trump's Twitter account.

## Jeff Bezos announces 40 grants totaling $123 million to combat homelessness
 - [https://www.cnn.com/2022/11/22/business/jeff-bezos-day-1-fund-grants/index.html](https://www.cnn.com/2022/11/22/business/jeff-bezos-day-1-fund-grants/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 19:30:37+00:00

Jeff Bezos is continuing to make good on his pledge to give away the majority his wealth, to the tune of $123 million today.

## Elon Musk has upended Twitter's business. Here's how he could fix it
 - [https://www.cnn.com/2022/11/22/tech/elon-musk-twitter-subscription-business/index.html](https://www.cnn.com/2022/11/22/tech/elon-musk-twitter-subscription-business/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 19:23:32+00:00

Much of Twitter's ad sales team has been fired or pushed out. Large companies from General Mills to Macy's have paused advertising on the platform, with more potentially following suit after new owner Elon Musk's decision to restore the account of former President Donald Trump and other controversial figures. And any cursory scroll of the platform will likely show you fewer big brand ads.

## Donors love hobnobbing with politicians. Ron DeSantis isn't playing ball
 - [https://www.cnn.com/2022/11/22/politics/ron-desantis-gop-donors-2024/index.html](https://www.cnn.com/2022/11/22/politics/ron-desantis-gop-donors-2024/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 19:21:57+00:00

Gov. Ron DeSantis has gotten a rock star's reception at Republican Party functions since winning reelection this month, solidifying himself as a top-tier possible presidential contender. But the Florida Republican has left some influential members of the party wanting more.

## In final White House briefing, Fauci says he hopes he is remembered for giving it 'everything that I have'
 - [https://www.cnn.com/2022/11/22/politics/anthony-fauci-final-white-house-briefing/index.html](https://www.cnn.com/2022/11/22/politics/anthony-fauci-final-white-house-briefing/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 18:25:14+00:00

Dr. Anthony Fauci, in his final White House briefing before departing his official positions, said he hopes that he is remembered for giving his job "everything I have" and for never leaving "anything on the field."

## Boris Johnson claims France was 'in denial' before Russia's invasion of Ukraine
 - [https://www.cnn.com/2022/11/22/europe/boris-johnson-ukraine-invasion-europe-comments-intl/index.html](https://www.cnn.com/2022/11/22/europe/boris-johnson-ukraine-invasion-europe-comments-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 17:55:30+00:00

Former British Prime Minister Boris Johnson has claimed France was "in denial" about the prospect of a Russian invasion of Ukraine, and accused the German government of initially favoring a quick Ukrainian military defeat over a long conflict.

## Cristiano Ronaldo to leave Manchester United with immediate effect
 - [https://www.cnn.com/2022/11/22/football/cristiano-ronaldo-manchester-united-departure-spt-intl/index.html](https://www.cnn.com/2022/11/22/football/cristiano-ronaldo-manchester-united-departure-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 17:54:50+00:00

Cristiano Ronaldo is leaving Manchester United with immediate effect, the English Premier League club announced on Tuesday.

## Qatar is a minefield for World Cup advertisers
 - [https://www.cnn.com/2022/11/22/business/world-cup-advertising/index.html](https://www.cnn.com/2022/11/22/business/world-cup-advertising/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 17:44:05+00:00

Billions of people watch FIFA's World Cup every four years, a tantalizing opportunity for advertisers who want to capitalize on the feel-good fervor of the world's biggest sporting event. But this year, it's a reputational minefield for some of the world's biggest brands.

## After returning from war, Ukrainian MMA fighter Yaroslav Amosov looks to defend his world title
 - [https://www.cnn.com/2022/11/22/sport/yaroslav-amosov-return-bellator-spt-intl/index.html](https://www.cnn.com/2022/11/22/sport/yaroslav-amosov-return-bellator-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 17:29:49+00:00

Six months ago, world champion MMA fighter Yaroslav Amosov should have been defending his welterweight title at Bellator 281 in London. Instead, the Ukrainian had returned to his homeland to help in the war effort following Russia's invasion on February 24.

## Hear from US journalist who was detained for wearing a rainbow shirt in Qatar
 - [https://www.cnn.com/videos/sports/2022/11/22/journalist-detained-qatar-world-cup-lgbtq-cnntm-contd-ldn-vpx.cnn](https://www.cnn.com/videos/sports/2022/11/22/journalist-detained-qatar-world-cup-lgbtq-cnntm-contd-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 17:26:27+00:00

CNN's Poppy Harlow, Don Lemon, and Kaitlan Collins speak to journalist Grant Wahl who was temporarily detained by security for wearing a rainbow shirt while covering the World Cup in Qatar.

## Lindsey Graham testifies before Georgia grand jury investigating 2020 election aftermath
 - [https://www.cnn.com/2022/11/22/politics/lindsey-graham-fulton-county-grand-jury-2020-election/index.html](https://www.cnn.com/2022/11/22/politics/lindsey-graham-fulton-county-grand-jury-2020-election/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 17:12:43+00:00

South Carolina Sen. Lindsey Graham is appearing Tuesday before a Georgia grand jury investigating efforts to overturn the 2020 election.

## See dramatic rescue attempt as boat is swamped with raging water
 - [https://www.cnn.com/videos/us/2022/11/22/coast-guard-boat-rescue-north-carolina-orig-mg.cnn](https://www.cnn.com/videos/us/2022/11/22/coast-guard-boat-rescue-north-carolina-orig-mg.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 17:12:10+00:00

A fishing boat off the coast of North Carolina was beginning to sink just as the U.S. Coast Guard arrived to attempt a rescue.

## More than 6,500 civilians have died since the war started: OHCHR
 - [https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-11-22-22/h_7bc4eb42d09cd1568db2a2d5cca4051d](https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-11-22-22/h_7bc4eb42d09cd1568db2a2d5cca4051d)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 17:03:11.622822+00:00



## How sneakers came to be cultural currency
 - [https://www.cnn.com/style/article/sneakers-cultural-currency-downside-up-podcast/index.html](https://www.cnn.com/style/article/sneakers-cultural-currency-downside-up-podcast/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 17:00:16+00:00

When my two boys have free time, they want to go to the mall. No, they aren't shop-a-holics. They want to go gaze at sneakers.

## Judge sets October 2023 trial for New York attorney general's $250 million lawsuit against Trump
 - [https://www.cnn.com/2022/11/22/politics/new-york-lawsuit-trump-october-2023-trial/index.html](https://www.cnn.com/2022/11/22/politics/new-york-lawsuit-trump-october-2023-trial/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 16:57:29+00:00

A New York state judge set an October 2023 trial date for the New York attorney general's $250 million lawsuit against former President Donald Trump, his eldest children and the Trump Organization, just as the presidential election gets underway.

## Saudi Arabia stuns Lionel Messi's Argentina in one of the biggest upsets in World Cup history
 - [https://www.cnn.com/collections/intl-world-cup-221122/](https://www.cnn.com/collections/intl-world-cup-221122/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 16:33:37+00:00



## FTX's financial mismanagement comes under the microscope
 - [https://www.cnn.com/2022/11/22/business/ftx-bankruptcy-cash/index.html](https://www.cnn.com/2022/11/22/business/ftx-bankruptcy-cash/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 16:22:29+00:00

The full extent of FTX's financial disarray is becoming clearer as the failed crypto exchange's new management combs for cash as part of the bankruptcy process.

## US journalist says he was initially denied entry to a stadium because of rainbow t-shirt
 - [https://www.cnn.com/2022/11/22/football/rainbow-clothing-mcallister-wahl-qatar-world-cup-spt-intl/index.html](https://www.cnn.com/2022/11/22/football/rainbow-clothing-mcallister-wahl-qatar-world-cup-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 15:39:23+00:00

Some people attending 2022 World Cup matches have said they have experienced difficulties in Qatar when trying to enter stadiums wearing clothing in support of LGBTQ rights.

## He provokes Republican voters during wrestling matches. Why he no longer feels safe
 - [https://www.cnn.com/videos/politics/2022/11/22/wrestling-political-tensions-appalachia-reeve-contd-cnntm-vpx.cnn](https://www.cnn.com/videos/politics/2022/11/22/wrestling-political-tensions-appalachia-reeve-contd-cnntm-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 15:35:33+00:00

Daniel Harnsberger, aka "The Progressive Liberal," often the bad guy at wrestling matches in the Republican-voting mining towns of Appalachia and some southern states, speaks to CNN's Elle Reeve about the moment he realized things had changed.

## Six minutes of terror
 - [https://www.cnn.com/2022/11/22/us/colorado-springs-nightclub-shooting-narrative-cec/index.html](https://www.cnn.com/2022/11/22/us/colorado-springs-nightclub-shooting-narrative-cec/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 15:03:01+00:00

Michael Anderson was mixing drinks at Club Q Saturday night when he heard popping sounds amid the loud, thumping music.

## With a strike looming, railroad unions and management head back to negotiating table
 - [https://www.cnn.com/2022/11/22/business/railroad-union-negotiations/index.html](https://www.cnn.com/2022/11/22/business/railroad-union-negotiations/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 14:48:18+00:00

With a crippling freight rail strike looming in two weeks, leaders of four railroad unions and management of the major US freight railroads are due back at the negotiating table Tuesday afternoon.

## Hulu's 'Welcome to Chippendales' looks a little under-dressed for success
 - [https://www.cnn.com/2022/11/22/entertainment/welcome-to-chippendales-review/index.html](https://www.cnn.com/2022/11/22/entertainment/welcome-to-chippendales-review/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 14:47:55+00:00

Hulu has carved out an impressive niche of salacious fact-based limited series, including several with a true-crime hook. "Welcome to Chippendales" checks off those boxes, but in a less-appealing package that's surprisingly lifeless, and even with its trashy selling points looks under-dressed for success.

## In 'Wednesday,' Jenna Ortega makes Netflix's Addams Family series look like a snap
 - [https://www.cnn.com/2022/11/22/entertainment/wednesday-review/index.html](https://www.cnn.com/2022/11/22/entertainment/wednesday-review/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 14:45:05+00:00

Although the main character's name was inspired by the poetic line "Wednesday's child is full of woe," "Wednesday" is generally a delight, thanks almost entirely to Jenna Ortega. Having outgrown her Disney Channel days, Ortega makes the Addams Family's now-high-school-age daughter the coolest humorless goth sociopath you'll ever meet, in a Netflix series that's more kooky than spooky or ooky.

## King Charles welcomes South Africa's Ramaphosa for first state visit
 - [https://www.cnn.com/2022/11/22/africa/king-charles-hosts-ramaphosa-intl/index.html](https://www.cnn.com/2022/11/22/africa/king-charles-hosts-ramaphosa-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 14:25:32+00:00

King Charles hosted his first state visit since becoming British monarch on Tuesday, welcoming South African President Cyril Ramaphosa to Buckingham Palace.

## Bob Iger: Here's how much the CEO will make in his return to Disney
 - [https://www.cnn.com/2022/11/22/media/disney-bob-iger-pay/index.html](https://www.cnn.com/2022/11/22/media/disney-bob-iger-pay/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 14:09:07+00:00

Bob Iger, who shocked the media world when he returned as CEO of Disney on Sunday, will once again be among the highest-paid executives in Hollywood.

## We now know what Budweiser will do with the beer it can't sell at the World Cup
 - [https://www.cnn.com/2022/11/22/business/budweiser-unsold-beer-world-cup/index.html](https://www.cnn.com/2022/11/22/business/budweiser-unsold-beer-world-cup/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 13:30:30+00:00

Qatar's last-minute decision to ban alcohol at World Cup stadiums has left Budweiser with loads of beer left on its hands. The company has an innovative solution to offload it.

## Is the dollar's relentless rise coming to an end?
 - [https://www.cnn.com/2022/11/22/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2022/11/22/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 13:21:55+00:00

The story of financial markets and the global economy this year has been written in part by the dramatic rise of the US dollar, whose inexorable ascent has sent shockwaves around the world. At last, however, its breakneck rally could be coming to an end.

## If the world avoids a recession, it'll have India and China to thank
 - [https://www.cnn.com/2022/11/22/economy/oecd-economic-outlook-november/index.html](https://www.cnn.com/2022/11/22/economy/oecd-economic-outlook-november/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 12:57:54+00:00

Global growth will slow further in the coming year but the world will likely avoid a recession thanks to Asia's biggest economies.

## Pro wrestlers used to love to be hated. But today's political tensions make that dangerous
 - [https://www.cnn.com/2022/11/22/politics/political-tensions-wrestling/index.html](https://www.cnn.com/2022/11/22/politics/political-tensions-wrestling/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 12:45:21+00:00

Back in the late 1980s, when Beau James started pro wrestling, the crowds came for a show between good and evil, to see a story about heroes and villains, to enjoy the bouts and then go home.

## Christie's withdraws T. rex skeleton from auction days before sale
 - [https://www.cnn.com/style/article/christies-shen-tyrannosaurus-rex-auction-cancel-intl-scn-hnk/index.html](https://www.cnn.com/style/article/christies-shen-tyrannosaurus-rex-auction-cancel-intl-scn-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 12:16:00+00:00

Christie's has withdrawn a Tyrannosaurus rex skeleton from sale, with just days to go until the historic auction, after a paleontologist said the fossil largely comprises copyrighted replica bones from another specimen.

## Argentina stunned by shocking loss in its first game of the Qatar World Cup
 - [https://www.cnn.com/2022/11/22/football/lionel-messi-argentina-saudi-arabia-2022-world-cup-spt-intl/index.html](https://www.cnn.com/2022/11/22/football/lionel-messi-argentina-saudi-arabia-2022-world-cup-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 12:07:30+00:00

Saudi Arabia produced one of the biggest upsets in World Cup history Tuesday, beating Lionel Messi's Argentina 2-1 in an astonishing Group C match.

## Saudi Arabia beat Argentina in huge World Cup upset
 - [https://www.cnn.com/sport/live-news/world-cup-11-22-22/index.html](https://www.cnn.com/sport/live-news/world-cup-11-22-22/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 11:29:36+00:00

• Their countries' teams aren't even in the World Cup. So why are these fans traveling to Qatar?
• Captains told not to wear 'OneLove' armband

## Dwarf tomato seeds will launch to space station aboard SpaceX's next resupply flight
 - [https://www.cnn.com/2022/11/22/world/spacex-dwarf-tomatoes-iss-scn/index.html](https://www.cnn.com/2022/11/22/world/spacex-dwarf-tomatoes-iss-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 11:07:14+00:00

When SpaceX's 26th commercial resupply mission launches Tuesday, it will carry a bounty of supplies, a pair of new solar arrays, dwarf tomato seeds and a range of science experiments to the International Space Station.

## Shortages of antivirals, antibiotics compound stress of a rough season for viral illnesses in kids
 - [https://www.cnn.com/2022/11/22/health/drug-shortages-tamiflu-amoxicillin-albuterol/index.html](https://www.cnn.com/2022/11/22/health/drug-shortages-tamiflu-amoxicillin-albuterol/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 11:04:54+00:00

Shortages of key medications used to treat common childhood illnesses like flu, ear infections and sore throats are adding to the misery of this year's early and severe respiratory virus season.

## Jury deliberations begin in Oath Keepers seditious conspiracy trial
 - [https://www.cnn.com/2022/11/22/politics/oath-keepers-seditious-conspiracy-trial/index.html](https://www.cnn.com/2022/11/22/politics/oath-keepers-seditious-conspiracy-trial/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 11:03:47+00:00

A Washington, DC, jury will begin deliberating Tuesday in the criminal trial of five alleged leaders of the right-wing Oath Keepers militia group charged with seditious conspiracy.

## Club Q was more than a night out. It was a safe space for the LGBTQ community of Colorado Springs
 - [https://www.cnn.com/2022/11/22/us/club-q-colorado-springs-lgbtq-community/index.html](https://www.cnn.com/2022/11/22/us/club-q-colorado-springs-lgbtq-community/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 10:50:55+00:00

Days after the mass shooting at Club Q, the LGBTQ community in Colorado Springs, Colorado, is not only grieving the loss of friends' lives. They are also mourning the violent assault on what many call their home, their safe space.

## Her house collapsed underneath her feet as earthquake hit
 - [https://www.cnn.com/videos/world/2022/11/22/indonesia-earthquake-cianjur-coren-ovn-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2022/11/22/indonesia-earthquake-cianjur-coren-ovn-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 10:49:49+00:00

Rescuers are digging through debris to find survivors of a powerful earthquake that toppled homes and buildings in a highly populated area of Indonesia's West Java province, killing more than 100 people. CNN's Anna Coren reports.

## Hear what weapons Boris Johnson thinks Ukraine needs the most
 - [https://www.cnn.com/videos/world/2022/11/22/boris-johnson-exclusive-interview-sot-ukraine-quest-ovn-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2022/11/22/boris-johnson-exclusive-interview-sot-ukraine-quest-ovn-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 10:41:22+00:00

Speaking with CNN's Richard Quest at an event for CNN's partner network CNN Portugal, former British Prime Minister Johnson offers his views on the ongoing Russia-Ukraine war.

## You can thank The Sims for the rise of luxury fashion in gaming
 - [https://www.cnn.com/style/article/digital-fashion-video-games-the-sims/index.html](https://www.cnn.com/style/article/digital-fashion-video-games-the-sims/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 10:17:57+00:00

Gaming and fashion may appear to be unlikely bedfellows, but what our avatars wear — whether skydiving into a battle in Fortnite or having a dinner date in The Sims — has been of interest since video game characters could first change their clothes.

## Officials describe chaotic scene after SUV drove through Massachusetts Apple store, leaving 1 dead and at least 19 injured
 - [https://www.cnn.com/2022/11/22/us/massachusetts-apple-store-crash-tuesday/index.html](https://www.cnn.com/2022/11/22/us/massachusetts-apple-store-crash-tuesday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 10:09:04+00:00

First responders described a chaotic scene Monday after an SUV crashed through the window of a busy Apple store in Hingham, Massachusetts, leaving one man dead and at least 19 others injured, authorities say.

## Messi and Argentina prepare to face Saudi Arabia in Qatar World Cup
 - [https://edition.cnn.com/sport/live-news/world-cup-11-22-22/index.html](https://edition.cnn.com/sport/live-news/world-cup-11-22-22/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 10:03:00.460938+00:00



## More than 6,500 civilians have died since the war in Ukraine started
 - [https://www.cnn.com/europe/live-news/russia-ukraine-war-news-11-22-22/index.html](https://www.cnn.com/europe/live-news/russia-ukraine-war-news-11-22-22/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 10:00:41+00:00

• 'Incredibly dangerous, tiresome, soul-destroying': The battle for Kherson

## Jill Biden and Naomi Biden featured in Vogue magazine
 - [https://www.cnn.com/2022/11/22/politics/jill-biden-naomi-biden-vogue-magazine/index.html](https://www.cnn.com/2022/11/22/politics/jill-biden-naomi-biden-vogue-magazine/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 10:00:21+00:00

First lady Jill Biden and her granddaughter, Naomi Biden, are featured on the cover of the new digital version of Vogue magazine, which will be released Tuesday, a person familiar with the details told CNN.

## Appeals court hearing to determine future of special master for Trump's Mar-a-Lago documents
 - [https://www.cnn.com/2022/11/22/politics/appeals-court-trump-doj-mar-a-lago-docs/index.html](https://www.cnn.com/2022/11/22/politics/appeals-court-trump-doj-mar-a-lago-docs/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 10:00:12+00:00

As former President Donald Trump faces the new reality of a special counsel leading Justice Department investigations on his conduct, a federal appeals court on Tuesday will hear arguments about whether it should remove what has been a notable hurdle in one of the probes.

## Urban rewilding is bringing wildlife to the heart of cities
 - [https://www.cnn.com/2022/11/22/world/urban-rewilding-tiny-forest-cities-future-scn-spc-intl/index.html](https://www.cnn.com/2022/11/22/world/urban-rewilding-tiny-forest-cities-future-scn-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 09:30:26+00:00

Visions of the urban future tend to revolve around mile-high skyscrapers, flying cars and high-tech solutions to sustainability challenges.

## 'Everybody in that building experienced combat that night.' Army veteran Richard Fierro describes the moment he took down the Colorado nightclub gunman
 - [https://www.cnn.com/2022/11/22/us/richard-fierro-colorado-springs-club-q-shooting/index.html](https://www.cnn.com/2022/11/22/us/richard-fierro-colorado-springs-club-q-shooting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 09:06:33+00:00

Former Army Maj. Richard Fierro never thought he would need to use the combat skills he learned in the military while on a night out with his family.

## Ukrainian officials urge Kherson residents to evacuate for winter
 - [https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-11-22-22/index.html](https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-11-22-22/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 09:02:59.012005+00:00



## Jay Leno released from the hospital after burn injuries
 - [https://www.cnn.com/2022/11/21/entertainment/jay-leno-released/index.html](https://www.cnn.com/2022/11/21/entertainment/jay-leno-released/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 08:57:45+00:00

Jay Leno has been discharged from the hospital after sustaining burn injuries in a gasoline fire about nine days ago.

## Grand Canyon destination changes 'offensive' name
 - [https://www.cnn.com/travel/article/grand-canyon-havasupai-gardens/index.html](https://www.cnn.com/travel/article/grand-canyon-havasupai-gardens/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 07:39:14+00:00

A location in Arizona's Grand Canyon National Park is getting rid of its "offensive" name.

## Family holds memorial for slain Idaho student as police search for answers in quadruple killing
 - [https://www.cnn.com/2022/11/22/us/university-of-idaho-students-killed-tuesday/index.html](https://www.cnn.com/2022/11/22/us/university-of-idaho-students-killed-tuesday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 07:35:37+00:00

As police continue to comb through evidence in the killings of four University of Idaho students found dead nearly 10 days ago, the family of one of the victims came together to grieve their loss at a memorial Monday.

## Analysis: Paul Ryan invents a new category of anti-Trumpism
 - [https://www.cnn.com/2022/11/21/politics/paul-ryan-never-again-trump-2024/index.html](https://www.cnn.com/2022/11/21/politics/paul-ryan-never-again-trump-2024/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 06:25:57+00:00

You know all about the "Never Trumpers" -- that rump group of Republicans who have loudly spoken out against former President Donald Trump and what he has done to the GOP.

## Singapore defends its treatment of Binance after FTX 'debacle'
 - [https://www.cnn.com/2022/11/22/investing/singapore-mas-watch-list-binance-ftx-crypto-intl-hnk/index.html](https://www.cnn.com/2022/11/22/investing/singapore-mas-watch-list-binance-ftx-crypto-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 05:50:01+00:00

Singapore's central bank has responded to criticism of its treatment of two of the world's largest crypto exchanges, explaining why Binance was on an investor watch list while FTX, which has filed for bankruptcy, was not.

## A rural town's river vanished. Is Chile's constitution to blame?
 - [https://www.cnn.com/2022/11/22/americas/chile-petorca-drought-intl-latam/index.html](https://www.cnn.com/2022/11/22/americas/chile-petorca-drought-intl-latam/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 05:04:24+00:00

When she was a child, Marileu Avendaño used to go to the river with her friends to play. She was born and raised in Petorca, a rural town of more than 10,500 inhabitants in central Chile.

## Factory fire kills at least 38 people in central China, state media reports
 - [https://www.cnn.com/2022/11/21/asia/china-factory-fire-henan-intl-hnk/index.html](https://www.cnn.com/2022/11/21/asia/china-factory-fire-henan-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 04:47:02+00:00

A fire at a factory in central China killed 36 people on Monday, according to Chinese state-media, the latest in a string of fatal industrial accidents to hit the country in recent years.

## Elon Musk says Twitter is 'holding off' restarting paid verification over impersonation concerns
 - [https://www.cnn.com/2022/11/21/tech/elon-musk-twitter/index.html](https://www.cnn.com/2022/11/21/tech/elon-musk-twitter/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 02:45:58+00:00

Elon Musk said Monday evening that Twitter is "holding off" the restart of his paid account verification plan over continued concerns of impersonation on the social media platform.

## 'Aren't we humans too?': Hear intercepted phone call from Russian soldier
 - [https://www.cnn.com/videos/us/2022/11/22/intercepted-phone-call-russian-soldier-girlfriend-audio-russia-matthew-chance-dnt-ebof-vpx.cnn](https://www.cnn.com/videos/us/2022/11/22/intercepted-phone-call-russian-soldier-girlfriend-audio-russia-matthew-chance-dnt-ebof-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 02:16:29+00:00

CNN has obtained an intercepted phone conversation between a Russian soldier and his girlfriend where he describes what he sees on the ground in Ukraine as the "third world war." CNN's Matthew Chance reports.

## Video shows Ukrainian forces infiltrating Russian command center
 - [https://www.cnn.com/videos/world/2022/11/22/ukraine-video-recon-russia-kherson-retreat-kiley-dnt-tsr-vpx.cnn](https://www.cnn.com/videos/world/2022/11/22/ukraine-video-recon-russia-kherson-retreat-kiley-dnt-tsr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 02:11:24+00:00

CNN joins a Ukrainian reconnaissance unit as they review the weeks leading up to liberating Kherson from Russia. CNN's Sam Kiley reports.

## Army vet who helped stop shooter describes what happened
 - [https://www.cnn.com/videos/us/2022/11/22/fierro-man-who-helped-disarm-colorado-club-q-shooting-suspect-intv-ac360-vpx.cnn](https://www.cnn.com/videos/us/2022/11/22/fierro-man-who-helped-disarm-colorado-club-q-shooting-suspect-intv-ac360-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 02:11:17+00:00

Richard Fierro, the Army veteran who helped disarm the suspect in the Club Q shooting that killed 5 people and injured 25 others, speaks to CNN's John Berman about the experience that took the life of his daughter's boyfriend.

## Killers of US blogger escape from Bangladesh court on motorbikes
 - [https://www.cnn.com/2022/11/21/asia/us-blogger-avijit-roy-killers-escape-bangladesh-court-intl-hnk/index.html](https://www.cnn.com/2022/11/21/asia/us-blogger-avijit-roy-killers-escape-bangladesh-court-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 02:07:28+00:00

Two Islamist militants sentenced to death for killing a US blogger critical of religious extremism escaped from a crowded court in Bangladesh's Dhaka on Sunday.

## Bob Iger is back at Disney. These are the problems he has to fix
 - [https://www.cnn.com/videos/business/2022/11/21/bob-iger-problems-chapek-disney-ceo-mc-contd-orig.cnn-business](https://www.cnn.com/videos/business/2022/11/21/bob-iger-problems-chapek-disney-ceo-mc-contd-orig.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 01:27:59+00:00

Bob Chapek is out as Disney CEO, and Bob Iger is back in. CNN Business' Frank Pallotta explains the challenges Iger will have to address to make Disney fans and shareholders happy.

## 2021 video appears to show shooting suspect ranting about police
 - [https://www.cnn.com/videos/us/2022/11/21/colorado-club-q-shooting-suspect-2021-police-standoff-facebook-video-tsr-vpx.cnn](https://www.cnn.com/videos/us/2022/11/21/colorado-club-q-shooting-suspect-2021-police-standoff-facebook-video-tsr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 01:25:57+00:00

New video obtained by CNN appears to show the Colorado Springs shooting suspect ranting about police last year during a standoff. Anderson Lee Aldrich, who was arrested after allegedly making a bomb threat in June 2021, livestreamed the video from his mother's Facebook page, according to his mother's former landlord.

## Stunning video shows meteor light up Norway's skies
 - [https://www.cnn.com/videos/world/2022/11/21/norway-meteor-cprog-lon-orig-mrg.cnn](https://www.cnn.com/videos/world/2022/11/21/norway-meteor-cprog-lon-orig-mrg.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-22 00:12:47+00:00

Part of the Northern Taurids, the bolide burned up in the atmosphere 65 km (40 miles) above sea level, according to the Norwegian meteor network.


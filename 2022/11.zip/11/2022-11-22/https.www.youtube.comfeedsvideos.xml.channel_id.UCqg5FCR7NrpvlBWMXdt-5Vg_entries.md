# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Bayonetta 3 (Zero Punctuation)
 - [https://www.youtube.com/watch?v=Za6iAeO2omU](https://www.youtube.com/watch?v=Za6iAeO2omU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-11-23 00:00:00+00:00

Support us on Patreon to get Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.patreon.com/the_escapist

This week on Zero Punctuation, Yahtzee reviews Bayonetta 3.

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Evil West | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=nu2mWhcBRMQ](https://www.youtube.com/watch?v=nu2mWhcBRMQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-11-23 00:00:00+00:00

Support us on Patreon to get Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.patreon.com/the_escapist

Sebastian Ruiz reviews Evil West, developed by Flying Wild Hog.

Evil West on Steam: https://store.steampowered.com/app/1065310/Evil_West/

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Revisiting the Original God of War - Part 6 | Get Jesse to the Greek
 - [https://www.youtube.com/watch?v=Z-8wIRXwyLY](https://www.youtube.com/watch?v=Z-8wIRXwyLY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-11-23 00:00:00+00:00

Support us on Patreon to get Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.patreon.com/the_escapist

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## The Callisto Protocol's Paywalled Death Animations Are a New Low | Breakout
 - [https://www.youtube.com/watch?v=A2tgmWFkI-w](https://www.youtube.com/watch?v=A2tgmWFkI-w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-11-23 00:00:00+00:00

This week on Breakout we're taking about season passes and The Callisto Protocol specifically locking down content for a linear single player game...

Featuring Nick Calandra, Marty Sliva, and KC Nwosu, the freeform podcast dives into a bit of our daily lives, the latest games, movies, tv shows and books, the occasional craft beer review and random topics we find interesting.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Yahtzee and Marty Play Sonic Frontiers | Post-ZP Stream
 - [https://www.youtube.com/watch?v=ApjuI6xgXjA](https://www.youtube.com/watch?v=ApjuI6xgXjA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-11-23 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Yahtzee plays two hours of Sonic Frontiers for today's Post-ZP Stream.

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist​

Want to see the next episode a week early? Check out http://www.escapistmagazine.com​ for the latest episodes of your favorite shows.

---



---


The Escapist Merch Store ►►https://teespring.com/stores/the-esca...​
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag​
Follow us on Twitter ►► https://twitter.com/EscapistMag

#ZeroPunctuation

## Gungrave G.O.R.E | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=KcC4OQM9hH0](https://www.youtube.com/watch?v=KcC4OQM9hH0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-11-22 00:00:00+00:00

Support us on Patreon to get Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.patreon.com/the_escapist

Sebastian Ruiz reviews Gungrave G.O.R.E, developed by Iggymob.

Gungrave G.O.R.E on Steam: https://store.steampowered.com/app/1630110/Gungrave_GORE/

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Is Andor the Best Star Wars Has Been... Ever? | The Recap
 - [https://www.youtube.com/watch?v=CNY17uevKOo](https://www.youtube.com/watch?v=CNY17uevKOo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-11-22 00:00:00+00:00

This week on The Recap, we discuss Andor as the series is about to wrap up.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## King Arthur: Knight's Tale | The Editor's Hour
 - [https://www.youtube.com/watch?v=3Jf_XQVUM3k](https://www.youtube.com/watch?v=3Jf_XQVUM3k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-11-22 00:00:00+00:00

For The Editor's Hour today, Nick's going to be checking out a tactical RPG he's had his eye on for a while. 

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Ship of Fools | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=Guv9VRHPtwc](https://www.youtube.com/watch?v=Guv9VRHPtwc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-11-22 00:00:00+00:00

Support us on Patreon to get Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.patreon.com/the_escapist

KC Nwosu reviews Ship of Fools, developed by Fika Productions.

Ship of Fools on Steam: https://store.steampowered.com/app/1286580/Ship_of_Fools/

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Why Guild Wars 2 Has the Best Fishing Mini-Game of All Time
 - [https://www.youtube.com/watch?v=N6Z_JGlnEeY](https://www.youtube.com/watch?v=N6Z_JGlnEeY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-11-22 00:00:00+00:00

Support us on Patreon to get Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.patreon.com/the_escapist

In today's episode JM8 explains the designs behind Guild Wars 2's immaculate fishing mini game featuring the developers themselves!

If you want to see more game design content a new Anatomy episode will release every other week, or you can subscribe to JM8s personal channel for similar content: https://www.youtube.com/c/JM8GameDesign

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag


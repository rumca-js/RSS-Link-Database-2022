# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## World Cup 2022: Watch Kylian Mbappe's highlights for France against Australia
 - [https://www.bbc.co.uk/sport/av/football/63724904?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63724904?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 23:49:59+00:00

Watch the best of France's Kylian Mbappe's stunning performance during their 4-1 victory against Australia in at World Cup 2022.

## World Cup 2022: Olivier Giroud goes from understudy to leading light as he equals France scoring record
 - [https://www.bbc.co.uk/sport/football/63724940?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63724940?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 22:48:06+00:00

Olivier Giroud arrived in Qatar as an understudy among France's ensemble cast but took on a lead role in the 4-2 win over Australia.

## World Cup 2022: Gareth Southgate 'worried' England used as example in referee video
 - [https://www.bbc.co.uk/sport/football/63721852?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63721852?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 22:45:25+00:00

Gareth Southgate says he is "worried" that England were used as an example of a foul at a corner in Fifa's pre-tournament briefing for referees.

## Scottish independence: Supreme Court to rule on referendum case
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-63716412?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-63716412?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 22:32:42+00:00

The court was asked to clarify whether the Scottish government can hold indyref2 without Westminster consent.

## Baby given one day to live reaches first birthday
 - [https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-63705516?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-63705516?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 22:32:13+00:00

A mother says it is the greatest feeling in the world that her son has reached his first birthday.

## World Cup 2022: England captain Harry Kane set to have scan on right ankle on Wednesday
 - [https://www.bbc.co.uk/sport/football/63724625?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63724625?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 22:26:03+00:00

England skipper Harry Kane is set to have a scan on his right ankle before Friday's World Cup game with the United States.

## Cristiano Ronaldo leaves Manchester United: Situation 'like ticking timebomb' - Rio Ferdinand
 - [https://www.bbc.co.uk/sport/football/63723639?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63723639?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 22:14:42+00:00

Cristiano Ronaldo's situation at Manchester United was "like a ticking timebomb", says former United and England captain Rio Ferdinand.

## Manchester United: Glazer family owners look to sell all or part of Premier League club
 - [https://www.bbc.co.uk/sport/football/63723992?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63723992?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 21:58:28+00:00

Manchester United's American owners say they will "explore strategic alternatives" for the club "including new investment, a sale, or other transactions".

## World Cup 2022: Kylian Mbappe - Alan Shearer, Didier Drogba & Vincent Kompany analysis
 - [https://www.bbc.co.uk/sport/av/football/63724322?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63724322?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 21:39:48+00:00

BBC Sport's Gary Lineker, Alan Shearer, Didier Drogba and Vincent Kompany discuss Kylian Mbappe's brilliant performance against Australia and ask if there is any way defenders can stop "the greatest player on the planet."

## World Cup 2022: Germany face Japan with 'huge motivation' to avoid shock defeat
 - [https://www.bbc.co.uk/sport/football/63644792?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63644792?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 21:19:54+00:00

Midfielder Joshua Kimmich is desperate for Germany to right the wrongs of their woeful 2018 World Cup campaign.

## Trump taxes: Supreme Court clears Democrats to see returns
 - [https://www.bbc.co.uk/news/world-us-canada-63724223?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-63724223?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 21:19:50+00:00

Congressional Democrats have been chasing access to Mr Trump's financial records for three years.

## World Cup: Kylian Mbappe and Olivier Giroud fire France to 4-1 win against Australia - highlights
 - [https://www.bbc.co.uk/sport/av/football/63670510?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63670510?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 21:10:32+00:00

Watch highlights as Kylian Mbappe and Olivier Giroud star in a thrilling 4-1 victory for France against Australia in their opening Group D match at the World Cup.

## World Cup 2022: Kylian Mbappe scores for France against Australia
 - [https://www.bbc.co.uk/sport/av/football/63724040?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63724040?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 20:53:47+00:00

Watch as Kylian Mbappe crowns his brilliant performance with France's third goal against Australia in their opening Group D match at the World Cup.

## Housing target vote faces delay over Tory revolt
 - [https://www.bbc.co.uk/news/uk-politics-63720128?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63720128?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 20:47:41+00:00

It comes as Michael Gove is expected to meet Tory MPs amid the threat of a backbench rebellion.

## World Cup 2022: Kylian Mbappe flick sets up Olivier Giroud goal for France against Australia
 - [https://www.bbc.co.uk/sport/av/football/63724032?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63724032?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 19:56:56+00:00

Watch as Kylian Mbappe's brilliant flick begins a move finished by Olivier Giroud for France's second goal against Australia in their opening Group D match at the World Cup.

## World Cup 2022: More pain on biggest stage for 'emotional' Poland striker Robert Lewandowski
 - [https://www.bbc.co.uk/sport/football/63712910?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63712910?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 19:21:44+00:00

Robert Lewandowski was hurting after the 2018 World Cup, and still is as his wait for a goal continues.

## Ukraine monastery raid as SBU targets Russian agents
 - [https://www.bbc.co.uk/news/world-europe-63715922?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63715922?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 19:19:40+00:00

Kyiv authorities say they want to stop Russia using the site for sabotage, intelligence or weapons.

## Teachers' strike in Scotland to go ahead as new pay offer rejected
 - [https://www.bbc.co.uk/news/uk-scotland-63715723?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-63715723?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 18:39:09+00:00

Scotland's biggest teachers' union says a new pay offer is "insulting" and confirm Thursday's strike.

## Cristiano Ronaldo leaves Man Utd: Rio Ferdinand says 'both parties will be delighted'
 - [https://www.bbc.co.uk/sport/av/football/63722379?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63722379?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 18:22:33+00:00

BBC Sport's Rio Ferdinand says Manchester United and Cristiano Ronaldo will both be "delighted" after it was announced he is leaving the club with immediate effect.

## Mexico 0-0 Poland: Robert Lewandowski misses penalty in World Cup opener
 - [https://www.bbc.co.uk/sport/football/63631782?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63631782?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 18:14:54+00:00

Robert Lewandowski has a penalty saved as Poland and Mexico play out a goalless World Cup draw at a fervent Stadium 974.

## Antarctica penguins: How too much ice triggered population decline
 - [https://www.bbc.co.uk/news/world-australia-63700487?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-63700487?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 18:13:01+00:00

A large Adélie penguin population off Antarctica has fallen by 43% over the past decade.

## Richard Hammond reveals Top Gear crash coma dream
 - [https://www.bbc.co.uk/news/uk-63716208?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63716208?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 17:54:43+00:00

The presenter has gone viral on TikTok talking about his experience following a high-speed car crash in 2006.

## Just Stop Oil: Pair guilty of damaging Van Gogh painting's frame
 - [https://www.bbc.co.uk/news/uk-england-london-63717863?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-63717863?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 17:50:21+00:00

Activists Louis McKechnie and Emily Brocklebank glued themselves to Peach Trees In Blossom.

## Cristiano Ronaldo to leave Manchester United with immediate effect
 - [https://www.bbc.co.uk/sport/football/63720774?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63720774?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 17:48:45+00:00

Portugal forward Cristiano Ronaldo is to leave Manchester United with immediate effect.

## World Cup 2022: Guillermo Ochoa makes incredible save
 - [https://www.bbc.co.uk/sport/av/football/63721176?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63721176?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 17:35:35+00:00

Watch the moment Mexico's Guillermo Ochoa makes a brilliant save to deny Robert Lewandowski's penalty in Group C at the World Cup.

## World Cup 2022: Why Wales striker Kieffer Moore is underrated in every way - Ashley Williams
 - [https://www.bbc.co.uk/sport/football/63696845?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63696845?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 17:29:44+00:00

Former Wales captain Ashley Williams explains why striker Kieffer Moore is underrated in every way after his impact from the bench in the USA draw.

## Owen Paterson takes UK government to European court over lobbying probe
 - [https://www.bbc.co.uk/news/uk-politics-63714944?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63714944?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 17:28:05+00:00

Owen Paterson, who was forced to quit as an MP after a lobbying probe, claims his right to privacy was infringed.

## UK visas: How does the points-based immigration system work?
 - [https://www.bbc.co.uk/news/uk-48785695?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-48785695?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 17:26:27+00:00

Most people wanting to come to the UK to work need to apply via a points-based system.

## England v South Africa: Hugh Tizard & Bevan Rodd in contention for Springbok match
 - [https://www.bbc.co.uk/sport/rugby-union/63722363?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/63722363?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 17:20:52+00:00

Saracens' uncapped second row Hugh Tizard and Sale prop Bevan Rodd are named in a 26-strong England squad to prepare to face South Africa on Saturday.

## King Charles welcomes South Africa's Cyril Ramaphosa - in pictures
 - [https://www.bbc.co.uk/news/in-pictures-63714611?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-63714611?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 17:03:22+00:00

South Africa's Cyril Ramaphosa is welcomed to London as Charles III hosts his first state visit as King.

## Beth Mead: Arsenal & England forward out with anterior cruciate ligament injury
 - [https://www.bbc.co.uk/sport/football/63720708?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63720708?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 16:54:34+00:00

England forward Beth Mead will be out for "an extended period" after suffering a ruptured anterior cruciate ligament, her club Arsenal say.

## Twins born from embryos frozen 30 years ago
 - [https://www.bbc.co.uk/news/world-us-canada-63718914?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-63718914?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 16:52:55+00:00

It is believed to be a new record for the longest-frozen embryos ever to result in a successful live birth.

## More train strikes announced by rail union
 - [https://www.bbc.co.uk/news/business-63715658?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63715658?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 15:53:18+00:00

The RMT says further strike action will take place across four 48-hour periods in December and January.

## Chelsea manager Emma Hayes says injured forward Pernille Harder is irreplaceable
 - [https://www.bbc.co.uk/sport/football/63720235?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63720235?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 15:47:50+00:00

Injured forward Pernille Harder is irreplaceable, says Chelsea boss Emma Hayes.

## World Cup 2022: Denmark 0-0 Tunisia - toothless Danes held in opener
 - [https://www.bbc.co.uk/sport/football/63631780?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63631780?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 15:23:51+00:00

Denmark have to settle for a goalless draw against a spirited Tunisia in their Group D opening game in Qatar.

## World Cup 2022: Tunisia hold Denmark to goalless draw in Qatar
 - [https://www.bbc.co.uk/sport/av/football/63670506?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63670506?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 15:07:34+00:00

Tunisia hold Denmark to goalless draw in an intriguing Group D opener that saw both teams having goals ruled out by the officials.

## World Cup 2022: Saudi Arabia deliver 'seismic' shock but don't count Argentina out
 - [https://www.bbc.co.uk/sport/football/63718202?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63718202?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 14:51:17+00:00

Argentina's shock World Cup defeat by Saudi Arabia is "seismic" and "historic", but what does it mean for both nations?

## England v South Africa: Jacques Nienaber claims Springboks not given due respect
 - [https://www.bbc.co.uk/sport/rugby-union/63716162?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/63716162?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 14:30:03+00:00

South Africa coach Jacques Nienaber accuses the rugby world of lacking respect for his team in the wake of director of rugby Rassie Erasmus' ban for social media posts on referees.

## Thames Water lifts hosepipe ban for millions after heavy rain
 - [https://www.bbc.co.uk/news/uk-england-63718823?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-63718823?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 14:29:56+00:00

Thames Water says recent heavy rainfall has helped replenish river and reservoir levels.

## Strictly Come Dancing: Kym Marsh tests positive for Covid
 - [https://www.bbc.co.uk/news/entertainment-arts-63718895?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63718895?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 14:28:43+00:00

The former Hear'Say singer hopes to return the following week with her partner Graziano di Prima.

## World Cup 2022: 'I want more of the same from England, please' - Alan Shearer
 - [https://www.bbc.co.uk/sport/football/63696511?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63696511?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 13:58:41+00:00

Former England captain Alan Shearer says he hopes the Three Lions stick to the attacking approach shown against Iran when they face USA and Wales.

## Dressing room scenes after Saudis beat Argentina
 - [https://www.bbc.co.uk/sport/av/football/63717221?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63717221?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 13:57:18+00:00

We go inside the Saudi Arabia dressing room as their players celebrate the shock 2-1 victory against Argentina at the Fifa World Cup.

## Nottingham: Mother dies after fire that killed her children
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-63717024?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-63717024?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 13:30:42+00:00

Police are given extra time to question a 31-year-old man, held on suspicion of murder.

## Public vote to decide Oxford word of the year for first time
 - [https://www.bbc.co.uk/news/uk-63714604?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63714604?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 12:53:02+00:00

Language lovers can choose between metaverse, #IStandWith and the phrase goblin mode.

## 2022 World Cup: Saleh Al Shehri equalises for Saudi Arabia against Argentina
 - [https://www.bbc.co.uk/sport/av/football/63716395?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63716395?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 12:21:06+00:00

Saleh Al Shehri equalises early into the second-half for Saudi Arabia against Argentina at the Fifa World Cup.

## 2022 World Cup: Argentina take lead through controversial Lionel Messi penalty
 - [https://www.bbc.co.uk/sport/av/football/63716388?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63716388?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 12:17:18+00:00

Watch as Argentina take lead through controversial Lionel Messi penalty against Saudi Arabia at the Fifa World Cup.

## World Cup 2022: Saudi Arabia's Salem Al Dawsari stunner beats Argentina
 - [https://www.bbc.co.uk/sport/av/football/63716392?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63716392?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 12:09:44+00:00

Saudi Arabia take shock lead through Salem Al Dawsari's stunner to take 2-1 lead against Argentina at the World Cup.

## World Cup 2022: Argentina 1-2 Saudi Arabia highlights
 - [https://www.bbc.co.uk/sport/av/football/63669805?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63669805?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 12:07:09+00:00

All the goals as Saudi Arabia produce stunning upset by beating Argentina 2-1 at the World Cup.

## Manston processing centre empty after migrants placed in new accommodation
 - [https://www.bbc.co.uk/news/uk-63713074?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63713074?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 11:55:06+00:00

The migrant holding facility no longer has anyone being detained there, Home Office sources say.

## Australia v England: Travis Head and David Warner smash hosts to ODI series sweep
 - [https://www.bbc.co.uk/sport/cricket/63712778?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/63712778?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 11:44:53+00:00

Travis Head and David Warner share a record 269-run stand as Australia beat England by 221 runs in the third ODI in Melbourne.

## Eurovision scraps jury voting in semi-finals
 - [https://www.bbc.co.uk/news/entertainment-arts-63716398?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63716398?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 11:43:58+00:00

The move comes after several countries had their votes cancelled at this year's contest.

## Kidderminster man catches giant goldfish
 - [https://www.bbc.co.uk/news/uk-england-hereford-worcester-63707394?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-hereford-worcester-63707394?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 11:35:09+00:00

Andy Hackett from Kidderminster lands the "elusive" beast while on a trip to France.

## Prince Andrew heckler will not face court
 - [https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-63716064?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-63716064?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 11:25:45+00:00

The Duke of York was shouted at as he walked behind the Queen's coffin in Edinburgh.

## World Cup 2022: Wales match beats England game in TV ratings
 - [https://www.bbc.co.uk/news/entertainment-arts-63715578?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63715578?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 11:23:38+00:00

An average audience of 9.4 million watched the Wales match, while 7.8 million watched England.

## World Cup 2022: Declan Rice says criticism gave England players 'fire in our bellies'
 - [https://www.bbc.co.uk/sport/football/63714460?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63714460?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 11:13:05+00:00

Criticism of England's form before the World Cup gave players "fire in our bellies" against Iran, says midfielder Declan Rice.

## MPs can claim Christmas parties on expenses, says Ipsa
 - [https://www.bbc.co.uk/news/uk-politics-63714892?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63714892?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 11:12:26+00:00

The body responsible for MPs' expenses say an "office festive event" can include food and decorations.

## Hundreds of schools downgraded in England
 - [https://www.bbc.co.uk/news/education-63713880?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-63713880?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 10:50:52+00:00

Some of the 308 schools no longer rated outstanding had not been inspected for 15 years, Ofsted says.

## Disqualified driver jailed after crashing stolen car into bus stop
 - [https://www.bbc.co.uk/news/uk-63715762?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63715762?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 10:48:08+00:00

Monica Moss is sentenced to 24 months’ imprisonment following the incident in Crawley.

## Chinese GP to be cancelled because of Covid policy
 - [https://www.bbc.co.uk/sport/formula1/63713326?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/63713326?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 10:22:36+00:00

Formula 1 is set to cancel the 2023 Chinese Grand Prix due to the country's Covid policies, BBC Sport has learned.

## Better Leisure reduces opening hours as energy bills triple
 - [https://www.bbc.co.uk/news/uk-england-63703201?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-63703201?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 10:20:00+00:00

Better Leisure says it is introducing a temporary programme across many of its 268 centres.

## World Cup 2022: Virgil van Dijk hits back at criticism over OneLove armband row
 - [https://www.bbc.co.uk/sport/football/63713257?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63713257?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 09:45:37+00:00

Netherlands captain Virgil van Dijk hits back at criticism of European teams for deciding not to wear the OneLove armband at the World Cup.

## C﻿uban musician Pablo Milanés dies aged 79
 - [https://www.bbc.co.uk/news/articles/cn0497v1jdno?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/articles/cn0497v1jdno?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 09:36:38+00:00

The guitarist and singer was a key member of Cuba's Nuevo Trova movement after the revolution.

## Jack Grealish England World Cup worm dance delights young fan
 - [https://www.bbc.co.uk/news/uk-england-manchester-63709932?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-63709932?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 09:15:26+00:00

The 12-year-old boy who inspired the England player's dance move says "it's the best thing ever".

## Indonesia earthquake: Many schoolchildren killed in building collapses
 - [https://www.bbc.co.uk/news/world-asia-63712461?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-63712461?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 08:40:27+00:00

Rescuers are scrambling to find survivors amid the rubble of collapsed schools and homes.

## World Cup 2022: Belgium to drop 'love' from away shirts in Qatar
 - [https://www.bbc.co.uk/sport/football/63713724?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63713724?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 08:35:23+00:00

Belgium will not wear their white away shirts with the word "love" on the collar in the group stage of the World Cup following a discussion with Fifa.

## Cost of living: Eco-friendly options that could save money
 - [https://www.bbc.co.uk/news/newsbeat-63648143?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-63648143?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 08:04:48+00:00

Young people are repairing their broken things to help their finances - but it also helps the planet.

## UK government borrowing higher as energy bill support help begins
 - [https://www.bbc.co.uk/news/business-63704841?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63704841?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 07:59:59+00:00

Government borrowing rose last month as energy support schemes for households and businesses started.

## Top 10 greatest World Cup winners
 - [https://www.bbc.co.uk/sport/football/63235363?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63235363?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 07:07:09+00:00

The best World Cup-winning teams are ranked by Gary Lineker, Alan Shearer and Micah Richards in the latest Match of the Day Top 10 podcast.

## John Cantlie: Ten years since IS kidnap of British journalist in Syria
 - [https://www.bbc.co.uk/news/uk-63711446?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63711446?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 07:02:20+00:00

The fate of photographer John Cantlie, kidnapped by the jihadist group in 2012, remains unknown.

## Unboxed Festival: Do audience numbers justify £120m cost?
 - [https://www.bbc.co.uk/news/entertainment-arts-63656614?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63656614?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 06:35:37+00:00

The arts festival says 18m people across the UK have enjoyed Unboxed's programme of events.

## Rugby star Scott Hastings speaks of guilt over friend's cancer death
 - [https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-63663006?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-63663006?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 06:04:30+00:00

Former Scotland player Scott Hastings pays tribute to a school friend who died from cancer.

## 'Bondi Beast' serial rapist identified after almost 40 years
 - [https://www.bbc.co.uk/news/world-australia-63699882?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-63699882?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 05:53:02+00:00

Police believe the Sydney man attacked 31 women, including a teenager, in the 1980s and 1990s.

## Gujarat stray cattle: India man jailed for letting cows roam streets
 - [https://www.bbc.co.uk/news/world-asia-india-63658536?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-63658536?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 05:38:15+00:00

A court in Gujarat state convicted the man for letting cattle stray and endangering people’s lives.

## World Cup 2022: Wales hoping for history repeat after Bale salvages USA draw
 - [https://www.bbc.co.uk/sport/football/63711644?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63711644?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 05:29:44+00:00

Playing at their first World Cup for 64 years, Wales turned to a familiar saviour in Gareth Bale as they pulled a point from the fire in their opening game against the United States.

## Skegness: The seaside town at the centre of asylum debate
 - [https://www.bbc.co.uk/news/uk-england-lincolnshire-63663980?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lincolnshire-63663980?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 01:53:37+00:00

The BBC speaks to asylum seekers and residents in the seaside resort embroiled in the migrant row.

## King Charles to host South African president in first state visit as monarch
 - [https://www.bbc.co.uk/news/uk-63711177?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63711177?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 01:36:39+00:00

King Charles will hold a white-tie banquet for Cyril Ramaphosa at Buckingham Palace.

## Superbug fight 'needs farmers to reduce antibiotic use'
 - [https://www.bbc.co.uk/news/science-environment-63666024?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-63666024?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 01:16:11+00:00

Campaigners say they have found superbugs in rivers and waterways near farms and in livestock waste.

## Rwanda's electric vehicle push has a faltering start
 - [https://www.bbc.co.uk/news/business-63622624?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63622624?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 01:09:17+00:00

In a developing country like Rwanda building a market for electric cars has proved challenging.

## ESA mulls Solaris plan to beam solar energy from space
 - [https://www.bbc.co.uk/news/science-environment-62982113?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-62982113?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 01:00:43+00:00

The European Space Agency is considering the 'Solaris Initiative' plan to collect solar energy in orbit and beam electricity back to Earth.

## The Papers: Lions 'bare teeth' and Starmer's migration policy
 - [https://www.bbc.co.uk/news/blogs-the-papers-63711429?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-63711429?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 00:37:21+00:00

England's World Cup win over Iran and a speech on migration by the Labour leader lead the papers.

## Zimbabwe without Robert Mugabe: What has changed?
 - [https://www.bbc.co.uk/news/world-africa-63703145?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-63703145?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 00:21:48+00:00

It is exactly five years since Zimbabwe's ex-president left power but life is now worse for many.

## How many Covid cases does China have and what are its rules?
 - [https://www.bbc.co.uk/news/59882774?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/59882774?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 00:16:34+00:00

Covid-19 is flaring up in China, despite it having some of the toughest lockdown rules in the world.

## World Cup: The moment Gareth Bale sent Wales fans wild against USA
 - [https://www.bbc.co.uk/sport/av/football/63711766?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63711766?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 00:13:06+00:00

Watch the scenes as Gareth Bale sends Wales fans wild with their first World Cup goal in 64 years which earns a draw against the United States.

## World Cup 2022: Why is there so much stoppage time being added on?
 - [https://www.bbc.co.uk/sport/football/63710986?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63710986?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 00:08:50+00:00

The four matches at the World Cup so far have had much more stoppage time added on at the end of games than usual, but why?

## She Said stars praise women who spoke out against Harvey Weinstein
 - [https://www.bbc.co.uk/news/entertainment-arts-63707321?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63707321?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 00:04:49+00:00

The movie tells the story of the investigation that led to the downfall of one of Hollywood's most powerful figures.

## Black Friday: Shoppers warned most offers are not cheaper
 - [https://www.bbc.co.uk/news/business-63702559?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63702559?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 00:04:03+00:00

Only one in seven Black Friday deals offered a genuine discount last year, says consumer group Which?

## Qatar World Cup 2022: I walked 1,600km to get here
 - [https://www.bbc.co.uk/news/world-63708304?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-63708304?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 00:03:19+00:00

Saudi fan Abdullah al-Salmi walked all the way from his home in Jeddah to Doha to see the football tournament.

## Energy bills: Patients prescribed heating as part of health trial
 - [https://www.bbc.co.uk/news/business-63707689?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63707689?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 00:01:54+00:00

It is aimed at avoiding the cost of hospital care for patients whose conditions are worsened by the cold.

## Canada: Why the country wants to bring in 1.5m immigrants by 2025
 - [https://www.bbc.co.uk/news/world-us-canada-63643912?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-63643912?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 00:01:38+00:00

Some Canadians are concerned the country's aggressive immigration targets are too high.

## Cost of living: Energy suppliers failing to help vulnerable customers - report
 - [https://www.bbc.co.uk/news/business-63704037?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63704037?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-22 00:01:10+00:00

The regulator says its review has found serious problems among firms but suppliers have hit back.


# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## Meta researchers create AI that masters Diplomacy, tricking human players
 - [https://arstechnica.com/?p=1899693](https://arstechnica.com/?p=1899693)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-22 23:32:55+00:00

Meta's Cicero can negotiate or persuade with natural language—just like a human.

## Crypto and NFTs aren’t welcome in Grand Theft Auto Online
 - [https://arstechnica.com/?p=1899726](https://arstechnica.com/?p=1899726)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-22 22:28:20+00:00

Rockstar follows similar recent ban by Mojang and <em>Minecraft</em>.

## Thinking about taking your computer to the repair shop? Be very afraid
 - [https://arstechnica.com/?p=1899664](https://arstechnica.com/?p=1899664)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-22 20:51:52+00:00

Not surprisingly, female customers bear the brunt of the privacy violations.

## Review: Dell’s new UltraSharp monitor has high-contrast IPS Black screen
 - [https://arstechnica.com/?p=1881111](https://arstechnica.com/?p=1881111)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-22 20:01:27+00:00

Beefed-up image quality topped with a souped-up camera.

## Major tax-filing websites secretly share income data with Meta
 - [https://arstechnica.com/?p=1899620](https://arstechnica.com/?p=1899620)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-22 19:32:07+00:00

Financial data was sent to Meta by TaxAct, H&#038;R Block, and TaxSlayer.

## Android TV will require App Bundles in 2023, should reduce app size by 20%
 - [https://arstechnica.com/?p=1899518](https://arstechnica.com/?p=1899518)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-22 19:08:32+00:00

Bundles save space, with the tradeoff that developers give Google the app-signing keys.

## First efficacy data on bivalent boosters shows they work against infection
 - [https://arstechnica.com/?p=1899592](https://arstechnica.com/?p=1899592)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-22 18:55:14+00:00

"The bottom line is: We need more Americans vaccinated."

## LG continues diversifying OLED monitor options; lists 27-incher for $1,000
 - [https://arstechnica.com/?p=1899505](https://arstechnica.com/?p=1899505)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-22 18:44:34+00:00

Speed is the name of the game for this one.

## Danish scientists concoct fat-free whipped cream out of lactic acid bacteria
 - [https://arstechnica.com/?p=1899464](https://arstechnica.com/?p=1899464)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-22 18:19:10+00:00

Someday our holiday whipped topping could be made from beer-brewing residues or plants.

## Musk recruits engineers for “Twitter 2.0” after mass layoffs and resignations
 - [https://arstechnica.com/?p=1899533](https://arstechnica.com/?p=1899533)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-22 17:34:39+00:00

Musk: "People who are great at writing software are the highest priority."

## Spider monkey skeleton shows the risks of ancient Maya diplomacy
 - [https://arstechnica.com/?p=1899432](https://arstechnica.com/?p=1899432)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-22 17:26:45+00:00

The monkey is the oldest known captive, exported primate in Mesoamerica.

## Light, shadow, reflections, and terror: How a scary game does scary lighting
 - [https://arstechnica.com/?p=1899437](https://arstechnica.com/?p=1899437)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-22 17:05:09+00:00

Our behind-the-scenes look at <em>Callisto Protocol</em> continues with a look at terrifying visuals.

## Network-crashing leap seconds to be abandoned by 2035, for at least a century
 - [https://arstechnica.com/?p=1899455](https://arstechnica.com/?p=1899455)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-22 16:46:37+00:00

Our 50-year chronological rounding-error nightmare will soon be over.

## Ubisoft comes crawling back to Steam after years on Epic Games Store
 - [https://arstechnica.com/?p=1899491](https://arstechnica.com/?p=1899491)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-22 16:27:57+00:00

In 2019, company said Valve's 30 percent commissions were "unrealistic."

## Musk: Paid checkmarks won’t return until Twitter can stop impersonation
 - [https://arstechnica.com/?p=1899474](https://arstechnica.com/?p=1899474)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-22 16:20:27+00:00

Signal contradicts Musk, says it’s not helping to encrypt Twitter DMs.

## How Cupra made an electric hot hatch alternative to the Volkswagen ID.3
 - [https://arstechnica.com/?p=1899479](https://arstechnica.com/?p=1899479)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-22 16:08:41+00:00

Cupras drive very differently from VWs; Cupra's head of R&#038;D explains how.

## NASA’s new rocket blows the doors off its mobile launch tower
 - [https://arstechnica.com/?p=1899436](https://arstechnica.com/?p=1899436)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-22 14:23:26+00:00

"This is a dream for many of us who work at NASA."


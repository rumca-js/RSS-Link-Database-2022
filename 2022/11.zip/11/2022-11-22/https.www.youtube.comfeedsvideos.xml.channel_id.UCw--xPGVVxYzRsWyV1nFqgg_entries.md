# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## The Best Magical Objects? LET'S DEBATE!
 - [https://www.youtube.com/watch?v=4CNbrptZiyI](https://www.youtube.com/watch?v=4CNbrptZiyI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-11-23 00:00:00+00:00

Let's debate the best science fiction and fantasy magical objects! 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA 
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene


Merch: https://www.designbyhumans.com/shop/FantasyNews/ 


Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p


Equipment: 
Camera: https://amzn.to/3siqgHv  
Lens: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  


P.O. Box: PO Box 7874 Henrico, VA 23231

## 1899 Didn't STEAL Anything!
 - [https://www.youtube.com/watch?v=Bd7I2BUg0ck](https://www.youtube.com/watch?v=Bd7I2BUg0ck)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-11-22 00:00:00+00:00

Addressing the recent #1899 drama and controversy. 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA 
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.designbyhumans.com/shop/FantasyNews/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lens: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231


## How Bill C-11 Could Open the Door to State-Controlled Media: Peter Menzies in the Epoch Times
 - [https://macdonaldlaurier.ca/how-bill-c-11-could-open-the-door-to-state-controlled-media-peter-menzies-in-the-epoch-times/](https://macdonaldlaurier.ca/how-bill-c-11-could-open-the-door-to-state-controlled-media-peter-menzies-in-the-epoch-times/)
 - RSS feed: https://macdonaldlaurier.ca
 - date published: 2022-11-22 17:21:58+00:00

How Bill C-11 Could Open the Door to State-Controlled Media: Peter Menzies in the Epoch Times


# Source:ForrestKnight, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2WHjPDvbE6O328n17ZGcfg, language:en-US

## The ACTUAL Way to Code Productively & Professionally
 - [https://www.youtube.com/watch?v=Ov1tuHS4uNw](https://www.youtube.com/watch?v=Ov1tuHS4uNw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2WHjPDvbE6O328n17ZGcfg
 - date published: 2022-11-22 18:00:23+00:00

Get 75% OFF your first 3 months of APILayer for Black Friday (only available until November 30th): https://apilayer.com/offer?utm_source=Youtube&amp;utm_medium=Social&amp;utm_campaign=ForrestKnight.BlackFriday2022

I want to tell you how to be a more efficient software developer. Now, my “Why I Code for 4 Hours” video touches on the broader spectrum of how I am able improve efficiency in life that drips into my work as a software developer. This video is to get into the nitty-gritty details that are specific to developers, like taking time to master your IDE, refactoring your code, not over-engineering your solutions or reinventing the wheel, having a set of coding standards and style guidelines that you stick by, or even something as simple as learning keyboard shortcuts. Now, many of these things may take some time to accomplish up-front, but you have to weigh the time savings. You’ll find the long-term gain heavily outweighs the short-term loss.
This is what I implore you to do. Become an efficient programmer by following the things laid out in this video. You won’t be able to implement everything all at once. But pick one or two and start. Then pick up another few when you feel confident you’ve accomplished and can maintain the prior two. A comment with something you learned here today that maybe you’ll start implementing tomorrow will be greatly appreciated. Enjoy!

A portion of this video is sponsored by APILayer.

------------------------

🐱‍🚀 GitHub: https://github.com/forrestknight
🐦 Twitter: https://www.twitter.com/forrestpknight
💼 LinkedIn: https://www.linkedin.com/in/forrestpknight
📸 Instagram: https://www.instagram.com/forrestpknight
 
📓 Learning Resources: 
My Favorite Machine Learning Course:  https://imp.i384100.net/YgYEBJ
Open Source Computer Science Degree:  https://bit.ly/open-source-forrest
Python Open Source Computer Science Degree:  https://bit.ly/python-open-source
Udacity to Learn Any Coding Skill: http://bit.ly/udacity-forrest

👨‍💻 My Coding Gear:
My NAS Server: https://amzn.to/3brqO7b
My Hard Drives: https://amzn.to/3aKetMi
My Main Monitor: https://amzn.to/3siQfPa
My Second Monitor: https://amzn.to/3keHT84
My Standing Desk: https://amzn.to/3boAcbC
My PC Build:  https://bit.ly/my-coding-gear
My AI GPU: https://amzn.to/3uvmUmz


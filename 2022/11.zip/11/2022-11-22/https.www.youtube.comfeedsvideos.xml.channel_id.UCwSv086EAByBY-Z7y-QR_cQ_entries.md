# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## „Wynik zaufania” będzie normą, ze wszystkimi zaletami i wadami, jakie mogą przynieść.
 - [https://www.youtube.com/watch?v=Lap12vQ8cl4](https://www.youtube.com/watch?v=Lap12vQ8cl4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2022-11-23 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. http://bit.ly/3i8WYLF
2. http://bit.ly/3ibzXb6
3. http://bit.ly/3V7a7n1
4. http://bit.ly/2M9C7HV
5. http://bit.ly/3gw75ty
6. http://bit.ly/3EWcpQb
7. http://bit.ly/3i5ofMD
---------------------------------------------------------------
🎴 Do kolażu wykorzystano grafikę autorstwa: 
weforum.org - https://bit.ly/32t8u9N
---------------------------------------------------------------
💡 Tagi: #wef #schwab
--------------------------------------------------------------

## Juval Noach Harari: Elity cierpią na syndrom technologicznej Arki Noego!
 - [https://www.youtube.com/watch?v=Vbrlmk9nrGY](https://www.youtube.com/watch?v=Vbrlmk9nrGY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2022-11-22 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🎴 Wykorzystano grafikę ze stron:
artstation.com / Mitchell Stuart - http://bit.ly/3TXE5IS
---------------------------------------------------------------
✅ Źródła:
1. http://bit.ly/3UUl2Ru
---------------------------------------------------------------
💡 Tagi: #harari #utopia
--------------------------------------------------------------


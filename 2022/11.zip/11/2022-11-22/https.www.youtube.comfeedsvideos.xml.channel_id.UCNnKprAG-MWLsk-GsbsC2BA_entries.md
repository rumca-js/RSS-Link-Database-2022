# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## Fear the Furry
 - [https://www.youtube.com/watch?v=zRGLr9ZKznI](https://www.youtube.com/watch?v=zRGLr9ZKznI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2022-11-22 20:06:55+00:00

Go to our 2nd channel to see all the secret stuff you missed in this cartoon! https://youtu.be/AFOfdJ3y9bM

Special thanks to our Patron Producers!

Albert Hutchins
Andrew Palmer
Adam Knopow

Created by ► 
Tom Hinchliffe & Don Greger

Project Management ►
Redminus https://www.twitter.com/Redminus
BoyPorcelain https://www.twitter.com/OKillustrations

Animation ►
Twisted4000 https://twitter.com/Twisted4k
Carmet https://twitter.com/MikeCarmet
Glasscake https://twitter.com/glasscake
Super Youmna https://twitter.com/super_youmna
AZ https://twitter.com/ZoroxAnimated
TwistedGrim https://twitter.com/TheTwistedGrim_
Boy Porcelain https://www.instagram.com/olliekremer/
Holly Gee
Hunzero

Storyboard Art►
Boy Porcelain https://www.instagram.com/olliekremer/

Backgrounds ►
Naav Draws https://www.instagram.com/naav_draws/
Soured Apple https://twitter.com/SouredApple
Ikridia https://www.instagram.com/Ikridia
Logan Cook https://www.instagram.com/logan_cook_art
AJJ https://twitter.com/taksesal
SlagBjorn.art https://www.instagram.com/slagbjorn.art/
Chompolon https://twitter.com/chompolino
Lexivine https://twitter.com/lexivine
SpectralBeacon https://twitter.com/spectralbeacon

VO ► 
Marine - Don
UWU Marine - Tom 

Music ►
Zach Heyde https://youtube.com/playlist?list=PLXtP4ANq7nIUYo6VZEEHtd8H3HP_MthUC

Sound ► 
Justin Greger https://twitter.com/imadeasong

Compositing ► 
Oddest of the Odd
James Lee

Merch ►
https://crowdmade.com/flashgitz

Instagram ►
https://www.instagram.com/flashgitz/

Twitter ►
https://www.twitter.com/flashgitzanims
https://www.twitter.com/flashgitztom
https://www.twitter.com/flashgitzdon

Discord ►
https://discord.gg/nJCcJj6


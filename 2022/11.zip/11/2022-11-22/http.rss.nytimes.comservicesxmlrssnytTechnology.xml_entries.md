# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## How Covid Myths Spread on Far-Right Social Media Platforms
 - [https://www.nytimes.com/2022/11/22/us/politics/covid-misinformation-gab.html](https://www.nytimes.com/2022/11/22/us/politics/covid-misinformation-gab.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-11-22 22:40:38+00:00

The Biden administration has pushed social media giants like Facebook to curb Covid misinformation. But it is thriving on fringe platforms like Gab, a hub for extremist content.

## As Elon Musk Cuts Costs at Twitter, Some Bills Are Going Unpaid
 - [https://www.nytimes.com/2022/11/22/technology/elon-musk-twitter-cost-cutting.html](https://www.nytimes.com/2022/11/22/technology/elon-musk-twitter-cost-cutting.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-11-22 18:49:43+00:00

Mr. Musk and his advisers are examining all types of expenses at Twitter. Some of the social media company’s vendors have gotten stiffed.

## FTX Assets Still Missing as Firm Begins Bankruptcy Process
 - [https://www.nytimes.com/2022/11/22/business/ftx-bankruptcy-sam-bankman-fried.html](https://www.nytimes.com/2022/11/22/business/ftx-bankruptcy-sam-bankman-fried.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-11-22 18:14:03+00:00

A substantial amount of the company’s assets are missing, an FTX lawyer told a bankruptcy judge on Tuesday.

## Elon Musk’s Twitter Role Puts Tesla Board Under New Scrutiny
 - [https://www.nytimes.com/2022/11/22/business/elon-musk-tesla-board-twitter.html](https://www.nytimes.com/2022/11/22/business/elon-musk-tesla-board-twitter.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-11-22 17:01:00+00:00

Corporate governance experts say the electric-car maker’s directors may need to rein in the chief executive, with whom many have personal ties.


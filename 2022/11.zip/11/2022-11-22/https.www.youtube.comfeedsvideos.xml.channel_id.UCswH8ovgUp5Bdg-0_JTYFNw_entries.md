# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Qatar World Cup - This Goes Deeper Than You Know
 - [https://www.youtube.com/watch?v=J5kkRMq-TBg](https://www.youtube.com/watch?v=J5kkRMq-TBg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-11-23 00:00:00+00:00

Here is my take on the Qatar World Cup & what it really means for Qatar to hold this competition. #qatar #worldcup #football 
--------------------------------------------------------------------------------------------------------------------------
FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand

Join The Community STAY FREE AF: https://russellbrand.locals.com/

Come to My Festival COMMUNITY - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/

## Wait, Did THIS Really Happen?
 - [https://www.youtube.com/watch?v=kk7d5JocgvY](https://www.youtube.com/watch?v=kk7d5JocgvY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-11-22 00:00:00+00:00

We beat Big Pharma! No you didn’t Joe. But ordinary people found a way of denting the profits of Eli Lilly – the pharma company making billions from life-saving insulin by charging 4000 times what it costs to produce. Let’s revel in this story. #elililly #bigpharma #twitter 

References
https://www.fiercepharma.com/marketing/eli-lilly-pulls-twitter-ads-after-blue-check-fallout-report
https://www.forbes.com/sites/brucelee/2022/11/12/fake-eli-lilly-twitter-account-claims-insulin-is-free-stock-falls-43/
https://www.pharmaceutical-technology.com/news/lilly-full-year-2021-revenue/
https://www.commondreams.org/news/2022/11/14/amid-eli-lilly-twitter-fiasco-groups-call-end-insulin-price-gouging
--------------------------------------------------------------------------------------------------------------------------
FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand

Join The Community STAY FREE AF: https://russellbrand.locals.com/

Come to My Festival COMMUNITY - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/


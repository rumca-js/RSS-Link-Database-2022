# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 10 NEW Games of December 2022
 - [https://www.youtube.com/watch?v=wbHZyjaeSoE](https://www.youtube.com/watch?v=wbHZyjaeSoE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-11-23 00:00:00+00:00

Looking for something to play on pC, PS5, PS4,  Xbox Series X/S/One or Nintendo Switch this December? We got you covered with these video game release dates.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro 
0:15 Choo-Choo Charles 
1:34 Crisis Core –Final Fantasy 7– Reunion 
2:40 The Witcher 3 
3:41 Knights of Honor 2: Sovereign 
4:46 Samurai Maiden
5:51 The Walking Dead: Saints & Sinners – Chapter 2: Retribution 
6:45 High On Life 
8:05 Marvel's Midnight Suns 
9:21 Need For Speed Unbound 
10:32 The Callisto Protocol 
11:36 BONUS

10 Choo-Choo Charles 

Platform :- PC

Release Date :- December 9, 2022 



9 Crisis Core –Final Fantasy 7– Reunion 

PC PS5 XSX|S PS4 XBOX ONE Switch

Release Date :- December 13,  2022



8 The Witcher 3 

Platform :- PS5 XSX|S

Release Date :- December 14, 2022



7 Knights of Honor 2: Sovereign 

Platform :- PC 

Release Date :- December 6, 2022

 

6 Samurai Maiden

Platform :- PC Switch PS4 PS5

Release Date :- December 8, 2022 



5 The Walking Dead: Saints & Sinners – Chapter 2: Retribution 

Platform :- PC Meta Quest 2

Release Date :- December 1, 2022 



4 High On Life 

Platform :-  PC XSX|S Xbox One

Release Date :- December 13, 2022 



3 Marvel's Midnight Suns 

Platform :- PC PS5 XSX|S 

Release Date :- December 2, 2022 



2 Need For Speed Unbound 

Platform :- PC PS5 XSX|S

Release Date :- December 2,  2022



1 The Callisto Protocol 

Platform :- PC PS5 XSX|S PS4 XBOX ONE

Release Date :- December 2, 2022



BONUS

Back 4 Blood: River of Blood DLC 

Platform :- PC PS5 XSX|S PS4 XBOX ONE 

Release Date :- December 6 



Hello Neighbor 2 

Platform :- PS4 PS5 Xbox One XSX|S PC 

Release Date :- December 6, 2022

## 10 Third Person Games With OVER THE TOP ACTION
 - [https://www.youtube.com/watch?v=4YTnD32TXAQ](https://www.youtube.com/watch?v=4YTnD32TXAQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-11-22 00:00:00+00:00

Some third person perspective games bring incredibly wild action and combat to the table. Here are some of our favorites. 
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:18 Vanquish
1:38 Just Cause Series
2:54 Castlevania: Lords of Shadow
3:54 Bayonetta Series
5:07 Metal Gear Rising: Revengeance 
6:48 Stranglehold
8:08 Earth Defense Force Series
9:16 Devil May Cry 5
10:22 God of War Ragnarok
11:09 Asura's Wrath


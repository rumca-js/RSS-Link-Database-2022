# Source:Screen Junkies, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCOpcACMWblDls9Z6GERVi1A, language:en-US

## Honest Trailers | Pocahontas
 - [https://www.youtube.com/watch?v=wyspEl3a4YA](https://www.youtube.com/watch?v=wyspEl3a4YA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCOpcACMWblDls9Z6GERVi1A
 - date published: 2022-11-22 18:00:26+00:00

►►Subscribe to ScreenJunkies!► https://fandom.link/SJSubscribe

►►Check out the Fandom Twitch Channel!► http://twitch.tv/fandom

►►Watch the Honest Trailers Commentary with the Writers!► 

Honest Trailers | Pocahontas
Voice Narration: Jon Bailey aka Epic Voice Guy
Composer and Producer: David B
Title Design: Robert Holtby
Written by: Spencer Gilbert, Danielle Radford, Lon Harris & Bailey Meyers
Produced by: Spencer Gilbert
Associate Producer: Ryan O'Toole
Edited by: Randy Whitlock
Post-Production Supervisor: Emin Bassavand
Post-Production Coordinator: Mikołaj Kossakowski
Assistant Editor: Rebecca Castaneda
Director of Video Production: Max Dionne
#HonestTrailers


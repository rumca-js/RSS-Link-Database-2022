# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Illegal Immigrant Identified By Authorities As Suspected Burglar Of Katie Hobbs’ Campaign Office, Debunking Attempted Blame On Kari Lake
 - [https://www.dailywire.com/news/illegal-immigrant-identified-by-authorities-as-suspected-burglar-of-katie-hobbs-campaign-office-debunking-attempted-blame-on-kari-lake](https://www.dailywire.com/news/illegal-immigrant-identified-by-authorities-as-suspected-burglar-of-katie-hobbs-campaign-office-debunking-attempted-blame-on-kari-lake)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 23:50:38+00:00

Immigration and Customs Enforcement (ICE) said Wednesday that an illegal immigrant allegedly broke into the campaign office of Democrat gubernatorial candidate Katie Hobbs last week, despite her seeming attempt to blame it on her Republican opponent Kari Lake. According to local media, ICE said Daniel Mota Dos Reis, 36, of Portugal, who arrived in the ...

## The Purge Begins: Musk Is Terminating Massive Number Of Twitter Employees On Friday, Report Says
 - [https://www.dailywire.com/news/the-purge-begins-musk-is-terminating-massive-number-of-twitter-employees-on-friday-report-says](https://www.dailywire.com/news/the-purge-begins-musk-is-terminating-massive-number-of-twitter-employees-on-friday-report-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 22:15:17+00:00

New Twitter CEO Elon Musk will reportedly eliminate half of the company&#8217;s workforce at the end of this week as he tries to make the company profitable. Bloomberg News reported that Musk is cutting 3,700 of the company&#8217;s 7,500 employees and that employees will be notified of their dismissal on Friday. Musk is also reportedly ...

## Biden, Calling For Americans To Unite, Demonizes Republicans As A Threat To Democracy
 - [https://www.dailywire.com/news/biden-calling-for-americans-to-unite-demonizes-republicans-as-a-threat-to-democracy](https://www.dailywire.com/news/biden-calling-for-americans-to-unite-demonizes-republicans-as-a-threat-to-democracy)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 22:03:59+00:00

President Joe Biden (D) urged Americans to unite around shared values during a speech he delivered Wednesday night where he repeatedly demonized tens of millions of Republicans as a threat to the country. Biden started his speech by connecting an attack by a deranged lunatic on House Speaker Nancy Pelosi&#8217;s (D) husband to the January ...

## Musk Agrees To Restore Censorship Tools After Meeting With Leftists: ‘Elon Caved In Less Than A Week’
 - [https://www.dailywire.com/news/musk-agrees-to-restore-censorship-tools-after-meeting-with-leftists-elon-caved-in-less-than-a-week](https://www.dailywire.com/news/musk-agrees-to-restore-censorship-tools-after-meeting-with-leftists-elon-caved-in-less-than-a-week)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 21:19:08+00:00

New Twitter CEO Elon Musk reportedly will restore the content moderation tools that he briefly suspended after taking over following a meeting that he had this week with left-wing groups. Bloomberg News reported that Musk &#8220;promised&#8221; the groups that he would &#8220;restore content moderation tools that had been blocked for some staff by the end ...

## Arizona Judge Issues Restraining Order Against Voter Org Monitoring Drop Boxes, A Week After Ruling In Their Favor
 - [https://www.dailywire.com/news/arizona-judge-issues-restraining-order-against-voter-org-monitoring-drop-boxes-a-week-after-ruling-in-their-favor](https://www.dailywire.com/news/arizona-judge-issues-restraining-order-against-voter-org-monitoring-drop-boxes-a-week-after-ruling-in-their-favor)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 20:31:02+00:00

Just days after allowing an activist group to monitor ballot drop boxes, a federal judge issued a restraining order restricting the group&#8217;s activities. In an order handed down Tuesday evening, judge Michael T. Liburdi of the U.S. District Court of Arizona severely curtailed the activities that members of the election activist group Clean Elections USA ...

## Jake Tapper’s Primetime Slot At CNN Is Ending: Report
 - [https://www.dailywire.com/news/jake-tappers-primetime-slot-at-cnn-is-ending-report](https://www.dailywire.com/news/jake-tappers-primetime-slot-at-cnn-is-ending-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 20:30:14+00:00

CNN&#8217;s experiment moving Jake Tapper to the network&#8217;s primetime lineup is coming to an end after he struggled to keep up with competitors in ratings during the time slot. &#8220;As part of a special lineup, Jake agreed to anchor the 9p hour through the midterm elections,&#8221; a CNN spokesperson said. &#8220;At the completion of that ...

## WATCH: CNN Anchor Admits Democrats ‘Don’t Want To Be Seen’ With Biden
 - [https://www.dailywire.com/news/watch-cnn-anchor-admits-democrats-dont-want-to-be-seen-with-biden](https://www.dailywire.com/news/watch-cnn-anchor-admits-democrats-dont-want-to-be-seen-with-biden)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 20:24:22+00:00

CNN anchor Don Lemon admitted on Wednesday that Democratic candidates around the country were making it clear that they did not &#8220;want to be seen&#8221; with President Joe Biden. Lemon and his new morning co-hosts Kaitlan Collins and Poppy Harlow responded Wednesday to the most recent polling — which showed yet another dip in popularity ...

## In Desperate Bid To Save Democrats, Pollsters Don’t Care If They’re Wrong This Time
 - [https://www.dailywire.com/news/in-desperate-bid-to-save-democrats-pollsters-dont-care-if-theyre-wrong-this-time](https://www.dailywire.com/news/in-desperate-bid-to-save-democrats-pollsters-dont-care-if-theyre-wrong-this-time)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 19:39:38+00:00

Since the beginning of October, there have been 32 nationwide surveys taken on what pollsters call a &#8220;generic congressional ballot.&#8221; It&#8217;s a simple poll: Without being specific about candidates, the pollsters ask respondents who they will likely vote for in an election, Republicans or Democrats. Of those 32 surveys, just two outlets &#8212; Economist/YouGov and ...

## New York Appeals Court Rejects GOP Challenges To COVID-Era Absentee Voting Laws
 - [https://www.dailywire.com/news/new-york-appeals-court-rejects-gop-challenges-to-covid-era-absentee-voting-laws](https://www.dailywire.com/news/new-york-appeals-court-rejects-gop-challenges-to-covid-era-absentee-voting-laws)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 19:26:33+00:00

With one week left before the election, a New York appeals court declined Republican groups’ challenges to New York’s absentee voting laws established during the pandemic. The New York Appellate Division, Third Department ruled in two cases: Amedure v. New York and Cavalier v. Warren County Board of Elections. The court upheld laws allowing absentee ...

## ‘Superstar Losers’ Stacey Abrams, Beto O’Rourke Raised $170 Million To Unseat Republican Governors In Texas, Georgia. Polls Show They’re Getting Crushed.
 - [https://www.dailywire.com/news/superstar-losers-stacey-abrams-beto-orourke-raised-170-million-to-unseat-republican-governors-in-texas-georgia-polls-show-theyre-getting-crushed](https://www.dailywire.com/news/superstar-losers-stacey-abrams-beto-orourke-raised-170-million-to-unseat-republican-governors-in-texas-georgia-polls-show-theyre-getting-crushed)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 19:16:57+00:00

Democrats Stacey Abrams and Robert Francis &#8220;Beto&#8221; O&#8217;Rourke raised tens of millions of dollars, despite campaigns on track to get crushed in the 2022 midterms. Neither O&#8217;Rourke nor Abrams have led in any major public polling for the entirety of the 2022 election cycle. But new fundraising numbers for both campaigns show that O&#8217;Rourke raised ...

## ‘It’s Downright Racist’: Sara Haines Dares To Defend Asian Americans, And Her Co-Hosts Scold Her For It
 - [https://www.dailywire.com/news/its-downright-racist-sara-haines-dares-to-defend-asian-americans-and-her-co-hosts-scold-her-for-it](https://www.dailywire.com/news/its-downright-racist-sara-haines-dares-to-defend-asian-americans-and-her-co-hosts-scold-her-for-it)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 19:02:29+00:00

&#8220;The View&#8221; host Sara Haines dared to defend Asian Americans during Wednesday&#8217;s broadcast of the ABC midday talk show, and her co-hosts rewarded her efforts by scolding her, stopping just short of labeling her a racist as well. Haines and her co-hosts spent a portion of Wednesday&#8217;s show discussing one of the cases currently before ...

## Lee Zeldin Picks Up Key Endorsement – From The Naked Cowboy
 - [https://www.dailywire.com/news/lee-zeldin-picks-up-key-endorsement-from-the-naked-cowboy](https://www.dailywire.com/news/lee-zeldin-picks-up-key-endorsement-from-the-naked-cowboy)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 18:35:03+00:00

Rep. Lee Zeldin (R-NY) and New York gubernatorial candidate locked in another endorsement Wednesday from a long-time New Yorker famous for standing in the middle of Time Square wearing only cowboy boots, a hat, and white briefs while serenading everyday crowds with his acoustic guitar hanging just low enough to create an illusion of nudity, ...

## AOC Complains About Changes On Twitter; Musk Torches Her
 - [https://www.dailywire.com/news/aoc-complains-about-changes-on-twitter-musk-torches-her](https://www.dailywire.com/news/aoc-complains-about-changes-on-twitter-musk-torches-her)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 18:16:26+00:00

Rep. Alexandria Ocasio-Cortez (D-NY) complained on Twitter this week about the changes that new Twitter CEO Elon Musk is making to the platform, and she received a reply from the world&#8217;s richest man. AOC&#8217;s remarks came after Musk said that he will charge users $8 per month for a variety of features, which has sparked ...

## Data Show Most Michigan Voters Don’t Go Along With Woke Culture. Their Governor Flirts With It.
 - [https://www.dailywire.com/news/data-show-most-michigan-voters-dont-go-along-with-woke-culture-their-governor-flirts-with-it](https://www.dailywire.com/news/data-show-most-michigan-voters-dont-go-along-with-woke-culture-their-governor-flirts-with-it)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 18:14:39+00:00

The majority of Michigan voters aren’t too excited to hop on the woke train, even as their governor climbs aboard. According to data from the Michigan GOP and Victory Modeling, only around one in five Michiganders fully support woke ideas such as defunding the police, social media censorship, transgender athletes in women’s sports, and Critical ...

## Florida Judge Sentences Parkland School Shooter To Life In Prison Without Parole
 - [https://www.dailywire.com/news/florida-judge-sentences-parkland-school-shooter-to-life-in-prison-without-parole](https://www.dailywire.com/news/florida-judge-sentences-parkland-school-shooter-to-life-in-prison-without-parole)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 17:35:34+00:00

The Parkland shooter who killed 17 people on Valentine&#8217;s Day in 2018 was formally sentenced to life in prison without the possibility of parole on Wednesday after a Florida jury rejected the death penalty last month. The shooter, who The Daily Wire will not name, pleaded guilty to 17 counts of murder last year, which ...

## Beauty Queens Reveal They Secretly Wed After Keeping Their Relationship Private Since 2020
 - [https://www.dailywire.com/news/beauty-queens-reveal-they-secretly-wed-after-keeping-their-relationship-private-since-2020](https://www.dailywire.com/news/beauty-queens-reveal-they-secretly-wed-after-keeping-their-relationship-private-since-2020)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 17:17:21+00:00

A pair of former international beauty queens didn&#8217;t just come out of the closet last week, they sashayed down the aisle together. Former Miss Argentina Mariana Varela and Miss Puerto Rico Fabiola Valentín told their Instagram followers they tied the knot on Oct. 28 after a two-year, secret romance, Page Six reported Wednesday. The news ...

## Deja Vu All Over Again: Will Biden Speech Denigrate Half The Country As Threats To Democracy Wednesday Night?
 - [https://www.dailywire.com/news/deja-vu-all-over-again-will-biden-speech-denigrate-half-the-country-as-threats-to-democracy-wednesday-night](https://www.dailywire.com/news/deja-vu-all-over-again-will-biden-speech-denigrate-half-the-country-as-threats-to-democracy-wednesday-night)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 17:10:52+00:00

On September 1, President Joe Biden gave a prime-time address warning the United States that &#8220;MAGA forces&#8221; around the country were posing imminent threats to democracy. The speech was widely decried as authoritarian and despotic. The U.S. had never seen anything like it. Pundits were convinced that the White House would never try something so ...

## ‘Dahmer’ Series Creator Says He Was Upset Over LGBTQ Tag Removal, Says It’s A Story About ‘Gay Man’ And ‘His Gay Victims’
 - [https://www.dailywire.com/news/dahmer-series-creator-says-he-was-upset-over-lgbtq-tag-removal-says-its-a-story-about-gay-man-and-his-gay-victims](https://www.dailywire.com/news/dahmer-series-creator-says-he-was-upset-over-lgbtq-tag-removal-says-its-a-story-about-gay-man-and-his-gay-victims)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 16:57:24+00:00

Ryan Murphy, the man who created the hit Netflix series about serial murderer Jeffrey Dahmer, said he was upset when the platform removed the LGBTQ tag from the story about a &#8220;gay man&#8221; and &#8220;his gay victims.&#8221; In a recent lengthy interview for The New York Times, Murphy said not all &#8220;gay stories&#8221; have to ...

## What The Federal Reserve’s Changing Approach Toward Rate Hikes Could Mean For The Economy
 - [https://www.dailywire.com/news/what-the-federal-reserves-changing-approach-toward-rate-hikes-could-mean-for-the-economy](https://www.dailywire.com/news/what-the-federal-reserves-changing-approach-toward-rate-hikes-could-mean-for-the-economy)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 16:47:58+00:00

The Federal Reserve raised the target federal funds rate by 0.75% on Wednesday, but indicated that officials will avoid an overly zealous contractionary policy even as economists warn of a lagged effect that could reach into next year. The fourth consecutive 0.75% increase occurs as inflation remains elevated at four-decade highs. Target interest rates are ...

## White House Deletes Tweet After Getting Humiliated By Fact-Check
 - [https://www.dailywire.com/news/white-house-deletes-tweet-after-getting-humiliated-by-fact-check](https://www.dailywire.com/news/white-house-deletes-tweet-after-getting-humiliated-by-fact-check)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 16:43:19+00:00

The Biden administration deleted a tweet on Wednesday after it was fact-checked because it was missing key context. &#8220;Seniors are getting the biggest increase in their Social Security checks in 10 years through President Biden&#8217;s leadership,&#8221; the administration claimed. Twitter&#8217;s Birdwatch program, which has existed for a while, attached a note to the tweet noting ...

## Nation’s Largest Teachers Unions Dump At Least $2.25 Million On Michigan Gov. Whitmer Re-Election Campaign
 - [https://www.dailywire.com/news/nations-largest-teachers-unions-dump-at-least-2-25-million-on-michigan-gov-whitmer-re-election-campaign](https://www.dailywire.com/news/nations-largest-teachers-unions-dump-at-least-2-25-million-on-michigan-gov-whitmer-re-election-campaign)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 16:32:50+00:00

Michigan Democrat Governor Gretchen Whitmer&#8217;s re-election campaign received at least $2.25 million in donations from two of the nation&#8217;s largest teachers unions. According to a Fox News report, the pro-Whitmer group &#8220;Put Michigan First,&#8221; which aligns itself with the Democratic Governors Association, took $1 million in campaign contributions from the National Education Association (NEA), while ...

## ‘Should Be Ashamed’: Twitter Reacts To Man Who Identifies As Disabled Woman, Uses Wheelchair ‘Most Of The Time’
 - [https://www.dailywire.com/news/should-be-ashamed-twitter-reacts-to-man-who-identifies-as-disabled-woman-uses-wheelchair-most-of-the-time](https://www.dailywire.com/news/should-be-ashamed-twitter-reacts-to-man-who-identifies-as-disabled-woman-uses-wheelchair-most-of-the-time)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 16:20:48+00:00

A Norwegian man who identifies as a woman has inspired ire on social media for also identifying as disabled and using a wheelchair despite not physically needing one. “I have struggled with this every day my whole life,” Jørund Viktoria Alme, 53, told the Norwegian outlet Vi earlier this year, according to Reduxx. “It is ...

## Russian MMA Star Alexander Pisarev Dead At 33
 - [https://www.dailywire.com/news/russian-mma-star-alexander-pisarev-dead-at-33](https://www.dailywire.com/news/russian-mma-star-alexander-pisarev-dead-at-33)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 16:07:07+00:00

A professional Russian MMA fighter with no history serious health problems reportedly was found dead in his apartment by a family member. Alexander Pisarev, 33, was rushed to the hospital, according to some sources, along with his wife, who remains hospitalized, on October 30 after his father found him. &#8220;Alexander Pisarev died in his sleep ...

## Hunter Biden Laptop Reveals Disturbing Information About President’s Son, Underage Relative
 - [https://www.dailywire.com/news/hunter-biden-laptop-reveals-disturbing-information-about-presidents-son-underage-relative](https://www.dailywire.com/news/hunter-biden-laptop-reveals-disturbing-information-about-presidents-son-underage-relative)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 15:53:35+00:00

Hunter Biden complained to family members that his sister-in-law-turned-ex-lover Hallie Biden was accusing him of being sexually inappropriate with a relative in her early teens—accusations he strenuously denied&#8211;according to a review of the First Son&#8217;s abandoned laptop.

## Whoopi Lectures Clarence Thomas On Diversity, Suggests He Was An Affirmative Action Case
 - [https://www.dailywire.com/news/whoopi-lectures-clarence-thomas-on-diversity-suggests-he-was-an-affirmative-action-case](https://www.dailywire.com/news/whoopi-lectures-clarence-thomas-on-diversity-suggests-he-was-an-affirmative-action-case)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 15:36:40+00:00

&#8220;The View&#8221; host Whoopi Goldberg lectured Supreme Court Justice Clarence Thomas on the meaning of &#8220;diversity&#8221; during Wednesday&#8217;s broadcast, suggesting that Thomas himself might have benefitted from Affirmative Action. Goldberg and her co-hosts spent a portion of the show discussing the Affirmative Action case that the Supreme Court heard this week, questioning the &#8220;race-conscious&#8221; admissions ...

## William Shatner Has Hilarious Response To Musk Charging For Blue Check Marks
 - [https://www.dailywire.com/news/william-shatner-has-hilarious-response-to-musk-charging-for-blue-check-marks](https://www.dailywire.com/news/william-shatner-has-hilarious-response-to-musk-charging-for-blue-check-marks)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 15:25:08+00:00

Star Trek legend William Shatner had a hilarious response Wednesday to Twitter CEO Elon Musk&#8217;s plan to charge $8 a month to those verified Twitter users with blue check marks. The 91-year-old actor told one follower that he had zero plans to pay for &#8220;false status&#8221; on the social media platform when he already has ...

## ‘We Get It. You Bagged The Gorilla’: Megyn Kelly Mocks Meghan Markle’s Frequent ‘My Husband’ Comments
 - [https://www.dailywire.com/news/we-get-it-you-bagged-the-gorilla-megyn-kelly-mocks-meghan-markles-frequent-my-husband-comments](https://www.dailywire.com/news/we-get-it-you-bagged-the-gorilla-megyn-kelly-mocks-meghan-markles-frequent-my-husband-comments)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 15:17:33+00:00

Megyn Kelly, who has made no bones about her dislike for Meghan Markle, took another shot at her saying that Markle constantly refers to Prince Harry as &#8220;my husband.” Kelly made her remarks on her podcast “The Megyn Kelly Show,” where she spoke with Christopher Anderson, the author of “The King: The Life of Charles ...

## Daniel Radcliffe: Choosing Sides Against J.K. Rowling In Trans Argument Was ‘Important’
 - [https://www.dailywire.com/news/daniel-radcliffe-choosing-sides-against-j-k-rowling-in-trans-argument-was-important](https://www.dailywire.com/news/daniel-radcliffe-choosing-sides-against-j-k-rowling-in-trans-argument-was-important)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 15:13:25+00:00

Daniel Radcliffe is doubling down on his original stance against “Harry Potter” creator J.K. Rowling, who has been one of the few celebrities to express her disagreement with the transgender community. Radcliffe, an English actor best known for portraying the main character in the “Harry Potter” film franchise, had previously been close with the British ...

## ‘I’m Never Going To Accept This’: ‘Married With Children’ Star Opens Up About MS Battle
 - [https://www.dailywire.com/news/im-never-going-to-accept-this-married-with-children-star-opens-up-about-ms-battle](https://www.dailywire.com/news/im-never-going-to-accept-this-married-with-children-star-opens-up-about-ms-battle)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 14:47:30+00:00

Actress Christina Applegate shared her ongoing struggles with multiple sclerosis in a recent interview with The New York Times, revealing that she had gained some 40 pounds and could no longer walk without the use of a cane. Applegate spoke with the NYT ahead of the release of the final season of her Netflix series &#8220;Dead ...

## WSJ Poll: White Suburban Women Shift 15 Points In Favor Of Republicans In Congress
 - [https://www.dailywire.com/news/wsj-poll-white-suburban-women-shift-15-points-in-favor-of-republicans-in-congress](https://www.dailywire.com/news/wsj-poll-white-suburban-women-shift-15-points-in-favor-of-republicans-in-congress)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 14:38:16+00:00

A crucial demographic is leaning more toward Republicans in the midterm elections.  White suburban women voters have shifted their support to Republicans running for Congress by 15 percentage points, according to a new Wall Street Journal poll. The move demonstrates a 27-point move away from Democrats since the Journal’s poll from August. The group of ...

## ‘Lightweight, Empty-Suited, Empty-Headed Motherf***ers Like Ibram X. Kendi’: Loury Gives Epic Rant On CRT Leader
 - [https://www.dailywire.com/news/lightweight-empty-suited-empty-headed-motherfers-like-ibram-x-kendi-loury-gives-epic-rant-on-crt-leader](https://www.dailywire.com/news/lightweight-empty-suited-empty-headed-motherfers-like-ibram-x-kendi-loury-gives-epic-rant-on-crt-leader)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 14:36:12+00:00

Conservative economist Glenn Loury, whose disdain for Critical Race Theory (CRT) leader Ibram X. Kendi is swiftly becoming legendary, went on a tirade on his podcast that left his guest Columbia University professor of linguistics John McWhorter, laughing and unable to speak. Loury has been outspoken in his condemnation of black leaders who he feels ...

## For Freedom To Prevail In Iran, America Must Take A Hard Line Stance Against The Regime
 - [https://www.dailywire.com/news/for-freedom-to-prevail-in-iran-america-must-take-a-hard-line-stance-against-the-regime](https://www.dailywire.com/news/for-freedom-to-prevail-in-iran-america-must-take-a-hard-line-stance-against-the-regime)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 14:23:07+00:00

Over 40 years after the 1979 Iranian Revolution, which led to the taking of U.S. hostages, relations between the U.S. and Iran are as tense as ever. Iran’s advancement of its nuclear program and support for terrorist groups has frayed the relationship between the two countries, and Iran officials’ recent violence against demonstrators has stretched ...

## Federal Reserve Hikes Interest Rates Three-Quarters Of A Point, Markets Spike As Officials Hint At New Approach
 - [https://www.dailywire.com/news/federal-reserve-hikes-interest-rates-three-quarters-of-a-point](https://www.dailywire.com/news/federal-reserve-hikes-interest-rates-three-quarters-of-a-point)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 14:09:04+00:00

The Federal Reserve raised their target federal funds rate by three-quarters of a percentage point, with markets spiking as officials hinted that they could slow down the pace at which they tighten monetary policy. The move comes after the central bank raised target rates in June, July, and September, meaning that the current federal funds ...

## Crying Fowl: Government Warns Of Turkey Shortage Ahead Of Thanksgiving
 - [https://www.dailywire.com/news/crying-fowl-government-warns-of-turkey-shortage-ahead-of-thanksgiving](https://www.dailywire.com/news/crying-fowl-government-warns-of-turkey-shortage-ahead-of-thanksgiving)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 13:58:55+00:00

America is heading for a turkey shortage and elevated poultry prices as families prepare to gobble up the popular bird this Thanksgiving. The price per pound for an eight-pound hen has increased from $1.15 last year to $1.47 this year, according to data from the Department of Agriculture, with residents of the northeastern United States ...

## ‘Badly Done Bette’: Bette Midler Gets Slammed After Promoting Fake News With Kari Lake Parody Website
 - [https://www.dailywire.com/news/badly-done-bette-bette-midler-gets-slammed-after-promoting-fake-news-with-kari-lake-parody-website](https://www.dailywire.com/news/badly-done-bette-bette-midler-gets-slammed-after-promoting-fake-news-with-kari-lake-parody-website)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 13:50:05+00:00

Bette Midler was slammed on Wednesday after she promoted fake news about Republican Arizona gubernatorial candidate Kari Lake from a parody website. The 76-year-old actress shared a screenshot from the &#8220;About Me&#8221; section of the satire site mocking Lake, describing her as embracing &#8220;far-right nationalism and the forceful suppression of any opposition.&#8221; The page went ...

## ‘Very Dangerous For Our Country’: Officer Sicknick’s Mother Blames ‘People Like’ Kari Lake For Her Son’s Death In New Ad
 - [https://www.dailywire.com/news/very-dangerous-for-our-country-officer-sicknicks-mother-blames-people-like-kari-lake-for-her-sons-death-in-new-ad](https://www.dailywire.com/news/very-dangerous-for-our-country-officer-sicknicks-mother-blames-people-like-kari-lake-for-her-sons-death-in-new-ad)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 13:39:42+00:00

Gladys Sicknick, mother of the late Capitol Police Officer Brian Sicknick, claimed in a new ad that her son had died because of &#8220;people like&#8221; Republican Arizona gubernatorial candidate Kari Lake. The Republican Accountability Project, chaired by Bill Kristol and formerly known as Republican Voters Against Trump, shared the ad on Tuesday with the caption, ...

## Obama Rails About ‘Dangerous’ Political Climate While Biden Demonizes Republicans
 - [https://www.dailywire.com/news/obama-rails-about-dangerous-political-climate-while-biden-demonizes-republicans](https://www.dailywire.com/news/obama-rails-about-dangerous-political-climate-while-biden-demonizes-republicans)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 13:24:56+00:00

President Joe Biden is so unpopular that candidates in the 2022 midterm elections don&#8217;t want him anywhere near them. So former President Barack Obama had to come out of retirement to try to help floundering Democrats. Last weekend he swooped into Michigan to endorse Democratic Gov. Gretchen Whitmer at a campaign rally in Detroit. There, ...

## SCOTUS Hinting It Might Throw Out Affirmative Action Used In College Admissions
 - [https://www.dailywire.com/news/scotus-hinting-it-might-throw-out-affirmative-action-used-in-college-admissions](https://www.dailywire.com/news/scotus-hinting-it-might-throw-out-affirmative-action-used-in-college-admissions)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 13:04:01+00:00

The Supreme Court is in the midst of hearing two cases which could enable them to roll back affirmative action colleges and universities use for admissions. Students for Fair Admissions Inc. v. President &amp; Fellows of Harvard College and Students for Fair Admissions, Inc. v. University of North Carolina both ask the Supreme Court to ...

## Study: Excessive Alcohol Use Causes 20% Of Deaths In U.S. Adults Ages 20 To 49
 - [https://www.dailywire.com/news/study-excessive-alcohol-use-causes-20-of-deaths-in-u-s-adults-ages-20-to-49](https://www.dailywire.com/news/study-excessive-alcohol-use-causes-20-of-deaths-in-u-s-adults-ages-20-to-49)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 12:59:40+00:00

A new study revealed the role excessive alcohol plays in deaths in the United States. “I’m not surprised at the numbers,” David Jernigan, a professor of health law, policy and management at Boston University, told CNN. “This is a conservative estimate.” According to the study published Tuesday in JAMA Network Open, an estimated 1 in ...

## Teenagers Allegedly Killed Spanish Teacher Over Bad Grade, Prosecutors Say
 - [https://www.dailywire.com/news/teenagers-allegedly-killed-spanish-teacher-over-bad-grade-prosecutors-say](https://www.dailywire.com/news/teenagers-allegedly-killed-spanish-teacher-over-bad-grade-prosecutors-say)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 12:50:28+00:00

Two teenagers from Iowa stand accused of killing their Spanish teacher last year after she gave one of the teens a bad grade. Prosecutors allege that Willard Miller and Jeremy Goodale, who were both 16 at the time of the murder, followed Fairfield High School Spanish teacher Nohema Graber to a park where she was ...

## Bibi’s Back! Israel’s Election Results Project Huge Comeback For The Right
 - [https://www.dailywire.com/news/bibis-back-israels-election-results-project-huge-comeback-for-the-right](https://www.dailywire.com/news/bibis-back-israels-election-results-project-huge-comeback-for-the-right)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 12:29:53+00:00

With 86% of the votes counted in Israel&#8217;s 25th Knesset election, the right-wing bloc led by Benjamin Netanyahu&#8217;s Likud Party leads with a projected 65-seat majority. As a result, Netanyahu is poised to return to the prime ministership after a brief year in opposition. Netanyahu was Israel&#8217;s ninth prime minister from 1996 to 1999 and ...

## Kansas Woman Who Led All-Female ISIS Battalion Gets 20 Years In Prison
 - [https://www.dailywire.com/news/kansas-woman-who-led-all-female-isis-battalion-gets-20-years-in-prison](https://www.dailywire.com/news/kansas-woman-who-led-all-female-isis-battalion-gets-20-years-in-prison)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 12:27:50+00:00

A Kansas woman who led an all-female ISIS battalion in Syria was sentenced Tuesday to 20 years in prison. Allison Fluke-Ekren, 42, received the sentence in a federal courtroom in Alexandria, Virginia, after pleading guilty to conspiring to provide material support or resources to a foreign terrorist organization. &#8220;I deeply regret my choices, but I ...

## ‘An Act Of Faith’: Why Marriage Is Far Better Than The Short-Term, Hedonistic Pleasures Of The Single Life
 - [https://www.dailywire.com/news/an-act-of-faith-why-marriage-is-far-better-than-the-short-term-hedonistic-pleasures-of-the-single-life](https://www.dailywire.com/news/an-act-of-faith-why-marriage-is-far-better-than-the-short-term-hedonistic-pleasures-of-the-single-life)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 12:26:24+00:00

The following is a collection of excerpts from Dr. Jordan Peterson’s new series about marriage. You can watch the special on DailyWire+. My clinical experience, I would say, and my life experience, taught me that you could divide your life, in some sense, into thirds. One third of that is intimate relationship. We’ll say marriage. ...

## ‘An Act Of Faith’: Why Marriage Is Far Better Than The Single Life
 - [https://www.dailywire.com/news/an-act-of-faith-why-marriage-is-far-better-than-the-single-life](https://www.dailywire.com/news/an-act-of-faith-why-marriage-is-far-better-than-the-single-life)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 12:26:24+00:00

The following is a collection of excerpts from Dr. Jordan Peterson’s new series about marriage. You can watch the special on DailyWire+. My clinical experience, I would say, and my life experience, taught me that you could divide your life, in some sense, into thirds. One third of that is intimate relationship. We’ll say marriage. ...

## Storied NFL Franchise Goes On Block, Could Fetch $5B Or More
 - [https://www.dailywire.com/news/storied-nfl-franchise-goes-on-block-could-fetch-5b-or-more](https://www.dailywire.com/news/storied-nfl-franchise-goes-on-block-could-fetch-5b-or-more)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 12:15:10+00:00

The NFL’s Washington Commanders are on the block, and the sale price for one of the league’s most storied franchises could approach $5 billion. Embattled owner Dan Snyder, who bought the team in 1999 when it was known as the Washington Redskins, has hired Bank of America to find a buyer and facilitate a deal, ...

## Bill Maher Complains Trump Is A ‘Whiny Little B****.’ Kid Rock Cracks Up Maher With Retort
 - [https://www.dailywire.com/news/bill-maher-complains-trump-is-a-whiny-little-b-kid-rock-cracks-up-maher-with-retort](https://www.dailywire.com/news/bill-maher-complains-trump-is-a-whiny-little-b-kid-rock-cracks-up-maher-with-retort)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 12:13:50+00:00

Bill Maher couldn&#8217;t help but crack up when Kid Rock hit him with a quick retort after Maher complained about former President Donald Trump. During an episode of the “Club Random with Bill Maher” podcast on Sunday, Maher told Kid Rock, &#8220;I will never understand why you like this whiny little b****. You know, you&#8217;re such ...

## Holiday Travel At Risk: United Airlines Pilots Reject Tentative Contract Offer
 - [https://www.dailywire.com/news/holiday-travel-at-risk-united-airlines-pilots-reject-tentative-contract-offer](https://www.dailywire.com/news/holiday-travel-at-risk-united-airlines-pilots-reject-tentative-contract-offer)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 12:12:58+00:00

On Tuesday, United Airlines pilots rejected a contract offer, intensifying  fears that upcoming holiday airline travel may be impeded in a major way. That followed a vote on Monday by Delta Airlines pilots to call a strike for a new contract. The United pilots were represented by the Air Line Pilots Association, International (ALPA), which ...

## Man Pretended To Be Stanford Student, Lived On Campus For Nearly A Year
 - [https://www.dailywire.com/news/man-pretended-to-be-stanford-student-lived-on-campus-for-nearly-a-year](https://www.dailywire.com/news/man-pretended-to-be-stanford-student-lived-on-campus-for-nearly-a-year)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 12:09:41+00:00

A man posing as a student lived on Stanford University&#8217;s Palo Alto, California, campus for nearly a year, according to a new report. William Curry, who graduated from Vestavia Hills High School in Birmingham, Alabama, in 2021, was removed from campus on Thursday after allegedly attempting to take a television from a residence hall after ...

## White House Announces Days Before Midterms That Biden Admin Will Help Pay Certain People’s Power Bills
 - [https://www.dailywire.com/news/white-house-announces-days-before-midterms-that-biden-admin-will-help-pay-certain-peoples-power-bills](https://www.dailywire.com/news/white-house-announces-days-before-midterms-that-biden-admin-will-help-pay-certain-peoples-power-bills)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 12:06:59+00:00

The Biden administration announced on Wednesday, six days before the upcoming midterm elections, that the federal government would help pay power bills for qualifying low- and moderate-income households. The administration will provide $4.5 billion through the Department of Health and Human Services to “help lower heating costs for American families this winter,” according to a ...

## COVID Lockdown Tyrants Want Us To Forget, Grant ‘Pandemic Amnesty.’ Matt Walsh Has Some Thoughts.
 - [https://www.dailywire.com/news/covid-lockdown-tyrants-want-us-to-forget-grant-pandemic-amnesty-matt-walsh-has-some-thoughts](https://www.dailywire.com/news/covid-lockdown-tyrants-want-us-to-forget-grant-pandemic-amnesty-matt-walsh-has-some-thoughts)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 11:56:28+00:00

Daily Wire host and author Matt Walsh ripped into COVID lockdown tyrants after a columnist on Monday begged for “pandemic amnesty.&#8221; Brown University economist Emily Oster, writing at The Atlantic, admitted that aspects of school closures and other government mandates were ultimately unnecessary, while asserting that &#8220;we need to forgive one another for what we did and ...

## ‘Whipped Me With A Belt’: ‘Dancing With The Stars’ Pro Accuses Ex Of Physical Abuse
 - [https://www.dailywire.com/news/whipped-me-with-a-belt-dancing-with-the-stars-pro-accuses-ex-of-physical-abuse](https://www.dailywire.com/news/whipped-me-with-a-belt-dancing-with-the-stars-pro-accuses-ex-of-physical-abuse)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 11:38:01+00:00

“Dancing With the Stars” pro Cheryl Burke recently made accusations of abuse against her high school ex-boyfriend, claiming he subjected her to physical assault even while his parents were present. The 38-year-old professional dancer spoke about the alleged incidents during an episode of Jada Pinkett Smith’s “Red Table Talk.” Burke said she was visibly bruised ...

## ‘Honestly Yikes’: Billie Eilish Fans React To Baby Costume She Wore With Older Boyfriend
 - [https://www.dailywire.com/news/honestly-yikes-billie-eilish-fans-react-to-baby-costume-she-wore-with-older-boyfriend](https://www.dailywire.com/news/honestly-yikes-billie-eilish-fans-react-to-baby-costume-she-wore-with-older-boyfriend)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 11:24:04+00:00

Billie Eilish fans are a little weirded out by a recent photo she posted of herself dressed as a baby for Halloween, especially since she was posing with her older boyfriend who’s wearing an old man costume. The 20-year-old singer is in a relationship with 31-year-old Jesse Rutherford. The Instagram post seems to indicate that ...

## Famed Food Blogger Julie Powell Of ‘Julie And Julia’ Dies Of Cardiac Arrest At 49
 - [https://www.dailywire.com/news/famed-food-blogger-julie-powell-of-julie-and-julia-dies-of-cardiac-arrest-at-49](https://www.dailywire.com/news/famed-food-blogger-julie-powell-of-julie-and-julia-dies-of-cardiac-arrest-at-49)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 11:10:14+00:00

Julie Powell, who became famous for cooking every recipe in famed cook Julia Child’s “Mastering the Art of French Cooking,” prompting a major movie to be made about her, died of cardiac arrest at the age of 49. Julie Powell’s story was told in the film “Julie &amp; Julia,” starring Meryl Streep as Julia Child ...

## Liz Cheney Backs Another Democrat, Says She ‘Would Not Vote’ For Ohio’s J.D. Vance Over Tim Ryan
 - [https://www.dailywire.com/news/liz-cheney-backs-another-democrat-says-she-would-not-vote-for-ohios-j-d-vance-over-tim-ryan](https://www.dailywire.com/news/liz-cheney-backs-another-democrat-says-she-would-not-vote-for-ohios-j-d-vance-over-tim-ryan)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 11:00:52+00:00

Rep. Liz Cheney (R-WY) backed another Democratic candidate on Tuesday, telling a journalist in Ohio that she would not vote for GOP Senate candidate J.D. Vance. Cheney shared the comment during a conversation with journalist Judy Woodruff in Cleveland, Ohio, on Tuesday. “I would not vote for J.D. Vance,” Cheney said. When asked if she ...

## Mutilation Mandate: Why Proposed Biden Rule Will Require Hospitals To Offer ‘Gender Affirming Care’
 - [https://www.dailywire.com/news/mutilation-mandate-why-proposed-biden-rule-will-require-hospitals-to-offer-gender-affirming-care](https://www.dailywire.com/news/mutilation-mandate-why-proposed-biden-rule-will-require-hospitals-to-offer-gender-affirming-care)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 10:51:31+00:00

Conservatives have long avoided heated dinner conversations by demurring, “I’m socially liberal but fiscally conservative.” Translation: I have a diverse array of friends and enjoy low taxes. While unobjectionable in theory, this attitude has enabled something nefarious. The federal government has turned our desire to “live and let live” into an invitation to incentivize harmful ...

## ‘All Glory To God’: Canadian Pastor Jailed For Opening His Church During Lockdowns Acquitted By Top Court
 - [https://www.dailywire.com/news/all-glory-to-god-canadian-pastor-jailed-for-opening-his-church-during-lockdowns-acquitted-by-top-court](https://www.dailywire.com/news/all-glory-to-god-canadian-pastor-jailed-for-opening-his-church-during-lockdowns-acquitted-by-top-court)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 10:44:08+00:00

Pastor Tim Stephens of Fairview Baptist Church in Alberta, Canada, was acquitted by the province’s criminal court after he was charged with breaches of public health orders for opening his church despite government lockdowns. Footage of police officers taking Stephens away from his sobbing children went viral last summer as Canadian authorities made headlines for ...

## NBA Great’s Ex Begs Court To Block Their Trans Kid’s Gender Change, Says Dad ‘Positioned To Profit’
 - [https://www.dailywire.com/news/nba-greats-ex-begs-court-to-block-their-trans-kids-gender-change-says-dad-positioned-to-profit](https://www.dailywire.com/news/nba-greats-ex-begs-court-to-block-their-trans-kids-gender-change-says-dad-positioned-to-profit)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 10:31:08+00:00

The ex-wife of former NBA superstar Dwyane Wade is asking a judge to stop their 15-year-old biological son from a gender transition, and accusing the future Hall of Famer of exploiting the child, according to a report. Legal documents obtained by The Blast show Siohvaughn Funches-Wade is seeking to block her 15-year-old child Zaya, previously known ...

## CVS, Walmart, Walgreens Agree To $13.8 Billion Opioid Settlement: Report
 - [https://www.dailywire.com/news/cvs-walmart-walgreens-agree-to-13-8-billion-opioid-settlement-report](https://www.dailywire.com/news/cvs-walmart-walgreens-agree-to-13-8-billion-opioid-settlement-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 10:08:26+00:00

CVS, Walmart, and Walgreens have agreed to a $13.8 billion opioid settlement to resolve thousands of nationwide lawsuits, according to a new report. CVS will pay $5 billion over 10 years, Walgreens $5.7 billion over 15 years, and Walmart $3.1 billion, according to Reuters. &#8220;We know that reckless, profit-driven dispensing practices fueled the crisis; but ...

## Top Levi’s Exec Ousted Over Anti-Lockdown Speech Rips The ‘Left’s Betrayal’
 - [https://www.dailywire.com/news/top-levis-exec-ousted-over-anti-lockdown-speech-rips-the-lefts-betrayal](https://www.dailywire.com/news/top-levis-exec-ousted-over-anti-lockdown-speech-rips-the-lefts-betrayal)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 09:38:22+00:00

Ousted Levi&#8217;s executive Jennifer Sey ripped the &#8220;Left&#8217;s betrayal&#8221; of their ostensible values as &#8220;shocking and upsetting.&#8221; After more than 20 years at Levi Strauss &amp; Co., the well-liked liberal executive was on track to become CEO of the multi-billion-dollar corporation &#8212; but her refusal to shut up about COVID madness, specifically the policies of ...

## Anti-Woke YouTube Competitor Rumble Tells France Au Revoir Over Censorship Demands
 - [https://www.dailywire.com/news/anti-woke-youtube-competitor-rumble-tells-france-au-revoir-over-censorship-demands](https://www.dailywire.com/news/anti-woke-youtube-competitor-rumble-tells-france-au-revoir-over-censorship-demands)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 09:21:52+00:00

U.S. and Canada-based video platform Rumble is shutting down in France after refusing the European nation&#8217;s demand that it block pro-Russian news sources, according to its CEO. Rumble, founded in 2013 as a free-speech alternative to YouTube, where conservatives often find themselves censored, said it would rather not operate in France than submit to the ...

## Why The Legacy Media Is Panicked About Elon Musk’s Twitter Takeover
 - [https://www.dailywire.com/news/why-the-legacy-media-is-panicked-about-elon-musks-twitter-takeover](https://www.dailywire.com/news/why-the-legacy-media-is-panicked-about-elon-musks-twitter-takeover)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 08:08:02+00:00

It has now been a week since Elon Musk took over Twitter, and the wailing and gnashing of teeth is still audible across the legacy media landscape. In one sense, that’s rather shocking: why, precisely, should members of the media be so apoplectic about a billionaire taking over a social media company from other millionaires, ...

## Top Russian Military Leaders Discuss Options For Using Nuclear Weapons In Ukraine: Report
 - [https://www.dailywire.com/news/top-russian-military-leaders-discuss-options-for-using-nuclear-weapons-in-ukraine-report](https://www.dailywire.com/news/top-russian-military-leaders-discuss-options-for-using-nuclear-weapons-in-ukraine-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 07:43:08+00:00

Top Russian military officials have reportedly discussed in recent days when and how to use tactical nuclear weapons against Ukraine, should the Kremlin give the order to do so. The New York Times reported that Russian President Vladimir Putin was not part of the discussions, according to multiple senior U.S. officials. The report said that ...

## Feds Look Into Opening Investigation Into Musk Over Ties To Foreign Governments: Report
 - [https://www.dailywire.com/news/feds-look-into-opening-investigation-into-musk-over-ties-to-foreign-governments-report](https://www.dailywire.com/news/feds-look-into-opening-investigation-into-musk-over-ties-to-foreign-governments-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 07:31:31+00:00

U.S. Treasury Department officials are reportedly looking at whether they have the legal authority to investigate Elon Musk&#8217;s recent purchase of Twitter due to his close ties to foreign governments and investors, which includes entities that are hostile to the United States. The Washington Post reported that officials are concerned because &#8220;large foreign investors would ...

## Dr. Phil On John Fetterman’s Fitness For Office: ‘Hell No’ You Wouldn’t Get On A Plane If He Was Pilot
 - [https://www.dailywire.com/news/dr-phil-on-john-fettermans-fitness-for-office-hell-no-you-wouldnt-get-on-a-plane-if-he-was-pilot](https://www.dailywire.com/news/dr-phil-on-john-fettermans-fitness-for-office-hell-no-you-wouldnt-get-on-a-plane-if-he-was-pilot)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-02 07:20:16+00:00

Celebrity psychologist Dr. Phil McGraw told Joe Rogan, host of &#8220;The Joe Rogan Experience,&#8221; during a recent episode that it was clear that there was something wrong with Pennsylvania Democrat U.S. Senate candidate John Fetterman. The remarks by McGraw come after Fetterman debated last week against Republican challenger Dr. Mehmet Oz, and the overwhelming reaction ...


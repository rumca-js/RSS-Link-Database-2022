# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Israel's Far-Right Kingmakers Draw on U.S. Funding — Despite Terror Classifications
 - [https://theintercept.com/2022/11/02/israel-us-funding-terror/](https://theintercept.com/2022/11/02/israel-us-funding-terror/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2022-11-02 20:02:45+00:00

<p>Even as some in D.C. have expressed concern about the figures in Benjamin Netanyahu’s coalition, little is done about the tax-exempt U.S. supporters of Israel’s far right.</p>
<p>The post <a href="https://theintercept.com/2022/11/02/israel-us-funding-terror/" rel="nofollow">Israel&#8217;s Far-Right Kingmakers Draw on U.S. Funding — Despite Terror Classifications</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## Nobel Laureates Press Egypt to Free Alaa Abd El Fattah, Writer on Hunger Strike, Before COP27
 - [https://theintercept.com/2022/11/02/nobel-laureates-press-egypt-free-alaa-abd-el-fattah-writer-hunger-strike-cop27/](https://theintercept.com/2022/11/02/nobel-laureates-press-egypt-free-alaa-abd-el-fattah-writer-hunger-strike-cop27/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2022-11-02 13:08:46+00:00

<p>Nobel winners have urged world leaders to use their remarks at the COP27 climate conference in Egypt to press for the release of political prisoners, including Alaa Abd El Fattah.</p>
<p>The post <a href="https://theintercept.com/2022/11/02/nobel-laureates-press-egypt-free-alaa-abd-el-fattah-writer-hunger-strike-cop27/" rel="nofollow">Nobel Laureates Press Egypt to Free Alaa Abd El Fattah, Writer on Hunger Strike, Before COP27</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## The Fed's War on Workers
 - [https://theintercept.com/2022/11/02/intercepted-federal-reserve-fed/](https://theintercept.com/2022/11/02/intercepted-federal-reserve-fed/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2022-11-02 10:01:49+00:00

<p>How the Federal Reserve is undermining workers’ recent modest gains.</p>
<p>The post <a href="https://theintercept.com/2022/11/02/intercepted-federal-reserve-fed/" rel="nofollow">The Fed&#8217;s War on Workers</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>


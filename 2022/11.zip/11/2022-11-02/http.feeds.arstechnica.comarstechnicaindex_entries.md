# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## After nearly 50 years, FBI identifies “Lady of the Dunes” murder victim
 - [https://arstechnica.com/?p=1894476](https://arstechnica.com/?p=1894476)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-02 22:09:09+00:00

Tennessee native Ruth Marie Terry was 37 years old at the time of her 1974 murder.

## New Mac app wants to record everything you do—so you can “rewind” it later
 - [https://arstechnica.com/?p=1894475](https://arstechnica.com/?p=1894475)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-02 21:33:00+00:00

Find "anything you've seen, said, or heard" using 3,750x compression.

## Google Play Games beta now on Windows desktops, if that’s your thing
 - [https://arstechnica.com/?p=1894589](https://arstechnica.com/?p=1894589)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-02 21:02:00+00:00

Try some of Android's quirky games with mice, keyboards, and bigger screens.

## Intel’s oft-delayed “Sapphire Rapids” Xeon CPUs are finally coming in early 2023
 - [https://arstechnica.com/?p=1894557](https://arstechnica.com/?p=1894557)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-02 20:43:33+00:00

CPUs have been trickling out of Intel, but still waiting for volume shipments.

## Why Pfizer’s RSV vaccine success is a big deal, decades in the making
 - [https://arstechnica.com/?p=1894603](https://arstechnica.com/?p=1894603)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-02 20:27:28+00:00

Research on RSV vaccines dragged after a trial in the 60s went tragically wrong.

## Today’s best deals: Black Friday month begins with 4K TVs, iPads, and much more
 - [https://arstechnica.com/?p=1894447](https://arstechnica.com/?p=1894447)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-02 20:17:39+00:00

Dealmaster also has gaming mice, smart home devices, MacBooks, and Roomba robot vacuums.

## Nudity comes back to Tumblr, but sexually explicit images still banned
 - [https://arstechnica.com/?p=1894598](https://arstechnica.com/?p=1894598)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-02 19:57:30+00:00

Users can now label sexy posts as "mature" or having "sexual themes."

## Avatar: The Way of Water trailer brings us closer to a mighty heartbeat
 - [https://arstechnica.com/?p=1894518](https://arstechnica.com/?p=1894518)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-02 17:17:51+00:00

"We cannot let you bring your war here."

## No room for another monitor? Use your desktop’s side panel instead
 - [https://arstechnica.com/?p=1894483](https://arstechnica.com/?p=1894483)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-02 17:06:23+00:00

An intriguing idea, but Embedded DisplayPort limits compatibility.

## Dwarf Fortress on Steam gets release date, trailer, and graphics beyond ASCII
 - [https://arstechnica.com/?p=1894474](https://arstechnica.com/?p=1894474)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-02 16:09:59+00:00

Early next month, you can experience sublime subterranean chaos—with sprites.

## Musk meets with critics, says Twitter won’t restore banned users before election
 - [https://arstechnica.com/?p=1894504](https://arstechnica.com/?p=1894504)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-02 16:03:53+00:00

Musk: Twitter will consult civil rights groups before restoring any banned users.

## $550 PlayStation VR2 launches on Feb. 22, 2023
 - [https://arstechnica.com/?p=1894491](https://arstechnica.com/?p=1894491)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-02 15:03:40+00:00

Six games available for preorder alongside headset on Nov. 15.

## SpaceX is now building a Raptor engine a day, NASA says
 - [https://arstechnica.com/?p=1893966](https://arstechnica.com/?p=1893966)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-02 14:11:57+00:00

"This, by the way, is very high on their top risk list."

## US senator seeks antitrust review of apartment price-setting software
 - [https://arstechnica.com/?p=1894459](https://arstechnica.com/?p=1894459)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-02 13:33:56+00:00

Senate committee chair wants FTC to examine software sold by Texas-based RealPage.

## Honda aims for a solid-state-powered EV by the end of the decade
 - [https://arstechnica.com/?p=1894430](https://arstechnica.com/?p=1894430)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-02 13:00:33+00:00

The automaker is battling the dendrite problem with a polymer fiber coating.

## Video games invade the art world in MoMA’s Never Alone exhibition
 - [https://arstechnica.com/?p=1891639](https://arstechnica.com/?p=1891639)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-02 11:30:24+00:00

Are games art? Who cares. Exhibit is more interested in how they bring us together.


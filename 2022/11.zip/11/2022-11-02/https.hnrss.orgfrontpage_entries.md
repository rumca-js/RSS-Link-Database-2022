# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Apple now valued at more than Amazon, Alphabet and Meta combined
 - [https://www.marketwatch.com/story/apple-now-valued-at-more-than-amazon-alphabet-and-meta-combined-11667430617](https://www.marketwatch.com/story/apple-now-valued-at-more-than-amazon-alphabet-and-meta-combined-11667430617)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 23:25:45+00:00

<p>Article URL: <a href="https://www.marketwatch.com/story/apple-now-valued-at-more-than-amazon-alphabet-and-meta-combined-11667430617">https://www.marketwatch.com/story/apple-now-valued-at-more-than-amazon-alphabet-and-meta-combined-11667430617</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33444266">https://news.ycombinator.com/item?id=33444266</a></p>
<p>Points: 37</p>
<p># Comments: 19</p>

## American society is so focused on race that it is blind to class
 - [https://www.economist.com/leaders/2022/11/02/american-society-is-so-focused-on-race-that-it-is-blind-to-class](https://www.economist.com/leaders/2022/11/02/american-society-is-so-focused-on-race-that-it-is-blind-to-class)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 23:09:02+00:00

<p>Article URL: <a href="https://www.economist.com/leaders/2022/11/02/american-society-is-so-focused-on-race-that-it-is-blind-to-class">https://www.economist.com/leaders/2022/11/02/american-society-is-so-focused-on-race-that-it-is-blind-to-class</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33444137">https://news.ycombinator.com/item?id=33444137</a></p>
<p>Points: 129</p>
<p># Comments: 69</p>

## Next C compiler is a D compiler: Introducing DMD's ImportC
 - [https://briancallahan.net/blog/20220704.html](https://briancallahan.net/blog/20220704.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 22:10:29+00:00

<p>Article URL: <a href="https://briancallahan.net/blog/20220704.html">https://briancallahan.net/blog/20220704.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33443615">https://news.ycombinator.com/item?id=33443615</a></p>
<p>Points: 11</p>
<p># Comments: 3</p>

## Vast and innumerable throngs of the ancient dead
 - [https://www.laphamsquarterly.org/roundtable/vast-and-innumerable-throngs-ancient-dead](https://www.laphamsquarterly.org/roundtable/vast-and-innumerable-throngs-ancient-dead)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 21:32:28+00:00

<p>Article URL: <a href="https://www.laphamsquarterly.org/roundtable/vast-and-innumerable-throngs-ancient-dead">https://www.laphamsquarterly.org/roundtable/vast-and-innumerable-throngs-ancient-dead</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33443199">https://news.ycombinator.com/item?id=33443199</a></p>
<p>Points: 14</p>
<p># Comments: 1</p>

## Wine 7.2 Released
 - [https://www.winehq.org/announce/7.20](https://www.winehq.org/announce/7.20)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 21:17:26+00:00

<p>Article URL: <a href="https://www.winehq.org/announce/7.20">https://www.winehq.org/announce/7.20</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33443035">https://news.ycombinator.com/item?id=33443035</a></p>
<p>Points: 30</p>
<p># Comments: 1</p>

## Meta will own 13% of global submarine cables by 2024
 - [https://fairinternetreport.com/research/facebook-meta-submarine-cable-ownership](https://fairinternetreport.com/research/facebook-meta-submarine-cable-ownership)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 21:02:09+00:00

<p>Article URL: <a href="https://fairinternetreport.com/research/facebook-meta-submarine-cable-ownership">https://fairinternetreport.com/research/facebook-meta-submarine-cable-ownership</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33442875">https://news.ycombinator.com/item?id=33442875</a></p>
<p>Points: 37</p>
<p># Comments: 1</p>

## Braess's Paradox
 - [https://resources.mpi-inf.mpg.de/departments/d1/teaching/ws12/ct/Braess-paradox.pdf](https://resources.mpi-inf.mpg.de/departments/d1/teaching/ws12/ct/Braess-paradox.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 20:21:25+00:00

<p>Article URL: <a href="https://resources.mpi-inf.mpg.de/departments/d1/teaching/ws12/ct/Braess-paradox.pdf">https://resources.mpi-inf.mpg.de/departments/d1/teaching/ws12/ct/Braess-paradox.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33442415">https://news.ycombinator.com/item?id=33442415</a></p>
<p>Points: 8</p>
<p># Comments: 5</p>

## The case for JPEG XL
 - [https://cloudinary.com/blog/the-case-for-jpeg-xl](https://cloudinary.com/blog/the-case-for-jpeg-xl)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 20:11:19+00:00

<p>Article URL: <a href="https://cloudinary.com/blog/the-case-for-jpeg-xl">https://cloudinary.com/blog/the-case-for-jpeg-xl</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33442281">https://news.ycombinator.com/item?id=33442281</a></p>
<p>Points: 32</p>
<p># Comments: 1</p>

## Cree releases LEDs designed for horticulture
 - [https://cree-led.com/news/photophyll-select/](https://cree-led.com/news/photophyll-select/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 20:08:11+00:00

<p>Article URL: <a href="https://cree-led.com/news/photophyll-select/">https://cree-led.com/news/photophyll-select/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33442235">https://news.ycombinator.com/item?id=33442235</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Employee gift ideas that make people feel bad
 - [https://www.tremendous.com/blog/5-employee-gift-ideas-make-people-feel-bad](https://www.tremendous.com/blog/5-employee-gift-ideas-make-people-feel-bad)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 20:05:57+00:00

<p>Article URL: <a href="https://www.tremendous.com/blog/5-employee-gift-ideas-make-people-feel-bad">https://www.tremendous.com/blog/5-employee-gift-ideas-make-people-feel-bad</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33442195">https://news.ycombinator.com/item?id=33442195</a></p>
<p>Points: 25</p>
<p># Comments: 33</p>

## Tumblr brings mature content back, after 4 years
 - [https://staff.tumblr.com/post/699744158019190784/this-is-not-a-drill-our-new-community-guidelines](https://staff.tumblr.com/post/699744158019190784/this-is-not-a-drill-our-new-community-guidelines)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 20:05:03+00:00

<p>Article URL: <a href="https://staff.tumblr.com/post/699744158019190784/this-is-not-a-drill-our-new-community-guidelines">https://staff.tumblr.com/post/699744158019190784/this-is-not-a-drill-our-new-community-guidelines</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33442183">https://news.ycombinator.com/item?id=33442183</a></p>
<p>Points: 35</p>
<p># Comments: 14</p>

## A court just gutted years of California's housing efforts
 - [https://www.sfchronicle.com/opinion/openforum/article/california-469-stevenson-court-ceqa-housing-17550982.php](https://www.sfchronicle.com/opinion/openforum/article/california-469-stevenson-court-ceqa-housing-17550982.php)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 19:16:35+00:00

<p>Article URL: <a href="https://www.sfchronicle.com/opinion/openforum/article/california-469-stevenson-court-ceqa-housing-17550982.php">https://www.sfchronicle.com/opinion/openforum/article/california-469-stevenson-court-ceqa-housing-17550982.php</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33441442">https://news.ycombinator.com/item?id=33441442</a></p>
<p>Points: 50</p>
<p># Comments: 25</p>

## Why did the OpenSSL punycode vulnerability happen?
 - [https://words.filippo.io/dispatches/openssl-punycode/](https://words.filippo.io/dispatches/openssl-punycode/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 18:06:55+00:00

<p>Article URL: <a href="https://words.filippo.io/dispatches/openssl-punycode/">https://words.filippo.io/dispatches/openssl-punycode/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33440341">https://news.ycombinator.com/item?id=33440341</a></p>
<p>Points: 36</p>
<p># Comments: 21</p>

## Fed increases target rate to 3.75-4.00%
 - [https://www.federalreserve.gov/newsevents/pressreleases/monetary20221102a.htm](https://www.federalreserve.gov/newsevents/pressreleases/monetary20221102a.htm)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 18:00:37+00:00

<p>Article URL: <a href="https://www.federalreserve.gov/newsevents/pressreleases/monetary20221102a.htm">https://www.federalreserve.gov/newsevents/pressreleases/monetary20221102a.htm</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33440252">https://news.ycombinator.com/item?id=33440252</a></p>
<p>Points: 20</p>
<p># Comments: 30</p>

## The TypeScript compiler is now implemented internally with modules
 - [https://github.com/microsoft/TypeScript/pull/51387](https://github.com/microsoft/TypeScript/pull/51387)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 17:49:05+00:00

<p>Article URL: <a href="https://github.com/microsoft/TypeScript/pull/51387">https://github.com/microsoft/TypeScript/pull/51387</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33440030">https://news.ycombinator.com/item?id=33440030</a></p>
<p>Points: 13</p>
<p># Comments: 7</p>

## Crunchy Bridge's Ruby Back End: Sorbet, Tapioca, and Parlour
 - [https://www.crunchydata.com/blog/crunchy-bridges-ruby-backend-sorbet-tapioca-and-parlour-generated-type-stubs](https://www.crunchydata.com/blog/crunchy-bridges-ruby-backend-sorbet-tapioca-and-parlour-generated-type-stubs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 17:47:42+00:00

<p>Article URL: <a href="https://www.crunchydata.com/blog/crunchy-bridges-ruby-backend-sorbet-tapioca-and-parlour-generated-type-stubs">https://www.crunchydata.com/blog/crunchy-bridges-ruby-backend-sorbet-tapioca-and-parlour-generated-type-stubs</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33440005">https://news.ycombinator.com/item?id=33440005</a></p>
<p>Points: 13</p>
<p># Comments: 2</p>

## Doom3do: DOOM for the 3DO
 - [https://github.com/Olde-Skuul/doom3do](https://github.com/Olde-Skuul/doom3do)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 17:44:47+00:00

<p>Article URL: <a href="https://github.com/Olde-Skuul/doom3do">https://github.com/Olde-Skuul/doom3do</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33439947">https://news.ycombinator.com/item?id=33439947</a></p>
<p>Points: 21</p>
<p># Comments: 4</p>

## Grafana Faro: An open source project for front end application observability
 - [https://grafana.com/blog/2022/11/02/introducing-grafana-faro-oss-application-observability/](https://grafana.com/blog/2022/11/02/introducing-grafana-faro-oss-application-observability/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 17:35:33+00:00

<p>Article URL: <a href="https://grafana.com/blog/2022/11/02/introducing-grafana-faro-oss-application-observability/">https://grafana.com/blog/2022/11/02/introducing-grafana-faro-oss-application-observability/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33439799">https://news.ycombinator.com/item?id=33439799</a></p>
<p>Points: 18</p>
<p># Comments: 2</p>

## Coca-Cola increased plastic use ahead of COP27 summit it is sponsoring
 - [https://www.ft.com/content/662d4a0d-e8f5-4cd4-b03f-05b97e13e771](https://www.ft.com/content/662d4a0d-e8f5-4cd4-b03f-05b97e13e771)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 17:23:43+00:00

<p>Article URL: <a href="https://www.ft.com/content/662d4a0d-e8f5-4cd4-b03f-05b97e13e771">https://www.ft.com/content/662d4a0d-e8f5-4cd4-b03f-05b97e13e771</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33439561">https://news.ycombinator.com/item?id=33439561</a></p>
<p>Points: 10</p>
<p># Comments: 2</p>

## Mosh 1.4.0 Released
 - [https://mosh.org/mosh-1.4.0-released.html](https://mosh.org/mosh-1.4.0-released.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 17:22:36+00:00

<p>Article URL: <a href="https://mosh.org/mosh-1.4.0-released.html">https://mosh.org/mosh-1.4.0-released.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33439542">https://news.ycombinator.com/item?id=33439542</a></p>
<p>Points: 68</p>
<p># Comments: 6</p>

## One in Eight U.S. Adult Deaths Involved Too Much Alcohol
 - [https://www.medpagetoday.com/gastroenterology/generalhepatology/101519](https://www.medpagetoday.com/gastroenterology/generalhepatology/101519)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 17:04:40+00:00

<p>Article URL: <a href="https://www.medpagetoday.com/gastroenterology/generalhepatology/101519">https://www.medpagetoday.com/gastroenterology/generalhepatology/101519</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33439221">https://news.ycombinator.com/item?id=33439221</a></p>
<p>Points: 28</p>
<p># Comments: 25</p>

## Show HN: Nudges.fyi – simple, unmissable reminders via phone/text/email
 - [https://nudges.fyi](https://nudges.fyi)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 17:00:12+00:00

<p>I built this app primarily for my wife, who has tried many mainstream todo-list apps (OmniFocus, Things, and Todoist come to mind) over the years with little success. She isn't particularly interested in setting up a productivity system and the administrivia that goes with it. Even having to remember to look at an app once a day was far from ideal for her. This app is an attempt at a solution for anyone that fits this description, with a focus on alerting over organization.<p>Here's how it works: you create a nudge that's set to trigger at a given date and time, and the app phones you, texts you, or emails you (or all three) at the right moment. Nudges can trigger on a schedule, so something like "call me about monthly bills for the next month on the last day of every month" is quite easy to set up. It also works well (sample size 1, admittedly) as a supplement to a more robust GTD system. I use Things for almost everything, but my most important reminders are set up as nudges.<p>I've worked on this on and off for the last month or so and I think it's ready for a Show HN. There's likely some rough edges in there so I wouldn't use it for anything _critical_ just yet (let me know if you see anything that looks buggy!). I cut a lot of scope in order to release an initial version quickly; here's a list of things I'm considering adding to the app in the near future:<p><pre><code>  - Implement something analogous to Pagerduty: create nudges that repeatedly nag you (with something like an escalation policy) until you acknowledge them
  - More notification channels: get nudges on Telegram, WhatsApp, Slack, etc.
  - Families (or teams, possibly) share a namespace and can send nudges to each other
  - Nudges that collect a response: possibly for polls, a daily diary entry, or habit tracker
  - Incoming and outgoing webhooks
  - Snooze a nudge so it re-triggers in X minutes
</code></pre>
I work on distributed systems at my day job and haven't done frontend and CRUD things in a long while now, so building this out was a nice change of pace. If anyone's curious, the app is built with: Next.js (in static HTML mode) and Tailwind for the frontend, Go for the API server and background nudge loop, and SQLite (+Litestream) for persistence.<p>In any case, I'm looking for feedback from the HN community here: is this something you would use?<p>TL;DR: schedule reminders for yourself via phone call, text message, and/or email<p>(PS: the free plan doesn't allow call/SMS nudges because I'm a bit wary of spam, but if you'd like to give this a shot and can't [or don't want to] subscribe to a paid plan at this point, send me an email at tim@nudges.fyi for a 1-month code)</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33439118">https://news.ycombinator.com/item?id=33439118</a></p>
<p>Points: 6</p>
<p># Comments: 2</p>

## A Systems Engineering Primer
 - [https://cohost.org/jamesmunns/post/167078-systems-engineering](https://cohost.org/jamesmunns/post/167078-systems-engineering)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 16:57:31+00:00

<p>Article URL: <a href="https://cohost.org/jamesmunns/post/167078-systems-engineering">https://cohost.org/jamesmunns/post/167078-systems-engineering</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33439052">https://news.ycombinator.com/item?id=33439052</a></p>
<p>Points: 31</p>
<p># Comments: 2</p>

## The Problem with Go
 - [https://vanitynotes.com/posts/20221101-the-real-problem-with-go](https://vanitynotes.com/posts/20221101-the-real-problem-with-go)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 16:56:19+00:00

<p>Article URL: <a href="https://vanitynotes.com/posts/20221101-the-real-problem-with-go">https://vanitynotes.com/posts/20221101-the-real-problem-with-go</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33439021">https://news.ycombinator.com/item?id=33439021</a></p>
<p>Points: 45</p>
<p># Comments: 29</p>

## GitHub availability report: October 2022
 - [https://github.blog/2022-11-02-github-availability-report-october-2022/](https://github.blog/2022-11-02-github-availability-report-october-2022/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 16:41:23+00:00

<p>Article URL: <a href="https://github.blog/2022-11-02-github-availability-report-october-2022/">https://github.blog/2022-11-02-github-availability-report-october-2022/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33438729">https://news.ycombinator.com/item?id=33438729</a></p>
<p>Points: 19</p>
<p># Comments: 5</p>

## Typing the Technical Interview(solving a problem using only Haskell type system)
 - [https://aphyr.com/posts/342-typing-the-technical-interview](https://aphyr.com/posts/342-typing-the-technical-interview)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 16:41:13+00:00

<p>Article URL: <a href="https://aphyr.com/posts/342-typing-the-technical-interview">https://aphyr.com/posts/342-typing-the-technical-interview</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33438726">https://news.ycombinator.com/item?id=33438726</a></p>
<p>Points: 13</p>
<p># Comments: 2</p>

## Dozens of malicious PyPI packages discovered targeting developers
 - [https://blog.phylum.io/phylum-discovers-dozens-more-pypi-packages-attempting-to-deliver-w4sp-stealer-in-ongoing-supply-chain-attack](https://blog.phylum.io/phylum-discovers-dozens-more-pypi-packages-attempting-to-deliver-w4sp-stealer-in-ongoing-supply-chain-attack)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 16:39:15+00:00

<p>Article URL: <a href="https://blog.phylum.io/phylum-discovers-dozens-more-pypi-packages-attempting-to-deliver-w4sp-stealer-in-ongoing-supply-chain-attack">https://blog.phylum.io/phylum-discovers-dozens-more-pypi-packages-attempting-to-deliver-w4sp-stealer-in-ongoing-supply-chain-attack</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33438678">https://news.ycombinator.com/item?id=33438678</a></p>
<p>Points: 67</p>
<p># Comments: 19</p>

## Aegis Authenticator – Secure 2FA App for Android
 - [https://getaegis.app/](https://getaegis.app/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 16:32:06+00:00

<p>Article URL: <a href="https://getaegis.app/">https://getaegis.app/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33438540">https://news.ycombinator.com/item?id=33438540</a></p>
<p>Points: 35</p>
<p># Comments: 17</p>

## First release of LemmyBB, a federated bulletin board written in Rust
 - [https://join-lemmy.org/news/2022-11-02-_First_release_of_LemmyBB](https://join-lemmy.org/news/2022-11-02-_First_release_of_LemmyBB)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 16:29:17+00:00

<p>Article URL: <a href="https://join-lemmy.org/news/2022-11-02-_First_release_of_LemmyBB">https://join-lemmy.org/news/2022-11-02-_First_release_of_LemmyBB</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33438493">https://news.ycombinator.com/item?id=33438493</a></p>
<p>Points: 16</p>
<p># Comments: 0</p>

## Beaming solar energy from space
 - [https://www.caltech.edu/about/news/space-solar-power-atwater-hajimiri-pellegrino](https://www.caltech.edu/about/news/space-solar-power-atwater-hajimiri-pellegrino)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 16:22:19+00:00

<p>Article URL: <a href="https://www.caltech.edu/about/news/space-solar-power-atwater-hajimiri-pellegrino">https://www.caltech.edu/about/news/space-solar-power-atwater-hajimiri-pellegrino</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33438372">https://news.ycombinator.com/item?id=33438372</a></p>
<p>Points: 28</p>
<p># Comments: 25</p>

## NEONnoir is a hybrid point-and-click adventure/visual novel game for the Amiga
 - [https://steamknight.itch.io/neonnoir](https://steamknight.itch.io/neonnoir)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 16:06:37+00:00

<p>Article URL: <a href="https://steamknight.itch.io/neonnoir">https://steamknight.itch.io/neonnoir</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33438092">https://news.ycombinator.com/item?id=33438092</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## Seeking the Productive Life: Some Details of My Personal Infrastructure
 - [https://writings.stephenwolfram.com/2019/02/seeking-the-productive-life-some-details-of-my-personal-infrastructure/](https://writings.stephenwolfram.com/2019/02/seeking-the-productive-life-some-details-of-my-personal-infrastructure/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 15:57:35+00:00

<p>Article URL: <a href="https://writings.stephenwolfram.com/2019/02/seeking-the-productive-life-some-details-of-my-personal-infrastructure/">https://writings.stephenwolfram.com/2019/02/seeking-the-productive-life-some-details-of-my-personal-infrastructure/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33437911">https://news.ycombinator.com/item?id=33437911</a></p>
<p>Points: 30</p>
<p># Comments: 6</p>

## T-Mobile will start charging a $35 fee on all new activations and upgrades
 - [https://www.engadget.com/t-mobile-will-start-charging-a-35-fee-on-all-new-activations-and-upgrades-065518011.html](https://www.engadget.com/t-mobile-will-start-charging-a-35-fee-on-all-new-activations-and-upgrades-065518011.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 15:50:52+00:00

<p>Article URL: <a href="https://www.engadget.com/t-mobile-will-start-charging-a-35-fee-on-all-new-activations-and-upgrades-065518011.html">https://www.engadget.com/t-mobile-will-start-charging-a-35-fee-on-all-new-activations-and-upgrades-065518011.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33437791">https://news.ycombinator.com/item?id=33437791</a></p>
<p>Points: 87</p>
<p># Comments: 97</p>

## Grafana Phlare, open source database for continuous profiling at scale
 - [https://grafana.com/blog/2022/11/02/announcing-grafana-phlare-oss-continuous-profiling-database/](https://grafana.com/blog/2022/11/02/announcing-grafana-phlare-oss-continuous-profiling-database/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 15:28:26+00:00

<p>Article URL: <a href="https://grafana.com/blog/2022/11/02/announcing-grafana-phlare-oss-continuous-profiling-database/">https://grafana.com/blog/2022/11/02/announcing-grafana-phlare-oss-continuous-profiling-database/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33437419">https://news.ycombinator.com/item?id=33437419</a></p>
<p>Points: 55</p>
<p># Comments: 1</p>

## U.S. pushes Japan and other allies to join China chip curbs
 - [https://asia.nikkei.com/Politics/International-relations/U.S.-pushes-Japan-and-other-allies-to-join-China-chip-curbs](https://asia.nikkei.com/Politics/International-relations/U.S.-pushes-Japan-and-other-allies-to-join-China-chip-curbs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 15:24:48+00:00

<p>Article URL: <a href="https://asia.nikkei.com/Politics/International-relations/U.S.-pushes-Japan-and-other-allies-to-join-China-chip-curbs">https://asia.nikkei.com/Politics/International-relations/U.S.-pushes-Japan-and-other-allies-to-join-China-chip-curbs</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33437358">https://news.ycombinator.com/item?id=33437358</a></p>
<p>Points: 35</p>
<p># Comments: 5</p>

## An AI generated, never-ending discussion between Werner Herzog and Slavoj ŽIžek
 - [https://infiniteconversation.com/](https://infiniteconversation.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 15:21:32+00:00

<p>Article URL: <a href="https://infiniteconversation.com/">https://infiniteconversation.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33437296">https://news.ycombinator.com/item?id=33437296</a></p>
<p>Points: 19</p>
<p># Comments: 5</p>

## OpenSSL added new C parser code [...] without doing any basic security testing
 - [https://twitter.com/hanno/status/1587775675397726209](https://twitter.com/hanno/status/1587775675397726209)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 15:13:52+00:00

<p>Article URL: <a href="https://twitter.com/hanno/status/1587775675397726209">https://twitter.com/hanno/status/1587775675397726209</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33437158">https://news.ycombinator.com/item?id=33437158</a></p>
<p>Points: 19</p>
<p># Comments: 1</p>

## The worst drought in 1,200 years
 - [https://www.bbc.com/future/article/20221031-how-tucson-arizona-is-facing-up-to-a-1200-year-drought](https://www.bbc.com/future/article/20221031-how-tucson-arizona-is-facing-up-to-a-1200-year-drought)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 15:06:18+00:00

<p>Article URL: <a href="https://www.bbc.com/future/article/20221031-how-tucson-arizona-is-facing-up-to-a-1200-year-drought">https://www.bbc.com/future/article/20221031-how-tucson-arizona-is-facing-up-to-a-1200-year-drought</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33437020">https://news.ycombinator.com/item?id=33437020</a></p>
<p>Points: 38</p>
<p># Comments: 16</p>

## 'Planet killer' asteroid found hiding in sun's glare may one day hit Earth
 - [https://www.space.com/dangerous-asteroid-discovered-in-sun-glare](https://www.space.com/dangerous-asteroid-discovered-in-sun-glare)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 15:06:00+00:00

<p>Article URL: <a href="https://www.space.com/dangerous-asteroid-discovered-in-sun-glare">https://www.space.com/dangerous-asteroid-discovered-in-sun-glare</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33437012">https://news.ycombinator.com/item?id=33437012</a></p>
<p>Points: 15</p>
<p># Comments: 11</p>

## SpaceX is now building a Raptor engine a day, NASA says
 - [https://arstechnica.com/science/2022/11/spacex-is-now-building-a-raptor-engine-a-day-nasa-says/](https://arstechnica.com/science/2022/11/spacex-is-now-building-a-raptor-engine-a-day-nasa-says/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 15:00:46+00:00

<p>Article URL: <a href="https://arstechnica.com/science/2022/11/spacex-is-now-building-a-raptor-engine-a-day-nasa-says/">https://arstechnica.com/science/2022/11/spacex-is-now-building-a-raptor-engine-a-day-nasa-says/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33436918">https://news.ycombinator.com/item?id=33436918</a></p>
<p>Points: 70</p>
<p># Comments: 39</p>

## The pool of talented C++ developers is running dry
 - [https://www.efinancialcareers.com/news/2022/11/why-is-there-a-drought-in-the-talent-pool-for-c-developers](https://www.efinancialcareers.com/news/2022/11/why-is-there-a-drought-in-the-talent-pool-for-c-developers)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 14:23:05+00:00

<p>Article URL: <a href="https://www.efinancialcareers.com/news/2022/11/why-is-there-a-drought-in-the-talent-pool-for-c-developers">https://www.efinancialcareers.com/news/2022/11/why-is-there-a-drought-in-the-talent-pool-for-c-developers</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33436268">https://news.ycombinator.com/item?id=33436268</a></p>
<p>Points: 6</p>
<p># Comments: 3</p>

## Method Chaining in Pandas: Bad Form or a Recipe for Success?
 - [https://davidamos.dev/method-chaining-in-pandas/](https://davidamos.dev/method-chaining-in-pandas/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 13:50:56+00:00

<p>Article URL: <a href="https://davidamos.dev/method-chaining-in-pandas/">https://davidamos.dev/method-chaining-in-pandas/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33435731">https://news.ycombinator.com/item?id=33435731</a></p>
<p>Points: 9</p>
<p># Comments: 5</p>

## EU Commission proposes to accelerate the rollout of instant payments in euro
 - [https://ec.europa.eu/commission/presscorner/detail/en/IP_22_6272](https://ec.europa.eu/commission/presscorner/detail/en/IP_22_6272)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 13:49:52+00:00

<p>Article URL: <a href="https://ec.europa.eu/commission/presscorner/detail/en/IP_22_6272">https://ec.europa.eu/commission/presscorner/detail/en/IP_22_6272</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33435720">https://news.ycombinator.com/item?id=33435720</a></p>
<p>Points: 26</p>
<p># Comments: 10</p>

## Why Are so Many Babies Born around 8:00 A.M.?
 - [https://blogs.scientificamerican.com/sa-visual/why-are-so-many-babies-born-around-8-00-a-m/](https://blogs.scientificamerican.com/sa-visual/why-are-so-many-babies-born-around-8-00-a-m/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 13:47:57+00:00

<p>Article URL: <a href="https://blogs.scientificamerican.com/sa-visual/why-are-so-many-babies-born-around-8-00-a-m/">https://blogs.scientificamerican.com/sa-visual/why-are-so-many-babies-born-around-8-00-a-m/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33435695">https://news.ycombinator.com/item?id=33435695</a></p>
<p>Points: 19</p>
<p># Comments: 17</p>

## Ask HN: How can techies influence companies to stop implementing SMS/phone 2FA
 - [https://news.ycombinator.com/item?id=33435682](https://news.ycombinator.com/item?id=33435682)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 13:47:07+00:00

<p>We are tired of the risk that SMS 2FA brings. Most of us have gotten smart enough to not use it but some companies (financial institutions especially) only have SMS based 2FA even in 2022.<p>Then, there are some shady ones that force you to enter a phone number even for non SMS/TOTP based (looking at you sendgrid)<p>People losing access to their phone is a scenario and puts users at significant risk of losing access to key accounts. I am not even talking about the security risk SMS 2FA brings which of course it does.<p>The worst part is that even now, companies are implementing it as a "updated security measure". Who are these people in the tech. departments making these decisions ? It is beyond ridiculous and why can't there be someone who understands that this needs to stop. I know most common people have no idea but there are plenty of us who know what a pain in the ass this is.<p>Is it time to try and force a legislation through Congress because I don't think these companies give a shit until forced to.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33435682">https://news.ycombinator.com/item?id=33435682</a></p>
<p>Points: 10</p>
<p># Comments: 9</p>

## AskEdith – Never write SQL from scratch again
 - [https://www.askedith.ai/](https://www.askedith.ai/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 13:25:22+00:00

<p>Article URL: <a href="https://www.askedith.ai/">https://www.askedith.ai/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33435361">https://news.ycombinator.com/item?id=33435361</a></p>
<p>Points: 33</p>
<p># Comments: 13</p>

## Psychedelics: A Personal Take (2021)
 - [https://ava.substack.com/p/psychedelics-a-personal-take](https://ava.substack.com/p/psychedelics-a-personal-take)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 13:11:59+00:00

<p>Article URL: <a href="https://ava.substack.com/p/psychedelics-a-personal-take">https://ava.substack.com/p/psychedelics-a-personal-take</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33435140">https://news.ycombinator.com/item?id=33435140</a></p>
<p>Points: 23</p>
<p># Comments: 6</p>

## Urlscan.io's SOAR spot: Chatty security tools leaking private data
 - [https://positive.security/blog/urlscan-data-leaks](https://positive.security/blog/urlscan-data-leaks)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 13:00:55+00:00

<p>Article URL: <a href="https://positive.security/blog/urlscan-data-leaks">https://positive.security/blog/urlscan-data-leaks</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33435002">https://news.ycombinator.com/item?id=33435002</a></p>
<p>Points: 16</p>
<p># Comments: 0</p>

## Ask HN: How to deal with burnout and its consequences?
 - [https://news.ycombinator.com/item?id=33434742](https://news.ycombinator.com/item?id=33434742)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 12:38:33+00:00

<p>Hey HN,<p>Earlier this year I burned out hard and spectacularly, having nothing short of a total breakdown and being forced to take many, many months of medical leave by my GP.<p>My job wasn't overly difficult, but the corporate environment I found myself in was something I'd never done before and it was completely unsuited to me as an individual. It is the worst working experience I've ever been through.<p>I returned to my job late last month and I find that I simply don't care anymore. My burnout was never really fixed despite the time off. I'm unable to accomplish even basic tasks at work now and truthfully I'm at a point where I don't even care if I get fired. In the time I've been back I think I've been able to close one of two tiny tickets, the rest of the time I've literally done nothing.<p>During my time off I've been poked and prodded by psychologists and they seem to think I have ADHD and that it was a large contributing factor to this, though I'm not completely sure I buy this explanation.<p>I'm not well off like most people on here, I can survive 4-6 months with no salary, which I'm likely going to have to consider given my firing seems imminent at this point. I simply don't think I'm capable of maintaining this job anymore.<p>I really don't know how to get over this and how to move past it. I feel quite literally incapable of working. My mind knows what needs to be done, but my body says no and I am overwhelmed by apathy. I'm honestly not sure if I'm capable of working in tech anymore at this point and that's doing quite a number of any selfesteem I had.<p>Truthfully I didn't know things could get this bad. I'm trying to figure out what my future even looks like and how to move past this and any advice would be really appreciated.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33434742">https://news.ycombinator.com/item?id=33434742</a></p>
<p>Points: 37</p>
<p># Comments: 38</p>

## Jony Ive on Life After Apple
 - [https://www.wsj.com/articles/jony-ive-apple-design-interview-profile-lovefrom-11666733971](https://www.wsj.com/articles/jony-ive-apple-design-interview-profile-lovefrom-11666733971)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 12:35:08+00:00

<p>Article URL: <a href="https://www.wsj.com/articles/jony-ive-apple-design-interview-profile-lovefrom-11666733971">https://www.wsj.com/articles/jony-ive-apple-design-interview-profile-lovefrom-11666733971</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33434708">https://news.ycombinator.com/item?id=33434708</a></p>
<p>Points: 6</p>
<p># Comments: 4</p>

## Scientists Increasingly Can’t Explain How AI Works
 - [https://www.vice.com/en/article/y3pezm/scientists-increasingly-cant-explain-how-ai-works](https://www.vice.com/en/article/y3pezm/scientists-increasingly-cant-explain-how-ai-works)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 12:18:13+00:00

<p>Article URL: <a href="https://www.vice.com/en/article/y3pezm/scientists-increasingly-cant-explain-how-ai-works">https://www.vice.com/en/article/y3pezm/scientists-increasingly-cant-explain-how-ai-works</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33434512">https://news.ycombinator.com/item?id=33434512</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## Doing what you love when the money won’t follow
 - [https://loveofallwisdom.com/blog/2022/06/doing-what-you-love-when-the-money-wont-follow/](https://loveofallwisdom.com/blog/2022/06/doing-what-you-love-when-the-money-wont-follow/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 12:01:16+00:00

<p>Article URL: <a href="https://loveofallwisdom.com/blog/2022/06/doing-what-you-love-when-the-money-wont-follow/">https://loveofallwisdom.com/blog/2022/06/doing-what-you-love-when-the-money-wont-follow/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33434326">https://news.ycombinator.com/item?id=33434326</a></p>
<p>Points: 5</p>
<p># Comments: 3</p>

## Moral Toddlers Making a Mess
 - [https://quillette.com/2022/10/30/moral-toddlerhood/](https://quillette.com/2022/10/30/moral-toddlerhood/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 11:47:35+00:00

<p>Article URL: <a href="https://quillette.com/2022/10/30/moral-toddlerhood/">https://quillette.com/2022/10/30/moral-toddlerhood/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33434209">https://news.ycombinator.com/item?id=33434209</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Having a campus that looks like a Benetton ad isn't a compelling state interest
 - [https://davidlat.substack.com/p/affirmative-action-is-going-down](https://davidlat.substack.com/p/affirmative-action-is-going-down)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 11:43:21+00:00

<p>Article URL: <a href="https://davidlat.substack.com/p/affirmative-action-is-going-down">https://davidlat.substack.com/p/affirmative-action-is-going-down</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33434178">https://news.ycombinator.com/item?id=33434178</a></p>
<p>Points: 14</p>
<p># Comments: 4</p>

## Ask HN: Carrier “lost” my number in a port request
 - [https://news.ycombinator.com/item?id=33434153](https://news.ycombinator.com/item?id=33434153)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 11:40:06+00:00

<p>I tried switching from T-Mobile to US Mobile after parking it on a VoIP service for a year (was abroad). They botched the port request completely. Ended up gaslighted by both companies, both claimed they "don't have the number".<p>Need my number for 2FA—literally can't move forward with a background check for my new job, can't send money to my family with my bank, etc. I'm sure I could theoretically get a new number but it seems the admin cost of this would possibly be in the hundreds of hours.<p>Do I have any recourse?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33434153">https://news.ycombinator.com/item?id=33434153</a></p>
<p>Points: 17</p>
<p># Comments: 4</p>

## C++ is the next C++
 - [https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2022/p2657r0.html](https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2022/p2657r0.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 11:30:44+00:00

<p>Article URL: <a href="https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2022/p2657r0.html">https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2022/p2657r0.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33434092">https://news.ycombinator.com/item?id=33434092</a></p>
<p>Points: 51</p>
<p># Comments: 44</p>

## Pantone wants $15/month for the privilege of using its colors in Photoshop
 - [https://arstechnica.com/gadgets/2022/11/pantone-wants-15-month-for-the-privilege-of-using-its-colors-in-photoshop/](https://arstechnica.com/gadgets/2022/11/pantone-wants-15-month-for-the-privilege-of-using-its-colors-in-photoshop/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 11:00:24+00:00

<p>Article URL: <a href="https://arstechnica.com/gadgets/2022/11/pantone-wants-15-month-for-the-privilege-of-using-its-colors-in-photoshop/">https://arstechnica.com/gadgets/2022/11/pantone-wants-15-month-for-the-privilege-of-using-its-colors-in-photoshop/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33433882">https://news.ycombinator.com/item?id=33433882</a></p>
<p>Points: 14</p>
<p># Comments: 2</p>

## Why Functional Programming Should Be the Future of Software
 - [https://spectrum.ieee.org/functional-programming](https://spectrum.ieee.org/functional-programming)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 10:49:13+00:00

<p>Article URL: <a href="https://spectrum.ieee.org/functional-programming">https://spectrum.ieee.org/functional-programming</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33433783">https://news.ycombinator.com/item?id=33433783</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## AlphaFold’s new rival? Meta AI predicts shape of 600M proteins
 - [https://www.nature.com/articles/d41586-022-03539-1](https://www.nature.com/articles/d41586-022-03539-1)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 10:19:01+00:00

<p>Article URL: <a href="https://www.nature.com/articles/d41586-022-03539-1">https://www.nature.com/articles/d41586-022-03539-1</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33433583">https://news.ycombinator.com/item?id=33433583</a></p>
<p>Points: 38</p>
<p># Comments: 2</p>

## Priceloop NoCode Spreadsheet platform built in Scala and on-top of Postgres
 - [https://news.ycombinator.com/item?id=33433316](https://news.ycombinator.com/item?id=33433316)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 09:43:35+00:00

<p>Hi!<p>At priceloop, we are working on a completely novel way of how businesses can run their pricing. Like really really novel. Not just another AI model for pricing but we want to strive to redefine this software category.<p>In particular, we are building a NoCode platform that enables businesses and IT to work together in a seamless way. Some of our features:<p>- A powerful spreadsheet that can handle millions of rows<p>- Many built-in and custom functions: you can easily write external function in Python and use it in the spreadsheet: https://medium.com/priceloop-tech-blog/how-to-build-an-external-function-on-priceloop-nocode-7d1325be7816<p>- Autosuggestion and syntax highlighting when creating formulas; kind of a powerful IDE for spreadsheet formulas<p>- An easy API interface to interact with the spreadsheet<p>We are in early development and just released our alpha version. In the next upcoming weeks, we will also open-source the core of our platform! So bookmark our github org already: https://github.com/priceloop<p>Sign up to Priceloop NoCode now and try it out: https://alpha.priceloop.ai<p>Feedback is welcomed!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33433316">https://news.ycombinator.com/item?id=33433316</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Rakuten dumps Red Hat, turns to “true” open-source Linux OS
 - [https://www.telecomtv.com/content/digital-platforms-services/rakuten-dumps-red-hat-turns-to-true-open-source-linux-os-45803/](https://www.telecomtv.com/content/digital-platforms-services/rakuten-dumps-red-hat-turns-to-true-open-source-linux-os-45803/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 08:32:40+00:00

<p>Article URL: <a href="https://www.telecomtv.com/content/digital-platforms-services/rakuten-dumps-red-hat-turns-to-true-open-source-linux-os-45803/">https://www.telecomtv.com/content/digital-platforms-services/rakuten-dumps-red-hat-turns-to-true-open-source-linux-os-45803/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33432746">https://news.ycombinator.com/item?id=33432746</a></p>
<p>Points: 29</p>
<p># Comments: 6</p>

## TomTom announces new Maps Platform using OpenStreetMap
 - [https://www.tomtom.com/newsroom/behind-the-map/the-future-of-mapmaking-tomtom-maps-platform/](https://www.tomtom.com/newsroom/behind-the-map/the-future-of-mapmaking-tomtom-maps-platform/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 08:28:21+00:00

<p>Article URL: <a href="https://www.tomtom.com/newsroom/behind-the-map/the-future-of-mapmaking-tomtom-maps-platform/">https://www.tomtom.com/newsroom/behind-the-map/the-future-of-mapmaking-tomtom-maps-platform/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33432720">https://news.ycombinator.com/item?id=33432720</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## How to upgrade an antiquated Identity and Access Management system?
 - [https://memgraph.com/blog/how-to-upgrade-an-antiquated-identity-and-access-management-system](https://memgraph.com/blog/how-to-upgrade-an-antiquated-identity-and-access-management-system)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 08:19:34+00:00

<p>Article URL: <a href="https://memgraph.com/blog/how-to-upgrade-an-antiquated-identity-and-access-management-system">https://memgraph.com/blog/how-to-upgrade-an-antiquated-identity-and-access-management-system</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33432662">https://news.ycombinator.com/item?id=33432662</a></p>
<p>Points: 15</p>
<p># Comments: 0</p>

## Any tools can generate datatype from string?
 - [https://news.ycombinator.com/item?id=33432517](https://news.ycombinator.com/item?id=33432517)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 07:57:48+00:00

<p>i wonder if there is a tool can do this. for example: give a csv file, guess the schema.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33432517">https://news.ycombinator.com/item?id=33432517</a></p>
<p>Points: 5</p>
<p># Comments: 4</p>

## Protonmail can delete the wrong email and nobody cares
 - [https://github.com/ProtonMail/proton-bridge/issues/220](https://github.com/ProtonMail/proton-bridge/issues/220)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 07:22:58+00:00

<p>Article URL: <a href="https://github.com/ProtonMail/proton-bridge/issues/220">https://github.com/ProtonMail/proton-bridge/issues/220</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33432296">https://news.ycombinator.com/item?id=33432296</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## PhotoRoom Is Hiring a Senior Back End Engineer (Django, 200GB+ PSQL DB) in Paris
 - [https://jobs.lever.co/photoroom/01f5cb22-695a-402a-a970-818a6c2d47a9?lever-origin=applied&lever-source%5B%5D=Hacker%20News](https://jobs.lever.co/photoroom/01f5cb22-695a-402a-a970-818a6c2d47a9?lever-origin=applied&lever-source%5B%5D=Hacker%20News)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 07:00:22+00:00

<p>Article URL: <a href="https://jobs.lever.co/photoroom/01f5cb22-695a-402a-a970-818a6c2d47a9?lever-origin=applied&amp;lever-source%5B%5D=Hacker%20News">https://jobs.lever.co/photoroom/01f5cb22-695a-402a-a970-818a6c2d47a9?lever-origin=applied&amp;lever-source%5B%5D=Hacker%20News</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33432159">https://news.ycombinator.com/item?id=33432159</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Disneyland Shanghai shuts over COVID, visitors unable to leave
 - [https://www.bbc.com/news/world-asia-63456107](https://www.bbc.com/news/world-asia-63456107)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 06:48:17+00:00

<p>Article URL: <a href="https://www.bbc.com/news/world-asia-63456107">https://www.bbc.com/news/world-asia-63456107</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33432086">https://news.ycombinator.com/item?id=33432086</a></p>
<p>Points: 18</p>
<p># Comments: 9</p>

## What would happen if you fell through a hole to the center of the Earth?
 - [https://www.wtamu.edu/~cbaird/sq/2013/10/04/what-would-happen-if-you-fell-into-a-hole-that-went-through-the-center-of-the-earth/](https://www.wtamu.edu/~cbaird/sq/2013/10/04/what-would-happen-if-you-fell-into-a-hole-that-went-through-the-center-of-the-earth/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 06:10:30+00:00

<p>Article URL: <a href="https://www.wtamu.edu/~cbaird/sq/2013/10/04/what-would-happen-if-you-fell-into-a-hole-that-went-through-the-center-of-the-earth/">https://www.wtamu.edu/~cbaird/sq/2013/10/04/what-would-happen-if-you-fell-into-a-hole-that-went-through-the-center-of-the-earth/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33431910">https://news.ycombinator.com/item?id=33431910</a></p>
<p>Points: 3</p>
<p># Comments: 3</p>

## Cook Shortage Threatens to Sink U.S. Coast Guard Operations
 - [https://www.forbes.com/sites/craighooper/2022/10/31/a-cook-shortage-threatens-to-sink-us-coast-guard-operations/](https://www.forbes.com/sites/craighooper/2022/10/31/a-cook-shortage-threatens-to-sink-us-coast-guard-operations/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 02:47:41+00:00

<p>Article URL: <a href="https://www.forbes.com/sites/craighooper/2022/10/31/a-cook-shortage-threatens-to-sink-us-coast-guard-operations/">https://www.forbes.com/sites/craighooper/2022/10/31/a-cook-shortage-threatens-to-sink-us-coast-guard-operations/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33430886">https://news.ycombinator.com/item?id=33430886</a></p>
<p>Points: 15</p>
<p># Comments: 3</p>

## Rate Hikes Are Affecting the Economy
 - [https://www.apricitas.io/p/how-rate-hikes-are-affecting-the](https://www.apricitas.io/p/how-rate-hikes-are-affecting-the)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 02:11:10+00:00

<p>Article URL: <a href="https://www.apricitas.io/p/how-rate-hikes-are-affecting-the">https://www.apricitas.io/p/how-rate-hikes-are-affecting-the</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33430660">https://news.ycombinator.com/item?id=33430660</a></p>
<p>Points: 6</p>
<p># Comments: 4</p>

## Moving past TCP in the data center, part 1
 - [https://lwn.net/SubscriberLink/913260/8819c42491a70e9b/](https://lwn.net/SubscriberLink/913260/8819c42491a70e9b/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 01:24:00+00:00

<p>Article URL: <a href="https://lwn.net/SubscriberLink/913260/8819c42491a70e9b/">https://lwn.net/SubscriberLink/913260/8819c42491a70e9b/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33430305">https://news.ycombinator.com/item?id=33430305</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## iCloud Mail is experiencing an ongoing outage
 - [https://www.apple.com/support/systemstatus/](https://www.apple.com/support/systemstatus/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 00:50:51+00:00

<p>Article URL: <a href="https://www.apple.com/support/systemstatus/">https://www.apple.com/support/systemstatus/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33430049">https://news.ycombinator.com/item?id=33430049</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Show HN: Tier.run – Terraform for Stripe
 - [https://github.com/tierrun](https://github.com/tierrun)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-02 00:40:29+00:00

<p>Hi HN, we are Jevon, Blake and Isaac, we've been working on Tier for a little while ( <a href="http://github.com/tierrun" rel="nofollow">http://github.com/tierrun</a>)<p>Tier is "Terraform for Stripe" but it goes further and gives you feature flag style access checks, and allows you to count/report usage which can be used for metered billing.<p>When we started Tier, we knew that there was something interesting in the SaaS pricing and packaging space. Adjusting price is the single most effective lever a business can use to achieve product/market fit, and there's a strong correlation price nimbleness and market success.<p>In spite of overwhelming evidence of this, most startups pick the price for their product once and then never change it, opting instead to invest in less effective levers like CAC, sales efficiency, "virality", churn, etc. Why?<p>It's just too hard. Any change you make to the pricing model means refactoring not just the entire product, but sometimes the entire <i>company</i>. The path of least resistance leads to a place where there's no single source of truth, and changes anywhere require changes everywhere.After over 50 or so customer conversations and user research chats, this represents our third or fourth implementation (depending on how you count them), and our conception of how best to solve it has been refined and adjusted along the way.<p>The concept of "PriceOps" came out of those conversations, looking at where mature companies end up after several expensive rounds of iterating on how they implement their prices for flexibility and order. <a href="https://priceops.org" rel="nofollow">https://priceops.org</a><p>What we're releasing now is an open source tool you can use to set up your Stripe system that keeps everything organized around a single source of truth. With this, changes to your pricing model don't require changes to your application code or business processes.<p>As a bonus, I think it's actually easier to integrate with than integrating with Stripe the "normal" way. Use the identifiers for your customers and features that you already have. Define plans and subscribe customers to them. No ever-growing pile of object ids to manage.<p>If you are just starting to think about adding pricing to your product, or if you've built something custom but would like something less maintenance intensive, then please give Tier a try and we'd love your feedback.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33429972">https://news.ycombinator.com/item?id=33429972</a></p>
<p>Points: 11</p>
<p># Comments: 0</p>


# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Komplet drużyn z awansem do 1/8 finału Ligi Mistrzów
 - [https://eurosport.tvn24.pl/liga-mistrz-w-2022-2023--kiedy-losowanie-1-8-fina-u--kto-awansowa--z-grup-,1123330.html?source=rss](https://eurosport.tvn24.pl/liga-mistrz-w-2022-2023--kiedy-losowanie-1-8-fina-u--kto-awansowa--z-grup-,1123330.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 21:53:00+00:00

<img alt="Komplet drużyn z awansem do 1/8 finału Ligi Mistrzów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k4ej2y-piotr-zielinska-bedzie-jedynym-polakiem-w-fazie-pucharowej-lm/alternates/LANDSCAPE_1280" />
    Znamy 16 klubów, które awansowały do 1/8 finału. Kiedy losowanie?

## AC Milan w najlepszej szesnastce Ligi Mistrzów
 - [https://eurosport.tvn24.pl/ac-milan-po-dziewi-ciu-latach-w-najlepszej-szesnastce-ligi-mistrz-w,1123405.html?source=rss](https://eurosport.tvn24.pl/ac-milan-po-dziewi-ciu-latach-w-najlepszej-szesnastce-ligi-mistrz-w,1123405.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 21:52:53+00:00

<img alt="AC Milan w najlepszej szesnastce Ligi Mistrzów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sitzbz-ac-milan-moze-szykowac-sie-do-meczow-18-finalu/alternates/LANDSCAPE_1280" />
    Po dziewięciu latach.

## Szachtar rozbity w decydującym meczu, żegna się z Ligą Mistrzów
 - [https://eurosport.tvn24.pl/szachtar-rozbity-w-decyduj-cym-meczu---egna-si--z-lig--mistrz-w,1123397.html?source=rss](https://eurosport.tvn24.pl/szachtar-rozbity-w-decyduj-cym-meczu---egna-si--z-lig--mistrz-w,1123397.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 19:41:00+00:00

<img alt="Szachtar rozbity w decydującym meczu, żegna się z Ligą Mistrzów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sz056e-niemiecki-zespol-zdominowal-szachatara/alternates/LANDSCAPE_1280" />
    Przegrał na stadionie Legii w Warszawie z RB Lipsk i wiosną zagra w Lidze Europy.

## Koniec marzeń Hurkacza
 - [https://eurosport.tvn24.pl/koniec-marze--hurkacza-o-fina-ach--m-ody-du-czyk-nie-da--mu-szans,1123381.html?source=rss](https://eurosport.tvn24.pl/koniec-marze--hurkacza-o-fina-ach--m-ody-du-czyk-nie-da--mu-szans,1123381.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 18:58:00+00:00

<img alt="Koniec marzeń Hurkacza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4c79zc-hubert-hurkacz-podczas-turnieju-atp-masters-1000-w-paryzu-6190970/alternates/LANDSCAPE_1280" />
    Młody Duńczyk nie dał mu szans.

## Marek Falenta przerwał milczenie. "Nigdy nikomu nie sprzedałem żadnych nagrań"
 - [https://fakty.tvn24.pl/marek-falenta-przerwa--milczenie---nigdy-nikomu-nie-sprzeda-em--adnych-nagra--,1123384.html?source=rss](https://fakty.tvn24.pl/marek-falenta-przerwa--milczenie---nigdy-nikomu-nie-sprzeda-em--adnych-nagra--,1123384.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 18:12:00+00:00

<img alt="Marek Falenta przerwał milczenie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-omvazb-0211--marek-falenta-przerwal-milczenie-nigdy-nikomu-nie-sprzedalem-zadnych-nagran/alternates/LANDSCAPE_1280" />
    Skazany biznesmen milczy jednak w sprawie wątku rzekomej łapówki przekazanej synowi Donalda Tuska.

## Bachmut. To miejsce w Ukrainie najbardziej dziś przypomina piekło na Ziemi
 - [https://fakty.tvn24.pl/rosja-wznawia-udzia--w-umowie-zbo-owej--wci---jednak-bombarduje-ukrai-skie-miasta,1123361.html?source=rss](https://fakty.tvn24.pl/rosja-wznawia-udzia--w-umowie-zbo-owej--wci---jednak-bombarduje-ukrai-skie-miasta,1123361.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 18:11:00+00:00

<img alt="Bachmut. To miejsce w Ukrainie najbardziej dziś przypomina piekło na Ziemi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7cjajf-0211--rosja-wznawia-udzial-w-umowie-zbozowej-wciaz-jednak-bombarduje-ukrainskie-miasta/alternates/LANDSCAPE_1280" />
    Materiał Andrzeja Zauchy.

## Justyna Socha nie jest już szefową STOP NOP. Jest też zawiadomienie do prokuratury
 - [https://fakty.tvn24.pl/justyna-socha-nie-jest-ju--szefow--stop-nop--cz-onkowie-stowarzyszenia-z-o-yli-te--zawiadomienie-do-prokuratury,1123394.html?source=rss](https://fakty.tvn24.pl/justyna-socha-nie-jest-ju--szefow--stop-nop--cz-onkowie-stowarzyszenia-z-o-yli-te--zawiadomienie-do-prokuratury,1123394.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 18:06:00+00:00

<img alt="Justyna Socha nie jest już szefową STOP NOP. Jest też zawiadomienie do prokuratury" src="https://tvn24.pl/najnowsze/cdn-zdjecie-p9k631-0211--justyna-socha-nie-jest-juz-szefowa-stop-nop-czlonkowie-stowarzyszenia-zlozyli-tez-zawiadomienie-do-prokuratury/alternates/LANDSCAPE_1280" />
    Przez lata była twarzą ruchów antyszczepionkowych.

## TVN Warner Bros. Discovery domem skoków narciarskich w Polsce
 - [https://eurosport.tvn24.pl/tvn-warner-bros--discovery-domem-skok-w-narciarskich-w-polsce,1123378.html?source=rss](https://eurosport.tvn24.pl/tvn-warner-bros--discovery-domem-skok-w-narciarskich-w-polsce,1123378.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 18:00:00+00:00

<img alt="TVN Warner Bros. Discovery domem skoków narciarskich w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4hnrb5-dawid-kubacki-to-ambasador-skokow-grupy-warner-bros-discovery/alternates/LANDSCAPE_1280" />
    To będzie zimowe szaleństwo w rytmie skoków.

## Selekcjoner o szansach w mistrzostwach Europy
 - [https://eurosport.tvn24.pl/-przez-trzy-lata-dru-yna-mocno-si--rozwin--a---selekcjoner-o-szansach-w-mistrzostwach-europy,1123363.html?source=rss](https://eurosport.tvn24.pl/-przez-trzy-lata-dru-yna-mocno-si--rozwin--a---selekcjoner-o-szansach-w-mistrzostwach-europy,1123363.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 16:56:00+00:00

<img alt=" Selekcjoner o szansach w mistrzostwach Europy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bbpdef-arne-senstad-w-rozmowie-z-eurosportem/alternates/LANDSCAPE_1280" />
    Piłkarki ręczne reprezentacji Polski gotowe na turniej - zapewnia w rozmowie z Eurosportem Arne Senstad.

## Neuer o raku. "Miałem trzy operacje"
 - [https://eurosport.tvn24.pl/manuer-neuer-wyzna----e-walczy--z-rakiem---mia-em-trzy-operacje-,1123352.html?source=rss](https://eurosport.tvn24.pl/manuer-neuer-wyzna----e-walczy--z-rakiem---mia-em-trzy-operacje-,1123352.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 16:27:00+00:00

<img alt="Neuer o raku. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-bbhfxf-manuel-neuer/alternates/LANDSCAPE_1280" />
    Niemiecki bramkarz ujawnia.

## 93 powody do świętowania. Polacy poszukają kolejnych pucharowych zwycięstw
 - [https://eurosport.tvn24.pl/93-powody-do--wi-towania--polacy-poszukaj--kolejnych-pucharowych-zwyci-stw,1123333.html?source=rss](https://eurosport.tvn24.pl/93-powody-do--wi-towania--polacy-poszukaj--kolejnych-pucharowych-zwyci-stw,1123333.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 15:36:00+00:00

<img alt="93 powody do świętowania. Polacy poszukają kolejnych pucharowych zwycięstw" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sspibk-kamil-stoch-jako-ostatni-z-polakow-wygral-w-pucharze-swiata/alternates/LANDSCAPE_1280" />
    Nowy sezon Pucharu Świata tuż-tuż, a w nim szanse na kolejne polskie triumfy.

## W konkursie na trenera nie uwzględnili czarnoskórego
 - [https://eurosport.tvn24.pl/w-konkursie-na-trenera-nie-uwzgl-dnili-czarnosk-rego--s-ono-za-to-zap-ac-,1123329.html?source=rss](https://eurosport.tvn24.pl/w-konkursie-na-trenera-nie-uwzgl-dnili-czarnosk-rego--s-ono-za-to-zap-ac-,1123329.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 14:54:00+00:00

<img alt="W konkursie na trenera nie uwzględnili czarnoskórego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qymrps-wayne-rooney-wystepowal-w-dc-united-rowniez-jako-pilkarz/alternates/LANDSCAPE_1280" />
    Słono za to zapłacą.

## Nowy wymiar dominacji Świątek
 - [https://eurosport.tvn24.pl/nowy-wymiar-dominacji--wi-tek--takiego-wyczynu-nie-widziano-od-o-miu-lat,1123314.html?source=rss](https://eurosport.tvn24.pl/nowy-wymiar-dominacji--wi-tek--takiego-wyczynu-nie-widziano-od-o-miu-lat,1123314.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 13:58:00+00:00

<img alt="Nowy wymiar dominacji Świątek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1z6ljd-iga-swiatek-juz-pieciokrotnie-pokonywala-darie-kasatkine/alternates/LANDSCAPE_1280" />
    Takiego wyczynu nie widziano od ośmiu lat.

## "Mój świat się na chwilę zatrzymał". Poruszający wpis żony Leona
 - [https://eurosport.tvn24.pl/-m-j--wiat-si--na-chwil--zatrzyma----poruszaj-cy-wpis--ony-leona,1123332.html?source=rss](https://eurosport.tvn24.pl/-m-j--wiat-si--na-chwil--zatrzyma----poruszaj-cy-wpis--ony-leona,1123332.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 12:07:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-adv027-wilfredo-leon/alternates/LANDSCAPE_1280" />
    Skończyło się na strachu.

## Amerykanie zbudują elektrownię jądrową w Polsce. Wskazano preferowaną lokalizację
 - [https://tvn24.pl/biznes/z-kraju/elektrownie-atomowa-w-polsce-lokalizacja-gdzie-powstanie-elektrownia-budowana-przez-amerykanow-6190179?source=rss](https://tvn24.pl/biznes/z-kraju/elektrownie-atomowa-w-polsce-lokalizacja-gdzie-powstanie-elektrownia-budowana-przez-amerykanow-6190179?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 11:46:17+00:00

<img alt="Amerykanie zbudują elektrownię jądrową w Polsce. Wskazano preferowaną lokalizację" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-ep3y4q-juz-wkrotce-w-polsce-moze-powstac-elektrownia-jadrowa-4212108/alternates/LANDSCAPE_1280" />
    Projekt rządowej uchwały.

## Na działce Gerarda Pique odkryto 250 grobów
 - [https://eurosport.tvn24.pl/na-dzia-ce-gerarda-pique-odkryto-250-grob-w,1123316.html?source=rss](https://eurosport.tvn24.pl/na-dzia-ce-gerarda-pique-odkryto-250-grob-w,1123316.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 11:10:00+00:00

<img alt="Na działce Gerarda Pique odkryto 250 grobów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kbbv2g-gerard-pique-jest-legenda-barcelony/alternates/LANDSCAPE_1280" />
    Niecodzienne odkrycie w Andaluzji.

## Świątek wbija szpilę organizatorom WTA Finals
 - [https://eurosport.tvn24.pl/-wi-tek-wbija-szpil--organizatorom-wta-finals,1123318.html?source=rss](https://eurosport.tvn24.pl/-wi-tek-wbija-szpil--organizatorom-wta-finals,1123318.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 09:52:00+00:00

<img alt="Świątek wbija szpilę organizatorom WTA Finals" src="https://tvn24.pl/najnowsze/cdn-zdjecie-t0qyxj-iga-swiatek/alternates/LANDSCAPE_1280" />
    Liderka rankingu nie gryzie się w język.

## Wygrał ostatni mecz i stracił pracę
 - [https://eurosport.tvn24.pl/wygra--ostatni-mecz-i-straci--prac---koszykarze-brooklyn-nets-bez-trenera,1123280.html?source=rss](https://eurosport.tvn24.pl/wygra--ostatni-mecz-i-straci--prac---koszykarze-brooklyn-nets-bez-trenera,1123280.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 09:43:00+00:00

<img alt="Wygrał ostatni mecz i stracił pracę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2y4l58-steve-nash-byl-trenerem-brooklyn-nets/alternates/LANDSCAPE_1280" />
    Koszykarze Brooklyn Nets bez trenera.

## Wygrała szybciej niż Świątek. Polce wyrosła konkurencja
 - [https://eurosport.tvn24.pl/wygra-a-szybciej-ni---wi-tek--polce-wyros-a-konkurencja-w-fina-ach-wta,1123315.html?source=rss](https://eurosport.tvn24.pl/wygra-a-szybciej-ni---wi-tek--polce-wyros-a-konkurencja-w-fina-ach-wta,1123315.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 08:36:00+00:00

<img alt="Wygrała szybciej niż Świątek. Polce wyrosła konkurencja" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tfzvw6-caroline-garcia/alternates/LANDSCAPE_1280" />
    Caroline Garcia z przytupem rozpoczęła rywalizację w Fort Worth.

## Wpłacili na kampanię wyborczą, wkroczyli na sam szczyt
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym---do-spolki-z-odcinki,900735/odcinek-3,S00E03,900739?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym---do-spolki-z-odcinki,900735/odcinek-3,S00E03,900739?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 08:29:08+00:00

<img alt="Wpłacili na kampanię wyborczą, wkroczyli na sam szczyt " src="https://tvn24.pl/najnowsze/cdn-zdjecie-bdbtjk-beata-szydlo-6189854/alternates/LANDSCAPE_1280" />
    Jak to się ma do zasady równości wyborów? Reportaż Grzegorza Łakomskiego z portalu tvn24.pl i Dariusza Kubika z "Czarno na białym".

## Świątek o kluczu do łatwego zwycięstwa
 - [https://eurosport.tvn24.pl/-wi-tek-o-kluczu-do--atwego-zwyci-stwa,1123313.html?source=rss](https://eurosport.tvn24.pl/-wi-tek-o-kluczu-do--atwego-zwyci-stwa,1123313.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 06:45:00+00:00

<img alt="Świątek o kluczu do łatwego zwycięstwa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-aqg3qd-iga-swiatek-nie-przestaje-zachwycac/alternates/LANDSCAPE_1280" />
    Iga Świątek w doskonałym stylu weszła w turniej WTA Finals.

## Kraj wielkich nierówności. Kto wierzy jeszcze w amerykański sen?
 - [https://tvn24.pl/go/audio,14/podcast-o-zagranicy-odcinki,663543/odcinek-43,S00E43,900732?source=rss](https://tvn24.pl/go/audio,14/podcast-o-zagranicy-odcinki,663543/odcinek-43,S00E43,900732?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 05:00:00+00:00

<img alt="Kraj wielkich nierówności. Kto wierzy jeszcze w amerykański sen? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1jo24x-ameryka-6188861/alternates/LANDSCAPE_1280" />
    W Ameryce wszystko jest większe - większe problemy, ale może i większe możliwości radzenia sobie z nimi. Czy tak jest w istocie?

## Inicjatywa zbożowa "będzie działać jak wcześniej"
 - [https://tvn24.pl/swiat/ukraina-korytarz-zbozowy-powrot-rosji-do-inicjatywy-oswiadczenie-wladimira-putina-komentarz-biura-prezydenta-wolodymyra-zelenskiego-6189634?source=rss](https://tvn24.pl/swiat/ukraina-korytarz-zbozowy-powrot-rosji-do-inicjatywy-oswiadczenie-wladimira-putina-komentarz-biura-prezydenta-wolodymyra-zelenskiego-6189634?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-02 04:39:00+00:00

<img alt="Inicjatywa zbożowa " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2kf7gm-zaladunek-zboza-w-porcie-w-odessie-2021-zdjecie-ilustracyjne-5785763/alternates/LANDSCAPE_1280" />
    Erdogan: korytarz będzie otwarty.


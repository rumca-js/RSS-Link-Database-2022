# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Atrás Hay Truenos - Cara de Mapa (Live on KEXP)
 - [https://www.youtube.com/watch?v=cMNlK3ilzIY](https://www.youtube.com/watch?v=cMNlK3ilzIY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-11-03 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present KEXP live from Argentina with Atrás Hay Truenos performing “Cara de Mapa” live at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded September 22, 2022.

Roberto Aleandri: Guitar / Vocals
Diego Martínez - Bass / Vocals
Ignacio Mases - Guitar
Hector Zúñiga - Drums

Live Sound: Pablo Barros 
Audio Mixer: Diego Martínez
Stage: Gustavo Ramazzotti
Assistant: Florencia Russi

-----------------
KEXP live from Argentina is a partnership with the Argentine Ministry of Culture, MICA, and the Kirchner Cultural Center.

Realization, technical production: Centro Cultural Kirchner and KEXP

Sound Engineer: Pablo Nelken
Audio Mix and Mastering: Matt Ogaz
Videographers: Jim Beckmann, Sebastián Cáceres, Carlos Cruz & Alaia D’Alessandro
Live Director: Diego Laber
Editor: Carlos Cruz

Art: Lucila Rojo & team (stage design and art)
Lighting: Omar Posematto
Production Assistant: Gonzalo Vazquez
Media Fixer: Melissa Restrepo
Production and communication at Dirección Nacional de Integración Federal y Cooperación Internacional (Ministerio de Cultura de Argentina): Viviana Luna, Paloma Moccia, Pablo Murillo, Marcos Ribas, Lucia Soberal, Luciana Malavolta, Mariana Leder Kremer Hernández

Ministerio de Cultura de Argentina:
Tristán Bauer - Ministro de Cultura de la Nación Argentina
Lucrecia Cardoso - Secretaria de Desarrollo Cultural
Ariela Peretti - Directora Nacional de Integración Federal y Cooperación Internacional

https://atrashaytruenos.bandcamp.com
https://www.argentina.gob.ar/cultura
https://mica.gob.ar/inicio
https://www.cck.gob.ar
http://kexp.org

## Atrás Hay Truenos - Consuelo (Live on KEXP)
 - [https://www.youtube.com/watch?v=3JlU21j7Gzk](https://www.youtube.com/watch?v=3JlU21j7Gzk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-11-03 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present KEXP live from Argentina with Atrás Hay Truenos performing “Consuelo” live at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded September 22, 2022.

Roberto Aleandri: Guitar / Vocals
Diego Martínez - Bass / Vocals
Ignacio Mases - Guitar
Hector Zúñiga - Drums

Live Sound: Pablo Barros
Audio Mixer: Diego Martínez
Stage: Gustavo Ramazzotti
Assistant: Florencia Russi

-----------------
KEXP live from Argentina is a partnership with the Argentine Ministry of Culture, MICA, and the Kirchner Cultural Center.

Realization, technical production: Centro Cultural Kirchner and KEXP

Sound Engineer: Pablo Nelken
Audio Mastering: Matt Ogaz
Videographers: Jim Beckmann, Sebastián Cáceres, Carlos Cruz & Alaia D’Alessandro
Live Director: Diego Laber
Editor: Carlos Cruz

Art: Lucila Rojo & team (stage design and art)
Lighting: Omar Posematto
Production Assistant: Gonzalo Vazquez
Media Fixer: Melissa Restrepo
Production and communication at Dirección Nacional de Integración Federal y Cooperación Internacional (Ministerio de Cultura de Argentina): Viviana Luna, Paloma Moccia, Pablo Murillo, Marcos Ribas, Lucia Soberal, Luciana Malavolta, Mariana Leder Kremer Hernández

Ministerio de Cultura de Argentina:
Tristán Bauer - Ministro de Cultura de la Nación Argentina
Lucrecia Cardoso - Secretaria de Desarrollo Cultural
Ariela Peretti - Directora Nacional de Integración Federal y Cooperación Internacional

https://atrashaytruenos.bandcamp.com
https://www.argentina.gob.ar/cultura
https://mica.gob.ar/inicio
https://www.cck.gob.ar
http://kexp.org

## Atrás Hay Truenos - El Pantano (Live on KEXP)
 - [https://www.youtube.com/watch?v=G3eu2clzEXw](https://www.youtube.com/watch?v=G3eu2clzEXw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-11-03 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present KEXP live from Argentina with Atrás Hay Truenos performing “El Pantano” live at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded September 22, 2022.

Roberto Aleandri: Guitar / Vocals
Diego Martínez - Bass / Vocals
Ignacio Mases - Guitar
Hector Zúñiga - Drums

Live Sound: Pablo Barros 
Audio Mixer: Diego Martínez
Stage: Gustavo Ramazzotti
Assistant: Florencia Russi

-----------------
KEXP live from Argentina is a partnership with the Argentine Ministry of Culture, MICA, and the Kirchner Cultural Center.

Realization, technical production: Centro Cultural Kirchner and KEXP

Sound Engineer: Pablo Nelken
Audio Mastering: Matt Ogaz
Videographers: Jim Beckmann, Sebastián Cáceres, Carlos Cruz & Alaia D’Alessandro
Live Director: Diego Laber
Editor: Carlos Cruz

Art: Lucila Rojo & team (stage design and art)
Lighting: Omar Posematto
Production Assistant: Gonzalo Vazquez
Media Fixer: Melissa Restrepo
Production and communication at Dirección Nacional de Integración Federal y Cooperación Internacional (Ministerio de Cultura de Argentina): Viviana Luna, Paloma Moccia, Pablo Murillo, Marcos Ribas, Lucia Soberal, Luciana Malavolta, Mariana Leder Kremer Hernández

Ministerio de Cultura de Argentina:
Tristán Bauer - Ministro de Cultura de la Nación Argentina
Lucrecia Cardoso - Secretaria de Desarrollo Cultural
Ariela Peretti - Directora Nacional de Integración Federal y Cooperación Internacional

https://atrashaytruenos.bandcamp.com
https://www.argentina.gob.ar/cultura
https://mica.gob.ar/inicio
https://www.cck.gob.ar
http://kexp.org

## Atrás Hay Truenos - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=pobcQxVldHE](https://www.youtube.com/watch?v=pobcQxVldHE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-11-03 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present KEXP live from Argentina with Atrás Hay Truenos performing live at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded September 22, 2022.

Songs:
El Pantano
Cara de Mapa
Consuelo
Para Siempre
Viaje Hasta Mañana
Posguerra

Roberto Aleandri: Guitar / Vocals
Diego Martínez - Bass / Vocals
Ignacio Mases - Guitar
Hector Zúñiga - Drums

Live Sound: Pablo Barros 
Audio Mixer: Diego Martínez
Stage: Gustavo Ramazzotti
Assistant: Florencia Russi

-----------------
KEXP live from Argentina is a partnership with the Argentine Ministry of Culture, MICA, and the Kirchner Cultural Center.

Realization, technical production: Centro Cultural Kirchner and KEXP

Host: DJ Chilly
Interpretar: Eugenia Segovia
Sound Engineer: Pablo Nelken
Audio Mastering: Matt Ogaz
Videographers: Jim Beckmann, Sebastián Cáceres, Carlos Cruz & Alaia D’Alessandro
Live Director: Diego Laber
Editor: Carlos Cruz

Art: Lucila Rojo & team (stage design and art)
Lighting: Omar Posematto
Production Assistant: Gonzalo Vazquez
Media Fixer: Melissa Restrepo
Production and communication at Dirección Nacional de Integración Federal y Cooperación Internacional (Ministerio de Cultura de Argentina): Viviana Luna, Paloma Moccia, Pablo Murillo, Marcos Ribas, Lucia Soberal, Luciana Malavolta, Mariana Leder Kremer Hernández

Ministerio de Cultura de Argentina:
Tristán Bauer - Ministro de Cultura de la Nación Argentina
Lucrecia Cardoso - Secretaria de Desarrollo Cultural
Ariela Peretti - Directora Nacional de Integración Federal y Cooperación Internacional

https://atrashaytruenos.bandcamp.com
https://www.argentina.gob.ar/cultura
https://mica.gob.ar/inicio
https://www.cck.gob.ar
http://kexp.org

## Atrás Hay Truenos - Para Siempre (Live on KEXP)
 - [https://www.youtube.com/watch?v=bwjQ4KXuc2g](https://www.youtube.com/watch?v=bwjQ4KXuc2g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-11-03 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present KEXP live from Argentina with Atrás Hay Truenos performing “Para Siempre” live at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded September 22, 2022.

Roberto Aleandri: Guitar / Vocals
Diego Martínez - Bass / Vocals
Ignacio Mases - Guitar
Hector Zúñiga - Drums

Live Sound: Pablo Barros 
Audio Mixer: Diego Martínez
Stage: Gustavo Ramazzotti
Assistant: Florencia Russi

-----------------
KEXP live from Argentina is a partnership with the Argentine Ministry of Culture, MICA, and the Kirchner Cultural Center.

Realization, technical production: Centro Cultural Kirchner and KEXP

Sound Engineer: Pablo Nelken
Audio Mastering: Matt Ogaz
Videographers: Jim Beckmann, Sebastián Cáceres, Carlos Cruz & Alaia D’Alessandro
Live Director: Diego Laber
Editor: Carlos Cruz

Art: Lucila Rojo & team (stage design and art)
Lighting: Omar Posematto
Production Assistant: Gonzalo Vazquez
Media Fixer: Melissa Restrepo
Production and communication at Dirección Nacional de Integración Federal y Cooperación Internacional (Ministerio de Cultura de Argentina): Viviana Luna, Paloma Moccia, Pablo Murillo, Marcos Ribas, Lucia Soberal, Luciana Malavolta, Mariana Leder Kremer Hernández

Ministerio de Cultura de Argentina:
Tristán Bauer - Ministro de Cultura de la Nación Argentina
Lucrecia Cardoso - Secretaria de Desarrollo Cultural
Ariela Peretti - Directora Nacional de Integración Federal y Cooperación Internacional

https://atrashaytruenos.bandcamp.com
https://www.argentina.gob.ar/cultura
https://mica.gob.ar/inicio
https://www.cck.gob.ar
http://kexp.org

## Atrás Hay Truenos - Posguerra (Live on KEXP)
 - [https://www.youtube.com/watch?v=rzzpnZYdQzw](https://www.youtube.com/watch?v=rzzpnZYdQzw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-11-03 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present KEXP live from Argentina with Atrás Hay Truenos performing “Posguerra” live at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded September 22, 2022.

Roberto Aleandri: Guitar / Vocals
Diego Martínez - Bass / Vocals
Ignacio Mases - Guitar
Hector Zúñiga - Drums

Live Sound: Pablo Barros 
Audio Mixer: Diego Martínez
Stage: Gustavo Ramazzotti
Assistant: Florencia Russi

-----------------
KEXP live from Argentina is a partnership with the Argentine Ministry of Culture, MICA, and the Kirchner Cultural Center.

Realization, technical production: Centro Cultural Kirchner and KEXP

Sound Engineer: Pablo Nelken
Audio Mastering: Matt Ogaz
Videographers: Jim Beckmann, Sebastián Cáceres, Carlos Cruz & Alaia D’Alessandro
Live Director: Diego Laber
Editor: Carlos Cruz

Art: Lucila Rojo & team (stage design and art)
Lighting: Omar Posematto
Production Assistant: Gonzalo Vazquez
Media Fixer: Melissa Restrepo
Production and communication at Dirección Nacional de Integración Federal y Cooperación Internacional (Ministerio de Cultura de Argentina): Viviana Luna, Paloma Moccia, Pablo Murillo, Marcos Ribas, Lucia Soberal, Luciana Malavolta, Mariana Leder Kremer Hernández

Ministerio de Cultura de Argentina:
Tristán Bauer - Ministro de Cultura de la Nación Argentina
Lucrecia Cardoso - Secretaria de Desarrollo Cultural
Ariela Peretti - Directora Nacional de Integración Federal y Cooperación Internacional

https://atrashaytruenos.bandcamp.com
https://www.argentina.gob.ar/cultura
https://mica.gob.ar/inicio
https://www.cck.gob.ar
http://kexp.org

## Atrás Hay Truenos - Viaje Hasta Mañana (Live on KEXP)
 - [https://www.youtube.com/watch?v=7IyUcPyY9gA](https://www.youtube.com/watch?v=7IyUcPyY9gA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-11-03 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present KEXP live from Argentina with Atrás Hay Truenos performing “Viaje Hasta Mañana” live at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded September 22, 2022.

Roberto Aleandri: Guitar / Vocals
Diego Martínez - Bass / Vocals
Ignacio Mases - Guitar
Hector Zúñiga - Drums

Live Sound: Pablo Barros 
Audio Mixer: Diego Martínez
Stage: Gustavo Ramazzotti
Assistant: Florencia Russi

-----------------
KEXP live from Argentina is a partnership with the Argentine Ministry of Culture, MICA, and the Kirchner Cultural Center.

Realization, technical production: Centro Cultural Kirchner and KEXP

Sound Engineer: Pablo Nelken
Audio Mastering: Matt Ogaz
Videographers: Jim Beckmann, Sebastián Cáceres, Carlos Cruz & Alaia D’Alessandro
Live Director: Diego Laber
Editor: Carlos Cruz

Art: Lucila Rojo & team (stage design and art)
Lighting: Omar Posematto
Production Assistant: Gonzalo Vazquez
Media Fixer: Melissa Restrepo
Production and communication at Dirección Nacional de Integración Federal y Cooperación Internacional (Ministerio de Cultura de Argentina): Viviana Luna, Paloma Moccia, Pablo Murillo, Marcos Ribas, Lucia Soberal, Luciana Malavolta, Mariana Leder Kremer Hernández

Ministerio de Cultura de Argentina:
Tristán Bauer - Ministro de Cultura de la Nación Argentina
Lucrecia Cardoso - Secretaria de Desarrollo Cultural
Ariela Peretti - Directora Nacional de Integración Federal y Cooperación Internacional

https://atrashaytruenos.bandcamp.com
https://www.argentina.gob.ar/cultura
https://mica.gob.ar/inicio
https://www.cck.gob.ar
http://kexp.org


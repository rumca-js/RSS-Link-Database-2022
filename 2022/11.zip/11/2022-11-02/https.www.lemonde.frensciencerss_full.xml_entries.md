# Source:Le Monde - science, URL:https://www.lemonde.fr/en/science/rss_full.xml, language:en-US

## Amory Lovins: 'Vladimir Putin has just blown up the fossil fuel era'
 - [https://www.lemonde.fr/en/environment/article/2022/11/02/amory-lovins-vladimir-putin-has-just-blown-up-the-fossil-fuel-era_6002684_114.html](https://www.lemonde.fr/en/environment/article/2022/11/02/amory-lovins-vladimir-putin-has-just-blown-up-the-fossil-fuel-era_6002684_114.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2022-11-02 14:30:08+00:00

In an interview with 'Le Monde,' American scientist Amory Lovins, an ardent defender of energy efficiency and renewables, shares his belief that the war in Ukraine has triggered a determined move toward more sustainable energy in Europe.


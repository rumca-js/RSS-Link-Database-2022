# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## New Silmarillion Audiobook on the way, Fall of Númenor Sneak Peek, Open Q&A! | NERD MOOT
 - [https://www.youtube.com/watch?v=N1k3lkCf1Cw](https://www.youtube.com/watch?v=N1k3lkCf1Cw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-11-03 00:00:00+00:00

-Andy Serkis revealed he is recording a new Tolkien Audiobook - the Silmarillion. (Andy Serkis narrates "The Lord of the Rings": https://amzn.to/3gWuRP7 )

-Next week brings the release of The Fall of Númenor! ( https://amzn.to/3Dp4j0o )

-More LOTR gaming tidbits, open Q&A, and is Rings of Power adjusting course for season 2?

#silmarillion #lordoftherings #tolkien


## Making Music Is Impossible
 - [https://www.youtube.com/watch?v=SD4oHz-onBA](https://www.youtube.com/watch?v=SD4oHz-onBA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCI7kKmUuSQOHUvSWIYFDf1Q
 - date published: 2022-11-02 20:38:43+00:00

📂Documents
  └📁 FL Studio
      └📁 Nate.exe
           └⚠️ This application has stopped working

• TWITCH: https://www.twitch.tv/eliminatehq
• DISCORD: https://discord.gg/eliminatehq
• MY SAMPLE PACK: https://splice.com/sounds/disciple-samples/eliminate-cyber-trap-vol-1?sound_type=sample
• INSTAGRAM: https://www.instagram.com/eliminatemusic/
• TWITTER: https://twitter.com/eliminatemusic
• SUBREDDIT: https://www.reddit.com/r/EliminateHQ/

Primal Rights:
https://soundcloud.com/primalrights
https://www.instagram.com/primalrightsmusic/?hl=en
https://www.youtube.com/channel/UCi5XRiZo5NXhWrOXv0XMcnw

top secret burner account:
https://soundcloud.com/dubsteptractor


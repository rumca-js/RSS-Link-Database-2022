# Source:Niebezpiecznik, URL:https://feeds.feedburner.com/niebezpiecznik/, language:pl-PL

## Czy warto zainstalować aplikację mobilną swojego banku?
 - [https://niebezpiecznik.pl/post/czy-warto-zainstalowac-aplikacje-mobilna-swojego-banku/](https://niebezpiecznik.pl/post/czy-warto-zainstalowac-aplikacje-mobilna-swojego-banku/)
 - RSS feed: https://feeds.feedburner.com/niebezpiecznik/
 - date published: 2022-11-02 18:37:19+00:00

<a href="https://niebezpiecznik.pl/post/czy-warto-zainstalowac-aplikacje-mobilna-swojego-banku/"><img align="left" alt="" class="alignleft tfe wp-post-image" height="100" hspace="5" src="https://niebezpiecznik.pl/wp-content/uploads/2022/10/pko-min-150x150.jpg" width="100" /></a>Niektórzy z Was boją się aplikacji mobilnych swoich banków. Czasem piszecie do nas i pytacie &#8220;czy apka banku jest bezpieczna&#8221;? Albo wprost informujecie nas, że apki banku nie zainstalujecie i pytacie co Wam grozi, jeśli pozostaniecie przy potwierdzaniu transakcji SMS-em? Czy strach przed instalacją aplikacji mobilnej banku jest uzasadniony? Dziś spróbujemy odpowiedzieć na te pytania. [&#8230;]

## Minęło 13 lat od startu Niebezpiecznika&#8230;
 - [https://niebezpiecznik.pl/post/minelo-13-lat-od-startu-niebezpiecznika/](https://niebezpiecznik.pl/post/minelo-13-lat-od-startu-niebezpiecznika/)
 - RSS feed: https://feeds.feedburner.com/niebezpiecznik/
 - date published: 2022-11-02 13:48:45+00:00

<a href="https://niebezpiecznik.pl/post/minelo-13-lat-od-startu-niebezpiecznika/"><img align="left" alt="" class="alignleft tfe wp-post-image" height="100" hspace="5" src="https://niebezpiecznik.pl/wp-content/uploads/2022/11/trenerzy3-150x150.jpg" width="100" /></a>W Halloween minęło 13 lat od pierwszego artykułu, który opublikowaliśmy na Niebezpieczniku. Dla większości naszych Czytelników jesteśmy wyłącznie serwisem piszącym o bezpieczeństwie i nawet ci, którzy czytają Niebezpiecznika regularnie, często dziwią się, kiedy idąc na firmowe szkolenie z bezpieczeństwa, spotykają kogoś od nas w roli trenera. Nie wszyscy wiedzą, że poza pisaniem o bezpieczeństwie szkolimy [&#8230;]


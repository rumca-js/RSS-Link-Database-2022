# Source:John Harris, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmGSJVG3mCRXVOP4yZrU1Dw, language:en-US

## The REAL Reason Europe Took Over the World
 - [https://www.youtube.com/watch?v=9XECUXXbjhU](https://www.youtube.com/watch?v=9XECUXXbjhU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmGSJVG3mCRXVOP4yZrU1Dw
 - date published: 2022-11-02 00:00:00+00:00

How Europe Stole the World, Part 2
To start comparing quotes and simplify insurance-buying, check out Policygenius: https://policygenius.com/johnnyharris. Thanks to Policygenius for sponsoring this video!

The modern corporation was invented as a way to fuel imperialism. In Part 2 of our series on European imperialism we explore how Europe created private empires to help spread dominance and resource extraction across the globe.

Watch Part 1 here: https://youtu.be/vLpSeMlfZ60

Check out all my sources for this video here: https://docs.google.com/document/d/1-MJxsFIqSo-6exOlye1DDVq1ZdsCDIwC2VYR1gOd6so/edit?usp=sharing

- ways to support - 
My Patreon: https://www.patreon.com/johnnyharris
Our custom Presets & LUTs: https://store.dftba.com/products/johnny-iz-luts-and-presets

- where to find me -
Instagram: https://www.instagram.com/johnny.harris/
Tiktok: https://www.tiktok.com/@johnny.harris
Facebook: https://www.facebook.com/JohnnyHarrisVox
Iz's (my wife’s) channel: https://www.youtube.com/iz-harris

- how i make my videos -
Tom Fox makes my music, work with him here: https://tfbeats.com/
I make maps using this AE Plugin: https://aescripts.com/geolayers/?aff=77
All the gear I use: https://www.izharris.com/gear-guide
 
- my courses - 
Learn a language: https://brighttrip.com/course/language/
Visual storytelling: https://www.brighttrip.com/courses/visual-storytelling

- about -
Johnny Harris is an Emmy-winning journalist. He currently is based in Washington, DC, reporting on interesting trends and stories domestically and around the globe. Johnny's visual style blends motion graphics with cinematic videography to create content that explains complex issues in relatable ways.

- press - 
NYTimes: https://www.nytimes.com/2021/11/09/opinion/democrats-blue-states-legislation.html
NYTimes: https://www.nytimes.com/video/opinion/100000007358968/covid-pandemic-us-response.html
Vox Borders: https://www.youtube.com/watch?v=hLrFyjGZ9NU
Finding Founders: https://findingfounders.co/episodes/johnny-harris-2esj3-c3pet-2pg4c-xbtwa-5gaaa
NPR Planet Money: https://www.npr.org/transcripts/1072164745


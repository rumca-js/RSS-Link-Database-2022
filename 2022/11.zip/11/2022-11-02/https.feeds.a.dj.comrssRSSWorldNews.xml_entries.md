# Source:The Wall Street Journal, URL:https://feeds.a.dj.com/rss/RSSWorldNews.xml, language:en-US

## Ethiopia, Tigrayan Rebels Reach Truce in Two-Year Civil War
 - [https://www.wsj.com/articles/ethiopia-tigrayan-rebels-reach-truce-in-two-year-civil-war-11667418320](https://www.wsj.com/articles/ethiopia-tigrayan-rebels-reach-truce-in-two-year-civil-war-11667418320)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2022-11-02 19:45:00+00:00

The African Union-mediated deal could help end a conflict marked by widespread atrocities that has left hundreds of thousands dead.

## Iran's Supreme Leader Strikes Conciliatory Tone With Protesters
 - [https://www.wsj.com/articles/irans-supreme-leader-strikes-conciliatory-tone-with-protesters-11667405026](https://www.wsj.com/articles/irans-supreme-leader-strikes-conciliatory-tone-with-protesters-11667405026)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2022-11-02 17:51:00+00:00

Ali Khamenei steps up claims that U.S., Israel and Europe are inciting the monthslong protest movement, without providing evidence.

## Who Is China's New No. 2? A Business Pragmatist or a Party Loyalist?
 - [https://www.wsj.com/articles/china-li-qiang-xi-jinping-11667399077](https://www.wsj.com/articles/china-li-qiang-xi-jinping-11667399077)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWorldNews.xml
 - date published: 2022-11-02 14:54:00+00:00

Li Qiang’s record suggests he could serve as a moderating influence on Xi Jinping, but he has also fallen in line when it mattered.


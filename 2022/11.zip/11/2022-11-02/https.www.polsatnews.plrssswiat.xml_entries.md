# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## USA. Policjanci przebrali policyjne konie za duchy. Wytknięto podobieństwo do Ku Klux Klanu
 - [https://www.polsatnews.pl/wiadomosc/2022-11-02/usa-policjanci-przebrali-policyjne-konie-za-duchy-wytknieto-podobienstwo-do-ku-klux-klanu/](https://www.polsatnews.pl/wiadomosc/2022-11-02/usa-policjanci-przebrali-policyjne-konie-za-duchy-wytknieto-podobienstwo-do-ku-klux-klanu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-02 20:52:00+00:00

Policjanci z Ohio wywołali oburzenie po tym, jak przebrali swoje konie na Halloween w białe prześcieradła z otworami wyciętymi na oczach. Według tłumaczeń szeryfa chodziło o przebranie na Halloween, a konie miały przypominać duchy. Niektórzy mieszkańcy wytknęli jednak łudzące podobieństwo do Ku Klux Klanu.

## Holandia. Przykleili się do "Dziewczyny z perłą". Idą na miesiąc do więzienia
 - [https://www.polsatnews.pl/wiadomosc/2022-11-02/holandia-przykleili-sie-do-dziewczyny-z-perla-ida-na-miesiac-do-wiezienia/](https://www.polsatnews.pl/wiadomosc/2022-11-02/holandia-przykleili-sie-do-dziewczyny-z-perla-ida-na-miesiac-do-wiezienia/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-02 20:51:00+00:00

Dwaj działacze klimatyczni, którzy zaatakowali w Holandii bezcenny, znany na całym świecie obraz Dziewczyna z perłą, otrzymali złagodzony o połowę wyrok, bo sędzia uznała, że nie chce zniechęcać do protestowania. Aktywiści weszli do muzeum, jeden z nich przykleił głowę do szyby chroniącej dzieło, drugi przykleił do ściany obok rękę. Kara to dwa miesiące więzienia, w tym jeden w zawieszeniu.

## USA. Modelka znana z OnlyFans miała zabić swojego chłopaka. Jest nagranie ich bójki
 - [https://www.polsatnews.pl/wiadomosc/2022-11-02/usa-modelka-only-fans-zabila-swojego-chlopaka-nagranie-z-windy-pokazuje-ich-bojke/](https://www.polsatnews.pl/wiadomosc/2022-11-02/usa-modelka-only-fans-zabila-swojego-chlopaka-nagranie-z-windy-pokazuje-ich-bojke/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-02 19:53:00+00:00

26-letnia modelka i influencerka Courtney Clenney została oskarżona o zabójstwo po tym, jak śmiertelnie dźgnęła nożem swojego chłopaka. Jej adwokat twierdzi, że kobieta działała w samoobronie. W sieci pojawiło się nagranie z windy, na którym 26-latka bije i obraża swojego partnera.

## Wojna w Ukrainie. Niosą pomoc zwierzętom na froncie. "Nawet chomika uratowali"
 - [https://www.polsatnews.pl/wiadomosc/2022-11-02/wojna-w-ukrainie-niosa-pomoc-zwierzetom-na-froncie-nawet-chomika-uratowali/](https://www.polsatnews.pl/wiadomosc/2022-11-02/wojna-w-ukrainie-niosa-pomoc-zwierzetom-na-froncie-nawet-chomika-uratowali/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-02 19:10:00+00:00

Ukraińscy żołnierze i wolontariusze ratują w strefie walk zwierzęta, które straciły domy i opiekunów. W sieci pojawiło się nagranie żołnierza, który z patrolu przyniósł chomika w klatce. W Bachmucie uratowano szczeniaka uwięzionego w zrujnowanym domu, którego czekała niechybna śmierć, bo miał pysk uwięziony w konserwie. Jest wiele takich zwierząt - pisze doradca szefa MSW Anton Heraszczenko.

## Rosja. Oświadczenie MSZ o "zapobieganiu użycia broni nuklearnej"
 - [https://www.polsatnews.pl/wiadomosc/2022-11-02/rosja-oswiadczenie-msz-o-zapobieganiu-uzycia-broni-nuklearnej/](https://www.polsatnews.pl/wiadomosc/2022-11-02/rosja-oswiadczenie-msz-o-zapobieganiu-uzycia-broni-nuklearnej/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-02 17:06:00+00:00

Z Rosji w ostatnim czasie płyną niejasne, a czasem sprzeczne komunikaty dotyczące możliwości użycia broni atomowej w Ukrainie. We wtorek były prezydent i premier Dmitrij Miedwiediew przekazał, że taki scenariusz może być realny. W środę tamtejsze MSZ wydało oświadczenie o niedopuszczalności wojny nuklearnej. Zmienia się również narracja samego Władimira Putina w tej kwestii.

## Wojna w Ukrainie. Wstrząsające nagranie z Mariupola. Miasto wygląda jak Warszawa w 1944 roku
 - [https://www.polsatnews.pl/wiadomosc/2022-11-02/wojna-w-ukrainie-wstrzasajace-nagranie-z-mariupola-miasto-wyglada-jak-warszawa-w-1944-roku/](https://www.polsatnews.pl/wiadomosc/2022-11-02/wojna-w-ukrainie-wstrzasajace-nagranie-z-mariupola-miasto-wyglada-jak-warszawa-w-1944-roku/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-02 16:14:00+00:00

W mediach społecznościowych pojawiło się wstrząsające nagranie z okupowanego i anektowanego przez Rosję portowego miasta Mariupol w obwodzie donieckim. Z wideo nagranego z auta jadącego ulicami Miasta-Bohatera Ukrainy wynika, że nie ocalał tam żaden budynek. Wszystko wokół jest zrujnowane przez ostrzały i bombardowania. Tak wygląda wyzwalanie przez Rosję - piszą w komentarzach internauci.

## Rosja. Awaryjne lądowanie samolotu Ural Airlines. W maszynie zacięły się hamulce i pękły opony
 - [https://www.polsatnews.pl/wiadomosc/2022-11-02/rosja-awaryjne-ladowanie-samolotu-ural-airlines-w-maszynie-zaciely-sie-hamulce-i-pekly-opony/](https://www.polsatnews.pl/wiadomosc/2022-11-02/rosja-awaryjne-ladowanie-samolotu-ural-airlines-w-maszynie-zaciely-sie-hamulce-i-pekly-opony/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-02 14:29:00+00:00

Airbus A-320 należący do rosyjskich linii Ural Airlines wylądował awaryjnie na lotnisku w Irkucku (Syberia). Według medialnych doniesień, w samolocie zacięły się hamulce i z tego powodu podczas lądowania pękły także cztery opony. Na pokładzie było ponad 82 pasażerów i sześciu członków załogi. Nikt nie został ranny.

## Holandia. Nielegalne posterunki chińskiej policji w Amsterdamie i Rotterdamie. Reakcja rządu
 - [https://www.polsatnews.pl/wiadomosc/2022-11-02/holandia-nielegalne-posterunki-chinskiej-policji-w-amsterdamie-i-rotterdamie-reakcja-rzadu/](https://www.polsatnews.pl/wiadomosc/2022-11-02/holandia-nielegalne-posterunki-chinskiej-policji-w-amsterdamie-i-rotterdamie-reakcja-rzadu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-02 14:15:00+00:00

Szef holenderskiej dyplomacji Wopke Hoekstra wydał nakaz natychmiastowego zamknięcia funkcjonujących w kraju chińskich biur administracyjnych. Dziennikarskie śledztwo ujawniło poszlaki wskazujące, że mogą one służyć chińskiej policji do kontroli i wpływania na obywateli Chin w Niderlandach. Szef MSZ podał, że nigdy nie było zgody na funkcjonowanie posterunków w związku z czym są nielegalne.

## Łatwiej zostać nowym Jamesem Bondem. Brytyjski wywiad łagodzi zasady rekrutacji
 - [https://www.polsatnews.pl/wiadomosc/2022-11-02/latwiej-zostac-nowym-jamesem-bondem-brytyjski-wywiad-lagodzi-zasady-rekrutacji/](https://www.polsatnews.pl/wiadomosc/2022-11-02/latwiej-zostac-nowym-jamesem-bondem-brytyjski-wywiad-lagodzi-zasady-rekrutacji/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-02 13:42:00+00:00

MI5, MI6 i GCHQ zmieniają zasady narodowości dla nowych rekrutów. Agencje szpiegowskie w Wielkiej Brytanii nie będą już szukać kandydatów z co najmniej jednym brytyjskim rodzicem.

## Seria wpadek Joe Bidena. Pomylił wojny oraz okoliczności śmierci swojego syna
 - [https://www.polsatnews.pl/wiadomosc/2022-11-02/seria-wpadek-joe-bidena-pomylil-wojny-oraz-okolicznosci-smierci-swojego-syna/](https://www.polsatnews.pl/wiadomosc/2022-11-02/seria-wpadek-joe-bidena-pomylil-wojny-oraz-okolicznosci-smierci-swojego-syna/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-02 13:05:00+00:00

Joe Biden zaliczył serię wpadek podczas wizyty na Florydzie. Podczas swojego przemówienia prezydent USA pomylił wojnę w Ukrainie z wojną w Iraku oraz okoliczności śmierci swojego syna. Następnie stwierdził, że rozmawiał z człowiekiem, który wynalazł insulinę, mimo że lekarz ten zmarł przed jego narodzinami.

## Australia: Stado lwów uciekło z zagrody w zoo. Włączono ogłuszający alarm
 - [https://www.polsatnews.pl/wiadomosc/2022-11-02/australia-stado-lwow-ucieklo-z-zagrody-wlaczono-ogluszajacy-alarm/](https://www.polsatnews.pl/wiadomosc/2022-11-02/australia-stado-lwow-ucieklo-z-zagrody-wlaczono-ogluszajacy-alarm/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-02 13:04:00+00:00

Pięć lwów wydostało się z zagrody w zoo w Sydney. Personel i odwiedzając musieli ukryć się w bezpiecznych strefach. Na terenie ogrodu rozległ się ogłuszający alarm.

## Kumulacje w Eurojackpot i Powerball. Od tygodni nikt nie skreślił właściwych liczb
 - [https://www.polsatnews.pl/wiadomosc/2022-11-02/kumulacje-w-eurojackpot-i-powerball-od-tygodni-nikt-nie-skreslil-wlasciwych-liczb/](https://www.polsatnews.pl/wiadomosc/2022-11-02/kumulacje-w-eurojackpot-i-powerball-od-tygodni-nikt-nie-skreslil-wlasciwych-liczb/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-02 10:43:00+00:00

570 milionów złotych czeka na szczęśliwca, który najpóźniej w piątek poprawnie skreśli siedem liczb na kuponie Eurojackpot. O tę bajońską sumę rywalizują mieszkańcy 18 europejskich krajów, w tym Polski. Marzenia o fortunie mogą snuć również Amerykanie. W ich kraju od sierpnia ani razu nie padła główna wygrana w grze Powerball. Do wzięcia jest tam grubo ponad miliard dolarów.

## Niemcy: Polka awanturowała się na dworcu. Rzucała w pasażerów szklanymi butelkami
 - [https://www.polsatnews.pl/wiadomosc/2022-11-02/niemcy-polka-awanturowala-sie-na-dworcu-rzucala-w-pasazerow-szklanymi-butelkami/](https://www.polsatnews.pl/wiadomosc/2022-11-02/niemcy-polka-awanturowala-sie-na-dworcu-rzucala-w-pasazerow-szklanymi-butelkami/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-02 10:38:00+00:00

Na dworcu głównym w Essen pijana Polka rzucała butelkami w podróżnych. Podczas próby zatrzymania 53-latka kopała i znieważała policjantów.

## Niemcy. Trzech Polaków zatrzymanych w ciągu godziny. Każdy miał coś na sumieniu
 - [https://www.polsatnews.pl/wiadomosc/2022-11-02/niemcy-trzech-polakow-zatrzymanych-w-ciagu-godziny-kazdy-mial-cos-na-sumieniu/](https://www.polsatnews.pl/wiadomosc/2022-11-02/niemcy-trzech-polakow-zatrzymanych-w-ciagu-godziny-kazdy-mial-cos-na-sumieniu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-02 10:03:00+00:00

Niemieccy policjanci patrolujący autostradę A 11 w okolicach Pasewalk pochwalili się swoimi ostatnimi działami. Jak poinformowano, funkcjonariusze w ciągu godziny zatrzymali trzech Polaków. Każdy z nich miał coś na sumieniu.

## Indie. Zbiorowy gwałt na 14-latce. Aresztowano pięciu mężczyzn
 - [https://www.polsatnews.pl/wiadomosc/2022-11-02/indie-zbiorowy-gwalt-na-14-latce-aresztowanych-pieciu-mezczyzn/](https://www.polsatnews.pl/wiadomosc/2022-11-02/indie-zbiorowy-gwalt-na-14-latce-aresztowanych-pieciu-mezczyzn/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-02 09:48:00+00:00

14-latka z Indii padła ofiarą zbiorowego gwałtu. Dziewczynka została zwabiona do hotelu przez dwóch znanych jej mężczyzn, którzy następnie sprowadzili kolegów. Łącznie zatrzymanych zostało pięciu mężczyzn.

## Holandia: Squattersi przejęli dom rosyjskiego oligarchy. "Przeciw wojnie i kapitalizmowi"
 - [https://www.polsatnews.pl/wiadomosc/2022-11-02/holandia-squattersi-przejeli-dom-rosyjskiego-oligarchy-przeciw-wojnie-i-kapitalizmowi/](https://www.polsatnews.pl/wiadomosc/2022-11-02/holandia-squattersi-przejeli-dom-rosyjskiego-oligarchy-przeciw-wojnie-i-kapitalizmowi/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-02 09:37:00+00:00

Squattersi wprowadzili się do domu w Amsterdamie, który należy do rosyjskiego miliardera Arkadego Volozha, założyciela wyszukiwarki Yandex. Twierdzą, że okupacja budynku jest wymierzona przeciwko rosyjskiej inwazji na Ukrainę. Chcą zwrócić także uwagę na kryzys mieszkaniowy, w którym prawa miliarderów są lepiej chronione niż prawa osób bezbronnych.

## USA. Uczniowie zabili nauczycielkę. Powodem była zła ocena
 - [https://www.polsatnews.pl/wiadomosc/2022-11-02/usa-uczniowie-zabili-nauczycielke-powodem-byla-zla-ocena/](https://www.polsatnews.pl/wiadomosc/2022-11-02/usa-uczniowie-zabili-nauczycielke-powodem-byla-zla-ocena/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-02 08:34:00+00:00

Dwaj uczniowie z amerykańskiego stanu Iowa zabili swoją nauczycielkę języka hiszpańskiego. Według prokuratury nastolatkowie zabili 66-letnią kobietę z powodu złej oceny, którą wystawiła jednemu z nich.

## Włochy. Konfiskata samochodu za nielegalne wyrzucanie śmieci
 - [https://www.polsatnews.pl/wiadomosc/2022-11-02/wlochy-konfiskata-samochodu-za-nielegalne-wyrzucanie-smieci/](https://www.polsatnews.pl/wiadomosc/2022-11-02/wlochy-konfiskata-samochodu-za-nielegalne-wyrzucanie-smieci/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-02 05:58:00+00:00

Władze miejscowości Santa Croce Camerina na Sycylii wypowiedziały wojnę ludziom nielegalnie wyrzucającym śmieci. Aby ukrócić podobne zachowania wprowadzono tam nowe przepisy, które przewidują konfiskatę samochodu za ten proceder.

## Korea Północna grozi Stanom Zjednoczonym i Korei Południowej użyciem broni jądrowej
 - [https://www.polsatnews.pl/wiadomosc/2022-11-02/korea-polnocna-grozi-stanom-zjednoczonym-i-korei-poludniowej-uzyciem-broni-jadrowej/](https://www.polsatnews.pl/wiadomosc/2022-11-02/korea-polnocna-grozi-stanom-zjednoczonym-i-korei-poludniowej-uzyciem-broni-jadrowej/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-02 05:32:00+00:00

W odpowiedzi na wspólne ćwiczenia wojskowe Stanów Zjednoczonych i Korei Południowej, Korea Północna wydała zawoalowaną groźbę użycia broni jądrowej przeciwko tym dwóm krajom - podaje agencja AP. Tymczasem w środę rano czasu lokalnego Korea Płn. wystrzeliła 10 pocisków różnego rodzaju w kierunku wschodnim i zachodnim.


# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## God of War Ragnarok - Before You Buy
 - [https://www.youtube.com/watch?v=2HbRS-Y8gAo](https://www.youtube.com/watch?v=2HbRS-Y8gAo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-11-03 00:00:00+00:00

God of War Ragnarok (PS4, PS5) is a worthy followup to 2018's God of War. Let's dive in spoiler free.
Subscribe for more: http://youtube.com/gameranxtv ▼▼

Buy God of War: https://amzn.to/3T41HuE


Watch more 'Before You Buy': https://bit.ly/2kfdxI6

Friends Per Second Podcast: https://linktr.ee/friendspersecond

Jake's other channel: https://youtu.be/VU-iv1AnO24




#godofwar #godofwarragnarok

## 10 Alternate Paths That Took You Somewhere Completely DIFFERENT
 - [https://www.youtube.com/watch?v=7HXJ164uXAM](https://www.youtube.com/watch?v=7HXJ164uXAM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-11-02 00:00:00+00:00

Some games lead you on "wild goose chases" that bring you to completely unexpected places. Here are some of our favorite crazy examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:17 Far Cry 6
1:49 Nier: Automata
3:02 Metal Slug 3
4:12 The Stanley Parable
5:28 Mass Effect 2
6:57 Contra: Hard Corps
8:36 Star Fox
9:37 Live a Live
10:37 Deltarune Chapter 2
11:35 True Crime: Streets of L.A.

## Pokemon Scarlet and Violet: 10 Things You NEED TO KNOW
 - [https://www.youtube.com/watch?v=hiRNILFDoDM](https://www.youtube.com/watch?v=hiRNILFDoDM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-11-02 00:00:00+00:00

Pokémon Scarlet and Violet is releasing soon on Nintendo Switch so here’s EVERYTHING you need to know before jumping in.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:17 number 10
1:42 number 9
3:18 number 8
5:00 number 7
5:35 number 6
6:23 number 5
7:33 number 4
8:43 number 3
9:42 number 2
10:48 number 1


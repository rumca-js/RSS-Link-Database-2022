# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Regenerative Farmer Will Harris on Whole Foods and Green Washing
 - [https://www.youtube.com/watch?v=--4yKHWxjJ0](https://www.youtube.com/watch?v=--4yKHWxjJ0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-11-03 00:00:00+00:00

Taken from JRE #1893 w/Will Harris:
https://open.spotify.com/episode/0qf7CYEhxSFPAcdSw1JJMY?si=a7c053110120470b

## The Sober October Guys See Who Can Do the Most Push-Ups
 - [https://www.youtube.com/watch?v=oyr4465J62o](https://www.youtube.com/watch?v=oyr4465J62o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-11-02 00:00:00+00:00

Taken from JRE #1892 Sober October Recap:
https://open.spotify.com/episode/7i0HTQPr9NIyDctQzMCvYE?si=9c7df01b55b0421e

## Tom Segura's Obsession with Garth Brooks
 - [https://www.youtube.com/watch?v=hX5QV_q4iAM](https://www.youtube.com/watch?v=hX5QV_q4iAM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-11-02 00:00:00+00:00

Taken from JRE #1892 Sober October Recap:
https://open.spotify.com/episode/7i0HTQPr9NIyDctQzMCvYE?si=9c7df01b55b0421e


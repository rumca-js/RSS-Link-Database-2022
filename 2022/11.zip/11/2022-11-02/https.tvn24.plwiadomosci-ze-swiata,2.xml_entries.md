# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Kaczyński o parach jednopłciowych, dzieciach i wzywaniu na policję. O jaką historię chodzi?
 - [https://konkret24.tvn24.pl/polityka/jaroslaw-kaczynski-o-parach-jednoplciowych-dzieciach-i-wzywaniu-na-policje-o-jaka-historie-chodzi-6187951?source=rss](https://konkret24.tvn24.pl/polityka/jaroslaw-kaczynski-o-parach-jednoplciowych-dzieciach-i-wzywaniu-na-policje-o-jaka-historie-chodzi-6187951?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-11-02 15:00:20+00:00

<img alt="Kaczyński o parach jednopłciowych, dzieciach i wzywaniu na policję. O jaką historię chodzi? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-gb2lk0-jaroslaw-kaczynski-w-radomiu-6190076/alternates/LANDSCAPE_1280" />
    Opowieść o tym, jakoby w Anglii za publiczne stwierdzenie, że "z par jednopłciowych nie ma dzieci", można mieć problemy z policją, wraca w kolejnych wypowiedziach Jarosława Kaczyńskiego. Poszukaliśmy, którą historię z Wielkiej Brytanii prezes może mieć na myśli.

## Nie żyje Julie Powell, miała 49 lat. Jej historia stała się inspiracją dla filmu "Julie i Julia"
 - [https://tvn24.pl/kultura-i-styl/julie-powell-nie-zyje-miala-49-lat-jej-historia-stala-sie-inspiracja-dla-filmu-julie-i-julia-6189730?source=rss](https://tvn24.pl/kultura-i-styl/julie-powell-nie-zyje-miala-49-lat-jej-historia-stala-sie-inspiracja-dla-filmu-julie-i-julia-6189730?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-11-02 07:59:36+00:00

<img alt="Nie żyje Julie Powell, miała 49 lat. Jej historia stała się inspiracją dla filmu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ku4kp8-julie-powell-w-2009-roku-6189744/alternates/LANDSCAPE_1280" />
    W wieku 49 lat zmarła Julie Powell, autorka bloga kulinarnego, w którym odtwarzała dania legendarnej amerykańskiej kucharki Julii Child. Zamieszczane na nim przepisy w 2005 roku zostały wydane w formie książki. Historia Powell zainspirowała Norę Ephron do nakręcenia filmu "Julie i Julia" z Meryl Streep i Amy Adams w rolach głównych, który stał się kinowym hitem również w Polsce.


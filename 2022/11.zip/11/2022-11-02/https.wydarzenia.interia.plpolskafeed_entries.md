# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Korea Północna wystrzeliła kolejne pociski w kierunku Morza Japońskiego i Żółtego
 - [https://wydarzenia.interia.pl/kraj/news-korea-polnocna-wystrzelila-kolejne-pociski-w-kierunku-morza-,nId,6385603](https://wydarzenia.interia.pl/kraj/news-korea-polnocna-wystrzelila-kolejne-pociski-w-kierunku-morza-,nId,6385603)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-11-02 13:05:49+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-korea-polnocna-wystrzelila-kolejne-pociski-w-kierunku-morza-,nId,6385603"><img align="left" alt="Korea Północna wystrzeliła kolejne pociski w kierunku Morza Japońskiego i Żółtego" src="https://i.iplsc.com/korea-polnocna-wystrzelila-kolejne-pociski-w-kierunku-morza/000FACT0U9Q0QQH8-C321.jpg" /></a>Korea Północna wystrzeliła w środę po południu w kierunku Morza Japońskiego i Żółtego kolejnych sześć pocisków - ogłosiła armia Korei Południowej. Wcześniej tego dnia informowano o 100 pociskach artyleryjskich i co najmniej 17 balistycznych, z których jedna spadła niedaleko wybrzeża Korei Płd. Taka sytuacja miała miejsce po raz pierwszy od zakończenia wojny koreańskiej w 1953 roku.</p><br clear="all" />

## Polski atom coraz bliżej. Jest uchwała Rady Ministrów
 - [https://wydarzenia.interia.pl/kraj/news-polski-atom-coraz-blizej-jest-uchwala-rady-ministrow,nId,6385368](https://wydarzenia.interia.pl/kraj/news-polski-atom-coraz-blizej-jest-uchwala-rady-ministrow,nId,6385368)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-11-02 11:45:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-polski-atom-coraz-blizej-jest-uchwala-rady-ministrow,nId,6385368"><img align="left" alt="Polski atom coraz bliżej. Jest uchwała Rady Ministrów" src="https://i.iplsc.com/polski-atom-coraz-blizej-jest-uchwala-rady-ministrow/000GA7Y8IGO5OYUB-C321.jpg" /></a>Premier Mateusz Morawiecki przekazał, że rząd przyjął uchwałę w sprawie budowy wielkoskalowych elektrowni jądrowych w Polsce. Pierwszą elektrownię wybudują Amerykanie. -Elektrownie jądrowe będą bezpiecznikiem systemu energetycznego Polski - mówił premier.</p><br clear="all" />

## Zaduszki 2022. Czy trzeba iść do kościoła?
 - [https://wydarzenia.interia.pl/kraj/news-zaduszki-2022-czy-trzeba-isc-do-kosciola,nId,6355418](https://wydarzenia.interia.pl/kraj/news-zaduszki-2022-czy-trzeba-isc-do-kosciola,nId,6355418)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-11-02 06:58:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zaduszki-2022-czy-trzeba-isc-do-kosciola,nId,6355418"><img align="left" alt="Zaduszki 2022. Czy trzeba iść do kościoła?" src="https://i.iplsc.com/zaduszki-2022-czy-trzeba-isc-do-kosciola/000G7UKKOAFA5UX3-C321.jpg" /></a>1 listopada już niedługo, a to oznacza, że trzeba zacząć przygotowania na Dzień Wszystkich Świętych. To czas zadumy, który powinniśmy spędzić, odwiedzając groby krewnych na cmentarzach. Poza zapaleniem symbolicznego znicza mamy jednak również możliwość uczestnictwa w mszy świętej, dlatego wyjaśniamy, czy we Wszystkich Świętych trzeba iść do kościoła. Przypominamy, czy 1 listopada jest dniem wolnym od pracy i podajemy różnicę pomiędzy Dniem Wszystkich Świętych a Zaduszkami.</p><br clear="all" />

## Zaduszki. Co to za święto i kiedy wypada Święto Zmarłych?
 - [https://wydarzenia.interia.pl/kraj/news-zaduszki-co-to-za-swieto-i-kiedy-wypada-swieto-zmarlych,nId,6360006](https://wydarzenia.interia.pl/kraj/news-zaduszki-co-to-za-swieto-i-kiedy-wypada-swieto-zmarlych,nId,6360006)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-11-02 05:01:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zaduszki-co-to-za-swieto-i-kiedy-wypada-swieto-zmarlych,nId,6360006"><img align="left" alt="Zaduszki. Co to za święto i kiedy wypada Święto Zmarłych?" src="https://i.iplsc.com/zaduszki-co-to-za-swieto-i-kiedy-wypada-swieto-zmarlych/000G7UKKOAFA5UX3-C321.jpg" /></a>Zaduszki - czyli inaczej Dzień Zaduszny lub Święto Zmarłych - obchodzimy co roku 2 listopada. Uroczystość przypada zawsze po Wszystkich Świętych. Odwiedzamy wówczas cmentarze, zapalając na grobach znicze i stawiając kwiaty. Historia święta jest dosyć długa, choć nie każdy ją zna. Co warto o nim wiedzieć?</p><br clear="all" />


# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## Amazon, Snap partner to let customers shop for eyewear in AR
 - [https://www.zdnet.com/article/amazon-snap-partner-to-let-customers-shop-for-eyewear-in-ar/#ftag=RSSbaffb68](https://www.zdnet.com/article/amazon-snap-partner-to-let-customers-shop-for-eyewear-in-ar/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 22:34:29+00:00

Amazon Fashion is partnering with Snapchat to reach the increasing number of customers who are shopping on their smartphones.

## Google makes massive commitment to support more languages using AI
 - [https://www.zdnet.com/article/google-makes-massive-commitment-to-support-more-languages-using-ai/#ftag=RSSbaffb68](https://www.zdnet.com/article/google-makes-massive-commitment-to-support-more-languages-using-ai/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 21:05:21+00:00

To bring information to more people across the globe, Google will build an AI model that can support 1,000 languages.

## The Renpho Eye Massager just dropped to less than $70 on Amazon
 - [https://www.zdnet.com/article/renpho-eye-massager-deal-coupon-promo-code/#ftag=RSSbaffb68](https://www.zdnet.com/article/renpho-eye-massager-deal-coupon-promo-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 20:57:07+00:00

If you struggle to fall asleep after long days staring at a screen, the Renpho Eye Massager may help relieve dry eyes and forehead tension. Right now, it's 46% off on Amazon.

## Google Assistant updates make it more kid-friendly
 - [https://www.zdnet.com/home-and-office/smart-home/google-assistant-updates-make-it-more-kid-friendly-than-ever/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-home/google-assistant-updates-make-it-more-kid-friendly-than-ever/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 20:54:00+00:00

New Assistant updates include parental controls, a kid's dictionary, and four new kid-friendly voices.

## Google Assistant updates make it more kid friendly
 - [https://www.zdnet.com/article/google-assistant-updates-make-it-more-kid-friendly-than-ever/#ftag=RSSbaffb68](https://www.zdnet.com/article/google-assistant-updates-make-it-more-kid-friendly-than-ever/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 20:20:50+00:00

New Assistant updates include parental controls, a kid's dictionary and four new kid-friendly voices.

## The 5 best outdoor TVs of 2022
 - [https://www.zdnet.com/home-and-office/home-entertainment/best-outdoor-tv/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/best-outdoor-tv/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 19:56:00+00:00

The best outdoor TVs offer excellent glare protection and brilliant sound. Before you watch the next big game or movie, check out our top picks for outdoor TVs.

## Sony's PlayStation VR2 launches February 2023 for $550
 - [https://www.zdnet.com/home-and-office/home-entertainment/sonys-playstation-vr2-launches-february-2023-for-550/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/sonys-playstation-vr2-launches-february-2023-for-550/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 19:16:37+00:00

Sony's second-generation VR headset finally has an official launch date and pricing, as well as some new accessories and confirmed launch titles.

## How to change filters on your DJI Mini 3 Pro without breaking your drone
 - [https://www.zdnet.com/article/how-to-change-filters-on-your-dji-mini-3-pro-without-breaking-your-drone/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-change-filters-on-your-dji-mini-3-pro-without-breaking-your-drone/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 18:34:47+00:00

It's a lot easier once you know what you're doing.

## Want AirPods Pro's best feature for half the price? Try 1More
 - [https://www.zdnet.com/article/1more-aero-earbuds-review/#ftag=RSSbaffb68](https://www.zdnet.com/article/1more-aero-earbuds-review/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 18:14:00+00:00

Review: Spatial audio is the earbud feature of the moment. The new 1MORE Aero earbuds incorporate the popular surround-sound technology in a $110 package.

## The 5 best gaming earbuds of 2022
 - [https://www.zdnet.com/article/best-gaming-earbuds/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-gaming-earbuds/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 16:20:00+00:00

The best gaming headset doesn't have to feature over-ear headphones. Fortunately, brands like Razer, HyperX, and Asus offer high-quality gaming earbuds for PC and console gaming.

## Smartphones with interchangeable camera lenses: Hardware chaos or pure genius?
 - [https://www.zdnet.com/article/smartphones-with-interchangeable-camera-lenses-hardware-chaos-or-pure-genius/#ftag=RSSbaffb68](https://www.zdnet.com/article/smartphones-with-interchangeable-camera-lenses-hardware-chaos-or-pure-genius/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 15:34:00+00:00

The Xiaomi 12S Ultra Concept is engineered to support detachable camera lenses, giving the flagship smartphone a bump in photo and video output. But you shouldn't get too excited about it yet.

## Xiaomi unveils concept phone with interchangeable camera lenses: Hardware chaos or pure genius?
 - [https://www.zdnet.com/article/xiaomi-unveils-concept-phone-with-interchangeable-camera-lenses-hardware-chaos-or-pure-genius/#ftag=RSSbaffb68](https://www.zdnet.com/article/xiaomi-unveils-concept-phone-with-interchangeable-camera-lenses-hardware-chaos-or-pure-genius/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 15:34:00+00:00

The Xiaomi 12S Ultra Concept is engineered to support detachable camera lenses, giving the flagship smartphone a bump in photo and video output. But you shouldn't get too excited about it yet.

## Early Black Friday deal: Asus VivoBook Pro just dropped to $999
 - [https://www.zdnet.com/article/asus-vivobook-pro-deal-sale-coupon-code/#ftag=RSSbaffb68](https://www.zdnet.com/article/asus-vivobook-pro-deal-sale-coupon-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 14:45:00+00:00

If you work remotely or enjoy gaming, it may be time to upgrade your laptop. With early Black Friday sales, you can pick up the Asus VivoBook Pro for 28% off.

## How to give carbon capture credits this holiday season
 - [https://www.zdnet.com/home-and-office/smart-planet/how-to-give-carbon-capture-credits-this-holiday-season/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-planet/how-to-give-carbon-capture-credits-this-holiday-season/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 14:06:56+00:00

The technology is impressive. Give the gift of environmental impact this holiday season.

## Velotric Nomad 1 electric bike review: Tackle any terrain in comfort
 - [https://www.zdnet.com/article/velotric-nomad-1-electric-bike-review-tackle-any-terrain-in-comfort/#ftag=RSSbaffb68](https://www.zdnet.com/article/velotric-nomad-1-electric-bike-review-tackle-any-terrain-in-comfort/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 13:49:53+00:00

Velotric followed up its compelling Discover 1 e-bike with an equally compelling fat-tire model with lots of power, comfort, and style for trail and road riding.

## These two powerful Mac model updates are still MIA. Should you care?
 - [https://www.zdnet.com/article/these-two-powerful-mac-model-updates-are-still-mia-should-you-care/#ftag=RSSbaffb68](https://www.zdnet.com/article/these-two-powerful-mac-model-updates-are-still-mia-should-you-care/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 13:41:06+00:00

Tim Cook's self-imposed two year transition deadline has passed and still we haven't seen new Mac Pros or 27-inch iMacs. But should we care?

## iOS 16.1 draining your iPhone's battery fast? You're not alone
 - [https://www.zdnet.com/article/ios-16-1-draining-your-iphones-battery-fast-youre-not-alone/#ftag=RSSbaffb68](https://www.zdnet.com/article/ios-16-1-draining-your-iphones-battery-fast-youre-not-alone/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 13:04:18+00:00

Rapid battery drain and overheating seem to be plaguing some users.

## Apple TV 4K review: Apple is finally selling more for less
 - [https://www.zdnet.com/home-and-office/home-entertainment/apple-tv-4k-review-apple-is-finally-selling-more-for-less/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/apple-tv-4k-review-apple-is-finally-selling-more-for-less/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 13:00:32+00:00

Apple is covetous of your HDMI ports and wants the Apple TV 4K to be the only streaming device you'll ever use. But is it worthy of that title?

## iPad Pro (2022) review: Stop me if you've heard this one before, but…
 - [https://www.zdnet.com/article/ipad-pro-2022-review/#ftag=RSSbaffb68](https://www.zdnet.com/article/ipad-pro-2022-review/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 13:00:00+00:00

Apple's latest iPad Pro gets a small spec bump over last year's model, but there's a lot of hope among iPad Pro fans that the software experience will finally catch up.

## Cloud computing: Migration is not stopping and there's no going back
 - [https://www.zdnet.com/article/cloud-computing-migration-is-not-stopping-and-theres-no-going-back/#ftag=RSSbaffb68](https://www.zdnet.com/article/cloud-computing-migration-is-not-stopping-and-theres-no-going-back/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 12:19:32+00:00

Cloud computing spending continues to rise – and once apps have moved to the cloud, they tend to stay there.

## Starlink RV review: Changes the game for digital nomads
 - [https://www.zdnet.com/home-and-office/networking/starlink-rv-game-changer-for-digital-nomads/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/networking/starlink-rv-game-changer-for-digital-nomads/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 12:00:23+00:00

Is it perfect? Nope, but its no-fuss setup and respectable broadband speeds (at home and in the middle of nowhere) make it well worth the cost.

## IoT devices can undermine your security. Here are four ways to boost your defences
 - [https://www.zdnet.com/article/iot-devices-can-undermine-your-security-here-are-four-ways-to-boost-your-defences/#ftag=RSSbaffb68](https://www.zdnet.com/article/iot-devices-can-undermine-your-security-here-are-four-ways-to-boost-your-defences/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 11:47:22+00:00

IoT is an increasingly common part of critical networks and cyber attackers know it. Here's how to avoid becoming a victim of their tactics.

## The New Turing Test: Are you human?
 - [https://www.zdnet.com/article/the-new-turing-test-are-you-human/#ftag=RSSbaffb68](https://www.zdnet.com/article/the-new-turing-test-are-you-human/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 11:30:24+00:00

If the average individual ascribes intelligence to AI, it is because the average individual spends more and more of their time engaging in online tasks that a machine could easily emulate.

## How to use Photo Unblur on the Google Pixel 7 series
 - [https://www.zdnet.com/article/how-to-use-photo-unblur-on-the-google-pixel-7-series/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-use-photo-unblur-on-the-google-pixel-7-series/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 11:00:24+00:00

The latest Google Photos feature intelligently sharpens your images so that even the most blurry stills look...still.

## When it comes to tackling retention, employers are overlooking their biggest problem
 - [https://www.zdnet.com/education/professional-development/when-it-comes-to-tackling-retention-employers-are-overlooking-their-biggest-problem/#ftag=RSSbaffb68](https://www.zdnet.com/education/professional-development/when-it-comes-to-tackling-retention-employers-are-overlooking-their-biggest-problem/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 10:53:49+00:00

Employees want to develop their skills, but employers are holding them back.

## Finally, is this the end for the fax machine?
 - [https://www.zdnet.com/article/finally-is-this-the-end-for-the-fax-machine/#ftag=RSSbaffb68](https://www.zdnet.com/article/finally-is-this-the-end-for-the-fax-machine/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 10:53:01+00:00

Once an essential part of office life, the fax machine is on the way out.

## Singapore startup looks to shine light on solar energy affordability
 - [https://www.zdnet.com/article/singapore-startup-looks-to-shine-light-on-solar-energy-affordability/#ftag=RSSbaffb68](https://www.zdnet.com/article/singapore-startup-looks-to-shine-light-on-solar-energy-affordability/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 09:32:49+00:00

Solar AI Technologies hopes its "rent-to-own" service will help drive the installation of solar panels amongst households in the country, where adoption of the renewable energy remains low due to hefty upfront costs and lack of confidence it can be an alternative power source.

## Early Black Friday deal: ASUS VivoBook Pro just dropped to $999
 - [https://www.zdnet.com/home-and-office/asus-vivobook-pro-deal-sale-coupon-code/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/asus-vivobook-pro-deal-sale-coupon-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-02 08:54:28+00:00

Newegg's offer for the ASUS VivoBook Pro will likely appeal to both hybrid/remote workers and gamers looking for an upgrade.


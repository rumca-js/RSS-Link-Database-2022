# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Naukowcy: dłubanie w nosie może zwiększać ryzyko demencji i choroby Alzheimera
 - [https://tvn24.pl/tvnmeteo/nauka/nauka-dlubanie-w-nosie-moze-zwiekszyc-ryzyko-alzheimera-badania-6190869?source=rss](https://tvn24.pl/tvnmeteo/nauka/nauka-dlubanie-w-nosie-moze-zwiekszyc-ryzyko-alzheimera-badania-6190869?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2022-11-02 17:00:53+00:00

<img alt="Naukowcy: dłubanie w nosie może zwiększać ryzyko demencji i choroby Alzheimera" src="https://tvn24.pl/najnowsze/cdn-zdjecie-annie5-nos-shutterstock167161349-6190730/alternates/LANDSCAPE_1280" />
    Bakterie są w stanie przemieszczać się wzdłuż nerwu węchowego aż do mózgu i powodować zmiany charakterystyczne dla choroby Alzheimera - ustalili naukowcy z australijskiego Uniwersytetu Griffitha. Niebezpieczne może być z tego powodu dłubanie w nosie oraz wyrywanie z niego włosów. Choć badania przeprowadzone zostały na myszach, zdaniem jednego ze współautorów ich wyniki są również potencjalnie groźne dla ludzi.


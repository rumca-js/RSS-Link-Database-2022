# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## Forget combat, we asked the devs behind this upcoming RPG how they're including jobs like 'doctor' and 'orator'
 - [https://www.pcgamer.com/where-winds-meet-jobs-interview](https://www.pcgamer.com/where-winds-meet-jobs-interview)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 22:39:31+00:00

There's lots of swordfighting in Where Winds Meet, but I'm more excited to try earning a living 10th-century China.

## Nvidia fixes Modern Warfare 2 bug in its latest GeForce driver
 - [https://www.pcgamer.com/nvidia-fixes-modern-warfare-2-bug-in-its-latest-geforce-driver](https://www.pcgamer.com/nvidia-fixes-modern-warfare-2-bug-in-its-latest-geforce-driver)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 22:28:52+00:00

The bug in the latest Game Ready Driver was reported last week.

## Just as it predicted last year, half of Capcom's sales are now on PC
 - [https://www.pcgamer.com/just-as-it-predicted-last-year-half-of-capcoms-sales-are-now-on-pc](https://www.pcgamer.com/just-as-it-predicted-last-year-half-of-capcoms-sales-are-now-on-pc)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 22:13:26+00:00

The Japanese publisher said in late 2021 that it wanted PC to be its primary platform, and now it is.

## The numbers are in: Don't put too many attachments on your Modern Warfare 2 guns
 - [https://www.pcgamer.com/the-numbers-are-in-dont-put-too-many-attachments-on-your-modern-warfare-2-guns](https://www.pcgamer.com/the-numbers-are-in-dont-put-too-many-attachments-on-your-modern-warfare-2-guns)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 19:12:52+00:00

Maxing out your gun in the newest Call of Duty may not be the best way to go.

## Microsoft tells shareholders not to worry their pretty little heads about its work with the US military
 - [https://www.pcgamer.com/microsoft-tells-shareholders-not-to-worry-their-pretty-little-heads-about-its-work-with-the-us-military](https://www.pcgamer.com/microsoft-tells-shareholders-not-to-worry-their-pretty-little-heads-about-its-work-with-the-us-military)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 17:48:54+00:00

'We do not believe the requested third-party analyses would advance the interests of Microsoft, its shareholders, or other stakeholders'.

## Slay the Spire boardgame looks amazing, expensive, and has raised $1.4 million already
 - [https://www.pcgamer.com/slay-the-spire-boardgame-looks-amazing-expensive-and-has-raised-dollar14-million-already](https://www.pcgamer.com/slay-the-spire-boardgame-looks-amazing-expensive-and-has-raised-dollar14-million-already)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 17:22:02+00:00

$100 for the base set but you do get a bonus Claw pack. And Claw is Law.

## Important: Cyberpunk 2077 mod lets you pet your cat
 - [https://www.pcgamer.com/important-cyberpunk-2077-mod-lets-you-pet-your-cat](https://www.pcgamer.com/important-cyberpunk-2077-mod-lets-you-pet-your-cat)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 16:51:41+00:00

Feeline fine.

## Hideo Kojima's teases are just annoying now
 - [https://www.pcgamer.com/hideo-kojimas-teases-are-just-annoying-now](https://www.pcgamer.com/hideo-kojimas-teases-are-just-annoying-now)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 16:39:44+00:00

The director's drip-drip has slightly lost its charm.

## Well, here's a mod that replaces the Left 4 Dead 2 Charger with Homer in his car
 - [https://www.pcgamer.com/well-heres-a-mod-that-replaces-the-left-4-dead-2-charger-with-homer-in-his-car](https://www.pcgamer.com/well-heres-a-mod-that-replaces-the-left-4-dead-2-charger-with-homer-in-his-car)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 16:37:51+00:00

And another for Shaggy from Scooby-Doo.

## 2022's best co-op survival game is getting its biggest update yet
 - [https://www.pcgamer.com/2022s-best-co-op-survival-game-is-getting-its-biggest-update-yet](https://www.pcgamer.com/2022s-best-co-op-survival-game-is-getting-its-biggest-update-yet)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 16:29:00+00:00

A huge new biome, new enemies and resources, craftable go-carts, and two new bosses arrive next week.

## The best Disney Dreamlight Valley recipes
 - [https://www.pcgamer.com/disney-dreamlight-valley-best-recipes](https://www.pcgamer.com/disney-dreamlight-valley-best-recipes)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 15:25:25+00:00

Anyone can cook.

## The Past Within, a 'real-life escape room experience' for two players, is out now
 - [https://www.pcgamer.com/the-past-within-a-real-life-escape-room-experience-for-two-players-is-out-now](https://www.pcgamer.com/the-past-within-a-real-life-escape-room-experience-for-two-players-is-out-now)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 15:06:16+00:00

The first co-op Rusty Lake game is the studio's biggest production ever.

## Level Zero is a terrifying sci-fi asymmetrical horror where aliens stalk in the dark
 - [https://www.pcgamer.com/level-zero-is-a-terrifying-sci-fi-asymmetrical-horror-where-aliens-stalk-in-the-dark](https://www.pcgamer.com/level-zero-is-a-terrifying-sci-fi-asymmetrical-horror-where-aliens-stalk-in-the-dark)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 14:13:16+00:00

If Dead by Daylight had aliens in it.

## BioShock-like Soviet shooter Atomic Heart finally has a real release date
 - [https://www.pcgamer.com/bioshock-like-soviet-shooter-atomic-heart-finally-has-a-real-release-date](https://www.pcgamer.com/bioshock-like-soviet-shooter-atomic-heart-finally-has-a-real-release-date)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 13:28:31+00:00

Brace yourself for a February revolution.

## Black Friday PC gaming deals UK: the best deals on PCs, components and peripherals
 - [https://www.pcgamer.com/black-friday-pc-gaming-deals-uk](https://www.pcgamer.com/black-friday-pc-gaming-deals-uk)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 12:45:00+00:00

The very best Black November deals, as chosen by our experts.

## Genshin Impact: Dendro Hypostasis location and how to beat
 - [https://www.pcgamer.com/genshin-impact-dendro-hypostasis-location](https://www.pcgamer.com/genshin-impact-dendro-hypostasis-location)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 12:21:31+00:00

Beat this blocky boss for Nahida's ascension materials.

## Harvestella will offer a non-binary pronoun option
 - [https://www.pcgamer.com/harvestella-will-offer-a-non-binary-pronoun-option](https://www.pcgamer.com/harvestella-will-offer-a-non-binary-pronoun-option)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 11:28:39+00:00

Daisuke Taka said he wanted to show that "all players are welcome."

## Frontier acquires the studio behind Warhammer 40K: Daemonhunters with an eye to 'more ambitious future titles'
 - [https://www.pcgamer.com/frontier-acquires-the-studio-behind-warhammer-40k-daemonhunters-with-an-eye-to-more-ambitious-future-titles](https://www.pcgamer.com/frontier-acquires-the-studio-behind-warhammer-40k-daemonhunters-with-an-eye-to-more-ambitious-future-titles)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 11:27:36+00:00

You make space games, I make space games, let's make it official.

## Black Friday SSD deals 2022: the fastest PC storage at the lowest prices
 - [https://www.pcgamer.com/black-friday-ssd-deals](https://www.pcgamer.com/black-friday-ssd-deals)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 11:10:38+00:00

We're into Black November now, and the SSD deals are already popping off.

## Today's Wordle answer and hint for Wednesday, November 2
 - [https://www.pcgamer.com/wordle-today-501-answer-november-2](https://www.pcgamer.com/wordle-today-501-answer-november-2)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 08:01:28+00:00

Wordle today: The solution and a hint for the #501 puzzle.

## Vietnam's 'King of VGA' is selling mountains of graphics cards on the street
 - [https://www.pcgamer.com/vietnams-king-of-vga-is-selling-mountains-of-graphics-cards-on-the-street](https://www.pcgamer.com/vietnams-king-of-vga-is-selling-mountains-of-graphics-cards-on-the-street)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 04:01:55+00:00

I'll take a bag of burned-through GPUs, please.

## The November PC game releases and events you should know about
 - [https://www.pcgamer.com/pc-game-release-dates-november-2022](https://www.pcgamer.com/pc-game-release-dates-november-2022)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 00:14:17+00:00

Warhammer, Warcraft, and Warzone will go to war this Novembwar. I mean Warvember. Sorry, Warvembwar.

## EA plans to release a 'major' game before April, but won't say what it is
 - [https://www.pcgamer.com/ea-plans-to-release-a-major-game-before-april-but-wont-say-what-it-is](https://www.pcgamer.com/ea-plans-to-release-a-major-game-before-april-but-wont-say-what-it-is)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-02 00:09:45+00:00

The game is heavily rumored to be Star Wars Jedi: Survivor.


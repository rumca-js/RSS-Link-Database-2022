# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Border Patrol officers seize over $5.8 million worth of meth on truck entering U.S.
 - [https://www.foxnews.com/us/border-patrol-officers-seize-over-million-worth-meth-truck-entering-u-s](https://www.foxnews.com/us/border-patrol-officers-seize-over-million-worth-meth-truck-entering-u-s)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 23:55:17+00:00

U.S. Customs and Border Protection agents in Texas seized over $5.8 million worth of methamphetamine that was attempting to cross the U.S. border on Sunday.

## Astro's superfan 'Mattress Mack' claims his defense of Jose Altuve led to altercation with Phillies fan
 - [https://www.foxnews.com/sports/astros-superfan-mattress-mack-claims-his-defense-of-jose-altuve-led-to-altercation-with-phillies-fan](https://www.foxnews.com/sports/astros-superfan-mattress-mack-claims-his-defense-of-jose-altuve-led-to-altercation-with-phillies-fan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 23:42:18+00:00

Jim "Mattress Mack" McIngvale, who has a record payout riding on the Astros winning the World Series, was involved in a heated exchange with Phillies fans at Citizens Bank Park.

## Midterm study finds mainstream media gave Republicans '87%' more negative coverage than Democrats
 - [https://www.foxnews.com/media/study-finds-mainstream-media-gave-republicans-more-negative-coverage-democrats](https://www.foxnews.com/media/study-finds-mainstream-media-gave-republicans-more-negative-coverage-democrats)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 23:41:08+00:00

A new survey from conservative media watchdog group Media Research Center found coverage of the GOP headed into the midterm elections was almost 90% negative.

## Stacey Abrams, Beto O'Rourke dubbed 'superstar losers' by Atlantic writer
 - [https://www.foxnews.com/media/stacey-abrams-beto-orourke-dubbed-superstar-losers-atlantic-writer](https://www.foxnews.com/media/stacey-abrams-beto-orourke-dubbed-superstar-losers-atlantic-writer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 23:39:18+00:00

A writer at The Atlantic called out the popularity of Democrats Stacey Abrams and Beto O'Rourke, who seem to be famous for losing high profile electoral races.

## Biden urges voters to rebuke political violence by backing Democrats
 - [https://www.foxnews.com/politics/biden-speech](https://www.foxnews.com/politics/biden-speech)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 23:35:10+00:00

President Biden said the only way to repudiate political violence and Republican extremism was for Democrats to show up at the polls on Election Day.

## Ohio law enforcement seize enough fentanyl to kill 190,000 people
 - [https://www.foxnews.com/us/ohio-law-enforcement-seize-enough-fentanyl-kill-people](https://www.foxnews.com/us/ohio-law-enforcement-seize-enough-fentanyl-kill-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 23:32:45+00:00

An Ohio undercover investigation found 570 grams of fentanyl, which is enough to kill 190,000 people.

## Washington wife buried alive: Muffled screams revealed in violent kidnapping caught in Apple Watch 911 call
 - [https://www.foxnews.com/us/suspected-washington-kidnapper-speeds-past-police-car-wife-tied-up-back-of-van-video-shows](https://www.foxnews.com/us/suspected-washington-kidnapper-speeds-past-police-car-wife-tied-up-back-of-van-video-shows)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 23:09:54+00:00

A Washington man allegedly passed a responding officer as he fled his estranged wife's home with her tied up in the trunk last month, neighborhood video shows.

## Greg Gutfeld on midterm rhetoric: It's amazing how extreme the demonization has become
 - [https://www.foxnews.com/media/greg-gutfeld-midterm-rhetoric-amazing-how-extreme-demonization-has-become](https://www.foxnews.com/media/greg-gutfeld-midterm-rhetoric-amazing-how-extreme-demonization-has-become)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 23:07:04+00:00

Fox News host Greg Gutfeld slams the Democrats for how they are appealing to voters ahead of the 2022 midterms on 'The Five.'

## Parkland victims' families face shooter for the last time: 'Let this creature be erased'
 - [https://www.foxnews.com/us/parkland-victims-families-face-shooter-last-time-let-creature-be-erased](https://www.foxnews.com/us/parkland-victims-families-face-shooter-last-time-let-creature-be-erased)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 23:07:00+00:00

Families of victims who were killed in the Feb. 14, 2018, shooting at a Parkland, Florida, high school confronted shooter Nikolas Cruz for the last time.

## Cancel culture keeps targeting Amy Coney Barrett. Now it's an absurd call to ban her book
 - [https://www.foxnews.com/opinion/cancel-culture-targeting-amy-coney-barrett-absurd-call-ban-book](https://www.foxnews.com/opinion/cancel-culture-targeting-amy-coney-barrett-absurd-call-ban-book)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 22:59:52+00:00

Over the last decage censorship has become very popular from college campuses to the halls of Congress. The desire to quash Justice Amy Coney Barrett's book is the latest move.

## 'Bachelorette's’ Emily Maynard welcomes 6th baby, shares newborn’s Down syndrome diagnosis: ‘Biggest blessing'
 - [https://www.foxnews.com/entertainment/bachelorette-alum-emily-maynard-welcomes-6th-baby-shares-newborns-down-syndrome-diagnosis](https://www.foxnews.com/entertainment/bachelorette-alum-emily-maynard-welcomes-6th-baby-shares-newborns-down-syndrome-diagnosis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 22:53:52+00:00

Emily Maynard, the "Bachelorette" of season 8, revealed that her sixth child was born with Down Syndrome. Maynard opened up about her son's birth for the first time.

## Cowboys' Ezekiel Elliott teases Thanksgiving throwback uniforms
 - [https://www.foxnews.com/sports/cowboys-ezekiell-elliott-teases-thanksgiving-throwback-uniforms](https://www.foxnews.com/sports/cowboys-ezekiell-elliott-teases-thanksgiving-throwback-uniforms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 22:39:52+00:00

The Dallas Cowboys will pay homage to past teams Thanksgiving with throwback uniforms against the New York Giants. Ezekiel Elliott teased them on social media.

## Adam Zimmer's sister remembers her brother in emotional Instagram post
 - [https://www.foxnews.com/sports/adam-zimmers-sister-shares-emotional-instagram-post-just-one-day-after](https://www.foxnews.com/sports/adam-zimmers-sister-shares-emotional-instagram-post-just-one-day-after)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 22:24:39+00:00

Adam Zimmer, son of longtime NFL coach Mike Zimmer, died at age 38. Corri Zimmer White, Adam's sister, confirmed news of his death in an emotional social media post.

## Brittney Griner's wife speaks out on denied appeal: 'This is just absurd'
 - [https://www.foxnews.com/sports/brittney-griners-wife-speaks-out-denied-appeal-this-is-just-absurd](https://www.foxnews.com/sports/brittney-griners-wife-speaks-out-denied-appeal-this-is-just-absurd)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 22:24:20+00:00

Brittney Griner's wife, Cherelle Griner, spoke out for the first time on Tuesday since a Russian court ruled to uphold her nine-year prison sentence.

## Paul Pelosi attack: Capitol Police begin 'internal security review' after officers missed break-in
 - [https://www.foxnews.com/us/paul-pelosi-attack-capitol-police-begin-internal-security-review-after-officers-missed-break-in](https://www.foxnews.com/us/paul-pelosi-attack-capitol-police-begin-internal-security-review-after-officers-missed-break-in)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 22:16:54+00:00

U.S. Capitol Police has begun an "internal security review" after officers in the Command Center missed video surveillance capturing the break-in on the Pelosi's San Francisco residence.

## Police reveal 17-year-old suspect charged in robbery attempt of Commanders' Brian Robinson Jr.
 - [https://www.foxnews.com/sports/police-reveal-17-year-old-suspect-charged-commanders-brian-robinson-jr-robbery-attempt](https://www.foxnews.com/sports/police-reveal-17-year-old-suspect-charged-commanders-brian-robinson-jr-robbery-attempt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 22:15:37+00:00

The Metropolitan Police Department announced the arrest of a 17-year-old who is a suspect in the attempted robbery of Washington Commanders running back Brian Robinson Jr.

## Missing Miami 6-year-old boy has tearful reunion with mother two months after being kidnapped
 - [https://www.foxnews.com/us/missing-miami-6-year-old-boy-tearful-reunion-mother-two-months-kidnapped](https://www.foxnews.com/us/missing-miami-6-year-old-boy-tearful-reunion-mother-two-months-kidnapped)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 22:06:19+00:00

A 6-year-old boy whose father and mother allegedly kidnapped him two months ago had a tearful reunion with his mother at an airport in Miami on Tuesday.

## CNN's Jake Tapper moving back to old time slot following ratings struggle in primetime
 - [https://www.foxnews.com/media/cnns-jake-tapper-moving-back-old-time-slot-following-ratings-struggle-primetime](https://www.foxnews.com/media/cnns-jake-tapper-moving-back-old-time-slot-following-ratings-struggle-primetime)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 22:01:09+00:00

Jake Tapper is returning to daytime after he failed to revive CNN's viewership in primetime, where he continued bashing the GOP despite the network's effort towards nonpartisanship.

## Fox News Poll: Walker gains ground in Georgia Senate race
 - [https://www.foxnews.com/official-polls/fox-news-poll-walker-gains-ground-in-georgia-senate-race](https://www.foxnews.com/official-polls/fox-news-poll-walker-gains-ground-in-georgia-senate-race)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 22:00:39+00:00

Herschel Walker has closed the gap with Democratic Sen. Raphael Warnock in a hotly contested race that could decide control of the Senate.

## Fox News Poll: Half of Pennsylvanians say Senate debate a factor in their vote
 - [https://www.foxnews.com/official-polls/fox-news-poll-half-pennsylvanians-say-senate-debate-factor-their-vote](https://www.foxnews.com/official-polls/fox-news-poll-half-pennsylvanians-say-senate-debate-factor-their-vote)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 22:00:34+00:00

After a rocky debate performance for Pennsylvania Lt. Gov Fetterman last week, voters still show more support for the recent stroke victim over Dr. Mehmet Oz.

## Conservatives, midterms matter when it comes to state legislatures, too. Don't ignore their power
 - [https://www.foxnews.com/opinion/conservatives-midterms-matter-state-legislatures-ignore-power](https://www.foxnews.com/opinion/conservatives-midterms-matter-state-legislatures-ignore-power)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 22:00:31+00:00

The power of the conservative movement doesn't just live at the national level. It gets important stability through state legislatures, too. That's why votes at the state level matter.

## White House won't say if it plans to pay for Twitter or if republic will survive GOP takeover of Congress
 - [https://www.foxnews.com/politics/white-house-wont-say-plans-pay-twitter-wont-answer-republic-will-survive-gop-takeover-congress](https://www.foxnews.com/politics/white-house-wont-say-plans-pay-twitter-wont-answer-republic-will-survive-gop-takeover-congress)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 22:00:27+00:00

White House press secretary Karine Jean-Pierre was mum Wednesday when asked whether the White House would go along Elon Musk's new policy of having users pay $8 a month to be verified.

## Idaho court sets 'Doomsday mom' Lori Vallow's competency evaluation date
 - [https://www.foxnews.com/us/idaho-court-sets-doomsday-mom-lori-vallow-competency-evaluation-date](https://www.foxnews.com/us/idaho-court-sets-doomsday-mom-lori-vallow-competency-evaluation-date)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 21:54:07+00:00

So-called Idaho 'doomsday mom' Lori Vallow, accused of killing her two kids, is facing a competency test on Nov. 9. The results of the test will determine the future of her trial.

## California man accused of having dentist girlfriend killed used shirt to hang himself inside jail cell
 - [https://www.foxnews.com/us/california-man-accused-having-dentist-girlfriend-killed-used-shirt-hang-himself-inside-jail-cell](https://www.foxnews.com/us/california-man-accused-having-dentist-girlfriend-killed-used-shirt-hang-himself-inside-jail-cell)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 21:51:00+00:00

A California man accused of having his girlfriend killed in a murder-for-hire plot hung himself with a shirt inside a jail cell, authorities said.

## McCarthy slams Biden for 'dividing the nation' ahead of speech assailing MAGA Republicans
 - [https://www.foxnews.com/politics/house-gop-leader-mccarthy-says-biden-is-dividing-the-nation-instead-of-uniting-it-ahead-of-dnc-speech](https://www.foxnews.com/politics/house-gop-leader-mccarthy-says-biden-is-dividing-the-nation-instead-of-uniting-it-ahead-of-dnc-speech)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 21:50:32+00:00

EXCLUSIVE: House GOP Leader Kevin McCarthy said President Biden is "dividing the nation" ahead of his DNC anti-Republican speech Wednesday night.

## 'The Crown' star Dominic West reveals Queen Consort Camilla's cheeky response to his role as Prince Charles
 - [https://www.foxnews.com/entertainment/the-crown-star-dominic-west-reveals-queen-consort-camilla-cheeky-response](https://www.foxnews.com/entertainment/the-crown-star-dominic-west-reveals-queen-consort-camilla-cheeky-response)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 21:45:55+00:00

Season 5 of “The Crown” is expected to cover the royal family’s turbulent 1990s, when Prince Charles and Princess Diana’s marriage messily fell apart.

## Trinity College removed American flags from students' window but allowed pride flags to remain for days later
 - [https://www.foxnews.com/media/trinity-college-removed-american-flags-students-window-allowed-pride-flags](https://www.foxnews.com/media/trinity-college-removed-american-flags-students-window-allowed-pride-flags)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 21:45:18+00:00

Two students at Trinity College had their American flags removed from their dorm window by the college despite the school allowing LGBT and trans flags.

## Deadly Dallas hospital shooting captured on newly released surveillance, body camera
 - [https://www.foxnews.com/us/deadly-dallas-hospital-shooting-captured-newly-released-surveillance-body-camera](https://www.foxnews.com/us/deadly-dallas-hospital-shooting-captured-newly-released-surveillance-body-camera)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 21:34:52+00:00

Texas police released bodycam footage and surveillance tape showing the moments leading up to the death of two healthcare workers at a hospital last month.

## NFL great explains waiting a year to reveal cancer diagnoses: ‘I didn’t want pity’
 - [https://www.foxnews.com/sports/nfl-great-explains-waiting-year-reveal-cancer-diagnoses-i-didnt-want-pity](https://www.foxnews.com/sports/nfl-great-explains-waiting-year-reveal-cancer-diagnoses-i-didnt-want-pity)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 21:33:51+00:00

NFL Hall of Famer Terry Bradshaw said Wednesday he did not reveal his two cancer diagnoses for close to a year because he did not want pity from anyone.

## Liz Cheney campaigns for Democrats in an attempt to block Trump's allies from winning in midterms
 - [https://www.foxnews.com/politics/liz-cheney-campaigns-democrats-attempt-block-trumps-allies-winning-midterms](https://www.foxnews.com/politics/liz-cheney-campaigns-democrats-attempt-block-trumps-allies-winning-midterms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 21:29:36+00:00

Rep. Liz Cheney is embracing House Speaker Nancy Pelosi and Democrats in an effort to block former President Donald Trump's GOP allies from succeeding this November.

## Paul Pelosi investigation: What to know about David DePape in attack on Nancy Pelosi’s husband
 - [https://www.foxnews.com/us/paul-pelosi-investigation-what-know-about-david-depape-attack-nancy-pelosis-husband](https://www.foxnews.com/us/paul-pelosi-investigation-what-know-about-david-depape-attack-nancy-pelosis-husband)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 21:29:27+00:00

Paul Pelosi attack suspect David DePape made a series of alarming claims to police after allegedly breaking into the House Speaker's San Francisco home.

## Dual 'inflation' crisis? Professor warns embellished grades failing America and its students
 - [https://www.foxnews.com/media/dual-inflation-crisis-professor-embellished-grades-failing-america-students](https://www.foxnews.com/media/dual-inflation-crisis-professor-embellished-grades-failing-america-students)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 21:21:38+00:00

Professor Nicholas Giordano, of Suffolk County Community College in Selden, N.Y. warned of failing students through inaccurate depictions of scholastic aptitude.

## Stephen A. Smith wants Commanders to have Black ownership: 'It is far time that it has happened'
 - [https://www.foxnews.com/sports/stephen-a-smith-wants-commanders-black-ownership](https://www.foxnews.com/sports/stephen-a-smith-wants-commanders-black-ownership)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 21:15:21+00:00

With news that Washington Commanders owner Dan Snyder has taken the first step to a potential sale, Stephen A. Smith believes it's time for Black ownership in the NFL.

## Delphi murders suspect Richard Allen held on $20 million bond: court records
 - [https://www.foxnews.com/us/delphi-murders-suspect-richard-allen-held-20-million-bond-court-records](https://www.foxnews.com/us/delphi-murders-suspect-richard-allen-held-20-million-bond-court-records)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 21:05:54+00:00

The Indiana man accused of the 2017 double murder of two teens who went missing on a hike in Delphi is being held on a $20 million bond, according to court records.

## Tennessee officials say 200-plus votes cast for wrong Nashville races
 - [https://www.foxnews.com/politics/tennessee-officials-say-200-plus-votes-cast-wrong-nashville-races](https://www.foxnews.com/politics/tennessee-officials-say-200-plus-votes-cast-wrong-nashville-races)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 20:47:40+00:00

More than 200 votes have been wrongly cast in Nashville since early voting began in Tennessee, election officials said.

## Georgia stops accepting applications from people asking for rent assistance
 - [https://www.foxnews.com/us/georgia-stops-accepting-applications-people-asking-rent-assistance](https://www.foxnews.com/us/georgia-stops-accepting-applications-people-asking-rent-assistance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 20:43:08+00:00

A Georgia agency is no longer accepting applications for rent assistance from the federally funded aid program. The program began in 2020 to help combat evictions.

## Was your vote counted? A state-by-state guide to tracking your absentee ballot
 - [https://www.foxnews.com/politics/was-your-vote-counted-state-state-guide-tracking-absentee-ballot](https://www.foxnews.com/politics/was-your-vote-counted-state-state-guide-tracking-absentee-ballot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 20:41:19+00:00

Americans who voted early in the 2022 midterm elections can track their absentee ballots and ensure they were cast through these online portals.

## Does my vote really count? Understanding voting in elections
 - [https://www.foxnews.com/politics/does-my-vote-really-count-understanding-voting-elections](https://www.foxnews.com/politics/does-my-vote-really-count-understanding-voting-elections)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 20:40:37+00:00

Republicans and Democrats are headed into a contentious midterm election where both parties lead each in various races by razor-thin margins. People across the nation are voting early.

## Beatle George Harrison's ex-wife Pattie Boyd recalls their final meeting before his death: 'He wasn't well'
 - [https://www.foxnews.com/entertainment/beatle-george-harrison-ex-wife-pattie-boyd-recalls-final-meeting](https://www.foxnews.com/entertainment/beatle-george-harrison-ex-wife-pattie-boyd-recalls-final-meeting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 20:37:07+00:00

George Harrison passed away in 2001 at age 58 after a battle with cancer. Paul McCartney and Ringo Starr are the two surviving Beatles. John Lennon was murdered in 1980 at age 40.

## Oil, gas companies ask Biden administration to exempt small wells from upcoming methane control rule
 - [https://www.foxnews.com/us/oil-gas-companies-biden-administration-exempt-small-wells-upcoming-methane-control-rule](https://www.foxnews.com/us/oil-gas-companies-biden-administration-exempt-small-wells-upcoming-methane-control-rule)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 20:36:14+00:00

Oil companies are asking the United States to exempt the smallest wells in the nation from upcoming methane rules, which requires drillers to find and plug methane leaks.

## Pike County massacre: Angela Wagner says 8 murders were husband's idea
 - [https://www.foxnews.com/us/pike-county-massacre-angela-wagner-says-8-murders-husbands-idea](https://www.foxnews.com/us/pike-county-massacre-angela-wagner-says-8-murders-husbands-idea)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 20:35:13+00:00

Angela Wagner, matriarch of the family accused of killing eight victims in the 2016 Pike County massacre, testified Tuesday that the murders were her husband's idea.

## Texas car crash: 12 people ejected in wreck involving human smuggling, one person dead, authorities say
 - [https://www.foxnews.com/us/texas-car-crash-12-people-ejected-wreck-involving-human-smuggling-one-person-dead](https://www.foxnews.com/us/texas-car-crash-12-people-ejected-wreck-involving-human-smuggling-one-person-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 20:30:47+00:00

A car wreck that authorities suspect was connected to human smuggling left one person dead and 11 others injured in La Joya, Texas, on Wednesday.

## Everything you need to know about the Senate midterms, candidates, and important races
 - [https://www.foxnews.com/politics/everything-need-know-senate-seats-candidates-important-races](https://www.foxnews.com/politics/everything-need-know-senate-seats-candidates-important-races)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 20:30:29+00:00

Who will take control of the Senate? How many seats are up for grabs? Fox News Digital breaks down everything you need to know ahead of the 2022 midterm elections.

## Paris court will deliver verdict for ex-Liberian rebel case on Wednesday
 - [https://www.foxnews.com/world/paris-court-deliver-verdict-liberian-rebel-case-wednesday](https://www.foxnews.com/world/paris-court-deliver-verdict-liberian-rebel-case-wednesday)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 20:28:49+00:00

An ex-Liberian rebel was charged with torture, acts of barbarism, and complicity in crimes against humanity. A verdict will be delivered in a Paris court on Wednesday.

## New Jersey's former GOP governor hopes 'all the crazies' win midterms, denounces Republicans as a 'cult'
 - [https://www.foxnews.com/politics/new-jerseys-former-gop-governor-hopes-all-crazies-win-midterms-denounces-republicans-cult](https://www.foxnews.com/politics/new-jerseys-former-gop-governor-hopes-all-crazies-win-midterms-denounces-republicans-cult)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 20:25:30+00:00

New Jersey’s former Republican Gov. Christine Todd Whitman denounced her party as a cult and said a part of her hopes that "all the crazies" win next week's midterms.

## Ol' Blue Eyes Frank Sinatra: A collection of photos and facts
 - [https://www.foxnews.com/entertainment/ol-blue-eyes-frank-sinatra-collection-photos-facts](https://www.foxnews.com/entertainment/ol-blue-eyes-frank-sinatra-collection-photos-facts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 19:46:39+00:00

Frank Sinatra is one of the world's best selling artists in music ever. Born in New Jersey, the American singer and actor drew attention to himself and his music beginning in the 40s.

## Migos rapper Takeoff killed from 'gunshot wounds' to 'head and torso' in Houston shooting: coroner
 - [https://www.foxnews.com/entertainment/migos-rapper-takeoff-killed-gunshot-wounds-head-and-torso-houston-shooting-coroner](https://www.foxnews.com/entertainment/migos-rapper-takeoff-killed-gunshot-wounds-head-and-torso-houston-shooting-coroner)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 19:45:31+00:00

Takeoff was fatally shot multiple times in front of dozens of witnesses after a private party ended on Halloween in downtown Houston. The suspect is still at large.

## All Souls Day: Here's why priests advise praying for the dead
 - [https://www.foxnews.com/lifestyle/all-souls-day-priests-advise-praying-dead](https://www.foxnews.com/lifestyle/all-souls-day-priests-advise-praying-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 19:44:10+00:00

November 2 is the date of All Souls Day. This holiday is marked by people going to cemeteries, remembering their deceased loved ones and saying extra prayers.

## Portland homeless say their extensive rap sheets keep them on the streets: 'Almost impossible' to find job
 - [https://www.foxnews.com/us/portland-homeless-say-extensive-rap-sheets-keep-them-streets](https://www.foxnews.com/us/portland-homeless-say-extensive-rap-sheets-keep-them-streets)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 19:42:35+00:00

Homeless individuals in Portland, Oregon, say finding a job is difficult for them due to their extensive criminal records, which keeps them in a "downward spiral."

## Baltimore high school football fight leads to teams' suspensions from state playoffs
 - [https://www.foxnews.com/sports/baltimore-high-school-football-fight-leads-teams-suspensions-state-playoffs](https://www.foxnews.com/sports/baltimore-high-school-football-fight-leads-teams-suspensions-state-playoffs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 19:40:47+00:00

Two rival Baltimore high school football teams have been disqualified from the state playoffs after a massive fight broke out at their most recent game.

## Minnesota woman gunned down outside her office after rejecting co-worker's advances
 - [https://www.foxnews.com/us/minnesota-woman-gunned-down-outside-office-rejecting-co-workers-advances](https://www.foxnews.com/us/minnesota-woman-gunned-down-outside-office-rejecting-co-workers-advances)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 19:36:25+00:00

A Minnesota man is accused of gunning down his co-worker, Nicole Hammond, in a parking lot after she rejected his advances and asked him not to touch her, according to police.

## Jets' Joe Douglas on sticking with Elijah Moore, Denzel Mims past trade deadline: 'We love both these guys'
 - [https://www.foxnews.com/sports/jets-joe-douglas-sticking-elijah-moore-denzel-mims-past-trade-deadline-we-love-both-these-guys](https://www.foxnews.com/sports/jets-joe-douglas-sticking-elijah-moore-denzel-mims-past-trade-deadline-we-love-both-these-guys)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 19:29:30+00:00

New York Jets general manager Joe Douglas made it clear on Tuesday that there was never any intention to trade disgruntled wideouts Denzel Mims and Elijah Moore.

## 26-year-old Titanic mystery finally solved by divers
 - [https://www.foxnews.com/science/26-year-old-titanic-mystery-finally-solved-divers](https://www.foxnews.com/science/26-year-old-titanic-mystery-finally-solved-divers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 19:25:49+00:00

After more than two decades, an RMS Titanic mystery has been solved. Divers found the "blip" recorded on sonar in 1998 is a dense ecosystem nearly 3,000 meters deep.

## Former Spurs' employee to speak out on Joshua Primo allegations
 - [https://www.foxnews.com/sports/former-spurs-employee-speak-out-joshua-primo-allegations](https://www.foxnews.com/sports/former-spurs-employee-speak-out-joshua-primo-allegations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 19:23:37+00:00

A former San Antonio Spurs employee will address allegations surrounding first-round NBA draft pick Joshua Primo during a press conference Thursday, her attorney confirmed.

## Stanford squatter: Man pretending to be university student stayed in dorm for 10 months
 - [https://www.foxnews.com/us/stanford-squatter-man-pretending-university-student-stayed-dorm-10-months](https://www.foxnews.com/us/stanford-squatter-man-pretending-university-student-stayed-dorm-10-months)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 19:19:58+00:00

An Alabama man pretending to be a Stanford University student allegedly stayed in at least five dorms on the school's campus between December 2021 and Oct. 27.

## California Kohl's stabbing suspect repeatedly knifed victim, returned to continue attack, report says
 - [https://www.foxnews.com/us/california-kohls-stabbing-suspect-repeatedly-knifed-victim-returned-continue-attack-report-says](https://www.foxnews.com/us/california-kohls-stabbing-suspect-repeatedly-knifed-victim-returned-continue-attack-report-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 19:06:20+00:00

The man accused of fatally stabbing a father and daughter in a California Kohl's parking lot allegedly returned to stab the female victim twice more after the initial attack.

## Italian government criticized for decree banning rave parties
 - [https://www.foxnews.com/world/italian-government-criticized-decree-banning-rave-parties](https://www.foxnews.com/world/italian-government-criticized-decree-banning-rave-parties)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 19:03:32+00:00

Italy's new interior minister defended the government's decision to ban rave parties. Critics believe the ban could be used to halt sit-ins and other protests.

## California's Newsom says Dems getting 'destroyed' on messaging: 'We’re going to have to do better'
 - [https://www.foxnews.com/politics/californias-newsom-says-dems-getting-destroyed-messaging](https://www.foxnews.com/politics/californias-newsom-says-dems-getting-destroyed-messaging)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 19:01:08+00:00

California Gov. Gavin Newsom criticized his fellow democrats for getting crushed on narrative, saying they must do better going on the offense rather than the defense.

## Florida man unhappy with change he got at convenience store returns with 5 pals, robs cashier of $8K: police
 - [https://www.foxnews.com/us/florida-man-unhappy-change-convenience-store-returns-5-pals-robs-cashier-8k-police](https://www.foxnews.com/us/florida-man-unhappy-change-convenience-store-returns-5-pals-robs-cashier-8k-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 18:42:19+00:00

A Florida man is wanted after he and several others attacked a store clerk in Deerfield Beach and stole $8,000 following a dispute over change he received, authorities said.

## I'm Marco Rubio: This is why I want Florida's vote in the midterm election
 - [https://www.foxnews.com/opinion/marco-rubio-floridas-vote-midterm-election](https://www.foxnews.com/opinion/marco-rubio-floridas-vote-midterm-election)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 18:40:42+00:00

Every crisis we face as a country has been driven by the left's agenda. My opponent, Val Demings, would be a rubber stamp in the Senate for that liberal agenda.

## Nobel Prize winners urge world leaders to raise human rights issues at Egypt climate change conference
 - [https://www.foxnews.com/world/nobel-prize-winners-urge-world-leaders-to-raise-human-rights-issues-at-egypt-climate-change-conference](https://www.foxnews.com/world/nobel-prize-winners-urge-world-leaders-to-raise-human-rights-issues-at-egypt-climate-change-conference)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 18:35:38+00:00

World leaders attending the COP27 climate summit in Egypt are being urged to bring up human rights issues, specifically the case of prominent imprisoned activist Abdel-Fattah.

## 'The View' hosts Sunny Hostin and Sara Haines spar over affirmative action cases: 'Right-wing attack'
 - [https://www.foxnews.com/media/the-view-hosts-sunny-hostin-sara-haines-spar-over-affirmative-action-cases-right-wing-attack](https://www.foxnews.com/media/the-view-hosts-sunny-hostin-sara-haines-spar-over-affirmative-action-cases-right-wing-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 18:33:15+00:00

"The View" hosts Sunny Hostin and Sara Haines sparred over affirmative action cases before the Supreme Court, as Hostin warned of a "right-wing attack on our rights."

## Hillary Clinton roasted for latest 'basket of deplorables' moment: Her ego is 'preposterous'
 - [https://www.foxnews.com/media/hillary-clinton-roasted-latest-basket-deplorables-moment-ego-preposterous](https://www.foxnews.com/media/hillary-clinton-roasted-latest-basket-deplorables-moment-ego-preposterous)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 18:32:19+00:00

'Outnumbered' hosts react to Hillary Clinton's comments on MSNBC Tuesday and discuss the impact of White, suburban women shifting support to the GOP.

## David DePape allegedly said it was the 'end of the road' for Paul Pelosi: 'Take them all out'
 - [https://www.foxnews.com/us/david-depape-allegedly-said-it-was-end-of-road-paul-pelosi-take-them-all-out](https://www.foxnews.com/us/david-depape-allegedly-said-it-was-end-of-road-paul-pelosi-take-them-all-out)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 18:29:54+00:00

The man accused of attacking Paul Pelosi allegedly told the House Speaker's husband that it was the "end of the road" for him after he broke into the Pelosi's San Francisco residence.

## Brazil's Bolsonaro tells Supreme Court election 'is over'
 - [https://www.foxnews.com/world/brazil-bolsonaro-tells-supreme-court-election-over](https://www.foxnews.com/world/brazil-bolsonaro-tells-supreme-court-election-over)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 18:28:36+00:00

Brazil's Jair Bolsonaro reportedly told Supreme Court members the battle against leftist Luiz Inacio Lula da Silva was over, two days after Bolsonaro's election loss.

## Voter turnout in Colorado lags in early voting
 - [https://www.foxnews.com/politics/voter-turnout-colorado-lags-early-voting](https://www.foxnews.com/politics/voter-turnout-colorado-lags-early-voting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 18:27:04+00:00

Voter turnout in Colorado in early voting is lagging behind figures reported at this stage in the 2018 midterm election. Coloradans tend to vote by mail.

## Search for 1921 Tulsa Race Massacre victims finds 21 new graves
 - [https://www.foxnews.com/us/search-1921-tulsa-race-massacre-victims-21-new-graves](https://www.foxnews.com/us/search-1921-tulsa-race-massacre-victims-21-new-graves)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 18:18:50+00:00

A search for remains from the Tulsa Race Massacre that occurred in 1921 has led to the finding of 21 additional graves. The graves were found in the Oaklawn Cemetery.

## GOP wins ‘ballot box transparency’ lawsuit in Green Bay, Wisconsin
 - [https://www.foxnews.com/politics/rnc-sues-lack-ballot-box-transparency-battleground-state-wisconsin](https://www.foxnews.com/politics/rnc-sues-lack-ballot-box-transparency-battleground-state-wisconsin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 18:18:13+00:00

The Republican National Committee won its lawsuit against Green Bay, Wisconsin, county clerk over a "ballot box transparency" issue ahead of Nov. 8 midterm elections.

## Alabama residents will be able to vote on 10 constitutional amendments on the Nov. 8 ballot
 - [https://www.foxnews.com/politics/alabama-residents-vote-10-constitutional-amendments-nov-8-ballot](https://www.foxnews.com/politics/alabama-residents-vote-10-constitutional-amendments-nov-8-ballot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 17:51:57+00:00

Alabama's Nov. 8 elections will feature 10 state constitutional amendments. Voters can decide to remove racist language from the state constitution among other propositions.

## 2nd suspect in Atlanta suburb police shooting is in custody
 - [https://www.foxnews.com/us/2nd-suspect-atlanta-suburb-police-shooting-custody](https://www.foxnews.com/us/2nd-suspect-atlanta-suburb-police-shooting-custody)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 17:44:44+00:00

The second suspect in the shooting of a suburban Atlanta police officer has been taken into custody. The first suspect was arrested shortly after the shooting.

## Sharon Stone opens up about doctors finding 'large fibroid tumor' in her body following misdiagnosis
 - [https://www.foxnews.com/entertainment/sharon-stone-reveals-doctors-found-large-fibroid-tumor-in-her-body-following-misdiagnosis](https://www.foxnews.com/entertainment/sharon-stone-reveals-doctors-found-large-fibroid-tumor-in-her-body-following-misdiagnosis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 17:42:47+00:00

Sharon Stone is urging women to always "get a second opinion" from medical professionals after she received a misdiagnosis that turned out to be a "large fibroid tumor." The actress took to her Instagram to caution her fans and followers.

## Katie Hobbs flounders while defending debate refusal: 'Our campaign strategy is our campaign strategy'
 - [https://www.foxnews.com/media/katie-hobbs-flounders-defending-debate-refusal-our-campaign-strategy-our-campaign-strategy](https://www.foxnews.com/media/katie-hobbs-flounders-defending-debate-refusal-our-campaign-strategy-our-campaign-strategy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 17:42:23+00:00

Arizona Democrat Katie Hobbs struggled while defending her refusal not to debate Kari Lake during an interview on Wednesday, less than a week until election day.

## Prominent New York trans activist arrested for allegedly soliciting a minor
 - [https://www.foxnews.com/us/prominent-new-york-trans-activist-arrested-allegedly-soliciting-minor](https://www.foxnews.com/us/prominent-new-york-trans-activist-arrested-allegedly-soliciting-minor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 17:32:45+00:00

NYC transgender and HIV activist Lailani Muniz was arrested and charged after allegedly soliciting a minor, who was actually an adult male who exposes people who target children.

## Kansas self-imposes four-game suspension for head basketball coach Bill Self
 - [https://www.foxnews.com/sports/kansas-self-imposes-four-game-suspension-head-basketball-coach-bill-self](https://www.foxnews.com/sports/kansas-self-imposes-four-game-suspension-head-basketball-coach-bill-self)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 17:31:39+00:00

Kansas head coach Bill Self has been suspended for the first four games of the 2022 college basketball season, stemming from a 2017 investigation.

## Massachusetts Gov. Charlie Baker pleads with Biden administration for more help with migrants
 - [https://www.foxnews.com/politics/massachusetts-charlie-baker-pleads-biden-administration-help-migrants](https://www.foxnews.com/politics/massachusetts-charlie-baker-pleads-biden-administration-help-migrants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 17:25:41+00:00

Massachusetts Gov. Charlie Baker is asking for federal help to shelter illegal migrants, in a letter to Secretaries Alejandro Mayorkas and Xavier Becerra.

## Paraglider rescues woman trapped in submerged car in South Florida canal: video
 - [https://www.foxnews.com/us/paraglider-rescues-woman-trapped-submerged-car-south-florida-canal-video](https://www.foxnews.com/us/paraglider-rescues-woman-trapped-submerged-car-south-florida-canal-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 17:23:21+00:00

A man paragliding in south Florida noticed a woman trapped in a canal with her car. He not only jumped into action to help her, but caught the rescue on camera.

## Reggie Miller wonders where NBA players are in midst of Kyrie Irving controversy: 'It's been crickets'
 - [https://www.foxnews.com/sports/reggie-miller-wonders-where-nba-players-midst-kyrie-irving-controversy-crickets](https://www.foxnews.com/sports/reggie-miller-wonders-where-nba-players-midst-kyrie-irving-controversy-crickets)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 17:21:03+00:00

Basketball Hall of Famer Reggie Miller took a shot at NBA players for failing to step up and speak out amid the controversy surrounding Kyrie Irving.

## Twitter praised for fact-check on White House account: ‘Fact checks are getting factual now!’
 - [https://www.foxnews.com/media/twitter-praised-fact-check-white-house-account-fact-checks-getting-factual-now](https://www.foxnews.com/media/twitter-praised-fact-check-white-house-account-fact-checks-getting-factual-now)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 17:20:07+00:00

Conservatives praised Twitter for putting up a fact-check on one of the White House's latest tweets touting its alleged achievements in Social Security policy.

## Border Patrol union hits back at ACLU over agent clash with migrants: 'Go to hell'
 - [https://www.foxnews.com/politics/border-patrol-union-hits-back-aclu-agent-clash-with-migrants-go-hell](https://www.foxnews.com/politics/border-patrol-union-hits-back-aclu-agent-clash-with-migrants-go-hell)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 17:17:25+00:00

The National Border Patrol Council on Wednesday hit out at the American Civil Liberties Union for its criticism of Border Patrol's handling of a group of migrants.

## West Virginia's Mooney runs for Congress but aims at Manchin
 - [https://www.foxnews.com/politics/west-virginia-mooney-runs-congress-aims-manchin](https://www.foxnews.com/politics/west-virginia-mooney-runs-congress-aims-manchin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 17:16:11+00:00

West Virginia's Republican representative Alex Mooney is positioned to sweep the upcoming midterm election against progressive Democratic candidate Barry Wendell.

## Duffel bag murder suspect accused of slaying mom of 2 pleads guilty to lesser manslaughter charge
 - [https://www.foxnews.com/us/duffel-bag-murder-suspect-accused-slaying-mom-2-pleads-guilty-lesser-manslaughter-charge](https://www.foxnews.com/us/duffel-bag-murder-suspect-accused-slaying-mom-2-pleads-guilty-lesser-manslaughter-charge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 17:12:15+00:00

David Bonola, the accused killer of New York City mother Orsolya Gaal, whose remains were found stuffed in a duffel bag in Forest Hills, pleaded guilty to manslaughter.

## Who is Kevin Costner? Fox Nation explores Hollywood icon's life, career ahead of 'Yellowstone: One-Fifty'
 - [https://www.foxnews.com/media/kevin-costner-fox-nation-explores-hollywood-icons-life-career-yellowstone-one-fifty](https://www.foxnews.com/media/kevin-costner-fox-nation-explores-hollywood-icons-life-career-yellowstone-one-fifty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 17:07:05+00:00

Fox Nation's new special 'Who is Kevin Costner?' explores Costner's early life and legendary acting career, examining how he rose to stardom and became a global sensation.

## Affirmative Action case: SCOTUS justices were 'on fire' over Harvard's actions, says activist in hearing
 - [https://www.foxnews.com/media/supreme-court-justices-fire-over-harvards-demoralizing-personal-scores-activist-hearing](https://www.foxnews.com/media/supreme-court-justices-fire-over-harvards-demoralizing-personal-scores-activist-hearing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 16:47:27+00:00

Education activist Asra Nomani said she was "really emboldened" by the Supreme Court justices who decried Harvard's "personal ratings" during oral arguments.

## 25-year-old Republican bids to become youngest congresswoman ever, says her generation is 'waking up'
 - [https://www.foxnews.com/media/25-year-old-republican-bids-become-youngest-congresswoman-ever-generation-waking](https://www.foxnews.com/media/25-year-old-republican-bids-become-youngest-congresswoman-ever-generation-waking)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 16:45:57+00:00

New Hampshire GOP hopeful Karoline Leavitt discussed her campaign for Congress and goal to become the youngest woman ever elected.

## SD law requiring ballot petition workers to disclose personal information blocked by appeals court
 - [https://www.foxnews.com/politics/sd-law-requiring-ballot-petition-workers-disclose-personal-information-blocked-appeals-court](https://www.foxnews.com/politics/sd-law-requiring-ballot-petition-workers-disclose-personal-information-blocked-appeals-court)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 16:45:23+00:00

A South Dakota law that would require ballot workers to disclose their personal information has been blocked by a federal appeals court.

## NBA legend Dwyane Wade's petition to legally change teen child's gender, name faces roadblock from ex: report
 - [https://www.foxnews.com/sports/nba-legend-dwyane-wades-petition-legally-change-teen-childs-gender-name-faces-roadblock-ex](https://www.foxnews.com/sports/nba-legend-dwyane-wades-petition-legally-change-teen-childs-gender-name-faces-roadblock-ex)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 16:38:25+00:00

The ex-wife of NBA legend Dwyane Wade accused the former basketball player of trying to exploit their transgender daughter for financial gain.

## OnlyFans model Courtney Clenney hurled racial slurs at beau she later killed: report
 - [https://www.foxnews.com/us/onlyfans-model-courtney-clenney-hurled-racial-slurs-slain-beau-killed](https://www.foxnews.com/us/onlyfans-model-courtney-clenney-hurled-racial-slurs-slain-beau-killed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 16:29:06+00:00

Miami social media star Courtney Clenney called her boyfriend Christian Obumseli the n-word in the weeks before she allegedly stabbed him to death, new evidence shows.

## White House deletes tweet flagged by Twitter that credited Biden for Social Security payment increase
 - [https://www.foxnews.com/politics/white-house-deletes-tweet-flagged-twitter-credited-biden-social-security-payment-increase](https://www.foxnews.com/politics/white-house-deletes-tweet-flagged-twitter-credited-biden-social-security-payment-increase)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 16:28:39+00:00

The White House took down a tweet Wednesday that gave President Biden credit for rising Social Security payments that are the result of 40-year high inflation.

## Supreme Court cases raise questions about college admissions preferences for legacy, athlete applicants
 - [https://www.foxnews.com/media/supreme-court-cases-raises-questions-fairness-college-admissions-preferences-legacy-athlete-applicants](https://www.foxnews.com/media/supreme-court-cases-raises-questions-fairness-college-admissions-preferences-legacy-athlete-applicants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 16:28:28+00:00

Oral arguments in the affirmative action Supreme Court cases raise questions about the fairness of the admissions process for legacy and athlete admissions.

## ICC looks to reopen investigation into crime allegations against Venezuela
 - [https://www.foxnews.com/world/icc-looks-reopen-investigation-crimes-against-humanity-committed-venezuela](https://www.foxnews.com/world/icc-looks-reopen-investigation-crimes-against-humanity-committed-venezuela)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 16:26:21+00:00

The International Criminal Court is seeking to reopen an investigation into torture and killing allegations committed by the Venezuelan security forces.

## Judy Coughlin, wife of ex-Giants coach Tom Coughlin, dead at 77 after battle with rare brain disorder
 - [https://www.foxnews.com/sports/judy-coughlin-wife-ex-giants-coach-tom-coughlin-dead-battle-rare-brain-disorder](https://www.foxnews.com/sports/judy-coughlin-wife-ex-giants-coach-tom-coughlin-dead-battle-rare-brain-disorder)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 16:26:17+00:00

Tom Coughlin's wife, Judy, died at the age of 77, the family announced Tuesday. The former coach revealed last year she was battling a brain disorder.

## 2 brothers fatally stabbed a Detroit-area mother about 60 times, her 11-year-old daughter over 20 times
 - [https://www.foxnews.com/us/2-brothers-fatally-stabbed-detroit-area-mother-60-times-11-year-old-daughter-20-times](https://www.foxnews.com/us/2-brothers-fatally-stabbed-detroit-area-mother-60-times-11-year-old-daughter-20-times)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 16:25:27+00:00

Two brothers were convicted of fatally stabbing a Michigan woman and her young daughter. The brothers are facing mandatory life sentences without parole.

## NJ police capture gunman accused of shooting 2 Newark officers at 'close range'
 - [https://www.foxnews.com/us/nj-police-capture-gunman-accused-shooting-2-newark-officers-close-range](https://www.foxnews.com/us/nj-police-capture-gunman-accused-shooting-2-newark-officers-close-range)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 16:23:37+00:00

New Jersey law enforcement agents have captured the "armed and dangerous" suspect accused in the attempted murder of two Newark police officers on Tuesday.

## Dodge's electric muscle car may switch to gasoline someday
 - [https://www.foxnews.com/auto/dodges-electric-muscle-car-gasoline](https://www.foxnews.com/auto/dodges-electric-muscle-car-gasoline)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 16:20:08+00:00

Dodge CEO Tim Kuniskis said the Charger Daytona SRT electric muscle car is built on a platform that can accommodate an internal combustion engine if needed.

## Herschel Walker hits back after 'SNL' mocks his candidacy: 'Warnock needs some help'
 - [https://www.foxnews.com/media/herschel-walker-hits-back-snl-mocks-candidacy-warnock-needs-help](https://www.foxnews.com/media/herschel-walker-hits-back-snl-mocks-candidacy-warnock-needs-help)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 16:17:15+00:00

Georgia Senate candidate Herschel Walker said he doesn't take the attacks personally and argued his opponent could use the help after their recent debate.

## George Soros spends big in last-minute attempt to rescue far-left Texas district attorneys
 - [https://www.foxnews.com/politics/george-soros-spends-big-last-minute-attempt-rescue-far-left-texas-district-attorneys](https://www.foxnews.com/politics/george-soros-spends-big-last-minute-attempt-rescue-far-left-texas-district-attorneys)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 16:17:12+00:00

Billionaire George Soros has poured more than $1 million into Texas to help save Bexar County DA Joe Gonzalez and Dallas County DA John Creuzot this November, filings show.

## White suburban women trend Republican in race for Congress as economy tops abortion issue: poll
 - [https://www.foxnews.com/politics/white-suburban-women-trend-republican-race-congress-economy-tops-abortion-issue-poll](https://www.foxnews.com/politics/white-suburban-women-trend-republican-race-congress-economy-tops-abortion-issue-poll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 15:53:16+00:00

White suburban women have shifted 27 percentage points toward the Republican Party ahead of the midterm elections, according to a Wall Street Journal poll.

## Washington Post column calls for Biden, Harris to drop out of 2024 race: 'Unfitness has been demonstrated'
 - [https://www.foxnews.com/media/washington-post-column-calls-biden-harris-drop-2024-race-unfitness-demonstrated](https://www.foxnews.com/media/washington-post-column-calls-biden-harris-drop-2024-race-unfitness-demonstrated)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 15:52:40+00:00

A scathing Washington Post column from George Will said President Biden and Vice President Kamala Harris should leave public life after their first term.

## Commanders' Dan Snyder hires bank in first step towards possible team sale
 - [https://www.foxnews.com/sports/commanders-dan-synder-hires-bank-in-first-step-towards-possible-team-sale](https://www.foxnews.com/sports/commanders-dan-synder-hires-bank-in-first-step-towards-possible-team-sale)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 15:44:17+00:00

Dan Snyder has previously said he would not sale the Washington Commanders but announced Wednesday that a bank was hired "to consider potential transactions."

## Russia launches rocket with military satellite, UN looks to block space arms race
 - [https://www.foxnews.com/world/russia-launches-rocket-military-satellite-un-block-space-arms-race](https://www.foxnews.com/world/russia-launches-rocket-military-satellite-un-block-space-arms-race)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 15:41:06+00:00

Russia launched a Soyuz rocket carrying a military satellite into space as the U.N. looks to stave off a space arms race amid heightened tensions between the U.S. and Russia.

## North Carolina man fires at car leaving 4-year-old child with minor injury
 - [https://www.foxnews.com/us/north-carolina-man-fires-car-leaving-4-year-old-child-minor-injury](https://www.foxnews.com/us/north-carolina-man-fires-car-leaving-4-year-old-child-minor-injury)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 15:39:24+00:00

A man from North Carolina shot a car during a 'rolling road rage' situation. A child was injured but was treated on the scene and didn't require further medical attention.

## White Ohio police officer who fatally shot a Black driver in 2017 must pay the man's family $4.4 million
 - [https://www.foxnews.com/us/white-ohio-police-officer-fatally-shot-black-driver-2017-must-pay-mans-family-4-4-million](https://www.foxnews.com/us/white-ohio-police-officer-fatally-shot-black-driver-2017-must-pay-mans-family-4-4-million)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 15:29:08+00:00

A police officer in Ohio fatally shot a Black man inside his car in 2017. The officer has been ordered to pay the man's family $4.4 million.

## Republicans more enthusiastic to vote in midterms than Democrats, polls show
 - [https://www.foxnews.com/politics/republicans-more-enthusiastic-to-vote-in-midterms-than-democrats-polls-show](https://www.foxnews.com/politics/republicans-more-enthusiastic-to-vote-in-midterms-than-democrats-polls-show)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 15:28:11+00:00

Enthusiasm to vote in the midterm elections has plummeted sharply among Democrats compared to the run-up to the 2018 midterms, according to new polling data.

## 'Harry Potter' star Daniel Radcliffe doubles down on denouncing J.K. Rowling's transgender comments
 - [https://www.foxnews.com/entertainment/harry-potter-star-daniel-radcliffe-doubles-down-not-agreeing-creators-transgender-comments](https://www.foxnews.com/entertainment/harry-potter-star-daniel-radcliffe-doubles-down-not-agreeing-creators-transgender-comments)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 15:23:40+00:00

"Harry Potter" star Daniel Radcliffe reflected on why he spoke out against creator J.K. Rowling's comments about transgender people and how not everyone in the movie shares her opinions.

## Democrats worry they did 'poor job' with midterm messaging on economy: 'Having half a conversation'
 - [https://www.foxnews.com/media/democrats-worry-they-did-poor-job-midterm-messaging-economy-having-half-conversation](https://www.foxnews.com/media/democrats-worry-they-did-poor-job-midterm-messaging-economy-having-half-conversation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 15:21:51+00:00

Democratic leaders have started to second-guess their midterm messaging just days before the election as several worry about how they discuss the economy.

## Man who shot 2 US Marshals during a standoff in Tennessee sentenced to 40 years in prison
 - [https://www.foxnews.com/us/man-shot-2-us-marshals-during-standoff-tennessee-sentenced-40-years-prison](https://www.foxnews.com/us/man-shot-2-us-marshals-during-standoff-tennessee-sentenced-40-years-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 15:17:45+00:00

A man who shot two U.S. Marshalls in Tennessee has been sentenced to 40 years in federal prison. The man pleaded guilty to assault on a federal officer with a deadly weapon.

## Miss Puerto Rico and Miss Argentina reveal they secretly got married after keeping ‘relationship private’
 - [https://www.foxnews.com/entertainment/miss-puerto-rico-miss-argentina-secretly-married-relationship-private](https://www.foxnews.com/entertainment/miss-puerto-rico-miss-argentina-secretly-married-relationship-private)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 15:17:16+00:00

Mariana Varela from Argentina and Fabiola Valentín from Puerto Rico both took to Instagram to post a sweet video montage of their love for one another, including engagement photos.

## Parents in liberal enclave accused of ‘right-wing' school board takeover for demanding ‘transparency’
 - [https://www.foxnews.com/politics/parents-liberal-enclave-accused-right-wing-school-board-takeover-demanding-transparency](https://www.foxnews.com/politics/parents-liberal-enclave-accused-right-wing-school-board-takeover-demanding-transparency)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 15:12:55+00:00

A school board campaign in San Francisco's Bay Area is receiving backlash over calls to get "back to the basics" in the classroom. Activist parents believe it's a "right-wing takeover."

## Early voting data shows Republicans participating at higher rate than 2020; Democrats stay nearly the same
 - [https://www.foxnews.com/politics/early-voting-data-shows-republicans-participating-higher-rate-2020-democrats-stay-nearly-same](https://www.foxnews.com/politics/early-voting-data-shows-republicans-participating-higher-rate-2020-democrats-stay-nearly-same)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 15:09:07+00:00

New data shows that Democrats continue to vote early at a greater rate than Republicans, but the gap is narrowing in this year's midterm elections compared to 2020.

## NY mom grieving daughter allegedly killed by estranged husband blames Hochul policies for murder
 - [https://www.foxnews.com/us/ny-mom-grieving-daughter-allegedly-killed-estranged-husband-blames-hochul-policies-murder](https://www.foxnews.com/us/ny-mom-grieving-daughter-allegedly-killed-estranged-husband-blames-hochul-policies-murder)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 15:04:53+00:00

New York mom Tammy Hudson blamed Gov. Hochul's support of the no-cash-bail law for the murder of her daughter Keaira Bennefield, who was allegedly killed by her estranged husband.

## Republicans slam DHS' ongoing crackdown on 'disinformation' after disbanding controversial governance board
 - [https://www.foxnews.com/politics/republicans-slam-dhs-ongoing-crackdown-disinformation-disbanding-controversial-governance-board](https://www.foxnews.com/politics/republicans-slam-dhs-ongoing-crackdown-disinformation-disbanding-controversial-governance-board)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 14:44:52+00:00

Republicans are accusing the Department of Homeland Security of colluding with Big Tech amid newly published documents showing expanded crackdown on "disinformation."

## Florida deputies searching for mother, daughter last tracked in North Carolina
 - [https://www.foxnews.com/us/florida-deputies-searching-mother-daughter-last-tracked-north-carolina](https://www.foxnews.com/us/florida-deputies-searching-mother-daughter-last-tracked-north-carolina)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 14:41:48+00:00

Deputies in Florida are searching for a missing mother and her 2-year-old daughter. The two didn't show up for work and school after visiting family out of state last week.

## Man 'ran out' of Halloween candy, handed out possible ‘marijuana gummies’ instead: report
 - [https://www.foxnews.com/us/man-ran-out-halloween-candy-handed-out-possible-marijuana-gummies-instead-report](https://www.foxnews.com/us/man-ran-out-halloween-candy-handed-out-possible-marijuana-gummies-instead-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 14:31:29+00:00

Jarod Feilen, 25, was arrested after allegedly handing out gummy bears in packaging that smelled of marijuana to kids in South Chicago Heights, Illinois, on Halloween.

## Texas jury awards $21 million to family of man left in vegetative state after routine surgery
 - [https://www.foxnews.com/us/texas-jury-awards-21-million-family-of-man-left-in-vegetative-state-after-routine-surgery](https://www.foxnews.com/us/texas-jury-awards-21-million-family-of-man-left-in-vegetative-state-after-routine-surgery)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 14:30:05+00:00

The family of a Texas man who was left in a vegetative state after what was supposed to be routine leg surgery has been awarded $21 million by a Texas jury.

## Tennis stars slam video of coach striking, kicking teen player: 'I can't believe what I am seeing'
 - [https://www.foxnews.com/sports/tennis-stars-slam-video-coach-striking-kicking-teen-player-cant-believe-seeing](https://www.foxnews.com/sports/tennis-stars-slam-video-coach-striking-kicking-teen-player-cant-believe-seeing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 14:28:10+00:00

A tennis coach was seen on video hitting and kicking a 14-year-old girl and the clip, posted to social media, garnered a huge reaction in the tennis world.

## 'New' 1,200 horsepower 1972 Chevrolet K5 Blazer is a Bully
 - [https://www.foxnews.com/auto/horsepower-1972-chevrolet-k5-blazer-bully](https://www.foxnews.com/auto/horsepower-1972-chevrolet-k5-blazer-bully)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 14:23:34+00:00

The Ringbrothers custom car shop has rebuilt a 1972 Chevrolet K5 Blazer with a 1,200 horsepower engine and a host of new parts for the SEMA auto show.

## Obama takes to TikTok with 'painful' get-out-the-vote message
 - [https://www.foxnews.com/politics/obama-tiktok-painful-get-out-vote-message](https://www.foxnews.com/politics/obama-tiktok-painful-get-out-vote-message)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 14:19:12+00:00

Former President Barack Obama joined "Under The Desk News" on TikTok to motivate midterm election voters, urging action on climate change, abortion and gun control.

## Texas' lottery numbers for Tuesday, Nov. 1
 - [https://www.foxnews.com/us/texas-lottery-numbers-tuesday-nov-1](https://www.foxnews.com/us/texas-lottery-numbers-tuesday-nov-1)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 14:02:27+00:00

The Mega Million's estimated jackpot is $119,000,000. The Powerball estimated jackpot is $1,200,000,000. The Cash 5 numbers for Tuesday, Nov. 1 are 08-27-29-30-32.

## Drew Barrymore's iconic 'ET' red cowboy hat still fits 40 years after film's premiere
 - [https://www.foxnews.com/entertainment/drew-barrymores-iconic-et-red-hat-still-fits-40-years-later](https://www.foxnews.com/entertainment/drew-barrymores-iconic-et-red-hat-still-fits-40-years-later)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 13:59:10+00:00

Actress Drew Barrymore tried on the same red cowboy hat her younger self wore during the beloved 1982 film "E.T.," and it still fits 40 years after the film originally released.

## Illinois Democrats push back against controversial law eliminating cash bail: 'Cowering to criminals'
 - [https://www.foxnews.com/media/illinois-democrats-push-controversial-law-eliminating-cash-bail-cowering-criminals](https://www.foxnews.com/media/illinois-democrats-push-controversial-law-eliminating-cash-bail-cowering-criminals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 13:56:53+00:00

Chicago mayoral candidate Raymond Lopez (D) weighed in on Illinois' controversial SAFE-T Act on 'Fox & Friends' Wednesday, ripping soft-on-crime policies.

## Biden to deliver unscheduled speech at Capitol
 - [https://www.foxnews.com/politics/biden-deliver-unscheduled-speech-capitol](https://www.foxnews.com/politics/biden-deliver-unscheduled-speech-capitol)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 13:53:53+00:00

President Biden will deliver a speech at the U.S. Capitol on Monday.

## NFL trade deadline winners and losers: Breakdown of record day
 - [https://www.foxnews.com/sports/nfl-trade-deadline-winners-losers-breakdown-record-day](https://www.foxnews.com/sports/nfl-trade-deadline-winners-losers-breakdown-record-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 13:46:19+00:00

The NFL trade deadline featured a handful of trades, particularly with potential contenders for the playoffs. Read about who on the deadline and who lost.

## Kansas woman who helmed female ISIS battalion sentenced to 20 years in prison
 - [https://www.foxnews.com/us/kansas-woman-helmed-female-isis-battalion-sentenced-20-years-prison](https://www.foxnews.com/us/kansas-woman-helmed-female-isis-battalion-sentenced-20-years-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 13:45:39+00:00

A 42-year-old woman who was born in Kansas was sentenced by a judge to 20 years in prison Tuesday for leading an all-female ISIS battalion in Raqqa, Syria.

## Dick Durbin dragged for claiming free speech 'does not include spreading misinformation': 'It literally does'
 - [https://www.foxnews.com/media/dick-durbin-dragged-claiming-free-speech-include-spreading-misinformation-literally-does](https://www.foxnews.com/media/dick-durbin-dragged-claiming-free-speech-include-spreading-misinformation-literally-does)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 13:40:46+00:00

Sen. Dick Durbin was mocked by critics for claiming free speech "does not included spreading misinformation to downplay political violence" while scolding Elon Musk.

## Internal DHS emails describe ‘rough’ meeting between Mayorkas, Border Patrol agents
 - [https://www.foxnews.com/politics/internal-dhs-emails-describe-rough-meeting-between-mayorkas-border-patrol-agents](https://www.foxnews.com/politics/internal-dhs-emails-describe-rough-meeting-between-mayorkas-border-patrol-agents)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 13:36:02+00:00

DHS officials described a "rough" January meeting between Border Patrol agents and Secretary Alejandro Mayorkas, according to new email provided to Fox News.

## Tony Hawk's 'The Skatepark Project' teaches community organizing skills to youths
 - [https://www.foxnews.com/us/tony-hawks-skatepark-project-teaches-community-organizing-skills-youths](https://www.foxnews.com/us/tony-hawks-skatepark-project-teaches-community-organizing-skills-youths)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 13:34:56+00:00

Tony Hawk started a fellowship program that teaches 15 skateboarding enthusiasts about community organizing and project management so they can build skateparks in their neighborhoods.

## Migos' record label claims Takeoff killed by 'stray bullet,' condemns 'senseless violence'
 - [https://www.foxnews.com/entertainment/migos-record-label-claims-takeoff-killed-stray-bullet-condemns-senseless-violence](https://www.foxnews.com/entertainment/migos-record-label-claims-takeoff-killed-stray-bullet-condemns-senseless-violence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 13:34:42+00:00

The record label representing Kirsnick Khari Ball, a rapper known as Takeoff and member of the group Migos, is claiming he was killed by a “stray bullet” in Houston.

## Zeldin attack ad against Hochul features 93-year-old NY woman murdered at home by suspect out on no bail
 - [https://www.foxnews.com/politics/zeldin-attack-ad-against-hochul-features-93-year-old-ny-woman-murdered-home-suspect-out-no-bail](https://www.foxnews.com/politics/zeldin-attack-ad-against-hochul-features-93-year-old-ny-woman-murdered-home-suspect-out-no-bail)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 13:34:12+00:00

New York Republican gubernatorial candidate Lee Zeldin released a new ad attacking Gov. Kathy Hochul's support for cashless bail featuring the murder of 93-year-old Connie Tuori.

## Missing Arkansas hiker found alive at Buffalo National River
 - [https://www.foxnews.com/us/missing-arkansas-hiker-found-alive-buffalo-national-river](https://www.foxnews.com/us/missing-arkansas-hiker-found-alive-buffalo-national-river)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 13:29:52+00:00

Clinton “Preston” Smith, 67, was found alive Tuesday, five days after going missing from the Hemmed-in-Hollow Trail in Buffalo National River, the National Park Service said.

## NYPD officer missing, presumed dead in Guyana after waterfall tour gone awry: reports
 - [https://www.foxnews.com/us/nypd-officer-missing-presumed-dead-guyana-waterfall-tour-gone-awry-reports](https://www.foxnews.com/us/nypd-officer-missing-presumed-dead-guyana-waterfall-tour-gone-awry-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 13:25:30+00:00

NYPD Officer Gladstone Haynes reportedly was swept beneath the water near Orinduik Falls, on the border of Guyana and Brazil, while vacationing in South America with friends.

## NJ suspect at-large in Newark police officer shooting considered 'armed and dangerous,' officials say
 - [https://www.foxnews.com/us/nj-suspect-large-newark-police-officer-shooting-considered-armed-dangerous-officials-say](https://www.foxnews.com/us/nj-suspect-large-newark-police-officer-shooting-considered-armed-dangerous-officials-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 12:55:04+00:00

New Jersey investigators are hunting for the "armed and dangerous" suspect accused in the attempted murder of two Newark police officers on Tuesday afternoon.

## Adele addresses wrong mispronunciation of her name for years, reveals ‘perfectly’ correct way
 - [https://www.foxnews.com/entertainment/adele-addresses-wrong-mispronunciation-name-correct](https://www.foxnews.com/entertainment/adele-addresses-wrong-mispronunciation-name-correct)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 12:51:24+00:00

Adele pointed out how to correctly pronounce her name while hosting a happy hour with fans, to give a sneak peek of her new music video "I Drink Wine."

## Mother of Capitol Police officer Brian Sicknick blames 'people like Kari Lake' for his death
 - [https://www.foxnews.com/politics/mother-capitol-police-officer-brian-sicknick-blames-people-kari-lake-death](https://www.foxnews.com/politics/mother-capitol-police-officer-brian-sicknick-blames-people-kari-lake-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 12:45:05+00:00

Gladys Sicknick says "people like Kari Lake" are to blame for casualties of January 6th Capitol riot, including her son Brian Sicknick.

## Florida's lottery numbers for Tuesday, Nov. 1
 - [https://www.foxnews.com/us/floridas-lottery-numbers-for-tuesday-nov-1](https://www.foxnews.com/us/floridas-lottery-numbers-for-tuesday-nov-1)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 12:40:53+00:00

The Mega Million's estimated jackpot is $119,000,000. The Powerball estimated jackpot is $1,200,000,000. The Cash4Life numbers for Tuesday, Nov. 1 are 18-24-25-43-52.

## Ohio's lottery numbers for Tuesday, Oct. 1
 - [https://www.foxnews.com/us/ohios-lottery-numbers-tuesday-oct-1](https://www.foxnews.com/us/ohios-lottery-numbers-tuesday-oct-1)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 12:40:37+00:00

The Mega Million's estimated jackpot is $119,000,000. The Powerball estimated jackpot is $1,200,000,000. The Lucky For Life numbers for Tuesday, Nov. 1 are 01-06-10-35-45.

## Massachusetts police arrest man suspected of breaking into college students' apartments
 - [https://www.foxnews.com/us/massachusetts-police-arrest-suspect-merrimack-college-student-apartment-breakins](https://www.foxnews.com/us/massachusetts-police-arrest-suspect-merrimack-college-student-apartment-breakins)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 12:39:14+00:00

The North Andover Police Department says it has arrested Adam Auditore, who is accused of breaking into multiple apartments occupied by Merrimack College students.

## Danish leader quits in bid to form new Cabinet despite win
 - [https://www.foxnews.com/world/danish-leader-quits-bid-form-new-cabinet-despite-win](https://www.foxnews.com/world/danish-leader-quits-bid-form-new-cabinet-despite-win)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 12:29:07+00:00

Prime Minister Mette Frederiksen and her Social Democrat government, after winning first place in Denmark's election, chose to step down pin order to build a political coalition.

## Lara Trump hits back after The New Yorker blames 'right-wing mothers' for school board 'wars': 'Shame on them'
 - [https://www.foxnews.com/media/lara-trump-hits-back-new-yorker-blames-right-wing-mothers-school-board-wars-shame](https://www.foxnews.com/media/lara-trump-hits-back-new-yorker-blames-right-wing-mothers-school-board-wars-shame)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 12:26:23+00:00

Lara Trump said parents are 'fed up' on "Fox & Friends First" after The New Yorker blamed 'right-wing mothers" for tensions between school boards and parents.

## Sharks' Timo Meier shows off concentration to score impressive goal vs Ducks
 - [https://www.foxnews.com/sports/sharks-timo-meier-shows-off-concentration-score-impressive-goal-vs-ducks](https://www.foxnews.com/sports/sharks-timo-meier-shows-off-concentration-score-impressive-goal-vs-ducks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 12:12:13+00:00

Timo Meier scored an impressive goal for the San Jose Sharks on Tuesday night in the second period but the Anaheim Ducks got the better of them.

## ACLU slams government working with Big Tech to decide ‘what is true or false’
 - [https://www.foxnews.com/media/aclu-slams-government-working-big-tech-decide-true-false](https://www.foxnews.com/media/aclu-slams-government-working-big-tech-decide-true-false)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 12:00:52+00:00

The ACLU condemned the DHS for working with Big Tech to regulate speech, warning that government should not do so as a ploy to "get around" constitutional rights.

## WWE's Carmella reveals she had ectopic pregnancy: 'Why doesn’t anyone ever talk about this?'
 - [https://www.foxnews.com/sports/wwes-carmella-reveals-she-ectopic-pregnancy-doesnt-anyone-talk](https://www.foxnews.com/sports/wwes-carmella-reveals-she-ectopic-pregnancy-doesnt-anyone-talk)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 11:57:19+00:00

WWE superstar Carmella, whose real name is Leah Van Dale, revealed she suffered an ectopic pregnancy in an Instagram post on Monday.

## Russia rejoins Ukraine grain export wartime deal
 - [https://www.foxnews.com/world/russia-rejoins-ukraine-grain-export-wartime-deal](https://www.foxnews.com/world/russia-rejoins-ukraine-grain-export-wartime-deal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 11:53:27+00:00

Russia agreed to resume its role in exporting grain under the Turkey-UN brokered deal with Ukraine to secure Black Sea shipping lanes.

## Severe weather may impact Plains as West sees snow, rain
 - [https://www.foxnews.com/us/severe-weather-may-impact-plains-west-sees-snow-rain](https://www.foxnews.com/us/severe-weather-may-impact-plains-west-sees-snow-rain)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 11:39:55+00:00

There is the potential for unsettled weather over the Plains, including hail, tornadoes and flooding rain. The West will see mountain snow and rain along the coast.

## Jayme Hoskins, wife of Phillies star, buys beer for fans during World Series Game 3
 - [https://www.foxnews.com/sports/jayme-hoskins-wife-phillies-star-buys-beer-fans-world-series-game-3](https://www.foxnews.com/sports/jayme-hoskins-wife-phillies-star-buys-beer-fans-world-series-game-3)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 11:32:30+00:00

Jayme Hoskins, the wife of Philadelphia Phillies star Rhys Hoskins, proved to be the real MVP during the team's Game 3 win over the Houston Astros.

## The Russia-Iran monster: Biden’s strategic incompetence has created a new menace for America
 - [https://www.foxnews.com/opinion/the-russia-iran-monster-bidens-strategic-incompetence-create-new-menace-america](https://www.foxnews.com/opinion/the-russia-iran-monster-bidens-strategic-incompetence-create-new-menace-america)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 11:21:09+00:00

This analytic piece describes recent examples of the Russia-Iran military cooperation and its broader implications for US security.

## Astros' Lance McCullers Jr accused of tipping pitches during World Series beat down
 - [https://www.foxnews.com/sports/astros-lance-mccullers-jr-accused-tipping-pitches-world-series-beat-down](https://www.foxnews.com/sports/astros-lance-mccullers-jr-accused-tipping-pitches-world-series-beat-down)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 11:13:11+00:00

Houston Astros starter Lance McCullers Jr. addressed whether he was tipping pitchers during the shellacking he received in the World Series.

## How many times a week should you wash your hair? Experts say it depends.
 - [https://www.foxnews.com/lifestyle/how-many-times-week-wash-hair-experts-say-depends](https://www.foxnews.com/lifestyle/how-many-times-week-wash-hair-experts-say-depends)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 11:00:44+00:00

A trichologist and dermatologist tell Fox News Digital how often people should shampoo-wash their hair. Here are some hair care tips for straight, wavy, curly and kinky-coily hair.

## Dr. Phil guest shocked by the dumbing down of America's children: 'a coverup within the... system'
 - [https://www.foxnews.com/media/dr-phil-guest-shocked-dumbing-down-americas-children-coverup](https://www.foxnews.com/media/dr-phil-guest-shocked-dumbing-down-americas-children-coverup)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 11:00:27+00:00

A college professor on the Dr. Phil show shocked the host in a discussion on the systemic coverup of glaring issues in the U.S. education system.

## Nets' Kevin Durant 'shocked' over Steve Nash's departure
 - [https://www.foxnews.com/sports/nets-kevin-durant-shocked-steve-nashs-departure](https://www.foxnews.com/sports/nets-kevin-durant-shocked-steve-nashs-departure)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 10:38:02+00:00

Kevin Durant and Joe Harris both spoke about Steve Nash's departure from the Brooklyn Nets after their game against the Chicago Bulls on Tuesday night.

## Musk's midterm plans for Twitter, GOP on the offensive in Biden country and more top headlines
 - [https://www.foxnews.com/us/twitter-elon-musk-midterm-elections](https://www.foxnews.com/us/twitter-elon-musk-midterm-elections)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 10:30:59+00:00

Fox News First brings you Fox News' top headlines every morning.

## Dodge's new mystery muscle car keeps blowing up, but why?
 - [https://www.foxnews.com/auto/dodge-mystery-muscle-car-blowing-up](https://www.foxnews.com/auto/dodge-mystery-muscle-car-blowing-up)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 10:28:03+00:00

Dodge CEO Tim Kuniskis said the brand's last V8-powered muscle car is being delayed by development issues that have caused its engine to blow up.

## Ross Chastain's teammate explains the truly 'crazy' part of his Martinsville move
 - [https://www.foxnews.com/sports/ross-chastains-teammate-explains-truly-crazy-part-martinsville-move](https://www.foxnews.com/sports/ross-chastains-teammate-explains-truly-crazy-part-martinsville-move)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 10:16:57+00:00

Ross Chastain's move impressed teammate Daniel Suárez. It was not about Chastain pulling it off but for even thinking about doing it is what made it interesting.

## U.S. Justice Department charges ex-boxer with trafficking more than $1 billion in cocaine
 - [https://www.foxnews.com/sports/ex-boxer-charged-in-connection-to-1-billion-attempted-cocaine-smuggling-operation](https://www.foxnews.com/sports/ex-boxer-charged-in-connection-to-1-billion-attempted-cocaine-smuggling-operation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 10:13:05+00:00

Former professional heavyweight boxer Goran Gogic was charged with trafficking over 20 tons of cocaine valued at more than $1 billion through U.S. ports.

## Reported Chinese land buy in Florida for primate testing won't end well: Dr. Lisa Jones-Engel
 - [https://www.foxnews.com/media/reported-chinese-land-buy-florida-primate-testing-wont-end-well-dr-lisa-jones-engel](https://www.foxnews.com/media/reported-chinese-land-buy-florida-primate-testing-wont-end-well-dr-lisa-jones-engel)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 10:00:54+00:00

Animal expert Dr. Lisa Jones-Engel warned about a reported property acquired by a Chinese company for the purpose of primate testing on "Jesse Watters Primetime."

## California could be hit with 'conservative tsunami' after group's voter registration efforts: Grenell
 - [https://www.foxnews.com/politics/california-conservative-tsunami-after-organizations-voter-registration-efforts-grenell](https://www.foxnews.com/politics/california-conservative-tsunami-after-organizations-voter-registration-efforts-grenell)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 10:00:48+00:00

EXCLUSIVE: “Fix California” founder Amb. Ric Grenell says the Golden State is “about to be hit with a conservative tsunami” after the organization registered thousands of new right-leaning voters ahead of Election Day.

## Bono says he took a nap in the Lincoln Bedroom after having drinks with Obama
 - [https://www.foxnews.com/entertainment/bono-says-took-nap-lincoln-bedroom-drinks-obama](https://www.foxnews.com/entertainment/bono-says-took-nap-lincoln-bedroom-drinks-obama)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 09:51:28+00:00

Bono said because of an allergy to salicylates found in wine he ended up taking a nap in the Lincoln Bedroom during a visit with then-President Obama at the White House.

## Biden blasted for blaming high inflation on ‘war in Iraq,’ confusion on where his son died: ‘This is just sad’
 - [https://www.foxnews.com/media/biden-blasted-blaming-high-inflation-war-iraq-confusion-son-died-sad](https://www.foxnews.com/media/biden-blasted-blaming-high-inflation-war-iraq-confusion-son-died-sad)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 09:00:38+00:00

Conservatives on Twitter fact-checked several gaffes President Joe Biden made during his Tuesday address on inflation and the economy, including one about his own son.

## Iowa teenagers accused of killing Spanish teacher over bad grade
 - [https://www.foxnews.com/us/iowa-teenagers-accused-killing-spanish-teacher-over-bad-grade](https://www.foxnews.com/us/iowa-teenagers-accused-killing-spanish-teacher-over-bad-grade)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 08:49:54+00:00

Two Iowa high school students allegedly killed their Spanish teacher last year in response to receiving a poor grade. The teenagers will be tried as adults.

## Theo James says initial ‘White Lotus’ nude scene was ‘way too much, reshot ‘more subtle’ version
 - [https://www.foxnews.com/entertainment/theo-james-says-initial-white-lotus-nude-scene-way-too-much-reshot-more-subtle-version](https://www.foxnews.com/entertainment/theo-james-says-initial-white-lotus-nude-scene-way-too-much-reshot-more-subtle-version)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 08:16:50+00:00

Theo James said "The White Lotus" crew reshot his character's first nude scene after the original version was "way too much."

## Liz Cheney praises Nancy Pelosi as a 'tremendous leader,' warns against electing a GOP majority
 - [https://www.foxnews.com/politics/liz-cheney-praises-nancy-pelosi-tremendous-leader-warns-against-electing-gop-majority](https://www.foxnews.com/politics/liz-cheney-praises-nancy-pelosi-tremendous-leader-warns-against-electing-gop-majority)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 08:07:30+00:00

During an interview on Tuesday, Rep. Liz Cheney praised House Speaker Nancy Pelosi and spoke against the idea of certain Republicans winning in the midterms.

## Hochul 'lying' about blue-state crime wave, 'gaslighting' public, Caldwell says
 - [https://www.foxnews.com/media/hochul-lying-blue-state-crime-wave-gaslighting-public-caldwell](https://www.foxnews.com/media/hochul-lying-blue-state-crime-wave-gaslighting-public-caldwell)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 08:00:56+00:00

Fox News contributor Gianno Caldwell lost his brother to Chicago's gun violence, and called out New York Governor Kathleen Hochul for gaslighting the public.

## Media belatedly acknowledge GOP surge, including among conservatives they dismissed
 - [https://www.foxnews.com/shows/media-buzz/media-belatedly-acknowledge-gop-surge-including-conservatives-dismissed](https://www.foxnews.com/shows/media-buzz/media-belatedly-acknowledge-gop-surge-including-conservatives-dismissed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 07:17:10+00:00

The mainstream media has been reluctant to acknowledge the anticipated 'red wave' sweeping next week's midterm elections, but lately are changing their tune.

## African Americans aligned with GOP messaging on inflation, but will it pay off at the polls?
 - [https://www.foxnews.com/politics/african-americans-aligned-gop-messaging-inflation-pay-off-polls](https://www.foxnews.com/politics/african-americans-aligned-gop-messaging-inflation-pay-off-polls)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 07:00:05+00:00

African American voters appear to be aligned with GOP messaging on inflation with less than a week to go before the Nov. 8 midterm elections.

## Police video shows Hope Solo dragged out of car during DWI arrest in March
 - [https://www.foxnews.com/sports/police-video-shows-hope-solo-dragged-out-car-dwi-arrest](https://www.foxnews.com/sports/police-video-shows-hope-solo-dragged-out-car-dwi-arrest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 06:04:31+00:00

Former Team USA goalkeeper Hope Solo was dragged out of her car during DWI arrest in North Carolina in March. She plead guilt in July.

## New mom wins IRONMAN championship: First American to win in over 25 years
 - [https://www.foxnews.com/lifestyle/new-mom-wins-ironman-championship-first-american-win-25-years](https://www.foxnews.com/lifestyle/new-mom-wins-ironman-championship-first-american-win-25-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 06:00:58+00:00

Chelsea Sodaro won the IRONMAN World Championship 18 months after giving birth to her daughter. She became the first American to win in over 25 years and shared thoughts with Fox News Digital.

## Pro-Kemp Georgia sheriffs furious at Stacey Abrams for 'good ole boy' remarks: 'Vile and disgusting'
 - [https://www.foxnews.com/media/pro-kemp-georgia-sheriffs-furious-stacey-abrams-good-ole-boy-remarks-vile-disgusting](https://www.foxnews.com/media/pro-kemp-georgia-sheriffs-furious-stacey-abrams-good-ole-boy-remarks-vile-disgusting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 06:00:46+00:00

Georgia sheriffs supporting Brian Kemp spoke out harshly against Stacey Abrams in interviews with Fox News Digital for suggesting some of them were racists.

## SAFE-T Act: Illinois sheriff warns prosecutors not to be ‘overzealous’ targeting victims stopping criminals
 - [https://www.foxnews.com/politics/safe-t-act-illinois-sheriff-warns-prosecutors-overzealous-targeting-victims-stopping-criminals](https://www.foxnews.com/politics/safe-t-act-illinois-sheriff-warns-prosecutors-overzealous-targeting-victims-stopping-criminals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 06:00:45+00:00

Jefferson County Sheriff Jeff Bullard says the SAFE-T Act is not supported by the 'vast majority' of citizens, police officers, attorneys and judges in Illinois.

## SURROUNDED: Democrats forced to defend home territory as Republicans set sights on Biden House districts
 - [https://www.foxnews.com/politics/democrats-forced-defend-home-territory-republicans-set-sights-biden-house-districts](https://www.foxnews.com/politics/democrats-forced-defend-home-territory-republicans-set-sights-biden-house-districts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 06:00:33+00:00

House Democrats are being forced to defend areas thought to be safely in their hands as Republicans increase spending in districts won by President Biden in 2020 by double digits.

## Florence Pugh, Gisele Bündchen, Jennifer Aniston and more stars told to change their looks for Hollywood glory
 - [https://www.foxnews.com/entertainment/florence-pugh-gisele-bundchen-jennifer-aniston-stars-told-to-change-looks-hollywood-glory](https://www.foxnews.com/entertainment/florence-pugh-gisele-bundchen-jennifer-aniston-stars-told-to-change-looks-hollywood-glory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 06:00:19+00:00

Florence Pugh bashed executives' suggestions to lose weight for a show, while Gisele Bündchen, Jennifer Lopez and Jennifer Aniston also fought against criticism.

## Top teachers unions spent at least $2.25 million to re-elect Whitmer in Michigan
 - [https://www.foxnews.com/politics/top-teachers-unions-spent-2-25-million-re-elect-whitmer-michigan](https://www.foxnews.com/politics/top-teachers-unions-spent-2-25-million-re-elect-whitmer-michigan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 06:00:07+00:00

Two of the largest teachers unions in the United States donated more than $1 million each to a group supporting Michigan Democrat Gov. Gretchen Whitmer.

## Iran sent more than 3,500 drones to Russia for its war against Ukraine: intel dossier
 - [https://www.foxnews.com/world/iran-sent-more-than-3500-drones-russia-war-ukraine-intel-dossier](https://www.foxnews.com/world/iran-sent-more-than-3500-drones-russia-war-ukraine-intel-dossier)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 06:00:05+00:00

Fox News Digital obtained new intelligence from an Iranian opposition group, revealing the increased transfer of Iranian-produced drones to Russia for use in its war against Ukraine.

## American energy is on ballot and it's time to send Biden, Democrats a clear message
 - [https://www.foxnews.com/opinion/american-energy-ballot-time-send-biden-democrat-clear-message](https://www.foxnews.com/opinion/american-energy-ballot-time-send-biden-democrat-clear-message)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 06:00:03+00:00

President Joe Biden has been waging a war on American energy since the day he took office. Rising energy prices are hurting Americans who can least afford it.

## White House vows action on gun violence in late-night statement, says 'thoughts and prayers' not enough
 - [https://www.foxnews.com/politics/white-house-vows-action-gun-violence-late-night-statement-says-thoughts-prayers-not-enough](https://www.foxnews.com/politics/white-house-vows-action-gun-violence-late-night-statement-says-thoughts-prayers-not-enough)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 05:26:20+00:00

The White House released a statement late Tuesday night in which press secretary Karine Jean-Pierre said thoughts and prayers are not enough to reduce gun violence.

## LAURA INGRAHAM: Should there be amnesty for officials who made 'disastrous' COVID decisions?
 - [https://www.foxnews.com/media/laura-ingraham-should-amnesty-officials-made-disastrous-covid-decisions](https://www.foxnews.com/media/laura-ingraham-should-amnesty-officials-made-disastrous-covid-decisions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 05:23:57+00:00

Laura Ingraham discusses how the decisions made about COVID created lasting damage in a multitude of areas still playing out today on "The Ingraham Angle."

## North Korea launches at least 10 missiles; South Korea answers with its own test missiles
 - [https://www.foxnews.com/world/north-korea-launches-least-10-missiles-south-korea-answers-with-own-test-missiles](https://www.foxnews.com/world/north-korea-launches-least-10-missiles-south-korea-answers-with-own-test-missiles)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 05:07:32+00:00

South Korea launched at least three test missiles on Wednesday after North Korea fired off at least 10 missiles. The barrage of fire comes after NoKo threatened to use nuclear weapons.

## John McVay, legendary 49ers executive and Hall of Fame inductee, dead at 91: 'A class act'
 - [https://www.foxnews.com/sports/john-mcvay-49ers-legendary-executive-hall-fame-inductee-dead-91-class-act](https://www.foxnews.com/sports/john-mcvay-49ers-legendary-executive-hall-fame-inductee-dead-91-class-act)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 05:01:41+00:00

Former San Francisco 49ers and New York Giants head coach John McVay died at 91 years old on Tuesday. He was critical in five Super Bowl titles that the Niners accomplished during his reign.

## James Corden says he 'inadvertently' told a 2018 Ricky Gervais joke after accusations of stealing
 - [https://www.foxnews.com/entertainment/james-corden-says-inadvertently-told-2018-ricky-gervais-joke-accusations-stealing](https://www.foxnews.com/entertainment/james-corden-says-inadvertently-told-2018-ricky-gervais-joke-accusations-stealing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 05:00:26+00:00

James Corden faces accusations of stealing a Ricky Gervais joke after a line in a his monologue was almost verbatim from a 2018 Gervais stand-up special.

## GREG GUTFELD: California has a mad man problem
 - [https://www.foxnews.com/opinion/greg-gutfeld-california-has-mad-man-problem](https://www.foxnews.com/opinion/greg-gutfeld-california-has-mad-man-problem)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 04:54:51+00:00

Greg Gutfeld weighs in on what California Gov. Gavin Newsom had to say about the attack on Paul Pelosi on 'Gutfeld!'

## 2022 World Series: Phillies hit five home runs to take 2-1 series lead over Astros
 - [https://www.foxnews.com/sports/2022-world-series-phillies-hit-five-home-runs-take-2-1-series-lead-astros](https://www.foxnews.com/sports/2022-world-series-phillies-hit-five-home-runs-take-2-1-series-lead-astros)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 04:50:22+00:00

The Philadelphia Phillies are two wins away from their first World Series victory since 2008 after hitting TK home runs in their Game 3 win over the Houston Astros.

## Astros' Justin Verlander meets Phillies fan who flipped him the bird: 'He had a great sense of humor'
 - [https://www.foxnews.com/sports/astros-justin-verlander-meets-phillies-fan-flipped-bird](https://www.foxnews.com/sports/astros-justin-verlander-meets-phillies-fan-flipped-bird)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 04:28:09+00:00

Longtime Phillies fan Stephanie Di Ianni flipped the Astros' bus the bird on Monday night, and Justin Verlander did it right back. The two met before Game 3 on Tuesday.

## On this day in history, Nov. 2, 1948, Truman defeats Dewey, shocking pundits and mocking headline writers
 - [https://www.foxnews.com/lifestyle/this-day-history-nov-2-1948-truman-defeats-dewey-pundits-headline-writers](https://www.foxnews.com/lifestyle/this-day-history-nov-2-1948-truman-defeats-dewey-pundits-headline-writers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 04:02:33+00:00

President Harry S. Truman successfully led the United States out of World War II — then overcame domestic dissent and predictions of the pundits to win the 1948 election.

## Federal prison transport guard pleads guilty to sexually assaulting detainee
 - [https://www.foxnews.com/us/federal-prison-transport-guard-pleads-guilty-sexually-assaulting-detainee](https://www.foxnews.com/us/federal-prison-transport-guard-pleads-guilty-sexually-assaulting-detainee)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 03:28:01+00:00

A federal prison transport guard faces up to 10 years imprisonment for sexually assaulting a woman he was transporting from Washington to Minnesota.

## Chicago woman held on $2 million bail after admitting to stabbing unborn baby's father to death
 - [https://www.foxnews.com/us/chicago-woman-held-2-million-bail-stabbing-unborn-babys-father-death](https://www.foxnews.com/us/chicago-woman-held-2-million-bail-stabbing-unborn-babys-father-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 03:12:43+00:00

A Chicago woman was arrested and charged with first-degree murder after admitting she stabbed her unborn baby's father in the thigh.

## New York Magazine writer admits media 'afraid' to criticize the left on COVID, Black Lives Matter
 - [https://www.foxnews.com/media/new-york-magazine-writer-admits-media-afraid-criticize-left-covid-black-lives-matter](https://www.foxnews.com/media/new-york-magazine-writer-admits-media-afraid-criticize-left-covid-black-lives-matter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 02:54:48+00:00

New York Magazine writer Jonathan Chait was attacked after finally admitting that media members hesitated to criticize left-wing ideas for fear of being cancelled.

## Dana Perino on Pelosi attack: This is why crime is such a concern for people
 - [https://www.foxnews.com/media/dana-perino-pelosi-attack-crime-concern-people](https://www.foxnews.com/media/dana-perino-pelosi-attack-crime-concern-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 02:51:42+00:00

'The Five' co-hosts discuss new charges against David DePape, the man accused of assaulting Paul Pelosi, and Democrats blaming Republicans for the attack.

## TUCKER CARLSON: Affirmative action is immoral
 - [https://www.foxnews.com/opinion/tucker-carlson-affirmative-action-immoral](https://www.foxnews.com/opinion/tucker-carlson-affirmative-action-immoral)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 02:40:38+00:00

Fox News host Tucker Carlson gives his take on the upcoming Supreme Court case evaluating the constitutionality of affirmative action in college admission.

## SEAN HANNITY: Every voter needs to do their part and 'take nothing for granted'
 - [https://www.foxnews.com/media/sean-hannity-every-voter-needs-to-do-their-part-take-nothing-for-granted](https://www.foxnews.com/media/sean-hannity-every-voter-needs-to-do-their-part-take-nothing-for-granted)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 02:27:40+00:00

Sean Hannity expresses the importance of every voter to participating and remembering the pivotal nature of these midterm elections on "Hannity."

## NY mom killed in front of children hours after husband freed on no bail in alleged Facebook video beating
 - [https://www.foxnews.com/us/ny-mom-killed-front-children-hours-husband-freed-on-no-bail-alleged-facebook-video-beating](https://www.foxnews.com/us/ny-mom-killed-front-children-hours-husband-freed-on-no-bail-alleged-facebook-video-beating)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 01:58:07+00:00

A New York State man allegedly shot and killed his estranged wife in front of her children hours after being arrested for allegedly beating her.

## U.S. Capitol Police officers weren't watching live home security cameras when Paul Pelosi was attacked
 - [https://www.foxnews.com/us/u-s-capitol-police-officers-werent-watching-live-home-security-cameras-when-paul-pelosi-was-attacked](https://www.foxnews.com/us/u-s-capitol-police-officers-werent-watching-live-home-security-cameras-when-paul-pelosi-was-attacked)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 01:57:59+00:00

U.S. Capitol Police officers have survellance cameras outside the Pelosi's residence in San Francisco, but weren't watching it when David DePape allegedly broke in and injured Paul Pelosi.

## Charles Barkley says Kyrie Irving should have been suspended for antisemitic film comments
 - [https://www.foxnews.com/sports/charles-barkley-says-kyrie-irving-suspended-antisemitic-film-comments](https://www.foxnews.com/sports/charles-barkley-says-kyrie-irving-suspended-antisemitic-film-comments)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 01:57:52+00:00

Charles Barkley had strong words for Kyrie Irving, saying the Brooklyn Nets guard should have been suspended for his comments about a film Irving posted to Twitter.

## Julie Powell, food writer of 'Julie & Julia,' dead at 49
 - [https://www.foxnews.com/entertainment/julie-powell-food-writer-of-julie-julia-dead-49](https://www.foxnews.com/entertainment/julie-powell-food-writer-of-julie-julia-dead-49)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 01:53:18+00:00

Julie Powell, the internet blogger behind "Julie & Julia," has died at 49. She was found at her home in New York after suffering cardiac arrest.

## Hillary Clinton questions whether voters 'really understand' what’s at stake in the midterm elections
 - [https://www.foxnews.com/media/hillary-clinton-questions-voters-understand-stake-midterm-elections](https://www.foxnews.com/media/hillary-clinton-questions-voters-understand-stake-midterm-elections)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 01:52:38+00:00

Former Democratic presidential candidate Hillary Clinton suggested voters were unaware of the real threats against them this upcoming midterm election season.

## Florida woman shot and killed while laying in bed with her children in 'targeted hit,' sheriff says
 - [https://www.foxnews.com/us/florida-woman-shot-killed-laying-bed-children-targeted-hit-sheriff-says](https://www.foxnews.com/us/florida-woman-shot-killed-laying-bed-children-targeted-hit-sheriff-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 01:44:09+00:00

A woman was shot and killed by a masked gunman inside a Florida home shortly after midnight on Tuesday in what authorities say was a "targeted hit."

## Video shows rising boxing star standing next to Takeoff seconds before fatal shooting
 - [https://www.foxnews.com/sports/video-shows-boxing-star-standing-takeoff-seconds-fatal-shooting](https://www.foxnews.com/sports/video-shows-boxing-star-standing-takeoff-seconds-fatal-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 01:38:16+00:00

Up-and-coming boxer Shakur Stevenson was reportedly spotted next to Takeoff seconds before shots rang out that killed the 28-year-old Migos rapper in Houston.

## California high school football senior, 17, shot and killed in hometown
 - [https://www.foxnews.com/sports/california-high-school-football-senior-17-shot-killed-hometown](https://www.foxnews.com/sports/california-high-school-football-senior-17-shot-killed-hometown)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 01:28:54+00:00

Richard Reed, a 17-year-old two-way star and senior at Silverado High School in Victorville, California, was shot and killed Sunday night in his hometown.

## Judge Judy celebrates 80th birthday with 'idyllic' Bahamas getaway: 'One could not have a better birthday'
 - [https://www.foxnews.com/entertainment/judge-judy-celebrates-80th-birthday-idyllic-bahamas-getaway](https://www.foxnews.com/entertainment/judge-judy-celebrates-80th-birthday-idyllic-bahamas-getaway)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 01:24:58+00:00

Judge Judy Sheindlin recently celebrated her 80th birthday in the Bahamas with her family. Here's a look at how her career progressed since "Judge Judy" debuted in 1996.

## JESSE WATTERS: Gavin Newsom has to answer for Paul Pelosi attack and Cali crime
 - [https://www.foxnews.com/media/jesse-watters-gavin-newsom-answer-paul-pelosi-attack-cali-crime](https://www.foxnews.com/media/jesse-watters-gavin-newsom-answer-paul-pelosi-attack-cali-crime)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 01:22:14+00:00

Fox News host Jesse Watters asked for answers from California officials on why the Paul Pelosi attack happened during his monologue on "Jesse Watters Primetime."

## Ex-Chiefs coach Britt Reid sentenced to three years in jail after 2021 car crash
 - [https://www.foxnews.com/sports/ex-chiefs-coach-britt-reid-sentenced-three-years-jail-2021-car-crash](https://www.foxnews.com/sports/ex-chiefs-coach-britt-reid-sentenced-three-years-jail-2021-car-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 01:14:52+00:00

Ex-Kansas City Chiefs coach Britt Reid, the son of head coach Andy Reid, was sentenced to three years in prison Tuesday as a result of his 2021 car crash.

## Leftover Halloween pumpkins and jack-o'-lanterns: What to do with them?
 - [https://www.foxnews.com/lifestyle/leftover-halloween-pumpkins-jack-o-lanterns-what-to-do](https://www.foxnews.com/lifestyle/leftover-halloween-pumpkins-jack-o-lanterns-what-to-do)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 01:13:26+00:00

What can you do with leftover Halloween pumpkins and jack-o'-lanterns? Composting, cooking and donating are just a few ideas that make pumpkins reusable.

## US military conducting onsite inspections of weapons provided to Ukraine
 - [https://www.foxnews.com/world/us-military-conducting-onsite-inspections-weapons-provided-ukraine](https://www.foxnews.com/world/us-military-conducting-onsite-inspections-weapons-provided-ukraine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 01:04:34+00:00

U.S. military personnel are conducting inspections to ensure that money and weapons provided to Ukrainian troops is being properly used in Ukraine's fight against Russia.

## 'Hannity' on good news for Republicans in Pennsylvania, New Hampshire
 - [https://www.foxnews.com/transcript/hannity-good-news-republicans-pennsylvania-new-hampshire](https://www.foxnews.com/transcript/hannity-good-news-republicans-pennsylvania-new-hampshire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 01:00:28+00:00

Guests: Newt Gingrich, Kelly Tshibaka, Tudor Dixon, Ron DeSantis, Lee Zeldin, Ted Cruz

## Cindy Crawford, 56, hires 'coach' to navigate stress: ‘Maybe I'm just going through a midlife crisis'
 - [https://www.foxnews.com/entertainment/cindy-crawford-hired-coach-navigate-midlife-crisis](https://www.foxnews.com/entertainment/cindy-crawford-hired-coach-navigate-midlife-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 00:55:35+00:00

Cindy Crawford is opening up about how she is navigating the second half of her 50s. The supermodel shared that she hired a "coach" to help her with her stress.

## Texas preschool teacher allegedly brought THC gummies to class that sickened four kids
 - [https://www.foxnews.com/us/texas-preschool-teacher-allegedly-brought-thc-gummies-class-sickened-four-kids](https://www.foxnews.com/us/texas-preschool-teacher-allegedly-brought-thc-gummies-class-sickened-four-kids)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 00:41:41+00:00

A Texas preschool teacher was arrested and is facing charges after four students under 2 years of age became ill from THC gummies.

## Tim Ryan, JD Vance sound off on crime, abortion and immigration during Fox News town hall
 - [https://www.foxnews.com/politics/tim-ryan-jd-vanc-crime-abortion-immigration-during-fox-news-town-hall](https://www.foxnews.com/politics/tim-ryan-jd-vanc-crime-abortion-immigration-during-fox-news-town-hall)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 00:40:55+00:00

Ohio Senate candidates Tim Ryan, a Democrat, and his Republican challenger, JD Vance, offered their takes on a number of issues as they took part in a Fox News town hall event.

## Rep. Swalwell says GOP seems 'more comfortable' with 'violence' than 'voting'
 - [https://www.foxnews.com/media/rep-swalwell-gop-seem-comfortable-violence-voting](https://www.foxnews.com/media/rep-swalwell-gop-seem-comfortable-violence-voting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 00:31:24+00:00

Rep. Eric Swalwell suggested the upcoming election will discern whether America will decide its future 'through violence' or 'through voting.'

## JD Vance calls Big Tech 'the biggest threat to American democracy today'
 - [https://www.foxnews.com/media/jd-vance-calls-big-tech-biggest-threat-american-democracy-today](https://www.foxnews.com/media/jd-vance-calls-big-tech-biggest-threat-american-democracy-today)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 00:21:06+00:00

GOP hopeful JD Vance slammed Big Tech censorship as the "biggest threat to American democracy" at the Fox News town hall just one week before the 2022 midterms.

## Tennessee headlines first College Football Playoff rankings, Georgia down to third
 - [https://www.foxnews.com/sports/tennessee-headlines-first-college-football-playoff-rankings-georgia-down-third](https://www.foxnews.com/sports/tennessee-headlines-first-college-football-playoff-rankings-georgia-down-third)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 00:20:22+00:00

After beginning the season unranked in the AP poll, the Tennessee Volunteers are now the top-ranked football team in the nation after their 8-0 start.

## Fetterman and Oz separated by 1 point in race for Pennsylvania senator: Poll
 - [https://www.foxnews.com/politics/fetterman-oz-separated-one-point-race-pennsylvania-senator-newest-poll](https://www.foxnews.com/politics/fetterman-oz-separated-one-point-race-pennsylvania-senator-newest-poll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 00:17:08+00:00

The Pennsylvania Senate race between John Fetterman and Mehmet Oz is a virtual tie with Fetterman leading by 1 point, according to a new poll.

## Paul Pelosi attack: David DePape was on 'suicide mission' during alleged attack, targeted other politicians
 - [https://www.foxnews.com/us/paul-pelosi-attack-david-depape-was-suicide-mission-during-alleged-attack-targeted-other-politicians](https://www.foxnews.com/us/paul-pelosi-attack-david-depape-was-suicide-mission-during-alleged-attack-targeted-other-politicians)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 00:01:03+00:00

David DePape, the man accused of violently attacking Paul Pelosi, was on a suicide mission during the alleged attack and was targeting other politicians.

## Tucker Carlson: Democrats are defending the indefensible
 - [https://www.foxnews.com/transcript/tucker-carlson-democrats-defending-indefensible](https://www.foxnews.com/transcript/tucker-carlson-democrats-defending-indefensible)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-02 00:00:50+00:00

Guests: Vivek Ramaswamy, Marc Siegel, Mehmet Oz, Glenn Greenwald, Adam Laxalt, Nayib Bukele


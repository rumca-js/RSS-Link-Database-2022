# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Bookmarking for Unix Chads (For Browsers, Terminals, IDEs and everything else)
 - [https://www.youtube.com/watch?v=d_11QaTlf1I](https://www.youtube.com/watch?v=d_11QaTlf1I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2022-11-02 15:59:26+00:00

This is how GNU/Unix chads do bookmarking. Literally all you need is a text file and a line of shell code to get what your fancy $39-a-year bookmark manager does. This is just another super-basic use-case of dmenu.

Obviously this doesn't just apply to URLs, but I show that I use it here for text

My website: https://lukesmith.xyz
Classical books reprinted by me: https://lindypress.net
Get all my videos off YouTube: https://videos.lukesmith.xyz
or Odysee: https://odysee.com/$/invite/@Luke:7

Please donate: https://donate.lukesmith.xyz
BTC: bc1qd20r7phdct3t0e0z6jqs55ulectg25pngt7hyl
XMR: 89yML3AtqnTNdo3wNuoaW44D94Zx1kBZNSBc9SyNxGdaKEZwZNdVzvy9zpbzJMzysiWZEU3b5LwjQ3XwWuQsknCF8JK73yv

OR affiliate links to things l use:
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.


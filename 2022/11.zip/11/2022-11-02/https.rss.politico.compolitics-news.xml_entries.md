# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en-US

## Trump lawyers saw Justice Thomas as 'only chance' to stop 2020 election certification
 - [https://www.politico.com/news/2022/11/02/trump-lawyers-saw-justice-thomas-as-only-chance-to-stop-2020-election-certification-00064592](https://www.politico.com/news/2022/11/02/trump-lawyers-saw-justice-thomas-as-only-chance-to-stop-2020-election-certification-00064592)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2022-11-02 09:17:37+00:00

“We want to frame things so that Thomas could be the one to issue some sort of stay or other circuit justice opinion saying Georgia is in legitimate doubt,” Trump attorney Kenneth Chesebro wrote in an email exchange.


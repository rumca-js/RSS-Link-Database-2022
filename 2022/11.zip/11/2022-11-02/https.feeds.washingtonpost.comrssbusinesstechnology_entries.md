# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Call of Duty based some maps on real places. Not everyone was happy.
 - [https://www.washingtonpost.com/video-games/2022/11/02/modern-warfare-2-valderas-getty-breenbergh/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/video-games/2022/11/02/modern-warfare-2-valderas-getty-breenbergh/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-11-02 15:58:46+00:00

Several maps in “Call of Duty: Modern Warfare II” use real world locales as inspiration. One such source of inspiration is considering legal action.

## Prince William County board approves controversial data center project
 - [https://www.washingtonpost.com/dc-md-va/2022/11/02/prince-william-vote-data-center/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/dc-md-va/2022/11/02/prince-william-vote-data-center/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-11-02 13:58:27+00:00

The "Digital Gateway" plan to build 27 million square feet of data centers in a rural portion of Prince William was the subject of a contentious 14-hour vote.

## VR is funny. Why isn’t it pitched that way?
 - [https://www.washingtonpost.com/video-games/2022/11/02/virtual-reality-funny-playstation-vr2/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/video-games/2022/11/02/virtual-reality-funny-playstation-vr2/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-11-02 13:00:27+00:00

The virtual reality killer app won’t be epic. Normal video games already do that better. So why not let VR be funny and weird?

## A new feature for old Echo speakers could boost your home WiFi setup
 - [https://www.washingtonpost.com/technology/2022/11/02/eero-built-in-amazon-echo-speaker/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/11/02/eero-built-in-amazon-echo-speaker/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-11-02 07:00:58+00:00

Some Amazon Echos can double as WiFi range extenders. It’s not a perfect fix.

## Workers flee world’s biggest iPhone plant in China over virus restrictions
 - [https://www.washingtonpost.com/world/2022/11/02/china-foxconn-iphone-factory-zhengzhou-covid/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/world/2022/11/02/china-foxconn-iphone-factory-zhengzhou-covid/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-11-02 06:41:18+00:00

Foxconn is struggling to contain an exodus of workers at the plant making half the world's iPhones in the latest example of the economic and social costs China's zero covid policy.

## Musk says Twitter won’t restore banned accounts for weeks
 - [https://www.washingtonpost.com/technology/2022/11/02/musk-twitter-bans-trump/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/11/02/musk-twitter-bans-trump/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-11-02 01:48:02+00:00

Elon Musk pledged not to restore banned accounts — such as former president Donald Trump’s — to the platform until after the midterm elections.


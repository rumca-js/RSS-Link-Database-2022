# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## How Old Is Health Care?
 - [https://www.youtube.com/watch?v=mMmIlnAyK1k](https://www.youtube.com/watch?v=mMmIlnAyK1k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-11-03 00:00:00+00:00

Head to https://linode.com/scishow to get a $100 60-day credit on a new Linode account. Linode offers simple, affordable, and accessible Linux cloud solutions and services.

Health care has existed long before your insurance premiums. Exactly why we can hopefully chalk up to empathy, but there's less guessing as to when it may have began.

Hosted by: Hank Green (he/him)

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Matt Curls, Alisa Sherbow, Dr. Melvin Sanicas, Harrison Mills, Adam Brainard, Chris Peters, charles george, Piya Shedden, Alex Hackman, Christopher R, Boucher, Jeffrey Mckishen, Ash, Silas Emrys, Eric Jensen, Kevin Bealer, Jason A Saslow, Tom Mosner, Tomás Lagos González, Jacob, Christoph Schwanke, Sam Lutfi, Bryan Cloer
----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow #science #education
----------
Sources:
http://onlinedigeditions.com/publication/?i=113770&article_id=1078681&view=articleBrowser
https://www.sciencedirect.com/science/article/pii/S0277379118305389 
https://pubmed.ncbi.nlm.nih.gov/15815618/ 
https://www.nature.com/articles/s41586-022-05160-8 
https://www.hindawi.com/journals/scientifica/2016/8927654/

Image Sources:
https://www.nature.com/articles/s41586-022-05160-8#Fig7
https://www.gettyimages.com/detail/video/two-female-teammates-helping-injured-african-woman-on-stock-footage/1321218264
https://www.gettyimages.com/detail/photo/hand-paintings-at-the-cave-of-hands-in-santa-cruz-royalty-free-image/1203879005
https://www.gettyimages.com/detail/photo/young-woman-getting-vaccinated-in-a-medical-clinic-royalty-free-image/1364924500   
https://commons.wikimedia.org/wiki/File:Dmanisi_fossils_D_3444_%2B_D_3900_(Replika).jpg
https://www.gettyimages.com/detail/photo/diabetic-test-kit-royalty-free-image/1354249154 
https://www.gettyimages.com/detail/video/blending-strawberries-with-plant-milk-in-blender-stock-footage/678816306 
https://www.eurekalert.org/multimedia/551179
https://www.gettyimages.com/detail/photo/paleontologists-hand-with-brush-cleansing-fossil-royalty-free-image/1255327507
https://commons.wikimedia.org/wiki/File:Homo_Neanderthalensis_Adult_Male_Reconstruction.jpg
https://commons.wikimedia.org/wiki/File:3._Shanidar_cave,_a_paleolithic_cave_in_Bradost_Mountain,_Erbil_Governorate,_Iraqi_Kurdistan._April_4,_2014.jpg
https://commons.wikimedia.org/wiki/File:Shanidar_I_skull_and_skeleton,_c._60,000_to_45,00o_BCE._Iraq_Museum.jpg
https://www.eurekalert.org/multimedia/926681
https://www.gettyimages.com/detail/video/cave-drawings-02-stock-footage/1411354615
https://commons.wikimedia.org/wiki/File:Skeletal_remains_of_Shanidar_II,_c._60,000_to_45,000_BCE._Iraq_Museum.jpg
https://www.gettyimages.com/detail/photo/pre-history-painting-royalty-free-image/941056132
https://www.gettyimages.com/detail/video/pills-stock-footage/1318825722
https://www.gettyimages.com/detail/photo/yarroew-flowers-royalty-free-image/1361298439
https://www.gettyimages.com/detail/photo/cornflowers-royalty-free-image/104696040
https://www.gettyimages.com/detail/photo/yellow-blossoming-common-ragwort-from-close-royalty-free-image/542813776
https://www.gettyimages.com/detail/photo/juicy-cones-of-delicious-fragrant-ephedra-berries-royalty-free-image/1387641049
https://commons.wikimedia.org/wiki/File:Shanidar_Cave_-_overview.jpg
https://commons.wikimedia.org/wiki/File:Shanidar_skull.jpg
https://www.gettyimages.com/detail/photo/cave-paintings-on-the-wall-painted-ocher-rock-royalty-free-image/1039521866
https://commons.wikimedia.org/wiki/File:Homo_sapiens_neanderthalensis.jpg


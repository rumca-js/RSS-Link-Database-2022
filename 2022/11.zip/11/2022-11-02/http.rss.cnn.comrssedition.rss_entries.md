# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## North Korean missile launch triggers evacuation warnings in Japan
 - [https://www.cnn.com/collections/north-korea-shenanigans-intl-1102022/](https://www.cnn.com/collections/north-korea-shenanigans-intl-1102022/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 23:53:16+00:00



## Biden calls midterms a 'defining moment' for democracy amid political violence and voter intimidation
 - [https://biztoc.com/p/hinjtmwp?ref=rss&rd=1](https://biztoc.com/p/hinjtmwp?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 23:45:26+00:00

The president's remarks come after the attack on House Speaker Nancy Pelosi's husband in California and a restraining order against a group accused of voter intimidation in Arizona. <br /><br /> #arizona #nancypelosi #voter #attack

## Trump news
 - [https://biztoc.com/p/yja6m23w?ref=rss&rd=1](https://biztoc.com/p/yja6m23w?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 23:45:12+00:00

Donald Trump says Twitter has become ‘very boring’ since he got banned
    Donald Trump’s attorneys believed a direct appeal to Supreme Court Justice Clarence Thomas was their best hope of... <br /><br /> #supremecourt #emailmessages #election #clarencethomas #attorneys #johneastman #politico

## Biden issues stark warning of threat to US democracy
 - [https://www.cnn.com/collections/us-election-intl-110222/](https://www.cnn.com/collections/us-election-intl-110222/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 23:19:34+00:00



## Kanye West can't sell 'White Lives Matter' shirts because two Black men own the trademark
 - [https://www.cnn.com/2022/11/02/us/white-lives-matter-trademark-reaj/index.html](https://www.cnn.com/2022/11/02/us/white-lives-matter-trademark-reaj/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 23:04:34+00:00

Two Black radio hosts in Arizona could be a potential roadblock if Kanye West ever decided  to sell his "White Lives Matter" T-shirts in the United States.

## World Series Game 4 live: Aaron Nola takes mound for Phillies against Astros’ Cristian Javier
 - [https://biztoc.com/p/2smm3mt2?ref=rss&rd=1](https://biztoc.com/p/2smm3mt2?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 23:00:00+00:00

Rolling report: The Phillies host the Astros in Game 4 of the World Series in Citizens Bank Park. Follow all the action with Bryan Armen Graham <br /><br /> #cristianjavierrolling #worldseries #aaronnola #astros #citizensbankpark #bryanarmengrahamrolling #thephillies

## Live updates: US midterm election and early voting news
 - [https://biztoc.com/p/cknk8an9?ref=rss&rd=1](https://biztoc.com/p/cknk8an9?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 22:51:36+00:00

The 2022 US midterm election is just days away, and candidates across the country are making their final pitch as early voting is underway. Follow CNN for the latest election news and updates. <br /><br /> #voting #candidates #midtermelection

## Russia changes course, rejoins key deal with Ukraine
 - [https://www.cnn.com/videos/world/2022/11/02/russia-black-sea-grain-export-deal-ibrahim-kalin-intv-ist-intl-vpx-contd.cnn](https://www.cnn.com/videos/world/2022/11/02/russia-black-sea-grain-export-deal-ibrahim-kalin-intv-ist-intl-vpx-contd.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 22:35:50+00:00

Russia said it was rejoining the agreement that guarantees safe passage for ships carrying vital grain exports from Ukraine, a move that may help ease concerns about global food supplies that were raised when Moscow suspended its participation in the pact. Turkish Presidential Spokesperson Ibrahim Kalin discusses Russia's decision.

## Netanyahu is the projected winner, but it was Ben Gvir crowned on election night
 - [https://biztoc.com/p/pac75f9z?ref=rss&rd=1](https://biztoc.com/p/pac75f9z?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 22:23:00+00:00

The once unthinkably fringe politician is likely headed into the government, where his stances and those of others in the far-right may play a large role in shaping Israel's future <br /><br /> #bengvir #netanyahu #election #israel #fringepolitician

## Lab-made 'magic mushroom' improved depression in 3 weeks in large study
 - [https://www.cnn.com/2022/11/02/health/psilocybin-magic-mushroom-depression-wellness/index.html](https://www.cnn.com/2022/11/02/health/psilocybin-magic-mushroom-depression-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 22:21:15+00:00

A single dose of a synthetic version of the mind-altering component of magic mushrooms, psilocybin, improved depression in people with a treatment-resistant form of the disease, a new study found.

## See the moment an air raid siren interrupts a live TV broadcast in South Korea
 - [https://www.cnn.com/videos/world/2022/11/02/north-korea-missiles-launch-south-korea-air-raid-siren-ripley-dnt-lead-vpx.cnn](https://www.cnn.com/videos/world/2022/11/02/north-korea-missiles-launch-south-korea-air-raid-siren-ripley-dnt-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 22:19:00+00:00

South Korean officials said on Wednesday that North Korea fired more missiles in a single day that it ever has before, prompting South Korea's first air raid warning in 6 years. CNN's Will Ripley reports.

## 2022 World Series: Houston fans heckle Philadelphia restaurants that didn't accept Astros' catering requests
 - [https://biztoc.com/p/yz9u842q?ref=rss&rd=1](https://biztoc.com/p/yz9u842q?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 22:14:00+00:00

The two restaurants were initially accused of denying the Astros because they're the visiting team, but they both denied that claim <br /><br /> #philadelphia #worldseries #houston #astros #restaurants

## U.S. Accuses North Korea of Sending Russia Munitions
 - [https://biztoc.com/p/2aujxe8p?ref=rss&rd=1](https://biztoc.com/p/2aujxe8p?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 22:11:17+00:00

A White House official says North Korea has covertly sent a “significant number” of artillery shells to Russia. <br /><br /> #northkorea

## Clarence Thomas was 'key' to a plan to delay certification of 2020 election, Trump lawyers said in emails
 - [https://biztoc.com/p/u2ectwua?ref=rss&rd=1](https://biztoc.com/p/u2ectwua?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 22:03:00+00:00

A lawyer for former President Donald Trump described Supreme Court Justice Clarence Thomas as "key" to Trump's plan to delay Congress' certification of President Joe Biden's victory through... <br /><br /> #lawyers #supremecourt #election #clarencethomas #lawyer #victory #donaldtrump

## Analyst breaks down what Trump lawyers' email reveals
 - [https://www.cnn.com/videos/politics/2022/11/02/trump-lawyers-email-justice-clarence-thomas-january-6-honig-murray-lead-vpx.cnn](https://www.cnn.com/videos/politics/2022/11/02/trump-lawyers-email-justice-clarence-thomas-january-6-honig-murray-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 22:00:42+00:00

CNN senior legal analyst Elie Honig discusses emails from Trump lawyers that describe Justice Clarence Thomas as "key" in a plan to delay the 2020 election certification.

## What Happened To Matthew Perry’s Voice? The ‘Friends’ Star Just Confirmed Why He Has Speech Issues On Diane Sawyer Special
 - [https://biztoc.com/p/z5efvfbz?ref=rss&rd=1](https://biztoc.com/p/z5efvfbz?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 22:00:31+00:00

Matthew Perry sat down with Diane Sawyer for an intimate ABC Nightline interview last week in which the Friends alum, 53, opened up about his near-death experience due to drug addiction, and the... <br /><br /> #abcnightline #alum #matthewperry

## Oregon mayor arrested in connection to shooting and road rage incident
 - [https://biztoc.com/p/ysevmgdf?ref=rss&rd=1](https://biztoc.com/p/ysevmgdf?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 21:41:25+00:00

Dowen Jones, elected mayor of Rufus in 2018 with 76 votes, was booked on suspicion of attempted murder and four counts of attempted assault. <br /><br /> #assault #rufus #murder #roadrageincident #dowenjones #shooting #oregon

## Fantasy Football Week 9: FLEX rankings
 - [https://biztoc.com/p/7mkn69gh?ref=rss&rd=1](https://biztoc.com/p/7mkn69gh?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 21:31:24+00:00

Check out how the FLEX options stack up in our Week 9 fantasy rankings. <br /><br /> #fantasyfootball #flex

## Oath Keepers trial witness: Stewart Rhodes urged Trump to stay in power by force
 - [https://biztoc.com/p/fhjgvfk7?ref=rss&rd=1](https://biztoc.com/p/fhjgvfk7?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 21:30:00+00:00

<br /><br /> #stewartrhodes #oathkeepers #trialwitness

## Houston police are searching for witnesses after rapper Takeoff's killing
 - [https://biztoc.com/p/e9uwyphe?ref=rss&rd=1](https://biztoc.com/p/e9uwyphe?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 21:27:34+00:00

<br /><br /> #witnesses #killing #houston #takeoff #rapper

## Israel's Netanyahu nears victory, but trouble may lie ahead
 - [https://biztoc.com/p/9nqdrf56?ref=rss&rd=1](https://biztoc.com/p/9nqdrf56?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 21:23:24+00:00

His new coalition could create headaches for Netanyahu on the global stage. <br /><br /> #coalition #israel #netanyahu #victory

## From Generative Images and Video to Responsible AI: Here's What Google Covered During Its AI@ Event
 - [https://biztoc.com/p/rqany5zc?ref=rss&rd=1](https://biztoc.com/p/rqany5zc?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 21:20:00+00:00

The company revealed new advancements in generative AI images and videos and boosted the capabilities of potentially life saving flood and wildfire detection. <br /><br /> #google #generativeimages

## Phillies-Astros news: Pedro Martinez on how McCullers was tipping pitches; powder blue uniforms coming; Game 4 first pitch
 - [https://biztoc.com/p/gsypkzvs?ref=rss&rd=1](https://biztoc.com/p/gsypkzvs?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 21:12:36+00:00

The Phillies tied a World Series record thanks to their home run derby against the Astros Tuesday night. <br /><br /> #thephillies #mccullers #worldseries #pedromartinez #homerunderby #astros

## Paramount, Moonves to settle sex misconduct cases
 - [https://biztoc.com/p/chwbss3z?ref=rss&rd=1](https://biztoc.com/p/chwbss3z?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 20:52:16+00:00

The attorney general announced that CBS and Moonves would pay $30 million, with much of the money going to CBS shareholders. <br /><br /> #moonves #paramount

## Parkland victims confronted the shooter in court. Here's what they said
 - [https://biztoc.com/p/vnqnku6y?ref=rss&rd=1](https://biztoc.com/p/vnqnku6y?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 20:47:08+00:00

<br /><br /> #victims #parkland #shooter

## Stone Age child's grave site in Finland reveals surprises
 - [https://www.cnn.com/2022/11/02/world/stone-age-child-burial-scn/index.html](https://www.cnn.com/2022/11/02/world/stone-age-child-burial-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 20:42:08+00:00

The burial site of a young child who lived 8,000 years ago has been discovered in Eastern Finland, providing a rare glimpse into how Stone Age humans treated their deceased.

## Parkland school shooter sentenced to life in prison without parole after emotional victims’ statements
 - [https://biztoc.com/p/wt5r8jza?ref=rss&rd=1](https://biztoc.com/p/wt5r8jza?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 20:38:03+00:00

Nikolas Cruz, 24, fatally shot 17 people at Marjory Stoneman Douglas High School in Florida in 2018. <br /><br /> #prison #florida #parkland #victims #nikolascruz #schoolshooter

## Qualcomm shares fall on first-quarter guidance, hiring freeze announced
 - [https://biztoc.com/p/ccka9eax?ref=rss&rd=1](https://biztoc.com/p/ccka9eax?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 20:18:04+00:00

Qualcomm shares fell in extended trading on Wednesday after the chipmaker offered poor first-quarter guidance. <br /><br /> #chipmaker #qualcomm

## Today’s best deals: Black Friday month begins with 4K TVs, iPads, and much more
 - [https://biztoc.com/p/326tqhvi?ref=rss&rd=1](https://biztoc.com/p/326tqhvi?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 20:17:39+00:00

Dealmaster also has gaming mice, smart home devices, MacBooks, and Roomba robot vacuums. <br /><br /> #smarthomedevices #ipads #blackfriday

## Buck stops ... there: Gov. Hochul points finger at 'system, judges' after slain Keaira Bennefield's mom blames her
 - [https://biztoc.com/p/kfhxac74?ref=rss&rd=1](https://biztoc.com/p/kfhxac74?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 20:13:00+00:00

Gov. Kathy Hochul insisted Wednesday that everyone else failed Buffalo’s tragic mom-of-three Keaira Bennefield — and not her or New York’s no-cash-bail laws. <br /><br /> #keairabennefield #buck #kathyhochul #buffalo #mom #judges

## What higher interest rates mean for you
 - [https://www.cnn.com/videos/business/2022/06/15/interest-rates-fed-christine-romans-orig-mss.cnn](https://www.cnn.com/videos/business/2022/06/15/interest-rates-fed-christine-romans-orig-mss.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 20:11:47+00:00

CNN's Chief Business Correspondent Christine Romans breaks down how higher interest rates will impact your wallet.

## Aaron Paul Files Petition to Legally Change Name, Alongside Wife And Son
 - [https://biztoc.com/p/yt5ikap7?ref=rss&rd=1](https://biztoc.com/p/yt5ikap7?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 20:06:44+00:00

Aaron Paul, his wife, and their kid are all goin' Paul,  because the actor and his wife just filed a petition to change all their names -- and Aaron's included in the makeover. <br /><br /> #makeover #aaron #kid #aaronpaul #actor

## 4 people found shot, multiple suspects arrested during reported human smuggling incident in west Houston, police say
 - [https://biztoc.com/p/juuwybvn?ref=rss&rd=1](https://biztoc.com/p/juuwybvn?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 20:06:35+00:00

Houston police are investigating after four people were found shot and several people were arrested during a reported human smuggling incident in west Houston Wednesday afternoon. <br /><br /> #suspects #humansmugglingincident #houston

## Warring parties in Ethiopia agree on 'permanent cessation of hostilities'
 - [https://biztoc.com/p/bgm4xpvt?ref=rss&rd=1](https://biztoc.com/p/bgm4xpvt?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 20:00:00+00:00

The Ethiopian government and the Tigray People's Liberation Front  have agreed to permanently end hostilities, in a significant step toward ending the grinding war that has seen thousands of... <br /><br /> #ethiopia #war #cessation

## Former heavyweight boxer Goran Gogic charged with trafficking over $1 billion worth of cocaine
 - [https://www.cnn.com/2022/11/02/sport/goran-gogic-boxer-cocaine-trafficking-spt-intl/index.html](https://www.cnn.com/2022/11/02/sport/goran-gogic-boxer-cocaine-trafficking-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 19:54:49+00:00

Former heavyweight boxer Goran Gogic was charged with the maritime trafficking of over $1 billion worth of cocaine through US ports, the U.S. Department of Justice said on Monday.

## Ethiopian government, Tigrayan forces agree to truce after two years of war
 - [https://biztoc.com/p/hcw2878z?ref=rss&rd=1](https://biztoc.com/p/hcw2878z?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 19:54:13+00:00

<br /><br /> #forces #tigrayan #war #ethiopian

## Fantasy Football Week 9 lineup decisions: Starts, Sits, Sleepers and Busts to know for every game
 - [https://biztoc.com/p/ckvdstkg?ref=rss&rd=1](https://biztoc.com/p/ckvdstkg?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 19:49:40+00:00

Dig into the players who might be tough start/sit calls in your lineup based on game film notes, stats, more <br /><br /> #sleepers #fantasyfootball #dig #startsitcalls #gamedig

## The damage Kanye West is doing is devastating
 - [https://www.cnn.com/2022/11/02/opinions/kanye-west-antisemitic-comments-carter/index.html](https://www.cnn.com/2022/11/02/opinions/kanye-west-antisemitic-comments-carter/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 19:47:04+00:00

The toxic infection from Kanye West's antisemitic comments is spreading.

## NFL trade deadline 2022 update: Tracking Miami Dolphins trades for Bradley Chubb, Jeff Wilson
 - [https://biztoc.com/p/ut8z5ha6?ref=rss&rd=1](https://biztoc.com/p/ut8z5ha6?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 19:43:13+00:00

The Miami Dolphins made a pair of trades on Tuesday ahead of the NFL’s trade deadline. We look at what they did. <br /><br /> #miamidolphins #jeffwilson #nfl #bradleychubb

## Analysis: Why the GOP is gaining with less than a week to go
 - [https://www.cnn.com/2022/11/02/politics/republicans-advantage-midterms-analysis/index.html](https://www.cnn.com/2022/11/02/politics/republicans-advantage-midterms-analysis/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 19:42:34+00:00

The Democrats' hope to maintain control of at least one chamber in Congress comes down to Republicans blowing it. For a time, that looked quite plausible because of the unpopularity of the GOP brand at large and Republican candidates in specific races.

## Top Democrat Grills Capitol Police About Lawmaker Protection After Pelosi Attack
 - [https://biztoc.com/p/rc5d2c7r?ref=rss&rd=1](https://biztoc.com/p/rc5d2c7r?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 19:37:36+00:00

Representative Zoe Lofgren, Democrat of California and the chairwoman of the Administration Committee, raised questions in a lengthy letter to J. Thomas Manger, the Capitol Police chief. <br /><br /> #representative #zoelofgren #jthomasmanger #grillscapitolpolice #chairwoman #pelosiattack #administrationcommittee #lawmaker

## Former Miss Argentina and ex-Miss Puerto Rico reveal they are married
 - [https://biztoc.com/p/3ehpzyiy?ref=rss&rd=1](https://biztoc.com/p/3ehpzyiy?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 19:35:34+00:00

They both competed in last year’s Miss Grand International beauty pageant in Thailand. <br /><br /> #puertorico #beautypageant #thailand #missgrandinternational #argentina #exmiss

## The world's best cheese for 2022 is revealed
 - [https://www.cnn.com/travel/article/worlds-best-cheese-awards-2022-wales/index.html](https://www.cnn.com/travel/article/worlds-best-cheese-awards-2022-wales/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 19:19:47+00:00

When you gather 4,434 cheeses from 42 countries in one room to find out which is best, there's inevitably a sense of excitement in the air. There is, of course, inevitably also a very, very powerful smell.

## Thousands Tell FAA to Fix Shrinking Airplane Seats
 - [https://biztoc.com/p/3qh3uf5c?ref=rss&rd=1](https://biztoc.com/p/3qh3uf5c?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 19:16:00+00:00

The agency sought public comment on seat sizes and safety; people responded with many more thoughts on flying. <br /><br /> #faa #fixshrinkingairplane

## Miss Argentina and Miss Puerto Rico reveal that they're married
 - [https://www.cnn.com/2022/11/02/americas/miss-argentina-puerto-rico-married-cec/index.html](https://www.cnn.com/2022/11/02/americas/miss-argentina-puerto-rico-married-cec/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 19:09:21+00:00

A new power couple has taken the stage.

## Miss Argentina and Miss Puerto Rico reveal that they're married
 - [https://biztoc.com/p/qwniepv3?ref=rss&rd=1](https://biztoc.com/p/qwniepv3?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 19:09:00+00:00

Mariana Vaerla and Fabiola Valentín, respectively 2020's Miss Argentina and Miss Puerto Rico, stunned and delighted fans by revealing their secret relationship and recent wedding. <br /><br /> #fabiolavalentín #argentina #puertorico #marianavaerla #wedding

## Rufus, Oregon mayor arrested for attempted murder after road rage shooting
 - [https://biztoc.com/p/kdnzr9c9?ref=rss&rd=1](https://biztoc.com/p/kdnzr9c9?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:56:54+00:00

The mayor of Rufus, Oregon, is in custody after allegedly shooting at a family of four during a road rage incident, the Hood River County Sheriff’s Office said on Facebook. <br /><br /> #oregon #rufus #roadrageincident #murder

## Israel election results put Netanyahu’s right-wing coalition back in power
 - [https://biztoc.com/p/7xrvkpi2?ref=rss&rd=1](https://biztoc.com/p/7xrvkpi2?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:56:48+00:00

<br /><br /> #israel #netanyahu #coalition

## Live updates: Stocks slide in volatile trading session after Fed rate hike
 - [https://biztoc.com/p/fijkmbj9?ref=rss&rd=1](https://biztoc.com/p/fijkmbj9?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:56:00+00:00

The Fed is expected to announce a three-quarters of a percentage point rate hike for the fourth consecutive time Wednesday afternoon. But investors hope Fed chair Jerome Powell will suggest that... <br /><br /> #percentagepointratehike #jeromepowell #quillintelligence #danielledimartinobooth #ratehike #chiefstrategist

## Miss Argentina and Miss Puerto Rico reveal they secretly got married
 - [https://biztoc.com/p/zkjcqan8?ref=rss&rd=1](https://biztoc.com/p/zkjcqan8?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:55:02+00:00

A former Miss Argentina and a former Miss Puerto Rico shared that they got married last month after having kept their relationship private. <br /><br /> #puertorico #argentina

## Fighting intensifies near Kherson as Russian forces dig in and tell civilians to leave
 - [https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-11-02-22#h_3063b82e82250c2ad69b4f5878dda65e](https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-11-02-22#h_3063b82e82250c2ad69b4f5878dda65e)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:52:21.268453+00:00



## Parties to war in Ethiopia's Tigray region agree to stop fighting
 - [https://biztoc.com/p/zhf69uki?ref=rss&rd=1](https://biztoc.com/p/zhf69uki?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:52:00+00:00

The Ethiopian government and regional forces from Tigray agreed on Wednesday to cease hostilities, a dramatic diplomatic breakthrough two years into a war that has killed thousands, displaced... <br /><br /> #forces #tigray #war #ethiopia #breakthrough

## Ethiopia's Tigray conflict: Truce agreed
 - [https://biztoc.com/p/awxngq9b?ref=rss&rd=1](https://biztoc.com/p/awxngq9b?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:38:15+00:00

Both sides agree to stop their conflict which has led to a humanitarian crisis and warnings of a famine. <br /><br /> #conflict #tigray #truce #ethiopia #famine

## A far-right surge is set to put Netanyahu back in power. Who are his extremist allies?
 - [https://www.cnn.com/collections/israel-intl-110222/](https://www.cnn.com/collections/israel-intl-110222/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:35:12+00:00



## Eight teams that should have made a deal before the 2022 NFL trade deadline
 - [https://biztoc.com/p/8ggn2jq4?ref=rss&rd=1](https://biztoc.com/p/8ggn2jq4?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:35:00+00:00

The 2022 NFL trade deadline came and went without reinforcements arriving for the Packers' Aaron Rodgers or the Rams' Matthew Stafford. Kevin Patra highlights eight teams that might come to regret... <br /><br /> #kevinpatra #nfl #aaronrodgers #rams #packers #matthewstafford

## Donald Trump reaches settlement with protesters who allege they were assaulted by his security
 - [https://biztoc.com/p/gvsk3wxm?ref=rss&rd=1](https://biztoc.com/p/gvsk3wxm?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:33:45+00:00

Former President Donald Trump settled a civil lawsuit Wednesday that alleged his security guards violently assaulted protesters outside Trump Tower in 2015. <br /><br /> #trumptower #donaldtrump #protesters #securityguards

## LIVE: Federal Reserve unleashes another big rate hike but hints at a pullback
 - [https://biztoc.com/p/tws2iv34?ref=rss&rd=1](https://biztoc.com/p/tws2iv34?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:31:00+00:00

The Federal Reserve pumped up its benchmark interest rate by three-quarters of a point for a fourth straight time. <br /><br /> #pullback #federalreserve #ratehike

## The Rise of Rust, the ‘Viral’ Secure Programming Language That’s Taking Over Tech
 - [https://biztoc.com/p/hzy4yevr?ref=rss&rd=1](https://biztoc.com/p/hzy4yevr?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:27:00+00:00

Rust makes it impossible to introduce some of the most common security vulnerabilities. And its adoption can’t come soon enough. <br /><br /> #rust

## US officials divided over new intelligence suggesting Russian military discussed scenarios for using nuclear weapons
 - [https://biztoc.com/p/kpj8raw6?ref=rss&rd=1](https://biztoc.com/p/kpj8raw6?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:27:00+00:00

Russian military officials have discussed how and under what conditions Russia would use a tactical nuclear weapon on the battlefield in Ukraine, according to a US intelligence assessment... <br /><br /> #battlefield #russian #ukraine #militaryofficials

## A far-right surge is set to put Netanyahu back in power. Who are his extremist allies?
 - [https://biztoc.com/p/pyk86dy5?ref=rss&rd=1](https://biztoc.com/p/pyk86dy5?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:25:00+00:00

Israel's longest-serving prime minister, Benjamin Netanyahu, looks set to storm his way back into power, with partial election results suggesting he and his allies have won a clear majority of... <br /><br /> #knesset #benjaminnetanyahu #israel #primeminister #allies

## Woj: Nets to name Ime Udoka head coach ‘as early as today.’
 - [https://biztoc.com/p/7f9k7ps6?ref=rss&rd=1](https://biztoc.com/p/7f9k7ps6?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:22:39+00:00

Nothing official yet, but Adrian Wojnarowski reported on ESPN’s Get Up Wednesday that Brooklyn could hire suspended Celtics head coach by as early as Wednesday. 


.@wojespn weighs in on the... <br /><br /> #espn #nothingofficial #wojespn #adrianwojnarowski #celtics #imeudoka #getup #brooklyn #headcoach

## Live updates: Latest news from Russia and the war in Ukraine
 - [https://biztoc.com/p/te9a8jc8?ref=rss&rd=1](https://biztoc.com/p/te9a8jc8?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:21:00+00:00

Russia said Wednesday that it will resume its participation in the Black Sea grain initiative, a deal with Ukraine to enable vital agricultural exports. <br /><br /> #blacksea #war #ukraine

## NY mom's murder blamed on Hochul's policies could give Zeldin the win, former Clinton pollster says
 - [https://biztoc.com/p/dywcw2sp?ref=rss&rd=1](https://biztoc.com/p/dywcw2sp?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:18:22+00:00

Fox News contributor Mark Penn joined 'America's Newsroom' to weigh in on the heated New York gubernatorial race after a 'horrific' murder is blamed on no-cash bail. <br /><br /> #ny #americasnewsroom #hochul #zeldin #markpenn #mom #clinton #murder

## New York Attorney General Sets Settlement With Leslie Moonves and CBS Amid New Allegations of Corporate Cover-Up as 2018 Sexual...
 - [https://biztoc.com/p/jfvw78wh?ref=rss&rd=1](https://biztoc.com/p/jfvw78wh?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:12:00+00:00

UPDATING with details from New York Attorney General’s Office settlement. Paramount Global and former CBS chief Leslie Moonves have reached a settlement with New York state as part of an inve… <br /><br /> #sexualmisconduct #paramountglobal #lesliemoonves

## Israel elections: Netanyahu election win propels far right to power
 - [https://biztoc.com/p/bhppsb8g?ref=rss&rd=1](https://biztoc.com/p/bhppsb8g?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:11:41+00:00

Israel lurches to the right as parties hostile to Arabs are set to form part of the next government. <br /><br /> #arabs #netanyahu #electionwin #israel #elections

## How to pronounce Adele's name 'perfectly'
 - [https://biztoc.com/p/izy5qtdn?ref=rss&rd=1](https://biztoc.com/p/izy5qtdn?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:09:08+00:00

British superstar Adele praised a London-based fan for pronouncing her name 'perfectly' during a Q&amp;A and shared the right way to say it. <br /><br /> #fan #qamp #adele

## Gmail will directly show package and delivery tracking in your inbox
 - [https://biztoc.com/p/x5rwxxme?ref=rss&rd=1](https://biztoc.com/p/x5rwxxme?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 18:01:00+00:00

Ahead of the holiday shopping season, Gmail is adding package tracking and delivery information in a glanceable manner... <br /><br /> #deliverytracking

## Jennifer Lawrence says that she used to get stoned after 'Hunger Games' premieres: 'I don't do it anymore, I'm a mom!'
 - [https://biztoc.com/p/6mmbgnte?ref=rss&rd=1](https://biztoc.com/p/6mmbgnte?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 17:59:21+00:00

In a new interview with "The New York Times," Lawrence said that she was under the influence as far back as the first "Hunger Games" blockbuster. <br /><br /> #jenniferlawrence #premieres #hungergames #lawrence #mom

## The White House deleted a tweet Wednesday that took credit for a Social Security boost next year. One problem: the hike is largely due...
 - [https://biztoc.com/p/hkcihguz?ref=rss&rd=1](https://biztoc.com/p/hkcihguz?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 17:55:00+00:00

News and analysis from Capitol Hill for when you only have a few minutes, from POLITICO. <br /><br /> #capitolhill #politico #hike

## Jennifer Lawrence Says She Wishes She Didn't Make "Passengers," And Adele Had Told Her Not To
 - [https://biztoc.com/p/4xn4qxfk?ref=rss&rd=1](https://biztoc.com/p/4xn4qxfk?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 17:49:10+00:00

If you don't remember Jennifer Lawrence and Chris Pratt's high-profile sci-fi bomb, allow J. Law and Adele to refresh your memory. <br /><br /> #adele #chrispratt #passengers

## Seoul crowd crush: local police offices raided in investigation
 - [https://biztoc.com/p/rjut3uhy?ref=rss&rd=1](https://biztoc.com/p/rjut3uhy?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 17:49:00+00:00

Eleven emergency callers used Korean word for ‘crushed to death’ 13 times hours before incident <br /><br /> #policeoffices #investigation #seoul #emergencycallers #korean #crowdcrush

## Warring parties in Ethiopia agree on ceasefire in significant step toward peace
 - [https://www.cnn.com/2022/11/02/africa/ethiopia-cessation-hostilities-intl/index.html](https://www.cnn.com/2022/11/02/africa/ethiopia-cessation-hostilities-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 17:47:12+00:00

The Ethiopian government and the Tigray People's Liberation Front have agreed to a cessation of hostilities, the African Union (AU) High Representative for the Horn of Africa and former Nigerian president Olusegun Obasanjo announced in a media briefing Wednesday night in South Africa.

## See Robert Downey Jr.'s kids shave his head for upcoming role
 - [https://www.cnn.com/videos/entertainment/2022/11/02/robert-downey-jr-head-shave-cprog-orig-ch.cnn](https://www.cnn.com/videos/entertainment/2022/11/02/robert-downey-jr-head-shave-cprog-orig-ch.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 17:35:57+00:00

Robert Downey Jr. asked his two sons to help him prepare for a new HBO television series. They obliged and asked for a favor in return.

## Daniel Snyder considers 'potential transactions' for Washington Commanders
 - [https://biztoc.com/p/zp8quqj6?ref=rss&rd=1](https://biztoc.com/p/zp8quqj6?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 17:33:17+00:00

<br /><br /> #washingtoncommanders #danielsnyder

## Watch Teen Mom 's Tyler Baltierra and Catelynn Lowell Explain Carly's Adoption to Daughter Nova
 - [https://biztoc.com/p/sm9zfbgf?ref=rss&rd=1](https://biztoc.com/p/sm9zfbgf?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 17:32:55+00:00

In the Nov. 1 episode of Teen Mom: The Next Chapter, Tyler Baltierra and Catelynn Lowell explained to their daughter Nova why they placed Carly for adoption: “We were being irresponsible.” <br /><br /> #teenmom #nova #tylerbaltierra #catelynnlowell #carly

## 5 very scary numbers for Democrats in the new CNN poll
 - [https://www.cnn.com/2022/11/02/politics/cnn-poll-democrats-midterm-elections/index.html](https://www.cnn.com/2022/11/02/politics/cnn-poll-democrats-midterm-elections/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 17:30:12+00:00

A new CNN national poll paints a very grim portrait of the electorate for Democrats, with any number of warning signs that suggest the 2022 midterms are shaping up to be very tough for their side.

## Russia turns to fellow outcasts North Korea and Iran for help with faltering war effort
 - [https://biztoc.com/p/v4rk25p7?ref=rss&rd=1](https://biztoc.com/p/v4rk25p7?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 17:26:37+00:00

With aid continuing to flow to Ukraine from the West, and its own military increasingly strained by a war now entering its ninth month, Russia is turning to fellow outcasts from the international... <br /><br /> #west #war #northkorea #outcasts #ukraine #iran

## Biden to give speech on protecting democracy Wednesday night in DC
 - [https://biztoc.com/p/w2zjkmak?ref=rss&rd=1](https://biztoc.com/p/w2zjkmak?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 17:25:00+00:00

President Joe Biden is set to deliver a speech Wednesday on protecting democracy, just six days before the midterm elections as the nation deals with a tense political climate following the attack... <br /><br /> #nancypelosi #midtermelections #attack

## Making daylight saving permanent could drastically reduce deer collisions, study finds
 - [https://biztoc.com/p/buugdtsv?ref=rss&rd=1](https://biztoc.com/p/buugdtsv?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 17:21:53+00:00

Wildlife and vehicle collision data from 23 states show that drivers would hit and kill 37,000 fewer deer if the U.S. stuck to daylight saving time year-round. It would also prevent dozens of... <br /><br /> #humandeaths

## Inside the intense rivalry between Mitch McConnell and Rick Scott
 - [https://www.cnn.com/2022/11/02/politics/mitch-mcconnell-rick-scott-fight-senate-control/index.html](https://www.cnn.com/2022/11/02/politics/mitch-mcconnell-rick-scott-fight-senate-control/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 17:20:42+00:00

A simmering conflict between Sen. Mitch McConnell of Kentucky and Sen. Rick Scott of Florida is heating up in the closing days of the fall campaigns, as the two Republicans battle behind the scenes over who will get the credit for a big win -- and who will bear the blame if the party falls short.

## NFL trade deadline: What Dolphins, Vikings, Lions, Packers and others are telling us
 - [https://biztoc.com/p/7ezvr6u8?ref=rss&rd=1](https://biztoc.com/p/7ezvr6u8?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 17:20:20+00:00

Tuesday was revealing for Tua Tagovailoa, Justin Fields and followers of the front offices in Minnesota, Chicago, Pittsburgh and elsewhere. <br /><br /> #justinfields #pittsburgh #nfl #vikings #packers #lions #minnesota

## Christina Applegate on how life has changed since her MS diagnosis
 - [https://biztoc.com/p/rbezwn5v?ref=rss&rd=1](https://biztoc.com/p/rbezwn5v?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 17:20:03+00:00

Christina Applegate says she won't be watching the final season of 'Dead To Me' because reminders of her multiple sclerosis are too painful. <br /><br /> #diagnosis #deadtome #christinaapplegate

## Commanders exploring possible sale: Dan Snyder hires Bank of America for 'potential transactions'
 - [https://biztoc.com/p/8eg45t7n?ref=rss&rd=1](https://biztoc.com/p/8eg45t7n?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 17:16:00+00:00

The Snyder family is looking into selling the Commanders franchise <br /><br /> #dansnyder #transactions #thesnyder #bankofamerica #commanders #franchise

## No room for another monitor? Use your desktop’s side panel instead
 - [https://biztoc.com/p/di7izndk?ref=rss&rd=1](https://biztoc.com/p/di7izndk?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 17:06:23+00:00

An intriguing idea, but Embedded DisplayPort limits compatibility. <br /><br /> #desktop #monitor

## Capitol Police cameras recorded break in at Pelosi residence
 - [https://biztoc.com/p/k3dnyfef?ref=rss&rd=1](https://biztoc.com/p/k3dnyfef?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:57:57+00:00

<br /><br /> #pelosi #residence #cameras #capitolpolice

## The biggest transgender survey in the US is underway. Here's why it's important
 - [https://www.cnn.com/2022/11/02/us/us-trans-survey-2022-cec/index.html](https://www.cnn.com/2022/11/02/us/us-trans-survey-2022-cec/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:56:54+00:00

Federal surveys like the US Census are gradually taking their transgender respondents into account. But they rarely ask specific questions unique to trans life: Have they been denied access to reproductive health care? Is their life better than it was before they came out as trans?

## Offset Changes Instagram Avatar to Takeoff Photo After His Death
 - [https://biztoc.com/p/5mgbwqai?ref=rss&rd=1](https://biztoc.com/p/5mgbwqai?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:56:44+00:00

Offset has yet to speak out about the loss of his Migos brother, Takeoff, but he's paying tribute to his late friend through the use of his Instagram avatar. <br /><br /> #migos #takeoff #takeoffphoto

## Russian strikes plunge Ukraine into darkness
 - [https://www.cnn.com/2022/11/02/europe/kyiv-airstrikes-blackouts-energy-ukraine-russia-intl/index.html](https://www.cnn.com/2022/11/02/europe/kyiv-airstrikes-blackouts-energy-ukraine-russia-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:52:24+00:00

Once the smoke from Russia's latest rocket strikes had cleared and the sound of air raid sirens stopped, many of Kyiv's residents emerged, empty bottles in hand, to queue for water.

## Stewart Rhodes wrote message to Trump after Jan. 6 calling on him to 'save the Republic,' arrest members of Congress
 - [https://biztoc.com/p/fn2btny8?ref=rss&rd=1](https://biztoc.com/p/fn2btny8?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:48:32+00:00

The message was not delivered, but was later turned over to the FBI, a witness told jurors as the government nears the end of its argument in the Oath Keepers seditious conspiracy trial. <br /><br /> #oathkeepers #jurors #witness #stewartrhodes #arrestmembers #republic #trump #fbi

## Affirmative Action case: SCOTUS justices were 'on fire' over Harvard's actions, says activist in hearing
 - [https://biztoc.com/p/cwbgmt6k?ref=rss&rd=1](https://biztoc.com/p/cwbgmt6k?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:47:27+00:00

Education activist Asra Nomani said she was "really emboldened" by the Supreme Court justices who decried Harvard's "personal ratings" during oral arguments on two significant affirmative action... <br /><br /> #harvard #activist #affirmativeaction #asranomani #scotus #arguments #justices

## The Parkland school shooter is set to be sentenced to life in prison today
 - [https://biztoc.com/p/b6kyuj4s?ref=rss&rd=1](https://biztoc.com/p/b6kyuj4s?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:47:00+00:00

The gunman who murdered 17 people in 2018 at a South Florida high school is expected to be sentenced Wednesday to life in prison without the possibility of parole, bringing to a close an... <br /><br /> #southflorida #highschool #gunman #schoolshooter #parkland #prison

## Ethiopia’s warring sides agree ‘cessation of hostilities’: AU
 - [https://biztoc.com/p/kwh4b3h7?ref=rss&rd=1](https://biztoc.com/p/kwh4b3h7?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:45:06+00:00

African Union says Ethiopia’s government and Tigrayan forces formally agree to end fighting after talks in South Africa. <br /><br /> #southafrica #auafricanunion #tigrayan #forces #ethiopia

## Republican says party ‘will never lose another election’ in Wisconsin if he wins
 - [https://biztoc.com/p/5kngiyaa?ref=rss&rd=1](https://biztoc.com/p/5kngiyaa?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:45:00+00:00

Gubernatorial candidate Tim Michels’ comment is ‘a danger to our democracy’, Democrat opponent Tony Evers says <br /><br /> #tonyevers #election #gubernatorial #timmichels #wisconsin

## Biden team 'engaged in some planning' for 2024 bid as president mulls a reelection decision
 - [https://www.cnn.com/2022/11/02/politics/biden-2024-decision/index.html](https://www.cnn.com/2022/11/02/politics/biden-2024-decision/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:44:01+00:00

President Joe Biden's top advisers are making plans toward a 2024 reelection bid, even as he has not yet made a decision on whether to throw his hat into the ring again.

## Christina Applegate seen in Dead to Me trailer for FINAL season following MS diagnosis
 - [https://biztoc.com/p/4hvk8h6d?ref=rss&rd=1](https://biztoc.com/p/4hvk8h6d?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:42:41+00:00

The action-packed trailer begins by showing the two friends getting into a car crash that lands them in the hospital before coming under suspicion over the death of Judy's fiance Steve. <br /><br /> #hospital #trailer #deadtome #christinaapplegate #judy #steve #carcrash

## Fantasy Football Rankings Week 9: Sleepers, starts, sits
 - [https://biztoc.com/p/gdin669g?ref=rss&rd=1](https://biztoc.com/p/gdin669g?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:37:51+00:00

Jake Ciely offers up rankings, sleepers, buys and sells ahead of Week 9, and also shares his Top 25 list of video games from N64. <br /><br /> #sleepers #fantasyfootball #n64 #jakeciely

## North Korea covertly shipping artillery shells to Russia, US says
 - [https://biztoc.com/p/e2v6h56z?ref=rss&rd=1](https://biztoc.com/p/e2v6h56z?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:34:14+00:00

White House says North Korea is sending a ‘significant’ number of artillery shells to Russia for the Ukraine war. <br /><br /> #northkorea #war #ukraine

## Clarence Thomas was 'key' to delaying certification of 2020 election, Trump lawyers said in emails
 - [https://www.cnn.com/2022/11/02/politics/clarence-thomas-trump-eastman-emails/index.html](https://www.cnn.com/2022/11/02/politics/clarence-thomas-trump-eastman-emails/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:31:59+00:00

A lawyer for former President Donald Trump described Supreme Court Justice Clarence Thomas as "key" to Trump's plan to delay Congress' certification of President Joe Biden's victory through litigation after the 2020 election, according to emails recently turned over to the House select committee investigating January 6.

## World Series: Phillies Hit 5 Homers in Game 3 Win Over Astros
 - [https://biztoc.com/p/x3ku3qte?ref=rss&rd=1](https://biztoc.com/p/x3ku3qte?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:31:00+00:00

In the first World Series game in Philadelphia since 2009, the Phillies took Houston’s Lance McCullers Jr. deep five times and cruised to victory. <br /><br /> #winoverastros #philadelphia #lancemccullersjr #phillies #houston

## White House deletes tweet flagged by Twitter that credited Biden for Social Security payment increase
 - [https://biztoc.com/p/nvzvau7k?ref=rss&rd=1](https://biztoc.com/p/nvzvau7k?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:28:39+00:00

The White House took down a tweet Wednesday that gave President Biden credit for rising Social Security payments that are the result of 40-year high inflation. <br /><br /> #socialsecurity #twitter

## Details Revealed on the Death of Master P’s Daughter, Tytyana Miller
 - [https://biztoc.com/p/rt4yuwrq?ref=rss&rd=1](https://biztoc.com/p/rt4yuwrq?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:27:01+00:00

An official coroner's report reveals that Miller died from fentanyl intoxication. <br /><br /> #coroner #masterp #tytyanamiller

## Lena Horne becomes first Black woman to have a Broadway theater named after her
 - [https://www.cnn.com/2022/11/02/entertainment/lena-horne-broadway/index.html](https://www.cnn.com/2022/11/02/entertainment/lena-horne-broadway/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:22:26+00:00

A theater on Broadway has been officially renamed in honor of the late actress and civil rights activist Lena Horne.

## 10-year-old calls 911 during school shooting. Here's what her dad taught her at home
 - [https://www.cnn.com/videos/us/2022/11/02/uvalde-child-911-call-parents-react-intv-cnntm-vpx.cnn](https://www.cnn.com/videos/us/2022/11/02/uvalde-child-911-call-parents-react-intv-cnntm-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:19:43+00:00

In a 911 audio clip obtained by CNN, 10-year-old Khloie Torres, one of the survivors of the Uvalde school shooting, told a dispatcher she understood what to do because her dad taught her when she was a little girl. The parents of Khloie Torres join "CNN This Morning" to discuss.

## The fight for Senate control is now a pure jump ball
 - [https://www.cnn.com/collections/intl-us-pols/](https://www.cnn.com/collections/intl-us-pols/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:18:38+00:00



## Life-size cast of Princess Diana's hand goes up for auction
 - [https://www.cnn.com/style/article/princess-diana-hand-cast-oscar-nemon-auction-scli-intl/index.html](https://www.cnn.com/style/article/princess-diana-hand-cast-oscar-nemon-auction-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:11:31+00:00

A life-size cast of Princess Diana's hand is expected to sell for up to £40,000 ($46,046) when it goes under the hammer Tuesday.

## Opinion: Why Putin can't be allowed to win
 - [https://www.cnn.com/2022/11/02/opinions/ukraine-russia-iran-weapons-geopolitical-ghitis/index.html](https://www.cnn.com/2022/11/02/opinions/ukraine-russia-iran-weapons-geopolitical-ghitis/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 16:09:20+00:00

Almost immediately after last month's blast that destroyed a section of the Kerch bridge connecting Russia to Crimea -- the Ukrainian territory it annexed in 2014 -- the Kremlin intensified attacks on Ukraine's civilian infrastructure, stepping up its bombing of apartment buildings, power grid and water systems.

## India inch closer to semis after nervy win vs. Bangladesh
 - [https://www.cnn.com/2022/11/02/sport/india-bangladesh-t20-world-cup-spt-intl/index.html](https://www.cnn.com/2022/11/02/sport/india-bangladesh-t20-world-cup-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:58:36+00:00

Inaugural champions India put a foot in the semifinals of the T20 World Cup following their nervy five-run victory against Bangladesh in a rain-hit Group 2 humdinger in Adelaide on Wednesday.

## Going to win $1.2B Powerball prize? Consider not taking cash
 - [https://biztoc.com/p/9n3nvhme?ref=rss&rd=1](https://biztoc.com/p/9n3nvhme?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:58:25+00:00

Think you’re a sure bet to win an estimated $1.2 billion Powerball jackpot

## ‘It’s over’: Jair Bolsonaro reportedly accepts defeat in Brazil election
 - [https://biztoc.com/p/vkwueu6i?ref=rss&rd=1](https://biztoc.com/p/vkwueu6i?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:58:00+00:00

Bolsonaro previously failed to explicitly concede defeat to Luiz Inácio Lula da Silva in presidential vote <br /><br /> #election #brazil #luizinácioluladasilva #defeat #jairbolsonaro

## Maersk CEO says shipping slowdown is signaling a recession
 - [https://www.cnn.com/2022/11/02/business/maersk-ceo-recession/index.html](https://www.cnn.com/2022/11/02/business/maersk-ceo-recession/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:54:25+00:00

The spike in shipping rates since the onset of the pandemic has been a huge boon for Maersk. But the Danish shipping giant is warning its business will have to endure tougher times soon.

## Powerball's second-largest jackpot -- an estimated $1.2 billion -- up for grabs Wednesday
 - [https://biztoc.com/p/kfsjwxuc?ref=rss&rd=1](https://biztoc.com/p/kfsjwxuc?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:54:00+00:00

Powerball players will be taking their shot Wednesday night at an estimated $1.2 billion jackpot -- which would be the second-largest pool in the game's 30-year history. <br /><br /> #pool #powerballplayers

## Pelosi attacker evaded cameras, security to get inside home
 - [https://biztoc.com/p/pfc4dzrr?ref=rss&rd=1](https://biztoc.com/p/pfc4dzrr?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:42:57+00:00

With Nancy Pelosi gone, her San Francisco home's security was downgraded, and only her husband, Paul Pelosi, was home at the time of Friday's break-in. <br /><br /> #attacker #paulpelosi #nancypelosi #breakin #cameras

## UK leader Rishi Sunak U-turns on COP27 climate summit and will attend after all
 - [https://www.cnn.com/2022/11/02/uk/uk-pm-sunak-cop27-gbr-intl/index.html](https://www.cnn.com/2022/11/02/uk/uk-pm-sunak-cop27-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:42:22+00:00

UK Prime Minister Rishi Sunak said Wednesday that he will be attending next week's COP27 climate summit in Egypt, following widespread criticism of his previous decision not to.

## US officials divided over new intelligence suggesting Russian military discussed scenarios for using nuclear weapons
 - [https://www.cnn.com/2022/11/02/politics/us-russia-nuclear-weapon-intelligence/index.html](https://www.cnn.com/2022/11/02/politics/us-russia-nuclear-weapon-intelligence/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:41:27+00:00

Russian military officials have discussed how and under what conditions Russia would use a tactical nuclear weapon on the battlefield in Ukraine, according to a US intelligence assessment described to CNN by multiple sources who have read it.

## Week 9 fantasy football trade valuation tool: DeAndre Hopkins soars up the charts!
 - [https://biztoc.com/p/qi2hsf4b?ref=rss&rd=1](https://biztoc.com/p/qi2hsf4b?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:39:02+00:00

Alex Korff, AKA PeakedInHighSkool, updates his fantasy football trade value charts for Week 9, and notes the shard rise of DeAndre Hopkins. <br /><br /> #alexkorff #deandrehopkins #shardrise #akapeakedinhighskool

## Fantasy Football Six Pack: DJ Moore officially returns to fantasy relevance
 - [https://biztoc.com/p/wc2cm9xh?ref=rss&rd=1](https://biztoc.com/p/wc2cm9xh?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:38:02+00:00

Fantasy football analyst Andy Behrens shares some noteworthy numbers to keep in mind heading into Week 9. <br /><br /> #fantasyfootballanalyst #andybehrens #fantasyfootball #sixpack #djmoore

## Putin: We could quit grain deal again, but would not block grain for Turkey
 - [https://biztoc.com/p/36h7tyfq?ref=rss&rd=1](https://biztoc.com/p/36h7tyfq?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:37:00+00:00

President Vladimir Putin on Wednesday reserved Russia's right to withdraw again from an international agreement allowing Ukraine to export grain via the Black Sea, after ending four days of... <br /><br /> #vladimirputin #blacksea #ukraine #turkey

## Martin becomes season's seventh hurricane
 - [https://biztoc.com/p/cqhrce2m?ref=rss&rd=1](https://biztoc.com/p/cqhrce2m?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:35:50+00:00

The sixth and seventh hurricanes of the season formed Wednesday, with Hurricane Lisa developing in the Caribbean and Hurricane Martin forming in the north-central Atlantic Ocean. <br /><br /> #hurricane #hurricanes #martin #hurricanemartin #atlanticocean #hurricanelisa #caribbean

## From Apple to Disney, China's Covid curbs are again hurting business
 - [https://www.cnn.com/2022/11/02/business/covid-china-iphone-shanghai-disneyland-intl-hnk/index.html](https://www.cnn.com/2022/11/02/business/covid-china-iphone-shanghai-disneyland-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:31:31+00:00

It has been almost three years since Covid-19 first hit China, but the country's relentless adherence to lockdowns continues to hobble business and the economy.

## Prosecutors: Attacker awoke Pelosi, stood by his bedside
 - [https://www.cnn.com/videos/politics/2022/11/02/pelosi-family-911-call-bodycam-footage-gangel-cnntm-vpx.cnn](https://www.cnn.com/videos/politics/2022/11/02/pelosi-family-911-call-bodycam-footage-gangel-cnntm-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:27:24+00:00

CNN special correspondent Jamie Gangel reports on the three minute 911 call Paul Pelosi made before he was attacked in his home and how the attacker claims he was on a "suicide mission."

## Jennifer Lawrence: Adele Told Me Not to Star in ‘Passengers’ and ‘I Should’ve Listened to Her’
 - [https://biztoc.com/p/mh9iceig?ref=rss&rd=1](https://biztoc.com/p/mh9iceig?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:27:00+00:00

Jennifer Lawrence revealed in a new interview with The New York Times that none other than Adele warned her not to star in “Passengers,” the 2016 romance space drama co-starring Chris P… <br /><br /> #adele #passengers #romancespacedrama #jenniferlawrence #chrisp

## Watch viral moment of woman who survived attack by bison
 - [https://www.cnn.com/videos/us/2022/11/02/texas-woman-bison-attack-viral-video-lavandera-dnt-cnntm-vpx.cnn](https://www.cnn.com/videos/us/2022/11/02/texas-woman-bison-attack-viral-video-lavandera-dnt-cnntm-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:26:33+00:00

CNN's Ed Lavandera sits down with hiking enthusiast Rebecca Clark, who was hiking in a remote park in Texas when she was attacked by a bison.

## Family of American killed in Ukraine says his body is being held in potential war crimes probe
 - [https://biztoc.com/p/5i9w7caf?ref=rss&rd=1](https://biztoc.com/p/5i9w7caf?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:22:42+00:00

They said they were preparing for his remains to be returned to the U.S. until they were informed that Ukraine would hold his body as part of a potential war crimes investigation. <br /><br /> #ukraine #warcrimesinvestigation

## Beauty Queens Miss Argentina and Miss Puerto Rico Reveal They've Secretly Married
 - [https://biztoc.com/p/vy3zufjb?ref=rss&rd=1](https://biztoc.com/p/vy3zufjb?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:20:00+00:00

Mariana Varela and Fabiola Valentín, who met while competing at the Miss Grand International pageant in 2020, tied the knot on Oct.28 <br /><br /> #puertorico #marianavarela #argentina #fabiolavalentín #missgrandinternational #pageant #beautyqueens

## First on CNN: US accuses North Korea of trying to hide shipments of ammunition to Russia
 - [https://biztoc.com/p/4ftzcgyq?ref=rss&rd=1](https://biztoc.com/p/4ftzcgyq?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:20:00+00:00

The US is accusing North Korea of secretly supplying Russia with artillery shells for the Ukraine war by concealing where they are being transported to, according to newly declassified intelligence. <br /><br /> #northkorea #war #ukraine

## Lions at Sydney's Taronga Zoo escape their enclosure, alarming guests
 - [https://biztoc.com/p/f83rsxkd?ref=rss&rd=1](https://biztoc.com/p/f83rsxkd?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:19:56+00:00



## Two teenagers killed Spanish teacher over bad grade, Iowa prosecutors allege
 - [https://biztoc.com/p/z3rmpnjh?ref=rss&rd=1](https://biztoc.com/p/z3rmpnjh?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:19:00+00:00

Willard Miller and Jeremy Goodale, accused of beating Nohema Graber to death when they were 16, will stand trial as adults <br /><br /> #nohemagraber #teenagers #prosecutors #teacher #jeremygoodale #spanish #iowa #willardmiller

## Massive search for gunman accused of shooting 2 Newark cops continues into 2nd day
 - [https://biztoc.com/p/j9hhqak2?ref=rss&rd=1](https://biztoc.com/p/j9hhqak2?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:12:00+00:00

The alleged shooter — identified by police as Kendall Howard, 30, of East Orange — escaped after the officers returned fire, authorities said. <br /><br /> #gunman #newark #kendallhoward #eastorange #cops #shooter

## Tropical storm tracker: Hurricane Lisa forms
 - [https://biztoc.com/p/zpesckw2?ref=rss&rd=1](https://biztoc.com/p/zpesckw2?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:12:00+00:00

RIGHT NOW WE ARE MONITORING TO NAMED STORMS. MEREDITH: METEOROLOGIST KELLIANNE KLASS JOINING US NOW. ANYTHING COMING OUR WAY? KELLIANNE: TROPICAL STORM LISA EXPECTED TO MAKE LANDFALL AT BELIZE.... <br /><br /> #meredith #storm #tropicalstormlisa #belize #storms #centralflorida #tropicalstormmartin #landfall

## Washington Commanders owner Dan Snyder hires Bank of America to explore possible sale
 - [https://biztoc.com/p/z9msk7bh?ref=rss&rd=1](https://biztoc.com/p/z9msk7bh?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:09:19+00:00

Washington Commanders owner Daniel Snyder has hired Bank of America to help facilitate a potential sale of the team. <br /><br /> #bankofamerica #dansnyder #washingtoncommanders

## $550 PlayStation VR2 launches on Feb. 22, 2023
 - [https://biztoc.com/p/pfyqz3aa?ref=rss&rd=1](https://biztoc.com/p/pfyqz3aa?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:03:40+00:00

Six games available for preorder alongside headset on Nov. 15.

## The Russo Brothers Assemble: Inside AGBO, Their $1 Billion Studio, and When They Might Return to Marvel
 - [https://biztoc.com/p/zrdbtngt?ref=rss&rd=1](https://biztoc.com/p/zrdbtngt?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:00:24+00:00

Ever since Joe and Anthony Russo released “Avengers: Endgame,” in 2019, the sibling directors have been asked over and over if they would ever work again with Marvel Studios. Each time, they’ve tri… <br /><br /> #anthonyrusso #joe #avengersendgame #marvelstudios #marvel #studio #siblingdirectors

## NFL Trade Deadline Winners and Losers
 - [https://biztoc.com/p/gj9cfj9m?ref=rss&rd=1](https://biztoc.com/p/gj9cfj9m?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 15:00:11+00:00

NFC North quarterbacks on different ends of the spectrum, Eagles stay aggressive while their rivals stand pat … who should be happy the day after the trade deadline? <br /><br /> #eagles #quarterbacks #nfcnorth

## Biden to deliver unscheduled DNC speech at Union Station near Capitol
 - [https://biztoc.com/p/i63qunbh?ref=rss&rd=1](https://biztoc.com/p/i63qunbh?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:57:53+00:00

President Biden will deliver a Democratic National Committee speech near the U.S. Capitol Monday, an event that was added to his schedule six days before the midterms. <br /><br /> #dnc #capitol #unionstation #midterms

## Trump lawyers saw Justice Thomas as 'only chance' to stop 2020 election certification
 - [https://biztoc.com/p/qqw9iy3x?ref=rss&rd=1](https://biztoc.com/p/qqw9iy3x?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:51:26+00:00

“We want to frame things so that Thomas could be the one to issue some sort of stay or other circuit justice opinion saying Georgia is in legitimate doubt,” Trump attorney Kenneth Chesebro wrote... <br /><br /> #kennethchesebro #lawyers #georgia #thomas

## Netanyahu is back. Here's what that means for Israel
 - [https://www.cnn.com/2022/11/02/middleeast/what-netanyahus-return-means-mime-intl/index.html](https://www.cnn.com/2022/11/02/middleeast/what-netanyahus-return-means-mime-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:50:52+00:00

Benjamin Netanyahu is set to resurrect his political career and make an astonishing comeback as prime minister of Israel.

## CVS, Walmart, Walgreens agree to pay $13.8 bln to settle U.S. opioid claims
 - [https://biztoc.com/p/qdnx2bn3?ref=rss&rd=1](https://biztoc.com/p/qdnx2bn3?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:49:00+00:00

CVS Health Corp , Walgreens Boots Alliance Inc and Walmart Inc have agreed to pay about $13.8 billion to resolve thousands of U.S. state, local and tribal government lawsuits accusing the pharmacy... <br /><br /> #opioid #cvs #walgreens #cvshealthcorp

## Elon Musk hints that Donald Trump will not be back on Twitter before the midterms
 - [https://www.cnn.com/2022/11/02/tech/elon-musk-twitter-donald-trump/index.html](https://www.cnn.com/2022/11/02/tech/elon-musk-twitter-donald-trump/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:47:34+00:00

Elon Musk indicated on Wednesday that the Twitter account of former President Donald Trump will not be restored ahead of the US midterm elections next week, answering one of the biggest unknowns following his takeover of the social media company.

## Animal rights organization criticizes trainer for parading racehorse in pub
 - [https://www.cnn.com/2022/11/02/sport/peta-racehorse-hewick-pub-criticism-spt-intl/index.html](https://www.cnn.com/2022/11/02/sport/peta-racehorse-hewick-pub-criticism-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:42:32+00:00

A leading animal rights organization has criticized an Irish racehorse trainer for parading his winning steed in a pub earlier this week.

## Biden to give speech on threats to democracy from Capitol Hill on Wednesday
 - [https://biztoc.com/p/6jyqd9xv?ref=rss&rd=1](https://biztoc.com/p/6jyqd9xv?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:41:00+00:00

President Biden on Wednesday evening will deliver a speech focused on threats to democracy ahead of the midterm elections and following the violent attack on Speaker Nancy Pelosi’s  husba… <br /><br /> #husba #midtermelections #attack #capitolhill #nancypelosi

## Dan Snyder Hires Bank Of America To Sell Washington Commanders
 - [https://biztoc.com/p/8kjatvqs?ref=rss&rd=1](https://biztoc.com/p/8kjatvqs?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:40:08+00:00

Neither the Commanders or Bank of America, which has handled such notable team sales as the purchase of the Los Angeles Clippers by Steve Ballmer, would comment. <br /><br /> #washingtoncommanders #losangelesclippers #commanders #steveballmer #bankofamerica #dansnyderhires

## Women disrupt Supreme Court arguments to protest Dobbs decision
 - [https://www.cnn.com/2022/11/02/politics/women-disrupt-supreme-court-protest-dobbs/index.html](https://www.cnn.com/2022/11/02/politics/women-disrupt-supreme-court-protest-dobbs/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:39:57+00:00

At the start of oral arguments at the Supreme Court on Wednesday, several women rose out of their seats inside the courtroom to voice their opposition to this summer's decision overturning Roe v. Wade.

## Houston officials plead for witnesses to come forward in killing of 'peaceful' rapper Takeoff
 - [https://www.cnn.com/2022/11/02/entertainment/takeoff-shooting-houston-police/index.html](https://www.cnn.com/2022/11/02/entertainment/takeoff-shooting-houston-police/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:39:46+00:00

Houston officials vowed to solve the killing of rapper Takeoff, with the chief of police calling the 28-year-old Atlantan a "peaceful" man and urging any witnesses to the shooting to come forward.

## Houston officials plead for witnesses to come forward in killing of 'peaceful' rapper Takeoff
 - [https://biztoc.com/p/cre6c7jq?ref=rss&rd=1](https://biztoc.com/p/cre6c7jq?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:39:00+00:00

Houston officials vowed to deliver justice in the killing of rapper Takeoff, with the chief of police calling the 28-year-old Atlantan a "peaceful" man and urging any witnesses to the shooting to... <br /><br /> #witnesses #takeoffhouston #atlantan #houston #killing #rappertakeoff #shooting

## Why the Paul Pelosi attack keeps drawing in conspiracy theories
 - [https://biztoc.com/p/jmyird6c?ref=rss&rd=1](https://biztoc.com/p/jmyird6c?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:38:57+00:00

<br /><br /> #paulpelosi #attack

## Stephen A. & JJ Redick debate the Nets' firing of Steve Nash
 - [https://biztoc.com/p/dnf9nkpy?ref=rss&rd=1](https://biztoc.com/p/dnf9nkpy?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:34:26+00:00

<br /><br /> #jjredick #firing #stevenash #nets #stephena

## The only 4 words Powell should utter at the Fed news conference, according to one economist
 - [https://biztoc.com/p/2y3uj972?ref=rss&rd=1](https://biztoc.com/p/2y3uj972?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:29:24+00:00

<br /><br /> #powell #newsconference #economist

## PSVR 2 Launches February 22 For $550
 - [https://biztoc.com/p/z6y4gvxt?ref=rss&rd=1](https://biztoc.com/p/z6y4gvxt?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:24:15+00:00

Sony confirms the release date and price for the next PlayStation VR headset. <br /><br /> #sony #psvr2 #playstation

## Avatar: The Way of Water - Official Trailer (2022) Zoe Saldaña, Sam Worthington
 - [https://biztoc.com/p/wvz2sd6h?ref=rss&rd=1](https://biztoc.com/p/wvz2sd6h?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:23:38+00:00

<br /><br /> #zoesaldaña #samworthington

## Kevin Durant was shocked the Nets fired Steve Nash
 - [https://biztoc.com/p/8f6qu8yq?ref=rss&rd=1](https://biztoc.com/p/8f6qu8yq?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:21:29+00:00

<br /><br /> #stevenash #nets #kevindurant

## Europe has warmed faster than any other region in the past 30 years
 - [https://www.cnn.com/2022/11/02/weather/europe-warming-fastest-continent-climate/index.html](https://www.cnn.com/2022/11/02/weather/europe-warming-fastest-continent-climate/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:20:57+00:00

As the climate crisis accelerates, Europe is warming faster than any other region, according to a new State of the Climate in Europe report from the World Meteorological Organization.

## Obama takes to TikTok with 'painful' get-out-the-vote message
 - [https://biztoc.com/p/cjzd5jki?ref=rss&rd=1](https://biztoc.com/p/cjzd5jki?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:19:12+00:00

Former President Barack Obama joined "Under The Desk News" on TikTok to motivate midterm election voters, urging action on climate change, abortion and gun control. <br /><br /> #electionvoters #underthedesknews #barackobama

## Analysis: Why Donald Trump is still fighting to keep his tax returns hidden
 - [https://www.cnn.com/videos/politics/2022/11/02/trump-tax-return-cillizza-the-point-orig.cnn](https://www.cnn.com/videos/politics/2022/11/02/trump-tax-return-cillizza-the-point-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:17:00+00:00

Former President Donald Trump is fighting to keep the Internal Revenue Service from turning his tax returns over to a Democratic-led House committee. In today's episode of The Point, CNN's Chris Cillizza explains what Trump may want to keep from public view.

## Hear How Takeoff and the Migos Flow Changed Atlanta Rap
 - [https://biztoc.com/p/mc8r2bcc?ref=rss&rd=1](https://biztoc.com/p/mc8r2bcc?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:16:00+00:00

Quick-jabbing triplets had been a staple of rap, but the trio made the style sound fresh, thanks in large part to Takeoff, its master of syncopation. The rapper was shot and killed at 28 on Tuesday. <br /><br /> #takeoff #trio #rapper #master #triplets #rap #migosflowchangedatlanta

## Ryan Coogler explains what the Black Panther sequel would have looked like with Chadwick Boseman
 - [https://biztoc.com/p/vhbqdevr?ref=rss&rd=1](https://biztoc.com/p/vhbqdevr?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:10:32+00:00

Black Panther: Wakanda Forever director shares the plan he had for the sequel had Marvel star Chadwick Boseman lived <br /><br /> #ryancoogler #sequel #wakandaforever #blackpanther #marvel #chadwickboseman

## Video shows Iranian security forces beating and shooting man as officials order investigation
 - [https://www.cnn.com/2022/11/02/middleeast/iran-police-security-forces-video-investigation-intl/index.html](https://www.cnn.com/2022/11/02/middleeast/iran-police-security-forces-video-investigation-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:09:04+00:00

Iranian police said they would investigate an incident caught on camera showing security forces attacking and shooting a man, as a leading rights group condemned what it called the "crisis of impunity" in the country.

## Raheem Mostert: Bradley Chubb, Jeff Wilson trades are thrilling
 - [https://biztoc.com/p/y4ivf8c9?ref=rss&rd=1](https://biztoc.com/p/y4ivf8c9?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:09:00+00:00

The Dolphins were busy heading into Tuesday afternoon’s deadline and they wound up adding pieces on both sides of the ball before it passed.Edge rusher Bradley Chubb came from the Broncos in a... <br /><br /> #jeffwilson #bradleychubb #raheemmostert #broncos

## Takeoff, Migos Rapper, Dead After Being Shot in Houston
 - [https://biztoc.com/p/bkrvwtqz?ref=rss&rd=1](https://biztoc.com/p/bkrvwtqz?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:09:00+00:00

Takeoff, a member of the hip-hop trio Migos, was fatally shot at a party on November 1 at a bowling alley in Houston, police have confirmed. Takeoff, whose legal name was Kirshnik Khari Ball, was... <br /><br /> #rapper #rollingstoneball #kirshnikkhariball #quavo #migos #trio #poloclub #familymembers #georgia #hiphoptrio

## 10-year-old trapped with the Uvalde school shooter repeatedly called 911 for help
 - [https://www.cnn.com/2022/11/01/us/uvalde-911-classroom-call-delay/index.html](https://www.cnn.com/2022/11/01/us/uvalde-911-classroom-call-delay/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:07:32+00:00

"I'm in classroom 112," the little girl tells the police dispatcher. "Please hurry. There is a lot of dead bodies."

## Suspect in Paul Pelosi attack awoke him by standing over his bedside, documents show
 - [https://www.cnn.com/2022/11/02/politics/paul-pelosi-attack-latest-depape-court/index.html](https://www.cnn.com/2022/11/02/politics/paul-pelosi-attack-latest-depape-court/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:06:15+00:00

Disturbing new details have emerged in the attack on House Speaker Nancy Pelosi's husband, Paul Pelosi, including that the alleged assailant told police he was on a "suicide mission" and had a list of other prominent targets.

## Kidnapped 6-year-old Florida boy reunites with mom after being found in Canada
 - [https://biztoc.com/p/es624aq9?ref=rss&rd=1](https://biztoc.com/p/es624aq9?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:04:00+00:00

An Amber Alert had been issued for the boy at the end of August. <br /><br /> #florida #mom

## Midterm elections latest news: Biden to deliver speech on democracy tonight near Capitol
 - [https://biztoc.com/p/8efik9ji?ref=rss&rd=1](https://biztoc.com/p/8efik9ji?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:04:00+00:00

<br /><br /> #capitol #elections

## Ben Affleck Has Turned Jennifer Lopez into a Dunkin' Donuts Girl
 - [https://biztoc.com/p/2vritm9w?ref=rss&rd=1](https://biztoc.com/p/2vritm9w?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:02:14+00:00

Jennifer Lopez drinking Dunkin' Donuts for Ben Affleck may really be a master class in compromising for a happy marriage.
    Yesterday, Mr. and Mrs. Affleck—who married in a Vegas ceremony... <br /><br /> #neighborhood #ceremony #benaffleck #jenniferlopez #snacks #dunkindonuts #brentwood #vegas #georgia #masterclass

## Putin hasn't decided if he'll run for new presidential term in 2024
 - [https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-11-02-22#h_dc4f2e3094b68a2b267bf3c9b20775ef](https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-11-02-22#h_dc4f2e3094b68a2b267bf3c9b20775ef)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:02:02.328840+00:00



## Putin has not yet decided if he'll run for new presidential term in 2024, Kremlin says
 - [https://www.cnn.com/webview/europe/live-news/russia-ukraine-war-news-11-02-22#h_dc4f2e3094b68a2b267bf3c9b20775ef](https://www.cnn.com/webview/europe/live-news/russia-ukraine-war-news-11-02-22#h_dc4f2e3094b68a2b267bf3c9b20775ef)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 14:02:02.157437+00:00



## A bill passed to end daylight saving time. Here’s why you still have to change your clocks
 - [https://biztoc.com/p/9idn5wgm?ref=rss&rd=1](https://biztoc.com/p/9idn5wgm?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:52:00+00:00

Get ready for another change in time. Or at least a change in the clocks. <br /><br /> #change

## NFL betting: Even with all the action at trade deadline, Super Bowl odds didn't move
 - [https://biztoc.com/p/cz98nz82?ref=rss&rd=1](https://biztoc.com/p/cz98nz82?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:49:50+00:00

The trade deadline had a lot of activity, but what impact will the moves make? <br /><br /> #superbowl #nfl

## Christina Applegate on the subtle signs that led to MS diagnosis: 'I wish I had paid attention'
 - [https://biztoc.com/p/w5deg9js?ref=rss&rd=1](https://biztoc.com/p/w5deg9js?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:48:15+00:00

The “Dead To Me” star was diagnosed with multiple sclerosis in the summer of 2021. <br /><br /> #deadtome #christinaapplegate

## Kim Kardashian and Pete Davidson Not in Contact Despite Reports
 - [https://biztoc.com/p/79sgafhv?ref=rss&rd=1](https://biztoc.com/p/79sgafhv?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:47:37+00:00

Kim Kardashian and Pete Davidson have moved on -- at least for the time being -- from being a couple ... and are not still in communication, despite some recent reports. <br /><br /> #kimkardashian #petedavidson #contactdespitereports

## NFL trade deadline winners and losers: Breakdown of record day
 - [https://biztoc.com/p/qjpuvigi?ref=rss&rd=1](https://biztoc.com/p/qjpuvigi?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:46:19+00:00

The NFL trade deadline featured a handful of trades, particularly with potential contenders for the playoffs. Read about who on the deadline and who lost. <br /><br /> #losers #nfl #contenders #breakdown #playoffs #tradedeadlinewinners

## White House announces $13.5 bln funding to help households with energy bills
 - [https://biztoc.com/p/zwyjjv4y?ref=rss&rd=1](https://biztoc.com/p/zwyjjv4y?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:45:00+00:00

President Joe Biden's administration will make $13.5 billion available to help low-income U.S. households lower their heating costs this winter, the White House said on Wednesday. <br /><br /> #households

## Grain deal guarantees safe passage for ships carrying vital exports
 - [https://www.cnn.com/collections/intl-ukraine-021122/](https://www.cnn.com/collections/intl-ukraine-021122/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:42:51+00:00



## Adele reveals the correct way to pronounce her name
 - [https://biztoc.com/p/u58biiyt?ref=rss&rd=1](https://biztoc.com/p/u58biiyt?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:40:00+00:00

The Grammy winner praised a fan who said her name “perfectly” during a Q&amp;A to celebrate the release of her “I Drink Wine” music video. <br /><br /> #adele #musicvideo #idrinkwine #fan #qamp

## US accuses North Korea trying to hide shipments of ammunition to Russia
 - [https://www.cnn.com/2022/11/02/politics/north-korea-russia-ammunition/index.html](https://www.cnn.com/2022/11/02/politics/north-korea-russia-ammunition/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:38:41+00:00

The United States is accusing North Korea of secretly supplying Russia with a significant number of artillery shells for use in the Ukraine war and is trying to hide the shipments by making it appear as if the ammunition is being sent to countries in the Middle East or North Africa, according to newly declassified intelligence.

## The family of a woman who vanished 8 months ago in Wyoming is frustrated by delays in the case
 - [https://www.cnn.com/2022/11/02/us/irene-gakwa-missing-wyoming-woman-family-cec/index.html](https://www.cnn.com/2022/11/02/us/irene-gakwa-missing-wyoming-woman-family-cec/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:38:40+00:00

A criminal trial involving the boyfriend of a missing Wyoming woman has been postponed to next year, leaving her family frustrated over the second delay in the case in as many months.

## ‘Avatar: The Way of Water’ Official Trailer Unveils Stunning New Footage of Pandora, Teases an Epic War
 - [https://biztoc.com/p/swj5468n?ref=rss&rd=1](https://biztoc.com/p/swj5468n?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:36:00+00:00

20th Century Studios has released a new trailer for “Avatar: The Way of Water” a few weeks ahead of the hotly anticipated sci-fi sequel’s Dec. 16 release date. The second installm… <br /><br /> #avatarthewayofwater #trailer #pandora #scifisequel

## Sabotage of military helicopters deep inside Russia purportedly shown on video
 - [https://www.cnn.com/2022/11/02/europe/russia-helicopter-sabotage-video-intl/index.html](https://www.cnn.com/2022/11/02/europe/russia-helicopter-sabotage-video-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:34:12+00:00

Video has emerged purporting to show a man preparing and planting explosives on a Russian military helicopter at an airbase deep inside Russia.

## PlayStation VR2 Release Date and Price Revealed
 - [https://biztoc.com/p/6urimgfp?ref=rss&rd=1](https://biztoc.com/p/6urimgfp?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:30:09+00:00

PlayStation VR 2 will officially be released on February 22, 2023, for $549.99, and pre-orders will begin on November 15. <br /><br /> #vr2 #playstationvr2 #price

## A decade of rising house prices is over. The UK economy will feel the pain
 - [https://www.cnn.com/2022/11/02/economy/uk-housing-market-mortgage-rates/index.html](https://www.cnn.com/2022/11/02/economy/uk-housing-market-mortgage-rates/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:30:07+00:00

For years, home ownership in Britain has been a one-way bet. Prices have climbed steadily since the global financial crisis, rising in even larger increments after the pandemic began.

## The risky and lonely path for women in sports
 - [https://www.cnn.com/2022/11/02/opinions/brittney-griner-mana-russia-shim-us-soccer-bass/index.html](https://www.cnn.com/2022/11/02/opinions/brittney-griner-mana-russia-shim-us-soccer-bass/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:27:23+00:00

News last week that a Russian court upheld Phoenix Mercury star Brittney Griner's sentence of nine years in a penal colony for drug smuggling surprised no one. While Jake Sullivan, President Joe Biden's national security adviser, deemed the appeal "another sham judicial proceeding" and asked that Griner "be released immediately," the outcome continues to hang in the air as her legal team considers next steps.

## Israel's Netanyahu, facing multiple corruption charges, is set for a dramatic comeback in 5th election since 2019
 - [https://biztoc.com/p/sb8bf3e9?ref=rss&rd=1](https://biztoc.com/p/sb8bf3e9?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:20:18+00:00

Netanyahu is the longest-serving prime minister in Israel's history, and is currently charged with multiple counts of corruption with investigations and legal proceedings ongoing. <br /><br /> #election #proceedings #netanyahu #investigations #israel

## Apple TV 4K (3rd-Generation) Review
 - [https://biztoc.com/p/zi6hw3a6?ref=rss&rd=1](https://biztoc.com/p/zi6hw3a6?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:16:45+00:00

The new Apple TV 4K will start arriving to customers and launch in stores on Friday, November 4. Ahead of time, the first reviews of the latest Apple... <br /><br /> #apple #reviews

## The Parkland school shooter is set to be sentenced to life in prison today
 - [https://www.cnn.com/2022/11/02/us/parkland-shooter-nikolas-cruz-sentencing-wednesday/index.html](https://www.cnn.com/2022/11/02/us/parkland-shooter-nikolas-cruz-sentencing-wednesday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:15:12+00:00

The gunman who murdered 17 people in 2018 at a South Florida high school is expected to be sentenced Wednesday to life in prison without the possibility of parole, bringing to a close an agonizing, monthslong trial in which a jury declined to recommend a death sentence.

## Trucking, oil companies ramp up warnings on diesel shortage: 'We put ourselves in this situation'
 - [https://biztoc.com/p/4wet6be3?ref=rss&rd=1](https://biztoc.com/p/4wet6be3?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:13:28+00:00

Energy suppliers, truckers warn about diesel shortages ahead of the busy holiday season, as supply chain disruptions prompt surging prices at the pump. <br /><br /> #energysuppliers #truckers #oilcompanies

## Start ‘Em, Sit ‘Em Quarterbacks Fantasy Football Week 9: Justin Herbert Saves Bye-mageddon
 - [https://biztoc.com/p/57cuqyd9?ref=rss&rd=1](https://biztoc.com/p/57cuqyd9?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:07:14+00:00

With six teams on a bye, it’s time for the Chargers QB to step up. <br /><br /> #qb #chargers

## Russian generals reportedly discuss using nuclear weapons in Ukraine; Russia rejoins grain deal: Live updates
 - [https://biztoc.com/p/2g9sppkr?ref=rss&rd=1](https://biztoc.com/p/2g9sppkr?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:06:34+00:00

The on-again, off-again agreement under which Russia allowed grain to be shipped from Ukraine  is on again effective Thursday. Live updates. <br /><br /> #generals #russian #ukraine

## Twitter flags White House tweet crediting Biden for increase in Social Security payments caused by inflation
 - [https://biztoc.com/p/3q98pmbu?ref=rss&rd=1](https://biztoc.com/p/3q98pmbu?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:06:16+00:00

The White House is giving President Biden credit for a rising in Social Security payments that was actually driven by inflation levels that haven't been seen in decades.

## James Corden gives credit to Ricky Gervais after 'inadvertantly' telling his joke
 - [https://www.cnn.com/2022/11/02/entertainment/james-corden-ricky-gervais-joke/index.html](https://www.cnn.com/2022/11/02/entertainment/james-corden-ricky-gervais-joke/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:03:14+00:00

James Corden says he "inadvertently" told a joke originally made by fellow British funnyman Ricky Gervais.

## James Corden gives credit to Ricky Gervais after 'inadvertantly' telling his joke
 - [https://biztoc.com/p/rzb37xnb?ref=rss&rd=1](https://biztoc.com/p/rzb37xnb?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:03:00+00:00

James Corden says he "inadvertently" told a joke originally made by fellow British funnyman Ricky Gervais. <br /><br /> #rickygervais #jamescorden

## Doctors explain why mass shooters are usually male
 - [https://www.cnn.com/videos/health/2022/11/02/young-men-mass-shootings-doctors-wellness-orig.cnn](https://www.cnn.com/videos/health/2022/11/02/young-men-mass-shootings-doctors-wellness-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:01:22+00:00

It has become increasingly common to attribute mental illness as a key reason young men turn into active shooters. Relying on decades of experience, psychologist Dr. John Duffy and Vanderbilt University psychiatrist Dr. Jonathan M. Metzl question that idea while hashing out why a generation of young men, who were "handed the keys to the kingdom," have turned lethargic and hopeless.

## Steven Spielberg: The Origin Story
 - [https://biztoc.com/p/8v5yaws2?ref=rss&rd=1](https://biztoc.com/p/8v5yaws2?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:00:26+00:00

In 'The Fabelmans,' starring Michelle Williams, Paul Dano and Gabriel LaBelle, the director finally tells his own coming-of-age saga, mining family secrets and the antisemitic bullying of his... <br /><br /> #saga #pauldano #gabriellabelle #michellewilliams #stevenspielberg #thefabelmans #filmmaking #director #youth #theoriginstoryin

## Who Is Jennifer Lawrence Now?
 - [https://biztoc.com/p/b5vnzyvf?ref=rss&rd=1](https://biztoc.com/p/b5vnzyvf?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:00:15+00:00

The Oscar-winning “Hunger Games” actress is free from her franchise commitments. But after a brief hiatus from acting, what will she do next? <br /><br /> #jenniferlawrence #hiatus #hungergames #actress

## Apple TV 4K (2022) review: unmatched power, unrealized potential
 - [https://biztoc.com/p/45jtr3f5?ref=rss&rd=1](https://biztoc.com/p/45jtr3f5?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 13:00:00+00:00

The latest Apple TV 4K is Apple’s most powerful and full-featured entertainment box yet. And it’s finally available for a lower, if not quite cheap, $129 starting price. Now in its third... <br /><br /> #iphone #samsung #streamingplayer #appletv #apple #dolby #tvs

## Trump lawyers saw Clarence Thomas as ‘only chance’ to challenge 2020 election, report says
 - [https://biztoc.com/p/fbmne9iu?ref=rss&rd=1](https://biztoc.com/p/fbmne9iu?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 12:59:00+00:00

Attorney called ruling from conservative justice ‘our only chance to get a favorable judicial opinion’ by 6 January – follow all the latest news <br /><br /> #lawyers #election #trump #clarencethomas #attorney

## With 86% of votes tallied, Netanyahu on verge of breaking deadlock, regaining power
 - [https://biztoc.com/p/qjvab7ag?ref=rss&rd=1](https://biztoc.com/p/qjvab7ag?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 12:57:10+00:00

Near-complete results give Likud leader's bloc 65 seats, with far-right set to gain unprecedented power; landscape could change if Meretz, Balad cross threshold, but seen unlikely <br /><br /> #likud #balad #netanyahu #meretz

## We have been saying Adele's name wrong
 - [https://www.cnn.com/2022/11/02/entertainment/adele-name-pronunciation/index.html](https://www.cnn.com/2022/11/02/entertainment/adele-name-pronunciation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 12:55:19+00:00

Adele has shared how her name is actually pronounced.

## Start ‘Em, Sit ‘Em Kickers and Team Defenses Fantasy Football Week 9
 - [https://biztoc.com/p/nm9fb78q?ref=rss&rd=1](https://biztoc.com/p/nm9fb78q?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 12:42:41+00:00

Bill Belichick’s defense against an inexperienced QB is always a solid pick. <br /><br /> #qb #billbelichick

## Hurricane Lisa headed toward Belize; Martin also forecast to become hurricane
 - [https://biztoc.com/p/xfrska4c?ref=rss&rd=1](https://biztoc.com/p/xfrska4c?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 12:35:49+00:00

Hurricane Lisa developed in the Caribbean as the storm churned toward Belize on Wednesday, while Tropical Storm Martin is also forecast to become a short-lived hurricane. <br /><br /> #storm #caribbean #hurricanelisa #belize #hurricane #tropicalstormmartin

## Woj: Hiring Ime Udoka would be the 'last-ditch effort' to make this Nets team work
 - [https://biztoc.com/p/q4sgsvrj?ref=rss&rd=1](https://biztoc.com/p/q4sgsvrj?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 12:30:12+00:00

<br /><br /> #woj #imeudoka

## Niners RB Christian McCaffrey, Titans RB Derrick Henry lead Players of the Week
 - [https://biztoc.com/p/qegppdsk?ref=rss&rd=1](https://biztoc.com/p/qegppdsk?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 12:30:00+00:00

Running backs Derrick Henry and Christian McCaffrey led the way in the latest NFL weekly honor roll. <br /><br /> #derrickhenry #honorroll #christianmccaffrey #nfl #runningbacks #titansrb

## After Seoul Halloween crowd crush, these are the items left behind
 - [https://biztoc.com/p/xi4zewit?ref=rss&rd=1](https://biztoc.com/p/xi4zewit?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 12:22:00+00:00

<br /><br /> #seoulhalloween #crowdcrush

## Police question nanny of Nigerian music star Davido following death of his three-year-old son
 - [https://www.cnn.com/2022/11/02/africa/davido-son-drowns-scli-intl/index.html](https://www.cnn.com/2022/11/02/africa/davido-son-drowns-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 12:20:29+00:00

Police are questioning a nanny employed by Nigerian music star Davido following the death of his three-year-old son on Halloween.

## Prisco's NFL Week 9 picks: Streaking Commanders upset Vikings; Bucs beat Rams to snap skid; Saints stun Ravens
 - [https://biztoc.com/p/5jcpe2sj?ref=rss&rd=1](https://biztoc.com/p/5jcpe2sj?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 12:19:39+00:00

Pete Prisco reveals his Week 9 picks, including the Seahawks winning a desert shootout <br /><br /> #saints #nfl #ravens #bucs #desertshootout #vikings #seahawks #peteprisco #rams

## Christina Applegate gained 40 pounds, 'can't walk without a cane' amid MS battle
 - [https://biztoc.com/p/f5vtpbtd?ref=rss&rd=1](https://biztoc.com/p/f5vtpbtd?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 12:18:00+00:00

“I’m never going to accept this,” the “Dead to Me” star said, one year after revealing she’d been diagnosed with multiple sclerosis. “I’m pissed.&amp;#82… <br /><br /> #deadtome #christinaapplegate

## With first CFP rankings of 2022 released, what would a 12-team expanded field look like?
 - [https://biztoc.com/p/5kvd47hz?ref=rss&rd=1](https://biztoc.com/p/5kvd47hz?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 12:16:19+00:00

Exploring and projecting the future 12-team College Football Playoff with this week's rankings. <br /><br /> #cfp

## Adele Reveals How We've All Been Pronouncing Her Name Incorrectly
 - [https://biztoc.com/p/gf2adzwf?ref=rss&rd=1](https://biztoc.com/p/gf2adzwf?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 12:15:48+00:00

The Emmy, Grammy and Oscar winner says the correct pronunciation is a long "A" sound on the second syllable

## Grading every NFL trade deadline move: Bradley Chubb to the Dolphins, Chase Claypool to the Bears and more
 - [https://biztoc.com/p/tfm5nt6t?ref=rss&rd=1](https://biztoc.com/p/tfm5nt6t?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 12:04:32+00:00

From the Baltimore Ravens' trade for linebacker Roquan Smith to the Jacksonville Jaguars' acquisition of wide receiver Calvin Ridley, we grade every trade that went down at the deadline. <br /><br /> #bears #chaseclaypool #jacksonvillejaguars #nfl #roquansmith #baltimoreravens #bradleychubb #calvinridley

## Sabotage of military helicopters deep inside Russia purportedly shown on video
 - [https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-11-02-22#h_4392bb961684a91c25326589af72c0ed](https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-11-02-22#h_4392bb961684a91c25326589af72c0ed)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 12:01:58.420447+00:00



## Take the quiz: What kind of traveler are you?
 - [https://cnn.it/3NsijLy](https://cnn.it/3NsijLy)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 12:01:58.327784+00:00



## New class of combative MAGA candidates poised to roil House GOP
 - [https://biztoc.com/p/jgg2gyi6?ref=rss&rd=1](https://biztoc.com/p/jgg2gyi6?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 12:00:00+00:00

<br /><br /> #candidates #maga

## Iowa teens killed Spanish teacher over bad grade, prosecutors say
 - [https://biztoc.com/p/ytm3w872?ref=rss&rd=1](https://biztoc.com/p/ytm3w872?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:56:58+00:00

The documents were filed ahead of a hearing Wednesday where a judge will hear arguments on whether to suppress any of the evidence against the two teens, who are charged with murdering high school... <br /><br /> #nohemagraber #prosecutors #iowa #highschool #teacher #fairfield #hearing #spanish #teens

## How much alcohol is too much? Dr. Narula reports on new study
 - [https://www.cnn.com/videos/health/2022/11/02/excessive-drinking-deaths-study-dr-narula-contd-cnntm-vpx.cnn](https://www.cnn.com/videos/health/2022/11/02/excessive-drinking-deaths-study-dr-narula-contd-cnntm-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:52:17+00:00

An estimated one in five deaths of people ages 20 to 49 were attributable to excessive alcohol use in the United States, according to a new study published in JAMA Network Open. CNN medical correspondent Dr. Tara Narula reports.

## US women's gymnastics team wins historic gold medal at world championships in Liverpool
 - [https://www.cnn.com/2022/11/02/sport/usa-women-gymnastics-world-championships-gold-spt-intl/index.html](https://www.cnn.com/2022/11/02/sport/usa-women-gymnastics-world-championships-gold-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:52:14+00:00

The US women's gymnastics team has claimed a record-breaking sixth world championships gold medal in a row -- even without Simone Biles.

## Adele praises fan for pronouncing her name 'perfectly,' revealing many have been saying it wrong for years
 - [https://biztoc.com/p/kiafetkq?ref=rss&rd=1](https://biztoc.com/p/kiafetkq?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:51:47+00:00

The famed singer appeared shocked by a fan's perfect pronunciation of her name at a recent Q&amp;A event in Los Angeles. <br /><br /> #qamp #singer #adele #fan #qaevent

## Grain deal guarantees safe passage for ships carrying vital exports
 - [https://www.cnn.com/2022/11/02/europe/russia-resumes-ukraine-grain-deal-intl/index.html](https://www.cnn.com/2022/11/02/europe/russia-resumes-ukraine-grain-deal-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:46:23+00:00

Russia has rejoined the agreement that guarantees safe passage for ships carrying vital grain exports from Ukraine, just days after announcing it was suspending its participation in the pact, the Russian Ministry of Defense announced on Wednesday.

## Russia changes course, rejoins key Ukraine grain export deal
 - [https://biztoc.com/p/f5myvh8b?ref=rss&rd=1](https://biztoc.com/p/f5myvh8b?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:46:00+00:00

Russia said Wednesday it was rejoining the agreement that guarantees safe passage for ships carrying vital grain exports from Ukraine, a move that may help ease concerns about global food supplies... <br /><br /> #moscow #ukraine #grainexportdeal

## Russia-Ukraine war latest updates
 - [https://biztoc.com/p/czsj2d4u?ref=rss&rd=1](https://biztoc.com/p/czsj2d4u?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:44:32+00:00

<br /><br /> #war #ukraine

## Broncos GM George Paton: Bradley Chubb trade would have happened 'regardless' of Denver's record
 - [https://biztoc.com/p/fdmh2j3a?ref=rss&rd=1](https://biztoc.com/p/fdmh2j3a?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:39:00+00:00

Denver general manager George Paton traded star edge rusher Bradley Chubb on Tuesday for a package that included a first-round pick, and he claimed he would've made the deal even if the Broncos... <br /><br /> #denver #broncos #bradleychubb #georgepaton

## 'I think the NBA dropped the ball' on Kyrie Irving, says Charles Barkley
 - [https://www.cnn.com/2022/11/02/sport/kyrie-irving-brooklyn-nets-spt-intl/index.html](https://www.cnn.com/2022/11/02/sport/kyrie-irving-brooklyn-nets-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:38:18+00:00

NBA analyst and Basketball Hall of Famer Charles Barkley says he thinks the league "dropped the ball" on Kyrie Irving after the Brooklyn Nets star tweeted a documentary deemed to be antisemitic.

## Rishi Sunak's First Big U-Turn After Taking Charge As UK PM
 - [https://biztoc.com/p/6r6zikzg?ref=rss&rd=1](https://biztoc.com/p/6r6zikzg?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:38:18+00:00

UK Prime Minister Rishi Sunak on Wednesday announced he will attend the UN climate change conference, reversing an initial decision not to go because of "pressing domestic commitments". <br /><br /> #primeminister #rishisunak #climatechangeconference

## Video games invade the art world in MoMA's Never Alone exhibition
 - [https://biztoc.com/p/uxhdb629?ref=rss&rd=1](https://biztoc.com/p/uxhdb629?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:30:24+00:00

Are games art? Who cares. Exhibit is more interested in how they bring us together. <br /><br /> #artworld #exhibit #moma #exhibition #gamesart #neveralone

## World Series: Astros' Lance McCullers Jr. allows five Phillies home runs, dismisses idea of tipping pitches
 - [https://biztoc.com/p/74yx67rn?ref=rss&rd=1](https://biztoc.com/p/74yx67rn?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:30:00+00:00

McCullers is the first pitcher in World Series history to allow five homers in an outing <br /><br /> #outing #lancemccullersjr #worldseries #pitches #astros #phillies

## Matthew Perry 'could not be more single' after broken engagement
 - [https://biztoc.com/p/qd6bu88g?ref=rss&rd=1](https://biztoc.com/p/qd6bu88g?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:28:00+00:00

The “Friends” alum told Andy Cohen he doesn’t “have any rules” about dating sober people, clarifying, “That would be good. But it’s not a necessity.” <br /><br /> #alum #matthewperry #andycohen #single

## A huge tunnel has opened below Niagara Falls
 - [https://www.cnn.com/travel/article/niagara-falls-tunnel/index.html](https://www.cnn.com/travel/article/niagara-falls-tunnel/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:26:57+00:00

A whitewater wonder visited by everyone from Marilyn Monroe to Mark Twain, Niagara Falls has been a magnet drawing global travelers for at least two centuries. But until this year, a huge tunnel buried deep below the cascade has been off-limits to visitors.

## Suspect in Paul Pelosi attack told police he was on 'suicide mission'
 - [https://biztoc.com/p/iks6th6r?ref=rss&rd=1](https://biztoc.com/p/iks6th6r?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:20:00+00:00

Disturbing new details have emerged in the attack on House Speaker Nancy Pelosi's husband, Paul Pelosi, including that the alleged assailant told police he was on a "suicide mission" and had a... <br /><br /> #paulpelosi #assailant #attack #nancypelosi

## Netanyahu on course to lead Israel's most right-wing government ever, partial Israel results suggest
 - [https://www.cnn.com/2022/11/02/middleeast/netanyahu-israel-election-results-intl/index.html](https://www.cnn.com/2022/11/02/middleeast/netanyahu-israel-election-results-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:18:56+00:00

Benjamin Netanyahu appears to be on course for a bigger victory in Israel's fifth election in less than four years than initial exit polls suggested, all three of the country's main television channels projected Wednesday morning.

## Scientists identify genes that can cause 'uncombable hair syndrome'
 - [https://www.cnn.com/2022/11/02/health/uncombable-thick-hair-genes-scn-partner/index.html](https://www.cnn.com/2022/11/02/health/uncombable-thick-hair-genes-scn-partner/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:18:12+00:00

It's a hair condition that has frustrated parents for decades, now scientists believe they have found the genes responsible for "uncombable hair syndrome". Yes, it really is a thing.

## Netanyahu on course to lead Israel's most right-wing government ever, partial Israel results suggest
 - [https://biztoc.com/p/ayvvh8ma?ref=rss&rd=1](https://biztoc.com/p/ayvvh8ma?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:18:00+00:00

Benjamin Netanyahu appears to be on course for a bigger victory in Israel's fifth election in less than four years than initial exit polls suggested, all three of the country's main television... <br /><br /> #benjaminnetanyahu #israel #election #victory #televisionchannels

## European club suffers worst Champions League campaign in history
 - [https://www.cnn.com/2022/11/02/football/rangers-champions-league-worst-record-spt-intl/index.html](https://www.cnn.com/2022/11/02/football/rangers-champions-league-worst-record-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:15:21+00:00

The good news for Glasgow Rangers is the Scottish club has pocketed over $15 million for competing in the Champions League. The bad news is, after waiting 12 years to get back into the competition's group stages, the club's return has been nothing short of a nightmare.

## Wisconsin governor candidate Michels says he would fire DA Chisholm
 - [https://biztoc.com/p/iu9jfqa6?ref=rss&rd=1](https://biztoc.com/p/iu9jfqa6?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:14:07+00:00

Nearly every time Tim Michels is on the campaign trail, he mentions what he plans to do on Day 1 if elected: fire Milwaukee County DA John Chisholm. <br /><br /> #dachisholm #johnchisholm #campaigntrail #timmichels #wisconsin #milwaukeecounty

## Powerball jackpot soars to $1.2B, second largest in game's history
 - [https://biztoc.com/p/wudcfajy?ref=rss&rd=1](https://biztoc.com/p/wudcfajy?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:09:35+00:00

The Powerball jackpot has reached an estimated $1.2 billion after no ticket matched all six winning numbers on Monday night. This will be the second-largest jackpot. <br /><br /> #jackpot

## Sharon Stone Reveals Doctors Found 'Large Fibroid Tumor' in Her Body Following Misdiagnosis
 - [https://biztoc.com/p/gpu3vfbs?ref=rss&rd=1](https://biztoc.com/p/gpu3vfbs?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:01:07+00:00

"Don't get blown off ❣️GET A SECOND OPINION ❣️ It can save your life 🙏🏻💥," the Basic Instinct actress encouraged her followers on Instagram Tuesday after sharing the news <br /><br /> #basicinstinct #doctors #sharonstone #actress

## James Corden credits Ricky Gervais after making nearly identical joke
 - [https://biztoc.com/p/asyn42up?ref=rss&rd=1](https://biztoc.com/p/asyn42up?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:01:00+00:00

<br /><br /> #rickygervais #jamescorden

## Wall Street's recent love affair with the Fed could turn on a dime
 - [https://www.cnn.com/2022/11/02/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2022/11/02/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:00:58+00:00

Fed decision day is here — and so is some potential bad news for the market.

## Takeoff shooting - live: Drake and James Corden pay tribute to Migos rapper as Houston police issue statement
 - [https://biztoc.com/p/y7s6yact?ref=rss&rd=1](https://biztoc.com/p/y7s6yact?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:00:16+00:00

Takeoff, a member of rap trio Migos, has been shot dead in Houston, Texas, his representatives have confirmed.
    The rapper, whose full name was Kirshnik Khari Ball, was 28.
    His group mate,... <br /><br /> #representative #takeoff #quavoamp #victim #migos #houston #rapper #jamescorden #raptrio #drake

## GOP gains in deep-blue New York’s governor race rattle Democrats
 - [https://biztoc.com/p/27ea2x4i?ref=rss&rd=1](https://biztoc.com/p/27ea2x4i?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:00:00+00:00



## Julie Powell's Last Tweet Before Her Death at 49 Causes Confusion Among Fans
 - [https://biztoc.com/p/avdn7c8s?ref=rss&rd=1](https://biztoc.com/p/avdn7c8s?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 11:00:00+00:00

The popular author of Julie and Julia tweeted she had "black hairy tongue" the day before she died. <br /><br /> #juliepowell #julieandjulia

## Russian mercenaries jockey for influence amid military struggles in Ukraine
 - [https://www.cnn.com/2022/11/02/politics/yevgeny-prigozhin-ukraine-putin-kremlin-war-ukraine/index.html](https://www.cnn.com/2022/11/02/politics/yevgeny-prigozhin-ukraine-putin-kremlin-war-ukraine/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 10:39:43+00:00

One of Russian President Vladimir Putin's closest allies is using dissent around the war in Ukraine to jockey for increased influence inside the Kremlin, US and European officials said, offering a rare glimpse at the brewing tension among Putin allies and how Russia's disastrous war in Ukraine is affecting the internal dynamics of the Kremlin.

## Nets' Kevin Durant 'shocked' over Steve Nash's departure
 - [https://biztoc.com/p/ej3jqi6y?ref=rss&rd=1](https://biztoc.com/p/ej3jqi6y?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 10:38:02+00:00

Kevin Durant and Joe Harris both spoke about Steve Nash's departure from the Brooklyn Nets after their game against the Chicago Bulls on Tuesday night. <br /><br /> #chicagobulls #departure #joeharris #brooklynnets #stevenash #kevindurant

## Migos’s record label rails at ‘senseless violence’ that killed rapper Takeoff
 - [https://biztoc.com/p/i8pyn7cq?ref=rss&rd=1](https://biztoc.com/p/i8pyn7cq?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 10:34:00+00:00

Atlanta-based Quality Control issues statement speaking of ‘monumental loss’, as Houston police appeal for any of 40 people at scene to come forward <br /><br /> #takeoffatlanta #scene #houston #qualitycontrol #migos #rapper

## CVS Health raises outlook as third quarter results beat estimates
 - [https://biztoc.com/p/yd6cx333?ref=rss&rd=1](https://biztoc.com/p/yd6cx333?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 10:33:32+00:00

CVS Health beat Wall Street's expectations in its third quarter earnings report. The company also announced an opioid settlement. <br /><br /> #earningsreport

## Headless bodies and deadly bombs: gang violence escalates in Ecuador
 - [https://biztoc.com/p/skggngau?ref=rss&rd=1](https://biztoc.com/p/skggngau?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 10:32:00+00:00

On Tuesday, President Guillermo Lasso announced a curfew under a new state of emergency in Guayas and Esmeralda regions <br /><br /> #esmeralda #guillermolasso #guayas #curfew #ecuador

## Musk's midterm plans for Twitter, GOP on the offensive in Biden country and more top headlines
 - [https://biztoc.com/p/exbbzq32?ref=rss&rd=1](https://biztoc.com/p/exbbzq32?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 10:30:59+00:00

Fox News First brings you Fox News' top headlines every morning. <br /><br /> #musk #headlines #foxnewsfirst

## CVS, Walgreens and Walmart reach a tentative $12 billion deal in opioid cases, reports say
 - [https://www.cnn.com/2022/11/02/us/cvs-walgreens-walmart-opioid-settlement/index.html](https://www.cnn.com/2022/11/02/us/cvs-walgreens-walmart-opioid-settlement/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 10:28:27+00:00

Three major retailers -- CVS, Walgreens and Walmart -- have tentatively agreed to pay at least $12 billion to settle a number of lawsuits brought by states and local governments alleging the retailers mishandled prescriptions of opioid painkillers, according to reports from Bloomberg and Reuters.

## Jana Kramer Confronts Meghan King for Calling Her Ex-Husband Mike Caussin ‘Hot’: It ‘Really Bothered Me’
 - [https://biztoc.com/p/5k5i9pnj?ref=rss&rd=1](https://biztoc.com/p/5k5i9pnj?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 10:26:05+00:00

Getting heated. Jana Kramer clashed with Meghan King after the reality star called Mike Caussin "hot" — and the women gave fans a front-row seat as they hashed out their differences. Kramer, 38,... <br /><br /> #janakramer #callingher #mikecaussin #podcast #meghanking #realitystar #mikecaussinhot

## Philadelphia Phillies demolish Houston Astros in history-making victory and take a 2-1 series lead
 - [https://www.cnn.com/2022/11/02/sport/astros-phillies-world-series-game-3-spt-intl-trnd/index.html](https://www.cnn.com/2022/11/02/sport/astros-phillies-world-series-game-3-spt-intl-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 10:16:20+00:00

Philadelphia had waited 4,746 days to host a World Series game and it was forced to wait another day when Monday night's game was postponed due to rain.

## Russia Resumes Ukraine Grain-Export Deal in Abrupt Reversal
 - [https://biztoc.com/p/726yqe8i?ref=rss&rd=1](https://biztoc.com/p/726yqe8i?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 10:16:01+00:00

<br /><br /> #ukrainegrainexportdeal

## First Call: 1 team may have helped boost Steelers' return for Chase Claypool; reported off-field reasons for trade
 - [https://biztoc.com/p/dh78rcne?ref=rss&rd=1](https://biztoc.com/p/dh78rcne?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 10:13:07+00:00

Wednesday’s “First Call” looks at a number of angles surrounding the trade of Pittsburgh Steelers wide receiver Chase Claypool — from reaction in Chicago, to theories as to why the deal was made... <br /><br /> #pittsburghsteelers #callrdquo #chaseclaypool #firstcall

## What to expect from the Federal Reserve meeting
 - [https://www.cnn.com/2022/11/02/economy/federal-reserve-meeting-inflation/index.html](https://www.cnn.com/2022/11/02/economy/federal-reserve-meeting-inflation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 10:08:55+00:00

The Federal Reserve is expected to make history yet again on Wednesday, approving a fourth-straight rate hike of three-quarters of a percentage point as part of an aggressive battle to bring down the white-hot inflation that is plaguing the US economy.

## World stocks upbeat, even as Fed gets ready to hike big again
 - [https://biztoc.com/p/ebqfcrbi?ref=rss&rd=1](https://biztoc.com/p/ebqfcrbi?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 10:05:00+00:00

World equity markets rallied on Wednesday and the dollar eased, with investors appearing to look past another likely rise in U.S. interest rates and hoping for a slow down in the pace of... <br /><br /> #tightening

## ‘The Trump playbook’: Republicans hint they will deny election results
 - [https://biztoc.com/p/mxf57zuz?ref=rss&rd=1](https://biztoc.com/p/mxf57zuz?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 10:02:00+00:00

Some candidates are already questioning the integrity of the vote and undermining the credibility of the results <br /><br /> #candidates

## Prominent US academics urge Biden to do more to help anti-government protesters in Iran
 - [https://www.cnn.com/2022/11/02/politics/iran-academics-biden-letter/index.html](https://www.cnn.com/2022/11/02/politics/iran-academics-biden-letter/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 10:00:28+00:00

More than 2,000 academics from universities across the United States have written to President Joe Biden urging him to do more to support the anti-government protesters in Iran, many of whom are coming out of Iranian universities and schools as young Iranians take to the streets and face off against the country's brutal security services.

## CNN Poll: Republicans, backed by enthusiasm and economic concerns, hold a narrow edge ahead of next week's congressional election
 - [https://www.cnn.com/2022/11/02/politics/cnn-poll-gop-congressional-election/index.html](https://www.cnn.com/2022/11/02/politics/cnn-poll-gop-congressional-election/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 10:00:19+00:00

An enthusiastic Republican base and persistent concerns about the state of the economy place the GOP in a strong position with about a week to go in the race for control of the US House of Representatives, according to a new CNN Poll conducted by SSRS.

## CNN Poll: Republicans, backed by enthusiasm and economic concerns, hold a narrow edge ahead of next week's congressional election
 - [https://biztoc.com/p/wtzsj4za?ref=rss&rd=1](https://biztoc.com/p/wtzsj4za?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 10:00:00+00:00

An enthusiastic Republican base and persistent concerns about the state of the economy place the GOP in a strong position with about a week to go in the race for control of the US House of... <br /><br /> #ssrs #election #houseofrepresentatives

## Midterm elections 2022: The tide is turning for Republicans
 - [https://biztoc.com/p/pwv4vvzt?ref=rss&rd=1](https://biztoc.com/p/pwv4vvzt?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 09:53:42+00:00

With less than a week left to go before the midterms, just about everything is breaking in Republicans' favor.
    The big picture: Just a few weeks ago, Republicans seemed to be on the ropes... <br /><br /> #democratic #candidates #midterms #elections

## Christina Applegate discusses her resolve to finish the final season of 'Dead To Me' amid her multiple sclerosis diagnosis
 - [https://biztoc.com/p/5gn9qqnf?ref=rss&rd=1](https://biztoc.com/p/5gn9qqnf?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 09:49:00+00:00

Christina Applegate is opening up about living with multiple sclerosis, and how finishing her acclaimed show "Dead to Me" was important to her. <br /><br /> #deadtome #christinaapplegate

## Migos rapper Takeoff killed by 'stray bullet', record label claims
 - [https://biztoc.com/p/j3trw2g6?ref=rss&rd=1](https://biztoc.com/p/j3trw2g6?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 09:37:50+00:00

The star, who was 28, died on Tuesday night after an altercation at a bowling alley in Houston. <br /><br /> #recordlabel #houston #altercation #takeoff #migos #rapper

## White Suburban Women Swing Toward Backing Republicans for Congress - WSJ
 - [https://biztoc.com/p/drp4wwi3?ref=rss&rd=1](https://biztoc.com/p/drp4wwi3?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 09:30:00+00:00

A new Wall Street Journal poll shows the key group of midterm voters favors the GOP by 15 percentage points. <br /><br /> #voters #whitesuburbanwomenswing

## Ja Rule, Keke Palmer and more stars pay tribute to Takeoff
 - [https://biztoc.com/p/r2ma63nn?ref=rss&rd=1](https://biztoc.com/p/r2ma63nn?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 09:25:00+00:00

Ja Rule, Keke Palmer and more stars pay tribute to fallen artist Takeoff. <br /><br /> #artisttakeoff #kekepalmer #jarule #takeoff #stars

## Nigerian artist Ayobola Kekere-Ekun creates her colorful works from folded paper
 - [https://www.cnn.com/style/article/ayobola-kekere-ekun-quilling-spc-intl/index.html](https://www.cnn.com/style/article/ayobola-kekere-ekun-quilling-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 09:24:48+00:00

Eyes are often said to be windows to the soul. For Nigerian artist Ayobola Kekere-Ekun, eyes are a way of revealing the truth of someone's character. "You can tell a lot from a person's eyes. The eyes offer a mutual vulnerability," she said.

## How to increase the longevity of your wardrobe
 - [https://www.cnn.com/style/article/guide-old-clothes-sept/index.html](https://www.cnn.com/style/article/guide-old-clothes-sept/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 09:24:40+00:00



## World Series Lance McCullers Says He Was Not Tipping Pitches in Game 3
 - [https://biztoc.com/p/2nqtms8i?ref=rss&rd=1](https://biztoc.com/p/2nqtms8i?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 09:18:02+00:00

Houston’s Lance McCullers Jr. set a World Series record by allowing five home runs. The Phillies hinted they were onto something but McCullers said he just pitched poorly. <br /><br /> #lancemccullersjr #houston #pitches #phillies #worldseries

## Halloween crush investigators raid police stations across Seoul
 - [https://www.cnn.com/2022/11/02/asia/seoul-police-station-raid-investigation-intl-hnk/index.html](https://www.cnn.com/2022/11/02/asia/seoul-police-station-raid-investigation-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 09:16:01+00:00

Investigators probing the crowd crush that killed 156 people during Halloween festivities in South Korea raided police stations across Seoul on Wednesday.

## Harris to announce over $13 billion in assistance to help cut energy costs this winter
 - [https://biztoc.com/p/evipmz5k?ref=rss&rd=1](https://biztoc.com/p/evipmz5k?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 09:04:15+00:00

Vice President Kamala Harris on Wednesday will announce new steps the Biden administration is taking to help lower energy costs for Americans this winter. <br /><br /> #harris

## She Was Supposed to Be Unelectable. Now She's the Favorite
 - [https://biztoc.com/p/tne4wh4e?ref=rss&rd=1](https://biztoc.com/p/tne4wh4e?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 09:03:21+00:00

Kari Lake is poised to be the next Arizona governor. Democrats are wondering how that happened. <br /><br /> #arizona #favoritekarilake #karilake

## Experts warn about political violence after Election Day
 - [https://biztoc.com/p/y7nyyw4q?ref=rss&rd=1](https://biztoc.com/p/y7nyyw4q?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 09:00:40+00:00

<br /><br /> #electionday

## Russian Military Leaders Discussed Use of Nuclear Weapons, U.S. Officials Say
 - [https://biztoc.com/p/9j62ty33?ref=rss&rd=1](https://biztoc.com/p/9j62ty33?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 09:00:26+00:00

The conversations alarmed the Biden administration because they showed how frustrated Moscow had become over its battlefield setbacks in Ukraine. <br /><br /> #conversations #russian #ukraine #moscow

## Kanye West Haters Start 'Make Me a Billionaire Instead' GoFundMe Campaigns
 - [https://biztoc.com/p/9ykaxsya?ref=rss&rd=1](https://biztoc.com/p/9ykaxsya?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 09:00:00+00:00

Kanye West has folks trying to help him regain billionaire status via crowdfunding -- but his haters have responded with just as much passion ... and their own  requests. <br /><br /> #haters #kanyewesthatersstart #kanyewest #folks

## The Fed and White House combine for a day that cuts to the heart of Biden's political problem
 - [https://biztoc.com/p/zpdsay4m?ref=rss&rd=1](https://biztoc.com/p/zpdsay4m?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 09:00:00+00:00

Two Washington power centers will on Wednesday lay bare the politically poisonous dynamics of the top economic issue threatening President Joe Biden's congressional majorities with the midterm... <br /><br /> #midtermelections #powercenters

## World Series score: Phillies power past Astros in Game 3 as Bryce Harper, Kyle Schwarber lead home run barrage
 - [https://biztoc.com/p/bpxcvg9j?ref=rss&rd=1](https://biztoc.com/p/bpxcvg9j?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 09:00:00+00:00

The Phillies tied a World Series record as they took a 2-1 lead in the 2022 Fall Classic <br /><br /> #thephillies #fallclassicthephillies #bryceharper #astros #kyleschwarber #worldseries

## Ukraine Air Force says it has no effective defense against type of missiles Iran is allegedly preparing to ship to Russia
 - [https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-11-02-22#h_40ce72859dd3c80505a63eddaa886e03](https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-11-02-22#h_40ce72859dd3c80505a63eddaa886e03)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 08:52:07.755814+00:00

• Video: Russian billionaire speaks out against Putin

## Fight over southern region is ramping up as Ukrainian forces press forward and Russia increases pressure on residents to leave their homes
 - [https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-11-02-22/index.html](https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-11-02-22/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 08:52:07.747375+00:00

• Video: Russian billionaire speaks out against Putin

## Ukraine accuses Russian occupiers of spreading misinformation in Kherson to force civilians to leave
 - [https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-11-02-22/index.html](https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-11-02-22/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 08:52:07.604193+00:00



## Iowa teenagers accused of killing Spanish teacher over bad grade
 - [https://biztoc.com/p/epqhp6dy?ref=rss&rd=1](https://biztoc.com/p/epqhp6dy?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 08:49:54+00:00

Two Iowa high school students allegedly killed their Spanish teacher last year in response to receiving a poor grade. The teenagers will be tried as adults. <br /><br /> #iowa #spanish #teacher #teenagers #highschoolstudents

## Paul Pelosi attack suspect said he was on 'suicide mission': Officials
 - [https://biztoc.com/p/nn7xdfh8?ref=rss&rd=1](https://biztoc.com/p/nn7xdfh8?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 08:46:19+00:00

When asked if he had other plans, the suspect said he also had a list of targets including other politicians and their families, per the prosecution. <br /><br /> #paulpelosi #attacksuspect

## Itaewon crush: Anxious warnings turn into screams of terror in emergency calls
 - [https://biztoc.com/p/wqibb7kg?ref=rss&rd=1](https://biztoc.com/p/wqibb7kg?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 08:36:24+00:00

Calls made to Korean police hours before a fatal crush reveal how the horrifying incident unfolded. <br /><br /> #korean #crush #itaewon

## Live updates: Russia's war in Ukraine
 - [https://biztoc.com/p/pjx3qvep?ref=rss&rd=1](https://biztoc.com/p/pjx3qvep?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 08:33:00+00:00

The battle for the southern region of Kherson is intensifying as Ukrainian forces press forward and Russia increases pressure on residents to leave their homes. Follow live updates here. <br /><br /> #kherson #ukraine #forces #war

## Progressive icons hit the trail
 - [https://biztoc.com/p/25wsht4z?ref=rss&rd=1](https://biztoc.com/p/25wsht4z?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 08:30:00+00:00

On the Hill, liberal luminaries are relentless in pursuit of their priorities. On the midterm stump, they're treading more carefully. <br /><br /> #trail #onthehill

## Xiaomi's latest concept phone has an interchangeable Leica M lens
 - [https://biztoc.com/p/hsqyv252?ref=rss&rd=1](https://biztoc.com/p/hsqyv252?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 08:27:41+00:00

The Xiaomi 12S Ultra Concept Phone can mount any Leica M lens over its second 1-inch sensor.. <br /><br /> #conceptphone #xiaomi

## Former Idaho gubernatorial candidate convicted of killing Colorado girl, 12, who vanished in 1984
 - [https://biztoc.com/p/kuk6m88z?ref=rss&rd=1](https://biztoc.com/p/kuk6m88z?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 08:12:05+00:00

Jurors found Steve Pankey, 71, guilty of felony murder, second-degree kidnapping and false reporting in the disappearance and death of Jonelle Matthews, the office of district attorney Michael... <br /><br /> #stevepankey #idaho #girl #jurors #colorado #disappearance #kidnapping #michaelrourke #jonellematthews

## Two tropical storms expected to become hurricanes
 - [https://biztoc.com/p/5y9bybvc?ref=rss&rd=1](https://biztoc.com/p/5y9bybvc?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 08:09:06+00:00

Tropical storms Martin and Lisa are both forecast to become short-lived hurricanes Wednesday, the National Hurricane Center said, and a third storm could develop by the weekend. <br /><br /> #lisa #hurricanes #nationalhurricanecenter #storms #martin #storm

## North and South Korea exchange missile launches as tensions ratchet up even further
 - [https://biztoc.com/p/eqw4nihn?ref=rss&rd=1](https://biztoc.com/p/eqw4nihn?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 07:54:00+00:00

The dueling launches come as U.S., South Korean and Japanese officials say Pyongyang is apparently preparing to conduct its first nuclear test in years. <br /><br /> #northandsouthkorea #pyongyang #southkorean

## Stanford University reviewing safety after man caught living illegally in dorms
 - [https://www.cnn.com/2022/11/02/us/stanford-university-man-illegally-living-in-dorms/index.html](https://www.cnn.com/2022/11/02/us/stanford-university-man-illegally-living-in-dorms/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 07:51:38+00:00

Stanford University is reviewing its safety procedures after a man was reportedly found illegally living on campus, the university said in a statement Tuesday.

## Stanford University is reviewing its safety procedures after a man was caught living illegally in dorms, school says
 - [https://biztoc.com/p/ikccwwyw?ref=rss&rd=1](https://biztoc.com/p/ikccwwyw?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 07:51:00+00:00

Stanford University is reviewing its safety procedures after a man was reportedly found illegally living on campus, the university said in a statement Tuesday. <br /><br /> #dorms #stanforduniversity #university #campus #school

## Trump news
 - [https://biztoc.com/p/u8vba9kx?ref=rss&rd=1](https://biztoc.com/p/u8vba9kx?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 07:40:00+00:00

Donald Trump says Twitter has become ‘very boring’ since he got banned
    Donald Trump has been granted a temporary stay in his effort to keep the House Ways and Means Committee from gaining... <br /><br /> #johnroberts #stay #supremecourt

## Denmark centre-left bloc wins narrow victory in nail-biting vote
 - [https://biztoc.com/p/7hmwuadt?ref=rss&rd=1](https://biztoc.com/p/7hmwuadt?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 07:30:34+00:00

Social Democratic incumbent PM Mette Frederiksen secures mandate to form a government after a close election. <br /><br /> #election #victory #democratic #mettefrederiksen #denmark

## China Locks Down Area Around Foxconn's 'IPhone City' Plant
 - [https://biztoc.com/p/wk59y48q?ref=rss&rd=1](https://biztoc.com/p/wk59y48q?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 07:27:13+00:00

<br /><br /> #plant #iphonecity #foxconn #chinalocksdownarea

## Tropical Storm Lisa plows through Caribbean as Tropical Storm Martin forms in Atlantic
 - [https://biztoc.com/p/6skrdpyn?ref=rss&rd=1](https://biztoc.com/p/6skrdpyn?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 07:24:47+00:00

Tropical Storm Lisa continued to push toward Central America in the Caribbean while Tropical Storm Martin formed in the Atlantic Ocean, both expected to grow into hurricanes, according to the... <br /><br /> #atlantictropicalstorm #caribbean #atlanticocean #tropicalstormlisa #nationalhurricanecenter #centralamerica #tropicalstormmartin #lisa

## Phillies tie World Series mark with five home runs in Game 3 win over Astros
 - [https://biztoc.com/p/jaua4ie2?ref=rss&rd=1](https://biztoc.com/p/jaua4ie2?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 07:17:18+00:00

The Phillies are two wins from the title after matching a World Series record with five home runs in a 7-0 battering of the Astros on Tuesday in Game 3 <br /><br /> #phillies #worldseries #battering #wins #astros

## Investigators raid Seoul police over the deadly crowd surge
 - [https://biztoc.com/p/7vjxdk83?ref=rss&rd=1](https://biztoc.com/p/7vjxdk83?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 07:13:30+00:00

<br /><br /> #investigators #seoul

## November 1, 2022 Russia-Ukraine news
 - [https://biztoc.com/p/duxqqnx5?ref=rss&rd=1](https://biztoc.com/p/duxqqnx5?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 07:13:00+00:00

Tensions are rising over the future of the Black Sea grain deal, with Russia claiming the corridor is suspended and Ukraine insisting it is committed to its continuation. Follow live updates here. <br /><br /> #newstensions #blacksea #ukraine #corridor

## Five police killed in Ecuador; state of emergency declared
 - [https://biztoc.com/p/rjyxknu7?ref=rss&rd=1](https://biztoc.com/p/rjyxknu7?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 07:05:00+00:00

At least five Ecuadorean police officers were killed on Tuesday in explosive attacks in response to prisoner transfers from overcrowded and violent penitentiaries, prompting President Guillermo... <br /><br /> #provinces #guillermolasso #ecuador #attacks #stateofemergency

## China is caught in a zero-Covid trap of its own making
 - [https://www.cnn.com/collections/intl-0211-china-covid/](https://www.cnn.com/collections/intl-0211-china-covid/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 06:54:54+00:00



## Man pretended to be a Stanford student, squatted in dorms for nearly a year
 - [https://biztoc.com/p/ukuvp9jq?ref=rss&rd=1](https://biztoc.com/p/ukuvp9jq?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 06:54:00+00:00

An Alabama man posed as a Stanford University student, squatting in several campus dorms and associating with the student community for nearly a year, according to university officials and reports. <br /><br /> #student #dorms #stanford #universityofficials

## Denmark's centre-left prime minister secures slender majority
 - [https://biztoc.com/p/ecc57jt4?ref=rss&rd=1](https://biztoc.com/p/ecc57jt4?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 06:49:03+00:00

<br /><br /> #denmark #primeminister

## Five police officers killed in Ecuador; state of emergency declared
 - [https://biztoc.com/p/g94vcqdy?ref=rss&rd=1](https://biztoc.com/p/g94vcqdy?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 06:29:00+00:00

The attacks overnight and early on Tuesday morning, including nine explosions in two cities, were an open declaration of war by gangs, Lasso said in a video address. <br /><br /> #explosions #war #gangs #lasso #declaration #ecuador #attacks #stateofemergency

## North Korean missile lands close to South Korean waters for first time in decades
 - [https://biztoc.com/p/2e73xb9e?ref=rss&rd=1](https://biztoc.com/p/2e73xb9e?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 06:15:00+00:00

North Korea fired at least 10 missiles Wednesday, including one that landed close to South Korean territorial waters for the first time since the 1945 division of the peninsula, South Korean... <br /><br /> #northkorean #southkorean #division #waters #peninsula #missilelands

## Teachers and students who called 911 in Uvalde shooting kept being told to wait
 - [https://biztoc.com/p/j26bxunw?ref=rss&rd=1](https://biztoc.com/p/j26bxunw?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 06:06:31+00:00

<br /><br /> #uvalde #shooting #teachers

## Lance McCullers Jr. disputes he was tipping pitches as Phils mash 5 HRs
 - [https://biztoc.com/p/xre7q5ez?ref=rss&rd=1](https://biztoc.com/p/xre7q5ez?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 06:06:18+00:00

Astros starter Lance McCullers Jr. disputed that he was tipping his pitches Tuesday night as the Phillies mashed a World Series-record-tying five home runs to go up 2-1. <br /><br /> #phillies #starter #worldseries #astros #phils #pitches #lancemccullersjr

## Pro-Kemp Georgia sheriffs furious at Stacey Abrams for 'good ole boy' remarks: 'Vile and disgusting'
 - [https://biztoc.com/p/vxg4rmnk?ref=rss&rd=1](https://biztoc.com/p/vxg4rmnk?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 06:00:46+00:00

Georgia sheriffs supporting Brian Kemp spoke out harshly against Stacey Abrams in interviews with Fox News Digital for suggesting some of them were racists. <br /><br /> #staceyabrams #georgia #racists #sheriffs #foxnewsdigital #briankemp

## Iran sent more than 3,500 drones to Russia for its war against Ukraine: intel dossier
 - [https://biztoc.com/p/atazw5vu?ref=rss&rd=1](https://biztoc.com/p/atazw5vu?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 06:00:05+00:00

Fox News Digital obtained new intelligence from an Iranian opposition group, revealing the increased transfer of Iranian-produced drones to Russia for use in its war against Ukraine. <br /><br /> #war #foxnewsdigital #oppositiongroup #ukraine #iran

## Phillies make history with 5 homers off Astros starter in Game 3 win
 - [https://biztoc.com/p/dxug8qa2?ref=rss&rd=1](https://biztoc.com/p/dxug8qa2?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 06:00:00+00:00

McCullers, pitching in his first World Series game since 2017, became the first pitcher in postseason history to give up five home runs in a game. <br /><br /> #worldseries #phillies #astros #starter #pitcher #mccullers

## 'The worst is behind us': Hong Kong kicks off its finance summit with top global bankers
 - [https://www.cnn.com/2022/11/02/business/hong-kong-finance-summit-john-lee-intl-hnk/index.html](https://www.cnn.com/2022/11/02/business/hong-kong-finance-summit-john-lee-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 05:50:28+00:00

Hong Kong leader John Lee sought to drum up confidence in the city's future as a global financial hub on Wednesday, as he welcomed some of Wall Street's top executives to its biggest international event in years.

## Samsung aims to add S Pen slot to its future Galaxy Z Fold phones - SamMobile
 - [https://biztoc.com/p/yw5uecqe?ref=rss&rd=1](https://biztoc.com/p/yw5uecqe?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 05:12:00+00:00

Samsung is, without a doubt, the undisputed king of foldable smartphones. The Galaxy Z Flip and the Galaxy Z Fold series ... <br /><br /> #samsung #sammobile #galaxyz

## Is Ime Udoka the answer for Nets? What’s next for Brooklyn after sacking Steve Nash?
 - [https://biztoc.com/p/9ujasijy?ref=rss&rd=1](https://biztoc.com/p/9ujasijy?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 05:08:55+00:00

What a day in Brooklyn.
    The Brooklyn Nets and Steve Nash parted ways Tuesday after a 2-5 start to the season, and league sources with direct knowledge of the discussions tell The Athletic’s... <br /><br /> #theathletic #headcoach #playoffs #shamscharania #leaguesources #celtics #seasons #imeudoka #brooklyn #stevenash

## Video investigation: How a night of celebration turn into a disaster
 - [https://www.cnn.com/videos/world/2022/11/02/seoul-itawon-halloween-investigation-hancocks-pkg-ovn-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2022/11/02/seoul-itawon-halloween-investigation-hancocks-pkg-ovn-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 05:05:27+00:00

At least 156 people were killed when Halloween party goers were trapped in a massive crowd surge in Seoul, South Korea. Combing through the social media footage from that night, CNN's Paula Hancocks investigates how the disastrous night unfolded.

## Liz Cheney backs second Democrat, picking Ryan over Vance for Ohio Senate
 - [https://biztoc.com/p/x28qxrkh?ref=rss&rd=1](https://biztoc.com/p/x28qxrkh?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 05:03:00+00:00

Leading anti-Trump Republican has already endorsed Democrat Elissa Slotkin for re-election in Michigan <br /><br /> #vance #michigan #ryan #reelection #elissaslotkin #ohiosenate #antitrump #lizcheney

## Lions slip loose from Sydney zoo enclosure
 - [https://www.cnn.com/2022/11/02/australia/taronga-zoo-escaped-lions-intl-hnk/index.html](https://www.cnn.com/2022/11/02/australia/taronga-zoo-escaped-lions-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 04:58:03+00:00

Five lions managed a short escape from their enclosure at Sydney's Taronga Zoo early on Wednesday, prompting the zoo to sound a "code one" alert and rush guests of its "Roar and Snore" overnight stay program to safety.

## Matthew Perry Jokes About His Substantial Friends Residuals: 'Yesterday I Bought Iowa'
 - [https://biztoc.com/p/drm36dp6?ref=rss&rd=1](https://biztoc.com/p/drm36dp6?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 04:42:23+00:00

"Yeah, they're not bad," the actor said of the checks he's received from his work on the sitcom, in which he played Chandler Bing <br /><br /> #chandlerbing #actor #matthewperry

## College Football Playoff rankings: Top four teams are Tennessee, Ohio State, Georgia, Clemson
 - [https://biztoc.com/p/nr54pds8?ref=rss&rd=1](https://biztoc.com/p/nr54pds8?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 04:31:00+00:00

<br /><br /> #ohiostate #georgia #tennessee #clemson #collegefootball

## Bron Breakker swarmed by NXT Title challengers: WWE NXT, Nov. 1, 2022
 - [https://biztoc.com/p/zkjybqs2?ref=rss&rd=1](https://biztoc.com/p/zkjybqs2?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 04:20:01+00:00

<br /><br /> #challengers #nxttitle #wwenxt #bronbreakker

## Christina Applegate Felt “An Obligation” To Finish Filming ‘Dead To Me’ Amid MS Diagnosis: “We’re Going To Do It On My Terms”
 - [https://biztoc.com/p/wsa6izzs?ref=rss&rd=1](https://biztoc.com/p/wsa6izzs?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 04:19:00+00:00

Christina Applegate was diagnosed with multiple sclerosis during the filming of the third and final season of Dead to Me back in 2021. The Netflix show took a pause for about five months and the st… <br /><br /> #christinaapplegate #netflix #deadtome #filming

## Nets' Kevin Durant 'shocked' by Steve Nash's exit as head coach
 - [https://biztoc.com/p/h6dqzz56?ref=rss&rd=1](https://biztoc.com/p/h6dqzz56?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 04:17:12+00:00

Nets star Kevin Durant said he wasn't consulted before it was announced that Steve Nash was out as head coach but that he knew that "everybody was being evaluated" after a rocky year. <br /><br /> #nets #kevindurant #stevenash #headcoach

## Iranian artist's surreal paintings of women take on a new sense of urgency
 - [https://www.cnn.com/style/article/arghavan-khosravi-paintings-iran-protests/index.html](https://www.cnn.com/style/article/arghavan-khosravi-paintings-iran-protests/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 04:10:41+00:00

For Iranian artist Arghavan Khosravi, depicting hair in her paintings has become charged with emotion. In early October, she posted a video of herself, on Instagram, sweeping her paintbrush across the canvas in fluid strokes to create fine strands. "These days when I'm painting hair, I'm filled with anger and hope. More than ever," she wrote in the caption.

## Major League Baseball has a diversity problem, experts say. This year's World Series is proof
 - [https://www.cnn.com/2022/11/02/us/world-series-mlb-black-players-youth-league-reaj/index.html](https://www.cnn.com/2022/11/02/us/world-series-mlb-black-players-youth-league-reaj/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 04:08:32+00:00

Dario Otero Jr., affectionately known as DJ, admires Jackie Robinson for making history as the first Black American to play Major League Baseball.

## Capitol Police had cameras outside Pelosi home that weren't monitored at break-in: Sources
 - [https://biztoc.com/p/qaxk75qf?ref=rss&rd=1](https://biztoc.com/p/qaxk75qf?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 04:06:18+00:00

The U.S. Capitol Police had cameras outside the home of House Speaker Nancy Pelosi, but they were not monitored, according to three sources familiar with the matter. <br /><br /> #cameras #capitolpolice #nancypelosi

## Biden stays clear of DeSantis criticism during campaign stop in Florida
 - [https://biztoc.com/p/ttcj2x6f?ref=rss&rd=1](https://biztoc.com/p/ttcj2x6f?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 04:05:21+00:00

Biden reserved criticism for GOP Sen. Rick Scott, House Minority Leader Kevin McCarthy, and GOP Sen. Ron Johnson of Wisconsin. <br /><br /> #desantis #wisconsin #rickscott #floridabiden #kevinmccarthy #ronjohnson #campaignstop

## 2 police officers shot in Newark, search continues for gunman
 - [https://biztoc.com/p/u5i2t59w?ref=rss&rd=1](https://biztoc.com/p/u5i2t59w?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 04:03:53+00:00

Both officers were rushed to University Hospital, where they are now recovering. <br /><br /> #newark #universityhospital #gunman

## Canon R6-II hands-on: Faster, more resolution and reduced heating issues
 - [https://biztoc.com/p/q29txjha?ref=rss&rd=1](https://biztoc.com/p/q29txjha?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 04:02:35+00:00

Just two years after the launch of the original EOS R6, Canon has unveiled its successor, the $2,500 EOS R6 Mark II.. <br /><br /> #markii #canon #r6ii

## N Korea fires missile south of maritime border
 - [https://biztoc.com/p/5pc8tjtv?ref=rss&rd=1](https://biztoc.com/p/5pc8tjtv?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 04:01:21+00:00

South Korea has responded to the North's latest test by launching three missiles of its own. <br /><br /> #nkorea #north

## Fed to Hike Big Again and Open Door to Downshift
 - [https://biztoc.com/p/vstfkyrk?ref=rss&rd=1](https://biztoc.com/p/vstfkyrk?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 04:01:00+00:00

<br /><br /> #hikebigagain

## In Brazil and Israel, leaders show Trump there can be political next acts
 - [https://www.cnn.com/2022/11/02/politics/trump-lula-da-silva-netanyahu-second-political-acts/index.html](https://www.cnn.com/2022/11/02/politics/trump-lula-da-silva-netanyahu-second-political-acts/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 04:00:05+00:00

It's the season of political comebacks, and don't think ex-President Donald Trump isn't watching.

## Police failed to catch break in at Pelosi home despite 1800 cameras
 - [https://biztoc.com/p/9ppg2q48?ref=rss&rd=1](https://biztoc.com/p/9ppg2q48?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 03:58:35+00:00

The Capitol police have installed more than 1,800 security cameras to monitor government officials, though their security procedures are unclear <br /><br /> #pelosi #securitycameras #governmentofficials #cameras #capitol

## 2022 World Series: Harper, Schwarber lead Phillies to Game 3 win
 - [https://biztoc.com/p/astqxg34?ref=rss&rd=1](https://biztoc.com/p/astqxg34?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 03:56:15+00:00

The Phillies hit five home runs in Game 3 of the 2022 World Series to take a 2-1 series lead over the Astros. Here are the top plays! <br /><br /> #plays #astros #harper #worldseries #phillies #schwarber

## Federal judge issues restraining order against group monitoring Arizona ballot boxes
 - [https://biztoc.com/p/a6jn32xa?ref=rss&rd=1](https://biztoc.com/p/a6jn32xa?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 03:50:00+00:00

The order prohibits members of Clean Elections USA from carrying weapons or wearing body armor within 250 feet of drop boxes. <br /><br /> #arizona #cleanelectionsusa

## Nets cap chaotic day by blowing late lead to Bulls with 4-point effort from Kyrie Irving
 - [https://biztoc.com/p/5yh9v2w6?ref=rss&rd=1](https://biztoc.com/p/5yh9v2w6?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 03:36:00+00:00

Hours after the dismissal of head coach Steve Nash amid reports that a man suspended for conduct violations would replace him, the Nets blew a late double-digit lead in a 108-99 loss to the... <br /><br /> #chicagobulls #kyrieirving #controversy #dismissal #nets #stevenash

## North Korea fires 10 missiles, South Korea says
 - [https://www.cnn.com/2022/11/01/asia/north-korea-missiles-wednesday-intl-hnk/index.html](https://www.cnn.com/2022/11/01/asia/north-korea-missiles-wednesday-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 03:35:39+00:00

North Korea fired at least 10 missiles from its east and west coasts on Wednesday, South Korea's Ministry of National Defense said.

## Judge Curbs Actions of Election-Monitoring Group in Arizona
 - [https://biztoc.com/p/7qtss8fj?ref=rss&rd=1](https://biztoc.com/p/7qtss8fj?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 03:25:24+00:00

The group may not take photos or videos of voters, openly carry firearms near ballot boxes, or post information about voters online, a federal judge ruled. <br /><br /> #arizona #ballotboxes #firearms #electionmonitoringgroup #voters

## World Series Game 3 score: Phillies power past Astros as Bryce Harper, Kyle Schwarber lead five-homer barrage
 - [https://biztoc.com/p/sygi6mbx?ref=rss&rd=1](https://biztoc.com/p/sygi6mbx?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 03:24:41+00:00

The Phillies hit all five homers off Lance McCullers Jr. as they took a 2-1 lead in the 2022 Fall Classic <br /><br /> #kyleschwarber #lancemccullersjr #bryceharper #worldseries #fallclassicthephillies #astros

## Phillies hit 5 home runs to win Game 3 of the 2022 World Series
 - [https://biztoc.com/p/umzpmbqv?ref=rss&rd=1](https://biztoc.com/p/umzpmbqv?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 03:16:46+00:00

<br /><br /> #phillies #worldseries

## Tropical Storm Martin to Become a Hurricane on Wednesday
 - [https://biztoc.com/p/h83s929q?ref=rss&rd=1](https://biztoc.com/p/h83s929q?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 03:16:25+00:00

Martin became the second named storm to develop in two days, with Tropical Storm Lisa moving west across the western Caribbean. <br /><br /> #tropicalstormmartin #storm #caribbean #hurricane #lisa

## Judge restricts Arizona ballot watchers - POLITICO
 - [https://biztoc.com/p/smucdw3d?ref=rss&rd=1](https://biztoc.com/p/smucdw3d?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 03:15:34+00:00

The temporary restraining order, from U.S. District Court Judge Michael Liburdi, limits what Clean Elections USA can do. <br /><br /> #arizona #usdistrictcourt #elections #michaelliburdi #politico

## Hear robocalls paid for by Arizona and Michigan GOP encouraging voting by mail
 - [https://www.cnn.com/videos/politics/2022/11/02/gop-robocalls-voting-by-mail-arizona-michigan-benson-sot-tapperctn-vpx.cnn](https://www.cnn.com/videos/politics/2022/11/02/gop-robocalls-voting-by-mail-arizona-michigan-benson-sot-tapperctn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 03:13:57+00:00

In an interview with CNN's Jake Tapper, Michigan's Secretary of State Jocelyn Benson calls out Arizona and Michigan's GOP on their "political strategy" to pay for robocalls encouraging voting by mail, despite party members bashing it.

## Why 'Truth in Advertising' laws don't apply to political ads
 - [https://www.cnn.com/videos/politics/2022/11/02/political-ads-lies-truth-in-advertising-laws-dishonest-ad-campaign-anti-lying-rules-tapperctn-vpx.cnn](https://www.cnn.com/videos/politics/2022/11/02/political-ads-lies-truth-in-advertising-laws-dishonest-ad-campaign-anti-lying-rules-tapperctn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 03:11:23+00:00

As races tighten leading up to Election Day, political ads are playing in heavy rotation. CNN's Jake Tapper fact-checks political ads and reveals what he thinks might be "the most dishonest TV campaign ad" yet.

## Takeoff, rapper and Migos member, killed in Houston shooting at 28
 - [https://biztoc.com/p/cb248tzv?ref=rss&rd=1](https://biztoc.com/p/cb248tzv?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 03:11:22+00:00

Rapper Takeoff, one-third of the Grammy-nominated group Migos, was shot and killed in Houston early Tuesday. He was 28.
    Driving the news: Houston police identified Takeoff as the fatal victim... <br /><br /> #bowling #downtown #quavo #rappertakeoff #migos #rapper #houston #victim #shooting #takeoff

## Pokémon Scarlet And Violet Get A Five-Minute Overview Trailer
 - [https://biztoc.com/p/fyezmwhr?ref=rss&rd=1](https://biztoc.com/p/fyezmwhr?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 03:05:00+00:00

Ahead of the arrival of Pokémon Scarlet and Violet on the Nintendo Switch later this month, Nintendo has released a new overview trailer - providing an extensive look at the new region of Paldea.
... <br /><br /> #starterpocketmonsters #nintendoswitch #nintendo #battles #paldea #pocketmonsters #arrival #violet #trailer #overviewtrailerahead

## World Series: Phillies blast 5 homers off Astros' Lance McCullers Jr. led by Bryce Harper, Kyle Schwarber
 - [https://biztoc.com/p/v9kxx2aw?ref=rss&rd=1](https://biztoc.com/p/v9kxx2aw?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 02:57:00+00:00

Delayed one day by rain, the Fall Classic's return to Philadelphia comes in crucial Game 3. <br /><br /> #worldseries #philadelphia #phillies #bryceharper #lancemccullersjr #kyleschwarber #astros #homers

## 'Weird, fake pious crap': Woman defends LGBTQ+ people in debate over library display
 - [https://www.cnn.com/videos/us/2022/11/02/tennessee-woman-defends-library-pride-month-display-lgbtq-orig-jc-jk.cnn](https://www.cnn.com/videos/us/2022/11/02/tennessee-woman-defends-library-pride-month-display-lgbtq-orig-jc-jk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 02:41:25+00:00

A library director in Maury County, Tennessee resigned amid pressure from conservatives after library staff put on a Pride Month display.

## Modern Warfare 2 Multiplayer Review
 - [https://biztoc.com/p/aqmr8iyc?ref=rss&rd=1](https://biztoc.com/p/aqmr8iyc?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 02:28:29+00:00

<br /><br /> #modernwarfare2

## North Korea missile lands off South Korean coast for first time, prompting air raid warnings
 - [https://biztoc.com/p/7p2gf8bx?ref=rss&rd=1](https://biztoc.com/p/7p2gf8bx?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 02:15:00+00:00

A North Korean ballistic missile landed less than 60 kilometres off South Korea's coast on Wednesday, the first time an apparent test had landed near the South's waters, leading to air raid... <br /><br /> #waters #southkorean #south #northkorea

## CFP rankings got Tennessee and LSU right, Alabama wrong, and it doesn't matter
 - [https://biztoc.com/p/tij76i7q?ref=rss&rd=1](https://biztoc.com/p/tij76i7q?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 02:03:55+00:00

Win and you're in. That should be the message for any college football coach whose team is ranked in the top seven of the initial CFP rankings. <br /><br /> #cfp #tennessee #collegefootballcoach #lsu

## Tapper on whether the perception of rising crime matches reality
 - [https://www.cnn.com/videos/politics/2022/11/02/jake-tapper-monologue-crime-midterms-tapperctn-vpx.cnn](https://www.cnn.com/videos/politics/2022/11/02/jake-tapper-monologue-crime-midterms-tapperctn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 02:03:15+00:00

CNN's Jake Tapper looks at how voters feel about the issue of crime ahead of the midterm elections and examines whether the perception of rising crime matches reality.

## First on CNN: 10-year-old trapped with the Uvalde school shooter repeatedly called 911 for help. It took officials 40 minutes to act
 - [https://biztoc.com/p/reuc2h7d?ref=rss&rd=1](https://biztoc.com/p/reuc2h7d?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 02:03:00+00:00

A 10-year-old girl trapped with classmates and the shooter told police exactly what was happening inside Robb Elementary. It still took responders 40 minutes to do something. <br /><br /> #classmates #schoolshooter #robbelementary #girl #shooter #uvalde

## Pennsylvania Supreme Court rules incorrectly dated or undated ballots must be set aside
 - [https://biztoc.com/p/nhbhvp8y?ref=rss&rd=1](https://biztoc.com/p/nhbhvp8y?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 02:02:00+00:00

The Pennsylvania Supreme Court has ordered that any general election ballots that are mailed in undated or incorrectly dated envelopes must be set aside and not counted by election boards. <br /><br /> #envelopes #election #electionboards

## World Series live updates: Phillies extend Game 3 lead with Kyle Schwarber, Rhys Hoskins homers
 - [https://biztoc.com/p/v7qz88w2?ref=rss&rd=1](https://biztoc.com/p/v7qz88w2?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 02:01:00+00:00

<br /><br /> #worldseries #phillies #rhyshoskins #kyleschwarber

## Shaquille O’Neal, Charles Barkley Slam ‘Idiot’ Kyrie Irving’s Antisemitism
 - [https://biztoc.com/p/f678bxij?ref=rss&rd=1](https://biztoc.com/p/f678bxij?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 01:53:14+00:00

“We have to sit up here and answer for what this idiot has done,” said O’Neal. “I stand for equality of all people” <br /><br /> #charlesbarkleyslam #shaquilleoneal #idiot #kyrieirving

## Capitol Police cameras caught break-in at Pelosi home, but no one was watching
 - [https://biztoc.com/p/yckn75ew?ref=rss&rd=1](https://biztoc.com/p/yckn75ew?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 01:51:35+00:00

<br /><br /> #capitolpolice #cameras #breakin #pelosi

## Pennsylvania Supreme Court Says Mail-In Ballots Without Dates Should Not Be Counted
 - [https://biztoc.com/p/2424iark?ref=rss&rd=1](https://biztoc.com/p/2424iark?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 01:51:24+00:00

Republicans had sued to stop election officials from counting noncompliant ballots, which could again become a crucial point of contention in the battleground state. <br /><br /> #battlegroundstate #electionofficials

## CFP Committee explains why Tennessee No. 1 ahead of 'explosive' Ohio State and 'solid' Georgia in initial rankings
 - [https://biztoc.com/p/iwcyx3hz?ref=rss&rd=1](https://biztoc.com/p/iwcyx3hz?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 01:46:28+00:00

KNOXVILLE, Tenn. — Kirby Smart has said his Georgia football team has work to do, and the College Football Playoff selection committee agreed. <br /><br /> #ohiostate #georgia #footballteam #selectioncommittee #cfpcommittee #tennessee #knoxville #kirbysmart #collegefootballplayoff

## 'Like something from a Stephen King novel': Analyst describes Pelosi attack
 - [https://www.cnn.com/videos/politics/2022/11/02/paul-pelosi-david-depape-court-documents-attack-details-john-miller-intv-ac360-vpx.cnn](https://www.cnn.com/videos/politics/2022/11/02/paul-pelosi-david-depape-court-documents-attack-details-john-miller-intv-ac360-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 01:39:09+00:00

CNN Chief Law Enforcement and Intelligence Analyst John Miller describes what court documents say about the interaction between Paul Pelosi and David DePape.

## Suspect in hammer attack on Paul Pelosi pleads not guilty to state charges
 - [https://biztoc.com/p/25i29tep?ref=rss&rd=1](https://biztoc.com/p/25i29tep?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 01:17:00+00:00

The 42-year-old man pleaded not guilty to attempted murder and other charges and was ordered to remain jailed without bond. <br /><br /> #murder #paulpelosi #hammerattack

## ‘Julie & Julia' Author Julie Powell Dead at 49
 - [https://biztoc.com/p/5zrggifi?ref=rss&rd=1](https://biztoc.com/p/5zrggifi?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 01:07:09+00:00

Julie Powell, the food blogger played by Amy Adams in the film “Julie &amp; Julia,” died at age 49 in her New York residence Oct. 26, per The New York Times. According to her husband, Eric Powell,...

## Pennsylvania Supreme Court Orders Election Officials to Disallow Ballots With Missing or Incorrect Dates
 - [https://biztoc.com/p/vafarz3f?ref=rss&rd=1](https://biztoc.com/p/vafarz3f?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 01:06:00+00:00

Mail-in ballots in Pennsylvania with wrong or missing dates won’t be counted, the state’s highest court ruled. The decision could affect thousands of votes in the hotly contested state. <br /><br /> #dates #election #pennsylvania

## See the moment judge dismisses member of Parkland shooter's defense team
 - [https://www.cnn.com/videos/us/2022/11/01/nikolas-cruz-parkland-shooter-sentencing-testimonies-contd-ath-vpx.cnn](https://www.cnn.com/videos/us/2022/11/01/nikolas-cruz-parkland-shooter-sentencing-testimonies-contd-ath-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 00:49:43+00:00

A judge dismissed a member of convicted gunman Nikolas Cruz's defense team during a heated exchange after testimony from victims' families of the 2018 Parkland school shooting.

## 2022 World Series: Astros-Phillies Game 3 top plays, live updates
 - [https://biztoc.com/p/jhueh66k?ref=rss&rd=1](https://biztoc.com/p/jhueh66k?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 00:43:39+00:00

The Houston Astros take on the Philadelphia Phillies in Game 3 of the 2022 World Series on FOX. Here are the top plays! <br /><br /> #philadelphiaphillies #worldseries #plays #houstonastros

## College Football Playoff Rankings: Tennessee, Ohio State, Georgia, Clemson open 1-4 in top 25
 - [https://biztoc.com/p/zhamki4t?ref=rss&rd=1](https://biztoc.com/p/zhamki4t?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 00:42:35+00:00

The first top 25 rankings of the 2022 season have arrived from the CFP Selection Committee <br /><br /> #collegefootball #georgia #cfpselectioncommittee #tennessee #ohiostate #clemson

## Trump Sharpie has now scrawled its way into the Trump Org trial
 - [https://biztoc.com/p/68r2v4s9?ref=rss&rd=1](https://biztoc.com/p/68r2v4s9?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 00:42:27+00:00

In a prosecution breakthrough, the jury in the tax-fraud trial of Donald Trump's business empire has seen the first evidence bearing his signatures. <br /><br /> #prosecutionbreakthrough #donaldtrump #taxfraudtrial #trumporg

## Hold on to the assets that you have: Larry Summers gives advice as recession looms
 - [https://www.cnn.com/videos/business/2022/11/01/recession-us-economy-interest-rate-hikes-federal-reserve-larry-summers-tsr-vpx.cnn](https://www.cnn.com/videos/business/2022/11/01/recession-us-economy-interest-rate-hikes-federal-reserve-larry-summers-tsr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 00:12:43+00:00

Former US Treasury Secretary Larry Summers talks to CNN's Wolf Blitzer about interest rate hikes amid inflation, and how Americans can prepare for a possible recession.

## Takeoff, member of rap group Migos, fatally shot outside private party in Houston, police say
 - [https://biztoc.com/p/i39k6tyf?ref=rss&rd=1](https://biztoc.com/p/i39k6tyf?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 00:09:00+00:00

Takeoff, who was one-third of the platinum-selling rap group Migos, was shot and killed early Tuesday in Houston, Texas, a source close to the group confirmed to CNN. He was 28. <br /><br /> #migos #rapgroup #takeoff #houston

## NFL trade deadline: NFC contenders pounce as Tom Brady, Aaron Rodgers uncharacteristically fade
 - [https://biztoc.com/p/6ckgmp36?ref=rss&rd=1](https://biztoc.com/p/6ckgmp36?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 00:07:00+00:00

The 49ers, Eagles and Vikings all made aggressive moves in an attempt to capitalize on an opportunity that basically never comes along. <br /><br /> #contenders #vikings #nfc #49ers #tombrady #aaronrodgers #eagles #nfl

## Russian billionaire speaks out against Putin
 - [https://www.cnn.com/videos/world/2022/11/01/oleg-tinkov-russian-billionaire-renounces-citizenship-ukraine-war-putin-chance-ebof-vpx.cnn](https://www.cnn.com/videos/world/2022/11/01/oleg-tinkov-russian-billionaire-renounces-citizenship-ukraine-war-putin-chance-ebof-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 00:06:28+00:00

Oleg Tinkov is the latest Russian billionaire to show his opposition to Russian president Vladimir Putin's war in Ukraine. CNN's Matthew Chance reports.

## Morbi bridge collapse: How a tourist spot became a bridge of death
 - [https://biztoc.com/p/fb2mufna?ref=rss&rd=1](https://biztoc.com/p/fb2mufna?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 00:01:14+00:00

One of India's worst disasters for years left 135 people dead - how did it happen? <br /><br /> #touristspot #morbi #disasters #bridgecollapse #bridge

## With Falsehoods About Pelosi Attack, Republicans Mimic Trump
 - [https://biztoc.com/p/yucn778k?ref=rss&rd=1](https://biztoc.com/p/yucn778k?ref=rss&rd=1)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-02 00:01:01+00:00

The former president has showed Republicans that there is no penalty — and possibly a reward — from voters for spreading false claims and insulting political opponents. <br /><br /> #pelosiattack #voters


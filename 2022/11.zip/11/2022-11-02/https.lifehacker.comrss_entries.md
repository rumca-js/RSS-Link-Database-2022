# Source:Lifehacker, URL:https://lifehacker.com/rss, language:en-US

## Here’s How to Snag a 55" TV From Walmart for $188
 - [https://lifehacker.com/here-s-how-to-snag-a-55-tv-from-walmart-for-188-1849732936](https://lifehacker.com/here-s-how-to-snag-a-55-tv-from-walmart-for-188-1849732936)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-02 21:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--hcE6nuEJ--/c_fit,fl_progressive,q_80,w_636/48a6d94968ebebde5800d3b560e91aa9.jpg" /><p>It happens every year: Customers get hyped about an amazing online Black Friday deal only to be let down when the website crashes or their internet is too slow to snag the best first-come, first-served deals. But this year, there’s a workaround on at least one impressive deal on this <a href="https://www.walmart.com/ip/TCL-55-Class-4-Series-4K-UHD-HDR-Smart-Roku-TV-55S41/540310513?irgwc=1&amp;sourceid=imp_QLJQonwt%3AxyNWyJxyiSAh2UGUkDXru0OIzO4z80&amp;veh=aff&amp;wmlspartner=imp_10451&amp;clickid=QLJQonwt%3AxyNWyJxyiSAh2UGUkDXru0OIzO4z80&amp;sharedid=&amp;affiliates_ad_id=567111&amp;campaign_id=9383" rel="noopener noreferrer" target="_blank">55&quot; 4K Smart TV</a> deal from Walmart,…</p><p><a href="https://lifehacker.com/here-s-how-to-snag-a-55-tv-from-walmart-for-188-1849732936">Read more...</a></p>

## Use These Money-Saving DIY Cleaning Product Alternatives
 - [https://lifehacker.com/use-these-money-saving-diy-cleaning-product-alternative-1849734244](https://lifehacker.com/use-these-money-saving-diy-cleaning-product-alternative-1849734244)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-02 21:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--SsPeZBn_--/c_fit,fl_progressive,q_80,w_636/5eeafb71aeca58104c197b49702b4e3b.jpg" /><p>It takes time and effort to keep you home clean, to say nothing of the cost. We’re constantly being bombarded with advertisements for products that claim they are the best on the market and, busy and desperate, we may very well buy them hoping for a time-saving solution to our cleaning woes. But for the most part, you…</p><p><a href="https://lifehacker.com/use-these-money-saving-diy-cleaning-product-alternative-1849734244">Read more...</a></p>

## Now There’s a Wordle for Flags (With Two Ways to Win)
 - [https://lifehacker.com/now-there-s-a-wordle-for-flags-with-two-ways-to-win-1849734199](https://lifehacker.com/now-there-s-a-wordle-for-flags-with-two-ways-to-win-1849734199)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-02 20:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--aNtqMUKx--/c_fit,fl_progressive,q_80,w_636/c6d440b1e573e05e42c5e5a217c3d1c7.png" /><p>If you haven’t had enough of the <a href="https://lifehacker.com/the-10-best-wordle-alternatives-ranked-by-difficulty-1848859009">Wordle-inspired games</a> (I still play <a href="https://lifehacker.com/redactle-is-like-wordle-but-for-a-whole-wikipedia-page-1849648942">Redactle</a> every day) you should know about <a href="https://redactleunlimited.com/flagle" rel="noopener noreferrer" target="_blank">Flagle</a>. No relation to the antifungal medication with a similar name, this is a flag guessing game—with a twist. </p><p><a href="https://lifehacker.com/now-there-s-a-wordle-for-flags-with-two-ways-to-win-1849734199">Read more...</a></p>

## Easy Ways to Make Your Laundry Smell Good (Without Harsh Detergents)
 - [https://lifehacker.com/easy-ways-to-make-your-laundry-smell-good-without-hars-1849733422](https://lifehacker.com/easy-ways-to-make-your-laundry-smell-good-without-hars-1849733422)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-02 20:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--qN8la9mj--/c_fit,fl_progressive,q_80,w_636/fe85a03b6e715c727b61f5766cddced8.jpg" /><p>When you have especially stinky clothes, washing and deodorizing them is the bare minimum you ask of your washing machine. That’s why we’ve shared <a href="https://lifehacker.com/how-to-get-the-stink-out-of-musty-smelling-clothes-1849385890">so many tips over the years</a> on how to go about it the right way. But what about when you just want your clothes to come out smelling extra nice?<br /></p><p><a href="https://lifehacker.com/easy-ways-to-make-your-laundry-smell-good-without-hars-1849733422">Read more...</a></p>

## BeReal Tattles When You Take a Screenshot
 - [https://lifehacker.com/bereal-tattles-when-you-take-a-screenshot-1849733633](https://lifehacker.com/bereal-tattles-when-you-take-a-screenshot-1849733633)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-02 19:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--D7zmu82J--/c_fit,fl_progressive,q_80,w_636/6e7be9b82d9c4a66886594397957dc33.jpg" /><p>Taking a screenshot of someone else’s <a href="https://lifehacker.com/what-is-the-new-social-media-app-bereal-and-do-you-r-1848780094">BeReal</a> <em>appears </em>to be a consequence-free affair. There’s zero feedback from the app, which makes it seem the same as taking a screenshot of someone’s latest Instagram post or a tweet. Unbeknownst to many BeReal users, however, the app tells on you whenever you take a screenshot.…</p><p><a href="https://lifehacker.com/bereal-tattles-when-you-take-a-screenshot-1849733633">Read more...</a></p>

## Boil Your Mashing Potatoes With Garlic and Aromatics
 - [https://lifehacker.com/boil-your-mashing-potatoes-with-garlic-and-aromatics-1849733321](https://lifehacker.com/boil-your-mashing-potatoes-with-garlic-and-aromatics-1849733321)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-02 19:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--qxDB2vyQ--/c_fit,fl_progressive,q_80,w_636/c00eb73a02a7418f36f2d47fb88cc8f4.jpg" /><p>The perfect bowl of mashed potatoes is creamy yet fluffy and well-seasoned throughout, but it’s not enough to add salt and seasonings after, or even during the mashing step. Infusing potatoes with flavor starts at the beginning, at the boiling step. </p><p><a href="https://lifehacker.com/boil-your-mashing-potatoes-with-garlic-and-aromatics-1849733321">Read more...</a></p>

## Add Pine Nuts to Your Meatballs
 - [https://lifehacker.com/add-pine-nuts-to-your-meatballs-1849732961](https://lifehacker.com/add-pine-nuts-to-your-meatballs-1849732961)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-02 18:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--GGcnnHKh--/c_fit,fl_progressive,q_80,w_636/f400196fcfed4c77bd5aedd0af88d5b7.jpg" /><p>I don’t think I’ve met a meatball I didn’t like, but once in a while, one <em>has</em> surprised me. Sometimes I’m smitten by an unusual meat blend, or maybe an unexpected spice. Recently, it was a surprise ingredient that got me: For enhanced richness, nuttiness, and pleasant texture in your meatballs, throw in some toasted…</p><p><a href="https://lifehacker.com/add-pine-nuts-to-your-meatballs-1849732961">Read more...</a></p>

## The Pros (and a Few Cons) of Peer-to-Peer Lending
 - [https://lifehacker.com/the-pros-and-a-few-cons-of-peer-to-peer-lending-1849732753](https://lifehacker.com/the-pros-and-a-few-cons-of-peer-to-peer-lending-1849732753)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-02 18:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--sac1lcJ6--/c_fit,fl_progressive,q_80,w_636/323ca507adf457d94e99b7beefcb24df.jpg" /><p>Everyone has moments in their life when they need a lump sum of money right away—when they don’t have the time to make a savings plan and wait until they’ve accumulated the needed funds. Borrowing money can be either a lengthy process <a href="https://lifehacker.com/the-basic-loan-terms-everyone-needs-to-know-before-borr-1849392188">full of paperwork</a>, delays, and credit checks—or it can be fast and easy, like with…</p><p><a href="https://lifehacker.com/the-pros-and-a-few-cons-of-peer-to-peer-lending-1849732753">Read more...</a></p>

## 'Black Hairy Tongue' Probably Didn't Kill Julie Powell
 - [https://lifehacker.com/black-hairy-tongue-probably-didnt-kill-julie-powell-1849732656](https://lifehacker.com/black-hairy-tongue-probably-didnt-kill-julie-powell-1849732656)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-02 17:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--sMJcYNb3--/c_fit,fl_progressive,q_80,w_636/3bdbe8a374c599bf1df328af2e9ef99f.jpg" /><p>Julie Powell, the author of <em>Julie and Julia</em>, <a href="https://twitter.com/licjulie/status/1585019082167885824" rel="noopener noreferrer" target="_blank">tweeted</a> before <a href="https://www.nytimes.com/2022/11/01/dining/julie-powell-dead.html" rel="noopener noreferrer" target="_blank">her recent death at age 49</a> that she had “something that’s literally Black Hairy Tongue” and that her doctor thought it was “no big deal.” This, of course, spawned rampant speculation that the black hairy tongue <em>was</em>, in fact, a big deal, and possibly related…</p><p><a href="https://lifehacker.com/black-hairy-tongue-probably-didnt-kill-julie-powell-1849732656">Read more...</a></p>

## You've Been Playing 'Super Mario Bros.' Wrong Your Whole Life
 - [https://lifehacker.com/youve-been-playing-super-mario-bros-wrong-your-whole-l-1849732657](https://lifehacker.com/youve-been-playing-super-mario-bros-wrong-your-whole-l-1849732657)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-02 17:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--H4nRUS48--/c_fit,fl_progressive,q_80,w_636/175851822fe28ccc54f01a33cc7411f8.jpg" /><p>The original <em>Super Mario Bros. </em>is a game with <em>stakes</em>. You don’t have the luxury of save states or level passwords. Once you lose all your lives, it’s game over. If you want to play again, you need to start from scratch—on World 1-1, whether you lost your third life on the first level, or on World 8-4. Or so we thought.<br /></p><p><a href="https://lifehacker.com/youve-been-playing-super-mario-bros-wrong-your-whole-l-1849732657">Read more...</a></p>

## What a 7% Mortgage Rate Really Means for Your Monthly Payment
 - [https://lifehacker.com/what-a-7-mortgage-rate-really-means-for-your-monthly-p-1849732713](https://lifehacker.com/what-a-7-mortgage-rate-really-means-for-your-monthly-p-1849732713)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-02 16:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--WADohf1q--/c_fit,fl_progressive,q_80,w_636/cf2b8d92b47981b9c95f3e6adea7e8cf.jpg" /><p>This week the long-term U.S. mortgage rate <a href="https://abcnews.go.com/Business/wireStory/average-long-term-mortgage-rates-jump-week-92199897#:~:text=Mortgage%20buyer%20Freddie%20Mac%20reported,%2Dyear%20mortgage%20averaged%203.14%25." rel="noopener noreferrer" target="_blank">jumped to 7.08%</a>, according to the Federal Home Loan Mortgage Corporation (aka Freddie Mac). This is a 0.14 percentage point increase from a week earlier, making it <a href="https://abcnews.go.com/Business/wireStory/average-long-term-mortgage-rates-jump-week-92199897#:~:text=Mortgage%20buyer%20Freddie%20Mac%20reported,%2Dyear%20mortgage%20averaged%203.14%25." rel="noopener noreferrer" target="_blank">the first time in more than two decades</a> that the mortgage rate has been over 7%. </p><p><a href="https://lifehacker.com/what-a-7-mortgage-rate-really-means-for-your-monthly-p-1849732713">Read more...</a></p>

## You Can Get ‘Saturnalia’ for Free on Your PC Right Now
 - [https://lifehacker.com/you-can-get-saturnalia-for-free-on-your-pc-right-now-1849732584](https://lifehacker.com/you-can-get-saturnalia-for-free-on-your-pc-right-now-1849732584)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-02 16:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--jRIVhEEj--/c_fit,fl_progressive,q_80,w_636/bfd76734e3221aa5cb2f7c896bdca2ab.png" /><p>As you age out of being able to dress up and go knocking on strangers’ doors for free candy, the next best thing is the day after Halloween when CVS sells leftover candy bars for 75% off. The good news is that it’s not just discounted leftover chocolate you can get this year, but a free kick-ass survival…</p><p><a href="https://lifehacker.com/you-can-get-saturnalia-for-free-on-your-pc-right-now-1849732584">Read more...</a></p>

## How to Put Out Every Kind of Kitchen Fire
 - [https://lifehacker.com/how-to-put-out-every-kind-of-kitchen-fire-1849732334](https://lifehacker.com/how-to-put-out-every-kind-of-kitchen-fire-1849732334)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-02 15:39:58+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--toFBE9RZ--/c_fit,fl_progressive,q_80,w_636/0b04338e19d831ac206a126dd16f9f25.jpg" /><p>Cooking accidents are <a href="https://www.statefarm.com/simple-insights/residence/protect-your-home-against-these-common-causes-of-house-fires#:~:text=Cooking%20is%20the%20leading%20cause,of%20civilian%20home%20fire%20deaths." rel="noopener noreferrer" target="_blank">the leading cause of house fires</a> in the United States, so as we move into the season of food-centric holidays and staying in at night where it’s cozy, let’s acquaint ourselves with the most effective ways of putting out various types of kitchen fires. Because not all of them are created equal,…</p><p><a href="https://lifehacker.com/how-to-put-out-every-kind-of-kitchen-fire-1849732334">Read more...</a></p>

## Garlic Confit Deserves a Spot on Your Thanksgiving Table
 - [https://lifehacker.com/garlic-confit-deserves-a-spot-on-your-thanksgiving-tabl-1849731860](https://lifehacker.com/garlic-confit-deserves-a-spot-on-your-thanksgiving-tabl-1849731860)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-02 15:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--S2Nz8BfR--/c_fit,fl_progressive,q_80,w_636/b8cd2b4e30d3241ddb67a74fb4cd2235.jpg" /><p>If you’re hosting Thanksgiving for a large group, you’ll need to think of ways to pack in a lot of flavor without making main dishes unapproachable for picky eaters. Garlic is a popular and versatile savory ingredient, but for the garlic averse, heavily loading the turkey or mashed potatoes with hunks of the pungent…</p><p><a href="https://lifehacker.com/garlic-confit-deserves-a-spot-on-your-thanksgiving-tabl-1849731860">Read more...</a></p>

## How to Translate Foreign Languages Directly From Your iPhone Camera
 - [https://lifehacker.com/how-to-translate-foreign-languages-directly-from-your-i-1849731075](https://lifehacker.com/how-to-translate-foreign-languages-directly-from-your-i-1849731075)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-02 14:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--bJ7lYFoF--/c_fit,fl_progressive,q_80,w_636/f395fde799ce22a6964bbc82a2506fa2.jpg" /><p>Every year, Apple adds a few new features that make third-party apps redundant. It’s so common that there’s a term for it—<a href="https://www.howtogeek.com/297651/what-does-it-mean-when-a-company-sherlocks-an-app/" rel="noopener noreferrer" target="_blank">Sherlocking</a>—that goes back to the early 2000s when Apple added a native search feature that made the Sherlock app useless.<br /></p><p><a href="https://lifehacker.com/how-to-translate-foreign-languages-directly-from-your-i-1849731075">Read more...</a></p>

## You'll Need Your First Colonoscopy Sooner Than You Think
 - [https://lifehacker.com/youll-need-your-first-colonoscopy-sooner-than-you-think-1849730322](https://lifehacker.com/youll-need-your-first-colonoscopy-sooner-than-you-think-1849730322)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-02 14:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--7IGx_vaA--/c_fit,fl_progressive,q_80,w_636/a5eeeec32974db537ed40fca88b5a2c5.jpg" /><p>Colonoscopies are no fun. <a href="https://lifehacker.com/the-secret-to-making-colonoscopy-prep-less-shitty-1848416858" target="_blank">Prepping for one</a> includes a full day of eating nothing but liquid and laxatives, with the goal of emptying everything out of your bowels in under 24 hours. Then, once your guts are completely empty, you’re sedated so that doctors can stick a flexible camera up your rear to take images of your…</p><p><a href="https://lifehacker.com/youll-need-your-first-colonoscopy-sooner-than-you-think-1849730322">Read more...</a></p>

## 11 Real, Amazing Treasure Hunts You Could Do From Home
 - [https://lifehacker.com/11-real-amazing-treasure-hunts-you-could-do-from-home-1849730325](https://lifehacker.com/11-real-amazing-treasure-hunts-you-could-do-from-home-1849730325)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-02 13:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--VdyDseRd--/c_fit,fl_progressive,q_80,w_636/57859863a71fd8ef228ba8f92eaa64e5.jpg" /><p>Traditional treasure-hunting is a huge hassle—you have to buy an ancient map in a scary curio shop, hire a ship captain with a hidden agenda, bribe officials in exotic nations, and who knows what else. I’d rather stay home, personally. Luckily, there are a host of treasures, both large and small, you can find while…</p><p><a href="https://lifehacker.com/11-real-amazing-treasure-hunts-you-could-do-from-home-1849730325">Read more...</a></p>

## For the Best Stuffing, Dry Your Bread Instead of Staling It
 - [https://lifehacker.com/for-the-best-stuffing-dry-your-bread-instead-of-stalin-1849729944](https://lifehacker.com/for-the-best-stuffing-dry-your-bread-instead-of-stalin-1849729944)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-02 13:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--JFmpxjTG--/c_fit,fl_progressive,q_80,w_636/238df0c4f670e5fe9a34b7610625ca5a.jpg" /><p>Whether you call it <a href="https://lifehacker.com/the-difference-between-stuffing-and-dressing-1847999886">stuffing or dressing</a>, the broth-soaked bread dish is a Thanksgiving must-have. Though it’s not advisable to stuff the turkey with anything, it’s commonly agreed upon that “dressing” is always made with cornbread, and “stuffing” is usually made with a white bread of some kind—usually sandwich bread. …</p><p><a href="https://lifehacker.com/for-the-best-stuffing-dry-your-bread-instead-of-stalin-1849729944">Read more...</a></p>


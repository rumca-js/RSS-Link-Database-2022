# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## Meta BANS ALL Children from VR Apps
 - [https://www.youtube.com/watch?v=ZBVQ9SK8Brg](https://www.youtube.com/watch?v=ZBVQ9SK8Brg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-11-02 20:15:25+00:00

Hello and welcome to TUESDAY- i mean WEDNESDAY NEWSDAY! Your number one resource for the entire week's worth of VR news. this week was actually pretty crazy with the amount of news, it was unexpected. From Meta facing some very deep financial issues from the Quest 2's lack of sales, to Mark having to testify before congress again- to Meta banning children under 13 from using applications on the Quest store- plus a ton of other news from Pico, Haptx, PSVR 2 and more! This is a crazy one!


Free admission to MC SUMMIT: 
 https://bit.ly/3yAJYnq
USE CODE: Thrill

My Links:
https://www.twitch.tv/thrilluwu
My discord: 
https://discord.gg/2hCGM9BYez
Patreon link:
https://www.patreon.com/Thrillseeker
OUTRO MUSIC:
https://www.youtube.com/watch?v=u6JwgNQDVfI

TIMESTAMPS:
00:00 Intro
00:44 Meta 
04:24 Rec Room
06:13 Meme Break/PSVR2 
07:26 VRChat finger tracking
08:19 Snapdragon XR2+
09:05 Unreal Engine 5
09:44 Pico
10:47 HaptX
11:16 QOTW
11:50 Outro


# Source:Ryan Reynolds, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg, language:en-US

## Official Spirited Trailer
 - [https://www.youtube.com/watch?v=Hmh6nGYKCEs](https://www.youtube.com/watch?v=Hmh6nGYKCEs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2022-11-02 00:00:00+00:00

Amazing what a year's worth of tap dance classes can do. If only Will and I took them. 

Watch #Spirited in theaters November 11 and streaming on @AppleTV+ November 18.
https://apple.co/spirited


# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Wielkie pieniądze w Eurojackpot. Tyle można wygrać w Polsce
 - [https://wydarzenia.interia.pl/zagranica/news-wielkie-pieniadze-w-eurojackpot-tyle-mozna-wygrac-w-polsce,nId,6385553](https://wydarzenia.interia.pl/zagranica/news-wielkie-pieniadze-w-eurojackpot-tyle-mozna-wygrac-w-polsce,nId,6385553)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2022-11-02 12:03:37+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wielkie-pieniadze-w-eurojackpot-tyle-mozna-wygrac-w-polsce,nId,6385553"><img align="left" alt="Wielkie pieniądze w Eurojackpot. Tyle można wygrać w Polsce" src="https://i.iplsc.com/wielkie-pieniadze-w-eurojackpot-tyle-mozna-wygrac-w-polsce/000DAWTWCSYFA5V0-C321.jpg" /></a>570 milionów złotych – taką sumę można wygrać w piątkowej kumulacji Eurojackpot. Wystarczy trafić siedem liczb. Nie tylko Polacy będą grali o zawrotne pieniądze. W Stanach Zjednoczonych w poniedziałkowym losowaniu Powerball do zdobycia był miliard dolarów, jednak zwycięzca nie padł, dlatego suma wzrosła do 1,2 mld. </p><br clear="all" />


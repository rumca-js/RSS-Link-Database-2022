# Source:CNET, URL:https://www.cnet.com/rss/all/, language:en-US

## 'Stranger Things': Creel House Is for Sale for $1.5 Million     - CNET
 - [https://www.cnet.com/culture/entertainment/stranger-things-creel-house-is-for-sale-for-1-5-million/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/stranger-things-creel-house-is-for-sale-for-1-5-million/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 23:19:00+00:00

It doesn't look anything like the Upside Down house anymore.

## Women's Sports Are Getting More Airtime With Dedicated Network     - CNET
 - [https://www.cnet.com/culture/entertainment/womens-sports-are-getting-more-airtime-with-dedicated-network/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/womens-sports-are-getting-more-airtime-with-dedicated-network/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 23:14:00+00:00

The Women's Sports Network has launched on streaming services.

## Another Uncontrolled Chinese Rocket Is About to Crash Back to Earth     - CNET
 - [https://www.cnet.com/science/space/another-uncontrolled-chinese-rocket-is-about-to-crash-back-to-earth/#ftag=CADf328eec](https://www.cnet.com/science/space/another-uncontrolled-chinese-rocket-is-about-to-crash-back-to-earth/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 23:00:07+00:00

It's currently expected to end up somewhere on the surface of our planet late Friday or Saturday.

## 9 Gadgets Under $50 You'll Want to Snag for Your Holiday Trip     - CNET
 - [https://www.cnet.com/tech/9-gadgets-under-50-youll-want-to-snag-for-your-holiday-trip/#ftag=CADf328eec](https://www.cnet.com/tech/9-gadgets-under-50-youll-want-to-snag-for-your-holiday-trip/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 23:00:03+00:00

Heading out on your holiday vacation? Make sure to pack one of these gadgets under $50.

## Why 'Andor' Is One of the Best Shows of 2022     - CNET
 - [https://www.cnet.com/culture/entertainment/why-andor-is-one-of-the-best-shows-of-2022/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/why-andor-is-one-of-the-best-shows-of-2022/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 22:26:00+00:00

Don't let Star Wars fatigue stop you from watching this incredible show.

## Heidi Klum's Worm Costume Is the Greatest Halloween Outfit of All Time     - CNET
 - [https://www.cnet.com/culture/internet/heidi-klums-worm-costume-is-the-greatest-halloween-outfit-of-all-time/#ftag=CADf328eec](https://www.cnet.com/culture/internet/heidi-klums-worm-costume-is-the-greatest-halloween-outfit-of-all-time/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 22:15:00+00:00

I am in complete shock.

## Google's Prototype AI Tool Can Write a Short Story. But Is It Any Good?     - CNET
 - [https://www.cnet.com/tech/computing/googles-prototype-ai-tool-can-write-a-short-story-but-is-it-any-good/#ftag=CADf328eec](https://www.cnet.com/tech/computing/googles-prototype-ai-tool-can-write-a-short-story-but-is-it-any-good/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 22:08:33+00:00

This week, Google showed off its Wordcraft editor, conceived with the help of more than a dozen published authors.

## Google's Prototype AI Tool Can Write a Short Story. But Is It Any Good?     - CNET
 - [https://www.cnet.com/tech/computing/google-ai-tool-wordcraft-lamda-write-short-story/#ftag=CADf328eec](https://www.cnet.com/tech/computing/google-ai-tool-wordcraft-lamda-write-short-story/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 22:08:00+00:00

Google is sharing short stories crafted by its Wordcraft writing editor and more than a dozen acclaimed authors.

## Best Xbox Deals: Save on Controllers, Headsets, Hard Drives and More     - CNET
 - [https://www.cnet.com/deals/best-xbox-deals/#ftag=CADf328eec](https://www.cnet.com/deals/best-xbox-deals/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 22:00:03+00:00

Where to grab all the Xbox gaming gear you need for less.

## Prime Video: The 29 Absolute Best Movies to Watch     - CNET
 - [https://www.cnet.com/culture/entertainment/prime-video-the-absolute-best-movies-to-watch-in-november/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/prime-video-the-absolute-best-movies-to-watch-in-november/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 21:52:09+00:00

This month, catch The People We Hate at the Wedding, a new raunchy comedy starring Kristen Bell.

## Google Play Android Games Can Now Be Played on Your PC     - CNET
 - [https://www.cnet.com/tech/gaming/google-play-android-games-can-now-be-played-on-your-pc/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/google-play-android-games-can-now-be-played-on-your-pc/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 21:43:03+00:00

A new beta lets gamers use their computers to play certain mobile games.

## Two Batches of Blood Pressure Medicine Have Been Recalled     - CNET
 - [https://www.cnet.com/health/medical/two-batches-of-blood-pressure-medicine-have-been-recalled/#ftag=CADf328eec](https://www.cnet.com/health/medical/two-batches-of-blood-pressure-medicine-have-been-recalled/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 21:20:00+00:00

If the pills in your medicine cabinet are included, reach out to your doctor before you stop taking them. Untreated hypertension can be dangerous.

## National Sandwich Day 2022: Free Sandwiches at Popeyes, McAlister's and More     - CNET
 - [https://www.cnet.com/culture/national-sandwich-day-2022-free-sandwiches-at-popeyes-mcalisters-and-more/#ftag=CADf328eec](https://www.cnet.com/culture/national-sandwich-day-2022-free-sandwiches-at-popeyes-mcalisters-and-more/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 21:15:02+00:00

Here are the restaurants that have sandwich discounts on Nov. 3 and beyond.

## Why Henry Cavill Is Leaving 'The Witcher,' and What He's Up to Next     - CNET
 - [https://www.cnet.com/culture/entertainment/why-henry-cavill-is-leaving-the-witcher-and-what-hes-up-to-next/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/why-henry-cavill-is-leaving-the-witcher-and-what-hes-up-to-next/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 21:08:00+00:00

Cavill won't return to the fantasy series for season 4 on Netflix.

## More People Need to Tune In to This Engrossing Horror Anthology Series     - CNET
 - [https://www.cnet.com/culture/more-people-should-tune-in-to-engrossing-horror-anthology-series-old-gods-of-appalachia/#ftag=CADf328eec](https://www.cnet.com/culture/more-people-should-tune-in-to-engrossing-horror-anthology-series-old-gods-of-appalachia/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 21:06:00+00:00

Filled with protective witches and malevolent spirits, the podcast Old Gods of Appalachia is a gripping must-listen.

## 6 Natural Remedies for an Upset Stomach     - CNET
 - [https://www.cnet.com/health/nutrition/6-natural-remedies-for-an-upset-stomach/#ftag=CADf328eec](https://www.cnet.com/health/nutrition/6-natural-remedies-for-an-upset-stomach/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 20:58:00+00:00

Here are six natural remedies for stomach aches that can help you feel better.

## Mars 'Pimples' Spotted by NASA Aren't What They Seem     - CNET
 - [https://www.cnet.com/science/space/mars-pimples-spotted-by-nasa-arent-what-they-seem/#ftag=CADf328eec](https://www.cnet.com/science/space/mars-pimples-spotted-by-nasa-arent-what-they-seem/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 20:47:00+00:00

There's a smashing origin story behind what looks like a group of raised angry bumps on Mars.

## 'The Good Nurse' on Netflix: Where Is Charles Cullen Now?     - CNET
 - [https://www.cnet.com/culture/entertainment/the-good-nurse-on-netflix-where-is-charles-cullen-now/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-good-nurse-on-netflix-where-is-charles-cullen-now/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 20:36:00+00:00

Here's what to know about the serial killer played by Eddie Redmayne in the true crime drama streaming now.

## Baby Formula Class Action Lawsuit: Do These Companies Owe You Money?     - CNET
 - [https://www.cnet.com/personal-finance/baby-formula-class-action-lawsuit-do-these-companies-owe-you-money/#ftag=CADf328eec](https://www.cnet.com/personal-finance/baby-formula-class-action-lawsuit-do-these-companies-owe-you-money/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 20:26:00+00:00

A major manufacturer of infant formula for big brands such as Target and Walmart is accused of falsely advertising how many servings are in a container.

## Samsung Black Friday Deals Revealed, Here's How to Get Early Access     - CNET
 - [https://www.cnet.com/deals/samsung-black-friday-deals-revealed-heres-how-to-get-early-access/#ftag=CADf328eec](https://www.cnet.com/deals/samsung-black-friday-deals-revealed-heres-how-to-get-early-access/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 20:04:42+00:00

Sign up and get a week's head start on the Black Friday deals.

## Bee With Adorable Dog-Like Face May Be in Danger     - CNET
 - [https://www.cnet.com/science/biology/bee-with-adorable-dog-like-face-may-be-in-danger/#ftag=CADf328eec](https://www.cnet.com/science/biology/bee-with-adorable-dog-like-face-may-be-in-danger/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 19:59:00+00:00

Meet Zephyr, a newly discovered species.

## Nintendo and Casio Are Selling a Super Mario Bros. G-Shock Watch     - CNET
 - [https://www.cnet.com/tech/gaming/nintendo-and-casio-are-selling-a-super-mario-bros-g-shock-watch/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/nintendo-and-casio-are-selling-a-super-mario-bros-g-shock-watch/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 19:59:00+00:00

The $150 price tag makes it a little more affordable than the $25,000 Mario Kart watch from TAG Heuer.

## Apple TV Plus: Every New TV Show Arriving in November     - CNET
 - [https://www.cnet.com/culture/entertainment/apple-tv-plus-tv-shows-to-watch-in-november-now/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/apple-tv-plus-tv-shows-to-watch-in-november-now/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 19:58:17+00:00

Here's a complete list of shows coming in November.

## Is Costco Really Cheaper Than A Regular Grocery Store? We Do the Math     - CNET
 - [https://www.cnet.com/how-to/is-costco-really-cheaper-than-a-regular-grocery-store-we-do-the-math/#ftag=CADf328eec](https://www.cnet.com/how-to/is-costco-really-cheaper-than-a-regular-grocery-store-we-do-the-math/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 19:47:32+00:00

We break down how much you can save buying groceries in bulk from Costco over the course of a year.

## 'Top Gun: Maverick' Still Won't Reveal When It'll Finally Start Streaming     - CNET
 - [https://www.cnet.com/news/top-gun-maverick-still-wont-spill-when-itll-finally-start-streaming/#ftag=CADf328eec](https://www.cnet.com/news/top-gun-maverick-still-wont-spill-when-itll-finally-start-streaming/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 19:47:00+00:00

Even five months after the blockbuster sequel hit theaters, Paramount won't pin down its streaming release date.

## The Absolute Best Sci-Fi TV Shows on Netflix     - CNET
 - [https://www.cnet.com/culture/entertainment/the-absolute-best-netflix-sci-fi-tv-shows-to-check-out-right-now/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-absolute-best-netflix-sci-fi-tv-shows-to-check-out-right-now/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 19:39:12+00:00

These are the best of the sci-fi series on Netflix.

## The Best Movies on Apple TV Plus     - CNET
 - [https://www.cnet.com/culture/entertainment/the-best-movies-to-see-on-apple-tv-plus-right-now/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-best-movies-to-see-on-apple-tv-plus-right-now/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 19:33:26+00:00

Apple TV Plus has an assortment of options, from dramas to music documentaries and animated movies.

## Prime Video: The 34 Absolute Best TV Shows to Watch     - CNET
 - [https://www.cnet.com/culture/entertainment/prime-video-the-34-absolute-best-shows-to-watch-november-2022/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/prime-video-the-34-absolute-best-shows-to-watch-november-2022/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 19:29:24+00:00

This month, catch The English, a Western drama series starring Emily Blunt.

## New Google Assistant Features Bring Kid-Friendly Updates     - CNET
 - [https://www.cnet.com/news/new-google-assistant-features-bring-kid-friendly-updates/#ftag=CADf328eec](https://www.cnet.com/news/new-google-assistant-features-bring-kid-friendly-updates/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 19:24:25+00:00

Parental controls, kids dictionary and kid-friendly voices are coming.

## Henry Cavill Is Leaving 'The Witcher': Here's Why     - CNET
 - [https://www.cnet.com/culture/entertainment/henry-cavill-is-leaving-the-witcher-heres-why/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/henry-cavill-is-leaving-the-witcher-heres-why/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 19:22:00+00:00

Cavill won't return to the show for season 4 on Netflix.

## Bumblebees Like Playing With Toys: See What That Looks Like     - CNET
 - [https://www.cnet.com/science/biology/bumblebees-like-playing-with-toys-see-what-that-looks-like/#ftag=CADf328eec](https://www.cnet.com/science/biology/bumblebees-like-playing-with-toys-see-what-that-looks-like/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 19:18:00+00:00

For the first time, a study has shown insects having fun with little wooden balls. What could this say about their emotional state?

## Where Do I Vote on Election Day 2022? How to Find Your Polling Place     - CNET
 - [https://www.cnet.com/news/politics/where-do-i-vote-on-election-day-2022-how-to-find-your-polling-place/#ftag=CADf328eec](https://www.cnet.com/news/politics/where-do-i-vote-on-election-day-2022-how-to-find-your-polling-place/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 19:15:00+00:00

Your polling location could've changed for a variety of reasons. We'll explain how to find out where you should go to vote this year.

## RSV Explained: Common Symptoms, When to Be Concerned and Available Treatments     - CNET
 - [https://www.cnet.com/health/medical/rsv-explained-common-symptoms-when-to-be-concerned-and-available-treatments/#ftag=CADf328eec](https://www.cnet.com/health/medical/rsv-explained-common-symptoms-when-to-be-concerned-and-available-treatments/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 19:00:11+00:00

Respiratory syncytial virus is known for its effects on children, but it affects adults too -- especially older folks.

## What's Next for Inflation Following the Latest Fed Rate Hike?     - CNET
 - [https://www.cnet.com/personal-finance/banking/whats-next-for-inflation-following-the-latest-fed-rate-hike/#ftag=CADf328eec](https://www.cnet.com/personal-finance/banking/whats-next-for-inflation-following-the-latest-fed-rate-hike/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 19:00:00+00:00

Higher rates and rising prices are hitting American workers with fixed wages the hardest.

## Tumblr to Allow 'Naked Human Form' on the Site -- With Some Rules     - CNET
 - [https://www.cnet.com/news/social-media/tumblr-to-allow-naked-human-form-on-the-site-with-some-rules/#ftag=CADf328eec](https://www.cnet.com/news/social-media/tumblr-to-allow-naked-human-form-on-the-site-with-some-rules/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 18:53:41+00:00

The platform, which once allowed porn, has a new policy around images containing nudity.

## Toyota Trailhunter SEMA Concept Previews Overland-Friendly Production Model     - CNET
 - [https://www.cnet.com/roadshow/news/toyota-trailhunter-concept-sema-2022/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/toyota-trailhunter-concept-sema-2022/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 18:44:42+00:00

Expect to see this name more often going forward.

## World Series 2022 Livestream: How to Watch Phillies vs. Astros Game 4 Today     - CNET
 - [https://www.cnet.com/tech/services-and-software/world-series-2022-livestream-how-to-watch-phillies-vs-astros-game-4-today/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/world-series-2022-livestream-how-to-watch-phillies-vs-astros-game-4-today/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 18:43:00+00:00

The Fall Classic continues in Philadelphia tonight, and you don't need cable to watch.

## Coffee Wars Heat Up as Starbucks and Dunkin' Release 2022 Holiday Cups     - CNET
 - [https://www.cnet.com/culture/starbucks-and-dunkin-both-release-2022-holiday-cups/#ftag=CADf328eec](https://www.cnet.com/culture/starbucks-and-dunkin-both-release-2022-holiday-cups/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 18:42:56+00:00

The real war on Christmas has officially begun.

## 'Avatar: Way of Water' Trailer Dives Into Gorgeous Underwater World     - CNET
 - [https://www.cnet.com/culture/entertainment/avatar-way-of-water-trailer-dives-viewers-into-gorgeous-underwater-world/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/avatar-way-of-water-trailer-dives-viewers-into-gorgeous-underwater-world/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 18:41:00+00:00

The trailer for James Cameron's sequel takes moviegoers back to Pandora and the world of the Na'vi.

## NASA Snaps Portrait of Sun 'Smiling' Down on Us Like a Big Fiery Goof     - CNET
 - [https://www.cnet.com/science/space/nasa-snaps-portrait-of-sun-smiling-down-on-us-like-a-big-fiery-goof/#ftag=CADf328eec](https://www.cnet.com/science/space/nasa-snaps-portrait-of-sun-smiling-down-on-us-like-a-big-fiery-goof/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 18:33:00+00:00

The sun put on a happy face during a week full of solar flares and ejections.

## Shanghai Disneyland Shuts Down Due to COVID With Guests Still Inside     - CNET
 - [https://www.cnet.com/health/medical/shanghai-disneyland-shuts-down-due-to-covid-with-guests-still-inside/#ftag=CADf328eec](https://www.cnet.com/health/medical/shanghai-disneyland-shuts-down-due-to-covid-with-guests-still-inside/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 18:31:00+00:00

All guests tested negative and were permitted to leave the theme park.

## 'World's Fastest Shoes' Promise to Get You Walking as Quickly as You Run     - CNET
 - [https://www.cnet.com/culture/fashion/worlds-fastest-shoes-promise-to-let-you-walk-as-quickly-as-you-run/#ftag=CADf328eec](https://www.cnet.com/culture/fashion/worlds-fastest-shoes-promise-to-let-you-walk-as-quickly-as-you-run/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 18:28:00+00:00

Inventors of the Moonwalkers say you'll get a 250% speed boost.

## Scientist Discovers Bee With Adorable Dog-Like Face     - CNET
 - [https://www.cnet.com/science/biology/scientist-discovers-bee-with-adorable-dog-like-face/#ftag=CADf328eec](https://www.cnet.com/science/biology/scientist-discovers-bee-with-adorable-dog-like-face/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 18:23:00+00:00

And the species may be in danger.

## How to Open An Online Bank Account     - CNET
 - [https://www.cnet.com/personal-finance/banking/how-to-open-online-bank-account/#ftag=CADf328eec](https://www.cnet.com/personal-finance/banking/how-to-open-online-bank-account/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 18:21:00+00:00

It's simple, straightforward and something you can do from anywhere.

## Borrowers Could Get Student Loan Debt Automatically Canceled in 2 Weeks     - CNET
 - [https://www.cnet.com/personal-finance/loans/borrowers-could-get-student-loan-debt-automatically-canceled-in-2-weeks/#ftag=CADf328eec](https://www.cnet.com/personal-finance/loans/borrowers-could-get-student-loan-debt-automatically-canceled-in-2-weeks/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 18:15:06+00:00

Many student loan borrowers with income info on file won't need to apply to have debt discharged.

## 6 Mac Keyboard Shortcuts You're Probably Not Using Enough     - CNET
 - [https://www.cnet.com/tech/computing/6-mac-keyboard-shortcuts-youre-probably-not-using-enough/#ftag=CADf328eec](https://www.cnet.com/tech/computing/6-mac-keyboard-shortcuts-youre-probably-not-using-enough/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 18:15:00+00:00

As a Mac owner, you should know about these underutilized Command keyboard shortcuts.

## Fed Raises Rates by Another 75 Basis Points. Here's What Higher Rates Mean for You     - CNET
 - [https://www.cnet.com/personal-finance/banking/fed-raises-rates-by-another-75-basis-points-heres-what-higher-rates-mean-for-you/#ftag=CADf328eec](https://www.cnet.com/personal-finance/banking/fed-raises-rates-by-another-75-basis-points-heres-what-higher-rates-mean-for-you/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 18:14:00+00:00

This marks the sixth interest rate hike of 2022, the latest move in a cycle to try to curb runaway inflation.

## Hulu: How to Remove Unwanted Shows From Your Keep Watching List     - CNET
 - [https://www.cnet.com/tech/services-and-software/hulu-how-to-remove-unwanted-shows-from-your-keep-watching-list/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/hulu-how-to-remove-unwanted-shows-from-your-keep-watching-list/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 18:06:24+00:00

You don't have to finish every show you start. No one checks.

## Volvo EX90 Electric SUV Teases a Slippery Shape     - CNET
 - [https://www.cnet.com/roadshow/pictures/volvo-ex90-electric-suv-exterior-teasers/#ftag=CADf328eec](https://www.cnet.com/roadshow/pictures/volvo-ex90-electric-suv-exterior-teasers/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 17:54:47+00:00

Its 0.29 drag coefficient should give this large, three-row SUV some decent on-road efficiency.

## Another Spent Chinese Rocket Is Falling Back to Earth and Out of Control     - CNET
 - [https://www.cnet.com/science/space/another-spent-chinese-rocket-is-falling-back-to-earth-and-out-of-control/#ftag=CADf328eec](https://www.cnet.com/science/space/another-spent-chinese-rocket-is-falling-back-to-earth-and-out-of-control/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 17:34:00+00:00

It's currently expected to end up somewhere on the surface of our planet late Friday or Saturday.

## 2022 Taurid Meteor Shower Raining Fireballs in Night Skies This Week     - CNET
 - [https://www.cnet.com/science/space/2022-taurid-meteor-shower-raining-fireballs-in-night-skies-this-week/#ftag=CADf328eec](https://www.cnet.com/science/space/2022-taurid-meteor-shower-raining-fireballs-in-night-skies-this-week/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 17:18:00+00:00

The annual meteor shower is due for a fiery outburst and appears to be delivering already.

## Voting in Person? Not if You Don't Bring These Things With You     - CNET
 - [https://www.cnet.com/news/politics/voting-in-person-not-if-you-dont-bring-these-things-with-you/#ftag=CADf328eec](https://www.cnet.com/news/politics/voting-in-person-not-if-you-dont-bring-these-things-with-you/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 17:15:02+00:00

It depends on where you live, but there may be some additional items you're required to bring to the polls.

## Xiaomi Concept Smartphone Comes With Full-Size Camera Lens     - CNET
 - [https://www.cnet.com/tech/mobile/xiaomi-concept-smartphone-comes-with-full-size-leica-camera-lens/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/xiaomi-concept-smartphone-comes-with-full-size-leica-camera-lens/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 17:11:00+00:00

The Xiaomi 12S Ultra Concept gets paired with a 35mm Leica lens.

## Here's Who Should Think About Buying a Hearing Aid     - CNET
 - [https://www.cnet.com/health/medical/heres-who-should-think-about-buying-a-hearing-aid/#ftag=CADf328eec](https://www.cnet.com/health/medical/heres-who-should-think-about-buying-a-hearing-aid/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 17:00:00+00:00

Learn the benefits of over-the-counter hearing aids and signs you could be a good candidate for picking them up at the store.

## Best Online Checking Accounts for November 2022     - CNET
 - [https://www.cnet.com/personal-finance/banking/best-online-checking-accounts/#ftag=CADf328eec](https://www.cnet.com/personal-finance/banking/best-online-checking-accounts/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 16:49:00+00:00

Many online-only checking accounts offer competitive interest rates, low fees and benefits such as new account bonuses.

## Volkswagen Brings Adventure and Speed to SEMA 2022     - CNET
 - [https://www.cnet.com/roadshow/pictures/volkswagen-2022-sema-concepts/#ftag=CADf328eec](https://www.cnet.com/roadshow/pictures/volkswagen-2022-sema-concepts/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 16:45:06+00:00

Head off-road in a Taos, or blast toward the horizon in a Golf R32, it's your choice.

## Volkswagen Jetta GLI Performance Concept Hustles Into SEMA     - CNET
 - [https://www.cnet.com/roadshow/pictures/volkswagen-jetta-gli-performance-concept-sema-2022/#ftag=CADf328eec](https://www.cnet.com/roadshow/pictures/volkswagen-jetta-gli-performance-concept-sema-2022/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 16:44:41+00:00

Thanks to some under-the-hood modifications, this sedan puts out an impressive amount of power.

## Buy Two Portable SSDs From SanDisk and Save Up to $180     - CNET
 - [https://www.cnet.com/deals/buy-two-portable-ssds-from-sandisk-and-save-up-to-180/#ftag=CADf328eec](https://www.cnet.com/deals/buy-two-portable-ssds-from-sandisk-and-save-up-to-180/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 16:36:05+00:00

These portable drives can fit in your pocket, withstand accidental drops and hold a ton of data, making them perfect travel or work companions.

## 'The Last of Us' Hits HBO Max on Jan. 15     - CNET
 - [https://www.cnet.com/culture/entertainment/the-last-of-us-hits-hbo-max-on-jan-15/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-last-of-us-hits-hbo-max-on-jan-15/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 16:22:00+00:00

The TV adaptation of the incredible postapocalyptic video game is kicking off early next year.

## Here's How You Can Access Apple's Newly Redesigned iCloud     - CNET
 - [https://www.cnet.com/tech/services-and-software/heres-how-you-can-access-apples-newly-redesigned-icloud/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/heres-how-you-can-access-apples-newly-redesigned-icloud/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 16:15:02+00:00

It only takes a click to test out the latest iCloud beta.

## 2023 Genesis GV60 EV Earns IIHS Top Safety Pick Plus     - CNET
 - [https://www.cnet.com/roadshow/news/2023-genesis-gv60-iihs-top-safety-pick-plus/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/2023-genesis-gv60-iihs-top-safety-pick-plus/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 16:12:00+00:00

It now hangs out alongside its platform sibling, the Hyundai Ioniq 5.

## Get Your Home Ready for Winter: 10 Tips     - CNET
 - [https://www.cnet.com/how-to/get-your-home-ready-for-winter-10-tips/#ftag=CADf328eec](https://www.cnet.com/how-to/get-your-home-ready-for-winter-10-tips/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 16:00:23+00:00

Prepare for snow and ice now to stay safe, warm and cozy at home all season long.

## Want to Enhance Your Google Home Experience? Enable These 5 Settings ASAP     - CNET
 - [https://www.cnet.com/how-to/want-to-enhance-your-google-home-experience-enable-these-5-settings-asap/#ftag=CADf328eec](https://www.cnet.com/how-to/want-to-enhance-your-google-home-experience-enable-these-5-settings-asap/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 16:00:19+00:00

You absolutely won't regret changing these features and settings.

## Use These 7 Coping Strategies to Lead a Stress-Free Life     - CNET
 - [https://www.cnet.com/health/mental/use-these-7-coping-strategies-to-lead-a-stress-free-life/#ftag=CADf328eec](https://www.cnet.com/health/mental/use-these-7-coping-strategies-to-lead-a-stress-free-life/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 16:00:00+00:00

We can't prevent stress. But we can manage it properly.

## 'Winnie the Pooh' Horror Movie is Getting a Theatrical Release, Report Says     - CNET
 - [https://www.cnet.com/culture/entertainment/winnie-the-pooh-horror-movie-is-getting-a-theatrical-release/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/winnie-the-pooh-horror-movie-is-getting-a-theatrical-release/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 15:49:05+00:00

Slasher flick Blood and Honey shows the adorable bear getting gory and it's apparently coming to theaters. Nobody tell Disney.

## Comcast, Charter Announce Xumo as Name of Joint Streaming Brand     - CNET
 - [https://www.cnet.com/tech/services-and-software/comcast-charter-announce-xumo-as-name-of-joint-streaming-brand/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/comcast-charter-announce-xumo-as-name-of-joint-streaming-brand/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 15:38:28+00:00

It's a streaming service that may already sound familiar to you.

## Save Up to 48% On Sun Joe Power Tools and Make Winterizing Your Home a Breeze     - CNET
 - [https://www.cnet.com/deals/48-off-sun-joe-power-tools-woot-today/#ftag=CADf328eec](https://www.cnet.com/deals/48-off-sun-joe-power-tools-woot-today/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 15:28:59+00:00

Right now at Woot, you can save big on Sun Joe electric chain saws, power washers and more.

## 2018 Hyundai Santa Fe Sport Recalled for ABS Short Circuits     - CNET
 - [https://www.cnet.com/roadshow/news/2018-hyundai-santa-fe-sport-recall-abs-short-circuits/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/2018-hyundai-santa-fe-sport-recall-abs-short-circuits/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 15:26:08+00:00

The recall covers nearly 45,000 SUVs.

## Snag This 55-Inch Vizio 4K TV for Only $298 (Save $130)     - CNET
 - [https://www.cnet.com/deals/snag-this-55-inch-vizio-4k-tv-for-only-298-save-130/#ftag=CADf328eec](https://www.cnet.com/deals/snag-this-55-inch-vizio-4k-tv-for-only-298-save-130/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 15:25:55+00:00

Upgrading to a 55-inch smart TV with better resolution can be the perfect way to binge your favorite holiday movies (or the big game) this season.

## Save $60 On This Logitech G502 Mouse and Take Your Gaming to the Next Level     - CNET
 - [https://www.cnet.com/deals/save-60-on-this-logitech-g502-mouse-and-take-your-gaming-to-the-next-level/#ftag=CADf328eec](https://www.cnet.com/deals/save-60-on-this-logitech-g502-mouse-and-take-your-gaming-to-the-next-level/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 15:24:55+00:00

Right now at Amazon you can snag this advanced wireless Logitech Lightspeed gaming mouse for just $90.

## Early Black Friday Deal at Columbia Saves You 50% on Select Winter Gear     - CNET
 - [https://www.cnet.com/deals/early-black-friday-deal-at-columbia-saves-you-50-on-select-winter-gear/#ftag=CADf328eec](https://www.cnet.com/deals/early-black-friday-deal-at-columbia-saves-you-50-on-select-winter-gear/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 15:23:00+00:00

Shop the sale that has limited styles every week.

## National Sandwich Day 2022: Where to Get a Free Sandwich and Other Discounts Tomorrow     - CNET
 - [https://www.cnet.com/culture/national-sandwich-day-2022-where-to-get-a-free-sandwich-and-other-discounts-tomorrow/#ftag=CADf328eec](https://www.cnet.com/culture/national-sandwich-day-2022-where-to-get-a-free-sandwich-and-other-discounts-tomorrow/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 15:15:02+00:00

Restaurants like McAlister's, Potbelly, Subway and more have sandwich discounts on Nov. 3 and beyond.

## 'Andor' Release Schedule: Is Episode 9 on Disney Plus?     - CNET
 - [https://www.cnet.com/culture/entertainment/andor-release-schedule-is-episode-9-on-disney-plus/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/andor-release-schedule-is-episode-9-on-disney-plus/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 15:12:33+00:00

The Star Wars show comes to Disney Plus each week until late this month, so let's run through the release dates and times for its three remaining episodes.

## Did You Know Netflix Has a Hidden Menu? Here's How to Unlock It     - CNET
 - [https://www.cnet.com/tech/services-and-software/did-you-know-netflix-has-a-hidden-menu-heres-how-to-unlock-it/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/did-you-know-netflix-has-a-hidden-menu-heres-how-to-unlock-it/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 15:07:22+00:00

Netflix secret codes will totally change the way you stream movies and shows.

## Save up to 30% Off at Raycon With Early Black Friday Deals     - CNET
 - [https://www.cnet.com/deals/save-up-to-30-off-at-raycon-with-early-black-friday-deals/#ftag=CADf328eec](https://www.cnet.com/deals/save-up-to-30-off-at-raycon-with-early-black-friday-deals/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 15:01:00+00:00

Start your holiday shopping early and save big on speakers, headphones and earbuds.

## How to Meditate with Music in 5 Steps     - CNET
 - [https://www.cnet.com/health/mental/how-to-meditate-with-music-in-5-steps/#ftag=CADf328eec](https://www.cnet.com/health/mental/how-to-meditate-with-music-in-5-steps/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 15:00:19+00:00

Learn how to use music as meditation to improve your mental health. Add more music to your life with this guide.

## AnkerMake M5 3DPrinter Review: Faster Prints and a Smarter Camera     - CNET
 - [https://www.cnet.com/tech/computing/ankermake-m5-3dprinter-review-faster-prints-and-a-smarter-camera/#ftag=CADf328eec](https://www.cnet.com/tech/computing/ankermake-m5-3dprinter-review-faster-prints-and-a-smarter-camera/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 15:00:00+00:00

Printing things quickly no longer means printing things poorly. It's game-changing.

## Mint Mobile's Early Access Black Friday Sale Scores You 3 Months of Service for Free     - CNET
 - [https://www.cnet.com/deals/mint-mobiles-early-access-black-friday-sale-scores-you-3-months-of-service-for-free/#ftag=CADf328eec](https://www.cnet.com/deals/mint-mobiles-early-access-black-friday-sale-scores-you-3-months-of-service-for-free/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 14:51:21+00:00

Simply prepay for three months of service on the plan or your choice and Mint Mobile will give you an extra three months of the same plan at no additional cost.

## Costco Shoppers: Here's How Much You Actually Save Compared to A Grocery Store     - CNET
 - [https://www.cnet.com/how-to/costco-shoppers-heres-how-much-you-actually-save-compared-to-a-grocery-store/#ftag=CADf328eec](https://www.cnet.com/how-to/costco-shoppers-heres-how-much-you-actually-save-compared-to-a-grocery-store/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 14:39:55+00:00

We do the math to find out how much money buying in bulk from Costco can save you over the course of a year.

## Bose's Excellent Frames Audio Sunglasses Are $100 Off Again     - CNET
 - [https://www.cnet.com/tech/mobile/boses-excellent-frames-audio-sunglasses-are-100-off-again/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/boses-excellent-frames-audio-sunglasses-are-100-off-again/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 14:25:00+00:00

The entire Bose Frames line, including the Tempo, the best-sounding Bluetooth audio glasses available, have returned to their lowest price ever of $149.

## 7 Best Foods for a Happiness Boost     - CNET
 - [https://www.cnet.com/health/mental/7-best-foods-for-a-happiness-boost/#ftag=CADf328eec](https://www.cnet.com/health/mental/7-best-foods-for-a-happiness-boost/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 14:23:00+00:00

Feeling a little down? Try eating these cheerful snacks for a boost of happiness.

## PlayStation VR2 Will Arrive in February for $550     - CNET
 - [https://www.cnet.com/tech/gaming/playstation-vr2-will-arrive-in-february-for-550/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/playstation-vr2-will-arrive-in-february-for-550/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 14:18:51+00:00

Sony is also releasing a slate of new games for the headset next year.

## Best Airbnb Credit Cards for November 2022     - CNET
 - [https://www.cnet.com/personal-finance/credit-cards/best-airbnb-credit-cards/#ftag=CADf328eec](https://www.cnet.com/personal-finance/credit-cards/best-airbnb-credit-cards/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 14:00:03+00:00

These credit cards offer the best rewards rates and perks for Airbnb stays.

## Snag up to 50% Off at Puma During Its Holiday Savings Sale     - CNET
 - [https://www.cnet.com/deals/snag-up-to-50-off-at-puma-during-its-holiday-savings-sale/#ftag=CADf328eec](https://www.cnet.com/deals/snag-up-to-50-off-at-puma-during-its-holiday-savings-sale/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 13:45:00+00:00

If you're going to buy clothes as a gift, get it somewhere trendy and at a discount.

## 'Avatar: Way of Water' Trailer Sweeps Viewers Into Underwater World     - CNET
 - [https://www.cnet.com/culture/entertainment/avatar-way-of-water-trailer-sweeps-viewers-into-underwater-world/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/avatar-way-of-water-trailer-sweeps-viewers-into-underwater-world/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 13:43:00+00:00

The trailer for James Cameron's sequel takes moviegoers back to Pandora and the world of the Na'vi.

## Snag a Previous-Gen iPad Air for as Low as $349 in Early Black Friday Sale     - CNET
 - [https://www.cnet.com/deals/snag-previous-gen-ipad-air-349-black-friday/#ftag=CADf328eec](https://www.cnet.com/deals/snag-previous-gen-ipad-air-349-black-friday/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 13:23:00+00:00

That saves you up to $120 on one of these lightweight Apple tablets.

## Save up to 41% on These Clever Kitchen Gadgets Right Now at Amazon     - CNET
 - [https://www.cnet.com/deals/save-up-to-41-on-these-clever-kitchen-gadgets-right-now-at-amazon/#ftag=CADf328eec](https://www.cnet.com/deals/save-up-to-41-on-these-clever-kitchen-gadgets-right-now-at-amazon/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 13:07:00+00:00

You can shop discounts on microwave pasta makers, novelty waffle irons and a compact electric griddle, with prices starting at just $14.

## Elgato Facecam Pro Review: A Streamer's 4K Dream     - CNET
 - [https://www.cnet.com/tech/computing/elgato-facecam-pro-review-a-streamers-4k-dream/#ftag=CADf328eec](https://www.cnet.com/tech/computing/elgato-facecam-pro-review-a-streamers-4k-dream/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 13:00:23+00:00

Elgato's 4K 60fps webcam is one of the top of its class, especially if you're a fan of Elgato's streaming-accessory ecosystem.

## Here's How to Eliminate Glare on Your TV     - CNET
 - [https://www.cnet.com/tech/home-entertainment/heres-how-to-eliminate-glare-on-your-tv/#ftag=CADf328eec](https://www.cnet.com/tech/home-entertainment/heres-how-to-eliminate-glare-on-your-tv/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 13:00:07+00:00

Glare from room lights or the sun can make your TV hard to see and hard to enjoy. Here are five tricks to reduce or get rid of it completely.

## Apple TV 4K 2022 Review in Progress: Cheaper Price and New Chip Only Go So Far     - CNET
 - [https://www.cnet.com/tech/home-entertainment/apple-tv-4k-2022-review-in-progress-cheaper-price-new-chip-only-go-so-far/#ftag=CADf328eec](https://www.cnet.com/tech/home-entertainment/apple-tv-4k-2022-review-in-progress-cheaper-price-new-chip-only-go-so-far/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 13:00:00+00:00

The lower $129 price tag is still higher than what Apple's streaming device rivals charge. So the question remains: Who's this for?

## Current Refinance Rates on Nov. 2, 2022: Rate Increases     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/current-refinance-rates-on-nov-2-2022-rate-increases/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/current-refinance-rates-on-nov-2-2022-rate-increases/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 13:00:00+00:00

Refinance rates were mixed, but one key rate climbed higher. See how the Fed's interest rate hikes could affect refinancing your home this year.

## Make Peace and Well-Being a Priority This Holiday Season     - CNET
 - [https://www.cnet.com/health/mental/make-peace-and-well-being-a-priority-this-holiday-season/#ftag=CADf328eec](https://www.cnet.com/health/mental/make-peace-and-well-being-a-priority-this-holiday-season/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 13:00:00+00:00

Whether you're stressed out or just need extra support, Talkspace's online therapy is one of the best gifts you can give yourself and others.

## Mortgage Interest Rates for Nov. 2, 2022: Major Rates Varied     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/mortgage-interest-rates-for-nov-2-2022-major-rates-varied/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/mortgage-interest-rates-for-nov-2-2022-major-rates-varied/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 13:00:00+00:00

Today, one key mortgage rate held steady, while others ticked up. If you're in the market for a mortgage, see how your payments might be affected by inflation.

## What Is Climate Justice and What Role Will the Movement Play at COP27?     - CNET
 - [https://www.cnet.com/news/politics/climate-change-and-the-justice-movement-for-a-greener-future/#ftag=CADf328eec](https://www.cnet.com/news/politics/climate-change-and-the-justice-movement-for-a-greener-future/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 13:00:00+00:00

Here's how and why the climate justice movement is fighting for a greener, fairer, safer and more equitable future.

## Learn the Ins and Outs of Microsoft PowerShell With This $30 Certification Bundle     - CNET
 - [https://www.cnet.com/deals/learn-the-ins-and-outs-of-microsoft-powershell-with-this-30-certification-bundle/#ftag=CADf328eec](https://www.cnet.com/deals/learn-the-ins-and-outs-of-microsoft-powershell-with-this-30-certification-bundle/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 12:55:00+00:00

Learn how to deploy task automation to improve efficiency with this three-course bundle created for system administrators just getting started with PowerShell.

## 9 Hidden iOS 16 Features You Definitely Need to Check Out     - CNET
 - [https://www.cnet.com/tech/services-and-software/9-hidden-ios-16-features-you-definitely-need-to-check-out/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/9-hidden-ios-16-features-you-definitely-need-to-check-out/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 12:15:07+00:00

Password-protected photos and all your saved Wi-Fi network passwords in one place -- to name just a couple.

## What Are Blackouts? Here's What Causes Them and Why They're So Dangerous     - CNET
 - [https://www.cnet.com/how-to/what-are-blackouts-heres-what-causes-them-and-why-theyre-so-dangerous/#ftag=CADf328eec](https://www.cnet.com/how-to/what-are-blackouts-heres-what-causes-them-and-why-theyre-so-dangerous/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 12:00:02+00:00

Learn more about these outages and how to prepare in advance.

## Holoride Hands-On: VR in the Car Is Like a Disney Ride video     - CNET
 - [https://www.cnet.com/videos/holoride-hands-on-vr-in-the-car-is-like-a-disney-ride/#ftag=CADf328eec](https://www.cnet.com/videos/holoride-hands-on-vr-in-the-car-is-like-a-disney-ride/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 12:00:01+00:00

Holoride is now launching VR games to be played in cars, selling its first VR packages to work in Audi vehicles. Bridget Carey took it for a test drive in New York, where the game reacts to drivers' actions in real time to help avoid motion sickness. Is this the future of backseat entertainment?

## Chrome Banishes Photo Format That Could Save Space on Your Phone     - CNET
 - [https://www.cnet.com/tech/computing/chrome-banishes-photo-format-that-could-save-space-on-your-phone/#ftag=CADf328eec](https://www.cnet.com/tech/computing/chrome-banishes-photo-format-that-could-save-space-on-your-phone/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 12:00:00+00:00

Adobe and Facebook like the new JPEG XL standard, but Google has dealt it a severe blow.

## VR in a Car: Holoride Launches Today. I Tested It and Didn't Lose My Lunch     - CNET
 - [https://www.cnet.com/tech/gaming/vr-in-a-car-holoride-launches-today-i-tested-it-and-didnt-lose-my-lunch/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/vr-in-a-car-holoride-launches-today-i-tested-it-and-didnt-lose-my-lunch/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 12:00:00+00:00

The company's VR games react in real time to how the car moves. It works with newer Audi vehicles at launch.

## Buying a New Smartwatch? Ask Yourself These Questions First     - CNET
 - [https://www.cnet.com/tech/mobile/buying-a-new-smartwatch-ask-yourself-these-questions-first/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/buying-a-new-smartwatch-ask-yourself-these-questions-first/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 11:00:45+00:00

Choosing the right smartwatch is all about which type of phone you own, how much you want to spend and what you intend to use it for.

## Acer Swift Edge (SFA16-41) Review: Big Screen OLED Laptop That Weighs Next to Nothing     - CNET
 - [https://www.cnet.com/tech/computing/acer-swift-edge-sfa16-41-review/#ftag=CADf328eec](https://www.cnet.com/tech/computing/acer-swift-edge-sfa16-41-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 11:00:40+00:00

The AMD-powered Swift Edge makes it easy to work anywhere without sacrificing screen size to do it.

## 10 Best Family Board Games for 2022     - CNET
 - [https://www.cnet.com/culture/entertainment/10-best-family-board-games-for-2022/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/10-best-family-board-games-for-2022/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 11:00:30+00:00

These games are perfect for family members young and old.

## Social Security Disability Insurance: Are You Getting Your November Check This Week?     - CNET
 - [https://www.cnet.com/personal-finance/social-security-disability-insurance-are-you-getting-your-november-check-this-week/#ftag=CADf328eec](https://www.cnet.com/personal-finance/social-security-disability-insurance-are-you-getting-your-november-check-this-week/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 11:00:24+00:00

Payments for SSDI recipients are disbursed between four different days each month. Find out why and when to expect your money.

## Arlo Pro 4 Security Camera Review: Our Favorite Outdoor Security Camera     - CNET
 - [https://www.cnet.com/news/arlo-pro-4-review/#ftag=CADf328eec](https://www.cnet.com/news/arlo-pro-4-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 11:00:20+00:00

The Arlo Pro 4 beats competitors like Nest with its solid features and reliable performance. Here's what to know.

## 8 Security Tips to Stop Car Break-Ins     - CNET
 - [https://www.cnet.com/how-to/8-security-tips-to-stop-car-break-ins/#ftag=CADf328eec](https://www.cnet.com/how-to/8-security-tips-to-stop-car-break-ins/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 10:00:03+00:00

It's easy to keep your car safe from theft. We'll tell you how.

## 'Andor' Episode 9 Explained: A Star Wars Escape Plot, a Torturous Sound and a Stalker     - CNET
 - [https://www.cnet.com/culture/entertainment/andor-episode-9-explained-a-star-wars-escape-plot-a-torturous-sound-and-a-stalker/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/andor-episode-9-explained-a-star-wars-escape-plot-a-torturous-sound-and-a-stalker/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 07:01:02+00:00

Recap: The Disney Plus show introduces a fun new form of interrogation.

## Giant SpaceX Falcon Heavy Rocket Launches for First Time in Three Years     - CNET
 - [https://www.cnet.com/science/space/giant-spacex-falcon-heavy-rocket-launches-for-first-time-in-three-years/#ftag=CADf328eec](https://www.cnet.com/science/space/giant-spacex-falcon-heavy-rocket-launches-for-first-time-in-three-years/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 06:24:00+00:00

The powerful rocket returns for a classified mission for the US Space Force.

## SpaceX Giant Falcon Heavy Rocket Launches for First Time in Three Years     - CNET
 - [https://www.cnet.com/science/space/spacex-giant-falcon-heavy-rocket-launches-for-first-time-in-three-years/#ftag=CADf328eec](https://www.cnet.com/science/space/spacex-giant-falcon-heavy-rocket-launches-for-first-time-in-three-years/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 05:03:00+00:00

The powerful rocket returns for a classified mission for the US Space Force.

## Google Welcomes Day of the Dead With Sugar Skulls Doodle     - CNET
 - [https://www.cnet.com/culture/internet/google-welcomes-day-of-the-dead-with-sugar-skulls-doodle/#ftag=CADf328eec](https://www.cnet.com/culture/internet/google-welcomes-day-of-the-dead-with-sugar-skulls-doodle/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 04:55:00+00:00

A key symbol of this ancient holiday is the sugar skull, and Google used real sugar in its creation.

## SpaceX's Giant Falcon Heavy Rocket Launches for First Time in Three Years     - CNET
 - [https://www.cnet.com/science/space/spacexs-giant-falcon-heavy-rocket-launches-for-first-time-in-three-years/#ftag=CADf328eec](https://www.cnet.com/science/space/spacexs-giant-falcon-heavy-rocket-launches-for-first-time-in-three-years/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 02:31:00+00:00

The powerful rocket returns for a classified mission for the US Space Force.

## 'The Stranger' on Netflix: The True Story That Inspired the Grim Thriller     - CNET
 - [https://www.cnet.com/culture/entertainment/the-stranger-on-netflix-the-true-story-that-inspired-the-grim-thriller/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-stranger-on-netflix-the-true-story-that-inspired-the-grim-thriller/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 01:11:00+00:00

A horrific murder case inspired this suspenseful thriller about a complex operation to catch the killer.

## Heidi Klum's Worm Is the Greatest Halloween Costume of All Time     - CNET
 - [https://www.cnet.com/culture/internet/heidi-klums-worm-is-the-greatest-halloween-costume-of-all-time/#ftag=CADf328eec](https://www.cnet.com/culture/internet/heidi-klums-worm-is-the-greatest-halloween-costume-of-all-time/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 00:24:00+00:00

Nothing else compares.

## Ex-Apple Employee Admits Defrauding Tech Giant of $17 Million     - CNET
 - [https://www.cnet.com/tech/ex-apple-employee-admits-defrauding-tech-giant-of-17-million/#ftag=CADf328eec](https://www.cnet.com/tech/ex-apple-employee-admits-defrauding-tech-giant-of-17-million/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 00:23:02+00:00

Former parts buyer engaged in theft, taking kickbacks and inflating invoices, prosecutors say.

## 'Andor' Episode 8 Explained: 'Rogue One' Cameos and a Dystopian Star Wars Hell Prison     - CNET
 - [https://www.cnet.com/culture/entertainment/andor-episode-8-explained-rogue-one-cameos-and-a-dystopian-star-wars-prison/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/andor-episode-8-explained-rogue-one-cameos-and-a-dystopian-star-wars-prison/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-11-02 00:00:03+00:00

Recap: The Disney Plus series gives us a fresh angle on the Empire's long-term cruelty, along with a pair of familiar faces.


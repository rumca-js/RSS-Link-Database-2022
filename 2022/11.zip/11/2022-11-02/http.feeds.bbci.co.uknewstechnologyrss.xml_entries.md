# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Apple store Glasgow workers unionise in UK first
 - [https://www.bbc.co.uk/news/technology-63485697?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-63485697?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-11-02 17:44:52+00:00

The UK's first Apple retail workers union has been formed, following US action.

## Haaland or Halland? Fans asked to spellcheck tweets
 - [https://www.bbc.co.uk/news/technology-63483695?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-63483695?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-11-02 11:30:26+00:00

The director of Visit Halland says the region's hashtag is now filled with photos of the footballer.

## China Covid: iPhone maker Foxconn boosts bonuses after lockdown breakout
 - [https://www.bbc.co.uk/news/business-63481119?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63481119?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-11-02 03:33:28+00:00

Foxconn locked down the world's largest iPhone factory in line with China's zero-Covid policy.

## Questions raised about AI weapons-scanning company
 - [https://www.bbc.co.uk/news/technology-63476769?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-63476769?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-11-02 01:18:26+00:00

BBC News has seen evidence Evolv, which claims to have the "signatures" of all weapons, has limitations.


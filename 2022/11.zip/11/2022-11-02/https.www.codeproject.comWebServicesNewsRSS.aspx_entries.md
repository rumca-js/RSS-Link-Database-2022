# Source:CodeProject, URL:https://www.codeproject.com/WebServices/NewsRSS.aspx, language:en-US

## Exploring the 'almost creepy' AI engine in Visual Studio 2022
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59366](https://www.codeproject.com/script/News/View.aspx?nwid=59366)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-11-02 04:00:00+00:00

Not "that one", the other creepy one

## Legacy database migration: What to know before you start
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59372](https://www.codeproject.com/script/News/View.aspx?nwid=59372)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-11-02 04:00:00+00:00

Why migrate when you can just write a new app on the new database?

## My Great Idea
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59374](https://www.codeproject.com/script/News/View.aspx?nwid=59374)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-11-02 04:00:00+00:00

#include *.h; (Mission accomplished!)

## People return to offices, productivity plunges
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59373](https://www.codeproject.com/script/News/View.aspx?nwid=59373)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-11-02 04:00:00+00:00

I guess people do like to work in their pyjamas

## RIP Google Hangouts, Google’s last, best chance to compete with iMessage
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59368](https://www.codeproject.com/script/News/View.aspx?nwid=59368)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-11-02 04:00:00+00:00

I know - stories about Google cancelling things is almost a "sun came up today" kind of story

## Ransomware is a global problem and getting worse, says US
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59367](https://www.codeproject.com/script/News/View.aspx?nwid=59367)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-11-02 04:00:00+00:00

To solve: put 1 million USD in unmarked bills behind the third bench in the park

## Really?
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59375](https://www.codeproject.com/script/News/View.aspx?nwid=59375)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-11-02 04:00:00+00:00

It's almost like there are a lot of bored developers out there

## Scientists increasingly can’t explain how AI works
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59370](https://www.codeproject.com/script/News/View.aspx?nwid=59370)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-11-02 04:00:00+00:00

It's a system of tubes. Of switch statements.

## Smart windows that can polarize sunlight could offer a low energy alternative to Wi-Fi
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59371](https://www.codeproject.com/script/News/View.aspx?nwid=59371)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-11-02 04:00:00+00:00

"We've got a line in the sky"

## The type system is a programmer's best friend
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59369](https://www.codeproject.com/script/News/View.aspx?nwid=59369)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-11-02 04:00:00+00:00

And only, in some cases


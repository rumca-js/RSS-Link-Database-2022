# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Opolskie. Syn miał zabić swoich rodziców krzesłem. Usłyszał zarzut podwójnego zabójstwa
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29099429,opolskie-syn-mial-zabic-swoich-rodzicow-krzeslem-uslyszal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29099429,opolskie-syn-mial-zabic-swoich-rodzicow-krzeslem-uslyszal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-02 20:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/97/b3/1b/z29045399M,policja---zdjecie-ilustracyjne.jpg" vspace="2" />Zarzut podwójnego zabójstwa usłyszał 31-letni Dawid D., który w poniedziałek zamordował swoich rodziców w Borkowicach - ustalił PAP. Podejrzany miał dokonać zbrodni przy użyciu krzesła. Mężczyzna przyznał się do winy.

## Kępno. Noworodek spadł ze stolika przy odcinaniu pępowiny. Ma uraz twarzoczaszki
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29099143,kepno-noworodek-spadl-ze-stolika-przy-odcinaniu-pepowiny-ma.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29099143,kepno-noworodek-spadl-ze-stolika-przy-odcinaniu-pepowiny-ma.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-02 19:46:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bc/c0/1b/z29099196M,Niemowle--zdjecie-ilustracyjne-.jpg" vspace="2" />Do niebezpiecznej sytuacji doszło w szpitalu w Kępnie (województwo wielkopolskie). Podczas odcinania pępowiny nowo narodzona dziewczynka spadła ze stolika, na który została odłożona przez położne.

## Niedrzwica Duża nie jest już "strefą wolną od LGBT". Pan Kazimierz walczył o to prawie trzy lata
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29098736,niedrzwica-duza-nie-jest-juz-strefa-wolna-od-lgbt-pan-kazimierz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29098736,niedrzwica-duza-nie-jest-juz-strefa-wolna-od-lgbt-pan-kazimierz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-02 17:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c9/c0/1b/z29099209M,Niedrzwica-Duza-nie-jest-juz--strefa-wolna-od-LGBT.jpg" vspace="2" />Radni z Niedrzwicy Dużej (woj. lubelskie) po blisko trzech latach uchylili uchwałę dyskryminującą osoby LGBT+ - w tym pana Kazimierza Strzelca, który długo o to uchylenie walczył. - W naszej gminie mieszka 12 tys. osób, statystycznie 600 z nich to osoby LGBT+. Chcę, żeby się czuły bezpiecznie - podkreśla w rozmowie z "Dziennikiem Wschodnim".

## Zazdrośni Niemcy i stolica brudu. Tak sztuczna inteligencja widzi paski "Wiadomości"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29097679,zazdrosni-niemcy-i-stolica-brudu-tak-sztuczna-inteligencja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29097679,zazdrosni-niemcy-i-stolica-brudu-tak-sztuczna-inteligencja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-02 16:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8f/c0/1b/z29098127M,-Rosnace-zarobki-Polakow-irytuja-Niemcow-.jpg" vspace="2" />Hasła z pasków "Wiadomości" TVP już od kilku lat bawią i uczą, a niejedno zaczęło żyć własnym życiem. Postanowiliśmy sprawdzić, co powstanie, gdy połączymy dwie twórcze siły: paskowych telewizji publicznej i sztuczną inteligencję. Oto obrazy wygenerowane przez AI na podstawie haseł w stylu "Rosnące zarobki irytują Niemców" czy "Opozycja chciała popsuć Polakom święta".

## TikToker z młodzieżówki PiS wygrał w teleturnieju TVP 20 tys. zł. "Nie będę się silił na skromność"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29097477,mlody-sympatyk-pis-z-tiktoka-wygral-w-teleturnieju-tvp-20-tys.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29097477,mlody-sympatyk-pis-z-tiktoka-wygral-w-teleturnieju-tvp-20-tys.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-02 13:43:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/dc/bf/1b/z29097948M,Oskar-z--Okiem-Mlodych--wygral-20-tys--zl-w-teletu.jpg" vspace="2" />Oskar Szafarowicz z kanału "Okiem Młodych" na TikToku, a zarazem członek Forum Młodych PiS, wygrał 20 tys. zł w teleturnieju "Giganci historii", emitowanym antenie TVP Historia. Tematem odcinka była Polska Sasów. Do zwycięstwa odniósł się m.in. poseł KO Michał Szczerba. W odpowiedzi 19-latek zaproponował politykowi "opcję honorowych przeprosin za insynuacje".

## Jarosław Kaczyński szykuje się na wybory jak na wojnę. PiS chce korpusu ochrony wyborów na 60 tys. osób
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29097461,jaroslaw-kaczynski-szykuje-sie-na-wybory-jak-na-wojne-pis-chce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29097461,jaroslaw-kaczynski-szykuje-sie-na-wybory-jak-na-wojne-pis-chce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-02 13:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5a/e9/18/z26122330M,Wybory--zdjecie-ilustracyjne-.jpg" vspace="2" />Korpus ochrony wyborów to nowy pomysł PiS, który został zapoczątkowany przez Jarosława Kaczyńskiego na jednym z objazdowych spotkań po Polsce. Jak się okazuje, w skład korpusu ma być zaangażowanych nawet 60 tysięcy osób.

## "Tęczowy Kościół" nadal działa. Sąd uchylił decyzję MSWiA i ministra sprawiedliwości
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29096917,teczowy-kosciol-nadal-dziala-sad-uchylil-decyzje-mswia-i.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29096917,teczowy-kosciol-nadal-dziala-sad-uchylil-decyzje-mswia-i.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-02 12:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/35/5d/19/z26598965M,Mariusz-Kaminski-i-Zbigniew-Ziobro.jpg" vspace="2" />Wojewódzki Sąd Administracyjny w Warszawie cofnął decyzję ministra spraw wewnętrznych i administracji Mariusza Kamińskiego i ministra sprawiedliwości Zbigniewa Ziobry w sprawie wykreślenia Reformowanego Kościoła Katolickiego z rejestru kościołów i innych związków wyznaniowych - podaje we wtorek "Rzeczpospolita". To prawdopodobnie jedyny kościół chrześcijański w Polsce, który błogosławi parom jednopłciowym.

## Dziennikarz TVN spotyka Macierewicza na cmentarzu. "Ja bym panu nie wrzucił"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29096696,dziennikarz-tvn-spotyka-macierewicza-na-cmentarzu-ja-bym-panu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29096696,dziennikarz-tvn-spotyka-macierewicza-na-cmentarzu-ja-bym-panu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-02 11:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a3/9a/1b/z28944291M,Antoni-Macierewicz-podczas-posiedzenia-Komisji-Obr.jpg" vspace="2" />Dziennikarz TVN24 Tomasz Sianecki kwestował na Starych Powązkach w Warszawie w ramach akcji, której celem jest renowacja i utrzymanie zabytkowych grobów. Jak się okazało, dziennikarz spotkał jednego dnia Antoniego Macierewicza. W "Szkle kontaktowym" Sianecki zdradził, co usłyszał od polityka.

## Płońsk. 32-latek mieszka w kurniku. Ojciec wyrzucił z domu dwóch synów z niepełnosprawnością
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29096310,plonsk-32-latek-mieszka-w-kurniku-ojciec-wyrzucil-z-domu-dwoch.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29096310,plonsk-32-latek-mieszka-w-kurniku-ojciec-wyrzucil-z-domu-dwoch.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-02 10:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e9/bf/1b/z29096681M,32-latek-mieszka-w-Kurniku.jpg" vspace="2" />Od pół roku 32-latek z niepełnosprawnością mieszka w kurniku. Nie ma dostępu do ciepłej wody, prądu i ogrzewania. - Jak ostatnio przymrozek był, to zimnawo było. To i tak dobrze, że sąsiad dał plandekę, bo jak burza przyszła, to zaczęło lecieć. Ciężko jest, ale trzeba sobie jakoś radzić - mówi Dawid Wielechowski reporterom Polsat News.

## Co z edukacją domową? Przemysław Czarnek o "mafiach oświatowych", które "wyłudzają miliony"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29096321,przemyslaw-czarnek-o-mafiach-oswiatowych-sposob-na-biznes.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29096321,przemyslaw-czarnek-o-mafiach-oswiatowych-sposob-na-biznes.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-02 10:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/97/af/1b/z29030807M,Przemyslaw-Czarnek.jpg" vspace="2" />Minister Przemysław Czarnek uważa, że "oświatowe mafie" wykorzystują "luki w przepisach i wyłudzają grube miliony złotych". Chodzi o placówki zajmujące się edukacją domową. Zdaniem ministra edukacji i nauki "system trzeba uszczelnić". Wiele osób zwraca jednak uwagę, że gdyby projekt został przyjęty w obecnym kształcie, mogłoby to oznaczać koniec domowej edukacji.

## Kiedy spadnie śnieg? Pogoda stopniowo zacznie się zmieniać. Oto, co czeka nas w listopadzie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29096190,kiedy-spadnie-snieg-pogoda-stopniowo-zacznie-sie-zmieniac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29096190,kiedy-spadnie-snieg-pogoda-stopniowo-zacznie-sie-zmieniac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-02 09:17:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b5/90/1b/z28903861M,Pierwszy-snieg--zdjecie-ilustracyjne-.jpg" vspace="2" />Kiedy do Polski przyjdzie zima? Zdaje się, że mijające dni były ostatnimi tak ciepłymi w tym roku. Wiele jednak wskazuje na to, że temperatura w Polsce będzie w najbliższym czasie nadal dość wysoka, jak na tę porę roku. Synoptycy zapowiedzieli, kiedy można się spodziewać pierwszego śniegu.

## Pszczółki. Duchowny miał przekląć radnych z ambony. "GW": Chce działkę za bezcen
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29096076,pszczolki-duchowny-mial-przeklac-radnych-z-ambony-gw-chce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29096076,pszczolki-duchowny-mial-przeklac-radnych-z-ambony-gw-chce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-02 09:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ff/94/1a/z27869439M,Ksiadz--zdjecie-ilustracyjne-.jpg" vspace="2" />Proboszcz parafii w Pszczółkach chciał odkupić gminną działkę za bezcen - podaje "Wyborcza", a w ostatnią niedzielę duchowny miał mówić na mszy o "prorosyjskich zapędach" gminnych urzędników oraz "że ich przeklina". Radni uznali, że mogą odsprzedać teren, jednak po cenach rynkowych.

## Kowary. We Wszystkich Świętych awantura na cmentarzu. "Wielka zadyma, jak na meczu"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29095988,kowary-w-dniu-wszystkich-swietych-awantura-na-cmentarzu-wielka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29095988,kowary-w-dniu-wszystkich-swietych-awantura-na-cmentarzu-wielka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-02 08:38:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b2/bf/1b/z29096114M,Cmentarz--zdjecie-ilustracyjne-.jpg" vspace="2" />W dniu Wszystkich Świętych na cmentarzu w Kowarach (woj.dolnośląskie) interweniowała policja. 20 Romów, zgodnie ze swoją tradycją, biesiadowało na grobach bliskich i piło alkohol. Nie jest jasne, jak doszło do awantury, prawdopodobnie jej powodem było to, że Romowie zachowywali się zbyt głośno, a później na zaludnionym cmentarzu sytuacja wymknęła się spod kontroli. Policja zatrzymała trzy osoby.

## Afera "gangu trucicieli". Zatrzymano dwie osoby. Niewykluczone, że do aresztu trafił szef grupy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29096118,afera-gangu-trucicieli-zatrzymano-kolejne-dwie-osoby-niewykluczone.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29096118,afera-gangu-trucicieli-zatrzymano-kolejne-dwie-osoby-niewykluczone.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-02 08:26:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/43/a9/1b/z29006403M,Policyjne-zatrzymanie.jpg" vspace="2" />Kolejne dwie osoby zatrzymane w aferze "gangu trucicieli" - podaje RMF FM. Jak dowiedziała się rozgłośnia, w ręce służb wpadli notariuszka z Sochaczewa, która miała współpracować z grupą wyłudzającą mieszkania od osób starszych, oraz Tomasz G. który miał wyłudzać nieruchomości.

## Błaszczak: Polska wybuduje zaporę na granicy z obwodem kaliningradzkim
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29096064,blaszczak-polska-wybuduje-zapore-na-granicy-z-obwodem-kaliningradzkim.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29096064,blaszczak-polska-wybuduje-zapore-na-granicy-z-obwodem-kaliningradzkim.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-02 07:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/57/82/1b/z28845911M,Pilne.jpg" vspace="2" />Będzie zapora na granicy Polski z Rosją - poinformował szef MON Mariusz Błaszczak. - Już dzisiaj rozpoczną się prace saperów, będące początkiem budowy tymczasowej zapory na granicy z obwodem kaliningradzkim - dodał.

## Rozłam wśród antyszczepionkowców. Justyna Socha nie jest już szefową STOP NOP. "Absurdalne pomówienia"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29095968,rozlam-wsrod-antyszczepionkowcow-justyna-socha-nie-jest-juz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29095968,rozlam-wsrod-antyszczepionkowcow-justyna-socha-nie-jest-juz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-02 07:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d4/06/1a/z27289812M,Justyna-Socha.jpg" vspace="2" />Justyna Socha nie jest już prezeską stowarzyszenia STOP NOP. "W obliczu absurdalnych pomówień wobec mnie od dwóch członków stowarzyszenia, złożyłam rezygnację z funkcji prezesa" - napisała. Tymczasem zarząd organizacji przedstawia inną wersję wydarzeń i informuje, że złożył zawiadomienie do prokuratury ws. pieniędzy, z których Socha miała się nie rozliczyć.

## 10-latek z komornikiem. Przemek ma spłacić długi matki, która się nad nim znęcała
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29095887,10-latek-z-komornikiem-przemek-ma-splacic-dlugi-matki-ktora.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29095887,10-latek-z-komornikiem-przemek-ma-splacic-dlugi-matki-ktora.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-02 06:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/92/85/1b/z28858770M,przemoc-wobec-dzieci---zdjecie-ilustracyjne.jpg" vspace="2" />10-latek z Dolnego Śląska od 2019 roku nie ma kontaktu z matką, która go zaniedbywała i została skazana za znęcanie się nad dzieckiem. Przemek trafił do rodziny zastępczej, a jego matka zadłuża mieszkanie, które chłopiec dostał od babci. Z tego powodu 10-latek ma na głowie komornika.

## Prawie połowa Polaków chce pomagać rosyjskiej opozycji. Najmniej chętni wyborcy PiS [SONDAŻ]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29095909,prawie-polowa-polakow-chce-pomagac-rosyjskiej-opozycji-najmniej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29095909,prawie-polowa-polakow-chce-pomagac-rosyjskiej-opozycji-najmniej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-02 06:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/10/bf/1b/z29095952M,Antyrosyjska-pikieta--zdjecie-ilustracyjne-.jpg" vspace="2" />Niemal połowa Polaków deklaruje, że nasz kraj powinien pomagać rosyjskiej opozycji. Inaczej jednak jest wśród elektoratu obozu władzy - aż 65 proc. z nich jest przeciwna pomaganiu przeciwnikom Władimira Putina.


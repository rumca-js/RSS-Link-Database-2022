# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Trucker Protests - Finally, The TRUTH
 - [https://www.youtube.com/watch?v=5eTbTMRKiyg](https://www.youtube.com/watch?v=5eTbTMRKiyg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-11-03 00:00:00+00:00

As New York City appeals a judge's ruling that could reinstate fired unvaccinated employees a report that the Freedom Convoy protests were peaceful has emerged. It’s OK though, cos if you do still get the vaccine you can get $5 off your groceries. Yay. #trudeau #biden #vaccine

References
https://abc7ny.com/covid-vaccine-nyc-mandate/12376163/
https://eu.lohud.com/story/news/coronavirus/2021/10/14/how-many-health-workers-lost-jobs-due-ny-vaccine-mandate/8449413002/
https://tnc.news/
https://www.wsj.com/articles/justin-trudeau-trucker-emergency-canada-ottowa-emergency-powers-protest-vaccine-mandate-freedom-convoy-11644962166
https://www.wsj.com/articles/justin-trudeaus-liberal-tyranny-canada-truckers-emergency-powers-11645561913
--------------------------------------------------------------------------------------------------------------------------
FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand

Join The Community STAY FREE AF: https://russellbrand.locals.com/

Come to My Festival COMMUNITY - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/

## Russell Brand & Jordan Peterson Have Heated Gender Debate
 - [https://www.youtube.com/watch?v=SHpusaIBQyI](https://www.youtube.com/watch?v=SHpusaIBQyI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-11-02 00:00:00+00:00

I spoke to Professor Jordan Peterson about the reasons for his Twitter ban and his thoughts around the gender debate. #JordanPeterson #gender #debate 

Watch the full conversation
https://russellbrand.locals.com/post/2953178/subcutaneous-with-jordan-peterson-exclusive-live-session  
--------------------------------------------------------------------------------------------------------------------------
FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand

Join The Community STAY FREE AF: https://russellbrand.locals.com/

Come to My Festival COMMUNITY - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/


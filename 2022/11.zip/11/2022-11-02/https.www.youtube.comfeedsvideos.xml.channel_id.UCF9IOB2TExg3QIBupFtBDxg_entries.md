# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Excess deaths continue
 - [https://www.youtube.com/watch?v=bGZJfVR9-wo](https://www.youtube.com/watch?v=bGZJfVR9-wo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-11-02 00:00:00+00:00

Link to free download of John’s 2 textbooks

http://159.69.48.3/

Deaths from cardiovascular disease show a significant excess

Epidemiologist Veena Raleigh, The King’s Fund

https://www.telegraph.co.uk/news/2022/10/29/disastrous-legacy-left-lockdown-non-covid-excess-deaths-overtake/

Food writer dies aged 49

https://www.theguardian.com/books/2022/nov/02/julie-powell-food-writer-and-blogger-behind-julie-julia-dies-aged-49

Cardiac arrest caused by heart arrhythmia

Olivebridge, upstate New York, 26 October, 2022

Survived by her husband, brother and parents

Throughout October

https://www.ons.gov.uk/peoplepopulationandcommunity/birthsdeathsandmarriages/deaths

An average of 1,564 extra deaths per week

Throughout 2020 it was 315

Throughout 2021 it was 1,322

24,440 non covid deaths since May, 2022

More on the proximal causes

https://app.powerbi.com/view?r=eyJrIjoiYmUwNmFhMjYtNGZhYS00NDk2LWFlMTAtOTg0OGNhNmFiNGM0IiwidCI6ImVlNGUxNDk5LTRhMzUtNGIyZS1hZDQ3LTVmM2NmOWRlODY2NiIsImMiOjh9

23 March, 2020 (first UK lockdown)

https://coronavirus.data.gov.uk/details/deaths?areaType=nation&areaName=England

https://www.ons.gov.uk/peoplepopulationandcommunity/birthsdeathsandmarriages/deaths/bulletins/deathsregisteredweeklyinenglandandwalesprovisional/weekending21october2022

Deaths registered, UK, week ending 21 October 2022

13,463

15.7% above the five-year average = 1,822 excess deaths

1,379 in week up to 23 March, 2020

https://www.telegraph.co.uk/news/2022/10/29/disastrous-legacy-left-lockdown-non-covid-excess-deaths-overtake/

All age groups

https://app.powerbi.com/view?r=eyJrIjoiYmUwNmFhMjYtNGZhYS00NDk2LWFlMTAtOTg0OGNhNmFiNGM0IiwidCI6ImVlNGUxNDk5LTRhMzUtNGIyZS1hZDQ3LTVmM2NmOWRlODY2NiIsImMiOjh9

E.g. 0 to 24

Amitava Banerjee, clinical data science, consultant cardiologist, Institute of Health Informatics, University College London

We should never ever have had a pandemic preparedness team that did not consider the indirect and long-term effects. 

We focussed on the direct effects of excess deaths from covid,

but from the beginning it’s likely the indirect effects will lead to more deaths, 

and more morbidity and more economic impacts than Covid deaths itself

What I see is still a focus on the direct effects of Covid

Nobody who is in charge of the NHS, or any of the new health secretaries, are making any noises about it


# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## The iPhone USB-C Law: Explained!
 - [https://www.youtube.com/watch?v=UdgRUCVUts0](https://www.youtube.com/watch?v=UdgRUCVUts0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-11-02 00:00:00+00:00

All opinions in the video are my own. Armchair analyst mode activated.
The port-less iPhone: https://youtu.be/Qfmeb2e_kb4
That shirt! http://shop.MKBHD.com

The actual law: https://data.consilium.europa.eu/doc/document/ST-10713-2022-INIT/x/pdf
Joanna's WSJ Interview: https://youtu.be/m-ugwoEOMvg

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds https://lnk.to/jordynedmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## The most amazing thing about jumping spiders! #shorts
 - [https://www.youtube.com/watch?v=8Dy5qGQguak](https://www.youtube.com/watch?v=8Dy5qGQguak)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2022-11-02 21:39:18+00:00

Another YouTube #shorts from Joe, your favorite science dad! 

References: https://sites.google.com/view/how-jumping-spiders-see/home 

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Facebook
https://www.facebook.com/itsokaytobesmartpbs/


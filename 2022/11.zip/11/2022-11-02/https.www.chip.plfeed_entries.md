# Source:Chip.pl, URL:https://www.chip.pl/feed, language:pl-PL

## Ewolucyjna luka wypełniona. Wystarczyła jedna skamieniałość
 - [https://www.chip.pl/2022/11/ewolucyjna-luka-yuanmoupithecus-xiaoyuan-gibon](https://www.chip.pl/2022/11/ewolucyjna-luka-yuanmoupithecus-xiaoyuan-gibon)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 20:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="975" src="https://konto.chip.pl/wp-content/uploads/2022/11/chiny.jpg" style="margin-bottom: 10px;" width="1300" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/chiny.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Jak dowiadujemy się z publikacji dostępnej na łamach Journal of Human Evolution, rekordowo stara skamieniałość gibona odnaleziona w południowo-zachodnich Chinach wypełniła lukę ewolucyjną w historii małp. Członkowie zespołu badawczego skupili się na rodzinie Hylobatidae obejmującej 20 współcześnie występujących gatunków gibonów, które można spotkać w niemal całej Azji, poczynając od północno-wschodnich Indii a na Indonezji kończąc. [&#8230;]</p>

## iPhone 14 może być naprawdę luksusowym towarem. Nie dość, że drogi, to jeszcze trudno dostępny
 - [https://www.chip.pl/2022/11/iphone-14-chinska-fabryka-apple-czasowo-zamknieta](https://www.chip.pl/2022/11/iphone-14-chinska-fabryka-apple-czasowo-zamknieta)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 18:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="675" src="https://konto.chip.pl/wp-content/uploads/2022/09/Apple-iPhone-14-iPhone-14-Plus-5up-hero-220907.jpg" style="margin-bottom: 10px;" width="1200" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/09/Apple-iPhone-14-iPhone-14-Plus-5up-hero-220907.jpg" style="display: block; margin: 1em auto;" /></p>
<p>W naszej części świata powoli o pandemii zapominamy, ale to nie oznacza, że wszędzie sytuacja jest taka sama. Chiny nadal borykają się z covidowymi problemami, co właśnie najbardziej odczuć może Apple, a w niedalekiej przyszłości pewnie i wszyscy chętni na kupno serii iPhone 14. Apple ma kłopoty — największa na świecie fabryka składająca ich smartfony [&#8230;]</p>

## Fizycy opracowali nowy sposób pomiaru upływu czasu. Kwantowy zegar przyda się do budowy komputerów
 - [https://www.chip.pl/2022/11/fizycy-stworzyli-nowy-sposob-mierzenia-czasu](https://www.chip.pl/2022/11/fizycy-stworzyli-nowy-sposob-mierzenia-czasu)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 18:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1203" src="https://konto.chip.pl/wp-content/uploads/2022/11/time-g5f9cd63e5_1920.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/time-g5f9cd63e5_1920.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Fizycy opracowali nowy sposób pomiaru upływu czasu. Okazuje się, że w skali kwantowej, nie zawsze daje się łatwo odróżnić &#8220;wtedy&#8221; od &#8220;teraz&#8221;. Zespół uczonych ze szwedzkiego Uniwersytetu w Uppsali pod lupę wziął tzw. atomy rydbergowskie. Są to takie atomy, w których przynajmniej jeden elektron został wzbudzony do wysokiego poziomu energetycznego. Nazwę zawdzięczają Johannesowi Rydbergowi, szwedzkiemu [&#8230;]</p>

## Wilk syty i owca cała. Fujifilm X-T5 to istny fanservice dla najwierniejszych użytkowników
 - [https://www.chip.pl/2022/11/fujifilm-x-t5-premiera-cena](https://www.chip.pl/2022/11/fujifilm-x-t5-premiera-cena)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 17:15:00+00:00

<img alt="Fujifilm X-T5" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2022/11/fujifilm-x-t5-premiera-5.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/fujifilm-x-t5-premiera-5.jpg" style="display: block; margin: 1em auto;" /></p>
<p>To największa zmiana w systemie aparatów Fujifilm od lat. Nowy Fujifilm X-T5 wygląda jak fanservice skierowany do najwierniejszych użytkowników i ostateczny argument, by nadal pozostać przy matrycy APS-C. Ok, gdyby ktoś średnio obeznany z tematem spojrzał na obudowę nowego aparatu, pewnie pomyliłby go od razu ze starym aparatem. I jeszcze poprzednim. I jeszcze starszym. Seria [&#8230;]</p>

## W końcu składany Galaxy Note, na jakiego zasługujemy. Samsung schowa rysik S-Pen w obudowie nowych Foldów
 - [https://www.chip.pl/2022/11/samsung-schowa-rysik-s-pen-w-obudowie-nowych-foldow](https://www.chip.pl/2022/11/samsung-schowa-rysik-s-pen-w-obudowie-nowych-foldow)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 17:00:50+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="787" src="https://konto.chip.pl/wp-content/uploads/2022/01/samsung-galaxy-z-fold3-test-34.jpg" style="margin-bottom: 10px;" width="1400" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/01/samsung-galaxy-z-fold3-test-34.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Debiutujący w sierpniu Galaxy Z Fold4, tak jak jego poprzednik, zapewnia obsługę rysika S Pen i choć spodziewano się, że w tym roku producent w końcu zapewni użytkownikom odpowiedni slot na niego — tak się nie stało. Wygląda jednak na to, że w przyszłości firma będzie chciała naprawić swój błąd. Przyszłe modele Galaxy Z Fold [&#8230;]</p>

## Pixel 7 Pro oblał test wytrzymałości. Google nadal nie ma składanego smartfona, ale wyginany już tak
 - [https://www.chip.pl/2022/11/pixel-7-pro-test-wytrzymalosci](https://www.chip.pl/2022/11/pixel-7-pro-test-wytrzymalosci)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 16:30:18+00:00

<img alt="Pixel 7 Pro dopiero zadebiutował, a już sprawia problemy. Powtórka z rozrywki?" class="attachment-full size-full wp-post-image" height="699" src="https://konto.chip.pl/wp-content/uploads/2022/10/pixel-7-pro-premiera-1.jpg" style="margin-bottom: 10px;" width="1200" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/10/pixel-7-pro-premiera-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>W tegorocznej serii Pixel 7 Google nadal kontynuowało design przyjęty w ubiegłorocznych Pixelach 6. Dokonano jednak kilku znaczących ulepszeń konstrukcyjnych, które rzekomo miały przełożyć się na większą trwałość urządzenia. Czy tak jest w rzeczywistości? Znany z torturowania smartfonów JerryRigEverything postanowił to sprawdzić. Pixel 7 Pro w teście wytrzymałości &#8211; jak sobie radzi nowy flagowiec Google? [&#8230;]</p>

## Huawei Pocket S pokazuje, że składany smartfon nie musi kosztować majątku
 - [https://www.chip.pl/2022/11/huawei-pocket-s-premiera-specyfikacja](https://www.chip.pl/2022/11/huawei-pocket-s-premiera-specyfikacja)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 16:01:10+00:00

<img alt="Huawei Pocket S pokazuje, że składany smartfon nie musi kosztować majątku" class="attachment-full size-full wp-post-image" height="594" src="https://konto.chip.pl/wp-content/uploads/2022/11/huawei-pocket-s-premiera-7.jpg" style="margin-bottom: 10px;" width="1191" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/huawei-pocket-s-premiera-7.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Zgodnie z zapowiedzią Huawei przedstawił dzisiaj swój drugi składany smartfon z klapką. Na Temat Huawei Pocket S mówiło się już od jakiegoś czasu, więc na okrojoną specyfikację P50 Pocket byliśmy przygotowani, a mimo to zostaliśmy naprawdę przyjemnie zaskoczeni. Cena mocno poleciała w dół, ale zmian nie jest znowu aż tak dużo. Miał być Huawei P50 [&#8230;]</p>

## Budynki zeroemisyjne, czyli jakie? Sprawdź, jakie zmiany szykuje Unia Europejska
 - [https://www.chip.pl/2022/11/budynki-zeroemisyjne-czyli-jakie-sprawdz](https://www.chip.pl/2022/11/budynki-zeroemisyjne-czyli-jakie-sprawdz)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 16:00:00+00:00

<img alt="Sama fotowoltaika nie wystarczy. Czym jest zeroemisyjny budynek?" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2022/11/solar-panels-ga91d48b10_1920.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/solar-panels-ga91d48b10_1920.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Nowe budownictwo o zerowej emisyjności od 2030 roku stanie się standardem na terenie unijnej wspólnoty. Zadecydowała o tym Rada Europejska, osiągając porozumienie w zakresie dyrektywy dotyczącej charakterystyki energetycznej budynków. Istniejące już nieruchomości mają zostać przekształcone w zeroemisyjne do 2050 roku. Ale czym tak naprawdę są budynki zeroemisyjne? Czy to oznacza, że Polacy będą musieli przebudować [&#8230;]</p>

## Test płyty głównej Z790 Aorus Elite AX
 - [https://www.chip.pl/2022/11/z790-aorus-elite-ax-test-recenzja-opinia](https://www.chip.pl/2022/11/z790-aorus-elite-ax-test-recenzja-opinia)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 15:30:00+00:00

<img alt="test Z790 Aorus Elite AX , recenzja Z790 Aorus Elite AX , opinia Z790 Aorus Elite AX" class="attachment-full size-full wp-post-image" height="889" src="https://konto.chip.pl/wp-content/uploads/2022/10/Z790-Aorus-Elite-AX-4.jpg" style="margin-bottom: 10px;" width="1185" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/10/Z790-Aorus-Elite-AX-4.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Z790 Aorus Elite AX to płyta główna obsługująca pamięci DDR5 i przeznaczona dla najnowszych procesorów Intela. Czy poradzi sobie z i9-13900K? Co otrzymujemy wraz z Z790 Aorus Elite AX? Aorus dołącza do płyty tylko podstawowe dodatki. Otrzymujemy więc instrukcję, antenę WIFi, G Connector i dwa kable SATA. Antena jest na kablu, więc możecie ją postawić [&#8230;]</p>

## Recykling paneli słonecznych coraz bliżej. Rozwiązanie inżynierów z Gdańska trafia na fabryczne taśmy
 - [https://www.chip.pl/2022/11/recykling-paneli-slonecznych-politechnika-gdanska](https://www.chip.pl/2022/11/recykling-paneli-slonecznych-politechnika-gdanska)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 14:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1440" src="https://konto.chip.pl/wp-content/uploads/2022/11/architecture-3379146_1920.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/architecture-3379146_1920.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Obfitość instalacji fotowoltaicznych w polskim krajobrazie sprawia, że coraz większym problemem zaczyna być kwestia ich recyklingu po upływie terminu używalności. Nadal nie wypracowano jednolitej metody i praktyki, co robić z ogniwami, kiedy przestaną być wydajne. Naukowcy z Politechniki Gdańskiej opracowali metodę odzysku krzemu z ogniw fotowoltaicznych, która została opatentowana. Odzyskiwanie krzemu z ogniw fotowoltaicznych pozwoli [&#8230;]</p>

## Do Xiaomi 12S Ultra podłączysz profesjonalne obiektywy warte grube tysiące. Ten koncept brzmi dziwnie znajomo
 - [https://www.chip.pl/2022/11/xiaomi-12s-ultra-concept-wymienne-obiektywy-aparat](https://www.chip.pl/2022/11/xiaomi-12s-ultra-concept-wymienne-obiektywy-aparat)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 13:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="919" src="https://konto.chip.pl/wp-content/uploads/2022/11/xiaomi-12s-ultra-concept-2.jpg" style="margin-bottom: 10px;" width="1576" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/xiaomi-12s-ultra-concept-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>W świecie mobilnej fotografii brakuje dużych innowacji? No to już są. Tworząc Xiaomi 12S Ultra firma równolegle pracowała nad dwoma wariantami smartfonu. Ten, którego do tej pory nie znaliśmy, pozwala wykorzystywać profesjonalne obiektywy z mocowaniem Leica M. Xiaomi 12S Ultra Concept z wymiennymi obiektywami W krótkim materiale wideo Xiaomi zaznacza dumę z modelu Xiaomi 12S [&#8230;]</p>

## Wygląda jak UFO i kosztuje tyle, co topowy procesor. AM AFA to klawiatura jak żadna inna
 - [https://www.chip.pl/2022/11/klawiatura-w-cenie-najwydajniejszego-procesora-am-afa](https://www.chip.pl/2022/11/klawiatura-w-cenie-najwydajniejszego-procesora-am-afa)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 12:30:00+00:00

<img alt="AM AFA" class="attachment-full size-full wp-post-image" height="945" src="https://konto.chip.pl/wp-content/uploads/2022/11/Klawiatura-w-cenie-najwydajniejszego-procesora.-Czym-ma-zachwycic-AM-AFA-2.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/Klawiatura-w-cenie-najwydajniejszego-procesora.-Czym-ma-zachwycic-AM-AFA-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Premiery doczekała się właśnie klawiatura AM AFA, za którą odpowiada firma Angry Miao, chcąca wyciągnąć z kieszeni każdego chętnego przynajmniej 3300 zł (780$)&#8230; i to za wersję podstawową! Ta rozszerzona kosztuje już 795 dolarów, więc śmiało możemy powiedzieć, że AM AFA jest wyceniana tak, jak procesor z najwyższej półki. Musi więc oferować równie wiele, czyż [&#8230;]</p>

## Elon Musk ma rację. Social media powinny być płatne
 - [https://www.chip.pl/2022/11/elon-musk-twitter-abonament](https://www.chip.pl/2022/11/elon-musk-twitter-abonament)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 12:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1281" src="https://konto.chip.pl/wp-content/uploads/2022/11/elon-musk-twitter-abonament-3.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/elon-musk-twitter-abonament-3.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Elona Muska można albo kochać, albo nienawidzić. W ostatnich tygodniach, gdy trwał cyrk związany z przejęciem przez multimiliardera platformy Twitter, Musk ponownie dał się poznać jako człowiek o specyficznym poczuciu humoru i kontrowersyjnych poglądach. W jednym jednak ma rację: media społecznościowe powinny być płatne. Twitter w Polsce obchodzi mało kogo. A przynajmniej do takiego wniosku [&#8230;]</p>

## Ich architektura ma odmienić świat. SiFive zapowiedziało procesory P670 i P470
 - [https://www.chip.pl/2022/11/procesory-p670-i-p470-sifive](https://www.chip.pl/2022/11/procesory-p670-i-p470-sifive)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 11:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="895" src="https://konto.chip.pl/wp-content/uploads/2021/10/Konkurencja-dla-X86-i-Arm-rosnie.-Nowy-rdzen-RISC-V-od-SiFive-ma-zachwycac-1.jpg" style="margin-bottom: 10px;" width="1600" /><p><img src="https://konto.chip.pl/wp-content/uploads/2021/10/Konkurencja-dla-X86-i-Arm-rosnie.-Nowy-rdzen-RISC-V-od-SiFive-ma-zachwycac-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Dwa nowe procesory na bazie architektury RISC-V to coś więcej, niż z pozoru może się wydawać, bo mówimy tutaj przecież o architekturze, która dopiero co rozwija skrzydła i próbuje uszczknąć nieco udziałów na rynku. Firma SiFive zapowiedziała właśnie dwa nowe procesory P670 i P470, które są przeznaczone do inteligentnych urządzeń konsumenckich następnej generacji. Na ten [&#8230;]</p>

## Jeszcze wydajniejsze DRAM. Proces 1-beta Microna wniesie je na nowy poziom
 - [https://www.chip.pl/2022/11/proces-1-beta-microna-dram-2-gb](https://www.chip.pl/2022/11/proces-1-beta-microna-dram-2-gb)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 10:30:00+00:00

<img alt="Proces 1-beta Microna" class="attachment-full size-full wp-post-image" height="1441" src="https://konto.chip.pl/wp-content/uploads/2022/11/Jeszcze-wydajniejsze-DRAM.-Proces-1-beta-Microna-wniesie-je-na-nowy-poziom-1-2.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/Jeszcze-wydajniejsze-DRAM.-Proces-1-beta-Microna-wniesie-je-na-nowy-poziom-1-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Firma Micron pochwaliła się właśnie nową technologią produkcji układów DRAM, czyli pamięci dynamicznej, trafiającej na laminaty kości DDR lub bezpośrednio na główne laminaty bardziej kompaktowych urządzeń. Te układy pełnią funkcję pamięci operacyjnej, stanowiącej niejako pomost między danymi, a procesorem, który zaciąga dane z RAMu do swojej pamięci podręcznej. Są więc ważne&#8230; a nawet bardzo ważne, [&#8230;]</p>

## Rewolucja w samonaprawiających się materiałach. Druk 3D rozwiązuje ich największe problemy
 - [https://www.chip.pl/2022/11/rewolucja-w-samonaprawiajacych-sie-materialach](https://www.chip.pl/2022/11/rewolucja-w-samonaprawiajacych-sie-materialach)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 10:00:00+00:00

<img alt="Rewolucja w samonaprawiających się materiałach, Druk 3D" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2022/11/Rewolucja-w-samonaprawiajacych-sie-materialach.-Druk-3D-rozwiazuje-ich-najwieksze-problemy.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/Rewolucja-w-samonaprawiajacych-sie-materialach.-Druk-3D-rozwiazuje-ich-najwieksze-problemy.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Gdyby tylko nasze samochody, krany, a przynajmniej ubrudzone ściany naprawiały się same&#8230; Wtedy życie byłoby zbyt piękne albo miało miejsce w przyszłości, bo samonaprowadzające się materiały nie są żadną abstrakcją. Potwierdzili to niedawno naukowcy z NC State University (NCSU) w USA, których pracę opisano w Nature Communications. Sukces zapewnili sobie po tym, jak wskazali, że [&#8230;]</p>

## Jak dźwięk umożliwia modelowanie otoczenia?
 - [https://www.chip.pl/2022/11/dzwiek-modelowanie-otoczenia-sposoby](https://www.chip.pl/2022/11/dzwiek-modelowanie-otoczenia-sposoby)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 08:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="632" src="https://konto.chip.pl/wp-content/uploads/2022/11/dzwiek.jpg" style="margin-bottom: 10px;" width="1300" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/dzwiek.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Przestrzenne informacje akustyczne mogą zostać użyte w tworzeniu zaawansowanych robotów. Naukowcy, którzy odpowiadają za publikację dostępną obecnie w bazie danych serwisu arXiv, wykorzystali w tym celu model uczenia maszynowego. Narzędzie to jest w stanie wychwycić, jak każdy dźwięk w pomieszczeniu rozchodzi się w przestrzeni. W efekcie model może przeprowadzić symulacje tego, co usłyszelibyśmy znajdując się [&#8230;]</p>

## Najszybszy nie oznacza najdroższy. Oto Canon EOS R6 Mark II i obiektyw RF 135 mm F1.8L IS USM
 - [https://www.chip.pl/2022/11/canon-eos-r6-ii-premiera-cena-rf-135-mm](https://www.chip.pl/2022/11/canon-eos-r6-ii-premiera-cena-rf-135-mm)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 07:04:42+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1077" src="https://konto.chip.pl/wp-content/uploads/2022/11/canon-eos-r6-mk-ii-premiera-3.jpg" style="margin-bottom: 10px;" width="1914" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/canon-eos-r6-mk-ii-premiera-3.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Canon wprowadza na rynek aparat Canon EOS R6 II reklamując go jako najszybszy aparat z flagowej serii EOS R. Wraz z nim debiutuje bardzo ciekawy obiektyw RF 135 mm F1.8L IS USM oraz nowa lampa błyskowa. Canon EOS R6 Mark II i 40-klatkowe zdjęcia seryjne Podczas gdy wiele osób czekało, a następnie zachwycało się nowym [&#8230;]</p>

## Będą chronić USA przed pociskami balistycznymi. Pociski przechwytujące nowej generacji nadchodzą
 - [https://www.chip.pl/2022/11/pociski-przechwytujace-nowej-generacji](https://www.chip.pl/2022/11/pociski-przechwytujace-nowej-generacji)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 05:00:00+00:00

<img alt="Pociski przechwytujące nowej generacji" class="attachment-full size-full wp-post-image" height="1063" src="https://konto.chip.pl/wp-content/uploads/2022/11/Beda-chronic-USA-przed-pociskami-balistycznymi.-Pociski-przechwytujace-nowej-generacji-nadchodza-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/Beda-chronic-USA-przed-pociskami-balistycznymi.-Pociski-przechwytujace-nowej-generacji-nadchodza-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Obrona przed pociskami balistycznymi przypomina walkę z wiatrakami. Czymś innym jest bowiem wystrzelenie pocisku w kierunku celu naziemnego, a czymś innym jego wykrycie, namierzenie i podjęcie próby zestrzelenia specjalnym efektorem. Pociski balistyczne i sposób ich doprowadzania do celu rozwija się jednak w najlepsze i dlatego USA rozwija swoje pociski przechwytujące nowej generacji tak, aby przeciwdziałać [&#8230;]</p>

## Czarne dziury znowu zaskakują. Chodzi o ich dziwne masy
 - [https://www.chip.pl/2022/11/czarne-dziury-superpozycja-kwantowa-masy](https://www.chip.pl/2022/11/czarne-dziury-superpozycja-kwantowa-masy)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-11-02 05:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="731" src="https://konto.chip.pl/wp-content/uploads/2022/02/podwojna-czarna-dziura.jpg" style="margin-bottom: 10px;" width="1300" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/02/podwojna-czarna-dziura.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Matematyczny dowód na kwantową naturę czarnych dziur może doprowadzić do &#8220;pogodzenia&#8221; fizyki kwantowej i ogólnej teorii względności. To z kolei powinno przełożyć się na przełom dotyczący zrozumienia, jak działa wszechświat. Dokonania w tej sprawie są dziełem autorów publikacji zamieszczonej na łamach Physical Review Letters. To właśnie oni wykazali, że superpozycje masy w teoretycznym typie czarnej [&#8230;]</p>


# Source:China Insights, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug, language:en-US

## Zhengzhou Foxconn Factory: 10,000+ workers flee covid lockdown/Apple iPhone Production Plunges
 - [https://www.youtube.com/watch?v=m9DXebls8Bc](https://www.youtube.com/watch?v=m9DXebls8Bc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug
 - date published: 2022-11-02 02:00:11+00:00

#Chinainsights#Iphoneworkerflee#foxconn
Foxconn Zhengzhou is one of Apple Inc.'s largest foundries in Asia, with a peak workforce of 300,000 employees at one point. From Oct. 29th to 30th, a large number of employees broke out of the plant after a fierce clash between the employees and the anti-epidemic workers. Some employees told overseas Chinese media that they witnessed batches of workers being hauled away from the dorm and quarantined. It’s exposed that abnormalities are found in the nucleic acid test results of nearly 20,000 people who are quarantined in an Evergrande's rotten-tail building. Once workers are placed in quarantine, they are left unattended, without medical care or food.
All these have scared the remaining workers. First, they are still afraid that they will be dragged away for quarantine; second, they are also afraid that the number of positive cases in Foxconn factories will continue to increase, and that eventually they will be infected. 

Have questions? Do you have something to share with us about China? We want to hear from you! 
Email: Cinsights.subscription@gmail.com
Facebook www.facebook.com/EyesOnChina.

Your support allows us to produce more high-quality videos. 
Consider donating at https://www.paypal.com/paypalme/ChinaInsights

Copyright @ China Insights 2021. Any illegal reproduction of this content in any form will result in immediate action against the person(s) concerned.


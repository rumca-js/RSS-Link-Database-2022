# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Zełenski: Dwa rosyjskie pociski rakietowe przeleciały nad korytarzem zbożowym
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-dwa-rosyjskie-pociski-rakietowe-przelecialy-nad-kor,nId,6386042](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-dwa-rosyjskie-pociski-rakietowe-przelecialy-nad-kor,nId,6386042)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 22:35:57+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-dwa-rosyjskie-pociski-rakietowe-przelecialy-nad-kor,nId,6386042"><img align="left" alt="Zełenski: Dwa rosyjskie pociski rakietowe przeleciały nad korytarzem zbożowym" src="https://i.iplsc.com/zelenski-dwa-rosyjskie-pociski-rakietowe-przelecialy-nad-kor/000F0Q0YNGDJMIOY-C321.jpg" /></a>Wołodymyr Zełenski poinformował w środę wieczorem, że rosyjski myśliwiec wystrzelił dwa pociski rakietowe, które przeleciały nad korytarzem zbożowym. - Każdy z tych ataków Rosjan, a zdarzają się one prawie codziennie, zagraża eksportowi żywności - oświadczył prezydent Ukrainy.</p><br clear="all" />

## Podano, ilu generałów straciła Rosja na wojnie z Ukrainą
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-podano-ilu-generalow-stracila-rosja-na-wojnie-z-ukraina,nId,6386035](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-podano-ilu-generalow-stracila-rosja-na-wojnie-z-ukraina,nId,6386035)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 22:12:31+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-podano-ilu-generalow-stracila-rosja-na-wojnie-z-ukraina,nId,6386035"><img align="left" alt="Podano, ilu generałów straciła Rosja na wojnie z Ukrainą" src="https://i.iplsc.com/podano-ilu-generalow-stracila-rosja-na-wojnie-z-ukraina/000EQ1BUPHB6UUOW-C321.jpg" /></a>Według danych w ciągu ośmiu miesięcy wojny Rosja straciła 1402 wysokich rangą oficerów, w tym dziesięciu generałów. W ostatnim czasie znacząco zwiększyła się też codzienna liczba zabijanych rosyjskich żołnierzy.
</p><br clear="all" />

## 30 razy okradł ten sam sklep. 74-latek zatrzymany
 - [https://wydarzenia.interia.pl/wielkopolskie/news-30-razy-okradl-ten-sam-sklep-74-latek-zatrzymany,nId,6385993](https://wydarzenia.interia.pl/wielkopolskie/news-30-razy-okradl-ten-sam-sklep-74-latek-zatrzymany,nId,6385993)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 21:13:59+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-30-razy-okradl-ten-sam-sklep-74-latek-zatrzymany,nId,6385993"><img align="left" alt="30 razy okradł ten sam sklep. 74-latek zatrzymany" src="https://i.iplsc.com/30-razy-okradl-ten-sam-sklep-74-latek-zatrzymany/000EIBA3E6NRXFA5-C321.jpg" /></a>Nie raz, a... 30 okradł ten sam sklep. Policja w Witkowie (woj. wielkopolskie) zatrzymała sprawcę, którym okazał się 74-latek. Mężczyzna chce dobrowolnie poddać się karze.</p><br clear="all" />

## Brazylia: Na południu kraju spadł śnieg. Po raz pierwszy w historii
 - [https://wydarzenia.interia.pl/zagranica/news-brazylia-na-poludniu-kraju-spadl-snieg-po-raz-pierwszy-w-his,nId,6386028](https://wydarzenia.interia.pl/zagranica/news-brazylia-na-poludniu-kraju-spadl-snieg-po-raz-pierwszy-w-his,nId,6386028)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 21:10:47+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-brazylia-na-poludniu-kraju-spadl-snieg-po-raz-pierwszy-w-his,nId,6386028"><img align="left" alt="Brazylia: Na południu kraju spadł śnieg. Po raz pierwszy w historii" src="https://i.iplsc.com/brazylia-na-poludniu-kraju-spadl-snieg-po-raz-pierwszy-w-his/000GACX32963YNBK-C321.jpg" /></a>W brazylijskim stanie Santa Catarina, na południu kraju, zanotowano we wtorek opady śniegu - podała w środę telewizja CNN Brasil. To fenomen atmosferyczny nienotowany w przeszłości.</p><br clear="all" />

## Elon Musk wypowiedział się w sprawie zablokowanych kont na Twitterze
 - [https://wydarzenia.interia.pl/zagranica/news-elon-musk-wypowiedzial-sie-w-sprawie-zablokowanych-kont-na-t,nId,6385994](https://wydarzenia.interia.pl/zagranica/news-elon-musk-wypowiedzial-sie-w-sprawie-zablokowanych-kont-na-t,nId,6385994)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 20:34:53+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-elon-musk-wypowiedzial-sie-w-sprawie-zablokowanych-kont-na-t,nId,6385994"><img align="left" alt="Elon Musk wypowiedział się w sprawie zablokowanych kont na Twitterze" src="https://i.iplsc.com/elon-musk-wypowiedzial-sie-w-sprawie-zablokowanych-kont-na-t/000FN2BJ6SGYGGW6-C321.jpg" /></a>Zablokowane konta na Twitterze nie zostaną odblokowane przynajmniej do najbliższych wyborów - informuje &quot;The Guardian&quot;, powołując się na wypowiedź Elona Muska. Zablokowane konta na Twitterze mają m.in. były prezydent USA Donald Trump i kongresmenka Marjorie Taylor Greene.</p><br clear="all" />

## Biden: Wojska USA w Polsce będą tam przez długi czas
 - [https://wydarzenia.interia.pl/zagranica/news-biden-wojska-usa-w-polsce-beda-tam-przez-dlugi-czas,nId,6386008](https://wydarzenia.interia.pl/zagranica/news-biden-wojska-usa-w-polsce-beda-tam-przez-dlugi-czas,nId,6386008)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 20:10:11+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-biden-wojska-usa-w-polsce-beda-tam-przez-dlugi-czas,nId,6386008"><img align="left" alt="Biden: Wojska USA w Polsce będą tam przez długi czas" src="https://i.iplsc.com/biden-wojska-usa-w-polsce-beda-tam-przez-dlugi-czas/000FZCMHO295XBQT-C321.jpg" /></a>- Wojska USA w Polsce i innych krajach NATO pozostaną tam przez długi czas - zapowiedział w środę prezydent USA Joe Biden. Wcześniej Biały Dom oświadczył, że dodatkowe 20 tys. żołnierzy USA w Europie pozostaną tam &quot;w przewidywalnej przyszłości&quot;.</p><br clear="all" />

## Kiedy spadnie śnieg? Pogoda na listopad
 - [https://wydarzenia.interia.pl/kraj/news-kiedy-spadnie-snieg-pogoda-na-listopad,nId,6385981](https://wydarzenia.interia.pl/kraj/news-kiedy-spadnie-snieg-pogoda-na-listopad,nId,6385981)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 19:45:28+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kiedy-spadnie-snieg-pogoda-na-listopad,nId,6385981"><img align="left" alt="Kiedy spadnie śnieg? Pogoda na listopad" src="https://i.iplsc.com/kiedy-spadnie-snieg-pogoda-na-listopad/000B1Z7ZQ8VR9WTE-C321.jpg" /></a>Zbliżamy się do zmiany warunków termicznych w Polsce - po okresie ciepła, pojawią się zimniejsze dni. Oprócz chłodniejszego powietrza w listopadzie, w kraju pojawią się przymrozki. Synoptycy zdradzili, że już w tym miesiącu pojawić się mogą pierwsze opady śniegu. </p><br clear="all" />

## Szkło w suplemencie diety. GIS ostrzega
 - [https://wydarzenia.interia.pl/kraj/news-szklo-w-suplemencie-diety-gis-ostrzega,nId,6385973](https://wydarzenia.interia.pl/kraj/news-szklo-w-suplemencie-diety-gis-ostrzega,nId,6385973)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 18:56:55+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-szklo-w-suplemencie-diety-gis-ostrzega,nId,6385973"><img align="left" alt="Szkło w suplemencie diety. GIS ostrzega" src="https://i.iplsc.com/szklo-w-suplemencie-diety-gis-ostrzega/0006IK21QV55B7Y9-C321.jpg" /></a>Możliwe zanieczyszczenie szkłem suplementu diety &quot;Anacaps Expert&quot; - przed tym ostrzega Główny Inspektorat Sanitarny. Konsumentów poproszono o niespożywanie określonej serii kapsułek.</p><br clear="all" />

## Atak na Sewastopol. Opublikowano nowe zdjęcia satelitarne
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-atak-na-sewastopol-opublikowano-nowe-zdjecia-satelitarne,nId,6385950](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-atak-na-sewastopol-opublikowano-nowe-zdjecia-satelitarne,nId,6385950)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 18:53:45+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-atak-na-sewastopol-opublikowano-nowe-zdjecia-satelitarne,nId,6385950"><img align="left" alt="Atak na Sewastopol. Opublikowano nowe zdjęcia satelitarne " src="https://i.iplsc.com/atak-na-sewastopol-opublikowano-nowe-zdjecia-satelitarne/000GAC93TLJUQ5FT-C321.jpg" /></a>W sieci pojawiły się zdjęcia z portu w Sewastopolu, w którym według Rosji miało dojść do &quot;ataku dronów&quot;. Mimo zapewnień Federacji Rosyjskiej o tym, że ukraińskie siły nie dokonały zniszczeń okrętów Floty Czarnomorskiej, zdjęcia potwierdzają, że jest wprost przeciwnie.</p><br clear="all" />

## USA rozważają ingerencję w przejęcie Twittera. Powodem Saudowie i Chińczycy
 - [https://wydarzenia.interia.pl/zagranica/news-usa-rozwazaja-ingerencje-w-przejecie-twittera-powodem-saudow,nId,6385957](https://wydarzenia.interia.pl/zagranica/news-usa-rozwazaja-ingerencje-w-przejecie-twittera-powodem-saudow,nId,6385957)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 18:37:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-rozwazaja-ingerencje-w-przejecie-twittera-powodem-saudow,nId,6385957"><img align="left" alt="USA rozważają ingerencję w przejęcie Twittera. Powodem Saudowie i Chińczycy" src="https://i.iplsc.com/usa-rozwazaja-ingerencje-w-przejecie-twittera-powodem-saudow/000G1IK5A7547NNC-C321.jpg" /></a>Administracja Joe Bidena rozważa przeprowadzenie formalnego przeglądu przejęcia Twittera przez Elona Muska - poinformował w środę &quot;Washington Post&quot;. Dziennik twierdzi, że transakcja ta dała dostęp do poufnych danych - w tym potencjalnie dotyczących użytkowników Twittera - inwestorom związanym z Arabią Saudyjską i Chinami.</p><br clear="all" />

## Olaf Scholz w Chinach. Jedna z najtrudniejszych wizyt
 - [https://wydarzenia.interia.pl/zagranica/news-olaf-scholz-w-chinach-jedna-z-najtrudniejszych-wizyt,nId,6385951](https://wydarzenia.interia.pl/zagranica/news-olaf-scholz-w-chinach-jedna-z-najtrudniejszych-wizyt,nId,6385951)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 18:02:38+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-olaf-scholz-w-chinach-jedna-z-najtrudniejszych-wizyt,nId,6385951"><img align="left" alt="Olaf Scholz w Chinach. Jedna z najtrudniejszych wizyt" src="https://i.iplsc.com/olaf-scholz-w-chinach-jedna-z-najtrudniejszych-wizyt/000DYIKZQO99GJBY-C321.jpg" /></a>To będzie politycznie i logistycznie jedna z najtrudniejszych wizyt niemieckiego kanclerza. Olaf Scholz w czwartek uda się w oficjalną podróż do Pekinu. Towarzyszyć mu będzie liczna delegacja gospodarcza, bo Niemcy mają spore interesy w Chinach, ale też wiele problemów. To polityczne wydarzenie budzi wiele kontrowersji w Niemczech i za granicą.</p><br clear="all" />

## Zgubił żonę na cmentarzu. Szczęśliwy finał poszukiwań
 - [https://wydarzenia.interia.pl/lodzkie/news-zgubil-zone-na-cmentarzu-szczesliwy-final-poszukiwan,nId,6385941](https://wydarzenia.interia.pl/lodzkie/news-zgubil-zone-na-cmentarzu-szczesliwy-final-poszukiwan,nId,6385941)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 17:59:37+00:00

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-zgubil-zone-na-cmentarzu-szczesliwy-final-poszukiwan,nId,6385941"><img align="left" alt="Zgubił żonę na cmentarzu. Szczęśliwy finał poszukiwań" src="https://i.iplsc.com/zgubil-zone-na-cmentarzu-szczesliwy-final-poszukiwan/000GAC2RNS30PLWR-C321.jpg" /></a>80-letni mężczyzna, który na jednym z łódzkich cmentarzy zgubił swoją żonę, otrzymał pomoc od policjantów z &quot;drogówki&quot;. Mundurowi zaopiekowali się zmarzniętym seniorem i odnaleźli kobietę. Para wróciła do domu.</p><br clear="all" />

## TikTok przekaże dane użytkowników do Chin
 - [https://wydarzenia.interia.pl/zagranica/news-tiktok-przekaze-dane-uzytkownikow-do-chin,nId,6385939](https://wydarzenia.interia.pl/zagranica/news-tiktok-przekaze-dane-uzytkownikow-do-chin,nId,6385939)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 17:54:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tiktok-przekaze-dane-uzytkownikow-do-chin,nId,6385939"><img align="left" alt="TikTok przekaże dane użytkowników do Chin " src="https://i.iplsc.com/tiktok-przekaze-dane-uzytkownikow-do-chin/000ADNBBSQDKTELQ-C321.jpg" /></a>Dane użytkowników TikToka z Europy będą dostępne dla pracowników m.in. w Chinach - przekazał &quot;The Guardian&quot;. Dostęp do danych ma być wykorzystywany do kontroli, w tym do sprawdzania &quot;wydajności algorytmów&quot;. - Nie jestem przekonany, że chiński rząd koncentruje się na szpiegowaniu danych użytkowników TikTok. Mają inne sposoby uzyskiwania prywatnych informacji - uważa profesor Michael Beale. </p><br clear="all" />

## Lasy Państwowe przejęły ośrodek nad Zegrzem. "Rosjanie zniszczyli wszystko"
 - [https://wydarzenia.interia.pl/kraj/news-lasy-panstwowe-przejely-osrodek-nad-zegrzem-rosjanie-zniszcz,nId,6385942](https://wydarzenia.interia.pl/kraj/news-lasy-panstwowe-przejely-osrodek-nad-zegrzem-rosjanie-zniszcz,nId,6385942)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 17:46:55+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-lasy-panstwowe-przejely-osrodek-nad-zegrzem-rosjanie-zniszcz,nId,6385942"><img align="left" alt="Lasy Państwowe przejęły ośrodek nad Zegrzem. &quot;Rosjanie zniszczyli wszystko&quot;" src="https://i.iplsc.com/lasy-panstwowe-przejely-osrodek-nad-zegrzem-rosjanie-zniszcz/000GAC47F7OWGMOM-C321.jpg" /></a>Lasy Państwowe przejęły ośrodek dzierżawiony przez ambasadę rosyjską nad Zalewem Zegrzyńskim. Jak przekazał wiceminister klimatu i środowiska Edward Siarka, po inwentaryzacji i ocenie biegłych zaproponowane zostanie nowe zagospodarowania terenu. Rzecznik prasowy Lasów Państwowych określił ośrodek jako &quot;całkowicie zdewastowany&quot;. &quot;Rosjanie zniszczyli wszystko&quot; - dodał.</p><br clear="all" />

## Radna wybrana z listy PiS straciła mandat. Powodem prawomocny wyrok
 - [https://wydarzenia.interia.pl/kraj/news-radna-wybrana-z-listy-pis-stracila-mandat-powodem-prawomocny,nId,6385826](https://wydarzenia.interia.pl/kraj/news-radna-wybrana-z-listy-pis-stracila-mandat-powodem-prawomocny,nId,6385826)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 17:33:15+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-radna-wybrana-z-listy-pis-stracila-mandat-powodem-prawomocny,nId,6385826"><img align="left" alt="Radna wybrana z listy PiS straciła mandat. Powodem prawomocny wyrok" src="https://i.iplsc.com/radna-wybrana-z-listy-pis-stracila-mandat-powodem-prawomocny/000FN9DINYVI0F6M-C321.jpg" /></a>Marta Z., była radna Starachowic, decyzją komisarza wyborczego straciła mandat. W czerwcu tego roku kobietę prawomocnie skazano w sprawie wyłudzenia. Do samorządu trafiła z listy Prawa i Sprawiedliwości.</p><br clear="all" />

## Złe wieści dla kierowców: Od nowego roku zmiany w OC. Będzie drożej
 - [https://wydarzenia.interia.pl/kraj/news-zle-wiesci-dla-kierowcow-od-nowego-roku-zmiany-w-oc-bedzie-d,nId,6371909](https://wydarzenia.interia.pl/kraj/news-zle-wiesci-dla-kierowcow-od-nowego-roku-zmiany-w-oc-bedzie-d,nId,6371909)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 17:30:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zle-wiesci-dla-kierowcow-od-nowego-roku-zmiany-w-oc-bedzie-d,nId,6371909"><img align="left" alt="Złe wieści dla kierowców: Od nowego roku zmiany w OC. Będzie drożej" src="https://i.iplsc.com/zle-wiesci-dla-kierowcow-od-nowego-roku-zmiany-w-oc-bedzie-d/0009QKZJL1EWFCF5-C321.jpg" /></a>Ubezpieczenie samochodu w 2023 roku będzie znacznie droższe. Wpływ na podwyżki cen ma między innymi galopująca inflacja, ale to tylko jeden z czynników, który sprawi, że kierowcy będą musieli sięgnąć głębiej do kieszeni. Sprawdzamy, co ma wpływ na ubezpieczenie samochodu oraz dlaczego będzie drożej. Kto płaci za OC najmniej? Odpowiedź w artykule. </p><br clear="all" />

## Premier Włoch Giorgia Meloni napisała do Bąkiewicza ws. Marszu Niepodległości
 - [https://wydarzenia.interia.pl/kraj/news-premier-wloch-giorgia-meloni-napisala-do-bakiewicza-ws-marsz,nId,6385768](https://wydarzenia.interia.pl/kraj/news-premier-wloch-giorgia-meloni-napisala-do-bakiewicza-ws-marsz,nId,6385768)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 17:07:34+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-premier-wloch-giorgia-meloni-napisala-do-bakiewicza-ws-marsz,nId,6385768"><img align="left" alt="Premier Włoch Giorgia Meloni napisała do Bąkiewicza ws. Marszu Niepodległości" src="https://i.iplsc.com/premier-wloch-giorgia-meloni-napisala-do-bakiewicza-ws-marsz/000DK9X80VFIB3G2-C321.jpg" /></a>Nowa premier Włoch Giorgia Meloni przesłała pozdrowienia dla Roberta Bąkiewicza i stowarzyszenia Marszu Niepodległości, jednak ze względu na swoje obowiązki nie pojawi się 11 listopada w Warszawie. &quot;Wierzę, że zobaczymy się za rok&quot; - napisał prezes stowarzyszenia Marsz Niepodległości. 
</p><br clear="all" />

## Polski górnik zginął w kopalni w Czechach
 - [https://wydarzenia.interia.pl/zagranica/news-polski-gornik-zginal-w-kopalni-w-czechach,nId,6385818](https://wydarzenia.interia.pl/zagranica/news-polski-gornik-zginal-w-kopalni-w-czechach,nId,6385818)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 17:02:59+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-polski-gornik-zginal-w-kopalni-w-czechach,nId,6385818"><img align="left" alt="Polski górnik zginął w kopalni w Czechach" src="https://i.iplsc.com/polski-gornik-zginal-w-kopalni-w-czechach/000GABQ4L9K0CRTR-C321.jpg" /></a>Jak przekazała rzeczniczka Kopalnii Ostrawsko-Karwińskich (OKD) Nad`a Chattova, w kopalni CzSM Południe w Stonawie w pobliżu Karwiny podczas obsługi maszyn zginął polski górnik. Zmarły był zatrudniony w firmie podwykonawczej Alpex.</p><br clear="all" />

## Polak zginął w wojnie w Ukrainie. "Żegnamy naszego bohatera"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polak-zginal-w-wojnie-w-ukrainie-zegnamy-naszego-bohatera,nId,6385739](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polak-zginal-w-wojnie-w-ukrainie-zegnamy-naszego-bohatera,nId,6385739)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 16:33:35+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polak-zginal-w-wojnie-w-ukrainie-zegnamy-naszego-bohatera,nId,6385739"><img align="left" alt="Polak zginął w wojnie w Ukrainie. &quot;Żegnamy naszego bohatera&quot;" src="https://i.iplsc.com/polak-zginal-w-wojnie-w-ukrainie-zegnamy-naszego-bohatera/000GABILJQ6NRTX7-C321.jpg" /></a>Ciało Mariana Matusza - rdzennego Polaka o ukraińskim obywatelstwie - przywieziono do Mościsk po dwóch tygodniach poszukiwań na froncie. Opłakiwały go tłumy mieszkańców. Walczył on praktycznie od początku wojny. To kolejna ofiara z polskimi korzeniami w wojnie zainicjowanej przez Rosjan.</p><br clear="all" />

## 25-latek, który uprowadził tramwaj odbywa areszt w oddziale psychiatrycznym
 - [https://wydarzenia.interia.pl/slaskie/news-25-latek-ktory-uprowadzil-tramwaj-odbywa-areszt-w-oddziale-p,nId,6385732](https://wydarzenia.interia.pl/slaskie/news-25-latek-ktory-uprowadzil-tramwaj-odbywa-areszt-w-oddziale-p,nId,6385732)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 16:03:09+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-25-latek-ktory-uprowadzil-tramwaj-odbywa-areszt-w-oddziale-p,nId,6385732"><img align="left" alt="25-latek, który uprowadził tramwaj odbywa areszt w oddziale psychiatrycznym" src="https://i.iplsc.com/25-latek-ktory-uprowadzil-tramwaj-odbywa-areszt-w-oddziale-p/000GABDOB6X60LWU-C321.jpg" /></a>Mężczyzna, który pod koniec października wyjechał tramwajem z zajezdni w Katowicach, odbywa areszt w oddziale psychiatrycznym. Informacje na ten temat potwierdziła prokuratura. 25-latek, choć nie miał uprawnień, zabierał po drodze pasażerów i dotarł w ten sposób do Chorzowa.</p><br clear="all" />

## Noworodek spadł ze stolika podczas odcinania pępowiny. Doznał urazu
 - [https://wydarzenia.interia.pl/wielkopolskie/news-noworodek-spadl-ze-stolika-podczas-odcinania-pepowiny-doznal,nId,6385729](https://wydarzenia.interia.pl/wielkopolskie/news-noworodek-spadl-ze-stolika-podczas-odcinania-pepowiny-doznal,nId,6385729)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 15:57:54+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-noworodek-spadl-ze-stolika-podczas-odcinania-pepowiny-doznal,nId,6385729"><img align="left" alt="Noworodek spadł ze stolika podczas odcinania pępowiny. Doznał urazu" src="https://i.iplsc.com/noworodek-spadl-ze-stolika-podczas-odcinania-pepowiny-doznal/000EAH5488IUP26N-C321.jpg" /></a>Urazu twarzoczaszki doznał noworodek w wyniku upadku ze stolika podczas odcinania pępowiny - podał zastępca dyrektora ds. medycznych w kępińskim (woj. wielkopolskie) szpitalu lekarz Zbigniew Bera.</p><br clear="all" />

## Tajemnicze "kratery". Nowe doniesienia o Nord Stream
 - [https://wydarzenia.interia.pl/zagranica/news-tajemnicze-kratery-nowe-doniesienia-o-nord-stream,nId,6385719](https://wydarzenia.interia.pl/zagranica/news-tajemnicze-kratery-nowe-doniesienia-o-nord-stream,nId,6385719)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 15:48:42+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tajemnicze-kratery-nowe-doniesienia-o-nord-stream,nId,6385719"><img align="left" alt="Tajemnicze &quot;kratery&quot;. Nowe doniesienia o Nord Stream" src="https://i.iplsc.com/tajemnicze-kratery-nowe-doniesienia-o-nord-stream/000GABABRBBM9CYW-C321.jpg" /></a>Operator Nord Stream 1, spółka Nord Stream AG, poinformowała w środę o zakończeniu wstępnego zbierana danych w miejscu uszkodzenia gazociągu w wyłącznej strefie ekonomicznej Szwecji. Na morskim dnie znaleziono tam dwa kratery o głębokości od 3 do 5 metrów. Są one pochodną wybuchu.</p><br clear="all" />

## Bunt wśród zmobilizowanych w Rosji. Powodem brak obiecanych wypłat
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-bunt-wsrod-zmobilizowanych-w-rosji-powodem-brak-obiecanych-w,nId,6385715](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-bunt-wsrod-zmobilizowanych-w-rosji-powodem-brak-obiecanych-w,nId,6385715)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 15:35:59+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-bunt-wsrod-zmobilizowanych-w-rosji-powodem-brak-obiecanych-w,nId,6385715"><img align="left" alt="Bunt wśród zmobilizowanych w Rosji. Powodem brak obiecanych wypłat" src="https://i.iplsc.com/bunt-wsrod-zmobilizowanych-w-rosji-powodem-brak-obiecanych-w/000G6XGEKTFO4JFI-C321.jpg" /></a>Brak obiecanych wypłat pieniędzy spowodował bunt ponad stu mężczyzn w Rosji zmobilizowanych na wojnę w Ukrainie. Jak przekazał portal Insider, zapowiedzieli oni, że nie pójdą walczyć. Aby powstrzymać protest, na miejsce koniecznie było ściągnięcie sił porządkowych.</p><br clear="all" />

## Polska będzie miała trzy elektrownie atomowe. Gdzie powstaną?
 - [https://wydarzenia.interia.pl/kraj/news-polska-bedzie-miala-trzy-elektrownie-atomowe-gdzie-powstana,nId,6385678](https://wydarzenia.interia.pl/kraj/news-polska-bedzie-miala-trzy-elektrownie-atomowe-gdzie-powstana,nId,6385678)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 15:25:55+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-polska-bedzie-miala-trzy-elektrownie-atomowe-gdzie-powstana,nId,6385678"><img align="left" alt="Polska będzie miała trzy elektrownie atomowe. Gdzie powstaną?" src="https://i.iplsc.com/polska-bedzie-miala-trzy-elektrownie-atomowe-gdzie-powstana/000GAB1S9641V9OO-C321.jpg" /></a>Dwa projekty dotyczące budowy elektrowni atomowych są już w toku, trzeci wciąż jest finalizowany - wynika z informacji przekazanych przez premiera Mateusza Morawieckiego. Wiadomo, w jakich lokalizacjach powstaną pierwsze elektrownie atomowe w Polsce.
</p><br clear="all" />

## Elektrownia Bełchatów największym trucicielem Europy? Sprawdzamy
 - [https://wydarzenia.interia.pl/lodzkie/news-elektrownia-belchatow-najwiekszym-trucicielem-europy-sprawdz,nId,6385598](https://wydarzenia.interia.pl/lodzkie/news-elektrownia-belchatow-najwiekszym-trucicielem-europy-sprawdz,nId,6385598)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 14:59:52+00:00

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-elektrownia-belchatow-najwiekszym-trucicielem-europy-sprawdz,nId,6385598"><img align="left" alt="Elektrownia Bełchatów największym trucicielem Europy? Sprawdzamy" src="https://i.iplsc.com/elektrownia-belchatow-najwiekszym-trucicielem-europy-sprawdz/000GA9XAA3NYUHUR-C321.jpg" /></a>W woj. łódzkim żyje się najkrócej, więc o taki stan rzeczy szybko obwiniono Elektrownię Bełchatów. Wcześniej ochrzczoną niechlubnym mianem &quot;największego truciciela Europy&quot;. Sprawa nie jest jednak taka oczywista.</p><br clear="all" />

## Mateusz Morawiecki za powołaniem komisji. Chodzi o uzależnienie Polski od Rosji
 - [https://wydarzenia.interia.pl/kraj/news-mateusz-morawiecki-za-powolaniem-komisji-chodzi-o-uzaleznien,nId,6385670](https://wydarzenia.interia.pl/kraj/news-mateusz-morawiecki-za-powolaniem-komisji-chodzi-o-uzaleznien,nId,6385670)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 14:32:58+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-mateusz-morawiecki-za-powolaniem-komisji-chodzi-o-uzaleznien,nId,6385670"><img align="left" alt="Mateusz Morawiecki za powołaniem komisji. Chodzi o uzależnienie Polski od Rosji" src="https://i.iplsc.com/mateusz-morawiecki-za-powolaniem-komisji-chodzi-o-uzaleznien/000GAAPX4KL9JY73-C321.jpg" /></a>Jestem za powołaniem komisji weryfikacyjnej do zbadania wszystkich potencjalnych działań służących uzależnieniu Polski od Rosji. W ciągu najbliższych dwóch tygodni zostanie przygotowana ustawa dotycząca tej kwestii - przekazał w środę premier Mateusz Morawiecki. </p><br clear="all" />

## Syn nękał ich latami. Rodzice... zlecili jego morderstwo
 - [https://wydarzenia.interia.pl/zagranica/news-syn-nekal-ich-latami-rodzice-zlecili-jego-morderstwo,nId,6385629](https://wydarzenia.interia.pl/zagranica/news-syn-nekal-ich-latami-rodzice-zlecili-jego-morderstwo,nId,6385629)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 14:07:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-syn-nekal-ich-latami-rodzice-zlecili-jego-morderstwo,nId,6385629"><img align="left" alt="Syn nękał ich latami. Rodzice... zlecili jego morderstwo" src="https://i.iplsc.com/syn-nekal-ich-latami-rodzice-zlecili-jego-morderstwo/000GA9XFIGO6Q7R9-C321.jpg" /></a>W stanie Telangana w Indiach doszło do tragicznej zbrodni rodzinnej. 26-latek miał zginąć z rąk sprawców wynajętych przez jego własnych rodziców. Policja wskazuje motyw i decyduje o areszcie.

</p><br clear="all" />

## Środa Wielkopolska: Tomasz B. spędzi w więzieniu 15 lat. Sąd skazał go za kilkukrotny gwałt
 - [https://wydarzenia.interia.pl/wielkopolskie/news-sroda-wielkopolska-tomasz-b-spedzi-w-wiezieniu-15-lat-sad-sk,nId,6385616](https://wydarzenia.interia.pl/wielkopolskie/news-sroda-wielkopolska-tomasz-b-spedzi-w-wiezieniu-15-lat-sad-sk,nId,6385616)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 13:28:08+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-sroda-wielkopolska-tomasz-b-spedzi-w-wiezieniu-15-lat-sad-sk,nId,6385616"><img align="left" alt="Środa Wielkopolska: Tomasz B. spędzi w więzieniu 15 lat. Sąd skazał go za kilkukrotny gwałt" src="https://i.iplsc.com/sroda-wielkopolska-tomasz-b-spedzi-w-wiezieniu-15-lat-sad-sk/000DI0ORFQJHUQ8U-C321.jpg" /></a>Na 15 lat więzienia za kilkukrotne zgwałcenie ze szczególnym okrucieństwem i nieudzielenie pomocy 46-letniej Anecie M. został w środę skazany Tomasz B. Wyrok poznańskiego Sądu Okręgowego nie jest prawomocny.</p><br clear="all" />

## Adam Niedzielski: Ryzyko następnej fali COVID-19 dopiero na przełomie roku
 - [https://wydarzenia.interia.pl/kraj/news-adam-niedzielski-ryzyko-nastepnej-fali-covid-19-dopiero-na-p,nId,6385613](https://wydarzenia.interia.pl/kraj/news-adam-niedzielski-ryzyko-nastepnej-fali-covid-19-dopiero-na-p,nId,6385613)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 13:26:45+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-adam-niedzielski-ryzyko-nastepnej-fali-covid-19-dopiero-na-p,nId,6385613"><img align="left" alt="Adam Niedzielski: Ryzyko następnej fali COVID-19 dopiero na przełomie roku" src="https://i.iplsc.com/adam-niedzielski-ryzyko-nastepnej-fali-covid-19-dopiero-na-p/000GA9MTIGRJD7Y9-C321.jpg" /></a>Jeśli chodzi o COVID-19, to tegoroczna jesień - w przeciwieństwie do jesieni, które pamiętamy z lat poprzednich - upłynie raczej w spokojny sposób - powiedział minister zdrowia Adam Niedzielski.  - Zła część wiadomości jest taka, że mamy w tej chwili zaszczepionych nieco ponad 700 tysięcy osób szczepionką w wersji BA.1 bądź BA.45. To bardzo mało - dodał szef MZ.</p><br clear="all" />

## Eksplozja w bazie lotniczej w głębokiej części Rosji. Tajemnicze wideo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-eksplozja-w-bazie-lotniczej-w-glebokiej-czesci-rosji-tajemni,nId,6385602](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-eksplozja-w-bazie-lotniczej-w-glebokiej-czesci-rosji-tajemni,nId,6385602)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 13:15:04+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-eksplozja-w-bazie-lotniczej-w-glebokiej-czesci-rosji-tajemni,nId,6385602"><img align="left" alt="Eksplozja w bazie lotniczej w głębokiej części Rosji. Tajemnicze wideo" src="https://i.iplsc.com/eksplozja-w-bazie-lotniczej-w-glebokiej-czesci-rosji-tajemni/000GA9KBBS2XL4QG-C321.jpg" /></a>W bazie lotniczej w Berednikach w Rosji doszło do eksplozji, w wyniku której wojsko Putina straciło wiele cennych maszyn. W sieci pokazano zdjęcia satelitarne ujawniające skalę zniszczeń. Do internetu trafiło również tajemnicze nagranie, na którym rzekomo widać, jak ktoś podkłada ładunek wybuchowy, by wysadzić rosyjską bazę.</p><br clear="all" />

## Brazylia: Protesty przeciwko wygranej Luli da Silvy. Ludzie blokują drogi
 - [https://wydarzenia.interia.pl/zagranica/news-brazylia-protesty-przeciwko-wygranej-luli-da-silvy-ludzie-bl,nId,6385582](https://wydarzenia.interia.pl/zagranica/news-brazylia-protesty-przeciwko-wygranej-luli-da-silvy-ludzie-bl,nId,6385582)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 12:52:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-brazylia-protesty-przeciwko-wygranej-luli-da-silvy-ludzie-bl,nId,6385582"><img align="left" alt="Brazylia: Protesty przeciwko wygranej Luli da Silvy. Ludzie blokują drogi" src="https://i.iplsc.com/brazylia-protesty-przeciwko-wygranej-luli-da-silvy-ludzie-bl/000GA9EAERMWPSX8-C321.jpg" /></a>Tysiące obywateli Brazylii wyszło na ulice i bierze udział w protestach przeciwko wygranej Luiza Inacio Luli da Silvy w niedzielnych wyborach prezydenckich. Lewicowy polityk wygrał niewielką przewagą w drugiej turze głosowania z dotychczasowym prawicowym szefem państwa Jairem Bolsonaro pozbawiając go tym samym prezydentury. </p><br clear="all" />

## Rosja straszy bombą atomową. Jasny przekaz z Białego Domu
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-straszy-bomba-atomowa-jasny-przekaz-z-bialego-domu,nId,6385587](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-straszy-bomba-atomowa-jasny-przekaz-z-bialego-domu,nId,6385587)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 12:48:06+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-straszy-bomba-atomowa-jasny-przekaz-z-bialego-domu,nId,6385587"><img align="left" alt="Rosja straszy bombą atomową. Jasny przekaz z Białego Domu" src="https://i.iplsc.com/rosja-straszy-bomba-atomowa-jasny-przekaz-z-bialego-domu/000GA9FAE7SDHDCM-C321.jpg" /></a>Stany Zjednoczone nie widzą żadnych oznak, że Rosja przygotowuje się do użycia broni jądrowej - powiedział w środę rzecznik Białego Domu John Kirby. Wcześniej dziennik &quot;New York Times&quot;, powołując się na waszyngtońskich urzędników podał, że amerykańskie władze dysponują informacjami wywiadowczymi, z których wynika, że przedstawiciele rosyjskiego kierownictwa wojskowego dyskutowali o możliwościach użycia broni jądrowej w Ukrainie. W rozmowach miał nie uczestniczyć Władimir Putin.</p><br clear="all" />

## Wojna w Ukrainie. John Kirby: USA nie widzą żadnych oznak, że Rosja przygotowuje się do użycia broni jądrowej
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-john-kirby-usa-nie-widza-zadnych-oznak-ze-r,nId,6385587](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-john-kirby-usa-nie-widza-zadnych-oznak-ze-r,nId,6385587)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 12:48:06+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-john-kirby-usa-nie-widza-zadnych-oznak-ze-r,nId,6385587"><img align="left" alt="Wojna w Ukrainie. John Kirby: USA nie widzą żadnych oznak, że Rosja przygotowuje się do użycia broni jądrowej" src="https://i.iplsc.com/wojna-w-ukrainie-john-kirby-usa-nie-widza-zadnych-oznak-ze-r/000GA9FAE7SDHDCM-C321.jpg" /></a>Stany Zjednoczone nie widzą żadnych oznak, że Rosja przygotowuje się do użycia broni jądrowej - powiedział w środę rzecznik Białego Domu John Kirby. Wcześniej dziennik &quot;New York Times&quot;, powołując się na waszyngtońskich urzędników podał, że amerykańskie władze dysponują informacjami wywiadowczymi, z których wynika, że przedstawiciele rosyjskiego kierownictwa wojskowego dyskutowali o możliwościach użycia broni jądrowej na Ukrainie. W rozmowach miał nie uczestniczyć Władimir Putin.

</p><br clear="all" />

## Ostrów Mazowiecka. W obecności prezydenta Andrzeja Dudy otwarto Muzeum Dom Rodziny Pileckich
 - [https://wydarzenia.interia.pl/kraj/news-ostrow-mazowiecka-w-obecnosci-prezydenta-andrzeja-dudy-otwar,nId,6385573](https://wydarzenia.interia.pl/kraj/news-ostrow-mazowiecka-w-obecnosci-prezydenta-andrzeja-dudy-otwar,nId,6385573)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 12:31:21+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ostrow-mazowiecka-w-obecnosci-prezydenta-andrzeja-dudy-otwar,nId,6385573"><img align="left" alt="Ostrów Mazowiecka. W obecności prezydenta Andrzeja Dudy otwarto Muzeum Dom Rodziny Pileckich" src="https://i.iplsc.com/ostrow-mazowiecka-w-obecnosci-prezydenta-andrzeja-dudy-otwar/000GA9C78ORU1HFM-C321.jpg" /></a>- Ten dom jest symbolem wychowania całego pokolenia - &quot;Kolumbów&quot; i Żołnierzy Niezłomnych  - mówił powiedział prezydent Andrzej Duda w Ostrowi Mazowieckiej. W środę otwarto tam Muzeum Dom Rodziny Pileckich.</p><br clear="all" />

## Szef białoruskiego KGB mówi o ataku na Białoruś. "Plany inwazji z Polski"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-szef-bialoruskiego-kgb-mowi-o-ataku-na-bialorus-plany-inwazj,nId,6385559](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-szef-bialoruskiego-kgb-mowi-o-ataku-na-bialorus-plany-inwazj,nId,6385559)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 12:21:41+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-szef-bialoruskiego-kgb-mowi-o-ataku-na-bialorus-plany-inwazj,nId,6385559"><img align="left" alt="Szef białoruskiego KGB mówi o ataku na Białoruś. &quot;Plany inwazji z Polski&quot;" src="https://i.iplsc.com/szef-bialoruskiego-kgb-mowi-o-ataku-na-bialorus-plany-inwazj/000GA9AHKJYBM9FB-C321.jpg" /></a>Szef białoruskiej bezpieki Iwan Tertel miał we wtorek wygłosić przemówienie, w którym oskarżał USA o plan ataku na Białoruś. Jak stwierdził, &quot;istnieją plany inwazji wojskowej z terytorium Polski&quot;. Powołał się przy tym na dywizję, która rzekomo stacjonuje w naszym kraju. W rzeczywistości wspomniane siły znajdują się w Rumunii.
</p><br clear="all" />

## Minister zdrowia: Pogarsza się stan zdrowia polskich dzieci
 - [https://wydarzenia.interia.pl/zdrowie/news-minister-zdrowia-pogarsza-sie-stan-zdrowia-polskich-dzieci,nId,6385563](https://wydarzenia.interia.pl/zdrowie/news-minister-zdrowia-pogarsza-sie-stan-zdrowia-polskich-dzieci,nId,6385563)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 12:19:13+00:00

<p><a href="https://wydarzenia.interia.pl/zdrowie/news-minister-zdrowia-pogarsza-sie-stan-zdrowia-polskich-dzieci,nId,6385563"><img align="left" alt="Minister zdrowia: Pogarsza się stan zdrowia polskich dzieci" src="https://i.iplsc.com/minister-zdrowia-pogarsza-sie-stan-zdrowia-polskich-dzieci/000GA994SEN2BE5I-C321.jpg" /></a>Stan zdrowia naszych dzieci pogarsza się, zarówno jeśli chodzi o otyłość, jak i nadwagę - poinformował w środę minister zdrowia Adam Niedzielski, omawiając wyniki badania zrealizowanego w grupie 2 tys. dzieci w wieku 8 lat. Badanie wykonał Instytut Matki i Dziecka w Warszawie.</p><br clear="all" />

## Zderzenie ciężarówki z pociągiem. "Kierowca nie zdążył"
 - [https://wydarzenia.interia.pl/mazowieckie/news-zderzenie-ciezarowki-z-pociagiem-kierowca-nie-zdazyl,nId,6385466](https://wydarzenia.interia.pl/mazowieckie/news-zderzenie-ciezarowki-z-pociagiem-kierowca-nie-zdazyl,nId,6385466)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 12:17:00+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-zderzenie-ciezarowki-z-pociagiem-kierowca-nie-zdazyl,nId,6385466"><img align="left" alt="Zderzenie ciężarówki z pociągiem. &quot;Kierowca nie zdążył&quot;" src="https://i.iplsc.com/zderzenie-ciezarowki-z-pociagiem-kierowca-nie-zdazyl/000GA97X04MS3225-C321.jpg" /></a>W Ołtarzewie (woj. mazowieckie) pociąg Kolei Mazowieckich uderzył w tył ciężarówki, której kierowca nie zdążył zjechać z przejazdu kolejowego. Pasażerowie korzystający z dojazdu do Warszawy z pociągów muszą przygotować się na czasowe utrudnienia w ruchu. </p><br clear="all" />

## Wjechał w sklep i prawie staranował ludzi. Grozi mu do 10 lat
 - [https://wydarzenia.interia.pl/lubuskie/news-wjechal-w-sklep-i-prawie-staranowal-ludzi-grozi-mu-do-10-lat,nId,6385483](https://wydarzenia.interia.pl/lubuskie/news-wjechal-w-sklep-i-prawie-staranowal-ludzi-grozi-mu-do-10-lat,nId,6385483)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 12:09:00+00:00

<p><a href="https://wydarzenia.interia.pl/lubuskie/news-wjechal-w-sklep-i-prawie-staranowal-ludzi-grozi-mu-do-10-lat,nId,6385483"><img align="left" alt="Wjechał w sklep i prawie staranował ludzi. Grozi mu do 10 lat" src="https://i.iplsc.com/wjechal-w-sklep-i-prawie-staranowal-ludzi-grozi-mu-do-10-lat/000GA8SVMR0NDWFG-C321.jpg" /></a>36-latek wjechał w drzwi sklepu na stacji paliw - później porzucił samochód i wraz z pasażerem uciekł z miejsca zdarzenia. Badania wykazały, że mężczyzna był pod wpływem narkotyków. Jak poinformowała policja, 36-letni mieszkaniec Gubina (woj. lubuskie) miał sądowy zakaz kierowania pojazdami mechanicznymi. Straty jakie wyrządził oszacowano na setki tysięcy złotych. </p><br clear="all" />

## Niemcy: Największa sieć domów towarowych na krawędzi upadku
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-najwieksza-siec-domow-towarowych-na-krawedzi-upadku,nId,6385532](https://wydarzenia.interia.pl/zagranica/news-niemcy-najwieksza-siec-domow-towarowych-na-krawedzi-upadku,nId,6385532)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 11:51:48+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-najwieksza-siec-domow-towarowych-na-krawedzi-upadku,nId,6385532"><img align="left" alt="Niemcy: Największa sieć domów towarowych na krawędzi upadku" src="https://i.iplsc.com/niemcy-najwieksza-siec-domow-towarowych-na-krawedzi-upadku/000GA952H7LCYS45-C321.jpg" /></a>Największa i zarazem ostatnia sieć tradycyjnych niemieckich domów towarowych Galeria Karstadt znalazła się w poważnych tarapatach. Firma szuka pomocy finansowej i stoi przed wielką restrukturyzacją, która doprowadzi do zamknięcia co trzeciego domu towarowego. Nie obędzie się bez grupowych zwolnień. Eksperci wieszczą upadek firmy, bo jej biznesowy plan nie odpowiada dzisiejszym wymaganiom klientów.</p><br clear="all" />

## Zapora tymczasowa na granicy z Kaliningradem. Straż Graniczna: Powstaje na naszą prośbę
 - [https://wydarzenia.interia.pl/kraj/news-zapora-tymczasowa-na-granicy-z-kaliningradem-straz-graniczna,nId,6385547](https://wydarzenia.interia.pl/kraj/news-zapora-tymczasowa-na-granicy-z-kaliningradem-straz-graniczna,nId,6385547)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 11:49:42+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zapora-tymczasowa-na-granicy-z-kaliningradem-straz-graniczna,nId,6385547"><img align="left" alt="Zapora tymczasowa na granicy z Kaliningradem. Straż Graniczna: Powstaje na naszą prośbę" src="https://i.iplsc.com/zapora-tymczasowa-na-granicy-z-kaliningradem-straz-graniczna/000GA954OEXL60JN-C321.jpg" /></a>Zapora tymczasowa na granicy z Rosją powstaje na naszą prośbę - przekazała Ewelina Szczepańska z zespołu prasowego Komendanta Głównego Straży Granicznej. Jak dodała, na razie na tej granicy jest spokojnie i stabilnie. Zapora będzie miała 2,5 metra wysokości i 3 metry wysokości. Prace nad budową rozpoczęły się w środę.

</p><br clear="all" />

## Polski atom coraz bliżej. Jest projekt uchwały Rady Ministrów
 - [https://wydarzenia.interia.pl/kraj/news-polski-atom-coraz-blizej-jest-projekt-uchwaly-rady-ministrow,nId,6385368](https://wydarzenia.interia.pl/kraj/news-polski-atom-coraz-blizej-jest-projekt-uchwaly-rady-ministrow,nId,6385368)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 11:45:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-polski-atom-coraz-blizej-jest-projekt-uchwaly-rady-ministrow,nId,6385368"><img align="left" alt="Polski atom coraz bliżej. Jest projekt uchwały Rady Ministrów" src="https://i.iplsc.com/polski-atom-coraz-blizej-jest-projekt-uchwaly-rady-ministrow/000GA7Y8IGO5OYUB-C321.jpg" /></a>Rząd ma przygotowany projekt uchwały o pierwszej polskiej elektrowni jądrowej, która ma zostać wybudowana w technologii Westinghouse AP1000. Pierwszy blok elektrowni Lubiatowo-Kopalino ma według zapowiedzi rozpocząć pracę w 2033 r.</p><br clear="all" />

## "Latający samochód" tuż przed maską. W komentarzach zachwyty. Jest nagranie
 - [https://wydarzenia.interia.pl/zagranica/news-latajacy-samochod-tuz-przed-maska-w-komentarzach-zachwyty-je,nId,6385499](https://wydarzenia.interia.pl/zagranica/news-latajacy-samochod-tuz-przed-maska-w-komentarzach-zachwyty-je,nId,6385499)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 11:17:51+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-latajacy-samochod-tuz-przed-maska-w-komentarzach-zachwyty-je,nId,6385499"><img align="left" alt="&quot;Latający samochód&quot; tuż przed maską. W komentarzach zachwyty. Jest nagranie" src="https://i.iplsc.com/latajacy-samochod-tuz-przed-maska-w-komentarzach-zachwyty-je/000GA90K0E24FQFX-C321.jpg" /></a>Wypadek na amerykańskiej autostradzie stał się przyczynkiem do zaskakującej dyskusji. Okrzyknięty &quot;latającym samochodem&quot; Land Rover Defender wprawił w zachwyt komentujących, którzy zdziwili się, jak dobrze przetrwał on potężny wypadek.</p><br clear="all" />

## Prezydent podpisał ustawę o maksymalnych cenach energii
 - [https://wydarzenia.interia.pl/kraj/news-prezydent-podpisal-ustawe-o-maksymalnych-cenach-energii,nId,6385518](https://wydarzenia.interia.pl/kraj/news-prezydent-podpisal-ustawe-o-maksymalnych-cenach-energii,nId,6385518)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 11:17:45+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prezydent-podpisal-ustawe-o-maksymalnych-cenach-energii,nId,6385518"><img align="left" alt="Prezydent podpisał ustawę o maksymalnych cenach energii" src="https://i.iplsc.com/prezydent-podpisal-ustawe-o-maksymalnych-cenach-energii/000GA92E741QLTFK-C321.jpg" /></a>Prezydent podpisał ustawę o środkach nadzwyczajnych mających na celu ograniczenie wysokości cen energii elektrycznej oraz wsparciu niektórych odbiorców w 2023 roku. Wprowadza ona mechanizm maksymalnych cen energii, który ma chronić uprawnionych odbiorców przed drastycznym wzrostem cen prądu. W 2023 r. gospodarstwa domowe po przekroczeniu limitów mają zapłacić nie więcej niż 693 zł za MWh, a samorządy i MŚP - 785 zł za MWh.

</p><br clear="all" />

## Pościg na S17. 16-latek pędził 240 km/h
 - [https://wydarzenia.interia.pl/mazowieckie/news-poscig-na-s17-16-latek-pedzil-240-km-h,nId,6385513](https://wydarzenia.interia.pl/mazowieckie/news-poscig-na-s17-16-latek-pedzil-240-km-h,nId,6385513)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 11:14:30+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-poscig-na-s17-16-latek-pedzil-240-km-h,nId,6385513"><img align="left" alt="Pościg na S17. 16-latek pędził 240 km/h" src="https://i.iplsc.com/poscig-na-s17-16-latek-pedzil-240-km-h/000GA941XWPVBVGQ-C321.jpg" /></a>Policjanci zatrzymali 16-latka, który próbował im uciec audi na trasie S17. Młody kierowca łamał przepisy, powodował kolizje i ominął punkt blokadowy, jadąc prosto na stojących policjantów - poinformowała w środę mł. asp. Paulina Harabin, oficer prasowa KPP w Otwocku. - Momentami osiągał prędkość ponad 240 km/h - poinformowała policjantka.</p><br clear="all" />

## Dystrybucja węgla przez samorządy. Prezydent podpisał ustawę
 - [https://wydarzenia.interia.pl/kraj/news-dystrybucja-wegla-przez-samorzady-prezydent-podpisal-ustawe,nId,6385508](https://wydarzenia.interia.pl/kraj/news-dystrybucja-wegla-przez-samorzady-prezydent-podpisal-ustawe,nId,6385508)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 11:11:16+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-dystrybucja-wegla-przez-samorzady-prezydent-podpisal-ustawe,nId,6385508"><img align="left" alt="Dystrybucja węgla przez samorządy. Prezydent podpisał ustawę" src="https://i.iplsc.com/dystrybucja-wegla-przez-samorzady-prezydent-podpisal-ustawe/000G4P1RVK9ME3B8-C321.jpg" /></a>Prezydent Andrzej Duda podpisał ustawę o dystrybucji węgla przez samorządy - poinformowała w środę KPRP. Gminy, spółki gminne i związki gminne będą mogły kupować węgiel za maksymalnie 1,5 tys. zł za tonę, a sprzedawać go mieszkańcom za nie więcej niż 2 tys. zł za tonę.</p><br clear="all" />

## Rosja wraca do umowy zbożowej. Kreml oficjalnie potwierdza
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-wraca-do-umowy-zbozowej-kreml-oficjalnie-potwierdza,nId,6385476](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-wraca-do-umowy-zbozowej-kreml-oficjalnie-potwierdza,nId,6385476)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 10:39:13+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-wraca-do-umowy-zbozowej-kreml-oficjalnie-potwierdza,nId,6385476"><img align="left" alt="Rosja wraca do umowy zbożowej. Kreml oficjalnie potwierdza" src="https://i.iplsc.com/rosja-wraca-do-umowy-zbozowej-kreml-oficjalnie-potwierdza/000GA8V05EKNL2H9-C321.jpg" /></a>Rosyjskie ministerstwo obrony przekazało, że Rosja wznawia realizację &quot;umowy zbożowej&quot; zawieszonej po wybuchach w Sewastopolu - poinformowała agencja Reutera. Prezydent Turcji Recep Tayyip Erdogan przekazał, że inicjatywa zbożowa zostanie wznowiona w środę w południe.</p><br clear="all" />

## Wojna w Ukrainie. Brytyjski wywiad: Grupa Wagnera dokonuje na Ukrainie minimalnych postępów
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-brytyjski-wywiad-grupa-wagnera-dokonuje-na-,nId,6385464](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-brytyjski-wywiad-grupa-wagnera-dokonuje-na-,nId,6385464)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 10:28:52+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-brytyjski-wywiad-grupa-wagnera-dokonuje-na-,nId,6385464"><img align="left" alt="Wojna w Ukrainie. Brytyjski wywiad: Grupa Wagnera dokonuje na Ukrainie minimalnych postępów" src="https://i.iplsc.com/wojna-w-ukrainie-brytyjski-wywiad-grupa-wagnera-dokonuje-na/000GA8SLUC3DPG6G-C321.jpg" /></a>Najemnicy z rosyjskiej grupy Wagnera dokonują na Ukrainie minimalnych postępów, posuwając się naprzód o 100-200 metrów dziennie, czyli znacznie mniej, niż zakłada rosyjska doktryna, i mniej niż obecne postępy sił ukraińskich - przekazało brytyjskie ministerstwo obrony. Jeden z czołowych krytyków Putina Michaił Chodorkowski informuje, że grupa Wagnera cieszy się w Rosji rosnącą popularnością, wynikającą ze zdolności do przekonania społeczeństwa, że jej członkowie są alternatywą dla potencjalnej szerszej mobilizacji. </p><br clear="all" />

## Stado lwów uciekło z zagrody w zoo, obok spali turyści. Panika w ośrodku
 - [https://wydarzenia.interia.pl/zagranica/news-stado-lwow-ucieklo-z-zagrody-w-zoo-obok-spali-turysci-panika,nId,6385458](https://wydarzenia.interia.pl/zagranica/news-stado-lwow-ucieklo-z-zagrody-w-zoo-obok-spali-turysci-panika,nId,6385458)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 10:25:49+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-stado-lwow-ucieklo-z-zagrody-w-zoo-obok-spali-turysci-panika,nId,6385458"><img align="left" alt="Stado lwów uciekło z zagrody w zoo, obok spali turyści. Panika w ośrodku" src="https://i.iplsc.com/stado-lwow-ucieklo-z-zagrody-w-zoo-obok-spali-turysci-panika/000GA8PMM04MS6HU-C321.jpg" /></a>Kilka godzin stresu przysporzyły zamieszkujące zoo w Sydney lwy. Stado opuściło swoją zagrodę i &quot;szalało&quot; po kompleksie. Obok, w namiotach, spali turyści. Na terenie ośrodka rozległ się ogłuszający alarm, kiedy trwał pościg za zwierzętami. </p><br clear="all" />

## Tragiczny weekend na drogach. Policja podała statystyki
 - [https://wydarzenia.interia.pl/kraj/news-tragiczny-weekend-na-drogach-policja-podala-statystyki,nId,6385424](https://wydarzenia.interia.pl/kraj/news-tragiczny-weekend-na-drogach-policja-podala-statystyki,nId,6385424)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 10:22:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tragiczny-weekend-na-drogach-policja-podala-statystyki,nId,6385424"><img align="left" alt="Tragiczny weekend na drogach. Policja podała statystyki" src="https://i.iplsc.com/tragiczny-weekend-na-drogach-policja-podala-statystyki/000GA8HRMJULHOWK-C321.jpg" /></a>Tylko 1 listopada na polskich drogach doszło do 39 wypadków, 7 osób zginęło, a 45 zostało rannych. W tym roku łącznie było o 10 ofiar mniej niż w analogicznym okresie ubiegłego roku. Policja podsumowuje akcję &quot;Znicz&quot;. </p><br clear="all" />

## Wielka Brytania: W samolot uderzył piorun. Do sieci trafiły zdjęcia
 - [https://wydarzenia.interia.pl/zagranica/news-wielka-brytania-w-samolot-uderzyl-piorun-do-sieci-trafily-zd,nId,6385416](https://wydarzenia.interia.pl/zagranica/news-wielka-brytania-w-samolot-uderzyl-piorun-do-sieci-trafily-zd,nId,6385416)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 10:18:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wielka-brytania-w-samolot-uderzyl-piorun-do-sieci-trafily-zd,nId,6385416"><img align="left" alt="Wielka Brytania: W samolot uderzył piorun. Do sieci trafiły zdjęcia" src="https://i.iplsc.com/wielka-brytania-w-samolot-uderzyl-piorun-do-sieci-trafily-zd/000GA81B5HXAK0AI-C321.jpg" /></a>Dramatyczne zdjęcia lotu Airbusa Belugi XL5 z lotniska Hawarden w Wielkiej Brytanii do Hamburga obiegły sieć. Krótko po starcie w maszynę uderzył piorun. Świadkowie mówią o potężnym odgłosie wybuchu i błysku światła. Zgłoszono także przerwy w dostawie prądu.</p><br clear="all" />

## Zapora na granicy z obwodem kaliningradzkim. Budowę rozpoczęto od Wisztyńca
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zapora-na-granicy-z-obwodem-kaliningradzkim-budowe-rozpoczet,nId,6385450](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zapora-na-granicy-z-obwodem-kaliningradzkim-budowe-rozpoczet,nId,6385450)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 10:08:27+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zapora-na-granicy-z-obwodem-kaliningradzkim-budowe-rozpoczet,nId,6385450"><img align="left" alt="Zapora na granicy z obwodem kaliningradzkim. Budowę rozpoczęto od Wisztyńca" src="https://i.iplsc.com/zapora-na-granicy-z-obwodem-kaliningradzkim-budowe-rozpoczet/000GA8NOGB6VX3LQ-C321.jpg" /></a>Budowę zapory na granicy rozpoczęto od miejscowości Wisztyniec w gminie Dubieniki. Leży ona na styku trzech granic - polskiej, rosyjskiej i litewskiej. Miejscowy samorząd nie wiedział o decyzji rządu. - Ale nikt na pewno protestował nie będzie - przekazał wójt Dubeninek.</p><br clear="all" />

## Szydłowiec. Ścięte drzewo przygniotło 64-latka. Mężczyzna nie żyje
 - [https://wydarzenia.interia.pl/mazowieckie/news-szydlowiec-sciete-drzewo-przygniotlo-64-latka-mezczyzna-nie-,nId,6385445](https://wydarzenia.interia.pl/mazowieckie/news-szydlowiec-sciete-drzewo-przygniotlo-64-latka-mezczyzna-nie-,nId,6385445)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 09:59:21+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-szydlowiec-sciete-drzewo-przygniotlo-64-latka-mezczyzna-nie-,nId,6385445"><img align="left" alt="Szydłowiec. Ścięte drzewo przygniotło 64-latka. Mężczyzna nie żyje" src="https://i.iplsc.com/szydlowiec-sciete-drzewo-przygniotlo-64-latka-mezczyzna-nie/000GA8RFSH3XFEN3-C321.jpg" /></a>64-letni mieszkaniec gminy Szydłowiec został uderzony przez upadające drzewo w wyniku czego poniósł śmierć na miejscu - poinformował Michał Burski z Komendy Powiatowej Policji w Szydłowcu. Decyzją prokuratora ciało mężczyzny zostało zabezpieczone celem przeprowadzenia sekcji zwłok</p><br clear="all" />

## Mieli prowadzić program, nie pojawili się na antenie. "Nie byli w stanie"
 - [https://wydarzenia.interia.pl/zagranica/news-mieli-prowadzic-program-nie-pojawili-sie-na-antenie-nie-byli,nId,6385435](https://wydarzenia.interia.pl/zagranica/news-mieli-prowadzic-program-nie-pojawili-sie-na-antenie-nie-byli,nId,6385435)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 09:57:26+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-mieli-prowadzic-program-nie-pojawili-sie-na-antenie-nie-byli,nId,6385435"><img align="left" alt="Mieli prowadzić program, nie pojawili się na antenie. &quot;Nie byli w stanie&quot;" src="https://i.iplsc.com/mieli-prowadzic-program-nie-pojawili-sie-na-antenie-nie-byli/000GA8K868K7D6UQ-C321.jpg" /></a>&quot;Zbyt roztrzęsieni, by pracować&quot; - pisze o sytuacji, która miała miejsce w lokalnej stacji BBC &quot;Daily Mail&quot;. Dziennikarze postanowili, że nie poprowadzą dwóch codziennych programów na żywo, ponieważ chwilę wcześniej dowiedzieli się o masowych zwolnieniach. W redakcji zapanowała grobowa atmosfera. </p><br clear="all" />

## Kaliningrad. Zapora na granicy z Rosją. Ochojska: Jaki w tym sens? To przerażające
 - [https://wydarzenia.interia.pl/autor/lukasz-szpyrka/news-kaliningrad-zapora-na-granicy-z-rosja-ochojska-jaki-w-tym-se,nId,6385441](https://wydarzenia.interia.pl/autor/lukasz-szpyrka/news-kaliningrad-zapora-na-granicy-z-rosja-ochojska-jaki-w-tym-se,nId,6385441)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 09:54:47+00:00

<p><a href="https://wydarzenia.interia.pl/autor/lukasz-szpyrka/news-kaliningrad-zapora-na-granicy-z-rosja-ochojska-jaki-w-tym-se,nId,6385441"><img align="left" alt="Kaliningrad. Zapora na granicy z Rosją. Ochojska: Jaki w tym sens? To przerażające" src="https://i.iplsc.com/kaliningrad-zapora-na-granicy-z-rosja-ochojska-jaki-w-tym-se/000GA8MMGXCXOL07-C321.jpg" /></a>Szef MON Mariusz Błaszczak ogłosił, że Polska zbuduje zaporę na granicy z obwodem kaliningradzkim. - To jest przerażające! Już zapora, którą zbudowano na granicy polsko-białoruskiej, jest kompletnie bezsensowna. Jeśli miała powstrzymać migrację, to jej nie powstrzymała. Wydano na to ogromne pieniądze. Teraz będziemy budowali kolejny mur na granicy z obwodem kaliningradzkim? Za jakie pieniądze? - zastanawia się Janina Ochojska, założycielka Polskiej Akcji Humanitarnej i europosłanka wybrana z list Koalicji Europejskiej. </p><br clear="all" />

## Izrael: Prawicowa koalicja utrzymuje przewagę. Popierają Benjamina Netanjahu
 - [https://wydarzenia.interia.pl/zagranica/news-izrael-prawicowa-koalicja-utrzymuje-przewage-popieraja-benja,nId,6385398](https://wydarzenia.interia.pl/zagranica/news-izrael-prawicowa-koalicja-utrzymuje-przewage-popieraja-benja,nId,6385398)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 09:17:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-izrael-prawicowa-koalicja-utrzymuje-przewage-popieraja-benja,nId,6385398"><img align="left" alt="Izrael: Prawicowa koalicja utrzymuje przewagę. Popierają Benjamina Netanjahu" src="https://i.iplsc.com/izrael-prawicowa-koalicja-utrzymuje-przewage-popieraja-benja/000AG4NJU2PHB3IA-C321.jpg" /></a>Po przeliczeniu 62 proc. głosów oddanych w wyborach parlamentarnych w Izraelu prawicowa koalicja popierająca byłego premiera Benjamina Netanjahu utrzymuje przewagę - przekazał portal &quot;Times of Israel&quot;, powołując się na izraelską Centralną Komisję Wyborczą. We wtorek w Izraelu zakończyły się wybory parlamentarne - według sondaży exit poll, Netanjahu wygrał wybory i powróci na stanowisko premiera.</p><br clear="all" />

## Koronawirus w Polsce. Ministerstwo Zdrowia opublikowało tygodniowy raport
 - [https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-koronawirus-w-polsce-ministerstwo-zdrowia-opublikowalo-tygod,nId,6385347](https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-koronawirus-w-polsce-ministerstwo-zdrowia-opublikowalo-tygod,nId,6385347)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 09:13:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-koronawirus-w-polsce-ministerstwo-zdrowia-opublikowalo-tygod,nId,6385347"><img align="left" alt="Koronawirus w Polsce. Ministerstwo Zdrowia opublikowało tygodniowy raport" src="https://i.iplsc.com/koronawirus-w-polsce-ministerstwo-zdrowia-opublikowalo-tygod/000AOSFTSXANGA2F-C321.jpg" /></a>Mamy 3 895 zakażeń koronawirusem, z czego 747 to ponowne przypadki. Z powodu COVID-19 zmarło 21 osób, z powodu współistnienia koronawirusa z innymi schorzeniami zmarły 42 osoby. Dane Ministerstwa Zdrowia obejmują okres od 27 października do 2 listopada. </p><br clear="all" />

## Tatry. Te znaki wprawiają turystów w zdumienie. "Poniekąd racja"
 - [https://wydarzenia.interia.pl/malopolskie/news-tatry-te-znaki-wprawiaja-turystow-w-zdumienie-poniekad-racja,nId,6385321](https://wydarzenia.interia.pl/malopolskie/news-tatry-te-znaki-wprawiaja-turystow-w-zdumienie-poniekad-racja,nId,6385321)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 08:57:00+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-tatry-te-znaki-wprawiaja-turystow-w-zdumienie-poniekad-racja,nId,6385321"><img align="left" alt="Tatry. Te znaki wprawiają turystów w zdumienie. &quot;Poniekąd racja&quot;" src="https://i.iplsc.com/tatry-te-znaki-wprawiaja-turystow-w-zdumienie-poniekad-racja/000GA7HIUURBAINR-C321.jpg" /></a>W Tatrach pojawiły się nowe znaki, które wprawiają turystów w zdumienie. Ich celem jest przypomnienie, że Tatrzański Park Narodowy nie jest miejscem, w którym potrzeby fizjologiczne można załatwić w dowolnym miejscu. </p><br clear="all" />

## Surrealistyczny widok w Londynie. Gigantyczne bombki sparaliżowały ruch
 - [https://wydarzenia.interia.pl/zagranica/news-surrealistyczny-widok-w-londynie-gigantyczne-bombki-sparaliz,nId,6385383](https://wydarzenia.interia.pl/zagranica/news-surrealistyczny-widok-w-londynie-gigantyczne-bombki-sparaliz,nId,6385383)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 08:48:07+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-surrealistyczny-widok-w-londynie-gigantyczne-bombki-sparaliz,nId,6385383"><img align="left" alt="Surrealistyczny widok w Londynie. Gigantyczne bombki sparaliżowały ruch " src="https://i.iplsc.com/surrealistyczny-widok-w-londynie-gigantyczne-bombki-sparaliz/000GA7WJUQ8X06W4-C321.jpg" /></a>&quot;Atak&quot; gigantycznych bombek bożonarodzeniowych na ulicach Londynu. Kierowcy w popłochu omijali sunące wprost na nich ozdoby, by uniknąć kolizji. Jak się okazało, bombki szykowane do corocznego spektaklu wymknęły się organizatorom spod kontroli.</p><br clear="all" />

## Rozłam u antyszczepionkowców. Justyna Socha nie jest już prezesem STOP NOP
 - [https://wydarzenia.interia.pl/kraj/news-rozlam-u-antyszczepionkowcow-justyna-socha-nie-jest-juz-prez,nId,6385365](https://wydarzenia.interia.pl/kraj/news-rozlam-u-antyszczepionkowcow-justyna-socha-nie-jest-juz-prez,nId,6385365)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 08:47:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rozlam-u-antyszczepionkowcow-justyna-socha-nie-jest-juz-prez,nId,6385365"><img align="left" alt="Rozłam u antyszczepionkowców. Justyna Socha nie jest już prezesem STOP NOP" src="https://i.iplsc.com/rozlam-u-antyszczepionkowcow-justyna-socha-nie-jest-juz-prez/000GA7SVFQF0PJMK-C321.jpg" /></a>&quot;W obliczu absurdalnych pomówień wobec mnie od dwóch członków stowarzyszenia, złożyłam rezygnację z funkcji Prezesa Ogólnopolskiego Stowarzyszenia Wiedzy o Szczepieniach STOP NOP&quot; - poinformowała w mediach społecznościowych Justyna Socha. Stowarzyszenie wydało w tej sprawie oświadczenie. Poinformowano w nim, że do prokuratury został złożony wniosek o możliwości popełnienia przestępstwa przez Sochę.</p><br clear="all" />

## Larry - kot z Downing Street. Premierzy się zmieniają, a on trwa
 - [https://wydarzenia.interia.pl/ciekawostki/news-larry-kot-z-downing-street-premierzy-sie-zmieniaja-a-on-trwa,nId,6385358](https://wydarzenia.interia.pl/ciekawostki/news-larry-kot-z-downing-street-premierzy-sie-zmieniaja-a-on-trwa,nId,6385358)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 08:45:53+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-larry-kot-z-downing-street-premierzy-sie-zmieniaja-a-on-trwa,nId,6385358"><img align="left" alt="Larry - kot z Downing Street. Premierzy się zmieniają, a on trwa" src="https://i.iplsc.com/larry-kot-z-downing-street-premierzy-sie-zmieniaja-a-on-trwa/000GA7KXLAL78J0E-C321.jpg" /></a>&quot;Rishi Sunak został premierem, jego rodzina jest dziana, więc oczekuję, że teraz będę miał w menu kawior i homara&quot; - można przeczytać na Twitterze Larry'ego, kota z Downing Street numer 10. Tak, na Twitterze. Choć to fake'owe konto kota urzędującego w siedzibie premiera Wielkiej Brytanii, to jest tak popularne, że Larry stał się nie tylko maskotką, ale i dyżurnym komentatorem dość zawiłej ostatnio brytyjskiej polityki. Może sobie na to pozwolić, przeżył - w ciągu nieco ponad 10 lat - pięciu premierów.</p><br clear="all" />

## Straż Graniczna: 124 osoby próbowały dostać się z Białorusi do Polski
 - [https://wydarzenia.interia.pl/podlaskie/news-straz-graniczna-124-osoby-probowaly-dostac-sie-z-bialorusi-d,nId,6385363](https://wydarzenia.interia.pl/podlaskie/news-straz-graniczna-124-osoby-probowaly-dostac-sie-z-bialorusi-d,nId,6385363)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 08:19:53+00:00

<p><a href="https://wydarzenia.interia.pl/podlaskie/news-straz-graniczna-124-osoby-probowaly-dostac-sie-z-bialorusi-d,nId,6385363"><img align="left" alt="Straż Graniczna: 124 osoby próbowały dostać się z Białorusi do Polski" src="https://i.iplsc.com/straz-graniczna-124-osoby-probowaly-dostac-sie-z-bialorusi-d/000GA7TBFJIV09BT-C321.jpg" /></a>124 osoby próbowały we wtorek dostać się nielegalnie z Białorusi do Polski. 18 Egipcjan przeprawiło się przez graniczną rzekę Świsłocz - przekazała Straż Graniczna. W całym październiku odnotowano łącznie ok. 2,5 tys. prób nielegalnego przekroczenia granicy.</p><br clear="all" />

## Nastolatkowie oskarżeni o brutalny mord. Absurdalny motyw zbrodni
 - [https://wydarzenia.interia.pl/zagranica/news-nastolatkowie-oskarzeni-o-brutalny-mord-absurdalny-motyw-zbr,nId,6385348](https://wydarzenia.interia.pl/zagranica/news-nastolatkowie-oskarzeni-o-brutalny-mord-absurdalny-motyw-zbr,nId,6385348)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 07:59:47+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nastolatkowie-oskarzeni-o-brutalny-mord-absurdalny-motyw-zbr,nId,6385348"><img align="left" alt="Nastolatkowie oskarżeni o brutalny mord. Absurdalny motyw zbrodni " src="https://i.iplsc.com/nastolatkowie-oskarzeni-o-brutalny-mord-absurdalny-motyw-zbr/000GA7EKC5OYVK4X-C321.jpg" /></a>Dwaj nastoletni uczniowie liceum ze stanu Iowa zasiądą w grudniu na ławie oskarżonych w sprawie brutalnego morderstwa. Prokuratura zarzuca im, że zamordowali swoją nauczycielkę hiszpańskiego. Zdaniem śledczych motyw morderstwa był szokująco absurdalny. </p><br clear="all" />

## Dramatyczne sceny w Szczecinie. Kobieta wypadła z okna na 10. piętrze
 - [https://wydarzenia.interia.pl/wiadomosci-lokalne/news-dramatyczne-sceny-w-szczecinie-kobieta-wypadla-z-okna-na-10-,nId,6385285](https://wydarzenia.interia.pl/wiadomosci-lokalne/news-dramatyczne-sceny-w-szczecinie-kobieta-wypadla-z-okna-na-10-,nId,6385285)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 07:36:00+00:00

<p><a href="https://wydarzenia.interia.pl/wiadomosci-lokalne/news-dramatyczne-sceny-w-szczecinie-kobieta-wypadla-z-okna-na-10-,nId,6385285"><img align="left" alt="Dramatyczne sceny w Szczecinie. Kobieta wypadła z okna na 10. piętrze" src="https://i.iplsc.com/dramatyczne-sceny-w-szczecinie-kobieta-wypadla-z-okna-na-10/0004XOUQAHNQTW1I-C321.jpg" /></a>Dramatyczne sceny rozegrały się na osiedlu przy ul. Wilczej w Szczecinie. Z jednego z okien wieżowca na 10. piętrze wypadła ok. 30-letnia kobieta. Jej życia nie udało się uratować.</p><br clear="all" />

## Sondaż. Większość Polaków popiera pomoc przeciwnikom Putina
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-sondaz-wiekszosc-polakow-popiera-pomoc-przeciwnikom-putina,nId,6385295](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-sondaz-wiekszosc-polakow-popiera-pomoc-przeciwnikom-putina,nId,6385295)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 06:45:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-sondaz-wiekszosc-polakow-popiera-pomoc-przeciwnikom-putina,nId,6385295"><img align="left" alt="Sondaż. Większość Polaków popiera pomoc przeciwnikom Putina" src="https://i.iplsc.com/sondaz-wiekszosc-polakow-popiera-pomoc-przeciwnikom-putina/000742R2M2EV55B4-C321.jpg" /></a>48 proc. ankietowanych w sondażu IBRIS opowiedziało się za tym, by Polska przyjmowała i pomagała działaczom rosyjskiej opozycji - przeciwnikom Władimira Putina. Przeciwnego zdania jest 42,5 proc. respondentów - podaje &quot;Rzeczpospolita&quot;.</p><br clear="all" />

## Prognoza pogody. IMGW ostrzega przed gęstymi mgłami
 - [https://wydarzenia.interia.pl/kraj/news-prognoza-pogody-imgw-ostrzega-przed-gestymi-mglami,nId,6385272](https://wydarzenia.interia.pl/kraj/news-prognoza-pogody-imgw-ostrzega-przed-gestymi-mglami,nId,6385272)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 06:40:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prognoza-pogody-imgw-ostrzega-przed-gestymi-mglami,nId,6385272"><img align="left" alt="Prognoza pogody. IMGW ostrzega przed gęstymi mgłami" src="https://i.iplsc.com/prognoza-pogody-imgw-ostrzega-przed-gestymi-mglami/000DNJDTVSCBKY6V-C321.jpg" /></a>W środę pogodę nad znaczną częścią Polski napłynie zatoka niżowa z frontem chłodnym. Jak powiedziała synoptyk IMGW-PIB Ilona Bazyluk, najmniejsze szanse na opady będą mieli mieszkańcy Małopolski i Górnego Śląska oraz centralnej części kraju. Wydano również pierwszy stopień ostrzeżenia przed mgłami dla północno-wschodniej części kraju. </p><br clear="all" />

## Niespokojnie na granicy polsko-rosyjskiej. Oświadczenie ministra obrony narodowej
 - [https://wydarzenia.interia.pl/kraj/news-niespokojnie-na-granicy-polsko-rosyjskiej-oswiadczenie-minis,nId,6385292](https://wydarzenia.interia.pl/kraj/news-niespokojnie-na-granicy-polsko-rosyjskiej-oswiadczenie-minis,nId,6385292)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 06:36:54+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-niespokojnie-na-granicy-polsko-rosyjskiej-oswiadczenie-minis,nId,6385292"><img align="left" alt="Niespokojnie na granicy polsko-rosyjskiej. Oświadczenie ministra obrony narodowej" src="https://i.iplsc.com/niespokojnie-na-granicy-polsko-rosyjskiej-oswiadczenie-minis/000G87D762U532YS-C321.jpg" /></a>- Już dziś rozpoczną się pracę podjęte przez saperów w sprawie zbudowania tymczasowej zapory na granicy z obwodem kaliningradzkim - powiedział wicepremier, minister obrony narodowej Mariusz Błaszczak. Szef MON dodał, że pojawiły się niepokojące informacje, że lotnisko w obwodzie Kaliningradzkim zostało otwarte dla lotów z Bliskiego Wschodu i Afryki Północnej. </p><br clear="all" />

## Nowe zasady w sycylijskiej gminie. Konfiskata auta za zaśmiecanie
 - [https://wydarzenia.interia.pl/zagranica/news-nowe-zasady-w-sycylijskiej-gminie-konfiskata-auta-za-zasmiec,nId,6385263](https://wydarzenia.interia.pl/zagranica/news-nowe-zasady-w-sycylijskiej-gminie-konfiskata-auta-za-zasmiec,nId,6385263)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 05:54:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nowe-zasady-w-sycylijskiej-gminie-konfiskata-auta-za-zasmiec,nId,6385263"><img align="left" alt="Nowe zasady w sycylijskiej gminie. Konfiskata auta za zaśmiecanie" src="https://i.iplsc.com/nowe-zasady-w-sycylijskiej-gminie-konfiskata-auta-za-zasmiec/000GA68S3O5MS31W-C321.jpg" /></a>Władze miejscowości Santa Croce Camerina na Sycylii wprowadziły nowe przepisy, które przewidują konfiskatę samochodu za nielegalne wyrzucanie śmieci. Burmistrz miasta chce w ten sposób walczyć z nielegalnymi wysypiskami śmieci. Jego stanowcze decyzje są wskazywane we Włoszech jako wzór. 
</p><br clear="all" />

## "Umowa zbożowa zostanie przedłużona". Statki mają przepłynąć przez korytarz
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-umowa-zbozowa-zostanie-przedluzona-statki-maja-przeplynac-pr,nId,6385265](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-umowa-zbozowa-zostanie-przedluzona-statki-maja-przeplynac-pr,nId,6385265)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 05:50:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-umowa-zbozowa-zostanie-przedluzona-statki-maja-przeplynac-pr,nId,6385265"><img align="left" alt="&quot;Umowa zbożowa zostanie przedłużona&quot;. Statki mają przepłynąć przez korytarz" src="https://i.iplsc.com/umowa-zbozowa-zostanie-przedluzona-statki-maja-przeplynac-pr/000GA68YCABQU0E3-C321.jpg" /></a>ONZ potwierdziła, że &quot;inicjatywa zbożowa&quot; zostanie przedłużona 3 listopada - poinformował na Twitterze minister infrastruktury Ukrainy Ołeksandr Kubrakow. Wcześniej koordynator ONZ ds. umowy zbożowej na Morzu Czarnym Amir Abdulla przekazał, że spodziewa się, że załadowane statki wypłyną z portów w czwartek.</p><br clear="all" />

## Korea Północna wystrzeliła pociski. Korea Południowa odpowiada i zamyka część dróg powietrznych
 - [https://wydarzenia.interia.pl/zagranica/news-korea-polnocna-wystrzelila-pociski-korea-poludniowa-odpowiad,nId,6385266](https://wydarzenia.interia.pl/zagranica/news-korea-polnocna-wystrzelila-pociski-korea-poludniowa-odpowiad,nId,6385266)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 05:32:34+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-korea-polnocna-wystrzelila-pociski-korea-poludniowa-odpowiad,nId,6385266"><img align="left" alt="Korea Północna wystrzeliła pociski. Korea Południowa odpowiada i zamyka część dróg powietrznych" src="https://i.iplsc.com/korea-polnocna-wystrzelila-pociski-korea-poludniowa-odpowiad/000GA6816H0LWUHW-C321.jpg" /></a>Korea Północna wystrzeliła w środę rano czasu lokalnego 10 pocisków różnego rodzaju w kierunku wschodnim i zachodnim - poinformowała agencja Reutera, która powołuje się na armię Korei Południowej. Jak przekazano, co najmniej jedna rakieta spadła w pobliżu wybrzeża południowokoreańskiego. W odpowiedzi na działania Korei Północnej, Korea Południowa wystrzeliła trzy pociski powietrze-ziemia.</p><br clear="all" />

## Pekin umacnia wpływy w Niemczech. "Bild" wymienił lobbujących polityków
 - [https://wydarzenia.interia.pl/zagranica/news-pekin-umacnia-wplywy-w-niemczech-bild-wymienil-lobbujacych-p,nId,6385264](https://wydarzenia.interia.pl/zagranica/news-pekin-umacnia-wplywy-w-niemczech-bild-wymienil-lobbujacych-p,nId,6385264)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 05:20:38+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-pekin-umacnia-wplywy-w-niemczech-bild-wymienil-lobbujacych-p,nId,6385264"><img align="left" alt="Pekin umacnia wpływy w Niemczech. &quot;Bild&quot; wymienił lobbujących polityków" src="https://i.iplsc.com/pekin-umacnia-wplywy-w-niemczech-bild-wymienil-lobbujacych-p/000GA67GGA2G337S-C321.jpg" /></a>Niemieccy politycy, prowadząc interesy z Chinami i lobbując na ich rzecz, szkodzą swojemu krajowi – przestrzegały niedawno w Bundestagu Federalna Służba Wywiadowcza i Urząd Ochrony Konstytucji. Według &quot;Bilda&quot; gospodarka weszła w &quot;bolesną zależność&quot; od polityki, a &quot;dyktatura komunistyczna jest jeszcze bardziej niebezpieczna, niż Rosja&quot;. Gazeta wymieniła byłych polityków, którzy zabiegają o &quot;wzmocnienie wpływów Pekinu w Niemczech&quot;.</p><br clear="all" />

## Wojna w Ukrainie. 252. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo,nzId,3308,akt,020549](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo,nzId,3308,akt,020549)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 04:38:30+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo,nzId,3308,akt,020549"><img align="left" alt="Wojna w Ukrainie. 252. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo/000GA667RXD4EQH6-C321.jpg" /></a>Najnowsze wydarzenia z frontu.</p><br clear="all" />

## Wojna w Ukrainie. 252. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo,nzId,3308,akt,020637](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo,nzId,3308,akt,020637)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 04:38:30+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo,nzId,3308,akt,020637"><img align="left" alt="Wojna w Ukrainie. 252. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo/000GA667RXD4EQH6-C321.jpg" /></a>Najnowsze wydarzenia z frontu.</p><br clear="all" />

## Wojna w Ukrainie. 252. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo,nzId,3308,akt,020735](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo,nzId,3308,akt,020735)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 04:38:30+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo,nzId,3308,akt,020735"><img align="left" alt="Wojna w Ukrainie. 252. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo/000GA667RXD4EQH6-C321.jpg" /></a>Najnowsze wydarzenia z frontu.</p><br clear="all" />

## Wojna w Ukrainie. 252. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo,nzId,3308,akt,020758](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo,nzId,3308,akt,020758)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 04:38:30+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo,nzId,3308,akt,020758"><img align="left" alt="Wojna w Ukrainie. 252. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo/000GA667RXD4EQH6-C321.jpg" /></a>Najnowsze wydarzenia z frontu.</p><br clear="all" />

## Wojna w Ukrainie. 252. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo,nzId,3308,akt,020833](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo,nzId,3308,akt,020833)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 04:38:30+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo,nzId,3308,akt,020833"><img align="left" alt="Wojna w Ukrainie. 252. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo/000GA667RXD4EQH6-C321.jpg" /></a>Najnowsze wydarzenia z frontu.</p><br clear="all" />

## Wojna w Ukrainie. 252. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo,nzId,3308,akt,020900](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo,nzId,3308,akt,020900)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-02 04:38:30+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo,nzId,3308,akt,020900"><img align="left" alt="Wojna w Ukrainie. 252. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-252-dzien-inwazji-rosji-relacja-na-zywo/000GA667RXD4EQH6-C321.jpg" /></a>Najnowsze wydarzenia z frontu.</p><br clear="all" />


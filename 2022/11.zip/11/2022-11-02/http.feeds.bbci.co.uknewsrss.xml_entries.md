# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Ben Chilwell: Chelsea left-back an England doubt for World Cup after hamstring injury
 - [https://www.bbc.co.uk/sport/football/63494358?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63494358?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 23:54:56+00:00

England left-back Ben Chilwell is a doubt for the World Cup after suffering a hamstring injury in Chelsea's Champions League win against Dinamo Zagreb.

## Rico Lewis: Pep Guardiola hails 'dream' Manchester City teenager
 - [https://www.bbc.co.uk/sport/football/63490166?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63490166?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 23:47:51+00:00

Pep Guardiola hails 17-year-old Rico Lewis' Champions League night to remember and says Manchester City "know he has quality".

## Iran protests: The dance video I dared not share
 - [https://www.bbc.co.uk/news/world-middle-east-63486897?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-63486897?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 23:46:12+00:00

Dancer Sarina was banned from performing but is now sharing her work in solidarity with protesting women.

## Paris Masters: Rafael Nadal loses to Thomas Paul with Dan Evans and Jack Draper eliminated
 - [https://www.bbc.co.uk/sport/tennis/63484284?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/63484284?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 23:25:58+00:00

Rafael Nadal is beaten by Thomas Paul at Paris Masters while Britons Dan Evans and Jack Draper are also eliminated.

## Migrant girl begs for help in message in a bottle
 - [https://www.bbc.co.uk/news/uk-63494181?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63494181?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 22:54:27+00:00

The child likens an overcrowded facility in Kent to a prison, in a letter thrown over its fence.

## Albania PM says UK language on migrants fuelling xenophobia
 - [https://www.bbc.co.uk/news/uk-63492218?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63492218?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 22:51:06+00:00

Edi Rama strongly criticises "rhetoric" blaming his citizens for the UK's crime and border problems.

## Mariah Carey's 'All I want for Christmas is you' copyright lawsuit dropped
 - [https://www.bbc.co.uk/news/world-asia-63492412?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-63492412?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 22:39:54+00:00

A copyright claim against the hit song All I Want for Christmas is You has been withdrawn.

## Chelsea 2-1 Dinamo Zagreb: Denis Zakaria scores on his Chelsea debut
 - [https://www.bbc.co.uk/sport/football/63479244?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63479244?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 22:05:58+00:00

Denis Zakaria scores on his Chelsea debut as the Blues round off their successful Champions League Group E campaign with victory against Dinamo Zagreb.

## Manchester Arena bomb hero says response was all wrong
 - [https://www.bbc.co.uk/news/uk-england-manchester-63486473?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-63486473?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 22:00:03+00:00

A man who fought to save a victim of the 2017 Manchester bombing says "big mistakes" were made.

## Rugby League World Cup: Reigning champions Australia score 14 tries in Cook Islands thrashing
 - [https://www.bbc.co.uk/sport/rugby-league/63492509?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-league/63492509?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 21:48:07+00:00

Champions Australia ran in 14 tries as they routed Cook Islands 74-0 to open their women's Rugby League World Cup in York.

## Son Heung-min: South Korea forward could miss World Cup
 - [https://www.bbc.co.uk/sport/football/63492456?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63492456?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 21:37:52+00:00

Tottenham forward Son Heung-min is to have surgery to stabilise a fracture around his left eye which could rule him out of the World Cup.

## Gymnastics World Championships: Great Britain fight back to win bronze in men's team final
 - [https://www.bbc.co.uk/sport/av/gymnastics/63494061?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/gymnastics/63494061?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 21:35:48+00:00

Watch highlights as Great Britain fight back to climb from eighth place to win bronze in the men's team final at the Gymnastics World Championships.

## Magic-mushroom drug can treat severe depression, trial suggests
 - [https://www.bbc.co.uk/news/health-63475630?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-63475630?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 21:35:43+00:00

In a trial, 25mg of psilocybin put patients in a dreamlike state, making therapy more likely to succeed.

## Rugby World Cup: England's Claudia MacDonald and Hannah Botterman start
 - [https://www.bbc.co.uk/sport/rugby-union/63493462?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/63493462?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 21:30:12+00:00

Wing Claudia MacDonald returns from injury and prop Hannah Botterman starts as England make two changes for their World Cup semi-final against Canada.

## Yorkshire: ECB disciplinary hearings to take place in public
 - [https://www.bbc.co.uk/sport/cricket/63346054?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/63346054?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 20:20:08+00:00

Disciplinary proceedings over charges resulting from racism allegations at Yorkshire will take place in public.

## Real Madrid 5-1 Celtic: Scottish champions routed in final group game
 - [https://www.bbc.co.uk/sport/football/63447097?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63447097?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 19:33:38+00:00

Celtic ended a frustrating Champions League campaign in grim fashion as Real Madrid handed out a rough lesson to claim victory and top Group F.

## Russian commanders discussed using nuclear arms in Ukraine, says US
 - [https://www.bbc.co.uk/news/world-europe-63488547?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63488547?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 19:10:18+00:00

Military leaders are said to have talked about how and when they might use the weapons in Ukraine.

## Albanian migrants: Why are they coming to the UK and how many have arrived?
 - [https://www.bbc.co.uk/news/explainers-63473022?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/explainers-63473022?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 18:53:37+00:00

Why are Albanian migrants coming to the UK and how many have arrived?

## Suella Braverman told Kent at 'breaking point' over migrant care
 - [https://www.bbc.co.uk/news/uk-england-kent-63488316?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-kent-63488316?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 18:46:08+00:00

Leaders warn Suella Braverman of potential disorder and more strains placed on public services.

## Driver and cyclist near misses caught on camera
 - [https://www.bbc.co.uk/news/uk-63492215?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63492215?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 18:39:32+00:00

New research by BBC Panorama highlights the strained relationship between the road users.

## Don't blame us for UK border problems, says Albanian PM
 - [https://www.bbc.co.uk/news/uk-politics-63489276?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63489276?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 18:38:59+00:00

The UK is "discriminating" against Albanians to excuse "policy failures", PM Edi Rama says.

## Ethiopia's Tigray conflict: Truce agreed
 - [https://www.bbc.co.uk/news/world-africa-63490546?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-63490546?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 18:38:15+00:00

Both sides agree to stop their conflict which has led to a humanitarian crisis and warnings of a famine.

## Cold, hungry migrants stranded in London after error
 - [https://www.bbc.co.uk/news/uk-63489901?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63489901?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 18:13:39+00:00

The group were moved out of an overcrowded facility in Kent but given nowhere to stay, the BBC is told.

## Emma Raducanu: Briton's injury 'under control' says Anne Keothavong
 - [https://www.bbc.co.uk/sport/tennis/63491204?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/63491204?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 17:51:21+00:00

Emma Raducanu's wrist injury is "under control" according to her Billie Jean King Cup captain Anne Keothavong.

## James Corden and Ricky Gervais: Can you steal a joke?
 - [https://www.bbc.co.uk/news/newsbeat-63483918?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-63483918?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 17:32:16+00:00

The Late Late Show comedian claims he inadvertently used a joke originally performed by Ricky Gervais.

## Warning of fewer rental properties as landlords squeezed
 - [https://www.bbc.co.uk/news/business-63486784?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63486784?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 17:10:06+00:00

Difficulties for some landlords to secure mortgages could mean less choice for tenants, MPs are told.

## Chris Mason: Life under the 'don't know yet' government
 - [https://www.bbc.co.uk/news/uk-politics-63486668?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63486668?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 17:02:34+00:00

Amid economic uncertainty, Rishi Sunak's team are pausing to work out to do next, writes Chris Mason.

## Youngest person to use prosthetic legs with computerised knees
 - [https://www.bbc.co.uk/news/uk-england-bristol-63486321?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-bristol-63486321?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 16:44:32+00:00

Harmonie-Rose has been training with an assistance dog to help her do tasks.

## PMQs: Fact-checking claims about asylum and migrants
 - [https://www.bbc.co.uk/news/63489695?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/63489695?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 16:24:22+00:00

There were a number of claims made about the asylum system at Prime Minister's Questions.

## Wayne Couzens: PCs in WhatsApp group with Sarah Everard killer jailed
 - [https://www.bbc.co.uk/news/uk-england-62995926?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-62995926?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 16:17:37+00:00

Two Met PCs shared grossly offensive messages on WhatsApp with Sarah Everard's killer Wayne Couzens.

## FA concerned over rise in 'abhorrent chants' about Hillsborough tragedy
 - [https://www.bbc.co.uk/sport/football/63490856?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63490856?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 16:14:39+00:00

The Football Association has expressed concerns over the rise of "abhorrent chants" related to the Hillsborough disaster.

## Rishi Sunak to review leadership campaign pledges
 - [https://www.bbc.co.uk/news/uk-politics-63488785?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63488785?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 15:45:53+00:00

The prime minster will look at whether his promises are still deliverable, his spokeswoman says.

## Ronnie Radford: Iconic FA Cup goalscorer dies aged 79
 - [https://www.bbc.co.uk/sport/football/63489122?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63489122?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 15:41:39+00:00

Ronnie Radford, scorer of one of the most memorable goals in FA Cup history, dies at the age of 79.

## England v Argentina: Marcus Smith, Owen Farrell & Manu Tuilagi set to take on Pumas
 - [https://www.bbc.co.uk/sport/rugby-union/63485795?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/63485795?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 15:22:12+00:00

England prepare to unleash a midfield combination of Marcus Smith, Owen Farrell and Manu Tuilagi when they face Argentina on Sunday.

## Alice Capsey among six players awarded first England Women central contracts
 - [https://www.bbc.co.uk/sport/cricket/63489263?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/63489263?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 15:12:33+00:00

Alice Capsey is among six players who have been awarded England Women central contracts for the first time for the 2022-23 season.

## Rosie Cooper: MP at centre of murder plot criticises 'stupid' ITV drama
 - [https://www.bbc.co.uk/news/entertainment-arts-63487213?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63487213?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 15:01:40+00:00

Rosie Cooper delivers a stinging criticism of a TV series about the story behind a plot to kill her.

## Heavyweight Anthony Joshua says he wants to fight 'good opponents' like Otto Wallin and Dillian Whyte
 - [https://www.bbc.co.uk/sport/boxing/63470282?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/63470282?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 14:47:37+00:00

British heavyweight Anthony Joshua says he is willing to fight Dillian Whyte in a rematch on his return to action next year.

## Rishi Sunak admits not enough asylum claims are being processed
 - [https://www.bbc.co.uk/news/uk-politics-63486665?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63486665?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 14:29:25+00:00

Rishi Sunak promises to fix the system, but Keir Starmer says the government has "lost control".

## How much could your mortgage rise? Try our calculator
 - [https://www.bbc.co.uk/news/business-63474582?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63474582?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 14:25:54+00:00

Use our calculator to find out how much mortgage payments could go up for your household.

## UK battery firm staff agree to November pay cut
 - [https://www.bbc.co.uk/news/business-63483666?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63483666?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 13:26:29+00:00

About 300 staff at Britishvolt have agreed to take a temporary pay cut as the company battles to stay afloat.

## T20 World Cup: India boost semi-final chances with five-run win over Bangladesh
 - [https://www.bbc.co.uk/sport/cricket/63485093?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/63485093?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 12:52:28+00:00

India boost their semi-final chances with a tense five-run win over Bangladesh in a rain-affected encounter at the Men's T20 World Cup in Adelaide.

## NHS boss Amanda Pritchard says patients not always getting care they deserve
 - [https://www.bbc.co.uk/news/health-63403846?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-63403846?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 12:40:24+00:00

Challenge facing health service greater than it was at peak of pandemic, says Amanda Pritchard.

## Scotland and England to meet at Hampden next year
 - [https://www.bbc.co.uk/sport/football/63486791?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63486791?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 12:31:12+00:00

Scotland will host England at Hampden next year to mark the first ever international match between the two sides in 1872.

## West Lane: Teenagers died after failures at 'unstable' hospital
 - [https://www.bbc.co.uk/news/uk-england-tees-63472700?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-tees-63472700?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 12:15:28+00:00

Christie Harnett, Nadia Sharif and Emily Moore took their own lives within months of each other.

## Tinder: More people pay for dating app despite cost of living crisis
 - [https://www.bbc.co.uk/news/business-63483904?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63483904?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 11:55:46+00:00

But the dating app's owner warns that the global economic slowdown is starting to take its toll.

## T20 World Cup: Bangladesh's Litton Das run out in controversial circumstances against India
 - [https://www.bbc.co.uk/sport/av/cricket/63486279?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/63486279?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 11:49:37+00:00

Bangladesh's Litton Das is furious after being run out on a wet pitch in the T20 World Cup match against India in Adelaide.

## Anzac XV: Combined Australia & New Zealand team could play Lions in 2025
 - [https://www.bbc.co.uk/sport/rugby-union/63485787?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/63485787?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 11:20:45+00:00

An 'Anzac' XV featuring players from Australia and New Zealand may face the British and Irish Lions as part of their tour Down Under in 2025.

## Census: Number of foreign-born people in England and Wales reaches 10 million
 - [https://www.bbc.co.uk/news/uk-63485073?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63485073?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 11:18:09+00:00

The 2021 census counted 10 million people living in England and Wales who were born outside the UK.

## The 'superheroes' catching drug dealers in Peru
 - [https://www.bbc.co.uk/news/world-latin-america-63483024?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-63483024?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 10:54:45+00:00

Peruvian police arrest four suspects in Lima, with officers masquerading as Marvel characters.

## World Cup 2022: England manager Gareth Southgate criticised for Qatar worker comments
 - [https://www.bbc.co.uk/sport/football/63482319?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63482319?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 10:53:50+00:00

England manager Gareth Southgate is criticised by human rights groups after he said workers in Qatar are "united" in wanting the World Cup to go ahead.

## Rishi Sunak is now going to COP27 climate summit
 - [https://www.bbc.co.uk/news/uk-politics-63484971?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63484971?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 10:28:05+00:00

Downing Street had argued the prime minister was too busy preparing for the budget.

## Migos rapper Takeoff killed by 'stray bullet', record label claims
 - [https://www.bbc.co.uk/news/entertainment-arts-63483768?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63483768?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 09:37:50+00:00

The star, who was 28, died on Tuesday night after an altercation at a bowling alley in Houston.

## What is climate change? A really simple guide
 - [https://www.bbc.co.uk/news/science-environment-24021772?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-24021772?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 09:23:25+00:00

World temperatures are rising because of human activity, threatening every aspect of human life.

## Screams heard in Halloween crush emergency calls
 - [https://www.bbc.co.uk/news/world-asia-63481769?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-63481769?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 08:36:24+00:00

Calls made to Korean police hours before a fatal crush reveal how the horrifying incident unfolded.

## Rugby League World Cup: England welcome Stuart Pearce and thump Greece
 - [https://www.bbc.co.uk/sport/rugby-league/63469320?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-league/63469320?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 08:12:52+00:00

In his BBC Sport column, England's George Williams discusses a visit from Stuart Pearce and relives captaincy against Greece.

## T20 World Cup: Zimbabwe fielder Milton Shumba loses trousers after embarrassing misfield
 - [https://www.bbc.co.uk/sport/av/cricket/63482734?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/63482734?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 08:12:32+00:00

Watch the moment Zimbabwe fielder Milton Shumba loses his trousers whilst attempting to stop a Netherlands boundary in the T20 World Cup in Australia.

## Shaunagh Brown column: 'It's scary when retirement thoughts creep in'
 - [https://www.bbc.co.uk/sport/rugby-union/63466548?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/63466548?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 07:08:42+00:00

As England prop Shaunagh Brown prepares for Saturday's World Cup semi-final, she considers the "scary" question of retirement.

## 'My dad, the claw hair clip inventor'
 - [https://www.bbc.co.uk/news/world-africa-63401869?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-63401869?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 07:05:05+00:00

BBC journalist Anne-Marie Dias Borges tells how her foster father invented the iconic claw hair clip.

## Cost of living: Man takes on four jobs to keep his business afloat
 - [https://www.bbc.co.uk/news/uk-england-kent-63304500?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-kent-63304500?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 06:18:38+00:00

Lee Murthwaite is seeing a 400% increase in energy bills at the recording studio he owns.

## Records of gay military sackings deleted by Ministry of Defence
 - [https://www.bbc.co.uk/news/uk-63400761?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63400761?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 06:09:20+00:00

Police records of military personnel who were dismissed for being gay have been destroyed, the BBC finds.

## What do Hancock's constituents think about his TV jungle trip?
 - [https://www.bbc.co.uk/news/uk-england-suffolk-63472625?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-suffolk-63472625?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 06:08:44+00:00

Constituents in the seat of Matt Hancock air their views as he announces he will join the ITV show.

## Royal Mail postal workers to strike on Black Friday
 - [https://www.bbc.co.uk/news/business-63478657?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63478657?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 06:00:30+00:00

Around 115,000 Royal Mail workers plan to walk out on four days in dispute over pay, a union says.

## Ukraine war: Russia's uncertain future a product of its past
 - [https://www.bbc.co.uk/news/world-europe-63471505?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63471505?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 05:32:30+00:00

Russia's invasion of Ukraine is making its future uncertain - but so too is its authoritarian past.

## Matt Hancock defends joining I'm A Celebrity cast
 - [https://www.bbc.co.uk/news/uk-63481685?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63481685?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 05:27:40+00:00

The ex-health secretary says politicians should "go where the people are" and not "sit in ivory towers".

## Manston migrant centre like a zoo, says asylum seeker
 - [https://www.bbc.co.uk/news/uk-63481151?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63481151?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 04:33:21+00:00

Up to 130 people were forced to share a tent, a former resident at the Manston centre tells the BBC.

## Taronga Zoo: Five lions escape exhibit at Sydney zoo
 - [https://www.bbc.co.uk/news/world-australia-63467137?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-63467137?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 04:21:03+00:00

The zoo was put in lockdown and one animal had to be tranquillised during the brief emergency.

## Victim stalked for almost 20 years calls sentence 'an insult'
 - [https://www.bbc.co.uk/news/uk-63472325?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63472325?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 02:38:16+00:00

Claire Waxman says the criminal justice system treats victims "appallingly" and needs to be reviewed.

## North Korea: Air raid warning triggered after Pyongyang launches missiles
 - [https://www.bbc.co.uk/news/world-asia-63481183?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-63481183?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 01:49:56+00:00

Residents in the remote South Korean island of Ulleungdo were told to seek shelter in bunkers.

## Police vetting lets in wrong people too often - report
 - [https://www.bbc.co.uk/news/uk-63478011?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63478011?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 01:35:58+00:00

Decisions to let officers join or stay in the police can be "questionable at best", a watchdog says.

## The Papers: 'Predators' join police and 'king of the bungle'
 - [https://www.bbc.co.uk/news/blogs-the-papers-63480801?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-63480801?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 01:06:30+00:00

Many papers focus on fury over Matt Hancock joining TV show I'm A Celebrity... Get Me Out Of Here!

## How Tottenham won Champions League group on dramatic night in Marseille
 - [https://www.bbc.co.uk/sport/football/63479282?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63479282?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 00:15:13+00:00

It was a topsy-turvy night in Group D as Tottenham did it the hard way to progress to the last 16 of the Champions League.

## Shirley Manson: 'Garbage got it in the neck from everyone'
 - [https://www.bbc.co.uk/news/entertainment-arts-63463129?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63463129?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 00:06:28+00:00

The singer reflects on how the band survived 30 years, and tells the stories behind their best songs.

## CEO Secrets: Sarah Willingham on impostor syndrome
 - [https://www.bbc.co.uk/news/business-63457629?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63457629?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 00:03:40+00:00

Sarah Willingham, CEO of Nightcap and former star of TV show Dragons' Den, shares her CEO Secret.

## Mangrove forests: Crocodile close-up in Cuba wins photo awards
 - [https://www.bbc.co.uk/news/in-pictures-63472199?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-63472199?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 00:02:51+00:00

The Mangrove Photography Award winners show unique ecosystems above and below the waterline.

## Cost of a cup of tea rising as food prices jump
 - [https://www.bbc.co.uk/news/business-63474304?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63474304?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 00:01:21+00:00

Prices for tea bags, milk and sugar all rose significantly in October, according to latest figures.

## Morbi bridge collapse: How a tourist spot became a bridge of death
 - [https://www.bbc.co.uk/news/world-asia-india-63477292?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-63477292?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 00:01:14+00:00

One of India's worst disasters for years left 135 people dead - how did it happen?

## Prison job advert banned for racial stereotyping
 - [https://www.bbc.co.uk/news/business-63458435?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63458435?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 00:01:13+00:00

The photo of a black inmate and white officer was likely to cause serious offence, a watchdog found.

## Champions League: The 30 years of change shaping Europe's biggest prize
 - [https://www.bbc.co.uk/sport/football/63456291?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63456291?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 00:00:14+00:00

Just over 30 years ago Europe's premier club competition was relaunched as the Champions League. Bigger changes are on the way.

## The Ukrainian jet pilots hunting cruise missiles
 - [https://www.bbc.co.uk/news/world-europe-63465297?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63465297?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-02 00:00:03+00:00

Russia has launched hundreds of missiles and drone attacks on Ukraine in the past few weeks.


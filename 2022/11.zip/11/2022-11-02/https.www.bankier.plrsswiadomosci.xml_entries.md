# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Powell zatrzymał szarżę byków. Mocne spadki na giełdach w USA
 - [https://www.bankier.pl/wiadomosc/Powell-zatrzymal-szarze-bykow-Mocne-spadki-na-gieldach-w-USA-8432895.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Powell-zatrzymal-szarze-bykow-Mocne-spadki-na-gieldach-w-USA-8432895.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 20:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/3/1bde314ce845c1-945-560-43-61-3456-2073.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Niespełna godzinę trwał "gołębi piwot" władz Fedu. 
Komunikat opublikowany po posiedzeniu FOMC wywołał szarżę byków na Wall 
Street, ale kilkadziesiąt minut później jastrzębimi wypowiedziami zatrzymał ją prezes Jerome Powell.</p>

## "Bezkarność Plus" i lex Czarnek w Sejmie. Posłowie zmienią też regulamin
 - [https://www.bankier.pl/wiadomosc/Bezkarnosc-Plus-i-lex-Czarnek-w-Sejmie-Poslowie-zmienia-tez-regulamin-8432882.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bezkarnosc-Plus-i-lex-Czarnek-w-Sejmie-Poslowie-zmienia-tez-regulamin-8432882.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 19:18:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/b/a1bf795147da47-948-568-120-50-3800-2280.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Projektem PiS ws. legalności przekazywania danych wyborców poczcie podczas wyborów w pandemii, a także dwoma projektami: poselskim i prezydenckim, nowelizacji ustawy Prawo oświatowe - zajmie się Sejm na rozpoczynającym się w czwartek dwudniowym posiedzeniu.</p>

## PGE uruchomi platformę do handlu energią elektryczną
 - [https://www.bankier.pl/wiadomosc/PGE-uruchomi-platforme-do-handlu-energia-elektryczna-8432868.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PGE-uruchomi-platforme-do-handlu-energia-elektryczna-8432868.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 18:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/d/48b3ac2d41c918-948-568-0-88-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PGE będzie prowadzić handel energią elektryczną na własnej platformie w naszym domu maklerskim - poinformował PAP prezes spółki Wojciech Dąbrowski. PGE jest największym krajowym wytwórcą energii elektrycznej.</p>

## Skorygowana strata netto grupy Polenergia w III kw. wyniosła 11,3 mln zł
 - [https://www.bankier.pl/wiadomosc/Skorygowana-strata-netto-grupy-Polenergia-w-III-kw-wyniosla-11-3-mln-zl-8432864.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Skorygowana-strata-netto-grupy-Polenergia-w-III-kw-wyniosla-11-3-mln-zl-8432864.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 18:18:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/6/5ad7a556f428c8-945-567-69-20-2705-1623.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Skorygowana strata netto grupy Polenergia w trzecim kwartale 2022 roku wyniosła 11,3 mln zł - poinformowała spółka w szacunkowych danych. W okresie trzech kwartałów 2022 roku skorygowany zysk netto grupy spadł do 107,7 mln zł</p>

## 75-ki weszły Powellowi w krew. Czwarta taka podwyżka w Fedzie
 - [https://www.bankier.pl/wiadomosc/Fed-podnosi-stopy-procentowe-listopad-2022-8432794.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Fed-podnosi-stopy-procentowe-listopad-2022-8432794.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 18:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/9/40a31910189a2a-948-568-0-68-3872-2323.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Federalny Komitet Otwartego Rynku (FOMC) zdecydował się na czwartą z rzędu 75-punktową podwyżkę stóp procentowych. W efekcie cena pieniądza w Fedzie znalazła się na najwyższym poziomie od stycznia 2008 roku.</p>

## "Washington Post": administracja USA rozważa ingerencję w przejęcie Twittera z uwagi na udział Saudów i Chińczyków
 - [https://www.bankier.pl/wiadomosc/Washington-Post-administracja-USA-rozwaza-ingerencje-w-przejecie-Twittera-z-uwagi-na-udzial-Saudow-i-Chinczykow-8432855.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Washington-Post-administracja-USA-rozwaza-ingerencje-w-przejecie-Twittera-z-uwagi-na-udzial-Saudow-i-Chinczykow-8432855.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 17:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/7/7bbd291b184825-948-568-2-71-1019-611.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Administracja Joe Bidena rozważa przeprowadzenie formalnego przeglądu przejęcia Twittera przez Elona Muska - podał w środę "Washington Post". Według dziennika, transakcja dała dostęp do poufnych danych - w tym potencjalnie dotyczących użytkowników Twittera - inwestorom związanym z Arabią Saudyjską i Chinami.</p>

## Miliony na wynagrodzenia, a efektów pracy brak. Posłowie prześwietlają spółkę Pałac Saski
 - [https://www.bankier.pl/wiadomosc/Miliony-na-wynagrodzenia-a-efektow-pracy-brak-Poslowie-przeswietlaja-spolke-Palac-Saski-8432833.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Miliony-na-wynagrodzenia-a-efektow-pracy-brak-Poslowie-przeswietlaja-spolke-Palac-Saski-8432833.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 17:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/8/5c082e47906ee5-948-568-5-293-2382-1429.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W imieniu Spółki Pałac Saski podtrzymuję deklarację pełnej transparentności - napisał w środowym oświadczeniu prezes Zarządu Spółki Pałac Saski Jan Edmund Kowalski odpowiadając na zarzuty stawiane spółce przez posłów KO -Dariusza Jońskiego i Michała Szczerbę</p>

## Skubianka odzyskana. Ośrodek nad Zegrzem dzierżawiony przez Rosjan przejęty przez Lasy Państwowe
 - [https://www.bankier.pl/wiadomosc/Skubianka-odzyskana-Osrodek-na-Zegrzem-dzierzawiony-przez-Rosjan-przejety-przez-Lasy-Panstowe-8432816.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Skubianka-odzyskana-Osrodek-na-Zegrzem-dzierzawiony-przez-Rosjan-przejety-przez-Lasy-Panstowe-8432816.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 16:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/e/4ac43ab9f50098-948-568-24-97-4866-2919.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ośrodek dzierżawiony przez ambasadę rosyjską nad Zalewem Zegrzyńskim został przejęty przez Lasy Państwowe (LP) - poinformował w środę wiceminister klimatu i środowiska Edward Siarka. Dodał, że po inwentaryzacji i ocenie biegłych zaproponowane zostanie nowe zagospodarowania terenu.</p>

## Kruk zastąpi PGNiG w WIG20 po sesji 4 listopada 2022 r.
 - [https://www.bankier.pl/wiadomosc/Kruk-zastapi-PGNiG-w-WIG20-po-sesji-4-listopada-2022-r-8432811.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kruk-zastapi-PGNiG-w-WIG20-po-sesji-4-listopada-2022-r-8432811.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 16:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/f/c824e591b30ac8-798-479-20-29-798-479.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kruk zastąpi PGNiG w indeksie WIG20 po sesji 4 listopada 2022 r, w indeksie WIG30 w miejsce PGNIG zostanie wpisana Bogdanka, a w indeksie mWIG40 w miejsce Kruka trafi ZE PAK - poinformowała GPW Benchmark w komunikacie.</p>

## Od 2024 zakaz wytwarzania i wprowadzania do obrotu pasz GMO. Rząd przyjął projekt
 - [https://www.bankier.pl/wiadomosc/Od-2024-zakaz-wytwarzania-i-wprowadzania-do-obrotu-pasz-GMO-Rzad-przyjal-projekt-8432796.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Od-2024-zakaz-wytwarzania-i-wprowadzania-do-obrotu-pasz-GMO-Rzad-przyjal-projekt-8432796.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 16:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/8/6baf9b90c2773b-792-475-5-0-792-475.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od 1 stycznia 2024 r. wejdzie w życie zakaz wytwarzania, wprowadzania do obrotu i stosowania w żywieniu zwierząt pasz genetycznie zmodyfikowanych - wynika z przyjętego w środę przez rząd projektu nowelizacji, o którym poinformowała KPRM.</p>

## Wzrostowe otwarcie listopada na GPW. Przecena Bumechu - inwestorzy liczyli na więcej
 - [https://www.bankier.pl/wiadomosc/Wzrostowe-otwarcie-listopada-na-GPW-Przecena-Bumechu-inwestorzy-liczyli-na-wiecej-8432768.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wzrostowe-otwarcie-listopada-na-GPW-Przecena-Bumechu-inwestorzy-liczyli-na-wiecej-8432768.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 16:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/4/a42ca6f1319839-945-560-7-78-1492-895.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od zieleni na głównych indeksach rozpoczął się listopad na polskiej giełdzie. Środowa sesja upłynęła pod znakiem wzrostów sektora energetycznego i paliwowego oraz bardzo dobrej postawy producentów gier. Negatywnie wyróżnił się kurs węglowego Bumechu.</p>

## Biały Dom: Korea Północna dostarcza Rosji amunicję artyleryjską
 - [https://www.bankier.pl/wiadomosc/Bialy-Dom-Korea-Polnocna-dostarcza-Rosji-amunicje-artyleryjska-8432747.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bialy-Dom-Korea-Polnocna-dostarcza-Rosji-amunicje-artyleryjska-8432747.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 15:29:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/6/586729cb9f6fbe-945-560-567-97-2819-1691.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Korea Północna dostarcza Rosji znaczące ilości amunicji artyleryjskiej - poinformował w środę rzecznik Rady Bezpieczeństwa Narodowego John Kirby. Zaznaczył jednak, że dostawy te nie zmienią kierunku wojny w Ukrainie. Przyznał jednocześnie, że rośnie niepokój dotyczący potencjalnego użycia broni jądrowej przez Rosję, choć nie ma sygnałów wskazujących na przygotowania do takiego uderzenia.</p>

## Kto uzależnił Polskę od Rosji? Rząd chce komisji weryfikacyjnej
 - [https://www.bankier.pl/wiadomosc/Kto-uzaleznil-Polske-od-Rosji-Rzad-chce-komisji-weryfikacyjnej-8432720.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kto-uzaleznil-Polske-od-Rosji-Rzad-chce-komisji-weryfikacyjnej-8432720.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 14:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/6/21d558d0e3cc6d-948-568-0-0-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jestem zwolennikiem powołania komisji weryfikacyjnej do zbadania potencjalnych działań i kontaktów służących uzależnieniu Polski od Rosji. W ciągu dwóch tygodni zostanie przygotowany projekt ustawy, która by tę kwestię regulowała - powiedział w środę premier Mateusz Morawiecki.</p>

## Zmiany w VAT? Premier o powrocie do pierwotnych stawek podatkowych
 - [https://www.bankier.pl/wiadomosc/Zmiany-w-VAT-Premier-o-powrocie-do-pierwotnych-stawek-podatkowych-8432711.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zmiany-w-VAT-Premier-o-powrocie-do-pierwotnych-stawek-podatkowych-8432711.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 14:41:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/9/8e89894157557b-948-568-75-70-1925-1154.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Decyzja w sprawie zakresu powrotu do pierwotnych stawek podatkowych zapadnie w grudniu – powiedział w środę podczas konferencji prasowej premier Mateusz Morawiecki.</p>

## Będą świadczenia dla rodzin poległych mundurowych
 - [https://www.bankier.pl/wiadomosc/Beda-swiadczenia-dla-rodzin-poleglych-mundurowych-8432673.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Beda-swiadczenia-dla-rodzin-poleglych-mundurowych-8432673.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 14:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/3/dd76383b462493-948-568-2-7-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przygotowaliśmy projekt ustawy o świadczeniach pieniężnych dla rodzin funkcjonariuszy i żołnierzy poległych na służbie - poinformował w środę minister spraw wewnętrznych i administracji Mariusz Kamiński. Projekt ma jeszcze w tym roku trafić do Sejmu, a nowe rozwiązania wejść w życie w 2023 roku.</p>

## Wybór Westinghouse to szansa dla kilku spółek z GPW
 - [https://www.bankier.pl/wiadomosc/Wybor-Westinghouse-to-szansa-dla-kilku-spolek-z-GPW-8432625.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wybor-Westinghouse-to-szansa-dla-kilku-spolek-z-GPW-8432625.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 13:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/4/35e4085dc3aed5-948-568-2-2-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ogłoszenie partnera do budowy pierwszej polskiej elektrowni atomowej rodzi nowe możliwości dla polskich firm, które mają szansę być zaangażowane w wielomiliardowy projekt. Z wieloma spółkami z GPW amerykańscy wykonawcy nawiązali współpracę już wiele miesięcy temu.</p>

## Rząd przyjął uchwałę dot. realizacji projektu jądrowego we współpracy z Westinghouse
 - [https://www.bankier.pl/wiadomosc/Rzad-przyjal-uchwale-dot-realizacji-projektu-jadrowego-we-wspolpracy-z-Westinghouse-8432660.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-przyjal-uchwale-dot-realizacji-projektu-jadrowego-we-wspolpracy-z-Westinghouse-8432660.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 13:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/d/a329dc28495295-948-568-0-69-1024-614.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rada Ministrów przyjęła uchwałę dotyczącą realizacji projektu jądrowego w technologii we współpracy z amerykańską firmą Westinghouse Nuclear - poinformował w środę premier Mateusz Morawiecki.</p>

## Twórcy serialu "Wielka woda" bez tantiem. Winne polskie prawo
 - [https://www.bankier.pl/wiadomosc/Tworcy-serialu-Wielka-woda-bez-tantiem-Winne-polskie-prawo-8432549.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tworcy-serialu-Wielka-woda-bez-tantiem-Winne-polskie-prawo-8432549.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 13:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/2/127133b7ef2513-948-568-187-0-2812-1687.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Choć wyprodukowany przez Netflix serial "Wielka woda" odniósł całkiem spory sukces, jego twórcy nie mają co liczyć w Polsce na tantiemy - informuje portal wirtualnemedia.pl. Powodem jest krajowe prawo, wciąż niedostosowane do przepisów ogólnoeuropejskich. Środowiska twórcze od dawna apelują do resortu kultury o nowelizację przepisów o prawie autorskim.

</p>

## Żywność i paliwa. To tu podwyżki bolą najbardziej
 - [https://www.bankier.pl/wiadomosc/Zywnosc-i-paliwa-To-tu-podwyzki-bola-najbardziej-8432627.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zywnosc-i-paliwa-To-tu-podwyzki-bola-najbardziej-8432627.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 13:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/2/7eb067074aaf0f-948-568-10-80-1990-1193.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polacy coraz silniej odczuwają skutki wzrostu cen. W październiku silne lub bardzo silne odczuwanie inflacji deklarowało 86 proc. badanych – wynika z sondażu przeprowadzonego przez CBOS.</p>

## Londyn nakłada sankcje na kolejnych rosyjskich oligarchów
 - [https://www.bankier.pl/wiadomosc/Londyn-naklada-sankcje-na-kolejnych-rosyjskich-oligarchow-8432594.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Londyn-naklada-sankcje-na-kolejnych-rosyjskich-oligarchow-8432594.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 12:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/8/91d40fbfc9c434-948-567-0-30-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wielka Brytania nałożyła w środę sankcje na czterech rosyjskich oligarchów z sektora stalowego i petrochemicznego, którzy, jak wskazano, ułatwiają prezydentowi Rosji Władimirowi Putinowi prowadzenie wojny na Ukrainie.</p>

## Polska elektrownia jądrowa. Rząd zdradził preferowaną lokalizację
 - [https://www.bankier.pl/wiadomosc/Polska-elektrownia-jadrowa-Rzad-zdradzil-preferowana-lokalizacje-8432566.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-elektrownia-jadrowa-Rzad-zdradzil-preferowana-lokalizacje-8432566.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 11:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/9/59b3e537fcb954-948-568-262-745-3024-1814.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Akceptację dla oferty amerykańskiej oraz wybór technologii Westinghouse AP1000 dla budowy pierwszej polskiej elektrowni jądrowej we wskazanej przez inwestora - jako preferowanej - lokalizacji Lubiatowo-Kopalino - przewiduje projekty uchwały rządu ws. budowy wielkoskalowych elektrowni jądrowych.</p>

## Francja "przymknie oko" na nielegalnych imigrantów, ale stawia warunek
 - [https://www.bankier.pl/wiadomosc/Francja-przymknie-oko-na-nielegalnych-imigrantow-ale-stawia-warunek-8432546.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Francja-przymknie-oko-na-nielegalnych-imigrantow-ale-stawia-warunek-8432546.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 11:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/1/d2bed0b3b730ba-945-560-7-41-1492-895.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Francuscy ministrowie spraw wewnętrznych Gerald Darmanin i pracy Olivier Dussopt zaproponowali zaostrzenie przepisów dotyczących deportacji cudzoziemców za granicę oraz przyznawanie tytułów pobytu dla pracowników bez dokumentów pobytowych, pracujących w sektorach, w których brakuje siły roboczej.</p>

## Tydzień bez prądu. Na to szykują się Brytyjczycy
 - [https://www.bankier.pl/wiadomosc/Tydzien-bez-pradu-Na-to-szykuja-sie-Brytyjczycy-8432541.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tydzien-bez-pradu-Na-to-szykuja-sie-Brytyjczycy-8432541.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 11:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/b/d134277aaea0f4-948-567-0-25-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Brytyjski rząd przeprowadza ćwiczenia, aby poradzić sobie z przerwami w dostawie energii trwającymi do siedmiu dni, które mogą pojawić się w efekcie kryzysu energetycznego - podał w środę dziennik "Guardian".</p>

## Maksymalna cena prądu staje się faktem. Ustawa podpisana
 - [https://www.bankier.pl/wiadomosc/Maksymalna-cena-pradu-staje-sie-faktem-Ustawa-podpisana-8432526.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Maksymalna-cena-pradu-staje-sie-faktem-Ustawa-podpisana-8432526.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 11:18:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/7/0c2b2f235e1ae2-948-568-0-209-2263-1357.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Andrzej Duda podpisał w środę ustawę o maksymalnych cenach energii dla gospodarstw domowych, sektora MŚP i samorządów. W 2023 r. gospodarstwa domowe po przekroczeniu limitów mają zapłacić nie więcej niż 693 zł za MWh, a samorządy i MŚP - 785 zł za MWh.</p>

## Sprzedaż węgla przez samorządy. Jest podpis prezydenta
 - [https://www.bankier.pl/wiadomosc/Sprzedaz-wegla-przez-samorzady-Jest-podpis-prezydenta-8432520.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sprzedaz-wegla-przez-samorzady-Jest-podpis-prezydenta-8432520.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 11:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/5/90bc3f07797dfb-948-568-0-59-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Andrzej Duda podpisał ustawę o dystrybucji węgla przez samorządy - poinformowała w środę KPRP. Gminy, spółki gminne i związki gminne będą mogły kupować węgiel za maksymalnie 1,5 tys. zł za tonę, a sprzedawać go mieszkańcom za nie więcej niż 2 tys. zł za tonę.</p>

## Prezes Obajtek pokieruje ogromną firmą. Duży awans płockiej spółki
 - [https://www.bankier.pl/wiadomosc/Prezes-Obajtek-pokieruje-ogromna-firma-Duzy-awans-plockiej-spolki-8432489.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezes-Obajtek-pokieruje-ogromna-firma-Duzy-awans-plockiej-spolki-8432489.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/0/234d5b95053f40-948-568-0-0-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Fuzja PKN Orlen i PGNiG stała się faktem. Według prezesa Obajtka Orlen będzie wśród 150 największych firm na świcie. Na konferencji uściślił, że chodzi o przychody. Sprawdzamy, które miejsce zajmie PKN Orlen pod tym względem. </p>

## Żabka wprowadza "Kawonament". Wiemy już, ile kosztuje nowa usługa
 - [https://www.bankier.pl/wiadomosc/Kawonament-w-aplikacji-sklepu-Zabka-Siec-wprowadza-subskrypcje-na-kawe-8432388.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kawonament-w-aplikacji-sklepu-Zabka-Siec-wprowadza-subskrypcje-na-kawe-8432388.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 10:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/5/5d651afdbd5ad9-948-568-121-186-1610-966.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sieć sklepów Żabka wprowadziła do swojej oferty abonament na kawę z automatów. Klient, który opłaci miesięczną subskrypcję, będzie mógł odebrać jeden ciepły napój dziennie. Z usługi skorzystają użytkownicy aplikacji mobilnej Żappka. Wiemy już, ile dokładnie będzie to kosztować.  
</p>

## Erdogan: Inicjatywa zbożowa zostanie wznowiona w środę w południe
 - [https://www.bankier.pl/wiadomosc/Erdogan-Inicjatywa-zbozowa-zostanie-wznowiona-w-srode-w-poludnie-8432490.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Erdogan-Inicjatywa-zbozowa-zostanie-wznowiona-w-srode-w-poludnie-8432490.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 10:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/b/13f6287fa22ac3-948-568-0-45-1823-1093.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Inicjatywa zbożowa umożliwiająca eksport ukraińskich produktów rolnych zostanie wznowiona w środę w południe - powiedział prezydent Turcji Recep Tayyip Erdogan, powołując się na rosyjskiego ministra obrony Siergieja Szojgu, który miał go zapewnić o powrocie Rosji do porozumienia w tej sprawie.</p>

## Credit Agricole szacuje tempo wzrostu gospodarczego w IV kwartale
 - [https://www.bankier.pl/wiadomosc/Credit-Agricole-szacuje-tempo-wzrostu-gospodarczego-w-IV-kwartale-8432472.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Credit-Agricole-szacuje-tempo-wzrostu-gospodarczego-w-IV-kwartale-8432472.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 10:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/7/c99a18694cf702-945-560-115-256-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Tempo wzrostu gospodarczego spowolni do 0,5 proc. rdr w IV kwartale z 3,9 proc. w III kwartale br. - ocenił Krystian Jaworski z Credit Agricole w komentarzu do środowej publikacji indeksu PMI. Zwrócił uwagę, że w październiku firmy podniosły ceny towarów m.in. w związku ze wzrostem kosztów energii.</p>

## CPK ogłosił pierwszy przetarg na budowę tunelu dalekobieżnego pod Łodzią
 - [https://www.bankier.pl/wiadomosc/CPK-oglosil-pierwszy-przetarg-na-budowe-tunelu-dalekobieznego-pod-Lodzia-8432471.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/CPK-oglosil-pierwszy-przetarg-na-budowe-tunelu-dalekobieznego-pod-Lodzia-8432471.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 10:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/b/4d512431a410ac-948-568-20-105-1980-1187.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Centralny Port Komunikacyjny ogłosił pierwszy z przetargów budowlanych na budowę w Łodzi czterokilometrowego tunelu Kolei Dużych Prędkości, który będzie częścią linii Warszawa – CPK – Łódź – Sieradz – Wrocław. Prace mają ruszyć w 2023 r. na zachód od stacji Łódź Fabryczna.</p>

## DM BOŚ podwyższył cenę docelową akcji CD Projekt, ale dalej zaleca sprzedaż
 - [https://www.bankier.pl/wiadomosc/DM-BOS-podwyzszyl-cene-docelowa-akcji-CD-Projekt-do-106-zl-podtrzymali-zalecenie-sprzedaj-8432467.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/DM-BOS-podwyzszyl-cene-docelowa-akcji-CD-Projekt-do-106-zl-podtrzymali-zalecenie-sprzedaj-8432467.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 10:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/c/c54b190d2f5986-948-568-57-368-4550-2730.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Analitycy DM BOŚ, w raporcie z 25 października podwyższyli cenę docelową akcji CD Projekt do 106 zł za akcję, z 89 zł poprzednio oraz podtrzymali rekomendację sprzedaj/niedoważaj.</p>

## Serbia zwiększa gotowość bojową wojsk. Powodem Kosowo
 - [https://www.bankier.pl/wiadomosc/Serbia-zwieksza-gotowosc-bojowa-wojsk-Powodem-Kosowo-8432466.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Serbia-zwieksza-gotowosc-bojowa-wojsk-Powodem-Kosowo-8432466.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 10:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/4/6a436fcbfdab31-945-560-0-52-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W związku z sytuacją w Kosowie i aktywnością dronów obserwujących położenie serbskich wojsk Serbia podniosła stopień gotowości bojowej swojej armii - poinformował minister obrony Milosz Vuczević.</p>

## Viaplay pod lupą UOKiK. Transmisje meczów były dalekie od ideału
 - [https://www.bankier.pl/wiadomosc/Viaplay-pod-lupa-UOKiK-Transmisje-meczow-byly-dalekie-od-idealu-8432452.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Viaplay-pod-lupa-UOKiK-Transmisje-meczow-byly-dalekie-od-idealu-8432452.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 09:49:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/a/31d5f3cc3ffdd2-948-568-9-0-1910-1146.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wszczęto postępowanie wyjaśniające ws. serwisu streamingowego Viaplay transmitującego m.in. transmisje sportowe na żywo  - poinformował w środę Urząd Ochrony Konkurencji i Konsumentów.  Podał, że jeśli relacja została przerwana, konsumenci mogą składać reklamacje.</p>

## DM BOŚ podwyższył cenę docelową akcji JSW
 - [https://www.bankier.pl/wiadomosc/DM-BOS-podwyzszyl-cene-docelowa-akcji-JSW-podtrzymal-rekomendacje-kupuj-przewazaj-8432449.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/DM-BOS-podwyzszyl-cene-docelowa-akcji-JSW-podtrzymal-rekomendacje-kupuj-przewazaj-8432449.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 09:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/7/257f102ae0e2f5-945-560-270-1518-2669-1601.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Analitycy DM BOŚ, w raporcie z 25 października, podwyższyli cenę docelową akcji JSW do 100 zł, zł 70 zł poprzednio. Rekomendacja kupuj/przeważaj została podtrzymana.</p>

## Gigantyczna strata szwajcarskiego banku centralnego
 - [https://www.bankier.pl/wiadomosc/Gigantyczna-strata-szwajcarskiego-banku-centralnego-8432409.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gigantyczna-strata-szwajcarskiego-banku-centralnego-8432409.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 09:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/b/09bee23dd91131-948-568-0-94-1882-1129.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W pierwszej 9 miesiącach roku Szwajcarski Bank Narodowy
 zanotował stratę w wysokości ponad 140 mld franków. To najgorszy wynik
 w przeszło stuletniej historii banku.</p>

## Idzie zima, a węgla coraz mniej. Wydobycie we wrześniu najniższe od 2 lat
 - [https://www.bankier.pl/wiadomosc/Idzie-zima-a-wegla-coraz-mniej-Wydobycie-we-wrzesniu-najnizsze-od-2-lat-8432430.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Idzie-zima-a-wegla-coraz-mniej-Wydobycie-we-wrzesniu-najnizsze-od-2-lat-8432430.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 09:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/8/5e35a65443b665-948-568-0-0-1775-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polskie kopalnie we wrześniu br. wydobyły 3,8 mln ton węgla kamiennego, a sprzedały 3,7 mln ton. Miesięczna produkcja i sprzedaż krajowego surowca należały historycznie do najniższych - wynika z danych ARP. Mniej węgla było jedynie w maju 2020 r., kiedy kopalnie dotknęła pandemia.</p>

## Orlen chce postawić na zwiększenie poszukiwań i wydobycia
 - [https://www.bankier.pl/wiadomosc/PKN-Orlen-po-fuzji-z-PGNiG-chce-postawic-na-zwiekszenie-poszukiwan-i-wydobycia-8432431.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PKN-Orlen-po-fuzji-z-PGNiG-chce-postawic-na-zwiekszenie-poszukiwan-i-wydobycia-8432431.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 09:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/1/76bee45ebfac47-948-568-7-11-1464-878.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PKN Orlen po fuzji z PGNiG chce postawić na zwiększenie segmentu poszukiwań i wydobycia zarówno w Polsce, jak i na świecie, tam gdzie koncern posiada swoje koncesje - poinformował prezes Orlenu Daniel Obajtek.</p>

## PIE: w czwartym kwartale nastąpi wyraźne spowolnienie w przemyśle
 - [https://www.bankier.pl/wiadomosc/PIE-w-czwartym-kwartale-nastapi-wyrazne-spowolnienie-w-przemysle-8432411.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PIE-w-czwartym-kwartale-nastapi-wyrazne-spowolnienie-w-przemysle-8432411.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 09:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/a/67d2c87eed85a6-948-568-0-494-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W czwartym kwartale czeka nas wyraźne spowolnienia w przemyśle – koniec roku przyniesie wyniki bliskie stagnacji. Wzrost cen energii przekłada się na koszty produkcji, co oznacza inflację – oceniają analitycy PIE w komentarzu do środowej publikacji indeksu PMI.</p>

## Minister ds. UE: Złożymy wniosek do KE o wstrzymanie naliczania kar za Izbę Dyscyplinarną
 - [https://www.bankier.pl/wiadomosc/Minister-ds-UE-Zlozymy-wniosek-do-KE-o-wstrzymanie-naliczania-kar-za-Izbe-Dyscyplinarna-8432406.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Minister-ds-UE-Zlozymy-wniosek-do-KE-o-wstrzymanie-naliczania-kar-za-Izbe-Dyscyplinarna-8432406.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 08:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/d/27c7303ac2b7d5-948-568-50-50-3950-2369.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W najbliższych dniach złożymy wniosek do Komisji Europejskiej o wstrzymanie naliczania kar za Izbę Dyscyplinarną Sądu Najwyższego - zapowiedział minister ds. UE Szymon Szynkowski vel Sęk. Jak dodał, po wejściu w życie ustawy, która zniosła tę izbę, kary nie powinny być naliczane.</p>

## Lagarde: EBC musi podnosić stopy, nawet jeśli rośnie ryzyko recesji
 - [https://www.bankier.pl/wiadomosc/Lagarde-EBC-musi-podnosic-stopy-nawet-jesli-rosnie-ryzyko-recesji-8432392.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lagarde-EBC-musi-podnosic-stopy-nawet-jesli-rosnie-ryzyko-recesji-8432392.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 08:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/4/6331caff2372ff-948-568-0-52-1750-1049.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Europejski Bank Centralny musi nadal podnosić stopy procentowe, by 
powstrzymać inflację, nawet jeśli prawdopodobieństwo recesji w strefie 
euro wzrosło - powiedziała w opublikowanym we wtorek wywiadzie prezes 
Christine Lagarde.</p>

## Borys: Możliwy koniec tarczy antyinflacyjnej przez trudną sytuację budżetową
 - [https://www.bankier.pl/wiadomosc/Borys-Mozliwy-koniec-tarczy-antyinflacyjnej-przez-trudna-sytuacje-budzetowa-8432402.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Borys-Mozliwy-koniec-tarczy-antyinflacyjnej-przez-trudna-sytuacje-budzetowa-8432402.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 08:41:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/a/380c75c452a3b5-948-568-0-39-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Być może w tej sytuacji, w jakiej teraz jesteśmy, rząd nie będzie mógł przedłużyć tarczy antyinflacyjnej, zresztą w budżecie tego nie zakłada - powiedział w środę prezes Polskiego Funduszu Rozwoju Paweł Borys.</p>

## Twisto podnosi opłaty. 20 zł miesięcznie za kartę
 - [https://www.bankier.pl/wiadomosc/Twisto-podnosi-oplaty-20-zl-miesiecznie-za-karte-8432389.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Twisto-podnosi-oplaty-20-zl-miesiecznie-za-karte-8432389.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 08:19:00+00:00

<p>Specjalizujący się w płatnościach odroczonych fintech Twisto zapowiedział zmiany w swojej ofercie. Od stycznia pojawi się nowy plan taryfowy, a w starych pakietach wzrosną opłaty. Za fizyczną kartę trzeba będzie zapłacić już blisko 20 zł miesięcznie.</p>

## Koniec tarcz antyinflacyjnych? Kotecki: W lutym 24 proc. inflacji
 - [https://www.bankier.pl/wiadomosc/Koniec-tarcz-antyinflacyjnych-Kotecki-W-lutym-24-proc-inflacji-8432385.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-tarcz-antyinflacyjnych-Kotecki-W-lutym-24-proc-inflacji-8432385.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 08:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/1/40f16837d6ed1a-948-568-0-0-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Bez tarczy antyinflacyjnej inflacja w lutym osiągnie 24 proc. - powiedział w radiu TOK FM członek RPP Ludwik Kotecki. Koniec tarcz antyinflacyjnych w związku z sytuacją fiskalną państwa zapowiedział prezes PFR Paweł Borys.</p>

## Fatalne nastroje w polskim przemyśle. "Gwałtowny spadek nowych zamówień osłabia produkcję"
 - [https://www.bankier.pl/wiadomosc/Fatalne-nastroje-w-polskim-przemysle-Gwaltowny-spadek-nowych-zamowien-oslabia-produkcje-8432358.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Fatalne-nastroje-w-polskim-przemysle-Gwaltowny-spadek-nowych-zamowien-oslabia-produkcje-8432358.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 08:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/2/1d8c1194f1e541-948-568-11-70-4656-2793.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Niepewne warunki i wysoka inflacja tłumią optymizm biznesowy sektora 
przemysłowego w Polsce, tempo spadku zatrudnienia jest najszybsze od 
niemal 2,5 roku, a gwałtowny spadek nowych zamówień osłabia produkcję - wynika z badania S&amp;P Global PMI.</p>

## Bumech szacuje skons. przychody w I-III kw. na 824 mln zł, a EBITDA na 448 mln zł
 - [https://www.bankier.pl/wiadomosc/Bumech-szacuje-skons-przychody-w-I-III-kw-na-824-mln-zl-a-EBITDA-na-448-mln-zl-8432365.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bumech-szacuje-skons-przychody-w-I-III-kw-na-824-mln-zl-a-EBITDA-na-448-mln-zl-8432365.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 07:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/c/184e54eb2a0149-945-567-266-150-1233-740.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Bumech szacuje skonsolidowane przychody ze sprzedaży w pierwszych trzech kwartałach 2022 r. na 824 mln zł, EBIT na 369 mln zł, a EBITDA na 448 mln zł - podała spółka w komunikacie.</p>

## Asbis podał wysokość dywidendy zaliczkowej na akcję za '22
 - [https://www.bankier.pl/wiadomosc/Asbis-wyplaci-0-2-USD-dywidendy-zaliczkowej-na-akcje-za-22-8432361.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Asbis-wyplaci-0-2-USD-dywidendy-zaliczkowej-na-akcje-za-22-8432361.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 07:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/f/f0b4f9a5add4bd-945-567-101-101-4398-2639.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rada Dyrektorów Asbisu zdecydowała o wypłacie akcjonariuszom zaliczki na poczet przewidywanej dywidendy z zysku za 2022 r. w wysokości 11,1 mln USD - podała spółka w komunikacie. Zaliczka wyniesie 0,2 USD na akcję.</p>

## Biomed Lublin zaktualizował strategię rozwoju
 - [https://www.bankier.pl/wiadomosc/Biomed-Lublin-zaktualizowal-strategie-rozwoju-8432359.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Biomed-Lublin-zaktualizowal-strategie-rozwoju-8432359.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 07:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/e/8f9fe76ff1a8eb-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Biomed Lublin zaktualizował strategię rozwoju. Priorytetem strategicznym spółki pozostają produkty lecznicze BCG - podała spółka w komunikacie.</p>

## Zmiany w podatku Belki. Soboń zdradza daty
 - [https://www.bankier.pl/wiadomosc/Zmiany-w-podatku-Belki-Sobon-zdradza-daty-8432357.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zmiany-w-podatku-Belki-Sobon-zdradza-daty-8432357.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 07:49:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/5/17d94e0657bee9-948-568-0-12-1200-719.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zmiany w podatku Belki będą możliwe zapewne od 1 stycznia 2024 r., ale możliwe, że uda się je wprowadzić wcześniej – powiedział w środę w TVP 1 wiceminister finansów Artur Soboń.</p>

## Sasin: Niedługo decyzje ws. trzeciej elektrowni jądrowej
 - [https://www.bankier.pl/wiadomosc/Sasin-Niedlugo-decyzje-ws-trzeciej-elektrowni-jadrowej-8432351.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sasin-Niedlugo-decyzje-ws-trzeciej-elektrowni-jadrowej-8432351.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 07:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/a/3fa849414d572f-948-568-7-11-1492-895.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dziś rząd podejmie decyzje o wyborze strategicznego partnera budowy elektrowni jądrowej według technologii amerykańskiej, do końca roku będzie studium wykonalności elektrowni koreańskiej, a niedługo będzie wskazana lokalizacja i partner trzeciej elektrowni - powiedział w środę wicepremier Jacek Sasin.</p>

## Połączenie PKN Orlen i PGNiG wpisane do rejestru sądowego
 - [https://www.bankier.pl/wiadomosc/Polaczenie-PKN-Orlen-i-PGNiG-wpisane-do-rejestru-sadowego-8432340.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polaczenie-PKN-Orlen-i-PGNiG-wpisane-do-rejestru-sadowego-8432340.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 07:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/7/5f5a60c7fe9451-948-568-48-57-3157-1894-S5.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Połączenie PKN Orlen z PGNiG zostało wpisane do rejestru przedsiębiorców Krajowego Rejestru Sądowego przez Sąd Rejonowy dla Łodzi-Śródmieścia w Łodzi XX Wydział Gospodarczy KRS - poinformował PKN Orlen w komunikacie.</p>

## Będzie mur na granicy z Rosją. Błaszczak: podjąłem decyzję
 - [https://www.bankier.pl/wiadomosc/Bedzie-mur-na-granicy-z-Rosja-Blaszczak-podjalem-decyzje-8432338.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bedzie-mur-na-granicy-z-Rosja-Blaszczak-podjalem-decyzje-8432338.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 07:27:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/9/720c2c18998510-945-567-70-19-1841-1105.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podjąłem decyzję o budowie tymczasowej zapory na granicy Polski z obwodem kaliningradzkim, już dziś rozpoczną się prace - poinformował w środę wicepremier, szef MON Mariusz Błaszczak.</p>

## Największa fabryka iPhone’ów na świecie objęta ścisłym lockdownem
 - [https://www.bankier.pl/wiadomosc/Najwieksza-fabryka-iPhone-ow-na-swiecie-objeta-scislym-lockdownem-8432339.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najwieksza-fabryka-iPhone-ow-na-swiecie-objeta-scislym-lockdownem-8432339.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 07:27:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/a/b316578699cb20-945-560-0-134-1912-1147.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Strefa ekonomiczna wokół lotniska w chińskim mieście Zhengzhou, gdzie znajduje się największa na świecie fabryka składająca telefony marki Apple, została w środę objęta ścisłym lockdownem z powodu ogniska zakażeń koronawirusem – ogłosiły miejscowe władze.</p>

## Brytyjski MON: minimalne postępy grupy Wagnera na froncie
 - [https://www.bankier.pl/wiadomosc/Brytyjski-MON-minimalne-postepy-grupy-Wagnera-na-froncie-8432331.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Brytyjski-MON-minimalne-postepy-grupy-Wagnera-na-froncie-8432331.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 07:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/b/0d0a7526d27d3a-763-457-0-408-763-457.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Najemnicy z rosyjskiej grupy Wagnera dokonują na Ukrainie minimalnych postępów, posuwając się naprzód o 100-200 metrów dziennie, czyli znacznie mniej, niż zakłada rosyjska doktryna, i mniej niż obecne postępy sił ukraińskich - przekazało w środę brytyjskie ministerstwo obrony.</p>

## Koniec "zero Covid"? Chińskie akcje odbijają
 - [https://www.bankier.pl/wiadomosc/Koniec-zero-Covid-Chinskie-akcje-odbijaja-8432328.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-zero-Covid-Chinskie-akcje-odbijaja-8432328.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/9/c43ccdda5cdffb-948-568-11-292-4488-2693.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Internetowe plotki o szykowanym przez władze rozluźnieniu polityki "zero
 Covid" napędzają odbicie chińskich akcji. Nadzieje inwestorów mogą się 
okazać płonne.</p>

## Borys: RPP będzie musiała podnieść stopy procentowe
 - [https://www.bankier.pl/wiadomosc/Borys-RPP-bedzie-musiala-podniesc-stopy-procentowe-8432325.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Borys-RPP-bedzie-musiala-podniesc-stopy-procentowe-8432325.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 06:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/1/9892333dc9b372-948-568-0-31-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />RPP będzie musiała jeszcze dokonać kilku podwyżek stóp po 25 pb, głównie przez politykę FED - powiedział w TVN 24 prezes PFR Paweł Borys.</p>

## Ropa drożeje po mocnym spadku jej zapasów w USA
 - [https://www.bankier.pl/wiadomosc/Ropa-drozeje-po-mocnym-spadku-jej-zapasow-w-USA-8432323.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ropa-drozeje-po-mocnym-spadku-jej-zapasow-w-USA-8432323.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 06:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/9/99660f3d5de606-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny ropy na giełdzie paliw w Nowym Jorku rosną i podążają w kierunku 90 USD za baryłkę po danych o mocnym spadku amerykańskich zapasów surowca  - podają maklerzy.</p>

## Bank oszukiwał na podatku PIT. Wpadł podczas kontroli KAS
 - [https://www.bankier.pl/wiadomosc/Bank-oszukiwal-na-podatku-PIT-Wpadl-podczas-kontroli-KAS-8432321.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bank-oszukiwal-na-podatku-PIT-Wpadl-podczas-kontroli-KAS-8432321.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 06:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/7/e9fad44ed564ed-945-560-0-141-1669-1001.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Funkcjonariusze mazowieckiej Krajowej Administracji Skarbowej zakończyli kontrolę w jednym z banków. Podczas niej wykryli nieprawidłowości w PIT. Bank złożył korektę i dobrowolnie wpłacił prawie 8 milionów złotych zaległego podatku wraz z odsetkami.</p>

## Aplikacja do e-paragonów coraz bliżej
 - [https://www.bankier.pl/wiadomosc/Aplikacja-do-e-paragonow-coraz-blizej-8432305.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Aplikacja-do-e-paragonow-coraz-blizej-8432305.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 05:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/b/e11498f250984d-948-568-0-248-3679-2207.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ministerstwo Finansów pracuje nad upowszechnieniem e-paragonów – takich, które będzie można pobrać na smartfona. W przyszłym roku udostępni bezpłatną aplikację, ale liczy na to, że na rynku pojawią się podobne rozwiązania komercyjne – informuje w środę "Dziennik Gazeta Prawna”.</p>

## UE przyspiesza prace nad zielonym wodorem. Będą dodatkowe środki dla firm
 - [https://www.bankier.pl/wiadomosc/UE-przyspiesza-prace-nad-zielonym-wodorem-Beda-dodatkowe-srodki-dla-firm-8432304.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/UE-przyspiesza-prace-nad-zielonym-wodorem-Beda-dodatkowe-srodki-dla-firm-8432304.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 05:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/2/2a2cdef3b774d7-816-490-67-2-816-490.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W październiku na stronie Rządowego Centrum Legislacji pojawił się projekt nowelizacji ustawy Prawo energetyczne, który wprowadza zapisy potrzebne dla realizacji Polskiej Strategii Wodorowej. Projekt został już skierowany...</p>

## Sasin: Weryfikacja atomu z Korei nastąpi do końca tego roku
 - [https://www.bankier.pl/wiadomosc/Sasin-Weryfikacja-atomu-z-Korei-nastapi-do-konca-tego-roku-8432303.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sasin-Weryfikacja-atomu-z-Korei-nastapi-do-konca-tego-roku-8432303.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 05:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/e/876f0160fd4bca-948-568-0-76-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Za dwa miesiące zostanie wypracowane studium możliwości koreańskiego atomu, które określi m.in. wstępny harmonogram prac – zapowiedział w rozmowie z "Rzeczpospolitą” wicepremier, minister aktywów państwowych Jacek Sasin.</p>

## Warchoł: Chcemy karać za zdradę ojczyzny
 - [https://www.bankier.pl/wiadomosc/Warchol-Chcemy-karac-za-zdrade-ojczyzny-8432298.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Warchol-Chcemy-karac-za-zdrade-ojczyzny-8432298.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 05:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/3/0f137a701870b6-948-568-16-0-3184-1910.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Chcemy wreszcie karać za zdradę ojczyny, do tej pory karalny był jedynie udział w obcym wywiadzie; wprowadzamy do Kodeksu Karnego definicję działalności wywiadowczej - powiedział w wywiadzie dla środowego "Naszego Dziennika” wiceminister sprawiedliwości Marcin Warchoł.</p>

## Falenta: Nie spotkałem się z rosyjskimi służbami, nie sprzedałem nagrań
 - [https://www.bankier.pl/wiadomosc/Falenta-Nie-spotkalem-sie-z-rosyjskimi-sluzbami-nie-sprzedalem-nagran-8432295.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Falenta-Nie-spotkalem-sie-z-rosyjskimi-sluzbami-nie-sprzedalem-nagran-8432295.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 05:41:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/c/71864f4f8bad36-945-567-0-121-4403-2642.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nigdy nie spotkałem nikogo z rosyjskich służb i nigdy nikomu nie sprzedałem żadnych nagrań – twierdzi w opublikowanej w środę rozmowie z "Rzeczpospolitą” Marek Falenta.</p>

## Czarnek uważa, że w edukacji domowej działają "mafie oświatowe". I zapowiada większą kontrolę
 - [https://www.bankier.pl/wiadomosc/Czarnek-uwaza-ze-w-edukacji-domowej-dzialaja-mafie-oswiatowe-I-zapowiada-wieksza-kontrole-8432293.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czarnek-uwaza-ze-w-edukacji-domowej-dzialaja-mafie-oswiatowe-I-zapowiada-wieksza-kontrole-8432293.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 05:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/4/b986b89042383d-948-568-0-44-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Edukacja nie może być poza kontrolą organu nadzoru pedagogicznego. Nie może być tak, że nikt za jej jakość nie bierze odpowiedzialności – przekonuje w rozmowie z "Dziennikiem Gazetą Prawną” szef MEiN Przemysław Czarnek.</p>

## Odbudowa ukraińskiej gospodarki może kosztować bilion dolarów. "Potrzebne nowe otwarcie"
 - [https://www.bankier.pl/wiadomosc/Odbudowa-ukrainskiej-gospodarki-moze-kosztowac-bilion-dolarow-Potrzebne-nowe-otwarcie-8432289.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Odbudowa-ukrainskiej-gospodarki-moze-kosztowac-bilion-dolarow-Potrzebne-nowe-otwarcie-8432289.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 05:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/b/6ca3918a656807-948-568-0-132-1761-1056.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Osiem miesięcy działań wojennych Rosji w Ukrainie spowodowały w tym kraju straty idące w setki miliardów dolarów. Agresor zniszczył kilkadziesiąt tysięcy kilometrów dróg, a także...</p>

## Wielu pracowników obawia się postępującej robotyzacji. Eksperci uspokajają i wymieniają korzyści
 - [https://www.bankier.pl/wiadomosc/Wielu-pracownikow-obawia-sie-postepujacej-robotyzacji-Eksperci-uspokajaja-i-wymieniaja-korzysci-8432290.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wielu-pracownikow-obawia-sie-postepujacej-robotyzacji-Eksperci-uspokajaja-i-wymieniaja-korzysci-8432290.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 05:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/b/109a446101c878-945-567-37-107-933-560.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Robotyzacja ma przede wszystkim odciążyć pracowników od wykonywania monotonnych i powtarzalnych czynności. Choć wielu pracowników obawia się utraty pracy z powodu przejęcia ich obowiązków przez roboty,...</p>

## Ministerstwo Klimatu pracuje nad ograniczeniem cen gazu w 2023 r. dla gospodarstw domowych, ale też innych podmiotów
 - [https://www.bankier.pl/wiadomosc/Ministerstwo-Klimatu-pracuje-nad-ograniczeniem-cen-gazu-w-2023-r-dla-gospodarstw-domowych-ale-tez-innych-podmiotow-8432282.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ministerstwo-Klimatu-pracuje-nad-ograniczeniem-cen-gazu-w-2023-r-dla-gospodarstw-domowych-ale-tez-innych-podmiotow-8432282.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 05:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/8/9e93b95797190c-948-567-5-0-995-596.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przygotowywane rozwiązania dotyczące gazu odnosić się będą nie tylko do gospodarstw domowych, ale także innych podmiotów - cena gazu w 2023 r. ma zostać ograniczona - poinformowała PAP wiceminister klimatu i środowiska Anna Łukaszewska-Trzeciakowska.</p>

## Pieców na węgiel ubywa powoli, a zakazy za pasem. Coraz mniej szans na dopłaty
 - [https://www.bankier.pl/wiadomosc/Piecow-na-wegiel-ubywa-powoli-a-zakazy-za-pasem-Coraz-mniej-szans-na-doplaty-8431397.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Piecow-na-wegiel-ubywa-powoli-a-zakazy-za-pasem-Coraz-mniej-szans-na-doplaty-8431397.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/f/924eb3139bb8d1-948-568-0-34-1989-1193.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad 4,4 mln pieców wciąż "działa" na paliwa stałe – wynika z danych zawartych w Centralnej Ewidencji Emisyjności Budynków. Tymczasem już za dwa miesiące w pierwszych województwach zaczną obowiązywać zakazy palenia w piecach najgorszych klas. Rosnące koszty montażu nowoczesnych pieców, kurczące się miejskie dotacje i dopłaty węglowe nie ułatwiają walki z tzw. kopciuchami.</p>

## Praca kierowcy w dobie transformacji. Ofert wciąż nie brakuje, firmy kuszą też zarobkami
 - [https://www.bankier.pl/wiadomosc/Praca-kierowcy-w-dobie-transformacji-Ofert-wciaz-nie-brakuje-8426850.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Praca-kierowcy-w-dobie-transformacji-Ofert-wciaz-nie-brakuje-8426850.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/1/e9962548270dd4-948-568-0-57-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wprowadzenie pakietu mobilności, gospodarcze konsekwencje COVID-19, zaburzenia łańcuchów dostaw i dekarbonizacja sprawiają, że perspektywy dla kierowców nie są tak dobre jak jeszcze jakiś czas temu. Ofert pracy dla wykwalifikowanych kandydatów wciąż jednak nie brakuje. Do tego zawodu niezmiennie przyciągają również atrakcyjne zarobki.</p>

## Smart kontrakty, czyli co...? Zobacz drugi odcinek Akademii Blockchain
 - [https://www.bankier.pl/wiadomosc/Smart-Contract-Akademia-Blockchain-odcinek-02-8430486.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Smart-Contract-Akademia-Blockchain-odcinek-02-8430486.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/3/40d11a14a9c174-948-568-48-0-1800-1079.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Smart kontrakty w świecie blockchain. Czym są, jak działają, jak się ich
 używa i czy zawsze warto - o tym wszystkim w drugim odcinku Akademii 
Blockchain, edukacyjnej serii wideo realizowanej we współpracy z 
Bankier.pl. Zapraszamy do obejrzenia transmisji.</p>

## Wenezuela i Kolumbia zapowiedziały "całkowitą integrację" swoich gospodarek
 - [https://www.bankier.pl/wiadomosc/Wenezuela-i-Kolumbia-zapowiedzialy-calkowita-integracje-swoich-gospodarek-8432274.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wenezuela-i-Kolumbia-zapowiedzialy-calkowita-integracje-swoich-gospodarek-8432274.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 04:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/4/3715b7b741b8d9-945-560-0-54-4368-2620.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Lewicowi prezydenci Wenezueli i Kolumbii, Nicolas Maduro i Gustavo Petro, którzy odbyli we wtorek wielogodzinne dwustronne rozmowy w Caracas, zapowiedzieli iż oba kraje będą pracowały nad zacieśnianiem dwustronnej współpracy aż do "całkowitej integracji".</p>

## Płatny Twitter nadchodzi. Musk zdradził cenę
 - [https://www.bankier.pl/wiadomosc/Platny-Twitter-nadchodzi-Musk-zdradzil-cene-8432268.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Platny-Twitter-nadchodzi-Musk-zdradzil-cene-8432268.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 03:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/5/5e736578982efc-945-560-0-162-2400-1439.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nowy właściciel platformy Twitter Elon Musk zapowiedział wprowadzenie opłaty w wysokości 8 dolarów miesięcznie za zweryfikowane konta na Twitterze - poinformowała we wtorek agencja Reutera.</p>

## Frederiksen chce stworzyć nowy "szeroki" rząd Danii
 - [https://www.bankier.pl/wiadomosc/Frederiksen-chce-stworzyc-nowy-szeroki-rzad-Danii-8432267.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Frederiksen-chce-stworzyc-nowy-szeroki-rzad-Danii-8432267.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 03:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/d/7fc68ab1318c2d-945-560-30-120-2970-1781.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Socjaldemokratyczna premier Danii Mette Frederiksen po wygraniu wyborów parlamentarnych ogłosiła podanie się w środę do dymisji oraz zapowiedziała stworzenie nowego "szerokiego" rządu wbrew dotychczasowemu podziałowi na lewicę i prawicę.</p>

## Netanjahu prawdopodobnie wygrał wybory. Nacjonaliści z dużym poparciem
 - [https://www.bankier.pl/wiadomosc/Netanjahu-prawdopodobnie-wygral-wybory-Nacjonalisci-z-duzym-poparciem-8432260.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Netanjahu-prawdopodobnie-wygral-wybory-Nacjonalisci-z-duzym-poparciem-8432260.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-02 00:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/9/216cf4f7c66e11-945-560-0-11-1150-689.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nic jeszcze nie wiadomo, dopóki liczone są głosy - powiedział we wtorek premier Izraela Jair Lapid po ogłoszeniu wyników sondaży exit poll, dających zwycięstwo w wyborach parlamentarnych blokowi popierającemu Benjamina Netanjahu. Liderzy skrajnie nacjonalistycznego sojuszu Religijny Syjonizm cieszą się z trzeciego wyniku.</p>


# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Minecraft Running on Asahi Linux with Open Source GPU Drivers
 - [https://social.treehouse.systems/@alyssa/109378606742926582](https://social.treehouse.systems/@alyssa/109378606742926582)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 23:40:56+00:00

<p>Article URL: <a href="https://social.treehouse.systems/@alyssa/109378606742926582">https://social.treehouse.systems/@alyssa/109378606742926582</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33686782">https://news.ycombinator.com/item?id=33686782</a></p>
<p>Points: 49</p>
<p># Comments: 4</p>

## Username cannot contain 'clyde'
 - [https://old.reddit.com/r/discordapp/comments/ywjcep/cant_use_my_name/](https://old.reddit.com/r/discordapp/comments/ywjcep/cant_use_my_name/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 23:13:12+00:00

<p>Article URL: <a href="https://old.reddit.com/r/discordapp/comments/ywjcep/cant_use_my_name/">https://old.reddit.com/r/discordapp/comments/ywjcep/cant_use_my_name/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33686556">https://news.ycombinator.com/item?id=33686556</a></p>
<p>Points: 33</p>
<p># Comments: 4</p>

## Briar: Peer-to-Peer Encrypted Messaging
 - [https://briarproject.org/how-it-works/](https://briarproject.org/how-it-works/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 22:21:45+00:00

<p>Article URL: <a href="https://briarproject.org/how-it-works/">https://briarproject.org/how-it-works/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33686094">https://news.ycombinator.com/item?id=33686094</a></p>
<p>Points: 20</p>
<p># Comments: 4</p>

## Liquid and immersion is the new cool at Supercomputing '22
 - [https://www.theregister.com/2022/11/19/liquid_cooling_sc22/](https://www.theregister.com/2022/11/19/liquid_cooling_sc22/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 21:34:18+00:00

<p>Article URL: <a href="https://www.theregister.com/2022/11/19/liquid_cooling_sc22/">https://www.theregister.com/2022/11/19/liquid_cooling_sc22/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33685608">https://news.ycombinator.com/item?id=33685608</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## I hate living in my tiny house
 - [https://www.fastcompany.com/90407740/why-i-hate-living-in-my-tiny-house](https://www.fastcompany.com/90407740/why-i-hate-living-in-my-tiny-house)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 21:32:13+00:00

<p>Article URL: <a href="https://www.fastcompany.com/90407740/why-i-hate-living-in-my-tiny-house">https://www.fastcompany.com/90407740/why-i-hate-living-in-my-tiny-house</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33685588">https://news.ycombinator.com/item?id=33685588</a></p>
<p>Points: 33</p>
<p># Comments: 18</p>

## For some with ADHD, the low rumble of brown noise quiets the brain
 - [https://www.washingtonpost.com/wellness/2022/11/14/brown-noise-adhd-focus/](https://www.washingtonpost.com/wellness/2022/11/14/brown-noise-adhd-focus/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 21:30:37+00:00

<p>Article URL: <a href="https://www.washingtonpost.com/wellness/2022/11/14/brown-noise-adhd-focus/">https://www.washingtonpost.com/wellness/2022/11/14/brown-noise-adhd-focus/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33685567">https://news.ycombinator.com/item?id=33685567</a></p>
<p>Points: 39</p>
<p># Comments: 19</p>

## DOS/4GW and Protected Mode (2021)
 - [https://pikuma.com/blog/what-is-dos4gw-protected-mode](https://pikuma.com/blog/what-is-dos4gw-protected-mode)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 21:19:05+00:00

<p>Article URL: <a href="https://pikuma.com/blog/what-is-dos4gw-protected-mode">https://pikuma.com/blog/what-is-dos4gw-protected-mode</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33685433">https://news.ycombinator.com/item?id=33685433</a></p>
<p>Points: 17</p>
<p># Comments: 3</p>

## Kite is saying farewell, and is open-sourcing all of its code.
 - [https://www.kite.com/blog/product/kite-is-saying-farewell/](https://www.kite.com/blog/product/kite-is-saying-farewell/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 20:57:33+00:00

<p>Article URL: <a href="https://www.kite.com/blog/product/kite-is-saying-farewell/">https://www.kite.com/blog/product/kite-is-saying-farewell/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33685209">https://news.ycombinator.com/item?id=33685209</a></p>
<p>Points: 109</p>
<p># Comments: 43</p>

## How I fixed Mopac and why it had it coming – The importance of bug reports
 - [https://omajoshi.com/blog/14/](https://omajoshi.com/blog/14/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 20:41:12+00:00

<p>Article URL: <a href="https://omajoshi.com/blog/14/">https://omajoshi.com/blog/14/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33685043">https://news.ycombinator.com/item?id=33685043</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Tesla killers: The new wave of must-have electric vehicles
 - [https://www.whichcar.com.au/news/tesla-killers-next-wave-electric-vehicles](https://www.whichcar.com.au/news/tesla-killers-next-wave-electric-vehicles)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 20:34:08+00:00

<p>Article URL: <a href="https://www.whichcar.com.au/news/tesla-killers-next-wave-electric-vehicles">https://www.whichcar.com.au/news/tesla-killers-next-wave-electric-vehicles</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33684966">https://news.ycombinator.com/item?id=33684966</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Show HN: A native macOS client for Apache Kafka
 - [https://defn.io/2022/11/20/ann-franz/](https://defn.io/2022/11/20/ann-franz/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 20:00:27+00:00

<p>Article URL: <a href="https://defn.io/2022/11/20/ann-franz/">https://defn.io/2022/11/20/ann-franz/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33684666">https://news.ycombinator.com/item?id=33684666</a></p>
<p>Points: 34</p>
<p># Comments: 3</p>

## Cigars, Booze, Money: How a Lobbying Blitz Made Sports Betting Ubiquitous
 - [https://www.nytimes.com/2022/11/20/business/sports-betting-lobbying-kansas.html](https://www.nytimes.com/2022/11/20/business/sports-betting-lobbying-kansas.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 19:39:42+00:00

<p>Article URL: <a href="https://www.nytimes.com/2022/11/20/business/sports-betting-lobbying-kansas.html">https://www.nytimes.com/2022/11/20/business/sports-betting-lobbying-kansas.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33684467">https://news.ycombinator.com/item?id=33684467</a></p>
<p>Points: 39</p>
<p># Comments: 12</p>

## We need more water than rain can provide: refilling rivers with desalination
 - [https://caseyhandmer.wordpress.com/2022/11/20/we-need-more-water-than-rain-can-provide-refilling-rivers-with-desalination/](https://caseyhandmer.wordpress.com/2022/11/20/we-need-more-water-than-rain-can-provide-refilling-rivers-with-desalination/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 19:39:35+00:00

<p>Article URL: <a href="https://caseyhandmer.wordpress.com/2022/11/20/we-need-more-water-than-rain-can-provide-refilling-rivers-with-desalination/">https://caseyhandmer.wordpress.com/2022/11/20/we-need-more-water-than-rain-can-provide-refilling-rivers-with-desalination/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33684466">https://news.ycombinator.com/item?id=33684466</a></p>
<p>Points: 26</p>
<p># Comments: 30</p>

## Upgrading Multi-GPU Interconnectivity with the Third-Generation Nvidia NVSwitch
 - [https://developer.nvidia.com/blog/upgrading-multi-gpu-interconnectivity-with-the-third-generation-nvidia-nvswitch/](https://developer.nvidia.com/blog/upgrading-multi-gpu-interconnectivity-with-the-third-generation-nvidia-nvswitch/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 19:34:03+00:00

<p>Article URL: <a href="https://developer.nvidia.com/blog/upgrading-multi-gpu-interconnectivity-with-the-third-generation-nvidia-nvswitch/">https://developer.nvidia.com/blog/upgrading-multi-gpu-interconnectivity-with-the-third-generation-nvidia-nvswitch/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33684402">https://news.ycombinator.com/item?id=33684402</a></p>
<p>Points: 11</p>
<p># Comments: 5</p>

## Tailscale with Avery Pennarun
 - [https://www.heavybit.com/library/podcasts/the-kubelist-podcast/ep-33-tailscale-with-avery-pennarun](https://www.heavybit.com/library/podcasts/the-kubelist-podcast/ep-33-tailscale-with-avery-pennarun)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 19:23:02+00:00

<p>Article URL: <a href="https://www.heavybit.com/library/podcasts/the-kubelist-podcast/ep-33-tailscale-with-avery-pennarun">https://www.heavybit.com/library/podcasts/the-kubelist-podcast/ep-33-tailscale-with-avery-pennarun</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33684255">https://news.ycombinator.com/item?id=33684255</a></p>
<p>Points: 18</p>
<p># Comments: 1</p>

## Just putting it out there
 - [https://www.cjchilvers.com/blog/just-putting-it-out-there/](https://www.cjchilvers.com/blog/just-putting-it-out-there/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 19:21:02+00:00

<p>Article URL: <a href="https://www.cjchilvers.com/blog/just-putting-it-out-there/">https://www.cjchilvers.com/blog/just-putting-it-out-there/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33684237">https://news.ycombinator.com/item?id=33684237</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Stop lying to yourself – you “fix it later”
 - [https://uselessdevblog.wordpress.com/2022/11/10/stop-lying-to-yourself-you-will-never-fix-it-later/](https://uselessdevblog.wordpress.com/2022/11/10/stop-lying-to-yourself-you-will-never-fix-it-later/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 19:10:51+00:00

<p>Article URL: <a href="https://uselessdevblog.wordpress.com/2022/11/10/stop-lying-to-yourself-you-will-never-fix-it-later/">https://uselessdevblog.wordpress.com/2022/11/10/stop-lying-to-yourself-you-will-never-fix-it-later/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33684130">https://news.ycombinator.com/item?id=33684130</a></p>
<p>Points: 27</p>
<p># Comments: 18</p>

## South Africa's national electricity crisis to worsen
 - [https://www.news24.com/fin24/economy/extreme-load-shedding-ahead-as-eskom-diesel-budget-runs-dry-20221120](https://www.news24.com/fin24/economy/extreme-load-shedding-ahead-as-eskom-diesel-budget-runs-dry-20221120)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 19:05:18+00:00

<p>Article URL: <a href="https://www.news24.com/fin24/economy/extreme-load-shedding-ahead-as-eskom-diesel-budget-runs-dry-20221120">https://www.news24.com/fin24/economy/extreme-load-shedding-ahead-as-eskom-diesel-budget-runs-dry-20221120</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33684066">https://news.ycombinator.com/item?id=33684066</a></p>
<p>Points: 20</p>
<p># Comments: 6</p>

## On Accountability in Software Development
 - [https://franciscomt.medium.com/on-accountability-in-software-development-7e80cc6226aa](https://franciscomt.medium.com/on-accountability-in-software-development-7e80cc6226aa)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 19:04:40+00:00

<p>Article URL: <a href="https://franciscomt.medium.com/on-accountability-in-software-development-7e80cc6226aa">https://franciscomt.medium.com/on-accountability-in-software-development-7e80cc6226aa</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33684062">https://news.ycombinator.com/item?id=33684062</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## The Modern Observability Problem
 - [https://failingfast.io/opentelemetry-observability/](https://failingfast.io/opentelemetry-observability/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 19:03:25+00:00

<p>Article URL: <a href="https://failingfast.io/opentelemetry-observability/">https://failingfast.io/opentelemetry-observability/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33684045">https://news.ycombinator.com/item?id=33684045</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Man of the Hole
 - [https://en.wikipedia.org/wiki/Man_of_the_Hole](https://en.wikipedia.org/wiki/Man_of_the_Hole)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 19:03:16+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/Man_of_the_Hole">https://en.wikipedia.org/wiki/Man_of_the_Hole</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33684043">https://news.ycombinator.com/item?id=33684043</a></p>
<p>Points: 25</p>
<p># Comments: 1</p>

## Good machine learning practice for medical device development
 - [https://www.fda.gov/medical-devices/software-medical-device-samd/good-machine-learning-practice-medical-device-development-guiding-principles](https://www.fda.gov/medical-devices/software-medical-device-samd/good-machine-learning-practice-medical-device-development-guiding-principles)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 18:57:07+00:00

<p>Article URL: <a href="https://www.fda.gov/medical-devices/software-medical-device-samd/good-machine-learning-practice-medical-device-development-guiding-principles">https://www.fda.gov/medical-devices/software-medical-device-samd/good-machine-learning-practice-medical-device-development-guiding-principles</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33683986">https://news.ycombinator.com/item?id=33683986</a></p>
<p>Points: 11</p>
<p># Comments: 0</p>

## The clever camera code on rolls of film
 - [https://www.youtube.com/watch?v=imMBwUGjXHs](https://www.youtube.com/watch?v=imMBwUGjXHs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 18:22:38+00:00

<p>Article URL: <a href="https://www.youtube.com/watch?v=imMBwUGjXHs">https://www.youtube.com/watch?v=imMBwUGjXHs</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33683642">https://news.ycombinator.com/item?id=33683642</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Welcome to the First RISC-V Site
 - [http://riscv.jghuff.com/](http://riscv.jghuff.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 18:16:17+00:00

<p>Article URL: <a href="http://riscv.jghuff.com/">http://riscv.jghuff.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33683571">https://news.ycombinator.com/item?id=33683571</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Let Crypto Burn
 - [https://www.ft.com/content/ac058ede-80cb-4aa6-8394-941443eec7e3](https://www.ft.com/content/ac058ede-80cb-4aa6-8394-941443eec7e3)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 18:09:15+00:00

<p>Article URL: <a href="https://www.ft.com/content/ac058ede-80cb-4aa6-8394-941443eec7e3">https://www.ft.com/content/ac058ede-80cb-4aa6-8394-941443eec7e3</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33683474">https://news.ycombinator.com/item?id=33683474</a></p>
<p>Points: 72</p>
<p># Comments: 10</p>

## Computer Latency: 1977-2017
 - [https://danluu.com/input-lag/](https://danluu.com/input-lag/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 17:51:03+00:00

<p>Article URL: <a href="https://danluu.com/input-lag/">https://danluu.com/input-lag/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33683278">https://news.ycombinator.com/item?id=33683278</a></p>
<p>Points: 21</p>
<p># Comments: 5</p>

## Disassembling an Amazon Blink Mini Camera
 - [https://astrid.tech/2022/07/07/0/blink-mini-disassembly/](https://astrid.tech/2022/07/07/0/blink-mini-disassembly/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 17:35:44+00:00

<p>Article URL: <a href="https://astrid.tech/2022/07/07/0/blink-mini-disassembly/">https://astrid.tech/2022/07/07/0/blink-mini-disassembly/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33683122">https://news.ycombinator.com/item?id=33683122</a></p>
<p>Points: 17</p>
<p># Comments: 0</p>

## While Crypto Bro Scammed Clients, Reporters Scammed Readers – Fair
 - [https://fair.org/home/while-crypto-bro-scammed-clients-reporters-scammed-readers/](https://fair.org/home/while-crypto-bro-scammed-clients-reporters-scammed-readers/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 17:25:06+00:00

<p>Article URL: <a href="https://fair.org/home/while-crypto-bro-scammed-clients-reporters-scammed-readers/">https://fair.org/home/while-crypto-bro-scammed-clients-reporters-scammed-readers/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33683037">https://news.ycombinator.com/item?id=33683037</a></p>
<p>Points: 25</p>
<p># Comments: 3</p>

## How the First Transistor Worked
 - [https://spectrum.ieee.org/transistor-history](https://spectrum.ieee.org/transistor-history)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 17:20:11+00:00

<p>Article URL: <a href="https://spectrum.ieee.org/transistor-history">https://spectrum.ieee.org/transistor-history</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33682976">https://news.ycombinator.com/item?id=33682976</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## IRCv3 2022 Spec round-up
 - [https://ircv3.net/2022/11/20/spec-round-up](https://ircv3.net/2022/11/20/spec-round-up)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 17:09:33+00:00

<p>Article URL: <a href="https://ircv3.net/2022/11/20/spec-round-up">https://ircv3.net/2022/11/20/spec-round-up</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33682835">https://news.ycombinator.com/item?id=33682835</a></p>
<p>Points: 55</p>
<p># Comments: 4</p>

## Show HN: A saxophone with keyboard keys, in Rust
 - [https://github.com/jcard0na/haxo-hw](https://github.com/jcard0na/haxo-hw)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 17:07:50+00:00

<p>I built this during Covid.  When I released it, some of the parts went out of stock or skyrocketed in price, no longer making this an economic DIY project.  Now that things are getting back to almost normal, I thought I'd share it here and request feedback.  This is a very niche project for people who like the same things I do:  saxophones, Rust, mechanical keyboards and the Raspberry Pi.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33682813">https://news.ycombinator.com/item?id=33682813</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## Motion (YC W20) Is Hiring Full Stack Engineers
 - [https://jobs.ashbyhq.com/motion/4f5f6a29-3af0-4d79-99a4-988ff7c5ba05?utm_source=hn](https://jobs.ashbyhq.com/motion/4f5f6a29-3af0-4d79-99a4-988ff7c5ba05?utm_source=hn)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 17:01:59+00:00

<p>Article URL: <a href="https://jobs.ashbyhq.com/motion/4f5f6a29-3af0-4d79-99a4-988ff7c5ba05?utm_source=hn">https://jobs.ashbyhq.com/motion/4f5f6a29-3af0-4d79-99a4-988ff7c5ba05?utm_source=hn</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33682743">https://news.ycombinator.com/item?id=33682743</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Ask HN: What is example of good documentation in your opinion?
 - [https://news.ycombinator.com/item?id=33682599](https://news.ycombinator.com/item?id=33682599)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 16:50:34+00:00

<p>I know its kinda generic question, but what technical documentation you would point to as well written, concise, with good examples etc.. Something that really stands out.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33682599">https://news.ycombinator.com/item?id=33682599</a></p>
<p>Points: 18</p>
<p># Comments: 30</p>

## The New Smoking
 - [https://conorbroderick.net/the-new-smoking/](https://conorbroderick.net/the-new-smoking/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 16:45:46+00:00

<p>Article URL: <a href="https://conorbroderick.net/the-new-smoking/">https://conorbroderick.net/the-new-smoking/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33682531">https://news.ycombinator.com/item?id=33682531</a></p>
<p>Points: 20</p>
<p># Comments: 9</p>

## The Case for the F-35
 - [https://www.navalgazing.net/The-Case-for-the-F-35](https://www.navalgazing.net/The-Case-for-the-F-35)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 16:44:36+00:00

<p>Article URL: <a href="https://www.navalgazing.net/The-Case-for-the-F-35">https://www.navalgazing.net/The-Case-for-the-F-35</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33682517">https://news.ycombinator.com/item?id=33682517</a></p>
<p>Points: 13</p>
<p># Comments: 3</p>

## Berkshirehathaway.com
 - [https://berkshirehathaway.com](https://berkshirehathaway.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 16:26:23+00:00

<p>Article URL: <a href="https://berkshirehathaway.com">https://berkshirehathaway.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33682276">https://news.ycombinator.com/item?id=33682276</a></p>
<p>Points: 36</p>
<p># Comments: 48</p>

## Acquisition of Chess Knowledge in AlphaZero
 - [https://www.pnas.org/doi/10.1073/pnas.2206625119](https://www.pnas.org/doi/10.1073/pnas.2206625119)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 15:44:44+00:00

<p>Article URL: <a href="https://www.pnas.org/doi/10.1073/pnas.2206625119">https://www.pnas.org/doi/10.1073/pnas.2206625119</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33681795">https://news.ycombinator.com/item?id=33681795</a></p>
<p>Points: 23</p>
<p># Comments: 0</p>

## IQ is a dismal measure of intelligence (2019)
 - [https://supermemo.guru/wiki/IQ_is_a_dismal_measure_of_intelligence](https://supermemo.guru/wiki/IQ_is_a_dismal_measure_of_intelligence)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 15:38:21+00:00

<p>Article URL: <a href="https://supermemo.guru/wiki/IQ_is_a_dismal_measure_of_intelligence">https://supermemo.guru/wiki/IQ_is_a_dismal_measure_of_intelligence</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33681732">https://news.ycombinator.com/item?id=33681732</a></p>
<p>Points: 19</p>
<p># Comments: 13</p>

## Airbus and Climate Change
 - [https://qchenevier.github.io/huma/airbus-and-climate-change](https://qchenevier.github.io/huma/airbus-and-climate-change)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 15:11:11+00:00

<p>Article URL: <a href="https://qchenevier.github.io/huma/airbus-and-climate-change">https://qchenevier.github.io/huma/airbus-and-climate-change</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33681460">https://news.ycombinator.com/item?id=33681460</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Eye contact marks the rise and fall of shared attention in conversation
 - [https://www.pnas.org/doi/10.1073/pnas.2106645118](https://www.pnas.org/doi/10.1073/pnas.2106645118)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 15:03:57+00:00

<p>Article URL: <a href="https://www.pnas.org/doi/10.1073/pnas.2106645118">https://www.pnas.org/doi/10.1073/pnas.2106645118</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33681393">https://news.ycombinator.com/item?id=33681393</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## UK food price inflation hit 16.2% in October – cost of food basics surging
 - [https://www.bbc.co.uk/news/business-63641414](https://www.bbc.co.uk/news/business-63641414)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 15:03:06+00:00

<p>Article URL: <a href="https://www.bbc.co.uk/news/business-63641414">https://www.bbc.co.uk/news/business-63641414</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33681382">https://news.ycombinator.com/item?id=33681382</a></p>
<p>Points: 48</p>
<p># Comments: 6</p>

## Help HN: Starlink Signup failed, no recourse
 - [https://news.ycombinator.com/item?id=33681263](https://news.ycombinator.com/item?id=33681263)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 14:47:43+00:00

<p>On october 27th, when I first heard about Starlink for RV's, I immediately signed up at starlink.com and paid €480. I filled in my email and my phone number, but to date I have not received a confirmation of receipt from Starlink. The payment was a direct transfer.<p>I have gone through the (not great) starlink support pages, and one can apparently only contact starlink through an account that becomes available through the confirmation email. Naturally I have none. It also states that if that confirmation email wasn't confirmed, the order would be cancelled after 7 days (it hasn't). There was no email in my Spam folder.<p>Now it's been over 3 weeks. I am a customer but as far as starlink is concerned, I am not. They obviously did their utmost best to not need a helpdesk, having generous procedures in place for when things fail. There is no one to talk to, not even a silly bot. This is all great when it works, but when you fall on the side where things don't work as intended, as I do now, it doesn't exactly feel great. It feels like a scam, it's indistinguishable.<p>There is also a potential for a scam. If I somehow filled in a slightly wrong email address someone else could, in theory, have taken over my account, and could have redirected the shipment. The point is, I'll never know, and I was not made aware of such risk while signing up. Indeed the signup experience was strangely feed-forward, without an email-confirmation step. In the end it felt like I was supposed to dump €480 into a void, with nothing to show for, except a bank transfer. Just like in a scam I was forced to rely on the reputation of the brand, only. This could have been a scam, except this is standard policy.<p>I think the above is a relevant data-point to many of you (non-scammers), because it represents an extreme case, even beyond Google, one where not only the non-fallability of software artifacts is presumed, but also the non-fallability of the organizational process that led to its 100% no-contact design.<p>That's sure to have some relevance to the community, but of course I just want someone to talk to and solve what could have been the smallest of issues. Any advice on how to proceed next is appreciated.<p>Edit: as commenters have mentioned, there is a reset option, by email or phone. AFAIK neither works.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33681263">https://news.ycombinator.com/item?id=33681263</a></p>
<p>Points: 63</p>
<p># Comments: 22</p>

## Tea: A new package manager from the creator of brew
 - [https://github.com/teaxyz/cli](https://github.com/teaxyz/cli)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 14:39:56+00:00

<p>Article URL: <a href="https://github.com/teaxyz/cli">https://github.com/teaxyz/cli</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33681216">https://news.ycombinator.com/item?id=33681216</a></p>
<p>Points: 34</p>
<p># Comments: 1</p>

## Sam Bankman-Fried, FTX Team Among Top Political Donors Before Bankruptcy
 - [https://www.wsj.com/articles/sam-bankman-fried-ftx-team-among-top-political-donors-before-bankruptcy-11668949205](https://www.wsj.com/articles/sam-bankman-fried-ftx-team-among-top-political-donors-before-bankruptcy-11668949205)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 14:35:44+00:00

<p>Article URL: <a href="https://www.wsj.com/articles/sam-bankman-fried-ftx-team-among-top-political-donors-before-bankruptcy-11668949205">https://www.wsj.com/articles/sam-bankman-fried-ftx-team-among-top-political-donors-before-bankruptcy-11668949205</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33681179">https://news.ycombinator.com/item?id=33681179</a></p>
<p>Points: 41</p>
<p># Comments: 33</p>

## Amazon Is Gutting Its Voice-Assistant Alexa
 - [https://www.businessinsider.com/amazon-alexa-job-layoffs-rise-and-fall-2022-11](https://www.businessinsider.com/amazon-alexa-job-layoffs-rise-and-fall-2022-11)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 13:58:41+00:00

<p>Article URL: <a href="https://www.businessinsider.com/amazon-alexa-job-layoffs-rise-and-fall-2022-11">https://www.businessinsider.com/amazon-alexa-job-layoffs-rise-and-fall-2022-11</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33680904">https://news.ycombinator.com/item?id=33680904</a></p>
<p>Points: 8</p>
<p># Comments: 4</p>

## Kernel (OS Kernel Book)
 - [https://539kernel.com/](https://539kernel.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 13:52:30+00:00

<p>Article URL: <a href="https://539kernel.com/">https://539kernel.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33680869">https://news.ycombinator.com/item?id=33680869</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## 10 KB Club: Curated list of websites whose home pages do not exceed 10 KB size
 - [https://10kbclub.com/](https://10kbclub.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 13:49:30+00:00

<p>Article URL: <a href="https://10kbclub.com/">https://10kbclub.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33680852">https://news.ycombinator.com/item?id=33680852</a></p>
<p>Points: 21</p>
<p># Comments: 1</p>

## Ask HN: Again: The “I want to do everything but end up doing nothing” dilemma
 - [https://news.ycombinator.com/item?id=33680805](https://news.ycombinator.com/item?id=33680805)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 13:44:23+00:00

<p>This thread is from 2015
https://news.ycombinator.com/item?id=9049208<p>I have bookmarked it and read it sometimes.  Is there a 2022 version of the thread we want to create?  Things surely have changed a lot since 2015.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33680805">https://news.ycombinator.com/item?id=33680805</a></p>
<p>Points: 32</p>
<p># Comments: 5</p>

## “Just a bunch of idiots having fun”–a photo history of the LAN party
 - [https://arstechnica.com/gaming/2022/11/just-a-bunch-of-idiots-having-fun-a-photo-history-of-the-lan-party/](https://arstechnica.com/gaming/2022/11/just-a-bunch-of-idiots-having-fun-a-photo-history-of-the-lan-party/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 13:17:42+00:00

<p>Article URL: <a href="https://arstechnica.com/gaming/2022/11/just-a-bunch-of-idiots-having-fun-a-photo-history-of-the-lan-party/">https://arstechnica.com/gaming/2022/11/just-a-bunch-of-idiots-having-fun-a-photo-history-of-the-lan-party/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33680678">https://news.ycombinator.com/item?id=33680678</a></p>
<p>Points: 29</p>
<p># Comments: 15</p>

## Hacker News Parody Thread
 - [http://bradconte.com/files/misc/HackerNewsParodyThread/](http://bradconte.com/files/misc/HackerNewsParodyThread/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 13:14:22+00:00

<p>Article URL: <a href="http://bradconte.com/files/misc/HackerNewsParodyThread/">http://bradconte.com/files/misc/HackerNewsParodyThread/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33680661">https://news.ycombinator.com/item?id=33680661</a></p>
<p>Points: 22</p>
<p># Comments: 1</p>

## Ask HN: Publish old projects even though the source code embarrasses you by now?
 - [https://news.ycombinator.com/item?id=33680469](https://news.ycombinator.com/item?id=33680469)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 12:42:12+00:00

<p>I have some game projects that were released almost ~15 years ago (https://store.steampowered.com/publisher/asylumsquare/list/100010). Of course, from today's perspective, they have some issues (low 4:3 resolution, for example).<p>I made the games available for free on Steam because I thought they might still find some players who enjoy them, even if they are of course a bit old-fashioned here and there.<p>I'm now thinking about releasing the source code as open source. I'd really like to do that, because I think it might be interesting for some people. And if people create new ports or mods/improvements, that would be pretty awesome.<p>However, from today's perspective, the source code is not very well structured - so it's a bit embarrassing. I'm torn on whether to publish it or not, because it might reflect badly on me as a developer. How would you handle that?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33680469">https://news.ycombinator.com/item?id=33680469</a></p>
<p>Points: 18</p>
<p># Comments: 11</p>

## Mildly Interesting Quirks of C
 - [https://gist.github.com/fay59/5ccbe684e6e56a7df8815c3486568f01](https://gist.github.com/fay59/5ccbe684e6e56a7df8815c3486568f01)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 11:54:33+00:00

<p>Article URL: <a href="https://gist.github.com/fay59/5ccbe684e6e56a7df8815c3486568f01">https://gist.github.com/fay59/5ccbe684e6e56a7df8815c3486568f01</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33680239">https://news.ycombinator.com/item?id=33680239</a></p>
<p>Points: 25</p>
<p># Comments: 2</p>

## I don't want to go back to social media
 - [https://lapcatsoftware.com/articles/socialmedia.html](https://lapcatsoftware.com/articles/socialmedia.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 10:45:51+00:00

<p>Article URL: <a href="https://lapcatsoftware.com/articles/socialmedia.html">https://lapcatsoftware.com/articles/socialmedia.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33679915">https://news.ycombinator.com/item?id=33679915</a></p>
<p>Points: 26</p>
<p># Comments: 3</p>

## Running Arm64.aarch64 FreeBSD on QEMU/UTM.app on Apple Silicon
 - [https://weblog.antranigv.am/posts/2022/11/running-arm64-aarch64-freebsd-on-qemu-utm-app-on-apple-silicon/](https://weblog.antranigv.am/posts/2022/11/running-arm64-aarch64-freebsd-on-qemu-utm-app-on-apple-silicon/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 10:22:23+00:00

<p>Article URL: <a href="https://weblog.antranigv.am/posts/2022/11/running-arm64-aarch64-freebsd-on-qemu-utm-app-on-apple-silicon/">https://weblog.antranigv.am/posts/2022/11/running-arm64-aarch64-freebsd-on-qemu-utm-app-on-apple-silicon/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33679818">https://news.ycombinator.com/item?id=33679818</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Reader Macros in Common Lisp (2014)
 - [https://lisper.in/reader-macros](https://lisper.in/reader-macros)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 10:22:08+00:00

<p>Article URL: <a href="https://lisper.in/reader-macros">https://lisper.in/reader-macros</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33679816">https://news.ycombinator.com/item?id=33679816</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Greg Bear (1951-2022)
 - [https://file770.com/greg-bear-1951-2022/](https://file770.com/greg-bear-1951-2022/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 09:48:14+00:00

<p>Article URL: <a href="https://file770.com/greg-bear-1951-2022/">https://file770.com/greg-bear-1951-2022/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33679668">https://news.ycombinator.com/item?id=33679668</a></p>
<p>Points: 16</p>
<p># Comments: 1</p>

## Thinking Forth
 - [https://thinking-forth.sourceforge.net/](https://thinking-forth.sourceforge.net/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 08:36:08+00:00

<p>Article URL: <a href="https://thinking-forth.sourceforge.net/">https://thinking-forth.sourceforge.net/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33679360">https://news.ycombinator.com/item?id=33679360</a></p>
<p>Points: 16</p>
<p># Comments: 2</p>

## ‘Vox Populi Vox Dei’
 - [https://www.historynet.com/what-is-the-history-of-vox-populi-vox-dei/](https://www.historynet.com/what-is-the-history-of-vox-populi-vox-dei/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 08:04:46+00:00

<p>Article URL: <a href="https://www.historynet.com/what-is-the-history-of-vox-populi-vox-dei/">https://www.historynet.com/what-is-the-history-of-vox-populi-vox-dei/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33679219">https://news.ycombinator.com/item?id=33679219</a></p>
<p>Points: 7</p>
<p># Comments: 5</p>

## Twitter was special. But it's time to leave
 - [https://www.pwnallthethings.com/p/twitter-was-special-but-its-time](https://www.pwnallthethings.com/p/twitter-was-special-but-its-time)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 07:44:07+00:00

<p>Article URL: <a href="https://www.pwnallthethings.com/p/twitter-was-special-but-its-time">https://www.pwnallthethings.com/p/twitter-was-special-but-its-time</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33679141">https://news.ycombinator.com/item?id=33679141</a></p>
<p>Points: 54</p>
<p># Comments: 65</p>

## Tracking Mastodon user numbers over time with a bucket of tricks
 - [https://simonwillison.net/2022/Nov/20/tracking-mastodon/](https://simonwillison.net/2022/Nov/20/tracking-mastodon/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 07:19:14+00:00

<p>Article URL: <a href="https://simonwillison.net/2022/Nov/20/tracking-mastodon/">https://simonwillison.net/2022/Nov/20/tracking-mastodon/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33679028">https://news.ycombinator.com/item?id=33679028</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## TIC-80 Fantasy Computer
 - [https://tic80.com/](https://tic80.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 06:15:51+00:00

<p>Article URL: <a href="https://tic80.com/">https://tic80.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33678782">https://news.ycombinator.com/item?id=33678782</a></p>
<p>Points: 17</p>
<p># Comments: 2</p>

## Collapse of Carvana, the 'Amazon of Used Cars', Continues
 - [https://www.thestreet.com/technology/the-collapse-of-carvana-the-amazon-of-used-cars-continues](https://www.thestreet.com/technology/the-collapse-of-carvana-the-amazon-of-used-cars-continues)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 05:54:25+00:00

<p>Article URL: <a href="https://www.thestreet.com/technology/the-collapse-of-carvana-the-amazon-of-used-cars-continues">https://www.thestreet.com/technology/the-collapse-of-carvana-the-amazon-of-used-cars-continues</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33678700">https://news.ycombinator.com/item?id=33678700</a></p>
<p>Points: 11</p>
<p># Comments: 0</p>

## QuickJS Running in WebAssembly
 - [https://github.com/justjake/quickjs-emscripten](https://github.com/justjake/quickjs-emscripten)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 05:40:08+00:00

<p>Article URL: <a href="https://github.com/justjake/quickjs-emscripten">https://github.com/justjake/quickjs-emscripten</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33678641">https://news.ycombinator.com/item?id=33678641</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Show HN: ILLA is an Open-source alternative to Retool
 - [https://github.com/illacloud/illa-builder](https://github.com/illacloud/illa-builder)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 05:30:54+00:00

<p>Article URL: <a href="https://github.com/illacloud/illa-builder">https://github.com/illacloud/illa-builder</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33678599">https://news.ycombinator.com/item?id=33678599</a></p>
<p>Points: 24</p>
<p># Comments: 7</p>

## Nvidia and Microsoft team up to build AI cloud computer
 - [https://arstechnica.com/information-technology/2022/11/nvidia-and-microsoft-team-up-to-build-massive-ai-cloud-computer/](https://arstechnica.com/information-technology/2022/11/nvidia-and-microsoft-team-up-to-build-massive-ai-cloud-computer/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 04:59:50+00:00

<p>Article URL: <a href="https://arstechnica.com/information-technology/2022/11/nvidia-and-microsoft-team-up-to-build-massive-ai-cloud-computer/">https://arstechnica.com/information-technology/2022/11/nvidia-and-microsoft-team-up-to-build-massive-ai-cloud-computer/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33678415">https://news.ycombinator.com/item?id=33678415</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## Planes are still decades away from displacing most bird jobs
 - [https://guzey.com/ai/planes-vs-birds/](https://guzey.com/ai/planes-vs-birds/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 04:31:02+00:00

<p>Article URL: <a href="https://guzey.com/ai/planes-vs-birds/">https://guzey.com/ai/planes-vs-birds/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33678263">https://news.ycombinator.com/item?id=33678263</a></p>
<p>Points: 38</p>
<p># Comments: 5</p>

## Tell HN: DuckDuckGo is blocked by Indian govt
 - [https://news.ycombinator.com/item?id=33677964](https://news.ycombinator.com/item?id=33677964)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 03:41:19+00:00

<p>Starting a few hours ago I can no longer acces duckduckgo. It says
"Your requested URL has been blocked as per the directions received from the Department of Telecommunications, Government of India"</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33677964">https://news.ycombinator.com/item?id=33677964</a></p>
<p>Points: 13</p>
<p># Comments: 7</p>

## Oikema House of Pleasure by Claude-Nicolas Ledoux (2020)
 - [https://archeyes.com/oikema-house-pleasure-claude-nicolas-ledoux/](https://archeyes.com/oikema-house-pleasure-claude-nicolas-ledoux/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 03:08:35+00:00

<p>Article URL: <a href="https://archeyes.com/oikema-house-pleasure-claude-nicolas-ledoux/">https://archeyes.com/oikema-house-pleasure-claude-nicolas-ledoux/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33677760">https://news.ycombinator.com/item?id=33677760</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## The Radiation Printer (2000)
 - [https://www.computer-history.info/Page4.dir/pages/Radiation.Printer.dir/index.html](https://www.computer-history.info/Page4.dir/pages/Radiation.Printer.dir/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 01:08:27+00:00

<p>Article URL: <a href="https://www.computer-history.info/Page4.dir/pages/Radiation.Printer.dir/index.html">https://www.computer-history.info/Page4.dir/pages/Radiation.Printer.dir/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33676972">https://news.ycombinator.com/item?id=33676972</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## Power struggles among nice people
 - [https://www.edbatista.com/2022/03/power-struggles-among-nice-people.html](https://www.edbatista.com/2022/03/power-struggles-among-nice-people.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 01:07:56+00:00

<p>Article URL: <a href="https://www.edbatista.com/2022/03/power-struggles-among-nice-people.html">https://www.edbatista.com/2022/03/power-struggles-among-nice-people.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33676967">https://news.ycombinator.com/item?id=33676967</a></p>
<p>Points: 31</p>
<p># Comments: 3</p>

## Closures and Objects Are Equivalent (2013)
 - [https://wiki.c2.com/?ClosuresAndObjectsAreEquivalent](https://wiki.c2.com/?ClosuresAndObjectsAreEquivalent)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 01:07:02+00:00

<p>Article URL: <a href="https://wiki.c2.com/?ClosuresAndObjectsAreEquivalent">https://wiki.c2.com/?ClosuresAndObjectsAreEquivalent</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33676959">https://news.ycombinator.com/item?id=33676959</a></p>
<p>Points: 4</p>
<p># Comments: 2</p>

## Brilliant jerks, crazy hotties, and other artifacts of range restriction (2019)
 - [https://towardsdatascience.com/brilliant-jerks-crazy-hotties-and-other-artifacts-of-range-restriction-c53785ae249f](https://towardsdatascience.com/brilliant-jerks-crazy-hotties-and-other-artifacts-of-range-restriction-c53785ae249f)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-11-20 00:24:53+00:00

<p>Article URL: <a href="https://towardsdatascience.com/brilliant-jerks-crazy-hotties-and-other-artifacts-of-range-restriction-c53785ae249f">https://towardsdatascience.com/brilliant-jerks-crazy-hotties-and-other-artifacts-of-range-restriction-c53785ae249f</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33676648">https://news.ycombinator.com/item?id=33676648</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>


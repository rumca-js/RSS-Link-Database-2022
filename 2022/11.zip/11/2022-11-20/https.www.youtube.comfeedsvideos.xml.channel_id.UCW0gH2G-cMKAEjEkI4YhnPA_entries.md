# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Vic Armstrong, Stunt Coordinator & 2nd Unit Director, The Rings of Power
 - [https://www.youtube.com/watch?v=tv4AhCksjTs](https://www.youtube.com/watch?v=tv4AhCksjTs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-11-21 00:00:00+00:00

We chat with legendary stuntman, stunt coordinator, and second unit director Vic Armstrong.  He's doubled as Indiana Jones, James Bond, Superman and directed action sequences for many films - including the opening scene of Terminator 2: Judgment Day.  On The Lord of the Rings: The Rings of Power, Vic was stunt coordinator and Second Unit Director.

#theringsofpower #ringsofpower #lordoftherings


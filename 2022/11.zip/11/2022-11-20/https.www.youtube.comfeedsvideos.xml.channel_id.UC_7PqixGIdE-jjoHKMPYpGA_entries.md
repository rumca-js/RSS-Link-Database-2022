# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Komentarz o tym, jak bardzo zepsuta jest nauka
 - [https://www.youtube.com/watch?v=_cz0pJc-wGo](https://www.youtube.com/watch?v=_cz0pJc-wGo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2022-11-20 14:24:41+00:00

Doprecyzowanieo tego filmu:
https://www.youtube.com/watch?v=BNZrBZHuuJQ


# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: Evelred - The Voice (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=BFhOre427QQ](https://www.youtube.com/watch?v=BFhOre427QQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-11-20 00:00:00+00:00

"The Voice" by Evelred/Capsule (Mateo Pascual), 1st at Euskal 1995.
Art "Freedom Comes Back" by Critikill/Brainstorm^Rebels^SWEET16, 1st at Function 2022

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Exact interpolation with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 16 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.


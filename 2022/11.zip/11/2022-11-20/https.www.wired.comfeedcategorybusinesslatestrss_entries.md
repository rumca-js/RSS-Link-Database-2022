# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## Elon Musk Embraces Twitter's Radical Fact-Checking Experiment
 - [https://www.wired.com/story/elon-musk-embraces-twitters-radical-crowdsourcing-experiment/](https://www.wired.com/story/elon-musk-embraces-twitters-radical-crowdsourcing-experiment/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2022-11-20 12:00:00+00:00

The project allows users to suggest short notes that add missing context to viral tweets. It could change how social platforms operate.


# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## There are altogether too many eyeballs in this Darkest Dungeon 2 update
 - [https://www.pcgamer.com/there-are-altogether-too-many-eyeballs-in-this-darkest-dungeon-2-update](https://www.pcgamer.com/there-are-altogether-too-many-eyeballs-in-this-darkest-dungeon-2-update)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-20 22:40:21+00:00

One creature is allowed to have two eyeballs, eight if it's a spider. That's the rules.

## Do some sci-fi dungeoneering in the open beta of Endless Dungeon
 - [https://www.pcgamer.com/do-some-sci-fi-dungeoneering-in-the-open-beta-of-endless-dungeon](https://www.pcgamer.com/do-some-sci-fi-dungeoneering-in-the-open-beta-of-endless-dungeon)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-20 22:03:00+00:00

It's running until November 28th.

## Great moments in PC gaming: Clearing your first savage raid in Final Fantasy 14
 - [https://www.pcgamer.com/great-moments-in-pc-gaming-clearing-your-first-savage-raid-in-final-fantasy-14](https://www.pcgamer.com/great-moments-in-pc-gaming-clearing-your-first-savage-raid-in-final-fantasy-14)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-20 20:47:16+00:00

Pushing past your comfort zone might unlock a newfound love.

## Today's Wordle answer and hint for Sunday, November 20
 - [https://www.pcgamer.com/wordle-519-answer-november-20](https://www.pcgamer.com/wordle-519-answer-november-20)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-20 08:05:46+00:00

Wordle today: The solution and a hint for the #519 puzzle.

## Tips for the tip throne: Things you should know about Warhammer 40K: Darktide
 - [https://www.pcgamer.com/warhammer-40k-darktide-tips-hints](https://www.pcgamer.com/warhammer-40k-darktide-tips-hints)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-20 05:22:44+00:00

"Ignorance is thy best defence," says the Imperium. Maybe don't let the Inquisitor know you read these hints and tips for Darktide.

## Obscure RTSes the world forgot about
 - [https://www.pcgamer.com/obscure-rtses-the-world-forgot-about](https://www.pcgamer.com/obscure-rtses-the-world-forgot-about)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-20 01:18:27+00:00

Overlooked real-time strategy games that should have been classics.

## Broforce is coming back for one last job, will probably punch Satan
 - [https://www.pcgamer.com/broforce-is-coming-back-for-one-last-job-will-probably-punch-satan](https://www.pcgamer.com/broforce-is-coming-back-for-one-last-job-will-probably-punch-satan)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-11-20 00:31:35+00:00

Check out the animated teaser for Broforce Forever.


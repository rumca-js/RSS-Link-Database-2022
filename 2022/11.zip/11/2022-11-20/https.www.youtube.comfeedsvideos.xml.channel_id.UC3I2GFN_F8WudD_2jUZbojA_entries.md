# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Luna Li - Afterglow (Live on KEXP)
 - [https://www.youtube.com/watch?v=NLNmqiIqm5w](https://www.youtube.com/watch?v=NLNmqiIqm5w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-11-21 00:00:00+00:00

http://KEXP.ORG presents Luna Li performing “Afterglow” live in the KEXP studio. Recorded October 6, 2022.

Luna Li - Guitar / Violin / Vocals
Sabrina Carrizo Sztainbok - Bass / Vocals
Char Aragoza - Keyboards / Vocals
Vania Lee - Drums

Host: Troy Nelson
Audio Engineer: Jon Roberts
Monitor Engineer: Niki Prekop
Audio Mixer: Gavin Brown
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Carlos Cruz

https://linktr.ee/lunaliii
http://kexp.org

## Luna Li - Cherry Pit (Live on KEXP)
 - [https://www.youtube.com/watch?v=FpbmM0c2bcc](https://www.youtube.com/watch?v=FpbmM0c2bcc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-11-21 00:00:00+00:00

http://KEXP.ORG presents Luna Li performing “Cherry Pit” live in the KEXP studio. Recorded October 6, 2022.

Luna Li - Guitar / Violin / Vocals
Sabrina Carrizo Sztainbok - Bass / Vocals
Char Aragoza - Keyboards / Vocals
Vania Lee - Drums

Host: Troy Nelson
Audio Engineer: Jon Roberts
Monitor Engineer: Niki Prekop
Audio Mixer: Gavin Brown
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Carlos Cruz

https://linktr.ee/lunaliii
http://kexp.org

## Luna Li - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=SVpLsz1z-O4](https://www.youtube.com/watch?v=SVpLsz1z-O4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-11-21 00:00:00+00:00

http://KEXP.ORG presents Luna Li performing live in the KEXP studio. Recorded October 6, 2022.

Songs:
Cherry Pit
Silver Into Rain
Afterglow
Lonely/Lovely

Luna Li - Guitar / Violin / Vocals
Sabrina Carrizo Sztainbok - Bass / Vocals
Char Aragoza - Keyboards / Vocals
Vania Lee - Drums

Host: Troy Nelson
Audio Engineer: Jon Roberts
Monitor Engineer: Niki Prekop
Audio Mixer: Gavin Brown
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Carlos Cruz

https://linktr.ee/lunaliii
http://kexp.org

## Luna Li - Lonely/Lovely (Live on KEXP)
 - [https://www.youtube.com/watch?v=20kq6U8VmNQ](https://www.youtube.com/watch?v=20kq6U8VmNQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-11-21 00:00:00+00:00

http://KEXP.ORG presents Luna Li performing “Lonely/Lovely” live in the KEXP studio. Recorded October 6, 2022.

Luna Li - Guitar / Violin / Vocals
Sabrina Carrizo Sztainbok - Bass / Vocals
Char Aragoza - Keyboards / Vocals
Vania Lee - Drums

Host: Troy Nelson
Audio Engineer: Jon Roberts
Monitor Engineer: Niki Prekop
Audio Mixer: Gavin Brown
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Carlos Cruz

https://linktr.ee/lunaliii
http://kexp.org

## Luna Li - Silver Into Rain (Live on KEXP)
 - [https://www.youtube.com/watch?v=NKfSWm2VWUE](https://www.youtube.com/watch?v=NKfSWm2VWUE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-11-21 00:00:00+00:00

http://KEXP.ORG presents Luna Li performing “Silver Into Rain” live in the KEXP studio. Recorded October 6, 2022.

Luna Li - Guitar / Violin / Vocals
Sabrina Carrizo Sztainbok - Bass / Vocals
Char Aragoza - Keyboards / Vocals
Vania Lee - Drums

Host: Troy Nelson
Audio Engineer: Jon Roberts
Monitor Engineer: Niki Prekop
Audio Mixer: Gavin Brown
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Carlos Cruz

https://linktr.ee/lunaliii
http://kexp.org


# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## Ecuador dampens Qatar's party as controversial World Cup gets underway
 - [https://www.cnn.com/2022/11/20/football/qatar-ecuador-opening-game-world-cup-2022-spt-intl/index.html](https://www.cnn.com/2022/11/20/football/qatar-ecuador-opening-game-world-cup-2022-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-11-20 18:23:29+00:00

For the past year, a giant clock in Doha has been counting down to the opening match of the World Cup. Qatar and the world need wait no more, after this controversial tournament got underway Sunday with the host losing 2-0 to Ecuador.

## IAEA warns whoever was behind 'powerful explosions' at Zaporizhzhia nuclear plant is 'playing with fire'
 - [https://www.cnn.com/2022/11/20/europe/zaporizhzhia-iaea-warning-intl/index.html](https://www.cnn.com/2022/11/20/europe/zaporizhzhia-iaea-warning-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-11-20 16:38:02+00:00

Powerful explosions rocked the Zaporizhzhia nuclear power plant in Ukraine this weekend, renewing concerns that fighting so close to the facility could cause a nuclear accident.

## Turkey launches deadly aerial campaign over Syria in response to Istanbul bombing
 - [https://www.cnn.com/2022/11/20/middleeast/turkey-air-operation-syria-intl/index.html](https://www.cnn.com/2022/11/20/middleeast/turkey-air-operation-syria-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-11-20 14:13:48+00:00

Eleven people have been killed in Syria, including one journalist, after Turkish warplanes carried out an "air operation" in the country and neighboring Iraq late Saturday, according to an official from the US-backed Syrian Democratic Forces (SDF). There have not been any casualties reported from the Iraqi side.


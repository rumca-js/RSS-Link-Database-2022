# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Elon Musk Reinstates Trump’s Twitter Account
 - [https://www.nytimes.com/2022/11/19/technology/trump-twitter-musk.html](https://www.nytimes.com/2022/11/19/technology/trump-twitter-musk.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-11-20 01:57:45+00:00

Mr. Musk, who had run a poll on Twitter about whether to bring back the former president to the service, said, “The people have spoken.”


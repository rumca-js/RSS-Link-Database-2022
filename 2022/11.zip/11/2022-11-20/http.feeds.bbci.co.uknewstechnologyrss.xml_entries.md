# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## FTX crypto exchange owes biggest creditors $3.1bn
 - [https://www.bbc.co.uk/news/business-63697459?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63697459?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-11-20 19:49:45+00:00

FTX owes about $1.45bn to its top 10 creditors, according to its US bankruptcy court filings.


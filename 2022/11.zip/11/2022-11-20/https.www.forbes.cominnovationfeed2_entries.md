# Source:Forbs - innovation, URL:https://www.forbes.com/innovation/feed2, language:en-US

## The Technology Behind The Epic Livestream Of ‘Elton John Live: Farewell From Dodger Stadium’
 - [https://www.forbes.com/sites/tonybradley/2022/11/20/the-technology-behind-the-epic-livestream-of-elton-john-live-farewell-from-dodger-stadium/](https://www.forbes.com/sites/tonybradley/2022/11/20/the-technology-behind-the-epic-livestream-of-elton-john-live-farewell-from-dodger-stadium/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 22:07:51+00:00

Fortunately, those of us who aren’t in Los Angeles and do not have tickets can still be part of the epic event because the concert will be streamed live on Disney+ Elton John’s music is timeless and spans generations.

## A Psychologist Explains Why Depression Is One Of The Most Misunderstood Mental Illnesses
 - [https://www.forbes.com/sites/traversmark/2022/11/20/a-psychologist-explains-why-depression-is-one-of-the-most-misunderstood-mental-illnesses/](https://www.forbes.com/sites/traversmark/2022/11/20/a-psychologist-explains-why-depression-is-one-of-the-most-misunderstood-mental-illnesses/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 21:47:52+00:00

Depression is a debilitating condition. It’s time to get rid of the misinformation around it.

## SwitchBot Wi-Fi Smart Lock Review
 - [https://www.forbes.com/sites/bennyhareven/2022/11/20/switchbot-wi-fi-smart-lock-review/](https://www.forbes.com/sites/bennyhareven/2022/11/20/switchbot-wi-fi-smart-lock-review/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 21:13:13+00:00

The SwitchBot Lock is a smart lock that lets you keep your existing lock and key on the outside of your door. I see how it fares.

## Volvo Cars Outlook Deteriorating As Profit Dives
 - [https://www.forbes.com/sites/neilwinton/2022/11/20/volvo-cars-outlook-deteriorating-as-profit-dives/](https://www.forbes.com/sites/neilwinton/2022/11/20/volvo-cars-outlook-deteriorating-as-profit-dives/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 16:43:56+00:00

Volvo Car’s profit fell by about a third as its major competitors in Europe reported strong earnings and Moody’s changed its outlook for its rating change to a less favorable “stable” from “positive”. Profitability will weaken as sales contract. UBS doesn’t expect positive free cash flow until 2025.

## Egypt’s Too Easy, The Next ‘God Of War’ Should Have Kratos In Christendom
 - [https://www.forbes.com/sites/paultassi/2022/11/20/egypts-too-easy-the-next-god-of-war-should-have-kratos-in-christendom/](https://www.forbes.com/sites/paultassi/2022/11/20/egypts-too-easy-the-next-god-of-war-should-have-kratos-in-christendom/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 15:53:51+00:00

Now that God of War’s Norse saga has ended with Ragnarok, speculation turns to which realm Kratos may dive into next. There are a lot of obvious choices for a new pantheon of gods to explore, the most common of which is ancient Egypt, though some bring up the idea of a Mayan game or exploring

## Elon Musk Reinstated Donald Trump On Twitter. Now The Real Drama Begins
 - [https://www.forbes.com/sites/johnbbrandon/2022/11/20/elon-musk-reinstated-donald-trump-on-twitter-now-the-real-drama-begins/](https://www.forbes.com/sites/johnbbrandon/2022/11/20/elon-musk-reinstated-donald-trump-on-twitter-now-the-real-drama-begins/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 15:48:31+00:00

The former President “rocked the vote” and was a significant favorite among Twitter users, most of whom voted because they follow Musk.

## ‘The Walking Dead’ Series Finale Reveals A Show Wildly Transformed From Its Beginnings
 - [https://www.forbes.com/sites/paultassi/2022/11/20/the-walking-dead-series-finale-reveals-a-show-wildly-transformed-from-its-beginnings/](https://www.forbes.com/sites/paultassi/2022/11/20/the-walking-dead-series-finale-reveals-a-show-wildly-transformed-from-its-beginnings/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 15:30:34+00:00

The Walking Dead is airing its last episode tonight, although “last” should probably be in quotes, given the plans AMC has for the series going forward.

## The Holiday Logistics Guide
 - [https://www.forbes.com/sites/stevebanker/2022/11/20/the-holiday-logistics-guide/](https://www.forbes.com/sites/stevebanker/2022/11/20/the-holiday-logistics-guide/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 15:13:00+00:00

Every holiday, the largest retailers and parcel carriers hire tens of thousands of full-time, part-time, and seasonal logistics employees for the end of year rush. With inflation and a looming recession, they are not hiring as many this year. But there are still many, many jobs available.

## Why The Disconnect Between Bungie And Players On ‘Destiny 2’ Seasonal Quality?
 - [https://www.forbes.com/sites/paultassi/2022/11/20/why-the-disconnect-between-bungie-and-players-on-destiny-2-seasonal-quality/](https://www.forbes.com/sites/paultassi/2022/11/20/why-the-disconnect-between-bungie-and-players-on-destiny-2-seasonal-quality/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 15:08:52+00:00

This past year, there seems to have been a bit of schism between players and Bungie regarding Destiny 2.

## Thanksgiving Turkey Shortage, Prices Up 20% With Avian Flu, Inflation
 - [https://www.forbes.com/sites/brucelee/2022/11/20/thanksgiving-turkey-shortage-prices-up-20-with-avian-flu-inflation/](https://www.forbes.com/sites/brucelee/2022/11/20/thanksgiving-turkey-shortage-prices-up-20-with-avian-flu-inflation/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 15:03:20+00:00

Turkey isn't the only traditional Thanksgiving food item that's become more expensive. Here's what's happened to the prices of other items.

## An Onslaught Of Mecha Toys Makes Up The Backbone Of ‘Tamashii Nations 2022 Tokyo’
 - [https://www.forbes.com/sites/olliebarder/2022/11/20/an-onslaught-of-mecha-toys-makes-up-the-backbone-of-tamashii-nations-2022-tokyo/](https://www.forbes.com/sites/olliebarder/2022/11/20/an-onslaught-of-mecha-toys-makes-up-the-backbone-of-tamashii-nations-2022-tokyo/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 14:42:18+00:00

It has been a good few years since we had a proper Tamashii Nations event in Akihabara. The pandemic obviously put a stop to these types of events in Tokyo, but now that most of the measures have been lifted, Bandai Spirits has finally shown what they have been up to.

## Twitter’s Broken Its Copyright Strike System, Users Are Uploading Full Movies
 - [https://www.forbes.com/sites/paultassi/2022/11/20/twitters-broken-its-copyright-strike-system-users-are-uploading-full-movies/](https://www.forbes.com/sites/paultassi/2022/11/20/twitters-broken-its-copyright-strike-system-users-are-uploading-full-movies/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 14:33:53+00:00

Last night, it became apparent that Twitter's automated copyright strike/takedown system was no longer functional.

## ‘Pokemon Scarlet And Violet’ User Review Scores Are In And They Are Terrible
 - [https://www.forbes.com/sites/paultassi/2022/11/20/pokemon-scarlet-and-violet-user-review-scores-are-in-and-they-are-terrible/](https://www.forbes.com/sites/paultassi/2022/11/20/pokemon-scarlet-and-violet-user-review-scores-are-in-and-they-are-terrible/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 13:55:28+00:00

Pokemon Scarlet and Violet already has the distinction of being the lowest critically rated mainline Pokemon entry by at least a few points, given its 77 metascore, but now that the site has opened up reviews to users, ...

## Firewalla Gold Plus Is The Perfect Firewall For Small Business And Home Networks
 - [https://www.forbes.com/sites/marksparrow/2022/11/20/firewalla-gold-plus-is-the-perfect-firewall-for-small-business-and-home-networks/](https://www.forbes.com/sites/marksparrow/2022/11/20/firewalla-gold-plus-is-the-perfect-firewall-for-small-business-and-home-networks/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 12:00:00+00:00

The new Firewalla Gold Plus is an innovative firewall for protecting home and office networks from cyber attacks. It also monitors network activity to ensure the data keeps flowing.

## Today’s ‘Quordle’ Answers And Clues For Sunday, November 20
 - [https://www.forbes.com/sites/krisholt/2022/11/20/todays-quordle-answers-and-clues-for-sunday-november-20/](https://www.forbes.com/sites/krisholt/2022/11/20/todays-quordle-answers-and-clues-for-sunday-november-20/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 06:57:33+00:00

Some hints and the solution for today's 'Quordle' are just ahead.

## Today’s ‘Heardle’ Answer And Clues For Sunday, November 20
 - [https://www.forbes.com/sites/krisholt/2022/11/20/todays-heardle-answer-and-clues-for-sunday-november-20/](https://www.forbes.com/sites/krisholt/2022/11/20/todays-heardle-answer-and-clues-for-sunday-november-20/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 05:51:09+00:00

Here's today's 'Heardle' song, along with some hints.

## Today’s Wordle #519 Hints, Clues And Answer For Sunday, November 20th
 - [https://www.forbes.com/sites/erikkain/2022/11/19/todays-wordle-519-hints-clues-and-answer-for-sunday-november-20th/](https://www.forbes.com/sites/erikkain/2022/11/19/todays-wordle-519-hints-clues-and-answer-for-sunday-november-20th/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 03:30:29+00:00

How to solve today's Wordle.

## Review: Syng Cell Alpha Triphonic Wireless Speaker
 - [https://www.forbes.com/sites/bradmoon/2022/11/19/review-syng-cell-alpha-triphonic-wireless-speaker/](https://www.forbes.com/sites/bradmoon/2022/11/19/review-syng-cell-alpha-triphonic-wireless-speaker/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 03:11:34+00:00

The Syng Cell Alpha is the world's first triphonic speaker, a $2399 ultra-modern device with 8 drivers and convincing spatial audio.

## iOS 16.2—Why You Should Apply The Next iPhone Software Straight Away
 - [https://www.forbes.com/sites/kateoflahertyuk/2022/11/19/ios-162-why-you-should-apply-the-next-iphone-software-straight-away/](https://www.forbes.com/sites/kateoflahertyuk/2022/11/19/ios-162-why-you-should-apply-the-next-iphone-software-straight-away/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 02:00:00+00:00

Apple iOS 16.2 could see a new feature called Rapid Security Response in action, which is a way for Apple to apply security updates to your phone on the fly.

## It’s Official: Webb Telescope Made A ‘Staggering’ Discovery A Day After Being Switched-On
 - [https://www.forbes.com/sites/jamiecartereurope/2022/11/19/its-official-webb-telescope-made-a-staggering-discovery-a-day-after-being-switched-on/](https://www.forbes.com/sites/jamiecartereurope/2022/11/19/its-official-webb-telescope-made-a-staggering-discovery-a-day-after-being-switched-on/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-20 01:00:00+00:00

Almost as soon as it began science operations last summer the James Webb Space Telescope revealed an “undiscovered country” of early galaxies. They exist just after the Big Bang and are surprisingly bright and active, confusing astronomers.


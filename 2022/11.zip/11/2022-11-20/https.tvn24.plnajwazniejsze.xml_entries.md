# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Autokar wpadł do przejścia podziemnego. Nie żyje jedna osoba
 - [https://tvn24.pl/wroclaw/wroclaw-plac-grunwaldzki-autokar-wpadl-do-przejscia-podziemnego-nie-zyje-jedna-osoba-6229051?source=rss](https://tvn24.pl/wroclaw/wroclaw-plac-grunwaldzki-autokar-wpadl-do-przejscia-podziemnego-nie-zyje-jedna-osoba-6229051?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 21:57:07+00:00

<img alt="Autokar wpadł do przejścia podziemnego. Nie żyje jedna osoba" src="https://tvn24.pl/poznan/cdn-zdjecie-ejwykn-autokar-wpadl-do-przejscia-podziemnego-6229048/alternates/LANDSCAPE_1280" />
    Po zderzeniu z samochodem.

## Wielka odwaga przed meczem mundialu. "Warunki w naszym kraju są złe"
 - [https://eurosport.tvn24.pl/wielka-odwaga-przed-meczem-mundialu---warunki-w-naszym-kraju-s--z-e-,1125450.html?source=rss](https://eurosport.tvn24.pl/wielka-odwaga-przed-meczem-mundialu---warunki-w-naszym-kraju-s--z-e-,1125450.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 21:25:55+00:00

<img alt="Wielka odwaga przed meczem mundialu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-dp3zvf-iran/alternates/LANDSCAPE_1280" />
    Reprezentanci Iranu zaczynają mundial w Katarze w momencie, gdy w ich ojczyźnie nie ustają krwawo tłumione protesty.

## Niespodzianka na Euro. Czarnogóra we łzach
 - [https://eurosport.tvn24.pl/niespodzianka-na-euro--czarnog-ra-we--zach,1125433.html?source=rss](https://eurosport.tvn24.pl/niespodzianka-na-euro--czarnog-ra-we--zach,1125433.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 19:33:27+00:00

<img alt="Niespodzianka na Euro. Czarnogóra we łzach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-v907sq-czarnogora-z-upragnionym-medalem/alternates/LANDSCAPE_1280" />
    Piłkarki ręczne z tego kraju z brązowym medalem mistrzostw Europy.

## Katarczycy mieli dość, wychodzili już w przerwie. "To było okropne"
 - [https://eurosport.tvn24.pl/katarczycy-mieli-do----wychodzili-ju--w-przerwie---to-by-o-okropne-,1125428.html?source=rss](https://eurosport.tvn24.pl/katarczycy-mieli-do----wychodzili-ju--w-przerwie---to-by-o-okropne-,1125428.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 19:24:48+00:00

<img alt="Katarczycy mieli dość, wychodzili już w przerwie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-j4z7o0-katar/alternates/LANDSCAPE_1280" />
    Mecz otwarcia mundialu nie poszedł po ich myśli.

## Morgan Freeman w niezwykłym duecie. Jego partnerowi nie dawano szans na przeżycie
 - [https://eurosport.tvn24.pl/morgan-freeman-w-niezwyk-ym-duecie--jego-partnerowi-nie-dawano-szans-na-prze-ycie,1125425.html?source=rss](https://eurosport.tvn24.pl/morgan-freeman-w-niezwyk-ym-duecie--jego-partnerowi-nie-dawano-szans-na-prze-ycie,1125425.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 19:08:36+00:00

<img alt="Morgan Freeman w niezwykłym duecie. Jego partnerowi nie dawano szans na przeżycie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-25uhbl-morgan-freeman-i-ghanim-al-muftah/alternates/LANDSCAPE_1280" />
    Amerykański aktor oraz Ghanim Al Muftah gwiazdami ceremonii otwarcia mundialu w Katarze.

## Symulował kontuzję, przed policją uciekał meleksem
 - [https://eurosport.tvn24.pl/symulowa--kontuzj---przed-policj--ucieka--meleksem--bohater-otwarcia-mundialu-ma-sporo-za-uszami,1125423.html?source=rss](https://eurosport.tvn24.pl/symulowa--kontuzj---przed-policj--ucieka--meleksem--bohater-otwarcia-mundialu-ma-sporo-za-uszami,1125423.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 18:43:58+00:00

<img alt="Symulował kontuzję, przed policją uciekał meleksem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xxcmuw-enner-valencia-byl-bohaterem-meczu-otwarcia-mundialu/alternates/LANDSCAPE_1280" />
    Enner Valencia, bohater otwarcia mundialu, ma sporo za uszami.

## Europa przygotowuje się na ciężką zimę. Możliwe przerwy w dostawie prądu
 - [https://fakty.tvn24.pl/europa-przygotowuje-si--na-ci--k--zim---mo-liwe-przerwy-w-dostawie-pr-du,1125406.html?source=rss](https://fakty.tvn24.pl/europa-przygotowuje-si--na-ci--k--zim---mo-liwe-przerwy-w-dostawie-pr-du,1125406.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 18:13:00+00:00

<img alt="Europa przygotowuje się na ciężką zimę. Możliwe przerwy w dostawie prądu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bn4wa8-europa-przygotowuje-sie-na-ciezka-zime-mozliwe-przerwy-w-dostawie-pradu/alternates/LANDSCAPE_1280" />
    Niemcy kreślą scenariusze na kryzys.

## Posiadanie psa lub kota staje się w Polsce coraz droższe
 - [https://fakty.tvn24.pl/posiadanie-psa-lub-kota-staje-si--w-polsce-coraz-dro-sze,1125410.html?source=rss](https://fakty.tvn24.pl/posiadanie-psa-lub-kota-staje-si--w-polsce-coraz-dro-sze,1125410.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 18:09:00+00:00

<img alt="Posiadanie psa lub kota staje się w Polsce coraz droższe" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8o4iml-posiadanie-psa-lub-kota-staje-sie-w-polsce-coraz-drozsze/alternates/LANDSCAPE_1280" />
    Coraz więcej właścicieli staje przed dylematem - pusta lodówka czy pełna miska.

## Katar przeszedł do niechlubnej historii
 - [https://eurosport.tvn24.pl/katar-za-s-aby--przeszed--do-niechlubnej-historii,1125417.html?source=rss](https://eurosport.tvn24.pl/katar-za-s-aby--przeszed--do-niechlubnej-historii,1125417.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 18:07:45+00:00

<img alt="Katar przeszedł do niechlubnej historii" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2vqwwa-katar-przegral-mecz-otwarcia/alternates/LANDSCAPE_1280" />
    Reprezentacja tego kraju jako gospodarz przegrała mecz otwarcia, co wcześniej na mistrzostwach nigdy nie miało miejsca.

## Pieniądze nie grają. Katarczycy rozbici w meczu otwarcia
 - [https://eurosport.tvn24.pl/lekcja-pi-ki-na-pocz-tek--katarczycy-rozbici-w-meczu-otwarcia,1125412.html?source=rss](https://eurosport.tvn24.pl/lekcja-pi-ki-na-pocz-tek--katarczycy-rozbici-w-meczu-otwarcia,1125412.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 17:58:33+00:00

<img alt="Pieniądze nie grają. Katarczycy rozbici w meczu otwarcia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s6xf67-ekw-6228975/alternates/LANDSCAPE_1280" />
    Katar nie miał nic do powiedzenia w rywalizacji z Ekwadorem, przegrał 0:2. Oba gole strzelił Enner Valencia.

## Takiego gola otwarcia na mundialu nie było
 - [https://eurosport.tvn24.pl/enner-valencia-z-pierwsz--bramk--w-katarze--takiego-gola-otwarcia-na-mundialu-nie-by-o,1125399.html?source=rss](https://eurosport.tvn24.pl/enner-valencia-z-pierwsz--bramk--w-katarze--takiego-gola-otwarcia-na-mundialu-nie-by-o,1125399.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 17:05:30+00:00

<img alt="Takiego gola otwarcia na mundialu nie było" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u9dria-enner-valencia-strzelil-pierwszego-gola-mundialu-w-katarze/alternates/LANDSCAPE_1280" />
    Enner Valencia z pierwszą bramką w Katarze.

## Szybki gol anulowany, Katarowi się upiekło. Tłumaczymy, skąd taka decyzja sędziego
 - [https://eurosport.tvn24.pl/szybki-gol-anulowany--katarowi-si--upiek-o--t-umaczymy--sk-d-taka-decyzja-s-dziego,1125398.html?source=rss](https://eurosport.tvn24.pl/szybki-gol-anulowany--katarowi-si--upiek-o--t-umaczymy--sk-d-taka-decyzja-s-dziego,1125398.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 16:55:35+00:00

<img alt="Szybki gol anulowany, Katarowi się upiekło. Tłumaczymy, skąd taka decyzja sędziego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xgcezb-trafienie-ennera-valencii-nie-zostalo-uznane/alternates/LANDSCAPE_1280" />
    Wiele pytań wzbudziła sytuacja z meczu otwarcia mistrzostw świata.

## Kapitalny Ekwador z kolejnym golem. Katar w potrzasku
 - [https://eurosport.tvn24.pl/mecz-otwarcia-mistrzostw--wiata-katar-2022--relacja-na--ywo,1125372.html?source=rss](https://eurosport.tvn24.pl/mecz-otwarcia-mistrzostw--wiata-katar-2022--relacja-na--ywo,1125372.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 16:20:00+00:00

<img alt="Kapitalny Ekwador z kolejnym golem. Katar w potrzasku
" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q5228c-rozpoczal-sie-mundial-w-katarze-6228910/alternates/LANDSCAPE_1280" />
    Katar - Ekwador. Relacja na żywo w eurosport.pl.

## On posędziuje pierwszy mecz Polaków. Egzotyczny wybór
 - [https://eurosport.tvn24.pl/on-pos-dziuje-pierwszy-mecz-polak-w--egzotyczny-wyb-r,1125390.html?source=rss](https://eurosport.tvn24.pl/on-pos-dziuje-pierwszy-mecz-polak-w--egzotyczny-wyb-r,1125390.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 15:54:54+00:00

<img alt="On posędziuje pierwszy mecz Polaków. Egzotyczny wybór" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ze1bsv-australijczyk-chris-beath-sedzia-meczu-meksyk-polska/alternates/LANDSCAPE_1280" />
    Coraz mniej znaków zapytania towarzyszy wielce wyczekiwanemu spotkaniu Polski z Meksykiem na mundialu.

## Oto maskotka mundialu w Katarze
 - [https://eurosport.tvn24.pl/u-miechni-ty-la-eeb--zaprezentowano-maskotk--mundialu-w-katarze,1125387.html?source=rss](https://eurosport.tvn24.pl/u-miechni-ty-la-eeb--zaprezentowano-maskotk--mundialu-w-katarze,1125387.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 15:46:18+00:00

<img alt="Oto maskotka mundialu w Katarze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qvzp5r-zaprezentowano-maskotke-mundialu-w-katarze/alternates/LANDSCAPE_1280" />
    Uśmiechnięty La'eeb.

## Holywoodzki aktor, dużo arabskiej kultury i wspomnień. Katarczycy otworzyli mundial
 - [https://eurosport.tvn24.pl/holywoodzki-aktor--du-o-arabskiej-kultury-i-wspomnie---katarczycy-otworzyli-mundial,1125375.html?source=rss](https://eurosport.tvn24.pl/holywoodzki-aktor--du-o-arabskiej-kultury-i-wspomnie---katarczycy-otworzyli-mundial,1125375.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 15:21:08+00:00

<img alt="Holywoodzki aktor, dużo arabskiej kultury i wspomnień. Katarczycy otworzyli mundial" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cvjk1i-otwarcie-mistrzostw-swiata-poprzedzilo-pierwszy-mecz-6228862/alternates/LANDSCAPE_1280" />
    Turniej oficjalnie wystartował.

## Gigantyczny przychód FIFA od ostatniego mundialu
 - [https://eurosport.tvn24.pl/gigantyczny-przych-d-fifa-od-ostatniego-mundialu,1125364.html?source=rss](https://eurosport.tvn24.pl/gigantyczny-przych-d-fifa-od-ostatniego-mundialu,1125364.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 14:11:17+00:00

<img alt="Gigantyczny przychód FIFA od ostatniego mundialu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-10wrj3-infantino-stoi-na-czele-fifa/alternates/LANDSCAPE_1280" />
    Poinformowała w dniu inauguracji mistrzostw świata w Katarze.

## Czas start. Zaczynamy mistrzostwa świata w Katarze
 - [https://eurosport.tvn24.pl/ceremonia-i-mecz-otwarcia-mistrzostw--wiata-katar-2022--relacja-na--ywo,1125372.html?source=rss](https://eurosport.tvn24.pl/ceremonia-i-mecz-otwarcia-mistrzostw--wiata-katar-2022--relacja-na--ywo,1125372.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 13:44:00+00:00

<img alt="Czas start. Zaczynamy mistrzostwa świata w Katarze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gpd198-ceremonia-i-mecz-otwarcia-na-mundialu-2022-ticker/alternates/LANDSCAPE_1280" />
    W eurosport.pl relacja z ceremonii otwarcia i pierwszego meczu mistrzostw świata Katar 2022.

## Skandal, który przekreślił marzenia Polek, porównany do słynnej "Hańby w Gijon"
 - [https://eurosport.tvn24.pl/skandal--kt-ry-przekre-li--marzenia-polek--por-wnany-do-s-ynnej--ha-by-w-gijon-,1125366.html?source=rss](https://eurosport.tvn24.pl/skandal--kt-ry-przekre-li--marzenia-polek--por-wnany-do-s-ynnej--ha-by-w-gijon-,1125366.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 13:35:00+00:00

<img alt="Skandal, który przekreślił marzenia Polek, porównany do słynnej " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qxgd9q-radosc-hiszpanki-po-golu-niemek/alternates/LANDSCAPE_1280" />
    Głos w sprawie zabrał prezydent Europejskiej Federacji Piłki Ręcznej (EHF) Michael Wiederer.

## Zaskoczenie polskich piłkarzy w Katarze
 - [https://eurosport.tvn24.pl/mundial-2022--pogoda-w-katarze-zaskoczy-a-polskich-pi-karzy,1125369.html?source=rss](https://eurosport.tvn24.pl/mundial-2022--pogoda-w-katarze-zaskoczy-a-polskich-pi-karzy,1125369.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 13:34:00+00:00

<img alt="Zaskoczenie polskich piłkarzy w Katarze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rnatqp-reprezentacja-polski-rozpocznie-mundial-od-meczu-z-meksykiem/alternates/LANDSCAPE_1280" />
    Niedzielna konferencja kadry.

## "Wyrafinowany sposób uzależniania". Czy jest jeszcze możliwość powstrzymania ofensywy chińskiej?
 - [https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-1204,S00E1204,917148?source=rss](https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-1204,S00E1204,917148?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 13:15:04+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cqi1nh-shutterstock634594757-6228669/alternates/LANDSCAPE_1280" />
    Film dokumentalny o uzależnianiu się krajów świata od Chin.

## Ruszyła "Strefa Kibica - Mundial" w TVN24
 - [https://eurosport.tvn24.pl/ruszy-a--strefa-kibica---mundial--w-tvn24,1125360.html?source=rss](https://eurosport.tvn24.pl/ruszy-a--strefa-kibica---mundial--w-tvn24,1125360.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 12:13:00+00:00

<img alt="Ruszyła " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9jm3zl-ruszyla-strefa-kibica-mundial/alternates/LANDSCAPE_1280" />
    Start mistrzostw świata w Katarze to także początek specjalnego cyklu w TVN24.

## "Od razu odmówiliśmy, dławiąc się przy czytaniu umowy"
 - [https://eurosport.tvn24.pl/wielkie--ledztwo-afp--jak-katar-kupowa--kibic-w,1125357.html?source=rss](https://eurosport.tvn24.pl/wielkie--ledztwo-afp--jak-katar-kupowa--kibic-w,1125357.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 08:58:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dku2j1-katar-kibice-mundial-2022-6228357/alternates/LANDSCAPE_1280" />
    Jak Katar kupował kibiców.

## Kupił i wyremontował domy dla dzieci. Piotr Zieliński wielki nie tylko na boisku
 - [https://eurosport.tvn24.pl/kupi--i-wyremontowa--domy-dla-dzieci--piotr-zieli-ski-wielki-nie-tylko-na-boisku,1124098.html?source=rss](https://eurosport.tvn24.pl/kupi--i-wyremontowa--domy-dla-dzieci--piotr-zieli-ski-wielki-nie-tylko-na-boisku,1124098.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 08:15:05+00:00

<img alt="Kupił i wyremontował domy dla dzieci. Piotr Zieliński wielki nie tylko na boisku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yew1yo-piotr-zielinski/alternates/LANDSCAPE_1280" />
    - Trzy komunie mieliśmy w tym roku, nawet chrzciny. Jest jak w normalnym domu - mówi eurosport.pl Bogdan Zieliński, ojciec reprezentanta Polski.

## Terminarz mundialu. Mecz po meczu
 - [https://eurosport.tvn24.pl/mundial-w-katarze-2022---terminarz--wyniki-i-grupy,1122528.html?source=rss](https://eurosport.tvn24.pl/mundial-w-katarze-2022---terminarz--wyniki-i-grupy,1122528.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 06:05:00+00:00

<img alt="Terminarz mundialu. Mecz po meczu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h9vulf-trofeum-pilkarskich-mistrzostw-swiata/alternates/LANDSCAPE_1280" />
    Zobacz podział na grupy, terminarz, tabele i wyniki meczów MŚ.

## 60-tysięczny stadion i gwiazdy światowej muzyki. O której godzinie ceremonia otwarcia mundialu 2022?
 - [https://eurosport.tvn24.pl/60-tysi-czny-stadion-i-gwiazdy--wiatowej-muzyki--kiedy-i-o-kt-rej-godzinie-ceremonia-otwarcia-mundialu-2022-,1124972.html?source=rss](https://eurosport.tvn24.pl/60-tysi-czny-stadion-i-gwiazdy--wiatowej-muzyki--kiedy-i-o-kt-rej-godzinie-ceremonia-otwarcia-mundialu-2022-,1124972.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 05:33:00+00:00

<img alt="60-tysięczny stadion i gwiazdy światowej muzyki. O której godzinie ceremonia otwarcia mundialu 2022?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pyo3q2-ceremonia-otwarcia-mundialu-w-katarze-odbedzie-sie-na-stadionie-al-bayt/alternates/LANDSCAPE_1280" />
    Najważniejsze informacje.

## Zmierzch bogów, podejrzenia i wiele wątpliwości
 - [https://eurosport.tvn24.pl/zmierzch-bog-w--podejrzenia-i-wiele-w-tpliwo-ci--katar-zaprasza-na-mundial,1125152.html?source=rss](https://eurosport.tvn24.pl/zmierzch-bog-w--podejrzenia-i-wiele-w-tpliwo-ci--katar-zaprasza-na-mundial,1125152.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 05:25:00+00:00

<img alt="Zmierzch bogów, podejrzenia i wiele wątpliwości" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8gg260-ronaldo-czy-messi/alternates/LANDSCAPE_1280" />
    Mistrzostwa świata w piłce nożnej 2022 czas zacząć.

## Anna Seniuk: im mniej gram, tym więcej żyję
 - [https://tvn24.pl/go/programy,7/bez-polityki-odcinki,413879/odcinek-106,S00E106,916387?source=rss](https://tvn24.pl/go/programy,7/bez-polityki-odcinki,413879/odcinek-106,S00E106,916387?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-11-20 04:00:00+00:00

<img alt="Anna Seniuk: im mniej gram, tym więcej żyję" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n6tc60-bez-polityki-anna-seniuk-6228127/alternates/LANDSCAPE_1280" />
    Opowiedziała między innymi o swoim debiucie w monodramie  ("Życie pani Pomsel"), o aktorstwie i życiu rodzinnym.


# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Teoria przejść filmowych 🎬 Dopasowanie do siebie ujęć na 3 sposoby [ Lekcja próbna z kursu ]
 - [https://www.youtube.com/watch?v=nVSUCSKb-c0](https://www.youtube.com/watch?v=nVSUCSKb-c0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2022-11-20 08:00:12+00:00

ZAMKNIĘCIE KURSU FILMOWO MONTAŻOWEGO 28.11.2022
Kurs filmowo-montażowy 🎬 https://www.kursfilmowaniaimontazu.pl/
Dodatek Podróżniczy 🎬 http://filmypodroznicze.pl/
Filmowy klaps info 🎬 https://youtu.be/5sw6a9UgHEA

W najbliższej przyszłości, jak już mówiłem będzie mniej podróży. Niemniej dziś wpadam z filmem pośrednio podróżniczym, mianowicie z próbną lekcją z kursu filmowo-montażowego Kołem Się Toczy 😊 Jednak zanim obejrzycie, przeczytajcie te kilka zdań proszę. Bo to ważne 🙂
Wiele osób pyta mnie: Czy dzięki kursowi nauczy się robić ciekawe i atrakcyjne dla oka filmy?
Odpowiadając - TAK! Oczywiście.
Ale...
Nie chciałbym, aby tylko tak ten kurs był traktowany. To nie jest kurs TYLKO o przejściach. Jest to naprawdę obszerny, kompleksowy kurs przygotowany według ścisłego, przemyślanego scenariusza. Bez pitu-pitu. Zaplanowany tak, aby przejść od podstaw do rzeczy zaawansowanych przyswajając wszystkie etapy filmowo-montażowe po drodze.
I owszem - przejścia są sporą częścią zarówno segmentu filmowego (teoria przejść jak dzisiaj), a także segmentu montażowego (masa przykładów, montaż krok po kroku + pliki projektowe i ujęcia do ćwiczenia). Jednak chciałbym, abyście nie myśleli o tym kursie tylko w kontekście przejść i robienia atrakcyjnych ujęć. 
Znajdziecie w kursie masę ogólnej i zaawansowanej wiedzy, która pozwoli Wam świadomie robić ciekawe filmy pełne pięknych ujęć, historii i emocji. Bo to jest w filmach najważniejsze - pamiętajcie 😊 Będziemy nie tylko uczyć robić się przejścia, ale także jak z sensem z nich korzystać, aby nie były tylko efektem samym w sobie. Aby były przede wszystkim wsparciem dla historii, emocji i fabuły filmu. I co ważne - kurs ten jest dla Was, niezależnie jaką tematyką chcecie się zajmować. Nie tylko filmami z podróży, ale dokumentami, filmami eventowymi, reklamowymi, przyrodniczymi, nawet reportażowymi. Natomiast jeśli zechcecie pójść w filmy typowo podróżnicze, to możecie się też zainteresować Dodatkiem Podróżniczym
No ale nie przedłużając...
Zapraszam!


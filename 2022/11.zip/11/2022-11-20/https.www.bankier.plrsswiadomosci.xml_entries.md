# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Media: Kazachstan może stać się nową stacją benzynową dla Europy. Kraj powoli odsuwa się od Rosji
 - [https://www.bankier.pl/wiadomosc/Media-Kazachstan-moze-stac-sie-nowa-stacja-benzynowa-dla-Europy-Kraj-powoli-odsuwa-sie-od-Rosji-8442987.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Media-Kazachstan-moze-stac-sie-nowa-stacja-benzynowa-dla-Europy-Kraj-powoli-odsuwa-sie-od-Rosji-8442987.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 22:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/2/9305cd156c9b68-948-568-0-109-2914-1748.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Bogaty w ropę naftową Kazachstan stopniowo odsuwa się od Rosji. O względy Kazachstanu zabiegają Europa oraz Chiny. Prezydenta Kasyma-Żomarta Tokajewa, który wg sondaży w niedzielnych wyborach zdobył blisko 82 proc. głosów, odwiedzili w ostatnim czasie wysocy urzędnicy UE i szefowie rządów Niemiec czy Turcji – analizuje portal dziennika „Handelsblatt”(HB).</p>

## Zełenski: Na wschodzie Ukrainy mamy 400 rosyjskich ostrzałów w ciągu dnia
 - [https://www.bankier.pl/wiadomosc/Zelenski-Na-wschodzie-Ukrainy-mamy-400-rosyjskich-ostrzalow-w-ciagu-dnia-8442974.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zelenski-Na-wschodzie-Ukrainy-mamy-400-rosyjskich-ostrzalow-w-ciagu-dnia-8442974.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 20:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/4/76a76072490dcf-948-568-0-33-1043-625.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na wschodzie kraju w ciągu dnia mamy już 400 (rosyjskich ostrzałów); najcięższe walki w obwodzie donieckim, a w obwodzie ługańskim powoli, z walkami, idziemy do przodu – powiedział w wystąpieniu wieczorem w niedzielę Wołodymyr Zełenski.</p>

## Kaczyński: Chcemy, żeby banki podniosły oprocentowanie wkładów
 - [https://www.bankier.pl/wiadomosc/Kaczynski-Chcemy-zeby-banki-podniosly-oprocentowanie-wkladow-8442949.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kaczynski-Chcemy-zeby-banki-podniosly-oprocentowanie-wkladow-8442949.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 18:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/5/37066c125c6289-948-568-0-167-1702-1021.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />My walczymy, mówię tutaj o rządzie, ale i o mnie jako szefie obozu rządzącego, żeby banki podniosły wszystkie oprocentowania wkładów - powiedział w Kędzierzynie-Koźlu prezes Prawa i Sprawiedliwości Jarosław Kaczyński.</p>

## Sasin potwierdza. Wzrośnie VAT na paliwa i nawozy
 - [https://www.bankier.pl/wiadomosc/Sasin-potwierdza-Wzrosnie-VAT-na-paliwa-i-nawozy-8442931.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sasin-potwierdza-Wzrosnie-VAT-na-paliwa-i-nawozy-8442931.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 18:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/e/54e998fd23cc29-948-568-20-10-3980-2387.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Będziemy musieli przywrócić wyższe stawki VAT nie tylko w przypadku energii elektrycznej, ale także w przypadku paliw i nawozów; możemy za to utrzymać zerowy VAT na żywność - tłumaczył w niedzielę wicepremier i minister aktywów państwowych Jacek Sasin.</p>

## Prezes PiS: Euro to waluta dla bardzo silnej gospodarki
 - [https://www.bankier.pl/wiadomosc/Prezes-PiS-Euro-to-waluta-dla-bardzo-silnej-gospodarki-8442933.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezes-PiS-Euro-to-waluta-dla-bardzo-silnej-gospodarki-8442933.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 16:52:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/1/c46debef6684a4-948-567-20-72-980-587.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Euro to waluta dla bardzo silnej gospodarki, dlatego nie możemy podjąć decyzji o jego przyjęciu – powiedział w niedzielę w Kędzierzynie-Koźlu prezes PiS Jarosław Kaczyński.</p>

## Sasin: Rafineria Gdańska będzie wpisana do specjalnego rozporządzenia
 - [https://www.bankier.pl/wiadomosc/Sasin-Rafineria-Gdanska-bedzie-wpisana-do-specjalnego-rozporzadzenia-8442927.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sasin-Rafineria-Gdanska-bedzie-wpisana-do-specjalnego-rozporzadzenia-8442927.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 16:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/e/439858e3c99d5a-948-568-0-42-1200-719.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po fuzji Orlenu z Lotosem, w rozporządzeniu wskażemy wyraźnie, że Rafineria Gdańska należy do przedsiębiorstw, których niekontrolowana sprzedaż nie jest możliwa - poinformował w niedzielę wicepremier Jacek Sasin.</p>

## Finlandia zbuduje zaporę na granicy z Rosją
 - [https://www.bankier.pl/wiadomosc/Finlandia-zbuduje-zapore-na-granicy-z-Rosja-8442919.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Finlandia-zbuduje-zapore-na-granicy-z-Rosja-8442919.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 15:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/8/9bd13706cba3a5-948-568-10-2-955-573.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W przyszłym roku Finlandia rozpocznie budowę zapory na granicy z Rosją – zapowiedziała podczas konferencji prasowej w Helsinkach premier tego kraju Sanna Marin.</p>

## Kaczyński twierdzi, że hipermarkety nie są "odpowiednio opodatkowane". Wspomniał też o "patologicznym układzie"
 - [https://www.bankier.pl/wiadomosc/Kaczynski-twierdzi-ze-hipermarkety-nie-sa-odpowiednio-opodatkowane-Wspomnial-tez-o-patologicznym-ukladzie-8442910.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kaczynski-twierdzi-ze-hipermarkety-nie-sa-odpowiednio-opodatkowane-Wspomnial-tez-o-patologicznym-ukladzie-8442910.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 14:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/a/f9cce7d09d1fad-948-568-112-18-1228-737.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Działające w Polsce zagraniczne sklepy wielkopowierzchniowe – hipermarkety - nie są w Polsce odpowiednio opodatkowane, choć powinny – przyznał podczas niedzielnego spotkania w Gliwicach prezes PiS Jarosław Kaczyński. Jak ocenił, zmianom w tym zakresie sprzeciwia się UE.</p>

## Handel na linii UE-Wielka Brytania. Rząd rozważa pójść w ślady Szwajcarii
 - [https://www.bankier.pl/wiadomosc/Handel-na-linii-UE-Wielka-Brytania-Rzad-rozwaza-pojsc-w-slady-Szwajcarii-8442897.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Handel-na-linii-UE-Wielka-Brytania-Rzad-rozwaza-pojsc-w-slady-Szwajcarii-8442897.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 14:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/7/c26fa91bd1a811-948-568-0-21-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Brytyjski rząd, aby usunąć problemy w handlu z Unią Europejską, rozważa plan zawarcia z nią umów podobnych do tych, jakie ma Szwajcaria, ale w żadnym wypadku nie ma mowy o powrocie do swobodnego przepływu osób - podał w niedzielę "The Sunday Times".</p>

## Gitara Kurta Cobaina, zegarek Presleya czy okulary Lennona - grube pieniądze za pamiątki po idolach
 - [https://www.bankier.pl/wiadomosc/Gitara-Kurta-Cobaina-zegarek-Presleya-czy-okulary-Lennona-grube-pieniadze-za-pamiatki-po-idolach-8438499.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gitara-Kurta-Cobaina-zegarek-Presleya-czy-okulary-Lennona-grube-pieniadze-za-pamiatki-po-idolach-8438499.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 09:00:00+00:00

<p>Roztrzaskana gitara Kurta Cobaina, legendarnego wokalisty i gitarzysty zespołu Nirvana, została sprzedana na aukcji w Nowym Jorku za 486 tysięcy dolarów - poinformował jej organizator, dom aukcyjny Julien's.</p>

## Konwój z gigantyczną maszyną utrudni ruch na drogach w woj. lubelskim [TRASA]
 - [https://www.bankier.pl/wiadomosc/Konwoj-z-gigantyczna-maszyna-utrudni-ruch-na-drogach-w-woj-lubelskim-TRASA-8442144.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Konwoj-z-gigantyczna-maszyna-utrudni-ruch-na-drogach-w-woj-lubelskim-TRASA-8442144.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/9/ca8ea525f18bf5-948-569-24-0-1026-616.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od poniedziałku do czwartku drogami ekspresowymi S17 i S19 w woj. lubelskim przejedzie konwój transportujący gigantyczną tarczę TBM, która wydrąży tunel na trasie S19 na Podkarpaciu; możliwe są zatory - poinformował Łukasz Minkiewicz z lubelskiego oddziału GDDKiA.</p>

## Więcej Polaków za inwestycjami w górnictwo węglowe niż przeciw nim
 - [https://www.bankier.pl/wiadomosc/Wiecej-Polakow-za-inwestycjami-w-gornictwo-weglowe-niz-przeciw-nim-8442824.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wiecej-Polakow-za-inwestycjami-w-gornictwo-weglowe-niz-przeciw-nim-8442824.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 07:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/4/9275a1dd21094f-948-568-0-43-1748-1049.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />40,3 proc. respondentów uważa, że Polska powinna zwiększyć inwestycje w górnictwo węglowe, czego domaga się Solidarna Polska, 29,1 proc. badanych jest przeciwnego zdania, a 30,6 proc. ankietowanych nie ma zdania w tej kwestii - wynika z sondażu SW Research dla rp.pl.</p>

## "Washington Post": w Rosji będą produkowane irańskie drony bojowe
 - [https://www.bankier.pl/wiadomosc/Washington-Post-w-Rosji-beda-produkowane-iranskie-drony-bojowe-8442819.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Washington-Post-w-Rosji-beda-produkowane-iranskie-drony-bojowe-8442819.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 07:18:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/3/7f40059fd97c69-948-568-33-157-4459-2675.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rosja i Iran porozumiały się w sprawie budowy "setek" dronów bojowych według irańskiego projektu na terytorium Rosji - poinformował dziennik "Washington Post", powołując się na anonimowe źródła. Umowę sfinalizowano na początku listopada podczas wizyty rosyjskiej delegacji w Iranie.</p>

## Kontrowersyjne pytania w ankiecie dla uczniów. Czarnek odpowiada Rzecznikowi Praw Obywatelskich
 - [https://www.bankier.pl/wiadomosc/Kontrowersyjne-pytania-w-ankiecie-dla-uczniow-Czarnek-odpowiada-Rzecznikowi-Praw-Obywatelskich-8442425.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kontrowersyjne-pytania-w-ankiecie-dla-uczniow-Czarnek-odpowiada-Rzecznikowi-Praw-Obywatelskich-8442425.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/d/bc538c44d5d6b7-948-568-0-44-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rodzice uczniów zostali poinformowani o badaniu, umożliwiono im przed nim dostęp i wgląd do ankiet. Rodzice, którzy nie wyrazili zgodny na udział ich dzieci w badaniu, mieli możliwość poinformowania o tym - napisał minister edukacji i nauki Przemysław Czarnek w odpowiadając RPO.</p>

## Większość Polaków nie wie, kto ma ich dane osobowe, i nie potrafi ich dobrze chronić
 - [https://www.bankier.pl/wiadomosc/Wiekszosc-Polakow-nie-wie-kto-ma-ich-dane-osobowe-i-nie-potrafi-ich-dobrze-chronic-8441133.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wiekszosc-Polakow-nie-wie-kto-ma-ich-dane-osobowe-i-nie-potrafi-ich-dobrze-chronic-8441133.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/b/e90fec13d27da6-948-568-0-27-1847-1108.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad 80 proc. Polaków nie wie, gdzie są ich dane osobowe, a ok. 70 proc. nie potrafi należycie ich chronić - wynika z badania serwisu ChronPESEL i Krajowego Rejestru Długów. Dodano, że 65 proc. Polaków obawia się o bezpieczeństwo tych danych przekazywanych firmom i instytucjom.</p>

## 10 tys. zł długiem nierealnym do spłaty? Tak, dla 36 proc. kobiet i 24 proc. mężczyzn
 - [https://www.bankier.pl/wiadomosc/10-tys-zl-dlugiem-nierealnym-do-splaty-Tak-dla-36-proc-kobiet-i-24-proc-mezczyzn-8442795.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/10-tys-zl-dlugiem-nierealnym-do-splaty-Tak-dla-36-proc-kobiet-i-24-proc-mezczyzn-8442795.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 05:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/6/3a5f1d7a5ff0e3-948-568-0-0-2407-1444.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />10 tys. zł to zadłużenie nierealne do spłacenia dla 36 proc. kobiet i 24 proc. mężczyzn - wynika z badania Rejestru Dłużników BIG InfoMonitor.</p>

## 1,2 mln podatników musi się liczyć z dopłatami przy rozliczeniu rocznym za 2022 r.
 - [https://www.bankier.pl/wiadomosc/1-2-mln-podatnikow-musi-sie-liczyc-z-doplatami-przy-rozliczeniu-rocznym-za-2022-r-8442792.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/1-2-mln-podatnikow-musi-sie-liczyc-z-doplatami-przy-rozliczeniu-rocznym-za-2022-r-8442792.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 05:21:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/9/ea840c32521ca6-948-568-0-151-2250-1349.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szacuje się, że około 1,2 mln podatników musi się liczyć z dopłatami przy rozliczeniu rocznym za 2022 r. – wynika z odpowiedzi Ministerstwa Finansów na pytania PAP.</p>

## COP27 przyjęła kompromisową rezolucję. Powstanie mechanizm strat i szkód
 - [https://www.bankier.pl/wiadomosc/COP27-przyjela-kompromisowa-rezolucje-Powstanie-mechanizm-strat-i-szkod-8442790.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/COP27-przyjela-kompromisowa-rezolucje-Powstanie-mechanizm-strat-i-szkod-8442790.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 05:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/4/1001c8ad1b082d-948-568-25-162-4750-2850.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Konferencja klimatyczna ONZ przyjęła w niedzielę rano deklarację końcową wzywającą do „szybkiej” redukcji emisji gazów cieplarnianych i potwierdzającą cel ograniczenia globalnego ocieplenia do 1,5 st. C., informuje AFP.</p>

## Brickit pokaże, co zbudować z klocków Lego, które już mamy w domu
 - [https://www.bankier.pl/wiadomosc/Klocki-Lego-Brickit-pokaze-co-zbudowac-z-klockow-Lego-ktore-mamy-w-domu-8436438.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Klocki-Lego-Brickit-pokaze-co-zbudowac-z-klockow-Lego-ktore-mamy-w-domu-8436438.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/9/1223edc1afc752-948-568-0-135-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Co można zbudować z klocków Lego, które tworzą na 
podłodze niemal Himalaje? Jeśli dodamy do tego pogubione instrukcje i 
małolata, który się nudzi - to rzeczywistość długich jesienno-zimowych 
wieczorów może być trudna do przetrwania. Aplikacja Brickit przybywa z 
pomocą. Jednym przyciskiem smartfona można zeskanować elementy, a ona 
podsunie pomysł, co można z nich zbudować. </p>

## Eksperci: W rękach inwestorów instytucjonalnych jest nieco ponad 9000 mieszkań na wynajem
 - [https://www.bankier.pl/wiadomosc/Eksperci-W-rekach-inwestorow-instytucjonalnych-jest-nieco-ponad-9000-mieszkan-na-wynajem-8442787.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Eksperci-W-rekach-inwestorow-instytucjonalnych-jest-nieco-ponad-9000-mieszkan-na-wynajem-8442787.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/3/70409101b3a3fd-948-568-34-714-4569-2741.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W największych aglomeracjach w rękach inwestorów instytucjonalnych jest nieco ponad 9000 mieszkań na wynajem, czego prawie połowa w stolicy - mówią PAP rynkowi eksperci.</p>

## Sprzedaż nowych mieszkań nurkuje, choć październik nie był najgorszy
 - [https://www.bankier.pl/wiadomosc/Sprzedaz-nowych-mieszkan-nurkuje-Choc-pazdziernik-nie-byl-najgorszy-8436455.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sprzedaz-nowych-mieszkan-nurkuje-Choc-pazdziernik-nie-byl-najgorszy-8436455.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/a/766ef0025210af-948-568-0-210-4667-2800.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W okresie dziesięciu miesięcy 2022 r. (styczeń-październik) w siedmiu największych miastach Polski deweloperzy sprzedali 28,2 tys. mieszkań, czyli o 35 proc. mniej rdr - wynika z danych BIG DATA RynekPierwotny.pl. W październiku deweloperzy znaleźli chętnych na łącznie blisko 3,2 tys. mieszkań, o 22 proc. więcej mdm.</p>

## TOP5 laptopów do gier do 4000 zł
 - [https://www.bankier.pl/wiadomosc/TOP5-laptopow-do-gier-do-4000-zl-8438638.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/TOP5-laptopow-do-gier-do-4000-zl-8438638.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/e/18e9f48dd02253-948-568-0-67-1000-600.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Czy można kupić dobry laptop dla gracza do 4000 złotych? Odpowiedź brzmi – jak najbardziej tak! Przygotowaliśmy zestawienie 5 najlepszych modeli wyposażonych w niezwykle mocne podzespoły. Wybierz swój wymarzony komputer przenośny i ciesz się ulubionymi grami w każdym miejscu.</p>

## Donald Trump wrócił na Twittera. Musk uaktywnił jego konto po głosowaniu użytkowników
 - [https://www.bankier.pl/wiadomosc/Donald-Trump-wrocil-na-Twittera-Musk-uaktywnil-jego-konto-8442777.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Donald-Trump-wrocil-na-Twittera-Musk-uaktywnil-jego-konto-8442777.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-20 01:27:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/d/71099a5cb26cde-948-568-2-62-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nieco ponad 15 milionów użytkowników Twittera głosowało w ankiecie, czy Trump może wrócić  na Twittera. Za  głosowało 51,8 proc. uczestników ankiety. Elon Mask zapowiedział, że przywróci konto zbanowanego prezydenta. Trump odpowiedział, że nie jest tym zainteresowany.</p>


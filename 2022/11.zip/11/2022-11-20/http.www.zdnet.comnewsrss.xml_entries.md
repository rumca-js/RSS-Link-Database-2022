# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## Three tech trends on the verge of a breakthrough in 2023
 - [https://www.zdnet.com/article/three-tech-trends-on-the-verge-of-a-breakthrough-in-2023/#ftag=RSSbaffb68](https://www.zdnet.com/article/three-tech-trends-on-the-verge-of-a-breakthrough-in-2023/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-20 23:00:21+00:00

The next year will see big leaps ahead for some technologies, and tiny but important steps for others.

## Amazon spreads joy (while firing 10,000 people)
 - [https://www.zdnet.com/article/amazon-spreads-joy-while-firing-10000-people/#ftag=RSSbaffb68](https://www.zdnet.com/article/amazon-spreads-joy-while-firing-10000-people/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-20 13:00:20+00:00

The finest of plans sometimes come up against the most awkward interference.

## I scoured Amazon for ridiculous travel gadgets. I didn't expect this
 - [https://www.zdnet.com/article/i-scoured-amazon-for-ridiculous-travel-gadgets-i-didnt-expect-this/#ftag=RSSbaffb68](https://www.zdnet.com/article/i-scoured-amazon-for-ridiculous-travel-gadgets-i-didnt-expect-this/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-20 12:00:20+00:00

Is it brilliant? Is it absurd? The answers may be yes and yes.

## I scoured Amazon for ridiculous travel gadgets. I never thought I'd see this
 - [https://www.zdnet.com/article/i-scoured-amazon-for-ridiculous-travel-gadgets-i-never-thought-id-see-this/#ftag=RSSbaffb68](https://www.zdnet.com/article/i-scoured-amazon-for-ridiculous-travel-gadgets-i-never-thought-id-see-this/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-11-20 12:00:00+00:00

Is it brilliant? Is it absurd? The answers may be yes and yes.


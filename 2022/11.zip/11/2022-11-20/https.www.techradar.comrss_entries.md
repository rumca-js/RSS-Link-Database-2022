# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## YouTube for TV gets a new start up sound – and could be adding comments
 - [https://www.techradar.com/news/youtube-for-tv-gets-a-new-start-up-sound-and-could-be-adding-comments/](https://www.techradar.com/news/youtube-for-tv-gets-a-new-start-up-sound-and-could-be-adding-comments/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-11-20 17:30:41+00:00

If you're using YouTube on your TV then you might have noticed a couple of new features appearing.

## OnePlus Buds Pro 2 design gets shown off in unofficial renders
 - [https://www.techradar.com/news/oneplus-buds-pro-2-design-gets-shown-off-in-unofficial-renders/](https://www.techradar.com/news/oneplus-buds-pro-2-design-gets-shown-off-in-unofficial-renders/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-11-20 13:30:02+00:00

We might not see the OnePlus Buds Pro 2 until next year, but a new leak suggests they'll have a familiar look.

## Meet the smartest office building in the world
 - [https://www.techradar.com/news/meet-the-smartest-office-building-in-the-world/](https://www.techradar.com/news/meet-the-smartest-office-building-in-the-world/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-11-20 13:04:24+00:00

TechRadar Pro heads to Singapore to view the office of the future.

## Farewell to the Nvidia RTX 2060, the 2nd most popular gaming GPU
 - [https://www.techradar.com/news/farewell-to-the-nvidia-rtx-2060-the-2nd-most-popular-gaming-gpu/](https://www.techradar.com/news/farewell-to-the-nvidia-rtx-2060-the-2nd-most-popular-gaming-gpu/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-11-20 11:00:24+00:00

The RTX 2060 Super is also getting the axe as Nvidia moves to end production and supply of the successful graphics card.

## Black Friday 2022 live: more deals today as prices continue to drop
 - [https://www.techradar.com/news/live/black-friday-2022-live-more-deals-today-as-prices-continue-to-drop/](https://www.techradar.com/news/live/black-friday-2022-live-more-deals-today-as-prices-continue-to-drop/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-11-20 07:53:18+00:00

All the latest Black Friday news and deals on Sunday, November 20


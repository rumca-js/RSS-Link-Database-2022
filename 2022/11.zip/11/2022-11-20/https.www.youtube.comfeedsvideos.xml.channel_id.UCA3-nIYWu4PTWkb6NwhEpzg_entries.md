# Source:Ryan Reynolds, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg, language:en-US

## Artificial Mintelligence
 - [https://www.youtube.com/watch?v=eRhJ-nfRd-4](https://www.youtube.com/watch?v=eRhJ-nfRd-4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2022-11-21 00:00:00+00:00

I'm going to use this same tech for parent-teacher conferences this year.

Sign up for @MintMobile at https://mintmobile.com

## The Walking Deadvertising
 - [https://www.youtube.com/watch?v=Lv-i4FTF49E](https://www.youtube.com/watch?v=Lv-i4FTF49E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2022-11-21 00:00:00+00:00

Maximum Effort brought a few characters back to life for #TWD tonight. It was a stupid amount of work and fun, especially for commercials that will run just once. Worth it. #WalkingDeadvertising

The Deadvertisers... 
00:07 DoorDash - https://www.youtube.com/doordash
00:38 Autodesk - https://www.youtube.com/autodesk
01:09 Ring - https://www.youtube.com/ring
01:40 Deloitte - https://www.youtube.com/deloitteus
02:11 MNTN Performance TV - https://www.youtube.com/mntn


# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Sandały Steve'a Jobsa trzymają się lepiej niż Twitter i kryptowaluty #TechWeek
 - [https://www.youtube.com/watch?v=nydVwCr64TA](https://www.youtube.com/watch?v=nydVwCr64TA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-11-20 00:00:00+00:00

Link do Speakly: https://speakly.app.link/Speakly możecie wypróbować przez 7 dni za free, a przy rocznej subskrybcji jest 60% zniżki.

W odcinku:
00:00 Wstęp: Cała nadzieja w sandałach!
01:11 Dobry wieczór!
01:16 Czy to już koniec kryptowalut?
02:10 Historia giełdy FTX i jej upadku
07:23 Mike Tyson sprzedaje marihuanowe cukierki w kształcie ucha
08:28 Właścicielka firmy Theranos skazana 
09:24 Meta zwalnia 11 tysięcy pracowników
09:50 Musk wysyła maile
10:47 Donald Trump wróci na Twittera?
11:13 Afera weryfikacyjna na Twitterze
14:08 Nowy pomysł Elona Muska
14:25 Reklama: Speakly
15:07 Afera cenowa na Ticketmaster
15:42 XPENG G3 – chiński samochód latający
16:22 Mięso przyszłości wyhodowane w laboratorium
17:22 Testy krwi z laboratorium
18:18 Technologia przyszłości: szkła kontaktowe, ekrany i smartfony
18:54 Krzesło biurowe od Volkswagena
19:04 Świąteczny poradnik zakupowy – już za tydzień! Albo... dwa
19:14 Pożegnanie
19:18 Znośnego tygodnia!

Źrodła:
Sandały Jobsa sprzedane: https://cbsn.ws/3Gym00S
Czy to koniec krypto? http://bit.ly/3UUc2LI
Droga do upadku FTX: http://bit.ly/3Oo3g6a
Gwiazdy pozwane za reklamowanie FTX: http://bit.ly/3AvGGCJ
Binance sprzedaje FTT: http://bit.ly/3Avq3Hm
Binance chce "uratować" FTX: http://bit.ly/3Gx1ePi
Ostatecznie jednak rezygnuje: http://bit.ly/3AwhHiQ
SBF przeprasza na TT: http://bit.ly/3UVX9II
Atak "hakerów" na FTX po upadłości: http://bit.ly/3gs54OR
Uszy z marihuaną: http://bit.ly/3tLVyJr
Elizabeth Holmes skazana na 11 lat więzienia: http://bit.ly/3Okpyps
Meta zwalnia 11 tysięcy pracowników: http://bit.ly/3XhMxFG
Musk pisze maila do pracowników: http://bit.ly/3hYBwcc
Niebieski znaczek kosztuje niektóre firmy dużo więcej niż 8 dolarów: http://bit.ly/3EkSxF3
Bilety na koncerty Taylor Swift "nieco" za drogie: http://bit.ly/3TSGe8s
Chiński samochód latający: https://youtu.be/SLk3tfQmjMI
Mięso z laboratorium: http://bit.ly/3UOxGkm
Krew z laboratorium: http://bit.ly/3hRkcpj
Szkła kontaktowe zintegrowane z Alexą: http://bit.ly/3Ol5y5S
Rozciągliwe ekrany: http://bit.ly/3UQMSh5
Składany Pixel: http://bit.ly/3AvI1to
Składany iPhone: https://youtu.be/k1DxL-vyjfs
Krzesło VW: https://youtu.be/eU4Sh14d1wo

Moje sociale:
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter


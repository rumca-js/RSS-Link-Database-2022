# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## The Evacuation of the CIA’s Afghan Proxies Has Opened One of the War’s Blackest Boxes
 - [https://theintercept.com/2022/11/20/taliban-afghanistan-zero-unit-migrants/](https://theintercept.com/2022/11/20/taliban-afghanistan-zero-unit-migrants/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2022-11-20 11:00:42+00:00

<p>Former Zero Unit members are facing a reversal of fortune that is humiliating, infuriating, and utterly intractable. </p>
<p>The post <a href="https://theintercept.com/2022/11/20/taliban-afghanistan-zero-unit-migrants/" rel="nofollow">The Evacuation of the CIA’s Afghan Proxies Has Opened One of the War’s Blackest Boxes</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>


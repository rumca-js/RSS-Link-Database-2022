# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Best red carpet fashion at the 2022 American Music Awards
 - [https://www.cnn.com/style/article/red-carpet-american-music-awards-2022/index.html](https://www.cnn.com/style/article/red-carpet-american-music-awards-2022/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 23:49:41+00:00

Celebrities are stepping onto the red carpet at the Microsoft Theater in Los Angeles where the American Music Awards will take place later this evening.

## Police say they are investigating Colorado Springs suspect's past
 - [https://edition.cnn.com/us/live-news/colorado-springs-club-q-mass-shooting/index.html](https://edition.cnn.com/us/live-news/colorado-springs-club-q-mass-shooting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 23:02:06.086471+00:00



## Mayor says 'heroic' individuals subdued shooter with his gun
 - [https://www.cnn.com/videos/us/2022/11/20/colorado-springs-mayor-lgbtq-nightclub-shooter-take-down-sot-vpx.cnn](https://www.cnn.com/videos/us/2022/11/20/colorado-springs-mayor-lgbtq-nightclub-shooter-take-down-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 22:15:53+00:00

Mayor of Colorado Springs, Colorado, John Suthers tells CNN's Jim Acosta how individuals at Club Q were able to stop a 22-year-old suspect who opened fire inside the LGBTQ nightclub.

## Biden on Colorado Springs mass shooting: 'Jill and I are praying for the families'
 - [https://edition.cnn.com/us/live-news/colorado-springs-club-q-mass-shooting/h_ec4171adbc0fcff1f83cc452a833b34a](https://edition.cnn.com/us/live-news/colorado-springs-club-q-mass-shooting/h_ec4171adbc0fcff1f83cc452a833b34a)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 22:02:04.427481+00:00



## In pictures: Mass shooting at LGBTQ club in Colorado
 - [https://www.cnn.com/2022/11/20/us/gallery/colorado-lgbtq-club-shooting/index.html](https://www.cnn.com/2022/11/20/us/gallery/colorado-lgbtq-club-shooting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 21:27:10+00:00

Five people were killed and 25 injured in a mass shooting Saturday at an LGBTQ nightclub in Colorado Springs, Colorado, authorities said Sunday.

## What former CIA director noticed about Trump's response to DOJ investigation
 - [https://www.cnn.com/videos/politics/2022/11/20/trump-response-doj-investigation-leon-panetta-acostanr-vpx.cnn](https://www.cnn.com/videos/politics/2022/11/20/trump-response-doj-investigation-leon-panetta-acostanr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 21:24:07+00:00

Former CIA director Leon Panetta discusses former President Trump's reaction to the Department of Justice naming a special counsel to oversee the criminal investigations of former President Donald Trump.

## Collapsed FTX owes nearly $3.1 billion to top 50 creditors
 - [https://www.cnn.com/2022/11/20/tech/ftx-billions-owed-creditors/index.html](https://www.cnn.com/2022/11/20/tech/ftx-billions-owed-creditors/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 20:05:51+00:00

Cryptocurrency exchange FTX, which has filed for US bankruptcy court protection, said it owes its 50 biggest creditors nearly $3.1 billion.

## See the moment a British comedian shreds £10,000 over David Beckham deal with Qatar
 - [https://www.cnn.com/videos/world/2022/11/20/british-comedian-burns-money-david-beckham-qatar-world-cup-cprog-orig-aw.cnn](https://www.cnn.com/videos/world/2022/11/20/british-comedian-burns-money-david-beckham-qatar-world-cup-cprog-orig-aw.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 19:44:41+00:00

Joe Lycett appeared to feed wads of banknotes into a shredder after calling out David Beckham over his role as Qatar's World Cup ambassador. The country has been criticized for mistreatment of people in the LGBTQ+ community.

## A comedian has apparently shredded £10,000 over David Beckham's role as Qatar's World Cup ambassador
 - [https://www.cnn.com/2022/11/20/football/david-beckham-joe-lycett-world-cup-spt-intl/index.html](https://www.cnn.com/2022/11/20/football/david-beckham-joe-lycett-world-cup-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 19:12:21+00:00

• Alcohol bans. Female referees. How this World Cup is one of firsts
• Explosive tirade: FIFA boss slams critics
• 'Don't feel comfortable traveling to Qatar': Dissenting voices are getting louder

## Storm continues to lash western New York with up to 6 feet of snow
 - [https://www.cnn.com/videos/us/2022/11/20/buffalo-new-york-snow-storm-cnntmw-vpx.cnn](https://www.cnn.com/videos/us/2022/11/20/buffalo-new-york-snow-storm-cnntmw-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 18:15:45+00:00

Heavy snow continues to pile up in western New York state after a historic storm saw the Buffalo area logging record snowfall totaling more than six feet in some areas.

## Host Qatar faces Ecuador in opening match of tournament mired in controversy
 - [https://www.cnn.com/sport/live-news/world-cup-opening-ceremony-11-20-2022/index.html](https://www.cnn.com/sport/live-news/world-cup-opening-ceremony-11-20-2022/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 17:45:21+00:00

• Alcohol bans. Female referees. How this World Cup is one of firsts
• Explosive tirade: FIFA boss slams critics
• 'Don't feel comfortable traveling to Qatar': Dissenting voices are getting louder

## Ukraine and Russia blame each other for shelling Zaporizhzhia nuclear plant
 - [https://www.cnn.com/europe/live-news/russia-ukraine-war-news-11-20-22/index.html](https://www.cnn.com/europe/live-news/russia-ukraine-war-news-11-20-22/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 17:43:49+00:00

• IAEA: Whoever was behind 'powerful explosions' at nuclear plant is 'playing with fire'

## Zakaria identifies the 'real sin' Trump committed that lost him GOP support
 - [https://www.cnn.com/videos/tv/2022/11/18/exp-gps-1120-fareeds-take-republicans-need-to-let-go-of-trump.cnn](https://www.cnn.com/videos/tv/2022/11/18/exp-gps-1120-fareeds-take-republicans-need-to-let-go-of-trump.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 17:41:04+00:00

Fareed Zakaria explains how former president Donald Trump could once again clinch the Republican nomination in 2024.

## Hear police statement after LBGTQ nightclub mass shooting
 - [https://www.cnn.com/videos/us/2022/11/20/colorado-springs-deadly-shooting-nightclub-video-vpx-cnntmw.cnn](https://www.cnn.com/videos/us/2022/11/20/colorado-springs-deadly-shooting-nightclub-video-vpx-cnntmw.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 16:40:30+00:00

A shooter killed at least five people and wounded 18 others at an LGBTQ nightclub in Colorado, according to police. Authorities say the suspected shooter, identified as a 22-year-old man, is in custody and receiving medical treatment.

## Kinzinger says he doesn't think McCarthy will 'last very long' if he becomes House speaker
 - [https://www.cnn.com/2022/11/20/politics/adam-kinzinger-kevin-mccarthy-speaker-cnntv/index.html](https://www.cnn.com/2022/11/20/politics/adam-kinzinger-kevin-mccarthy-speaker-cnntv/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 16:37:50+00:00

GOP Rep. Adam Kinzinger of Illinois lambasted House Minority Leader Kevin McCarthy on Sunday, saying he does not think the California Republican will last long if he's elected House speaker next year.

## 'It scares me': Man calls police on 9-year-old Black girl while she sprayed lanternflies
 - [https://www.cnn.com/videos/us/2022/11/19/neighbor-police-black-girl-spotted-lanternflies-orig-contd-llr.cnn](https://www.cnn.com/videos/us/2022/11/19/neighbor-police-black-girl-spotted-lanternflies-orig-contd-llr.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 16:34:12+00:00

A man called a non-emergency police line to report a 9-year-old Black girl who was spraying spotted lanternflies in Caldwell, New Jersey.

## US is increasing pace of hypersonic weapons development to chase China and Russia, senior admiral says
 - [https://www.cnn.com/2022/11/20/politics/us-hypersonic-china-russia-competition/index.html](https://www.cnn.com/2022/11/20/politics/us-hypersonic-china-russia-competition/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 16:17:31+00:00

China and Russia are driving the US to develop hypersonic weapons faster as the Pentagon seeks to increase the pace of testing and research and avoid falling behind, a senior Navy admiral responsible for US efforts said.

## Opening ceremony of the controversial 2022 FIFA World Cup has begun in Qatar
 - [http://edition.cnn.com/webview/sport/live-news/world-cup-opening-ceremony-11-20-2022/index.html](http://edition.cnn.com/webview/sport/live-news/world-cup-opening-ceremony-11-20-2022/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 16:01:55.636831+00:00



## Get ready for the most expensive holiday travel season ever
 - [https://www.cnn.com/2022/11/20/business/holiday-travel-prices/index.html](https://www.cnn.com/2022/11/20/business/holiday-travel-prices/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 15:58:53+00:00

For travelers getting ready to make their first holiday trips since before the pandemic: prepare for sticker shock.

## The best photos of the 2022 World Cup
 - [https://www.cnn.com/2022/11/20/football/gallery/world-cup-2022/index.html](https://www.cnn.com/2022/11/20/football/gallery/world-cup-2022/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 15:42:42+00:00

For the first time ever, the World Cup is taking place in the Middle East.

## One person killed in rollover of bus chartered by Brandeis University, school says
 - [https://www.cnn.com/2022/11/20/us/brandeis-university-bus-accident/index.html](https://www.cnn.com/2022/11/20/us/brandeis-university-bus-accident/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 15:35:22+00:00

One person was killed in a bus rollover accident late Saturday, according to Brandeis University. The accident involved Brandeis' Boston-Cambridge shuttle and happened on South Street near the Brandeis campus in Waltham, Massachusetts, the school said.

## Ukraine and Russia blame each other for shelling Zaporizhzhia nuclear plant
 - [http://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-11-20-22/index.html](http://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-11-20-22/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 15:01:54.666817+00:00



## Five people killed, at least 18 hurt in shooting at LGBT nightclub in Colorado Springs
 - [http://edition.cnn.com/webview/us/live-news/colorado-springs-club-q-mass-shooting/index.html](http://edition.cnn.com/webview/us/live-news/colorado-springs-club-q-mass-shooting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 15:01:54.658083+00:00

• Nightclub praised 'quick reactions of heroic customers'

## NFL Week 11 Preview: Bills and Browns escape blizzards in Buffalo
 - [https://www.cnn.com/2022/11/20/sport/nfl-week-11-preview-bills-browns-spt-intl/index.html](https://www.cnn.com/2022/11/20/sport/nfl-week-11-preview-bills-browns-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 14:08:17+00:00

The Buffalo Bills (6-3) and Cleveland Browns (3-6) were supposed to square off at Highmark Stadium in Buffalo this Sunday.

## Five people killed, at least 18 hurt in shooting at LGBT nightclub in Colorado Springs
 - [https://www.cnn.com/us/live-news/colorado-springs-club-q-mass-shooting/index.html](https://www.cnn.com/us/live-news/colorado-springs-club-q-mass-shooting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 14:07:47+00:00

• Nightclub praised 'quick reactions of heroic customers'

## Twitter was already in disarray. Trump's return will only make it more chaotic
 - [https://www.cnn.com/collections/intl-musk-trump-112022/](https://www.cnn.com/collections/intl-musk-trump-112022/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 13:50:01+00:00



## Joe Biden and Elon Musk, at opposite ends of leadership equation
 - [https://www.cnn.com/2022/11/20/opinions/biden-musk-leadership-opinion-column-galant/index.html](https://www.cnn.com/2022/11/20/opinions/biden-musk-leadership-opinion-column-galant/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 13:26:55+00:00

"If at eighty," novelist Henry Miller wrote, "...you have your health, if you still enjoy a good walk, a good meal (with all the trimmings), if you can sleep without first taking a pill, if birds and flowers, mountains and sea still inspire you, you are a most fortunate individual and you should get down on your knees morning and night and thank the good Lord for his savin' and keepin' power."

## Kindle's 15-year anniversary is a reminder simplicity is king
 - [https://www.cnn.com/2022/11/20/tech/kindle-15-anniversary/index.html](https://www.cnn.com/2022/11/20/tech/kindle-15-anniversary/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 13:13:52+00:00

Len Edgerly, a 72-year-old podcaster from Cambridge, Massachusetts, has spent the last 14 and a half years talking about his favorite tech product of all time: the Kindle.

## Sara Sidner: What I have in common with Michelle Obama, Melinda French Gates and Amal Clooney might surprise you
 - [https://www.cnn.com/2022/11/20/us/sidner-michelle-obama-amal-clooney-melinda-gates-self-doubt-essay/index.html](https://www.cnn.com/2022/11/20/us/sidner-michelle-obama-amal-clooney-melinda-gates-self-doubt-essay/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 13:03:32+00:00

I have a tormentor. And that tormentor is never far away. That tormentor is always ready to strike. That tormentor is me.

## Explosive tirade from FIFA boss threatens to overshadow World Cup opener
 - [https://www.cnn.com/collections/intl-infantino-world-cup-112022/](https://www.cnn.com/collections/intl-infantino-world-cup-112022/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 11:48:03+00:00



## Alcohol bans. Female referees. An Islamic country. How this World Cup is one of firsts
 - [https://www.cnn.com/2022/11/20/football/qatar-2022-world-cup-of-firsts-spt-intl/index.html](https://www.cnn.com/2022/11/20/football/qatar-2022-world-cup-of-firsts-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 11:39:34+00:00

• Explosive tirade from FIFA boss threatens to overshadow World Cup opener
• 'I don't feel comfortable travelling to Qatar': Dissenting voices are getting louder

## Hurricane Maria changed Puerto Rico. In a new exhibit, artists reflect back
 - [https://www.cnn.com/style/article/puerto-rico-art-exhibition-hurricane-maria-whitney-cec/index.html](https://www.cnn.com/style/article/puerto-rico-art-exhibition-hurricane-maria-whitney-cec/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 11:02:17+00:00

After Hurricane Maria struck Puerto Rico in 2017, artist Gabriella Báez's life changed.

## Joe Biden celebrates his 80th birthday
 - [https://www.cnn.com/2022/11/20/politics/joe-biden-80th-birthday/index.html](https://www.cnn.com/2022/11/20/politics/joe-biden-80th-birthday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 11:00:28+00:00

President Joe Biden turns 80 years old on Sunday, becoming the first octogenarian to ever serve in the highest office of the United States.

## Five people killed, at least 18 hurt in shooting at gay nightclub in Colorado Springs
 - [https://www.cnn.com/2022/11/20/us/colorado-springs-shooting-gay-nightclub/index.html](https://www.cnn.com/2022/11/20/us/colorado-springs-shooting-gay-nightclub/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 10:27:18+00:00

Five people were killed Saturday night at a gay nightclub in Colorado Springs, Colorado, police announced. Another 18 people were injured in the mass shooting at Club Q.

## World Cup guide: Teams and players to watch
 - [https://www.cnn.com/2022/11/20/football/qatar-world-cup-2022-guide-spt-intl/index.html](https://www.cnn.com/2022/11/20/football/qatar-world-cup-2022-guide-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 08:38:39+00:00

In just over 24 hours, Qatar 2022 will burst into life as the host nation takes on Ecuador in the opening game of the World Cup.

## Heavy snow expected to continue piling up in New York after historic storm
 - [https://www.cnn.com/2022/11/20/weather/buffalo-new-york-great-lakes-snowstorm-sunday/index.html](https://www.cnn.com/2022/11/20/weather/buffalo-new-york-great-lakes-snowstorm-sunday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 08:34:33+00:00

Heavy snow is expected to continue piling up in western New York state through Sunday after a historic storm saw the Buffalo area logging record snowfall totaling more than 6 feet in some areas.

## The airline passengers getting 'unacceptable' treatment
 - [https://www.cnn.com/travel/article/disabled-travel-airlines-special-assistance/index.html](https://www.cnn.com/travel/article/disabled-travel-airlines-special-assistance/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 08:12:10+00:00

As most people are excited to get back into the air, travelers with disabilities are finding things rather more difficult.

## Tosca Musk, Elon's sister, has a business venture of her own -- and it's all about romance and female sexuality
 - [https://www.cnn.com/2022/11/20/entertainment/tosca-musk-passionflix-movies-cec/index.html](https://www.cnn.com/2022/11/20/entertainment/tosca-musk-passionflix-movies-cec/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 08:04:03+00:00

Tosca Musk strides onto the red carpet at a Regal Cinemas, statuesque in a white pant suit and glistening burgundy silk top.

## Football loss inspired man to buy $150K lottery winner
 - [https://www.cnn.com/2022/11/20/us/north-carolina-football-lottery-win-trnd/index.html](https://www.cnn.com/2022/11/20/us/north-carolina-football-lottery-win-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 06:04:55+00:00

A North Carolina man turned the pain of his favorite football team's loss into the joy of a $150,000 Powerball win.

## Elon Musk restores Donald Trump's Twitter account
 - [https://www.cnn.com/2022/11/19/business/twitter-musk-trump-reinstate/index.html](https://www.cnn.com/2022/11/19/business/twitter-musk-trump-reinstate/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 01:43:44+00:00

Former US President Donald Trump's Twitter account has been reinstated on the platform.

## Retired colonel 'very concerned' about US weapon shortages for Ukraine
 - [https://www.cnn.com/videos/world/2022/11/20/us-low-on-weapons-ukraine-russia-leighton-nr-vpx.cnn](https://www.cnn.com/videos/world/2022/11/20/us-low-on-weapons-ukraine-russia-leighton-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 01:29:57+00:00

Retired Air Force Col. Cedric Leighton reacts to reports that the US is running low on weapons previously given to Ukraine that have been critical to the country's successes on the battlefield.

## Malaysia faces hung parliament for first time in history
 - [https://www.cnn.com/2022/11/19/asia/malaysia-election-race-parliament-intl-hnk/index.html](https://www.cnn.com/2022/11/19/asia/malaysia-election-race-parliament-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-11-20 00:33:31+00:00

Malaysia was facing a hung parliament for the first time in its history as support for a conservative Islamic alliance prevented major coalitions from winning a simple majority in a general election.


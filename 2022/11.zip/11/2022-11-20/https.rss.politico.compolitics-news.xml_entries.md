# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en-US

## Pelosi had ‘a career to be proud of,’ former GOP speaker says
 - [https://www.politico.com/news/2022/11/20/pelosi-career-paul-ryan-house-speaker-00069623](https://www.politico.com/news/2022/11/20/pelosi-career-paul-ryan-house-speaker-00069623)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2022-11-20 11:17:11+00:00

“It's an impressive legacy,” former House Speaker Paul Ryan said.

## Pence commends leaders of both parties for Jan. 6 handling
 - [https://www.politico.com/news/2022/11/20/pence-both-parties-jan-6-handling-00069618](https://www.politico.com/news/2022/11/20/pence-both-parties-jan-6-handling-00069618)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2022-11-20 09:13:12+00:00

Pence said that House and Senate leaders insisted that they had to reconvene that day.


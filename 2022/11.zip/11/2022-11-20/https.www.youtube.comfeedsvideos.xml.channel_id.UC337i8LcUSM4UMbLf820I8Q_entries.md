# Source:Just Some Guy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC337i8LcUSM4UMbLf820I8Q, language:en-US

## House of the Dragon: Forbidden Love
 - [https://www.youtube.com/watch?v=n8_Uh-jnpYs](https://www.youtube.com/watch?v=n8_Uh-jnpYs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC337i8LcUSM4UMbLf820I8Q
 - date published: 2022-11-20 02:19:47+00:00

House of the Dragon: Forbidden Love
----------------------------------------------------------------------------------------------
Art by Just Some Guy

Original trailer concept: Bleach Opening 01

Music: "Enkon Hakuchuumu" by Sakagami Souichi - Copyright (C) 2015 Trial & Error/Sakagami Souichi All rights reserved.

Trial & Error: http://www.tandess.com/en/music/


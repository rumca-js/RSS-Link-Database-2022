# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Google miało przekupić Activision, by zatrzymać prace na sklepem z aplikacjami
 - [https://ithardware.pl/aktualnosci/google_mialo_przekupic_activision_by_zatrzymac_prace_na_sklepem_z_aplikacjami-24450.html](https://ithardware.pl/aktualnosci/google_mialo_przekupic_activision_by_zatrzymac_prace_na_sklepem_z_aplikacjami-24450.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-20 23:38:39+00:00

<img src="https://ithardware.pl/artykuly/min/24450_1.jpg" />            W sieci pojawiła się informacja, jakoby Google przekupiło Activision Blizzard, aby ten nie stworzył konkurencyjnego sklepu z aplikacjami. Do zarzutu odni&oacute;sł się już Activision. Jakie jest stanowisko firmy?

Epic Games dwa lata temu...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/google_mialo_przekupic_activision_by_zatrzymac_prace_na_sklepem_z_aplikacjami-24450.html">https://ithardware.pl/aktualnosci/google_mialo_przekupic_activision_by_zatrzymac_prace_na_sklepem_z_aplikacjami-24450.html</a></p>

## Szaleństwo, i9 13900K pobiera prawie 400 W, a AiO 280 mm nie daje rady. Jaki zasilacz kupić?
 - [https://ithardware.pl/aktualnosci/szalenstwo_i9_13900k_pobiera_prawie_400_w_a_aio_280_mm_nie_daje_rady_jaki_zasilacz_kupic-24449.html](https://ithardware.pl/aktualnosci/szalenstwo_i9_13900k_pobiera_prawie_400_w_a_aio_280_mm_nie_daje_rady_jaki_zasilacz_kupic-24449.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-20 22:32:22+00:00

<img src="https://ithardware.pl/artykuly/min/24449_1.jpg" />            Jaki zasilacz do i9 13900k?

Od premiery najnowszych procesor&oacute;w Intela 13 generacji, wiemy dwie rzeczy o CPU&nbsp;i9 13900K&nbsp;- to najwydajniejszy procesor do gier, oraz że&nbsp;mocną obciążony pobiera więcej mocy niż topowe modele...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/szalenstwo_i9_13900k_pobiera_prawie_400_w_a_aio_280_mm_nie_daje_rady_jaki_zasilacz_kupic-24449.html">https://ithardware.pl/aktualnosci/szalenstwo_i9_13900k_pobiera_prawie_400_w_a_aio_280_mm_nie_daje_rady_jaki_zasilacz_kupic-24449.html</a></p>

## Acer prezentuje laptopa Aspire 3 z procesorem AMD Ryzen 7000
 - [https://ithardware.pl/aktualnosci/acer_prezentuje_laptopa_aspire_3_z_procesorem_amd_ryzen_7000-24448.html](https://ithardware.pl/aktualnosci/acer_prezentuje_laptopa_aspire_3_z_procesorem_amd_ryzen_7000-24448.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-20 20:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/24448_1.jpg" />            Acer wprowadza na rynek laptop wyposażony w procesor AMD Ryzen 7000. Co jeszcze zaoferuje najnowszy sprzęt producenta?

Notebook Acer&nbsp;Aspire 3 (A315-24P-R75B) dostrzeżony na Amazonie zawiera procesor&nbsp;AMD Ryzen 3 7320U, kt&oacute;ry...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/acer_prezentuje_laptopa_aspire_3_z_procesorem_amd_ryzen_7000-24448.html">https://ithardware.pl/aktualnosci/acer_prezentuje_laptopa_aspire_3_z_procesorem_amd_ryzen_7000-24448.html</a></p>

## GeForce RTX 4060 tuż za rogiem? Wiemy, kiedy NVIDIA ogłosi nowe karty graficzne
 - [https://ithardware.pl/aktualnosci/geforce_rtx_4060_tuz_za_rogiem_wiemy_kiedy_nvidia_oglosi_nowe_karty_graficzne-24446.html](https://ithardware.pl/aktualnosci/geforce_rtx_4060_tuz_za_rogiem_wiemy_kiedy_nvidia_oglosi_nowe_karty_graficzne-24446.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-20 17:38:10+00:00

<img src="https://ithardware.pl/artykuly/min/24446_1.jpg" />            NVIDIA ogłosiła swoją obecność na targach CES 2023. Firma będzie gospodarzem specjalnego przem&oacute;wienia &quot;GeForce&quot;, kt&oacute;re odbędzie się już 3 stycznia. W trakcie tego wydarzenia Zieloni przedstawią swoje najnowsze produkty,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/geforce_rtx_4060_tuz_za_rogiem_wiemy_kiedy_nvidia_oglosi_nowe_karty_graficzne-24446.html">https://ithardware.pl/aktualnosci/geforce_rtx_4060_tuz_za_rogiem_wiemy_kiedy_nvidia_oglosi_nowe_karty_graficzne-24446.html</a></p>

## Intel Core 13. generacji vs. AMD Ryzen 7000. Jakie procesory są najbardziej opłacalne?
 - [https://ithardware.pl/artykuly/intel_core_13_generacji_vs_amd_ryzen_7000_jakie_procesory_sa_najbardziej_oplacalne-24445.html](https://ithardware.pl/artykuly/intel_core_13_generacji_vs_amd_ryzen_7000_jakie_procesory_sa_najbardziej_oplacalne-24445.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-20 16:38:50+00:00

<img src="https://ithardware.pl/artykuly/min/24445_1.jpg" />            Na początku października bieżącego roku przyjrzeliśmy się sprawie opłacalności procesor&oacute;w AMD Ryzen 7000 i w większości przypadk&oacute;w (choć zdarzały się wyjątki) rekomendowaliśmy, by z zakupem nowej platformy zaczekać...
            <p>Pełna wersja strony <a href="https://ithardware.pl/artykuly/intel_core_13_generacji_vs_amd_ryzen_7000_jakie_procesory_sa_najbardziej_oplacalne-24445.html">https://ithardware.pl/artykuly/intel_core_13_generacji_vs_amd_ryzen_7000_jakie_procesory_sa_najbardziej_oplacalne-24445.html</a></p>

## Honor Magic Vs. Znamy specyfikację i wygląd składanego smartfona
 - [https://ithardware.pl/aktualnosci/honor_magic_vs_znamy_specyfikacje_i_wyglad_skladanego_smartfona-24444.html](https://ithardware.pl/aktualnosci/honor_magic_vs_znamy_specyfikacje_i_wyglad_skladanego_smartfona-24444.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-20 16:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/24444_1.jpg" />            Honor Magic Vs jest następcą Honor Magic V, kt&oacute;ry będzie zaprezentowany w ciągu kilku tygodni. Wiemy, co takiego zaoferuje nowy składany smartfon.

Honor Magic Vs dostanie 6,45-calowy zewnętrzny wyświetlacz OLED o rozdzielczości Full...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/honor_magic_vs_znamy_specyfikacje_i_wyglad_skladanego_smartfona-24444.html">https://ithardware.pl/aktualnosci/honor_magic_vs_znamy_specyfikacje_i_wyglad_skladanego_smartfona-24444.html</a></p>

## Koniec z tanimi pamięciami. Micron zmniejsza produkcję
 - [https://ithardware.pl/aktualnosci/koniec_z_tanimi_pamieciami_micron_zmniejsza_produkcje-24442.html](https://ithardware.pl/aktualnosci/koniec_z_tanimi_pamieciami_micron_zmniejsza_produkcje-24442.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-20 11:26:50+00:00

<img src="https://ithardware.pl/artykuly/min/24442_1.jpg" />            Niski popyt na pamięci oraz związane z tym zjawiskiem spadki cen nie są korzystne dla producent&oacute;w. Micron postanowił&nbsp;działać, tnąc produkcję wafli krzemowych o 20% w por&oacute;wnaniu do poprzedniego kwartału.&nbsp;Firma uważa, iż...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/koniec_z_tanimi_pamieciami_micron_zmniejsza_produkcje-24442.html">https://ithardware.pl/aktualnosci/koniec_z_tanimi_pamieciami_micron_zmniejsza_produkcje-24442.html</a></p>

## Twitter odblokował konto Donalda Trumpa. Nim to zrobiono Elon Musk przeprowadził głosowanie
 - [https://ithardware.pl/aktualnosci/twitter_odblokowal_konto_donalda_trumpa_elon_musk_przeprowadzil_glosowanie-24441.html](https://ithardware.pl/aktualnosci/twitter_odblokowal_konto_donalda_trumpa_elon_musk_przeprowadzil_glosowanie-24441.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-20 08:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/24441_1.jpg" />            Donald Trump został permanentnie zablokowany na Twitterze&nbsp;po ataku na Kapitol na początku 2021 roku, kt&oacute;rego&nbsp;dokonali zwolennicy Trumpa&nbsp;po przegranych przez niego wyborach prezydenckich w Stanach Zjednoczonych. Po przejęciu...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/twitter_odblokowal_konto_donalda_trumpa_elon_musk_przeprowadzil_glosowanie-24441.html">https://ithardware.pl/aktualnosci/twitter_odblokowal_konto_donalda_trumpa_elon_musk_przeprowadzil_glosowanie-24441.html</a></p>


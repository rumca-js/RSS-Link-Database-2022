# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## See an Exclusive Clip From Good Night Oppy, a New Doc About the Mars Rover That Defied the Odds
 - [https://gizmodo.com/good-night-oppy-documentary-mars-rovers-nasa-1849800988](https://gizmodo.com/good-night-oppy-documentary-mars-rovers-nasa-1849800988)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-20 21:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--jZy_KWVv--/c_fit,fl_progressive,q_80,w_636/f07c8cf3e731956efd34daa929cb7166.jpg" /><p>Often, the public only turns its gaze to space missions during the spectacular moments: launches and landings, mostly. But Mars rovers maintain a special place in our hearts, as they toil millions of miles from home, sending us updates and images over the course of years. We get used to receiving these alien…</p><p><a href="https://gizmodo.com/good-night-oppy-documentary-mars-rovers-nasa-1849800988">Read more...</a></p>

## Legion of Super-Heroes Trailer Brings Past and Future Heroes Together
 - [https://gizmodo.com/legion-of-super-heroes-animated-trailer-2023-release-1849806603](https://gizmodo.com/legion-of-super-heroes-animated-trailer-2023-release-1849806603)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-20 19:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--XjRzCHfP--/c_fit,fl_progressive,q_80,w_636/6d2491284ad08730f9f246bb9304dfe4.jpg" /><p>While Warner Bros. has spent the last decade plus trying to whip DC Comics movies into some form of coherence in <a href="https://gizmodo.com/james-gunn-head-of-dc-movies-and-tv-warner-bros-1849701460">live action</a>, its animated movie output has generally remained consistent. The 2010s saw over a dozen movies based on or inspired by the <em>New 52 </em>line of comics, and later rebooted into a new series of films…</p><p><a href="https://gizmodo.com/legion-of-super-heroes-animated-trailer-2023-release-1849806603">Read more...</a></p>

## Ryan Reynolds Found Time to Write an Unmade Deadpool Christmas Movie
 - [https://gizmodo.com/ryan-reynolds-deadpool-christmas-movie-1849806517](https://gizmodo.com/ryan-reynolds-deadpool-christmas-movie-1849806517)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-20 18:35:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--_2mCVmVt--/c_fit,fl_progressive,q_80,w_636/a53e9ba6b525267623ba94c89e7297bc.jpg" /><p>This year, Marvel’s gotten into the festive spirit with a pair of holiday specials. After <a href="https://gizmodo.com/werewolf-by-night-review-marvel-disney-plus-horror-stre-1849579625"><em>Werewolf by Night</em></a><em> </em>kicked things off in October and impressed near everyone with its commitment to old-school horror, the <a href="https://gizmodo.com/marvel-studios-guardians-of-the-galaxy-holiday-special-1849802143">Guardians of the Galaxy</a> headline next week’s Christmas-themed special. With such a large library of…</p><p><a href="https://gizmodo.com/ryan-reynolds-deadpool-christmas-movie-1849806517">Read more...</a></p>

## Jason David Frank, Longtime Power Ranger, Has Passed Away
 - [https://gizmodo.com/obituary-jason-david-frank-power-rangers-1849806348](https://gizmodo.com/obituary-jason-david-frank-power-rangers-1849806348)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-20 17:01:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--7redFAM6--/c_fit,fl_progressive,q_80,w_636/7cef0e9411b4caff25da2d19b0893278.jpg" /><p>Jason David Frank has passed away at the age of 49. The news was initially broke by his personal trainer and close friend, <a href="https://www.facebook.com/mike.bronzoulis/posts/pfbid0ZtdEeeNLRkyNoScd9c2aprdz1Znc19MUmMinemdxbRK8LuUErogtZdBaUS3uY1Hfl" rel="noopener noreferrer" target="_blank">Mike Bronzoulis</a>, and later corroborated by <a href="https://www.tmz.com/2022/11/20/power-rangers-jason-david-frank-dead-dies-tommy-oliver-green-white/?adid=social-twa" rel="noopener noreferrer" target="_blank">TMZ</a> (via Frank’s representative), along with fellow <em>Rangers </em>actors Walter Jones and Blake Foster. <br /></p><p><a href="https://gizmodo.com/obituary-jason-david-frank-power-rangers-1849806348">Read more...</a></p>

## Sci-fi Novelist Greg Bear Has Passed Away
 - [https://gizmodo.com/obituary-greg-bear-sci-fi-author-1849806303](https://gizmodo.com/obituary-greg-bear-sci-fi-author-1849806303)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-20 17:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--hnSWZWu0--/c_fit,fl_progressive,q_80,w_636/0dab3b1043e1750d8be4199e8711289b.jpg" /><p>Author Greg Bear has passed away, reports his wife <a href="https://www.facebook.com/astrid.bear/posts/pfbid045PjKbttdAiaBysKLooESWGpna6h5MdvkAXX97rQxz3V1MPdYWMukydSzq2h3GYyl" rel="noopener noreferrer" target="_blank">Astrid</a>. The 71-year-old novelist underwent surgery earlier in the month, and following the successful process, doctors discovered he’d had a stroke from clots that had been building in his body since surgery he had in 2014. He remained unconscious until November 18,…</p><p><a href="https://gizmodo.com/obituary-greg-bear-sci-fi-author-1849806303">Read more...</a></p>

## Open Channel: What Have Been Your Favorite Walking Dead Moments?
 - [https://gizmodo.com/open-channel-walking-dead-memory-amc-1849806010](https://gizmodo.com/open-channel-walking-dead-memory-amc-1849806010)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-20 15:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s---VP7R7wE--/c_fit,fl_progressive,q_80,w_636/f3b4db3760e218cc960b51a047072784.jpg" /><p>After 11 years, 176 episodes, and some <a href="https://gizmodo.com/new-walking-dead-lawsuit-robert-kirkman-zombies-amc-sho-1849787575">lawsuits</a>, the original <a href="https://gizmodo.com/the-walking-dead-final-episode-first-pictures-amc-1849778240"><em>Walking Dead</em></a><em> </em>series is coming to an end tonight. What was originally a simple adaptation of the popular Image comic from Charlie Adlard, Tony Moore, and Robert Kirkman has grown into a pop culture juggernaut with <a href="https://gizmodo.com/walking-dead-daryl-france-spin-off-tv-series-zombies-1849385634">six spinoffs</a> (at time of writing), an…</p><p><a href="https://gizmodo.com/open-channel-walking-dead-memory-amc-1849806010">Read more...</a></p>

## How a 'Playboy' Centerfold Became Part of the Creation of the JPEG
 - [https://gizmodo.com/lena-test-image-playboy-how-sex-changed-internet-1849798731](https://gizmodo.com/lena-test-image-playboy-how-sex-changed-internet-1849798731)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-11-20 14:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ouCTAX0B--/c_fit,fl_progressive,q_80,w_636/18fg9rynraomnpng.png" /><p><em>In her new book, <a href="https://www.workman.com/products/how-sex-changed-the-internet-and-the-internet-changed-sex/hardback" rel="noopener noreferrer" target="_blank">How Sex Changed the Internet and the Internet Changed Sex: An Unexpected History</a></em>,<em> Samantha Cole traces the twisting history of the “Lena Centerfold,” an image from Playboy that became an international standard for training computers to recognize images. The image, taken in 1972, persisted for decades</em>…</p><p><a href="https://gizmodo.com/lena-test-image-playboy-how-sex-changed-internet-1849798731">Read more...</a></p>


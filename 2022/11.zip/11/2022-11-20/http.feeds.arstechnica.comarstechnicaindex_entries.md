# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## “Just a bunch of idiots having fun”—a photo history of the LAN party
 - [https://arstechnica.com/?p=1898593](https://arstechnica.com/?p=1898593)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-20 13:08:49+00:00

An interview with Merritt K, chronicler of a crucial, awkward time in PC gaming.

## The World Cup ball has the aerodynamics of a champion
 - [https://arstechnica.com/?p=1899073](https://arstechnica.com/?p=1899073)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-11-20 11:03:47+00:00

A sports physicist breaks down the Al Rihla, the official ball of the World Cup.


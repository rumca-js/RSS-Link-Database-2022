# Source:PC world, URL:https://www.pcworld.com/index.rss, language:en-US

## Give thanks for early Black Friday savings on this projector and screen bundle
 - [https://www.pcworld.com/article/1383034/give-thanks-for-early-black-friday-savings-on-this-projector-and-screen-bundle.html](https://www.pcworld.com/article/1383034/give-thanks-for-early-black-friday-savings-on-this-projector-and-screen-bundle.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2022-11-20 08:00:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section><p>If you need a reason to be thankful for this season, here&rsquo;s a big one: Black Friday came early, and you can save on two hot items: a&nbsp;<a href="https://shop.pcworld.com/sales/watch-from-anywhere-bundle-wemax-go-projector-and-40-portable-screen-bundle?utm_source=pcworld.com&amp;utm_medium=referral&amp;utm_campaign=watch-from-anywhere-bundle-wemax-go-projector-and-40-portable-screen-bundle&amp;utm_term=scsf-557628&amp;utm_content=a0x1P000004ya7vQAA&amp;scsonar=1" rel="noreferrer noopener" target="_blank">1080P projector and a 40-inch portable screen</a>. During our Thankful Deals sale, which runs until November 23 at 11:59 PM Pacific, both items are on sale for $199.99. That&rsquo;s much less than if you were to buy each item from our shop individually.</p>



<p>The Wemax Go, which&nbsp;<a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.indiegogo.com/projects/wemax-go-thinnest-alpd-smart-laser-projector#/&amp;xcust=2-1-1383034-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">raised nearly $275,000 on Indiegogo</a>, uses an ALPD laser to project super-sharp images up to 100 inches wide at 300 lumens. That&rsquo;s bright enough to see even in full sunlight! It&rsquo;s got ports for HDMI, USB, or USB-C, and you can even connect the projector to your tablet or phone via WiFi. The Wemax Go packs all this tech into a package no bigger than a smartphone, so you can deliver stunning presentations or stream movies from Netflix or Roku anywhere the party goes.</p>



<p>The bundle also includes a 40&Prime; screen tailor-made for the Go. It&rsquo;s a lightweight rod that pulls out into a screen made of multilayer fabric with a black backing, so there&rsquo;s no bleed-through from the projector&rsquo;s powerful light source. Combine the two, and you can make it a movie night or game day anywhere the party is.</p>



<p>Get this&nbsp;<a href="https://shop.pcworld.com/sales/watch-from-anywhere-bundle-wemax-go-projector-and-40-portable-screen-bundle?utm_source=pcworld.com&amp;utm_medium=referral&amp;utm_campaign=watch-from-anywhere-bundle-wemax-go-projector-and-40-portable-screen-bundle&amp;utm_term=scsf-557628&amp;utm_content=a0x1P000004ya7vQAA&amp;scsonar=1" rel="noreferrer noopener" target="_blank">Watch From Anywhere Bundle</a>&nbsp;for Black Friday pricing. It&rsquo;s available for $199.99 or $100 off until Thanksgiving. No coupon is necessary, but it might sell out before that!</p>



<p><a href="https://shop.pcworld.com/sales/watch-from-anywhere-bundle-wemax-go-projector-and-40-portable-screen-bundle?utm_source=pcworld.com&amp;utm_medium=referral-cta&amp;utm_campaign=watch-from-anywhere-bundle-wemax-go-projector-and-40-portable-screen-bundle&amp;utm_term=scsf-557628&amp;utm_content=a0x1P000004ya7vQAA&amp;scsonar=1" rel="noreferrer noopener" target="_blank">&nbsp;</a></p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image"><img alt="" src="https://cdnp1.stackassets.com/a7f5b0d411fdb17d137e3a38e5d2b3e4fc7f285f/store/38b1d95452035add0472579dbaadc4181db2bf9d36ee044552159280a3cc/sale_316300_primary_image.jpg" /></figure></div>



<p><strong>Watch from Anywhere Bundle: Wemax Go Projector + 40&Prime; Portable Screen &ndash; $199.99</strong></p>



<p><a href="https://shop.pcworld.com/sales/watch-from-anywhere-bundle-wemax-go-projector-and-40-portable-screen-bundle?utm_source=pcworld.com&amp;utm_medium=referral-cta&amp;utm_campaign=watch-from-anywhere-bundle-wemax-go-projector-and-40-portable-screen-bundle&amp;utm_term=scsf-557628&amp;utm_content=a0x1P000004ya7vQAA&amp;scsonar=1" rel="noreferrer noopener" target="_blank">Save on This Projector</a></p>



<p><em>Prices subject to change.</em></p>
Projectors</div>


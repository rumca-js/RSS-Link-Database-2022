# Source:Epoch Times Tech, URL:https://www.theepochtimes.com/c-tech/feed/, language:en-US

## CBS News Resumes Posting on Twitter Amid ‘Uncertainty’ Over Elon Musk
 - [https://www.theepochtimes.com/cbs-news-resumes-posting-on-twitter-amid-uncertainty-over-elon-musk_4875496.html](https://www.theepochtimes.com/cbs-news-resumes-posting-on-twitter-amid-uncertainty-over-elon-musk_4875496.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-11-20 22:58:28+00:00

Tesla head Elon Musk talks to the press as he arrives to have a look at the construction site of the new Tesla Gigafactory near Berlin, Germany, on Sept. 3, 2020. (Maja Hitij/Getty Images)

## Twitter Reactivates Trump’s Account Following Poll of 15 Million Users
 - [https://www.theepochtimes.com/trump-will-be-reinstated-on-twitter-says-musk-following-poll_4874463.html](https://www.theepochtimes.com/trump-will-be-reinstated-on-twitter-says-musk-following-poll_4874463.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-11-20 01:30:06+00:00

Former President Donald Trump leaves the stage after speaking during an event at his Mar-a-Lago home in Palm Beach, Fla., on Nov. 15, 2022. (Joe Raedle/Getty Images)


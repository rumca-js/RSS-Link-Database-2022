# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## We Built a PC for the Price of a Steam Deck!
 - [https://www.youtube.com/watch?v=qixXsJBmyd8](https://www.youtube.com/watch?v=qixXsJBmyd8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-11-21 00:00:00+00:00

Thanks Jackery for sponsoring today's video! 
Save up to $1,080 during their Black Friday Sales from Nov 24th to Nov 28th! Also, stay tuned for Jackery's Crazy Monday sweepstake with prizes worth $250,000 in total in Jackery Livestream on Nov 28th, 2:30PM PST! Every order placed during the Black Friday Sales will get a chance to win A TRAVEL TRAILER!
Amazon: https://amzn.to/3X3qaUb
Website: https://bit.ly/3txiFqY

Discuss on the forum: https://linustechtips.com/topic/1469063-is-building-a-pc-dumb-when-the-steam-deck-exists/

Buy a GTX 1070: https://geni.us/Dmi3qN
Buy an Intel Core i3 12100F: https://geni.us/c2hXr
Buy a 256GB Steam Deck: https://lmg.gg/62oFY
Buy an MSI PRO B660M-G mATX Motherboard: https://geni.us/gHNh
Buy a kit of Silicon Power Gaming DDR4 16GB: https://geni.us/lnu7QS
Buy a Silicon Power A55 256 M.2 SSD: https://geni.us/7Yoz
Buy a Cougar MG130-G mATX Case: https://geni.us/F99Oj
Enermax CYBERBRON 500 W 80+ Bronze PSU: https://geni.us/6P6Qqr
Buy an Acer V226HQL 21.5" Monitor: https://geni.us/pf1OC6
Buy a Verbatim Slimline Keyboard and Mouse: https://geni.us/gWIf

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Steam Deck vs. PC Build for the same price, who will win?
0:13 Rules on everything
1:44 PC Parts Used (Links in the description ;) )
3:26 Powering on
5:19 How about a gaming laptop at the same price?
7:14 Trying out the gaming laptop
9:30 Steam Deck benchmarks
10:12 Cons of the Steam Deck
11:12 Steam Deck Dock

## We Bought HD Movies on Cassette Tape and They're AMAZING! - D-VHS and D-Theater
 - [https://www.youtube.com/watch?v=papQ8xQxizA](https://www.youtube.com/watch?v=papQ8xQxizA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-11-20 00:00:00+00:00

Join us in War Thunder for FREE at https://playwt.link/joinltt Get an exclusive bonus using our link - thanks for supporting the channel!

Check out all that ORIGIN PC has to offer and more at https://bit.ly/3Uvz23w

DVHS was a flash in the pan in the early 2000s, bringing 1080i content to tape. Why did it fail, who bought these things, and most importantly was it even any good?

Discuss on the forum: https://linustechtips.com/topic/1468854-we-bought-hd-movies-on-cassette-tape/

Buy Denzel Washington’s The Hurricane on Blu-Ray: https://geni.us/3mjh0Fs

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:20 The Hurricane
3:40 DVHS Player
4:40 VHS
6:15 DVHS
8:10 DVD
9:33 Blu-Ray
12:40 History
14:50 Why Buy DVHS?
17:20 Why Did It Fail?
19:14 Outro


# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Trump, YE, Tate, Peterson - four horsemen or free speech warriors?
 - [https://www.youtube.com/watch?v=8VGgPx2_eb8](https://www.youtube.com/watch?v=8VGgPx2_eb8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-11-21 00:00:00+00:00

As Twitter reinstates Trump, Kanye, Andrew Tate and Jordan Peterson , we ask, are there bigger questions we should be asking about social media companies than just who they decide to ban? 
#JordanPeterson #Ye #AndrewTate #JordanPeterson
--------------------------------------------------------------------------------------------------------------------------
FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand

Join The Community STAY FREE AF: https://russellbrand.locals.com/

Come to My Festival COMMUNITY - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/

## “That P*sses Me Off!” Will Harris BREAKS DOWN Bill Gates’s Greenwash Bullsh*t
 - [https://www.youtube.com/watch?v=S1l6GUpeirs](https://www.youtube.com/watch?v=S1l6GUpeirs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-11-20 00:00:00+00:00

I recently spoke with farmer Will Harris, who is a fourth-generation cattleman at White Oak Pastures. He shared his opinion on Bill Gates’s land grab & use of technology in farming. #billgates #farming #greenwashing 
--------------------------------------------------------------------------------------------------------------------------
FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand

Join The Community STAY FREE AF: https://russellbrand.locals.com/

Come to My Festival COMMUNITY - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/


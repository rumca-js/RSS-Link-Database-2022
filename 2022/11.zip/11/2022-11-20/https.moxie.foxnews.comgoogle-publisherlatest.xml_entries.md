# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Idaho murders: police have 'cleared' phone calls victims made on the night of stabbings
 - [https://www.foxnews.com/us/idaho-murders-police-have-cleared-phone-calls-victims-made-night-stabbings](https://www.foxnews.com/us/idaho-murders-police-have-cleared-phone-calls-victims-made-night-stabbings)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 23:55:45+00:00

Police said Sunday that they have cleared multiple phone calls two victims of a Nov. 13 quadruple homicide near the University of Idaho campus made the night of the murders.

## Falcons' Younghoe Koo hits late 53-yard field goal to lift Atlanta past Justin Fields, Bears
 - [https://www.foxnews.com/sports/falcons-younghoe-koo-hits-late-53-yard-field-goal-lift-atlanta-past-justin-fields-bears](https://www.foxnews.com/sports/falcons-younghoe-koo-hits-late-53-yard-field-goal-lift-atlanta-past-justin-fields-bears)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 23:51:18+00:00

Atlanta Falcons's Younghoe Koo hit a 53-yard field goal with less than two minutes left to play to defeat the Chicago Bears, 27-24, on Sunday.

## New Jersey woman sentenced to life in prison for killing 17-month-old son
 - [https://www.foxnews.com/us/new-jersey-woman-sentenced-life-prison-killing-17-month-old-son](https://www.foxnews.com/us/new-jersey-woman-sentenced-life-prison-killing-17-month-old-son)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 23:48:46+00:00

A South New Jersey woman, Heather Reynolds, was sentenced to life without parole for killing her 17-month-old son Axel in 2018 by suffocating him.

## Patriots' Marcus Jones stuns Jets with late punt-return touchdown for thrilling victory
 - [https://www.foxnews.com/sports/patriots-marcus-jones-stuns-jets-late-punt-return-touchdown-thrilling-victory](https://www.foxnews.com/sports/patriots-marcus-jones-stuns-jets-late-punt-return-touchdown-thrilling-victory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 23:48:14+00:00

The New England Patriots defeated the New York Jets 10-3 on Sunday after rookie cornerback scored a touchdown on an 84-yard punt return with 5 seconds left on the clock.

## AMAs 2022 red carpet: Celebrity fashion wins at American Music Awards
 - [https://www.foxnews.com/entertainment/amas-2022-red-carpet-celebrity-fashion-wins-american-music-awards](https://www.foxnews.com/entertainment/amas-2022-red-carpet-celebrity-fashion-wins-american-music-awards)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 23:36:22+00:00

Wayne Brady hosts star-studded American Music Awards 2022 at Microsoft Theater in Los Angeles, where Lionel Richie will be honored and Stevie Wonder performs.

## Tennessee star lost for season after tearing ACL in blowout loss
 - [https://www.foxnews.com/sports/tennessee-hendon-hooker-lost-season-tearing-acl-blowout-loss](https://www.foxnews.com/sports/tennessee-hendon-hooker-lost-season-tearing-acl-blowout-loss)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 23:19:54+00:00

The Tennessee Volunteers didn't just lose their bid at the College Football Playoffs in a blowout loss to South Carolina on Saturday. They've lost their quarterback for the season, too.

## Ukraine’s Zaporizhzhia nuclear plant rocked by 'powerful explosions,' UN nuclear agency says
 - [https://www.foxnews.com/world/ukraines-zaporizhzhia-nuclear-plant-rocked-powerful-explosions-un-nuclear-agency-says](https://www.foxnews.com/world/ukraines-zaporizhzhia-nuclear-plant-rocked-powerful-explosions-un-nuclear-agency-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 23:16:19+00:00

The International Atomic Energy Agency said that "powerful explosions" rocked Ukraine's Zaporizhzhia nuclear power plant, causing damage to some buildings.

## Lions rout Giants for third straight win; Jamaal Williams scores three touchdowns
 - [https://www.foxnews.com/sports/lions-rout-giants-third-straight-win-jamaal-williams-scores-three-touchdowns](https://www.foxnews.com/sports/lions-rout-giants-third-straight-win-jamaal-williams-scores-three-touchdowns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 23:07:16+00:00

The Detroit Lions have thrusted themselves into the NFC playoff picture as they won their third straight game, defeating the New York Giants on the road Sunday.

## Elon Musk pokes fun at CBS' short-lived Twitter hiatus after network resumes tweeting less than 48 hours later
 - [https://www.foxnews.com/media/elon-musk-pokes-fun-cbs-short-lived-twitter-hiatus-network-resumes-tweeting-48-hours-later](https://www.foxnews.com/media/elon-musk-pokes-fun-cbs-short-lived-twitter-hiatus-network-resumes-tweeting-48-hours-later)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 22:38:05+00:00

Elon Musk responded to CBS' return to Twitter, which comes less than 48 hours after the network announced it suspended usage over concerns with his management.

## UN negotiators agree to pay climate reparations to poor nations
 - [https://www.foxnews.com/world/un-negotiators-agree-pay-climate-reparations-poor-nations](https://www.foxnews.com/world/un-negotiators-agree-pay-climate-reparations-poor-nations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 22:23:41+00:00

Climate negotiators who meet this week for COP27 reached an agreement to pay funds to poor nations that have been victimized by climate change.

## Falcons' Cordarrelle Patterson breaks NFL record with 103-yard kickoff return for touchdown
 - [https://www.foxnews.com/sports/falcons-cordarrelle-patterson-breaks-nfl-record-103-yard-kickoff-return-touchdown](https://www.foxnews.com/sports/falcons-cordarrelle-patterson-breaks-nfl-record-103-yard-kickoff-return-touchdown)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 22:23:33+00:00

Atlanta Falcons running back Cordarrelle Patterson topped Josh Cribbs and Leon Washington with his ninth kickoff return for a touchdown in Sunday's win over the Chicago Bars.

## New York Times mocked for report on Biden's age: He 'has a lot going in his favor' for being 80 years old
 - [https://www.foxnews.com/media/new-york-times-mocked-report-bidens-age-lot-going-favor-being-80-years-old](https://www.foxnews.com/media/new-york-times-mocked-report-bidens-age-lot-going-favor-being-80-years-old)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 22:17:00+00:00

New York Times correspondent Sheryl Gay Stolberg argued that President Biden turning 80 this year is likely not a health concern for re-election in 2024.

## Eagles escape another upset as Jalen Hurts' late touchdown beats Colts
 - [https://www.foxnews.com/sports/eagles-escape-another-upset-jalen-hurts-late-touchdown-beats-colts](https://www.foxnews.com/sports/eagles-escape-another-upset-jalen-hurts-late-touchdown-beats-colts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 21:49:24+00:00

Jeff Saturday was close to his first home win as interim head coach, but Jalen Hurts and the Philadelphia Eagles scored late to beat the Indianapolis Colts on Sunday.

## Arizona attorney general’s office demands answers to ‘myriad’ voting issues in Maricopa County
 - [https://www.foxnews.com/politics/arizona-attorney-generals-office-demands-answers-to-myriad-voting-issues-maricopa-county](https://www.foxnews.com/politics/arizona-attorney-generals-office-demands-answers-to-myriad-voting-issues-maricopa-county)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 21:23:09+00:00

Arizona Assistant Attorney General Jennifer Wright sent a letter Saturday to the Maricopa County Attorney's Office demanding answers to "myriad" Election Day issues.

## Coastal Maryland armed carjacking leads to arrest of four teenagers and 12-year-old
 - [https://www.foxnews.com/us/coastal-maryland-armed-carjacking-leads-arrest-four-teenagers-12-year-old](https://www.foxnews.com/us/coastal-maryland-armed-carjacking-leads-arrest-four-teenagers-12-year-old)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 21:18:14+00:00

Ocean City Police arrested four teenagers and a 12-year-old in connection to an armed carjacking that occurred during the early morning hours on Nov. 12, 2022.

## Coast Guard says four drown near Florida Keys after boat capsizes in failed migration attempt
 - [https://www.foxnews.com/us/coast-guardfour-drown-florida-keys-boat-capsizes-failed-migration-attempt](https://www.foxnews.com/us/coast-guardfour-drown-florida-keys-boat-capsizes-failed-migration-attempt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 20:57:52+00:00

A vessel carrying nearly two dozen migrants capsized about 50 miles off the coast of Florida on Sunday, leaving at least four people dead, the Coast Guard said.

## Nets lift Kyrie Irving suspension, star guard admits apology should have come sooner
 - [https://www.foxnews.com/sports/nets-lift-kyrie-irving-suspension-star-guard-admits-apology-should-come-sooner](https://www.foxnews.com/sports/nets-lift-kyrie-irving-suspension-star-guard-admits-apology-should-come-sooner)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 20:51:26+00:00

The Brooklyn Nets have officially lifted Kyrie Irving's suspension prior to the team's game against the Memphis Grizzlies on Sunday night.

## If Idaho murder victims 'were going to go, they were going to go together,' friend says
 - [https://www.foxnews.com/us/if-idaho-murder-victims-were-going-go-they-were-going-go-together-friend-says](https://www.foxnews.com/us/if-idaho-murder-victims-were-going-go-they-were-going-go-together-friend-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 20:48:33+00:00

Close friends of University of Idaho homicide victims Kaylee Goncalves and Madison Mogen remember them as not only best friends but as sisters who loved to laugh and sing.

## Idaho university murders: Police search wooded area behind home where four students were fatally stabbed
 - [https://www.foxnews.com/us/idaho-university-murders-police-search-wooded-area-week-investigation-launched](https://www.foxnews.com/us/idaho-university-murders-police-search-wooded-area-week-investigation-launched)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 20:47:05+00:00

Police in Moscow, Idaho, were seen scouring the woods behind the home near the University of Idaho's campus where four students were found fatally stabbed last Sunday.

## China confirms 1st COVID-19 death since May as authorities try to clamp down on rising cases
 - [https://www.foxnews.com/world/china-confirms-1st-covid-19-death-since-may-authorities-clamp-down-rising-cases](https://www.foxnews.com/world/china-confirms-1st-covid-19-death-since-may-authorities-clamp-down-rising-cases)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 20:35:15+00:00

China's National Health Commission on Sunday announced the country's first COVID-19 death in nearly six months as health officials deal with an uptick in cases.

## Qatar disappoints in World Cup debut as Ecuador's Enner Valencia shines in opening match victory
 - [https://www.foxnews.com/sports/qatar-disappoints-world-cup-debut-ecuadors-enner-valencia-shines-opening-match-victory](https://www.foxnews.com/sports/qatar-disappoints-world-cup-debut-ecuadors-enner-valencia-shines-opening-match-victory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 19:39:44+00:00

Ecuador defeated Qatar in the opening match of the World Cup on Sunday with star striker Enner Valencia getting both two goals in the 2-0 win.

## 'Power Rangers' star Jason David Frank dead at 49
 - [https://www.foxnews.com/entertainment/power-rangers-star-jason-david-frank-dead-49](https://www.foxnews.com/entertainment/power-rangers-star-jason-david-frank-dead-49)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 19:36:44+00:00

Jason David Frank of "Mighty Morphin Power Rangers" series, as well as an accomplished mixed-martial artist died at 49, according to his representative.

## Elon Musk calls The New York Times 'boring': 'Far left brainwashing at this point'
 - [https://www.foxnews.com/media/elon-musk-calls-new-york-times-boring-far-left-brainwashing-at-this-point](https://www.foxnews.com/media/elon-musk-calls-new-york-times-boring-far-left-brainwashing-at-this-point)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 19:33:47+00:00

Elon Musk called out The New York Times on Sunday in a tweet and said that it was "tragic" how far they had fallen, adding that they are just "far left brainwashing."

## Dem Sen Warner says ‘Trump was right’ about banning China’s TikTok, warns parents against letting kids on app
 - [https://www.foxnews.com/politics/dem-sen-mark-warner-trump-was-right-banning-chinas-tiktok-warns-parents-letting-kids-app](https://www.foxnews.com/politics/dem-sen-mark-warner-trump-was-right-banning-chinas-tiktok-warns-parents-letting-kids-app)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 19:10:53+00:00

Sen. Mark Warner warned parents not to allow their kids to download TikTok, saying former President Donald Trump "was right" about the China-owned video app.

## 'Fox News Sunday' on November 20, 2022
 - [https://www.foxnews.com/transcript/fox-news-sunday-november-20-2022](https://www.foxnews.com/transcript/fox-news-sunday-november-20-2022)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 19:00:07+00:00

On 'Fox News Sunday,' host Shannon Bream welcomed Sen. Tom Cotton, Sen. Mark Warner, Fox News' Peter Doocy and more to discuss the latest political news.

## Michael J. Fox accepts honorary Oscar award for Parkinson's Disease advocacy and research
 - [https://www.foxnews.com/entertainment/michael-j-fox-accepts-honorary-oscar-award-parkinsons-disease-advocacy-research](https://www.foxnews.com/entertainment/michael-j-fox-accepts-honorary-oscar-award-parkinsons-disease-advocacy-research)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 18:50:16+00:00

Michael J. Fox was recognized for his advocacy work with Parkinson's Disease and given an honorary Academy Award at the 13th Annual Governors Awards on Saturday.

## Missouri teen who rushed to help officer shot in line of duty honored for heroism
 - [https://www.foxnews.com/us/missouri-teen-who-rushed-help-officer-shot-line-duty-honored-for-heroism](https://www.foxnews.com/us/missouri-teen-who-rushed-help-officer-shot-line-duty-honored-for-heroism)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 18:45:07+00:00

Missouri teenager Ava Donegan was celebrated for her bravery last month when she helped tie a tourniquet on an Excelsior Springs officer who was shot in the line of duty.

## With Dems in House minority, Clyburn, Hoyer say party will 'look forward,' put politics aside
 - [https://www.foxnews.com/politics/dems-house-minority-clyburn-hoyer-party-look-forward-put-politics-aside](https://www.foxnews.com/politics/dems-house-minority-clyburn-hoyer-party-look-forward-put-politics-aside)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 18:36:47+00:00

House Majority Leader Steny Hoyer and Majority Whip James Clyburn said that Democrats will focus on the future as Republicans are set to take the majority,

## Biden says 'no motive' clear in Colorado nightclub shooting, calls for assault weapons ban
 - [https://www.foxnews.com/politics/biden-no-motive-clear-colorado-nightclub-shooting-calls-assault-weapons-ban](https://www.foxnews.com/politics/biden-no-motive-clear-colorado-nightclub-shooting-calls-assault-weapons-ban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 18:28:10+00:00

President Biden acknowledged that there was no clear motive in the attack on Club Q in Colorado, but called for an assault weapons ban in a Sunday statement.

## Hakeem Jeffries confident he can unite Dems after Pelosi exit, says he has 'great respect' for AOC
 - [https://www.foxnews.com/politics/hakeem-jeffries-confident-he-can-unite-dems-after-pelosi-exit-says-he-has-great-respect-aoc](https://www.foxnews.com/politics/hakeem-jeffries-confident-he-can-unite-dems-after-pelosi-exit-says-he-has-great-respect-aoc)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 18:25:20+00:00

Rep. Hakeem Jeffries, D-N.Y., is currently running unopposed to be the new leader of House Democrats, expressing optimism he could bring the party together as leader.

## Antonio Brown trolls Aaron Rodgers, Derek Carr amid struggling seasons: 'Wonder why Adams left'
 - [https://www.foxnews.com/sports/antonio-brown-trolls-aaron-rodgers-derek-carr-amid-struggling-seasons-wonder-why-adams-left](https://www.foxnews.com/sports/antonio-brown-trolls-aaron-rodgers-derek-carr-amid-struggling-seasons-wonder-why-adams-left)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 18:11:33+00:00

Antonio Brown is at it again on social media, this time taking aim at veteran NFL quarterbacks Aaron Rodgers of the Packers and the Raiders' Derek Carr.

## Fox Nation honors Yellowstone's 150th birthday with special episodes of 'Yellowstone: One-Fifty,' 'Park'd'
 - [https://www.foxnews.com/media/fox-nation-honors-yellowstones-150th-birthday-with-special-episodes-yellowstone-one-fifty-parkd](https://www.foxnews.com/media/fox-nation-honors-yellowstones-150th-birthday-with-special-episodes-yellowstone-one-fifty-parkd)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 17:39:47+00:00

Abby Hornacek joined 'Fox & Friends Weekend' to discuss how Fox Nation is honoring Yellowstone's 150th birthday with new, special episodes dedicated to the oldest national park.

## Idaho police to hold press conference one week after brutal university murders
 - [https://www.foxnews.com/us/idaho-police-hold-press-conference-week-brutal-university-murders](https://www.foxnews.com/us/idaho-police-hold-press-conference-week-brutal-university-murders)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 17:31:20+00:00

Police in Moscow, Idaho, will hold a press conference on Sunday afternoon at 3 PST to provide updates on the quadruple fatal stabbing of University of Idaho students.

## Iranian regime targets Kurdish city in crackdown on protests
 - [https://www.foxnews.com/world/iranian-regime-targets-kurdish-city-crack-down-protests](https://www.foxnews.com/world/iranian-regime-targets-kurdish-city-crack-down-protests)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 17:24:55+00:00

Iran has taken aim at a small Kurdish-majority city in its most recent attempt to fight back against protests that have raged in the country for over two months.

## One dead, 27 injured in bus crash near Brandeis University following hockey game
 - [https://www.foxnews.com/us/one-dead-27-injured-bus-crash-near-brandeis-university-following-hockey-game](https://www.foxnews.com/us/one-dead-27-injured-bus-crash-near-brandeis-university-following-hockey-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 17:18:22+00:00

A Saturday night bus crash near Massachusetts' Brandeis University campus left one student dead and 27 others injured, mostly Brandeis students, according to officials.

## Who is Anderson Lee Aldrich? Suspect in Colorado nightclub shooting had previous major run-in with police
 - [https://www.foxnews.com/us/who-anderson-lee-aldrich-suspect-colorado-nightclub-shooting-previous-major-run-police](https://www.foxnews.com/us/who-anderson-lee-aldrich-suspect-colorado-nightclub-shooting-previous-major-run-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 17:12:00+00:00

Anderson Lee Aldrich, the suspect in Saturday's shooting at an LGBTQ nightclub in Colorado, was previously arrested for bomb threats in 2021, according to records.

## Biden DOE official claims DeSantis was willing to 'sacrifice' people: 'Some of you may die'
 - [https://www.foxnews.com/media/biden-doe-official-claims-desantis-willing-sacrifice-people-you-may-die](https://www.foxnews.com/media/biden-doe-official-claims-desantis-willing-sacrifice-people-you-may-die)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 17:00:52+00:00

A Biden U.S. Department of Education official had biting words about Florida Gov. Ron DeSantis on Twitter, calling him "tiny" and a "bully."

## 2022 AMAs: Taylor Swift nominated, Wayne Brady hosting, Carrie Underwood performing and what else to know
 - [https://www.foxnews.com/entertainment/2022-amas-taylor-swift-nominated-wayne-brady-hosting-carrie-underwood-performing-what-else-to-know](https://www.foxnews.com/entertainment/2022-amas-taylor-swift-nominated-wayne-brady-hosting-carrie-underwood-performing-what-else-to-know)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 17:00:32+00:00

The AMA Awards, one of the few award shows decided by fan votes, are here. Here's a look at who's hosting and performing and other details about the show.

## McCarthy vows to remove Swalwell, Schiff, Omar from House committees
 - [https://www.foxnews.com/politics/mccarthy-vows-remove-swalwell-schiff-omar-house-committees](https://www.foxnews.com/politics/mccarthy-vows-remove-swalwell-schiff-omar-house-committees)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 16:38:24+00:00

House Minority Leader Kevin McCarthy, R-Calif., on Sunday vowed to remove Democratic Reps. Eric Swalwell and Adam Schiff from the House Intelligence Committee.

## Idaho university murder victim's mom reveals last messages she sent just hours before tragic killing
 - [https://www.foxnews.com/us/idaho-university-murder-victims-mom-reveals-last-messages-she-sent-just-hours-before-tragic-killing](https://www.foxnews.com/us/idaho-university-murder-victims-mom-reveals-last-messages-she-sent-just-hours-before-tragic-killing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 16:31:40+00:00

Kristi Goncalves, the mom of slain Idaho student Kaylee Goncalves, reveals she talked to her daughter Saturday and received photos from her later that day.

## Cotton sides with Biden on granting immunity to Saudi crown prince
 - [https://www.foxnews.com/politics/cotton-sides-with-biden-granting-immunity-saudi-crown-prince](https://www.foxnews.com/politics/cotton-sides-with-biden-granting-immunity-saudi-crown-prince)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 16:09:01+00:00

The Biden administration's decision to shield Saudi Crown Prince Mohammed bin Salman from U.S.-based lawsuits was backed by Sen. Tom Cotton, R-Ark, on Fox News Sunday.

## Nikole Hannah-Jones challenges New York City mom's subway concerns under Hochul
 - [https://www.foxnews.com/media/nikole-hannah-jones-challenges-new-york-city-moms-subway-concerns-hochul](https://www.foxnews.com/media/nikole-hannah-jones-challenges-new-york-city-moms-subway-concerns-hochul)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 16:04:22+00:00

1619 Project founder Nikole Hannah-Jones mocked Asian Wave Alliance President Yiatin Chu on Thursday for a tweet about subway safety in New York City.

## Cops identify suspect in Colorado LGBTQ nightclub shooting
 - [https://www.foxnews.com/us/cops-identify-suspect-colorado-gay-nightclub-shooting](https://www.foxnews.com/us/cops-identify-suspect-colorado-gay-nightclub-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 15:57:56+00:00

Police identified the suspect in Saturday's shooting at an LGBT@ club in Colorado Springs as Anderson Lee Aldrich, 22. Police say it is unclear if the attack was a hate crime.

## Florida drug investigation nets 2 arrests, 23 guns seized
 - [https://www.foxnews.com/us/florida-drug-investigation-nets-2-arrests-23-guns-seized](https://www.foxnews.com/us/florida-drug-investigation-nets-2-arrests-23-guns-seized)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 15:41:01+00:00

Tampa police arrested two men and recovered nearly dozen firearms after executing a search warrant as part of an investigation of a suspected drug dealer.

## Parents of Idaho university murder victim reveal why investigation is taking so much time: 'made a mess'
 - [https://www.foxnews.com/us/parents-idaho-university-murder-victim-reveal-why-investigation-taking-so-much-time-made-a-mess](https://www.foxnews.com/us/parents-idaho-university-murder-victim-reveal-why-investigation-taking-so-much-time-made-a-mess)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 15:27:10+00:00

The parents of Kaylee Goncalves, one of the Idaho college students who was fatally stabbed, said the investigation will take time due to all of the evidence police have collected.

## One of country's most liberal cities takes moderate turn after election, pushes back on 'Defund the Police'
 - [https://www.foxnews.com/politics/one-countrys-most-liberal-cities-takes-moderate-turn-after-election-pushes-back-defund-police](https://www.foxnews.com/politics/one-countrys-most-liberal-cities-takes-moderate-turn-after-election-pushes-back-defund-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 15:07:16+00:00

West Hollywood, California, which has long been known as one of the most progressive cities in the country, has taken a more moderate turn after the midterm elections.

## Odell Beckham Jr sets visits with 2 teams as sweepstakes nears its end: report
 - [https://www.foxnews.com/sports/odell-beckham-jr-sets-visits-2-teams-sweepstakes-near-end-report](https://www.foxnews.com/sports/odell-beckham-jr-sets-visits-2-teams-sweepstakes-near-end-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 14:56:18+00:00

Odell Beckham Jr. appeared to be closer to choosing a team for the remainder of the 2022 season and has two visits after Thanksgiving reportedly set to go.

## 4 dead in small plane crash in Washington state
 - [https://www.foxnews.com/us/dead-small-plane-crash-washington-state](https://www.foxnews.com/us/dead-small-plane-crash-washington-state)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 14:50:35+00:00

The FAA and NTSB are investigating after a single-engine Textron 208B crashed into a field and caught fire on Friday morning, killing four people, officials said.

## Idaho university murders: What we know, what investigators should look for, and how the public can help
 - [https://www.foxnews.com/media/university-idaho-murders-know-investigators-should-look-how-public-help](https://www.foxnews.com/media/university-idaho-murders-know-investigators-should-look-how-public-help)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 14:43:30+00:00

Crime experts Ted Williams and Dr. Michael Baden weighed in on the University of Idaho stabbings on Sunday's 'Fox & Friends Weekend,' discussing key forensic details.

## Pacers' Aaron Nesmith slips on wet floor in post-game celebration snafu
 - [https://www.foxnews.com/sports/pacers-aaron-nesmith-slips-wet-floor-post-game-celebration-snafu](https://www.foxnews.com/sports/pacers-aaron-nesmith-slips-wet-floor-post-game-celebration-snafu)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 14:34:10+00:00

Indiana Pacers forward Aaron Nesmith scored 19 points off the bench but had a little trouble with the celebration of his big game against the Orlando Magic.

## Ex-MLB star Asdrubal Cabrera clocks opposing player who hit home run, sparking wild brawl in Venezuelan league
 - [https://www.foxnews.com/sports/ex-mlb-star-asdrubal-cabrera-clocks-opposing-player-hit-home-run-sparking-wild-brawl-venzeulan-league](https://www.foxnews.com/sports/ex-mlb-star-asdrubal-cabrera-clocks-opposing-player-hit-home-run-sparking-wild-brawl-venzeulan-league)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 14:26:49+00:00

Asdrubal Cabrera, former MLB star, got into a fight in the Venezuelan Winter League on Saturday night after the opposing team hit a big home run.

## China agrees to meet with US defense secretary for first time since Taiwan crisis
 - [https://www.foxnews.com/politics/china-agrees-meet-us-defense-secretary-first-time-taiwan-crisis](https://www.foxnews.com/politics/china-agrees-meet-us-defense-secretary-first-time-taiwan-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 14:24:57+00:00

Defense Secretary Lloyd Austin will meet with his Chinese counterpart this week for the first time since China escalated military drills around Taiwan this summer.

## Parents of Idaho university murder victim vow ex-boyfriend's innocence in case: 'We stand behind Jack 1000%'
 - [https://www.foxnews.com/media/parents-idaho-university-murder-victim-vow-ex-boyfriend-innocence-case-stand-jack-1000](https://www.foxnews.com/media/parents-idaho-university-murder-victim-vow-ex-boyfriend-innocence-case-stand-jack-1000)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 14:18:48+00:00

The parents of slain Idaho college student, Kaylee Goncalves, spoke out on 'Lawrence Jones Cross Country,' maintaining their daughter's ex-boyfriend's innocence in the case.

## Veronika Khomyn, wife of Rams' Sean McVay, opens up on toughest part of marriage: 'It’s impossible'
 - [https://www.foxnews.com/sports/veronika-khomyn-wife-rams-sean-mcvay-opens-toughest-part-marriage-its-impossible](https://www.foxnews.com/sports/veronika-khomyn-wife-rams-sean-mcvay-opens-toughest-part-marriage-its-impossible)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 14:17:38+00:00

Veronika Khomyn, the wife of Los Angeles Rams coach Sean McVay, shared about the struggle of being married to an NFL coach in an Instagram post.

## Tom Cruise teased for 'ruining' TV show 'Call the Midwife' for operating his helicopter
 - [https://www.foxnews.com/entertainment/tom-cruise-teased-ruining-tv-show-call-midwife-operating-helicopter](https://www.foxnews.com/entertainment/tom-cruise-teased-ruining-tv-show-call-midwife-operating-helicopter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 14:11:51+00:00

"Call the Midwife" actress Jenny Agutter is calling out actor Tom Cruise for his use of his helicopter over the set of her BBC show. She says the noise is "ruining" the production.

## World Cup 2022: Budweiser finds alternative idea for beer surplus following alcohol ban
 - [https://www.foxnews.com/sports/world-cup-2022-budweiser-finds-alternative-idea-beer-surplus-alcohol-ban](https://www.foxnews.com/sports/world-cup-2022-budweiser-finds-alternative-idea-beer-surplus-alcohol-ban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 14:10:38+00:00

Budweiser found a good way to get rid of the rest of their beer after Qatar and FIFA agreed to an alcohol ban for the World Cup outside the fan festivals.

## Rhode Island official shares 'extreme' view that using the wrong pronoun is an act of violence
 - [https://www.foxnews.com/media/rhode-island-official-shares-extreme-view-using-wrong-pronoun-act-violence](https://www.foxnews.com/media/rhode-island-official-shares-extreme-view-using-wrong-pronoun-act-violence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 14:10:06+00:00

A Rhode Island elected official claimed using the wrong pronouns was a form of violence, and used a definition from the World Health Organization to justify her claims.

## Accused 'Potomac River Rapist' found dead in jail while awaiting trial for murder, police say
 - [https://www.foxnews.com/us/accused-potomac-river-rapist-found-dead-jail-awaiting-trial-murder-police](https://www.foxnews.com/us/accused-potomac-river-rapist-found-dead-jail-awaiting-trial-murder-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 14:06:28+00:00

Giles Warrick, the man accused of being the "Potomac River Rapist" who terrorized the Washington, D.C., area in the 1990s, was found dead in a jail cell on Saturday.

## Striking black cat found underweight, dehydrated in Utah needs a new home
 - [https://www.foxnews.com/lifestyle/striking-black-cat-found-underweight-dehydrated-utah-needs-home](https://www.foxnews.com/lifestyle/striking-black-cat-found-underweight-dehydrated-utah-needs-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 13:00:45+00:00

It's National Adopt-a-Senior-Pet Month— and five-year-old cat Dusk is currently available for adoption at Best Friends Lifesaving Center in Salt Lake City, Utah.

## Woke goes to die over education at the ballot box
 - [https://www.foxnews.com/opinion/woke-goes-die-education-ballot-box](https://www.foxnews.com/opinion/woke-goes-die-education-ballot-box)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 13:00:27+00:00

Midterm election voters rewarded incumbent candidates who fought for parental rights and education freedom.

## Area 51 website owner who says armed feds raided his homes speaks out: 'It could be your door next'
 - [https://www.foxnews.com/us/area-51-website-owner-who-says-armed-feds-raided-his-homes-speaks-out-it-could-be-your-door-next](https://www.foxnews.com/us/area-51-website-owner-who-says-armed-feds-raided-his-homes-speaks-out-it-could-be-your-door-next)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 12:47:36+00:00

The owner of an Area 51 website says federal agents raided two of his homes, busted down his door, and "manhandled" him investigating a crime he is still not aware of.

## Why this 'Fox & Friends' co-host is grateful his wife went to get new sunglasses
 - [https://www.foxnews.com/opinion/why-fox-friends-co-host-grateful-wife-new-sunglasses](https://www.foxnews.com/opinion/why-fox-friends-co-host-grateful-wife-new-sunglasses)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 12:00:27+00:00

Thanksgiving week is a wonderful time to be thankful for our blessings and reflect on them. I am grateful that my wife and I went to get new sunglasses a few years ago. Here's why.

## U.K. doctor testifies in Lucy Letby 'killer nurse' trial: 'Nothing I've seen before or since'
 - [https://www.foxnews.com/world/doctor-testifies-lucy-letby-killer-nurse-trial-nothing-ive-seen-before-since](https://www.foxnews.com/world/doctor-testifies-lucy-letby-killer-nurse-trial-nothing-ive-seen-before-since)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 12:00:14+00:00

A doctor in the trial of U.K. nurse Lucy Letby, who is accused of murdering seven babies as a neonatal nurse, testified that he had never seen a baby's condition deteriorate so quickly.

## Indiana man saved by South Bend officer as a toddler makes it his 'mission' to thank her 24 years later
 - [https://www.foxnews.com/lifestyle/indiana-man-saved-south-bend-officer-toddler-makes-his-mission-thank-her-24-years-later](https://www.foxnews.com/lifestyle/indiana-man-saved-south-bend-officer-toddler-makes-his-mission-thank-her-24-years-later)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 11:13:51+00:00

Over two decades after a South Bend police officer saved the life of a toddler walking alone in traffic, the now 27-year-old man returned to the department to say thank you.

## Multiple dead, several others injured in shooting at Colorado Springs club
 - [https://www.foxnews.com/us/multiple-dead-several-others-injured-shooting-colorado-springs-club](https://www.foxnews.com/us/multiple-dead-several-others-injured-shooting-colorado-springs-club)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 11:06:46+00:00

A shooting at a club in Colorado Springs early Sunday morning left at least five people dead and another 18 injured. The suspected shooter was taken into custody.

## GOP AGs moving forward with lawsuit targeting FBI, top Biden officials for allegedly colluding with Big Tech
 - [https://www.foxnews.com/media/gop-ags-moving-forward-lawsuit-targeting-fbi-top-biden-officials-allegedly-colluding-big-tech](https://www.foxnews.com/media/gop-ags-moving-forward-lawsuit-targeting-fbi-top-biden-officials-allegedly-colluding-big-tech)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 11:00:50+00:00

Missouri Attorney General Eric Schmitt had a major gain in a lawsuit against the FBI and top-ranking Biden officials, he told "Unfiltered with Dan Bongino."

## NFL Week 11 preview: Chiefs look to separate from AFC West rivals, New York teams look to take control
 - [https://www.foxnews.com/sports/nfl-week-11-preview-chiefs-look-separate-afc-west-rivals-new-york-teams-look-take-control](https://www.foxnews.com/sports/nfl-week-11-preview-chiefs-look-separate-afc-west-rivals-new-york-teams-look-take-control)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 11:00:50+00:00

Week 11 of the NFL season will mean more to a handful of teams vying for playoff spots with only a few games left. Here's what is cooking in the NFL on Sunday

## Trump takes incoming fire from potential GOP nomination rivals at first major 2024 cattle call
 - [https://www.foxnews.com/politics/trump-takes-incoming-fire-potential-gop-nomination-rivals-first-major-2024-cattle-call](https://www.foxnews.com/politics/trump-takes-incoming-fire-potential-gop-nomination-rivals-first-major-2024-cattle-call)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 10:02:30+00:00

Former President Donald Trump faces criticism from potential nomination rivals the Republican Jewish Coalition conference, the first major GOP 2024 cattle call

## Las Vegas metro police searching for sexual assault victims of suspect nabbed in cold case
 - [https://www.foxnews.com/us/las-vegas-metro-police-searching-sexual-assault-victims-suspect-nabbed-cold-case](https://www.foxnews.com/us/las-vegas-metro-police-searching-sexual-assault-victims-suspect-nabbed-cold-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 09:58:51+00:00

After announcing an arrest in a 1980 murder and sexual assault, Las Vegas Metropolitan Police are looking for more people who could have been victimized by 64-year-old Paul Nuttall.

## NH Gov. Chris Sununu says Republicans need to stop backing 'crazy, unelectable candidates' in GOP primaries
 - [https://www.foxnews.com/politics/nh-gov-chris-sununu-says-republicans-need-stop-backing-crazy-unelectable-candidates-gop-primaries](https://www.foxnews.com/politics/nh-gov-chris-sununu-says-republicans-need-stop-backing-crazy-unelectable-candidates-gop-primaries)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 09:51:39+00:00

New Hampshire Gov. Chris Sununu told the Republican Party that "candidate quality matters" and to stop supporting "unelectable" candidates in GOP primaries.

## Chris Christie says GOP should move past Trump: 'It is time to stop being afraid of any one person'
 - [https://www.foxnews.com/politics/chris-christie-says-gop-should-move-past-trump-time-stop-being-afraid-any-one-person](https://www.foxnews.com/politics/chris-christie-says-gop-should-move-past-trump-time-stop-being-afraid-any-one-person)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 09:27:02+00:00

Former New Jersey Gov. Chris Christie said the Republican Party ought to move on from Donald Trump, just days after Trump announced his is running for president again.

## Joe Biden celebrates 80th birthday after Naomi Biden's White House wedding
 - [https://www.foxnews.com/politics/joe-biden-celebrates-80th-birthday-after-naomi-bidens-white-house-wedding](https://www.foxnews.com/politics/joe-biden-celebrates-80th-birthday-after-naomi-bidens-white-house-wedding)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 09:19:01+00:00

Joe Biden is celebrating his 80th birthday at the White House Sunday, becoming the only U.S. president to do so while in office. Biden's health and age are often questioned.

## Joe Biden celebrates turning 80 years old day after Naomi Biden's White House wedding
 - [https://www.foxnews.com/politics/joe-biden-celebrates-turning-80-years-old-day-after-naomi-bidens-white-house-wedding](https://www.foxnews.com/politics/joe-biden-celebrates-turning-80-years-old-day-after-naomi-bidens-white-house-wedding)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 09:19:01+00:00

Joe Biden is celebrating his 80th birthday at the White House Sunday, becoming the only U.S. president to do so while in office. Biden's health and age are often questioned.

## FOX Bet Super 6: Terry Bradshaw is giving away $100,000 in NFL Week 11
 - [https://www.foxnews.com/sports/fox-bet-super-6-terry-bradshaw-giving-away-100000-nfl-week-11](https://www.foxnews.com/sports/fox-bet-super-6-terry-bradshaw-giving-away-100000-nfl-week-11)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 07:51:09+00:00

Players could win $100,000 in NFL Week 11 by playing FOX Bet Super 6 and picking the winners and margins of victory for six marquee matchups,

## Texas man with multiple DWI convictions sentenced in drunken crash that killed father of four
 - [https://www.foxnews.com/us/texas-man-multiple-dwi-convictions-sentenced-drunken-crash-killed-father-four](https://www.foxnews.com/us/texas-man-multiple-dwi-convictions-sentenced-drunken-crash-killed-father-four)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 07:01:03+00:00

A Texas man with five prior convictions for driving while intoxicated was sentenced to 35 years in prison for a 2018 drunk-driving crash that killed Wayne Childers, a father of four.

## Abortion is 'gruesome sign' of what society has forgotten, says Catholic archbishop
 - [https://www.foxnews.com/lifestyle/abortion-gruesome-sign-society-forgotten-church-archbishop](https://www.foxnews.com/lifestyle/abortion-gruesome-sign-society-forgotten-church-archbishop)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 07:00:47+00:00

In the wake of the Dobbs decision, the pro-life work and advocacy of the Catholic Church is far from over, Church leaders said at the bishops' conference this week in Baltimore, Maryland.

## ELI STEELE: Pastor Corey Brooks is reviving the American Dream
 - [https://www.foxnews.com/opinion/eli-steele-pastor-corey-brooks-reviving-american-dream](https://www.foxnews.com/opinion/eli-steele-pastor-corey-brooks-reviving-american-dream)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 07:00:03+00:00

Pastor Corey Brooks spent nearly a year on a Chicago rooftop. He wasn't just raising money for a community center — he was reviving the American Dream.

## Nikki Haley hints at 2024 presidential run during Republican Jewish Coalition speech: 'I've never lost'
 - [https://www.foxnews.com/politics/nikki-haley-hints-2024-presidential-run-republican-jewish-coalition-speech](https://www.foxnews.com/politics/nikki-haley-hints-2024-presidential-run-republican-jewish-coalition-speech)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 06:53:28+00:00

Nikki Haley commented on the 2024 presidential elections and whether or not she would run during a speech at at the Republican Jewish Coalition annual meeting in Las Vegas, Nevada.

## Ron DeSantis receives multiple standing ovations at first major GOP 2024 presidential cattle call
 - [https://www.foxnews.com/politics/ron-desantis-receives-multiple-standing-ovations-first-major-gop-2024-presidential-cattle-call](https://www.foxnews.com/politics/ron-desantis-receives-multiple-standing-ovations-first-major-gop-2024-presidential-cattle-call)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 06:29:06+00:00

GOP Gov. Ron DeSantis of Florida keynotes the Republican Jewish Coalition's annual leadership summit in Las Vegas, which is seen as the first major 2024 cattle call

## Dog killed by mountain lion while on a walk in Los Angeles
 - [https://www.foxnews.com/us/dog-killed-mountain-lion-while-walk-los-angeles](https://www.foxnews.com/us/dog-killed-mountain-lion-while-walk-los-angeles)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 05:41:36+00:00

A mountain lion attacked and killed a chihuahua as it was being walked by a dog walker Friday night. Video of the attack was caught on a home's security camera.

## Donald Trump reacts after Elon Musk reinstates his Twitter account, ending lifetime ban
 - [https://www.foxnews.com/politics/donald-trump-reacts-after-elon-musk-reinstates-his-twitter-account-ending-lifetime-ban](https://www.foxnews.com/politics/donald-trump-reacts-after-elon-musk-reinstates-his-twitter-account-ending-lifetime-ban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 04:48:19+00:00

Former President Donald Trump has responded to Elon Musk reinstating him to Twitter on Saturday, following a poll Musk conducted asking users if he should be allowed back.

## Spencer Rattler has career night as South Carolina pulls off dominating upset against No. 5 Tennessee
 - [https://www.foxnews.com/sports/spencer-rattler-career-night-south-carolina-dominating-upset-no-5-tennessee](https://www.foxnews.com/sports/spencer-rattler-career-night-south-carolina-dominating-upset-no-5-tennessee)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 04:29:54+00:00

The South Carolina Gamecocks never let off the gas pedal on Saturday night in their dominating win over the fifth-ranked Tennessee Volunteers.

## Idaho university murders: Police reveal key details about events surrounding stabbing of 4 students
 - [https://www.foxnews.com/us/idaho-university-murders-police-reveal-key-details-about-events-surrounding-stabbing-students](https://www.foxnews.com/us/idaho-university-murders-police-reveal-key-details-about-events-surrounding-stabbing-students)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 03:42:57+00:00

Idaho police revealed new details about the events surrounding the stabbings of four University of Idaho students that happened on early Sunday morning

## North Carolina police identify 20-year-old driver of truck who struck, killed girl during Christmas parade
 - [https://www.foxnews.com/us/north-carolina-police-identify-20-year-old-driver-truck-struck-killed-girl-during-christmas-parade](https://www.foxnews.com/us/north-carolina-police-identify-20-year-old-driver-truck-struck-killed-girl-during-christmas-parade)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 03:23:17+00:00

The out-of-control truck pulling a float that crashed into a girl dancing in a Raleigh Christmas parade Saturday morning was being driven by a 20-year-old.

## Biden signaled 'weakness' at G-20, doesn't have a 'macro-sense' of what's going on: Gordon Sondland
 - [https://www.foxnews.com/media/biden-signaled-weakness-g-20-doesnt-have-macro-sense-going-gordon-sondland](https://www.foxnews.com/media/biden-signaled-weakness-g-20-doesnt-have-macro-sense-going-gordon-sondland)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 03:09:37+00:00

Former Amb. Gordon Sondland called out President Biden's visit to the G-20 Summit and praised former President Donald Trump's approach to diplomacy on "One Nation with Brian Kilmeade."

## Liberals on Twitter fume after Musk reinstates Trump to platform: 'God help us'
 - [https://www.foxnews.com/politics/liberals-twitter-fume-musk-reinstates-trump-platform-god-help-us](https://www.foxnews.com/politics/liberals-twitter-fume-musk-reinstates-trump-platform-god-help-us)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 03:04:13+00:00

Liberals and various celebrities on social media responded with frustration and concern after Elon Musk reinstated former President Trump to Twitter.

## Texas DPS troopers stop human smuggling operations in 2 separate traffic stops last weekend
 - [https://www.foxnews.com/us/texas-dps-troopers-human-smuggling-operations-separate-traffic-stops](https://www.foxnews.com/us/texas-dps-troopers-human-smuggling-operations-separate-traffic-stops)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 02:58:19+00:00

Troopers with the Texas Department of Public Safety arrested two human smugglers in two separate incidents this month as part of Operation Lone Star.

## 2022 World Cup: France loses Ballon d'Or winner for tournament after he tears muscle in practice
 - [https://www.foxnews.com/sports/2022-world-cup-france-loses-ballon-dor-winner-tournament-tearing-muscle-practice](https://www.foxnews.com/sports/2022-world-cup-france-loses-ballon-dor-winner-tournament-tearing-muscle-practice)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 02:52:59+00:00

Reigning Ballon d'Or winner Karim Benzema of France tore a muscle in his leg during Saturday's practice and will miss the World Cup, which begins Sunday.

## Chris Hemsworth says he's taking a break from acting to spend time with family after facing his own mortality
 - [https://www.foxnews.com/entertainment/chris-hemsworth-says-taking-time-from-acting-facing-own-mortality](https://www.foxnews.com/entertainment/chris-hemsworth-says-taking-time-from-acting-facing-own-mortality)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 02:46:09+00:00

Chris Hemsworth is taking a break from acting to spend time with his family after facing his own mortality during an episode about death in his new show.

## Idaho student murders: Law enforcement trying to 'expedite everything' in search for suspect, prosecutor says
 - [https://www.foxnews.com/us/idaho-student-murders-law-enforcement-trying-expedite-everything-search-suspect-prosecutor-says](https://www.foxnews.com/us/idaho-student-murders-law-enforcement-trying-expedite-everything-search-suspect-prosecutor-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 02:38:25+00:00

An Idaho prosecutor said law enforcement is working to "expedite everything" in the search for a suspect that killed four University of Idaho students.

## No. 1 Georgia takes down Kentucky, sweeps SEC for second consecutive regular season
 - [https://www.foxnews.com/sports/no-1-georgia-takes-down-kentucky-sweeps-sec-second-consecutive-year](https://www.foxnews.com/sports/no-1-georgia-takes-down-kentucky-sweeps-sec-second-consecutive-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 01:53:47+00:00

Georgia's usually explosive offense could only do so much against Kentucky's stout defense, but 16 points proved to be enough for the top-ranked Bulldogs to remain unbeaten.

## Illinois head coach blasts refs after loss to No. 3 Michigan
 - [https://www.foxnews.com/sports/illinois-head-coach-blasts-refs-loss-no-3-michigan](https://www.foxnews.com/sports/illinois-head-coach-blasts-refs-loss-no-3-michigan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 01:27:31+00:00

No. 3 Michigan avoided an upset at home to the Illinois Fighting Illini, but Illinois head coach Bret Bielema thinks Michigan got some help from the refs.

## Elon Musk says Trump will be reinstated to Twitter after more than 15 million users voted in poll
 - [https://www.foxnews.com/politics/elon-musk-says-trump-reinstated-twitter-more-15-million-users-voted-poll](https://www.foxnews.com/politics/elon-musk-says-trump-reinstated-twitter-more-15-million-users-voted-poll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 01:22:00+00:00

Twitter CEO Elon Musk former President Trump will be readmitted to Twitter after more than 7.5 million users voted to bring him back to the platform.

## Kevin McCarthy says he will remove Ilhan Omar from committee assignment over 'antisemitism' when speaker
 - [https://www.foxnews.com/politics/kevin-mccarthy-says-will-remove-ilhan-omar-committee-assignment-antisemitism-speaker](https://www.foxnews.com/politics/kevin-mccarthy-says-will-remove-ilhan-omar-committee-assignment-antisemitism-speaker)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 01:13:40+00:00

Minority Leader Kevin McCarthy said he'll strip Rep. Ilhan Omar of her House Foreign Affairs Committee assignment if he is elected speaker in the next term.

## Kyrie Irving discusses 'learning journey' since suspension: 'A lot of hurt that needed to be healed'
 - [https://www.foxnews.com/sports/kyrie-irving-discusses-learning-journey-suspension-hurt-needed-healed](https://www.foxnews.com/sports/kyrie-irving-discusses-learning-journey-suspension-hurt-needed-healed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 00:54:05+00:00

Kyrie Irving once again apologized for tweeting an antisemitic documentary and being unapologetic about it, saying he's had tough conversations in the last few weeks.

## Tim Allen talks long friendship with 'Toy Story' co-star Tom Hanks: 'I adore that man's heart and mind'
 - [https://www.foxnews.com/entertainment/tim-allen-talks-long-friendship-toy-story-co-star-tom-hanks-adore-mans-heart-mind](https://www.foxnews.com/entertainment/tim-allen-talks-long-friendship-toy-story-co-star-tom-hanks-adore-mans-heart-mind)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 00:29:11+00:00

Tim Allen shared details about how he stays in touch with his "Toy Story" co-star Tom Hanks, saying the two get together for the "most peculiar" lunches.

## UFC Fight Night 215 headliner canceled at last minute due to undisclosed Derrick Lewis illness
 - [https://www.foxnews.com/sports/ufcs-main-event-canceled-saturday-night-league-officials-announce](https://www.foxnews.com/sports/ufcs-main-event-canceled-saturday-night-league-officials-announce)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 00:25:36+00:00

Heavyweights Derrick Lewis and Serghei Spivac will no longer battle at UFC Vegas 65 in Las Vegas. The event was canceled because Lewis came down with an illness.

## Idaho university murders: Prosecutor seen entering house where four students were stabbed to death
 - [https://www.foxnews.com/us/idaho-university-murders-prosecutor-seen-entering-house-where-four-students-were-stabbed-death](https://www.foxnews.com/us/idaho-university-murders-prosecutor-seen-entering-house-where-four-students-were-stabbed-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-20 00:15:37+00:00

Latah County prosecuting attorney Bill Thompson was seen on Saturday entering the Moscow, Idaho, home where four students were killed on Nov. 13.


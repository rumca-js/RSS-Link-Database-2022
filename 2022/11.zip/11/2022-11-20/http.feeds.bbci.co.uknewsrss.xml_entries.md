# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## The Papers: 'Lions of Arabia' and 'soft Brexit warnings'
 - [https://www.bbc.co.uk/news/blogs-the-papers-63697978?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-63697978?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 23:59:23+00:00

The final countdown to England's World Cup kick off is causing much excitement on Monday's front pages.

## UK Championship final: Mark Allen beats Ding Junhui 10-7 after being 6-1 behind
 - [https://www.bbc.co.uk/sport/snooker/63691850?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/snooker/63691850?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 23:53:52+00:00

Mark Allen produces a sensational recovery as he fights back from 6-1 down to beat Ding Junhui 10-7 for his first UK Championship title.

## World Cup 2022: Tears and emotion as Wales return
 - [https://www.bbc.co.uk/news/uk-wales-63208053?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-63208053?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 22:05:45+00:00

It is a day many fans feared they would never see, with 64 years of hurt finally coming to an end.

## World Cup 2022: Qatar beaten by Ecuador as dream turns into nightmare
 - [https://www.bbc.co.uk/sport/football/63695036?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63695036?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 21:35:05+00:00

Qatar were beaten by Ecuador as the dreams of the host nation turned into a nightmare at Al Bayt Stadium.

## 'My small country is now the centre of the world'
 - [https://www.bbc.co.uk/news/world-middle-east-63696648?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-63696648?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 21:20:52+00:00

How Qataris feel about their country becoming the first in the Arab world to host a World Cup.

## Turkey Kurdish strikes: A population living in fear
 - [https://www.bbc.co.uk/news/world-middle-east-63697644?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-63697644?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 20:47:15+00:00

After the recent bombing in Istanbul, Turkish retaliatory air strikes on Kurdish targets have left a population on edge.

## ATP Finals: Novak Djokovic beats Casper Ruud to equal Roger Federer's record
 - [https://www.bbc.co.uk/sport/tennis/63696459?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/63696459?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 20:44:43+00:00

Former world number one Novak Djokovic beats Casper Ruud to win a record-equalling sixth ATP Finals.

## England: 'No escape from furnace and expectation at World Cup 2022'
 - [https://www.bbc.co.uk/sport/football/63693420?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63693420?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 20:12:06+00:00

With England set to open their World Cup campaign against Iran on Monday, BBC Sport's Phil McNulty takes a closer look at what is at stake.

## World Cup 2022: England and Wales braced for tournament openers
 - [https://www.bbc.co.uk/sport/football/63697402?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63697402?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 20:06:41+00:00

Gareth Southgate says he wants to take England fans on a happy journey while Wales captain Gareth Bale relishes a "massive piece" of Wales' football history.

## Martyn's Law: PM urged not to delay venue security bill
 - [https://www.bbc.co.uk/news/uk-england-manchester-63695982?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-63695982?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 18:21:09+00:00

Protect Duty, or Martyn's Law, was introduced in the wake of the Manchester Arena bombing.

## World Cup 2022: Qatar 0-2 Ecuador: Enner Valencia double gives South Americans win
 - [https://www.bbc.co.uk/sport/football/63603375?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63603375?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 18:16:07+00:00

Hosts Qatar open the 2022 Fifa World Cup in calamitous fashion, easily beaten by Ecuador in a humbling defeat at Al Bayt.

## World Cup 2022: Enner Valencia scores double as hosts lose opening game
 - [https://www.bbc.co.uk/sport/av/football/63669797?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63669797?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 18:12:38+00:00

Watch highlights as Qatar become the first host nation to lose their opening game as Ecuador captain Enner Valencia scores twice.

## England v Iran: Preview, team news, predictions & stats
 - [https://www.bbc.co.uk/sport/football/63603382?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63603382?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 17:49:06+00:00

Gareth Southgate hopes England can go on a "fantastic journey" at the World Cup to bring "real happiness" to the nation

## World Cup 2022: Bale wants World Cup to 'inspire a Welsh generation'
 - [https://www.bbc.co.uk/sport/av/football/63697097?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63697097?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 17:44:46+00:00

Wales captain Gareth Bale wants their historic World Cup appearance to inspire the next generation.

## England: Gareth Southgate says players will take the knee before Iran World Cup 2022 match
 - [https://www.bbc.co.uk/sport/football/63695662?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63695662?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 17:40:00+00:00

Gareth Southgate says his England players will take the knee before Monday's World Cup opener against Iran.

## Joe Lycett 'shreds' £10k in David Beckham Qatar protest
 - [https://www.bbc.co.uk/news/uk-63692988?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63692988?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 17:38:27+00:00

The comedian appears to destroy wads of banknotes in an industrial shredder in a clip posted on Twitter.

## Dominic Raab warns terrorists over further prison time
 - [https://www.bbc.co.uk/news/uk-63696400?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63696400?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 17:27:27+00:00

Dominic Raab says terrorist offenders will be punished if they are "unwilling to change their ways".

## World Cup 2022: Morgan Freeman and Jung Kook star in glitzy opening ceremony
 - [https://www.bbc.co.uk/sport/football/63692043?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63692043?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 17:13:31+00:00

The 2022 World Cup kicks off with a visually striking opening ceremony before the first match between hosts Qatar and Ecuador.

## Iran captain voices solidarity with protests at home
 - [https://www.bbc.co.uk/sport/football/63696125?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63696125?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 16:58:32+00:00

Iran captain Ehsan Hajsafi speaks out against the situation in his home country before his nation's opening game against England at the World Cup.

## World Cup 2022: Enner Valencia's second doubles Ecuador's lead against Qatar
 - [https://www.bbc.co.uk/sport/av/football/63696412?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63696412?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 16:54:49+00:00

Watch as Ecuador captain Enner Valencia scores his second goal as Ecuador lead Qatar 2-0 in the opening game of the Fifa World Cup in Qatar.

## Nottingham: Murder probe as children, three and one, die in flat fire
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-63690097?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-63690097?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 16:42:41+00:00

Firefighters say they were called out after neighbours in Nottingham saw smoke coming from the flat.

## World Cup 2022: Watch the best of the World Cup opening ceremony
 - [https://www.bbc.co.uk/sport/av/football/63696120?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63696120?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 16:40:44+00:00

Watch the best moments from the opening ceremony of the 2022 World Cup from the Al Bayt Stadium including an appearance from Morgan Freeman and BTS's Jungkook.

## England v New Zealand: Matt Dawson says 'Marcus Smith kick dead stopped me in my tracks'
 - [https://www.bbc.co.uk/sport/rugby-union/63696370?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/63696370?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 16:30:56+00:00

England fans saw reasons to be cheerful and fearful in the dramatic draw with New Zealand, writes World Cup winner Matt Dawson.

## Pundits on Qatar controversies and 'bizarre' Infantino rant
 - [https://www.bbc.co.uk/sport/av/football/63696118?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63696118?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 16:19:18+00:00

Watch as BBC Sport pundits Alan Shearer, Alex Scott and Ashely Williams have an important conversation surrounding the World Cup in Qatar.

## Australia triumph & 'extraordinary steps' taken - but where next for rugby league?
 - [https://www.bbc.co.uk/sport/rugby-league/63691695?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-league/63691695?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 16:00:47+00:00

Australia's victory over Samoa brought the curtain down on the World Cup - but what's the future for international rugby league?

## World Cup 2022: Gareth Bale ready for 'historic' Wales opener v USA
 - [https://www.bbc.co.uk/sport/football/63603389?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63603389?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 16:00:41+00:00

Gareth Bale is ready to lead Wales in a "massive piece of history" when he captains them in their first World Cup match for 64 years on Monday.

## Zaporizhzhia shelling: Explosions at occupied nuclear site in Ukraine
 - [https://www.bbc.co.uk/news/world-europe-63694763?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63694763?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 15:53:30+00:00

The head of the nuclear watchdog issues an urgent plea after new blasts near the Zaporizhzhia plant.

## What is loss and damage and will rich nations pay for climate change?
 - [https://www.bbc.co.uk/news/science-environment-63478446?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-63478446?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 14:56:50+00:00

In a landmark deal, richer nations agree to give money to developing nations facing climate change.

## Chelsea 3-0 Tottenham: Manager Emma Hayes returns as Blues go top of WSL
 - [https://www.bbc.co.uk/sport/football/63612798?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63612798?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 14:56:23+00:00

Chelsea mark the return of manager Emma Hayes and a record home crowd by beating Tottenham 3-0 at Stamford Bridge.

## Abu Dhabi Grand Prix: Max Verstappen wins as Sebastian Vettel scores points in final race
 - [https://www.bbc.co.uk/sport/formula1/63691532?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/63691532?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 14:36:52+00:00

Red Bull's Max Verstappen wins the final race of the season in Abu Dhabi as Ferrari's Charles Leclerc beats Sergio Perez to secure second in the championship.

## World Cup 2022: Joe Allen ruled out of Wales opener against United States
 - [https://www.bbc.co.uk/sport/football/63695407?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63695407?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 14:15:08+00:00

Wales midfielder Joe Allen is out of Monday's World Cup opener against the United States with a hamstring injury.

## World Cup 2022: How Wales can start 'dream' World Cup with a win
 - [https://www.bbc.co.uk/sport/football/63680715?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63680715?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 14:11:03+00:00

Former Wales defender and BBC pundit Danny Gabbidon on how Rob Page's side can start their first World Cup for 64 years by beating the United States.

## Gwent Police: New messages reveal more misconduct allegations
 - [https://www.bbc.co.uk/news/uk-wales-63689022?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-63689022?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 13:47:08+00:00

The messages include Jimmy Savile jokes, a video of a woman stripping, and leaked nude images.

## Jeremy Hunt has no plan for growth, says CBI boss
 - [https://www.bbc.co.uk/news/business-63694717?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63694717?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 13:35:43+00:00

Tony Danker tells the BBC the Autumn Statement will tackle inflation but won't revive growth.

## Church plans vigil for woman missing in River Don
 - [https://www.bbc.co.uk/news/uk-scotland-north-east-orkney-shetland-63694148?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-north-east-orkney-shetland-63694148?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 13:32:46+00:00

Police confirm the search has entered its third day at Monymusk as the local community gathers in hope.

## Ukraine war: We will rebuild, vows mayor of flattened Mariupol
 - [https://www.bbc.co.uk/news/world-europe-63694707?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63694707?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 12:55:26+00:00

The key city is occupied by Russia - but the exiled Ukrainian mayor is still making plans.

## Health Secretary Steve Barclay defends delay to social care cap
 - [https://www.bbc.co.uk/news/uk-politics-63693931?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63693931?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 11:52:50+00:00

Steve Barclay says the delay is a "difficult decision" but will allow more funding for social care.

## COP27: Climate costs deal struck but no fossil fuel progress
 - [https://www.bbc.co.uk/news/science-environment-63677466?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-63677466?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 11:45:06+00:00

Rich nations will pay climate damages, but the final deal does not cut fossil fuels further.

## Club Q Colorado shooting: Five dead after attack at nightclub
 - [https://www.bbc.co.uk/news/world-us-canada-63693310?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-63693310?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 11:41:16+00:00

The Club Q nightclub in Colorado Springs thanked customers who subdued the gunman on Saturday.

## Met Police passes file on cash-for-honours allegations to prosecutors
 - [https://www.bbc.co.uk/news/uk-england-london-63690651?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-63690651?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 10:38:45+00:00

It has been alleged a donor to one of the King's charities was offered help securing a knighthood.

## Climate change: Five key takeaways from COP27
 - [https://www.bbc.co.uk/news/science-environment-63693738?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-63693738?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 10:26:26+00:00

The biggest win on climate since the Paris Agreement in 2015... or the biggest loss?

## World Cup 2022: Rio Ferdinand answers your World Cup questions
 - [https://www.bbc.co.uk/sport/av/football/63691289?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63691289?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 10:00:26+00:00

BBC Sport pundit Rio Ferdinand answers questions from our followers about the World Cup, England and whether he's still got it.

## Cambridge: Three arrested after 'targeted' teenager stab death
 - [https://www.bbc.co.uk/news/uk-england-cambridgeshire-63693336?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cambridgeshire-63693336?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 09:51:53+00:00

Three teenagers are arrested after a 17-year-old dies in a "targeted attack" in Cambridge.

## World Cup 2022: Can you name all the players in the BBC opening titles?
 - [https://www.bbc.co.uk/sport/football/63685169?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63685169?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 09:19:43+00:00

The BBC titles for the World Cup features 61 individual players. But how many of them can you name against the clock?

## World Superbikes: Eugene Laverty crashes in final race of career
 - [https://www.bbc.co.uk/sport/northern-ireland/63693626?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/northern-ireland/63693626?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 09:13:54+00:00

Eugene Laverty is taken to a Melbourne hospital by helicopter after crashing during the final race of his World Superbike career.

## Turkey Kurdish raids: Operation Claw-Sword targets militant bases
 - [https://www.bbc.co.uk/news/world-middle-east-63693308?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-63693308?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 09:05:11+00:00

Operation Claw-Sword targeted sites in Syria and Iraq a week after a deadly bombing in Istanbul.

## Singer Maluma walks out of Qatar interview
 - [https://www.bbc.co.uk/news/world-middle-east-63693408?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-63693408?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 08:05:51+00:00

The Colombian star, who features on the World Cup anthem, was asked about human rights issues.

## Labour would abolish the House of Lords
 - [https://www.bbc.co.uk/news/uk-politics-63692981?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63692981?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 07:38:19+00:00

The House would be replaced with a "new, reformed upper chamber", the BBC is told.

## World Cup 2022: How Qatar built a team 'ready to dazzle the world'
 - [https://www.bbc.co.uk/sport/football/63490589?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63490589?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 06:41:22+00:00

Qatar's national team is aiming to 'dazzle the world' at this year's World Cup, with the hosts hoping that plans put in place long before they were awarded the tournament pay off.

## Will you be allowed to watch the World Cup at work?
 - [https://www.bbc.co.uk/news/business-63420545?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63420545?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 06:34:36+00:00

Bosses have to decide whether to get behind the controversial World Cup.

## World Cup: BBC Analysis editor Ros Atkins looks at the controversies around Qatar 2022
 - [https://www.bbc.co.uk/sport/av/football/63689011?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63689011?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 06:01:06+00:00

BBC Analysis editor Ros Atkins looks at how Qatar won the World Cup, as well as the human rights and environmental issues surrounding the tournament.

## World Cup 2022: Inside Qatar's £175-a-night fan village
 - [https://www.bbc.co.uk/sport/football/63690765?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63690765?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 05:56:32+00:00

BBC Sport's Nesta McGregor visits Qatar's £175-a-night tented fan village to find out what supporters think of the experience.

## World Cup 2022: Spending the night at Qatar's £175-a-night fan village
 - [https://www.bbc.co.uk/sport/av/football/63691286?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63691286?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 05:55:01+00:00

BBC Sport's Nesta McGregor spends the night at the Qetaifan Island Fan Village just north of Doha, where football fans are arriving for the 2022 World Cup in Qatar.

## Awaab Ishak: Councils put 'on notice' following toddler's mould death
 - [https://www.bbc.co.uk/news/uk-63691578?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63691578?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 04:46:16+00:00

The housing secretary tells providers to improve conditions after Awaab Ishak's death due to mould in his home.

## Musk reinstates Trump's Twitter account
 - [https://www.bbc.co.uk/news/world-us-canada-63692369?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-63692369?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 03:06:01+00:00

The ban against the ex-US president is lifted, but Trump says he sees no reason to return.

## The Papers: 'Come on you Lions' and Fifa boss speech 'outrage'
 - [https://www.bbc.co.uk/news/blogs-the-papers-63691816?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-63691816?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 00:24:01+00:00

Plenty of stories on Sunday's front pages look forward to the World Cup finally kicking off in Qatar.

## World Cup music: Why official singles went out of fashion
 - [https://www.bbc.co.uk/news/entertainment-arts-63668308?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63668308?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 00:22:05+00:00

While Three Lions still gets played every tournament, the days of squad singles are long gone.

## Talking therapy: How ice cream is helping people discuss difficult topics
 - [https://www.bbc.co.uk/news/uk-63503970?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63503970?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 00:14:57+00:00

Artist Annie Nicholson's work has centred around grief since she lost family members in a tragic accident.

## Safe haven laws and the surrendered infants in US
 - [https://www.bbc.co.uk/news/world-us-canada-63387906?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-63387906?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 00:12:59+00:00

Michelle told no-one she was pregnant. So when she gave birth by the roadside, she did something she came to regret.

## Jang Jung Hyuck: ‘Compared to escaping North Korea, the fights feel like nothing’
 - [https://www.bbc.co.uk/news/world-asia-63644829?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-63644829?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-11-20 00:02:51+00:00

Jang Jung Hyuck used kickboxing to cope with the trauma of escaping North Korea.


# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## For rivals Japan and China, the new space race is about removing junk
 - [https://www.washingtonpost.com/world/2022/11/20/japan-china-space-junk-removal-compete/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/world/2022/11/20/japan-china-space-junk-removal-compete/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-11-20 02:00:24+00:00

In a universe full of litter, Japan aims to become the first country to develop the technology and rules for space debris mitigation.


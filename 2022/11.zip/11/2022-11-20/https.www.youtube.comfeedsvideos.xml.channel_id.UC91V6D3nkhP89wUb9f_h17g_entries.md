# Source:MeatCanyon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC91V6D3nkhP89wUb9f_h17g, language:en-US

## Elons Blue Check Mark
 - [https://www.youtube.com/watch?v=V8H2ETMpRFw](https://www.youtube.com/watch?v=V8H2ETMpRFw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC91V6D3nkhP89wUb9f_h17g
 - date published: 2022-11-20 18:00:21+00:00

Thanks for watching!

Animators:
Jerb: https://twitter.com/jerbjpg?s=20


Vudujin: https://twitter.com/Vudujin


DublyMike: https://twitter.com/dublymike?s=20


Leo "Awez" Chenevert - https://mobile.twitter.com/aweztube


Storyboard:
Jake Smith: https://www.instagram.com/dead_gremlin_comix/

Creature Design:
Dan Peacock: https://www.instagram.com/dan.a.peacock/?hl=en


BG Artist:
Kuo Yang: https://www.artstation.com/kuoyang


Davecavedraws: https://www.instagram.com/davecavedraws/


COMP FX:
Molly Wright: https://www.youtube.com/c/wollymight
YouTube

Audio Design:
https://twitter.com/imadeasong?s=20

Composer:
Alex Walker Smith: https://www.youtube.com/alexwalkersmith


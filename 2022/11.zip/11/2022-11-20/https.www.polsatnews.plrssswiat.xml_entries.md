# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Niemcy zaoferowali Polsce systemy obrony przeciwlotniczej Patriot
 - [https://www.polsatnews.pl/wiadomosc/2022-11-20/niemcy-zaoferowali-polsce-systemy-obrony-przeciwlotniczej-patriot/](https://www.polsatnews.pl/wiadomosc/2022-11-20/niemcy-zaoferowali-polsce-systemy-obrony-przeciwlotniczej-patriot/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-20 21:47:00+00:00

Niemcy zaoferowali Polsce systemy obrony przeciwlotniczej Patriot - przekazała minister obrony Niemiec Christine Lambrecht. Jak powiadomiła, system Patriot miałby pomóc w ochronie przestrzeni powietrznej przed zbłądzonymi rakietami ze wschodu.

## Wielka Brytania. 17-latek i dwóch 14-latków aresztowanych pod zarzutem morderstwa
 - [https://www.polsatnews.pl/wiadomosc/2022-11-20/wielka-brytania-17-latek-i-dwoch-14-latkow-aresztowanych-pod-zarzutem-morderstwa/](https://www.polsatnews.pl/wiadomosc/2022-11-20/wielka-brytania-17-latek-i-dwoch-14-latkow-aresztowanych-pod-zarzutem-morderstwa/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-20 21:13:00+00:00

Trzech nastolatków zostało aresztowanych pod zarzutem morderstwa, do którego miało dojść w Cambridge. Wśród zatrzymanych jest dwóch 14-latków i 17-latek. Ofiarą ataku nożem był 17-letni chłopiec.

## Katar. Aktor Morgan Freeman i niepełnosprawny Ghanim Al-Muftah na ceremonii otwarcia mundialu
 - [https://www.polsatnews.pl/wiadomosc/2022-11-20/katar-aktor-morgan-freeman-i-niepelnosprawny-ghanim-al-muftah-na-ceremonii-otwarcia-mundialu/](https://www.polsatnews.pl/wiadomosc/2022-11-20/katar-aktor-morgan-freeman-i-niepelnosprawny-ghanim-al-muftah-na-ceremonii-otwarcia-mundialu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-20 20:56:00+00:00

Piłka nożna jednoczy narody i ich zamiłowanie do pięknej gry - powiedział w czasie ceremonii otwarcia Mistrzostw Świata w piłce nożnej Morgan Freeman, amerykański aktor prowadzący uroczystość rozpoczęcia rozgrywek. Wraz z nim na scenie był niepełnosprawny katarski ambasador mistrzostw Ghanim Al-Muftah.

## Ukraina: Pies Patron otrzymał honorowy tytuł od UNICEF
 - [https://www.polsatnews.pl/wiadomosc/2022-11-20/ukraina-pies-patron-otrzymal-honorowy-tytul-od-unicef/](https://www.polsatnews.pl/wiadomosc/2022-11-20/ukraina-pies-patron-otrzymal-honorowy-tytul-od-unicef/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-20 19:33:00+00:00

UNICEF przyznał Patronowi honorowy status psa Dobrej Woli oraz podpisał memorandum o współpracy. Pies Patron wykonuje zadania dla Państwowej Służby Ukrainy ds. Sytuacji Nadzwyczajnych. Po rozpoczęciu wojny w Ukrainie zyskał międzynarodową sławę dzięki pracy podczas wykrywania min lądowych.

## Turcja. Ataki lotnicze na kurdyjskie wsie. Ankara wini Kurdów za wybuch w Stambule
 - [https://www.polsatnews.pl/wiadomosc/2022-11-20/turcja-ataki-lotnicze-na-kurdyjskie-bazy-ankara-wini-kurdow-za-wybuch-w-stambule/](https://www.polsatnews.pl/wiadomosc/2022-11-20/turcja-ataki-lotnicze-na-kurdyjskie-bazy-ankara-wini-kurdow-za-wybuch-w-stambule/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-20 18:56:00+00:00

Turcja rozpoczęła w niedzielę naloty na północne regiony Syrii i Iraku - poinformowało tego dnia tureckie Ministerstwo Obrony. Ataki są wymierzone na zamieszkałe przez Kurdów miejscowości. Ankara obwinia Kurdów za zeszłotygodniowy atak bombowy w Stambule.

## Mobilizacja w Rosji. Pokazowe zatrzymanie żołnierzy. Mają odpowiedzieć za nieprzestrzeganie rozkazu
 - [https://www.polsatnews.pl/wiadomosc/2022-11-20/mobilizacja-w-rosji-pokazowe-zatrzymanie-zolnierzy-maja-odpowiedziec-za-nieprzestrzeganie-nakazu/](https://www.polsatnews.pl/wiadomosc/2022-11-20/mobilizacja-w-rosji-pokazowe-zatrzymanie-zolnierzy-maja-odpowiedziec-za-nieprzestrzeganie-nakazu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-20 17:50:00+00:00

W Biełgorodzie zatrzymano dwóch poborowych, wobec których wszczęto postępowanie karne - można zobaczyć na pokazowym nagraniu, które pojawiło się w sieci. Żołnierze mają odpowiedzieć za nieprzestrzeganie rozkazu wydanego przez przełożonego. Od rozpoczęcia wojny w Ukrainie Rosjanie niejednokrotnie tworzyli propagandowe nagrania, w których m.in. powielano prokremlowską narrację.

## Prezydent Turcji: Cena za izolację Rosji będzie nieskończona. Już płacą ją Europa i Polska
 - [https://www.polsatnews.pl/wiadomosc/2022-11-20/prezydent-turcji-cena-za-izolacje-rosji-bedzie-nieskonczona-juz-placa-ja-europa-i-polska/](https://www.polsatnews.pl/wiadomosc/2022-11-20/prezydent-turcji-cena-za-izolacje-rosji-bedzie-nieskonczona-juz-placa-ja-europa-i-polska/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-20 16:16:00+00:00

Polityka izolacji Rosji doprowadzi do poważnych konsekwencji dla krajów europejskich - powiedział prezydent Turcji Recep Tayyip Erdogan, cytowany przez prokremlowską agencję Ria Nowosti. Jak dodał, cenę ponosić będzie także Polska. Prezydent Turcji mówił również o drodze do pokoju w Ukrainie.

## Katar. Rozpoczęły się Mistrzostwa Świata w Piłce Nożnej. Poza sportem, kontrowersje
 - [https://www.polsatnews.pl/wiadomosc/2022-11-20/katar-rozpoczely-sie-mistrzostwa-swiata-w-pilce-noznej-mezczyzn-poza-sportem-kontrowersje/](https://www.polsatnews.pl/wiadomosc/2022-11-20/katar-rozpoczely-sie-mistrzostwa-swiata-w-pilce-noznej-mezczyzn-poza-sportem-kontrowersje/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-20 15:54:00+00:00

Od wystawnej ceremonii otwarcia poprowadzonej przez amerykańskiego aktora Morgana Freemana rozpoczęły się 22. Mistrzostwa Świata w Piłce Nożnej Mężczyzn. Na sportowe święto cieniem kładą się kontrowersje dotyczące organizacji imprezy i wyboru gospodarza.

## Rosja. Kłęby dymu nad stolicą. Pożar w centrum Moskwy
 - [https://www.polsatnews.pl/wiadomosc/2022-11-20/rosja-kleby-dymu-nad-stolica-pozar-w-centrum-moskwy/](https://www.polsatnews.pl/wiadomosc/2022-11-20/rosja-kleby-dymu-nad-stolica-pozar-w-centrum-moskwy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-20 15:01:00+00:00

W centrum Moskwy w niedziele wybuchł pożar. Ogień pojawił się w dwupiętrowym budynku. Jak powiadomił niezależny rosyjski portal Meduza, z budynku ewakuowano siedem osób, natomiast dwie znajdują się w środku.

## Spotkanie Mateusza Morawieckiego z premier Finlandii. Prośba do Węgier
 - [https://www.polsatnews.pl/wiadomosc/2022-11-20/spotkanie-mateusza-morawieckiego-z-premier-finlandii-prosba-do-wegier/](https://www.polsatnews.pl/wiadomosc/2022-11-20/spotkanie-mateusza-morawieckiego-z-premier-finlandii-prosba-do-wegier/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-20 14:51:00+00:00

Za kilka dni pan premier Viktor Orban i ja spotykamy się w formacie Grupy Wyszehradzkiej. Jestem pewien, że razem z naszymi przyjaciółmi ze Słowacji i Czech poprosimy premiera Węgier o szybką ratyfikację dokumentów dla Szwecji i Finlandii, ponieważ ma to krytyczne znaczenia dla wschodniej flanki naszego regionu - powiedział premier Mateusz Morawiecki po spotkaniu z premier Finlandii.

## Iran. Od początku antyrządowych protestów zginęło 58 dzieci
 - [https://www.polsatnews.pl/wiadomosc/2022-11-20/iran-od-poczatku-antyrzadowych-protestow-zginac-mialo-58-dzieci/](https://www.polsatnews.pl/wiadomosc/2022-11-20/iran-od-poczatku-antyrzadowych-protestow-zginac-mialo-58-dzieci/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-20 14:21:00+00:00

58 dzieci poniżej 18. roku życia straciło życie podczas antyrządowych protestów w Iranie - informuje The Guardian, powołując się na tamtejsze organizacje zajmujące się prawami człowieka. Pięcioro dzieci miało zginąć tylko w minionym tygodniu.

## Rosja: Erupcja wulkanu na Kamczatce. Kolejny może wybuchnąć w każdej chwili
 - [https://www.polsatnews.pl/wiadomosc/2022-11-20/rosja-erupcja-wulkanu-na-kamczatce-kolejny-wulkan-na-polwyspie-tez-moze-w-kazdej-chwili-wybuchnac/](https://www.polsatnews.pl/wiadomosc/2022-11-20/rosja-erupcja-wulkanu-na-kamczatce-kolejny-wulkan-na-polwyspie-tez-moze-w-kazdej-chwili-wybuchnac/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-20 13:24:00+00:00

Na Kamczatce jednocześnie obudziły się dwa wulkany. Rozpoczęła się erupcja Kluczewskiej Sopki, zaś Szywiełucz może w każdej chwili wybuchnąć. Grozi nam potężna erupcja - ostrzegają rosyjscy eksperci.

## USA. Strzelanina w Kolorado. Nie żyje 5 osób, 18 jest rannych
 - [https://www.polsatnews.pl/wiadomosc/2022-11-20/usa-strzelanina-w-kolorado-nie-zyje-5-osob-18-jest-rannych/](https://www.polsatnews.pl/wiadomosc/2022-11-20/usa-strzelanina-w-kolorado-nie-zyje-5-osob-18-jest-rannych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-20 12:43:00+00:00

Pięć osób nie żyje, a 18 zostało rannych w wyniku strzelaniny w klubie nocnym w Colorado Springs w amerykańskim stanie Kolorado. Policja otrzymała informację o zdarzeniu przed północą z soboty na niedzielę czasu lokalnego. Sprawca został zatrzymany i przewieziony do szpitala. Na razie nie wiadomo, jakie były jego motywy.

## Ukraina. Potężne eksplozje na terenie Zaporoskiej Elektrowni Jądrowej. Jest komunikat MAEA
 - [https://www.polsatnews.pl/wiadomosc/2022-11-20/ukraina-potezne-eksplozje-na-terenie-zaporoskiej-elektrowni-jadrowej/](https://www.polsatnews.pl/wiadomosc/2022-11-20/ukraina-potezne-eksplozje-na-terenie-zaporoskiej-elektrowni-jadrowej/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-20 12:25:00+00:00

W sobotę wieczorem i w niedzielę rano na terenie oraz w najbliższych okolicach okupowanej przez rosyjskie wojska Zaporoskiej Elektrowni Atomowej miało miejsce kilkanaście silnych wybuchów - wynika z komunikatu opublikowanego przez Międzynarodową Agencję Energii Atomowej (MAEA).

## "Lud przemówił". Musk odblokował konto Trumpa. Były prezydent USA nie chce wracać na Twittera
 - [https://www.polsatnews.pl/wiadomosc/2022-11-20/lud-przemowil-musk-odblokowal-konto-trumpa-byly-prezydent-usa-nie-chce-wracac-na-twittera/](https://www.polsatnews.pl/wiadomosc/2022-11-20/lud-przemowil-musk-odblokowal-konto-trumpa-byly-prezydent-usa-nie-chce-wracac-na-twittera/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-20 10:03:00+00:00

W zorganizowanej przez Elona Muska ankiecie większość użytkowników opowiedziała się za odblokowaniem konta Donalda Trumpa. Jego profil ponownie jest widoczny na Twitterze. Sam były prezydent USA stwierdził, że nie jest zainteresowany powrotem do aktywności na tej platformie. - Nie widzę ku temu żadnego powodu - mówił.

## Ukraina: Na wyzwolonych terenach znaleziono ponad 700 ciał. Większość to cywile
 - [https://www.polsatnews.pl/wiadomosc/2022-11-20/ukraina-na-wyzwolonych-terenach-znaleziono-ponad-700-cial-wiekszosc-to-cywile/](https://www.polsatnews.pl/wiadomosc/2022-11-20/ukraina-na-wyzwolonych-terenach-znaleziono-ponad-700-cial-wiekszosc-to-cywile/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-20 09:06:00+00:00

Prokurator generalny Ukrainy poinformował, że na terenach wyzwolonych spod rosyjskiej okupacji znaleziono ponad 700 ciał zabitych, z czego prawie 90 proc. stanowią cywile. Odkryto również ponad 20 miejsc, w których Rosjanie nielegalnie przetrzymywali i torturowali Ukraińców.

## Peru. Ćwiczyli akcję ratunkową na nowym pasie startowym. Spowodowali katastrofę
 - [https://www.polsatnews.pl/wiadomosc/2022-11-20/peru-cwiczyli-akcje-ratunkowa-na-nowym-pasie-startowym-spowodowali-katastrofe/](https://www.polsatnews.pl/wiadomosc/2022-11-20/peru-cwiczyli-akcje-ratunkowa-na-nowym-pasie-startowym-spowodowali-katastrofe/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-11-20 07:20:00+00:00

Nowe nagranie katastrofy pasażerskiego samolotu Airbus A320neo na międzynarodowym lotnisku w Limie, stolicy Peru. Trasę startującej maszyny przeciął wóz strażacki. Zginęło dwóch strażaków, samolot stracił silnik i podwozie, a następnie zapalił się. Rannych zostało kilkadziesiąt osób, które były na pokładzie. Śledztwo ma wyjaśnić, czy pojazd gaśniczy miał autoryzację do wjazdu na pas startowy.


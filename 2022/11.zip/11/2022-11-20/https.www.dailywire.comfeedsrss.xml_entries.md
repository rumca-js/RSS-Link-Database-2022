# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## ‘I’m Sick Of This S**t’: Lori Lightfoot Rages Over Colorado Shooting, Gets Dragged Because She’s Mayor Of Chicago
 - [https://www.dailywire.com/news/im-sick-of-this-st-lori-lightfoot-rages-over-colorado-shooting-gets-dragged-because-shes-mayor-of-chicago](https://www.dailywire.com/news/im-sick-of-this-st-lori-lightfoot-rages-over-colorado-shooting-gets-dragged-because-shes-mayor-of-chicago)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-20 21:36:50+00:00

Chicago&#8217;s Democratic Mayor Lori Lightfoot voiced her outrage in the wake of Sunday morning&#8217;s shooting in Colorado Springs — but then took a beating on Twitter when critics pointed out the fact that she presides over a city where shootings are an everyday thing. Lightfoot began by sharing a tweet from the Associated Press announcing ...

## ‘You’re Letting Him Get Away With Murder’: Jake Tapper Torches Biden For Giving Saudi Prince A Pass
 - [https://www.dailywire.com/news/youre-letting-him-get-away-with-murder-jake-tapper-torches-biden-for-giving-saudi-prince-a-pass](https://www.dailywire.com/news/youre-letting-him-get-away-with-murder-jake-tapper-torches-biden-for-giving-saudi-prince-a-pass)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-20 20:24:39+00:00

CNN anchor Jake Tapper laid into President Joe Biden on Sunday morning, lambasting him for allowing Saudi Prince Mohammed bin Salman to claim immunity in the murder of The Washington Post journalist Jamal Khashoggi. Tapper concluded his Sunday broadcast of &#8220;State of the Union&#8221; with a monologue addressing the fact that the Biden administration had ...

## Twitter Reinstates Undercover Journalism Enterprise Project Veritas
 - [https://www.dailywire.com/news/twitter-reinstates-undercover-journalism-enterprise-project-veritas](https://www.dailywire.com/news/twitter-reinstates-undercover-journalism-enterprise-project-veritas)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-20 19:00:20+00:00

Twitter reinstated the non-profit investigative journalism enterprise Project Veritas on Sunday, making it the latest account to have access again to the social media platform under its new owner Elon Musk. Officials restricted Project Veritas in 2021 for allegedly posting a video showing Facebook Vice President Guy Rosen admitting the social media platform built a ...

## Paul Ryan Calls Himself A ‘Never-Again-Trumper,’ Says It Will Be ‘Really Hard’ To Govern With Thin Majority
 - [https://www.dailywire.com/news/paul-ryan-calls-himself-a-never-again-trumper-says-it-will-be-really-hard-to-govern-with-thin-majority](https://www.dailywire.com/news/paul-ryan-calls-himself-a-never-again-trumper-says-it-will-be-really-hard-to-govern-with-thin-majority)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-20 16:48:42+00:00

Former Republican Speaker of the House Paul Ryan called himself a “never-again-Trumper” and blamed former President Donald Trump for the GOP&#8217;s lackluster performance in the midterm elections. Appearing on ABC’s &#8220;This Week&#8221; with co-anchor Jonathon Karl on Sunday, Ryan reflected on his tenure as speaker and his relationship with then-President Trump. He also warned that ...

## Original Green Power Ranger Jason Frank Dead At 49
 - [https://www.dailywire.com/news/original-green-power-ranger-jason-frank-dead-at-49](https://www.dailywire.com/news/original-green-power-ranger-jason-frank-dead-at-49)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-20 16:18:42+00:00

Jason David Frank, best known for portraying Tommy Oliver, the original Green and White Ranger on Mighty Morphin Power Rangers, died at 49 years old in Texas, a representative confirmed Sunday to media outlets. &#8220;Please respect the privacy of his family and friends during this horrible time as we come to terms with the loss ...

## CBS News Resumes Twitter Activity Less Than 48 Hours After Pausing ‘Out Of An Abundance Of Caution’
 - [https://www.dailywire.com/news/cbs-news-resumes-twitter-activity-less-than-48-hours-after-pausing-out-of-an-abundance-of-caution](https://www.dailywire.com/news/cbs-news-resumes-twitter-activity-less-than-48-hours-after-pausing-out-of-an-abundance-of-caution)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-20 14:29:10+00:00

CBS News resumed posting on Twitter Sunday after announcing the network would pause its activity on the platform two days earlier &#8220;out of an abundance of caution&#8221; as the social media company moves through an intense period of change under its new owner Elon Musk. &#8220;After pausing for much of the weekend to assess the ...

## Persecution Of Christians Rising In At Least 18 Countries Of ‘Particular Concern,’ Report Finds
 - [https://www.dailywire.com/news/persecution-of-christians-rising-in-at-least-18-countries-of-particular-concern-report-finds](https://www.dailywire.com/news/persecution-of-christians-rising-in-at-least-18-countries-of-particular-concern-report-finds)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-20 14:14:15+00:00

The persecution of Christians in at least 18 countries throughout the world has been increasing, according to a new report.  The report, titled “Persecuted and Forgotten? A Report On Christians Oppressed For Their Faith 2020-22,” was released on November 16 by the Catholic group Aid to the Church In Need. It examined “human rights violations” ...

## Trump Sees No Reason To Return To Twitter As Musk Allows Him Back On Platform
 - [https://www.dailywire.com/news/trump-sees-no-reason-to-return-to-twitter-as-musk-allows-him-back-on-platform](https://www.dailywire.com/news/trump-sees-no-reason-to-return-to-twitter-as-musk-allows-him-back-on-platform)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-20 10:02:08+00:00

Former President Donald Trump said he did not &#8220;see any reason&#8221; to return to Twitter shortly before new CEO Elon Musk reinstated his account on the social media platform on Saturday. Trump made the remarks during a brief appearance at the annual leadership meeting of the Republican Jewish Coalition when Matt Brooks, CEO of the ...

## ‘There Is No Substitute For Victory’: Ron DeSantis Lays Out The Roadmap For Republicans To Dominate
 - [https://www.dailywire.com/news/there-is-no-substitute-for-victory-ron-desantis-lays-out-the-roadmap-for-republicans-to-dominate](https://www.dailywire.com/news/there-is-no-substitute-for-victory-ron-desantis-lays-out-the-roadmap-for-republicans-to-dominate)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-20 09:58:09+00:00

Florida Governor Ron DeSantis (R) laid out the roadmap this weekend for Republicans to dominate politically in the coming years following Republicans&#8217; blowout wins earlier this month in the midterm elections. DeSantis made the remarks during a 25-minute speech on Saturday at the annual leadership meeting of the Republican Jewish Coalition. The governor, who numerous recent ...

## Leftists Rage Over Musk Reinstating Trump’s Account On Twitter: ‘This Is Bulls***’
 - [https://www.dailywire.com/news/leftists-rage-over-musk-reinstating-trumps-account-on-twitter-this-is-bulls](https://www.dailywire.com/news/leftists-rage-over-musk-reinstating-trumps-account-on-twitter-this-is-bulls)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-20 09:04:43+00:00

Leftists raged Saturday evening after Twitter CEO Elon Musk reinstated former President Donald Trump’s Twitter account despite Trump repeatedly stating that he would not use the platform again. The announcement from Musk comes after more than 15 million people voted in a non-scientific poll that he posted to his Twitter account asking if Trump should be ...

## Arizona Gov. Election In Doubt As AG Demands Full Report On ‘Myriad Problems’ In Maricopa Voting
 - [https://www.dailywire.com/news/arizona-gov-election-in-doubt-as-ag-demands-full-report-on-myriad-problems-in-maricopa-voting](https://www.dailywire.com/news/arizona-gov-election-in-doubt-as-ag-demands-full-report-on-myriad-problems-in-maricopa-voting)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-20 08:43:28+00:00

Arizona’s attorney general&#8217;s office ordered Maricopa County officials to submit a report on its botched handling of the November 8 election that led to Democratic gubernatorial candidate Katie Hobbs’ apparent victory over Republican Kari Lake, saying answers are needed before the election can be certified. In a letter from the election integrity unit of Attorney ...

## At Least 5 Dead, 18 Wounded In Mass Shooting At Colorado Gay Nightclub
 - [https://www.dailywire.com/news/at-least-5-dead-18-wounded-in-mass-shooting-at-colorado-gay-nightclub-white_check_mark-eyes-heavy_plus_sign](https://www.dailywire.com/news/at-least-5-dead-18-wounded-in-mass-shooting-at-colorado-gay-nightclub-white_check_mark-eyes-heavy_plus_sign)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-11-20 07:23:48+00:00

A gunman opened fire inside a gay nightclub in Colorado just before midnight Saturday, killing five people and wounding at least 18, authorities said. The carnage occurred inside Club Q in Colorado Springs, which describes itself online as an “adult-oriented gay and lesbian nightclub hosting theme nights such as karaoke, drag shows &amp; DJs.” The ...


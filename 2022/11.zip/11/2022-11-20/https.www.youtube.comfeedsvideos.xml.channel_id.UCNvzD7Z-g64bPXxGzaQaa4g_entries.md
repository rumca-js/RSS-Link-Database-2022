# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Evil West - Before You Buy
 - [https://www.youtube.com/watch?v=7yfsMQL0CpQ](https://www.youtube.com/watch?v=7yfsMQL0CpQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-11-21 00:00:00+00:00

Evil West (PC, PS5, PS4, Xbox Series X/S/One) is a simple action adventure game with a wild west horror spin. How is it? Let's talk.
Subscribe for more: http://youtube.com/gameranxtv ▼▼

Buy Evil West: https://amzn.to/3U1nWlr


Watch more 'Before You Buy': https://bit.ly/2kfdxI6

#evilwest

## 10 UNREALISTIC Gameplay Mechanics That DON'T SUCK
 - [https://www.youtube.com/watch?v=7qdZoYoypfk](https://www.youtube.com/watch?v=7qdZoYoypfk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-11-20 00:00:00+00:00

Many games have unrealistic elements that just make things so much more fun.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:40 Number 10
2:10 Number 9
3:36 Number 8
4:56 Number 7
6:00 Number 6
7:05 Number 5
8:30 Number 4
9:56 Number 3
12:10 Number 2
13:29 Number 1
15:00 BONUS


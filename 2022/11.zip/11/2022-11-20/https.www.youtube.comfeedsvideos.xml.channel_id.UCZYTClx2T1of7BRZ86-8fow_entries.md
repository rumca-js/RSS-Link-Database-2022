# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## These Primates Communicate With Their Butts
 - [https://www.youtube.com/watch?v=t7_mBpjb1Mg](https://www.youtube.com/watch?v=t7_mBpjb1Mg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-11-21 00:00:00+00:00

This video was sponsored by Guardio. Go to https://guard.io/SciShow for a 7 day free trial. for a 7 day free trial.


This episode is about the birds and the bees and the butts.

Hosted by: Stefan Chin (he/him)

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Matt Curls, Alisa Sherbow, Dr. Melvin Sanicas, Harrison Mills, Adam Brainard, Chris Peters, charles george, Piya Shedden, Alex Hackman, Christopher R, Boucher, Jeffrey Mckishen, Ash, Silas Emrys, Eric Jensen, Kevin Bealer, Jason A Saslow, Tom Mosner, Tomás Lagos González, Jacob, Christoph Schwanke, Sam Lutfi, Bryan Cloer
----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow #science #education
----------

Sources
https://www.nature.com/scitable/knowledge/library/old-world-monkeys-83033815/ 
https://www.sciencedirect.com/science/article/pii/0162309581900200 
https://www.sciencedirect.com/science/article/pii/S000334728471181X 
https://www.sciencedirect.com/science/article/abs/pii/S0003347299911594 
https://www.sciencedirect.com/science/article/abs/pii/S0003347215001190?via%3Dihub 
https://www.science.org/doi/abs/10.1126/science.1087513 
https://www.pnas.org/doi/pdf/10.1073/pnas.1206391109 
https://sites.santafe.edu/~bowles/Dominance/Papers/Albertsetal_paternity.pdf 
https://deepblue.lib.umich.edu/bitstream/handle/2027.42/96030/ekrobert_1.pdf%3Bsequence=1 
https://www.duo.uio.no/bitstream/handle/10852/59376/ERIKSEN-Gry-Anita--Master-thesis--19-Aug-BIO5960.pdf 
https://www.sciencedirect.com/science/article/pii/S0003347274800709 
https://deepblue.lib.umich.edu/bitstream/handle/2027.42/96030/ekrobert_1.pdf;sequence=1 
https://pubmed.ncbi.nlm.nih.gov/11051443/ 
https://www.sciencedirect.com/science/article/pii/B9780123786326000069 
https://youtu.be/uayhhleFczc?t=39 
https://www.sciencedirect.com/science/article/abs/pii/S0003347215001190 
https://academic.oup.com/beheco/article/23/4/699/223123?login=false 
https://brill.com/view/journals/beh/131/1-2/article-p1_1.xml 
https://www.nature.com/articles/35065597

Images

https://www.gettyimages.com
https://www.eurekalert.org/multimedia/631025
https://www.eurekalert.org/multimedia/546815
https://commons.wikimedia.org/wiki/File:GambiaMakasutu057_(12234967265).jpg
https://commons.wikimedia.org/wiki/File:Achtsame_Ber%C3%BChrung_Mantelpaviane_Tiergarten_Worms.JPG
https://en.wikipedia.org/wiki/File:Southern_gelada_(Theropithecus_gelada_obscura)_female_with_baby.jpg
https://commons.wikimedia.org/wiki/File:Hamadryas_baboon.jpg
https://www.eurekalert.org/multimedia/546815
https://www.eurekalert.org/multimedia/631025


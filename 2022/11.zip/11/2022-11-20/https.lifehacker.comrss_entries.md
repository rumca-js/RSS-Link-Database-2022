# Source:Lifehacker, URL:https://lifehacker.com/rss, language:en-US

## Set These Boundaries Before Your Thanksgiving Guests Arrive
 - [https://lifehacker.com/set-these-boundaries-before-your-thanksgiving-guests-ar-1849803471](https://lifehacker.com/set-these-boundaries-before-your-thanksgiving-guests-ar-1849803471)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-20 18:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--r2w5_dZ7--/c_fit,fl_progressive,q_80,w_636/4f192a9aa9810f8d55507d7f44cb693d.jpg" /><p>While there’s no way to guarantee that your Thanksgiving gathering will be 100% conflict-free, setting a few boundaries with your guests ahead of the big dinner can help to at least minimize confrontations and awkward moments. Here are a few examples of topics to discuss and agree on before coming together for the…</p><p><a href="https://lifehacker.com/set-these-boundaries-before-your-thanksgiving-guests-ar-1849803471">Read more...</a></p>

## Sorry, but Your Microwave Needs Maintenance
 - [https://lifehacker.com/sorry-but-your-microwave-needs-maintenance-1849803456](https://lifehacker.com/sorry-but-your-microwave-needs-maintenance-1849803456)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-20 16:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--zNCxY0cu--/c_fit,fl_progressive,q_80,w_636/6f40cf0d91fd3bf9931d9cd8fe45463d.jpg" /><p>It’s easy to forget about our microwave when we’re not using it—especially since many models are compact, tucked into the corners of counters, or mounted above the stove. But, like other kitchen appliances, our microwaves need basic maintenance in order to keep running smoothly. </p><p><a href="https://lifehacker.com/sorry-but-your-microwave-needs-maintenance-1849803456">Read more...</a></p>

## The Best Black Friday Food Deals and Freebies
 - [https://lifehacker.com/the-best-black-friday-food-deals-and-freebies-1849803447](https://lifehacker.com/the-best-black-friday-food-deals-and-freebies-1849803447)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-11-20 14:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--oCtQ4tkg--/c_fit,fl_progressive,q_80,w_636/352cf12a2aeeb8d80965ac02a32657a0.jpg" /><p>Clothes and electronics aren’t the only items marked down on Black Friday: A number of restaurants have also announced a range of deals (some of which include free food) on their meals, snacks, and gift cards.</p><p><a href="https://lifehacker.com/the-best-black-friday-food-deals-and-freebies-1849803447">Read more...</a></p>


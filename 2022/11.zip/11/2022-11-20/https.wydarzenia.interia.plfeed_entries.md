# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Niemieckie media o wycince drzew w Bieszczadach: Czy niedźwiedzie przetrwają?
 - [https://wydarzenia.interia.pl/kraj/news-niemieckie-media-o-wycince-drzew-w-bieszczadach-czy-niedzwie,nId,6423209](https://wydarzenia.interia.pl/kraj/news-niemieckie-media-o-wycince-drzew-w-bieszczadach-czy-niedzwie,nId,6423209)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 21:58:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-niemieckie-media-o-wycince-drzew-w-bieszczadach-czy-niedzwie,nId,6423209"><img align="left" alt="Niemieckie media o wycince drzew w Bieszczadach: Czy niedźwiedzie przetrwają?" src="https://i.iplsc.com/niemieckie-media-o-wycince-drzew-w-bieszczadach-czy-niedzwie/000GDA1VF1VC14KH-C321.jpg" /></a>Ze względu na rosnące ceny drewna, w Europie wycina się więcej lasów. Polska zajmuje w tym procederze czołowe miejsce - alarmuje &quot;Tagesspiegel&quot;. Sytuację pogarsza także zawieszony import z Ukrainy czy z Białorusi. A to nie jedyny problem. W Bieszczadach przeciwko masowej wycince drzew, która zagraża żyjącym tam niedźwiedziom, protestują ekolodzy.</p><br clear="all" />

## Brytyjski historyk: Celem Putina jest "landgrab"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-brytyjski-historyk-celem-putina-jest-landgrab,nId,6423198](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-brytyjski-historyk-celem-putina-jest-landgrab,nId,6423198)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 21:37:19+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-brytyjski-historyk-celem-putina-jest-landgrab,nId,6423198"><img align="left" alt="Brytyjski historyk: Celem Putina jest &quot;landgrab&quot; " src="https://i.iplsc.com/brytyjski-historyk-celem-putina-jest-landgrab/000GDA0WRRMS59X0-C321.jpg" /></a>- Celem Putina jest &quot;landgrab&quot; - zabór ziemi oraz zemsta za rok 1991. - Putin i jego ludzie znajdowali się wówczas na średnim szczeblu służb specjalnych i musieli przyglądać się, jak ich szefowie tracą imperium - mówi w &quot;Spieglu&quot; brytyjski historyk Orlando Figes.</p><br clear="all" />

## Media: Rosjanie próbowali szpiegować Brytyjczyków na Morzu Północnym
 - [https://wydarzenia.interia.pl/zagranica/news-media-rosjanie-probowali-szpiegowac-brytyjczykow-na-morzu-po,nId,6423207](https://wydarzenia.interia.pl/zagranica/news-media-rosjanie-probowali-szpiegowac-brytyjczykow-na-morzu-po,nId,6423207)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 21:34:51+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-media-rosjanie-probowali-szpiegowac-brytyjczykow-na-morzu-po,nId,6423207"><img align="left" alt="Media: Rosjanie próbowali szpiegować Brytyjczyków na Morzu Północnym" src="https://i.iplsc.com/media-rosjanie-probowali-szpiegowac-brytyjczykow-na-morzu-po/000GDA0VQ4EN5NWK-C321.jpg" /></a>Rosyjski okręt próbował szpiegować przeprowadzane na Morzu Północnym działania. Brytyjska marynarka wojenna prowadziła wówczas testy z dronami morskimi, w tym z autonomicznymi wyrzutniami pocisków - podają brytyjskie media. Rosjan odstraszyły wysłane na miejsce brytyjskie okręty.</p><br clear="all" />

## Spór o eskortę prezesa PiS. "Dziesiątki radiowozów i policjantów"
 - [https://wydarzenia.interia.pl/kraj/news-spor-o-eskorte-prezesa-pis-dziesiatki-radiowozow-i-policjant,nId,6423197](https://wydarzenia.interia.pl/kraj/news-spor-o-eskorte-prezesa-pis-dziesiatki-radiowozow-i-policjant,nId,6423197)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 21:14:42+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-spor-o-eskorte-prezesa-pis-dziesiatki-radiowozow-i-policjant,nId,6423197"><img align="left" alt="Spór o eskortę prezesa PiS. &quot;Dziesiątki radiowozów i policjantów&quot; " src="https://i.iplsc.com/spor-o-eskorte-prezesa-pis-dziesiatki-radiowozow-i-policjant/000GD9Y2ILFCHFO3-C321.jpg" /></a>Jarosław Kaczyński kontynuuje objazd po kraju. W niedzielę prezes PiS był w Gliwicach. W pobliżu miejsca, gdzie odbywało się spotkanie z mieszkańcami obecne były liczne zastępy policji. - Dziesiątki radiowozów i policjantów. Państwo PiS w pigułce - skrytykował Borys Budka. Na wpis polityka zareagował Radosław Fogiel. - Gdyby popierający was zadymiarze nie organizowali wulgarnych awantur, to policja nie oceniałaby tak wysoko potencjalnego zagrożenia - stwierdził.</p><br clear="all" />

## Media: Eksperci z Korei Płn. pomogli stworzyć broń chemiczną dla Hezbollahu
 - [https://wydarzenia.interia.pl/zagranica/news-media-eksperci-z-korei-pln-pomogli-stworzyc-bron-chemiczna-d,nId,6423192](https://wydarzenia.interia.pl/zagranica/news-media-eksperci-z-korei-pln-pomogli-stworzyc-bron-chemiczna-d,nId,6423192)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 20:53:17+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-media-eksperci-z-korei-pln-pomogli-stworzyc-bron-chemiczna-d,nId,6423192"><img align="left" alt="Media: Eksperci z Korei Płn. pomogli stworzyć broń chemiczną dla Hezbollahu" src="https://i.iplsc.com/media-eksperci-z-korei-pln-pomogli-stworzyc-bron-chemiczna-d/000GD9WUDSXD25LL-C321.jpg" /></a>Hezbollah przechowuje setki pocisków z toksycznym ładunkiem chemicznym w magazynie w Al-Kusajr w pobliżu granicy libańsko-syryjskiej - podaje &quot;The Jerusalem Post&quot;, powołując się na saudyjskie media. Jak czytamy, w konstrukcji pocisków mieli brać udział eksperci z Korei Północnej.</p><br clear="all" />

## Oferta z Niemiec. Chodzi o systemy obrony powietrznej Patriot
 - [https://wydarzenia.interia.pl/zagranica/news-oferta-z-niemiec-chodzi-o-systemy-obrony-powietrznej-patriot,nId,6423176](https://wydarzenia.interia.pl/zagranica/news-oferta-z-niemiec-chodzi-o-systemy-obrony-powietrznej-patriot,nId,6423176)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 20:00:05+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-oferta-z-niemiec-chodzi-o-systemy-obrony-powietrznej-patriot,nId,6423176"><img align="left" alt="Oferta z Niemiec. Chodzi o systemy obrony powietrznej Patriot" src="https://i.iplsc.com/oferta-z-niemiec-chodzi-o-systemy-obrony-powietrznej-patriot/000GD9O5B02BE5GV-C321.jpg" /></a>Niemcy zaoferowały Polsce system obrony powietrznej i przeciwrakietowej typu Patriot - poinformował Reuters. - Baterie mają pomóc w zabezpieczeniu przestrzeni powietrznej po tym jak zbłąkany pocisk rozbił się w Polsce - powiedziała minister obrony Niemiec Christine Lambrecht.</p><br clear="all" />

## Białoruś oskarża Ukrainę o prowokację. "To może doprowadzić do starcia"
 - [https://wydarzenia.interia.pl/zagranica/news-bialorus-oskarza-ukraine-o-prowokacje-to-moze-doprowadzic-do,nId,6423166](https://wydarzenia.interia.pl/zagranica/news-bialorus-oskarza-ukraine-o-prowokacje-to-moze-doprowadzic-do,nId,6423166)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 19:55:11+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bialorus-oskarza-ukraine-o-prowokacje-to-moze-doprowadzic-do,nId,6423166"><img align="left" alt="Białoruś oskarża Ukrainę o prowokację. &quot;To może doprowadzić do starcia&quot;" src="https://i.iplsc.com/bialorus-oskarza-ukraine-o-prowokacje-to-moze-doprowadzic-do/000GD9LI950JP0T4-C321.jpg" /></a>Białoruś oskarża Ukrainę o prowokację, jako dowód pokazując wideo, na którym widać mężczyznę z bronią, przekraczającego ukraińsko-białoruską granicę. &quot;Ukraiński żołnierz robił zdjęcia i nagrywał filmy w okolicy&quot; - napisał Państwowy Komitet Graniczny Republiki Białorusi. Dodano, że &quot;stwarza to sytuacje prowokacyjne na granicy, które mogą doprowadzić do starcia zbrojnego&quot;.</p><br clear="all" />

## Pożar w Szczytnie. Strażacy znaleźli zwęglone ciała
 - [https://wydarzenia.interia.pl/warminsko-mazurskie/news-pozar-w-szczytnie-strazacy-znalezli-zweglone-ciala,nId,6423164](https://wydarzenia.interia.pl/warminsko-mazurskie/news-pozar-w-szczytnie-strazacy-znalezli-zweglone-ciala,nId,6423164)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 19:25:59+00:00

<p><a href="https://wydarzenia.interia.pl/warminsko-mazurskie/news-pozar-w-szczytnie-strazacy-znalezli-zweglone-ciala,nId,6423164"><img align="left" alt="Pożar w Szczytnie. Strażacy znaleźli zwęglone ciała" src="https://i.iplsc.com/pozar-w-szczytnie-strazacy-znalezli-zweglone-ciala/000G9NAANF4DG9XW-C321.jpg" /></a>Do pożaru, prawdopodobnie gołębnika, doszło na terenie ogródków działkowych w Szczytnie. Na miejsce przyjechały trzy zastępy straży pożarnej. Początkowo informowano o odnalezieniu jednego zwęglonego ciała. Jak jednak informuje policja, strażacy mieli odkryć w budynku jeszcze jedne zwłoki.</p><br clear="all" />

## Pożar w Szczytnie. Strażacy znaleźli zwęglone ciało
 - [https://wydarzenia.interia.pl/warminsko-mazurskie/news-pozar-w-szczytnie-strazacy-znalezli-zweglone-cialo,nId,6423164](https://wydarzenia.interia.pl/warminsko-mazurskie/news-pozar-w-szczytnie-strazacy-znalezli-zweglone-cialo,nId,6423164)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 19:25:59+00:00

<p><a href="https://wydarzenia.interia.pl/warminsko-mazurskie/news-pozar-w-szczytnie-strazacy-znalezli-zweglone-cialo,nId,6423164"><img align="left" alt="Pożar w Szczytnie. Strażacy znaleźli zwęglone ciało" src="https://i.iplsc.com/pozar-w-szczytnie-strazacy-znalezli-zweglone-cialo/000G9NAANF4DG9XW-C321.jpg" /></a>Do pożaru prawdopodobnie gołębnika doszło na terenie ogródków działkowych w Szczytnie. Na miejsce przyjechały trzy zastępy straży pożarnej. - W trakcie działań odnaleziono zwęglone ciało - poinformowali strażacy. Stan zwłok nie pozwala póki co na określenie płci ofiary.</p><br clear="all" />

## Nietypowa praktyka w rosyjskiej telewizji. Wyciszają "zakazane" słowa
 - [https://wydarzenia.interia.pl/zagranica/news-nietypowa-praktyka-w-rosyjskiej-telewizji-wyciszaja-zakazane,nId,6423160](https://wydarzenia.interia.pl/zagranica/news-nietypowa-praktyka-w-rosyjskiej-telewizji-wyciszaja-zakazane,nId,6423160)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 19:01:25+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nietypowa-praktyka-w-rosyjskiej-telewizji-wyciszaja-zakazane,nId,6423160"><img align="left" alt="Nietypowa praktyka w rosyjskiej telewizji. Wyciszają &quot;zakazane&quot; słowa " src="https://i.iplsc.com/nietypowa-praktyka-w-rosyjskiej-telewizji-wyciszaja-zakazane/000GD9F8NXNKTI3U-C321.jpg" /></a>W rosyjskiej telewizji podczas transmisji talent show w piosence wykonywanej przez jedną z uczestniczek wyciszono słowa &quot;pokój&quot; i wojna&quot;. Prowadzący nie umiał wyjaśnić, skąd taka decyzja i odesłał do rzecznika prasowego. To nie pierwsza tego typu sytuacja w kremlowskiej telewizji.</p><br clear="all" />

## Żołnierze odmówili wyjazdu do Ukrainy. Zostali aresztowani. Jest nagranie
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zolnierze-odmowili-wyjazdu-do-ukrainy-zostali-aresztowani-je,nId,6423154](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zolnierze-odmowili-wyjazdu-do-ukrainy-zostali-aresztowani-je,nId,6423154)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 18:50:21+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zolnierze-odmowili-wyjazdu-do-ukrainy-zostali-aresztowani-je,nId,6423154"><img align="left" alt="Żołnierze odmówili wyjazdu do Ukrainy. Zostali aresztowani. Jest nagranie" src="https://i.iplsc.com/zolnierze-odmowili-wyjazdu-do-ukrainy-zostali-aresztowani-je/000GD9EILNLX1851-C321.jpg" /></a>Dwóch żołnierzy, zmobilizowanych najprawdopodobniej w ramach zarządzonej przez Władimira Putina &quot;częściowej mobilizacji&quot;, zostało aresztowanych po tym, jak odmówili udziału w wojnie w Ukrainie. Zdaniem adwokata Maksima Grebeniuka cytowanego przez portal Ukraińska Prawda, &quot;nie było potrzeby dokonywania zatrzymania na terenie jednostki wojskowej&quot;. - Miało to charakter demonstracyjny i zostało zrobione w celu zastraszenia innych - dodał.</p><br clear="all" />

## Najdłużej panujący prezydent na świecie zorganizował potrójne wybory
 - [https://wydarzenia.interia.pl/zagranica/news-najdluzej-panujacy-prezydent-na-swiecie-zorganizowal-potrojn,nId,6423152](https://wydarzenia.interia.pl/zagranica/news-najdluzej-panujacy-prezydent-na-swiecie-zorganizowal-potrojn,nId,6423152)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 18:35:12+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-najdluzej-panujacy-prezydent-na-swiecie-zorganizowal-potrojn,nId,6423152"><img align="left" alt="Najdłużej panujący prezydent na świecie zorganizował potrójne wybory" src="https://i.iplsc.com/najdluzej-panujacy-prezydent-na-swiecie-zorganizowal-potrojn/000GD9DFJR8VOVAU-C321.jpg" /></a>W Gwinei Równikowej zorganizowano w niedzielę przyspieszone wybory prezydenckie połączone z wyborami parlamentarnymi i samorządowymi - poinformowała agencja Reutera. Od ponad 40 lat nieprzerwanie rządzi tam Teodoro Obiang Nguema Mbasogo, będąc tym samym najdłużej panującym prezydentem na świecie.</p><br clear="all" />

## Japonia: Matka przekonała dziewięcioletnią córkę do operacji plastycznej
 - [https://wydarzenia.interia.pl/zagranica/news-japonia-matka-przekonala-dziewiecioletnia-corke-do-operacji-,nId,6423141](https://wydarzenia.interia.pl/zagranica/news-japonia-matka-przekonala-dziewiecioletnia-corke-do-operacji-,nId,6423141)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 18:20:55+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-japonia-matka-przekonala-dziewiecioletnia-corke-do-operacji-,nId,6423141"><img align="left" alt="Japonia: Matka przekonała dziewięcioletnią córkę do operacji plastycznej" src="https://i.iplsc.com/japonia-matka-przekonala-dziewiecioletnia-corke-do-operacji/000GD9AE3QIAYWR2-C321.jpg" /></a>Mieszkanka Japonii miała przekonać swoją dziewięcioletnią córkę do operacji plastycznej powiek. Dziewczynka, która miała zgodzić się na zabieg, chciała wyglądać &quot;pięknie jak jej siostra&quot;. - Jeśli możesz znieść ból operacji plastycznej, to moim zdaniem czyni cię to piękną osobą - powiedziała dziewięciolatka mediom.</p><br clear="all" />

## W rosyjskiej telewizji mówią o "świętej nienawiści". "Zamarzną i zgniją"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-w-rosyjskiej-telewizji-mowia-o-swietej-nienawisci-zamarzna-i,nId,6423140](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-w-rosyjskiej-telewizji-mowia-o-swietej-nienawisci-zamarzna-i,nId,6423140)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 17:57:18+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-w-rosyjskiej-telewizji-mowia-o-swietej-nienawisci-zamarzna-i,nId,6423140"><img align="left" alt="W rosyjskiej telewizji mówią o &quot;świętej nienawiści&quot;. &quot;Zamarzną i zgniją&quot; " src="https://i.iplsc.com/w-rosyjskiej-telewizji-mowia-o-swietej-nienawisci-zamarzna-i/000GD98QJRCBL4SN-C321.jpg" /></a>&quot;Podżeganie do ludobójstwa w rosyjskiej telewizji idzie pełną parą&quot; - napisał na Twitterze minister spraw zagranicznych Ukrainy Dmytro Kułeba. Do wpisu załączył nagranie z fragmentami wypowiedzi rosyjskich propagandystów. Słyszmy w nim, że &quot;jeśli reżim kijowski wybierze ścieżkę zbrodniarzy wojennych, to (Ukraińcy - red.) powinni tam zamarznąć i zgnić&quot;. Inny z &quot;ekspertów&quot; twierdzi, że &quot;Zełenki spełnia kryteria terrorysty&quot;. Padło też porównanie do obozów koncentracyjnych...</p><br clear="all" />

## USA: Tragedia podczas parady bożonarodzeniowej. Nie żyje dziecko
 - [https://wydarzenia.interia.pl/zagranica/news-usa-tragedia-podczas-parady-bozonarodzeniowej-nie-zyje-dziec,nId,6423122](https://wydarzenia.interia.pl/zagranica/news-usa-tragedia-podczas-parady-bozonarodzeniowej-nie-zyje-dziec,nId,6423122)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 17:20:02+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-tragedia-podczas-parady-bozonarodzeniowej-nie-zyje-dziec,nId,6423122"><img align="left" alt="USA: Tragedia podczas parady bożonarodzeniowej. Nie żyje dziecko" src="https://i.iplsc.com/usa-tragedia-podczas-parady-bozonarodzeniowej-nie-zyje-dziec/000GD94F75320WK5-C321.jpg" /></a>Do tragedii doszło podczas parady bożonarodzeniowej w Karolinie Północnej w sobotę. Kierowca samochodu, który holował jedną z platform, stracił panowanie nad pojazdem. Toczący się pojazd uderzył w 11-letnią dziewczynkę. Dziecko zmarło.</p><br clear="all" />

## Zatrzymali poszukiwanego od 17 lat Polaka. Ukrywał się w Hiszpanii
 - [https://wydarzenia.interia.pl/lubuskie/news-zatrzymali-poszukiwanego-od-17-lat-polaka-ukrywal-sie-w-hisz,nId,6423116](https://wydarzenia.interia.pl/lubuskie/news-zatrzymali-poszukiwanego-od-17-lat-polaka-ukrywal-sie-w-hisz,nId,6423116)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 16:58:49+00:00

<p><a href="https://wydarzenia.interia.pl/lubuskie/news-zatrzymali-poszukiwanego-od-17-lat-polaka-ukrywal-sie-w-hisz,nId,6423116"><img align="left" alt="Zatrzymali poszukiwanego od 17 lat Polaka. Ukrywał się w Hiszpanii" src="https://i.iplsc.com/zatrzymali-poszukiwanego-od-17-lat-polaka-ukrywal-sie-w-hisz/000GD91SAF90BHJ9-C321.jpg" /></a>Od 2005 roku 53-letni Polak ukrywał się przed wymiarem sprawiedliwości. Był on oskarżony m.in. o liczne napady rabunkowe, przemoc i zastraszanie. Poszukiwanego trzema listami gończymi i trzema Europejskimi Nakazami Aresztowania 53-latka zatrzymali &quot;łowcy głów&quot;, czyli policjanci z Zespołu Poszukiwań Celowych Komendy Wojewódzkiej Policji w Gorzowie Wielkopolskim.</p><br clear="all" />

## Niemieckim żołnierzom brakuje spodni i kurtek. "Niedopuszczalne"
 - [https://wydarzenia.interia.pl/zagranica/news-niemieckim-zolnierzom-brakuje-spodni-i-kurtek-niedopuszczaln,nId,6423094](https://wydarzenia.interia.pl/zagranica/news-niemieckim-zolnierzom-brakuje-spodni-i-kurtek-niedopuszczaln,nId,6423094)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 16:52:50+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemieckim-zolnierzom-brakuje-spodni-i-kurtek-niedopuszczaln,nId,6423094"><img align="left" alt="Niemieckim żołnierzom brakuje spodni i kurtek. &quot;Niedopuszczalne&quot; " src="https://i.iplsc.com/niemieckim-zolnierzom-brakuje-spodni-i-kurtek-niedopuszczaln/000GD8ZD769R2239-C321.jpg" /></a>Eva Hoegl, pełnomocnik Bundestagu ds. sił zbrojnych poinformowała, że 43 żołnierzom, którzy zostaną wysłani na Mali wciąż brakuje spodni i kurtek. - Batalion w Badenii-Wirtembergii otrzymał właśnie skarpety - dodała. </p><br clear="all" />

## Rosja: Wzmożona aktywność wulkanów na Kamczatce. Eksperci ostrzegają
 - [https://wydarzenia.interia.pl/zagranica/news-rosja-wzmozona-aktywnosc-wulkanow-na-kamczatce-eksperci-ostr,nId,6423103](https://wydarzenia.interia.pl/zagranica/news-rosja-wzmozona-aktywnosc-wulkanow-na-kamczatce-eksperci-ostr,nId,6423103)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 16:06:58+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosja-wzmozona-aktywnosc-wulkanow-na-kamczatce-eksperci-ostr,nId,6423103"><img align="left" alt="Rosja: Wzmożona aktywność wulkanów na Kamczatce. Eksperci ostrzegają" src="https://i.iplsc.com/rosja-wzmozona-aktywnosc-wulkanow-na-kamczatce-eksperci-ostr/000GD8WROT56J7C3-C321.jpg" /></a>Chmury popiołu i gorącej lawy wyrzucają dwa wulkany na Kamczatce w Rosji. Przyczyną groźnego zjawiska jest sobotnie trzęsienie ziemi. Naukowcy twierdzą, że może dojść do poważnych erupcji.</p><br clear="all" />

## Podolak: Negocjacje z Rosją są jednoznaczne z kapitulacją
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-podolak-negocjacje-z-rosja-sa-jednoznaczne-z-kapitulacja,nId,6423098](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-podolak-negocjacje-z-rosja-sa-jednoznaczne-z-kapitulacja,nId,6423098)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 15:55:52+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-podolak-negocjacje-z-rosja-sa-jednoznaczne-z-kapitulacja,nId,6423098"><img align="left" alt="Podolak: Negocjacje z Rosją są jednoznaczne z kapitulacją" src="https://i.iplsc.com/podolak-negocjacje-z-rosja-sa-jednoznaczne-z-kapitulacja/000FGI2JKK51QMXT-C321.jpg" /></a>- Negocjacje z Moskwą oznaczałyby kapitulację. Rosja nie chce negocjacji – stwierdził w wywiadzie dla agencji AFP Mychajło Podolak, doradca prezydenta Ukrainy Wołodymyra Zełenskiego. Dodał też, że &quot;odzyskanie Chersonia oraz wcześniejsze wyzwolenie obwodu charkowskiego to są punkty zwrotne wojny&quot;. - Wojna zakończy się, gdy odzyskamy kontrolę nad naszymi granicami i kiedy Rosja zacznie się bać Ukrainy - podsumował. 

</p><br clear="all" />

## Rosyjskie media: Pożar w centrum Moskwy. Płonie magazyn
 - [https://wydarzenia.interia.pl/zagranica/news-rosyjskie-media-pozar-w-centrum-moskwy-plonie-magazyn,nId,6423089](https://wydarzenia.interia.pl/zagranica/news-rosyjskie-media-pozar-w-centrum-moskwy-plonie-magazyn,nId,6423089)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 15:32:04+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosyjskie-media-pozar-w-centrum-moskwy-plonie-magazyn,nId,6423089"><img align="left" alt="Rosyjskie media: Pożar w centrum Moskwy. Płonie magazyn" src="https://i.iplsc.com/rosyjskie-media-pozar-w-centrum-moskwy-plonie-magazyn/000GD8L42SSP5KFG-C321.jpg" /></a>W centrum Moskwy w rejonie Placu Komsomolskiego wybuchł pożar, który objął powierzchnię ok. 2 tys. metrów kwadratowych - informuje portal Meduza. To kolejny pożar w Rosji, do którego doszło w ciągu ostatnich kilku dni.</p><br clear="all" />

## "To są raczej kapiszony". Kaczyński o "radach" Jacka Saryusza-Wolskiego
 - [https://wydarzenia.interia.pl/kraj/news-to-sa-raczej-kapiszony-kaczynski-o-radach-jacka-saryusza-wol,nId,6423078](https://wydarzenia.interia.pl/kraj/news-to-sa-raczej-kapiszony-kaczynski-o-radach-jacka-saryusza-wol,nId,6423078)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 15:30:38+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-to-sa-raczej-kapiszony-kaczynski-o-radach-jacka-saryusza-wol,nId,6423078"><img align="left" alt="&quot;To są raczej kapiszony&quot;. Kaczyński o &quot;radach&quot; Jacka Saryusza-Wolskiego" src="https://i.iplsc.com/to-sa-raczej-kapiszony-kaczynski-o-radach-jacka-saryusza-wol/000GD8LBDII1LWQ1-C321.jpg" /></a>- Do ostrej walki potrzeba kul (...) to są raczej kapiszony - powiedział Jarosław Kaczyński, odnosząc się do słów europosła Jacka Saryusza-Wolskiego, który sugerował, że Polska powinna zastosować weto, by otrzymać unijne fundusze. - Mamy trzy weta, które są oczywiste, dotyczące trzech nowych podatków, zasobów własnych Unii (...) Aż się prosi, by zastosować nie politykę ugłaskiwania Komisji, ale taką jak Węgry, czyli zawetować, a potem rezygnować z weta, jeżeli fundusze popłyną  - mówił Saryusz-Wolski.</p><br clear="all" />

## Jarosław Kaczyński: Stworzyliśmy zupełnie nową rzeczywistość
 - [https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-stworzylismy-zupelnie-nowa-rzeczywistosc,nId,6423079](https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-stworzylismy-zupelnie-nowa-rzeczywistosc,nId,6423079)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 15:10:59+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-stworzylismy-zupelnie-nowa-rzeczywistosc,nId,6423079"><img align="left" alt="Jarosław Kaczyński: Stworzyliśmy zupełnie nową rzeczywistość" src="https://i.iplsc.com/jaroslaw-kaczynski-stworzylismy-zupelnie-nowa-rzeczywistosc/000GD8JD62RPBE4E-C321.jpg" /></a>- Stworzyliśmy zupełnie nową rzeczywistość, ale ona jest nieustannie atakowana i kontestowana przez wyrosłe z PRL przemalowane elity - powiedział prezes PiS Jarosław Kaczyński podczas wizyty w Gliwicach. - Pieniędzy nie było, myśmy je znaleźli - dodał. </p><br clear="all" />

## Morawiecki o konfiskacie majątków oligarchów: Oni muszą poczuć ból tej wojny
 - [https://wydarzenia.interia.pl/zagranica/news-morawiecki-o-konfiskacie-majatkow-oligarchow-oni-musza-poczu,nId,6423070](https://wydarzenia.interia.pl/zagranica/news-morawiecki-o-konfiskacie-majatkow-oligarchow-oni-musza-poczu,nId,6423070)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 14:39:38+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-morawiecki-o-konfiskacie-majatkow-oligarchow-oni-musza-poczu,nId,6423070"><img align="left" alt="Morawiecki o konfiskacie majątków oligarchów: Oni muszą poczuć ból tej wojny" src="https://i.iplsc.com/morawiecki-o-konfiskacie-majatkow-oligarchow-oni-musza-poczu/000GD7TSGP5KGJEC-C321.jpg" /></a>- Chciałbym podkreślić jeden element, który nie został jeszcze wykorzystany. Jest to potencjalna konfiskata aktywów rosyjskich, majątków Federacji Rosyjskiej i majtków oligarchów. Oni muszą poczuć ból tej wojny, muszą zostać pociągnięci do odpowiedzialności - powiedział premier Mateusz Morawiecki na wspólnej konferencji z szefową fińskiego rządu Sanną Marin.</p><br clear="all" />

## Wielka Brytania chce być drugą Szwajcarią. Ustalenia "The Sunday Times"
 - [https://wydarzenia.interia.pl/raporty/raport-brytyjskie-referendum/aktualnosci/news-wielka-brytania-chce-byc-druga-szwajcaria-ustalenia-the-sund,nId,6423063](https://wydarzenia.interia.pl/raporty/raport-brytyjskie-referendum/aktualnosci/news-wielka-brytania-chce-byc-druga-szwajcaria-ustalenia-the-sund,nId,6423063)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 14:19:12+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-brytyjskie-referendum/aktualnosci/news-wielka-brytania-chce-byc-druga-szwajcaria-ustalenia-the-sund,nId,6423063"><img align="left" alt="Wielka Brytania chce być drugą Szwajcarią. Ustalenia &quot;The Sunday Times&quot;" src="https://i.iplsc.com/wielka-brytania-chce-byc-druga-szwajcaria-ustalenia-the-sund/000GD7RUG1QLUFMV-C321.jpg" /></a>&quot;The Sunday Times&quot; podał, że brytyjski rząd przymierza się do nowej umowy z Unią Europejską. By usunąć problemy związane z handlem będzie chciał dogadać się z UE na podobnych warunkach jak Szwajcaria - czytamy. W planie nie ma mowy o powrocie do swobodnego przepływu osób. </p><br clear="all" />

## Jarosław Kaczyński zareagował na "osiem gwiazdek". "To jest rynsztok"
 - [https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-zareagowal-na-osiem-gwiazdek-to-jest-ryns,nId,6423048](https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-zareagowal-na-osiem-gwiazdek-to-jest-ryns,nId,6423048)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 13:28:15+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-zareagowal-na-osiem-gwiazdek-to-jest-ryns,nId,6423048"><img align="left" alt="Jarosław Kaczyński zareagował na &quot;osiem gwiazdek&quot;. &quot;To jest rynsztok&quot;" src="https://i.iplsc.com/jaroslaw-kaczynski-zareagowal-na-osiem-gwiazdek-to-jest-ryns/000GD7M1EPEV7FH4-C321.jpg" /></a>- Rządy PO-PSL bardzo intensywnie zajmowały się nie wzmacnianiem, ale osłabianiem naszej armii, jej redukcją - ocenił podczas spotkania z mieszkańcami w Gliwicach Jarosław Kaczyński. Prezes PiS określił, że osoby używające &quot;ośmiu gwiazdek&quot; &quot;staczają się do rynsztoku&quot;. - My chcemy, żeby Polska płynęła w czystej wodzie - zapewniał.</p><br clear="all" />

## Małopolska: Ciało 41-latka w rzeczce. "Zwłoki znalazł jego brat"
 - [https://wydarzenia.interia.pl/malopolskie/news-malopolska-cialo-41-latka-w-rzeczce-zwloki-znalazl-jego-brat,nId,6423046](https://wydarzenia.interia.pl/malopolskie/news-malopolska-cialo-41-latka-w-rzeczce-zwloki-znalazl-jego-brat,nId,6423046)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 13:13:49+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-malopolska-cialo-41-latka-w-rzeczce-zwloki-znalazl-jego-brat,nId,6423046"><img align="left" alt="Małopolska: Ciało 41-latka w rzeczce. &quot;Zwłoki znalazł jego brat&quot;" src="https://i.iplsc.com/malopolska-cialo-41-latka-w-rzeczce-zwloki-znalazl-jego-brat/000FY3H4N879S7OQ-C321.jpg" /></a>Z potoku Nieczajka w Radwanie (woj. małopolskie) wyłowiono ciało 41-latka - poinformowała policja w Dąbrowie Tarnowskiej. Na zwłoki mężczyzny natrafił w sobotę wieczorem jego brat. Służby rozpoczęły dochodzenie, aby ustalić przyczyny śmierci.</p><br clear="all" />

## USA: Strzelanina w klubie LGBT. Pięć osób zginęło, a 18 zostało rannych
 - [https://wydarzenia.interia.pl/zagranica/news-usa-strzelanina-w-klubie-lgbt-piec-osob-zginelo-a-18-zostalo,nId,6423038](https://wydarzenia.interia.pl/zagranica/news-usa-strzelanina-w-klubie-lgbt-piec-osob-zginelo-a-18-zostalo,nId,6423038)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 12:42:03+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-strzelanina-w-klubie-lgbt-piec-osob-zginelo-a-18-zostalo,nId,6423038"><img align="left" alt="USA: Strzelanina w klubie LGBT. Pięć osób zginęło, a 18 zostało rannych" src="https://i.iplsc.com/usa-strzelanina-w-klubie-lgbt-piec-osob-zginelo-a-18-zostalo/000GD7H05P8Y89MD-C321.jpg" /></a>Pięć osób zginęło a 18 zostało rannych w ataku na klub LGBT w stanie Kolorado w USA. Podejrzany o atak został ujęty przez lokalną policję i przetransportowany do aresztu, gdzie został poddany leczeniu z powodu obrażeń, jakich doznał podczas zatrzymania. Służby nie wykluczają, że liczba ofiar może wzrosnąć.</p><br clear="all" />

## Silne eksplozje na terenie Zaporoskiej Elektrowni Atomowej w Ukrainie
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-silne-eksplozje-na-terenie-zaporoskiej-elektrowni-atomowej-w,nId,6423025](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-silne-eksplozje-na-terenie-zaporoskiej-elektrowni-atomowej-w,nId,6423025)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 12:05:35+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-silne-eksplozje-na-terenie-zaporoskiej-elektrowni-atomowej-w,nId,6423025"><img align="left" alt="Silne eksplozje na terenie Zaporoskiej Elektrowni Atomowej w Ukrainie" src="https://i.iplsc.com/silne-eksplozje-na-terenie-zaporoskiej-elektrowni-atomowej-w/000GD7EB6X8BUC81-C321.jpg" /></a>Na terenie i w pobliżu kontrolowanej przez rosyjskie wojska Zaporoskiej Elektrowni Atomowej na południu Ukrainy doszło w sobotę wieczorem i w niedzielę rano do silnych wybuchów - poinformowała w komunikacie Międzynarodowa Agencja Energii Atomowej (MAEA). Według Enerhoatmu rosyjskie wojsko trafiło 12 razy w obiekty infrastruktury na terenie siłowni.</p><br clear="all" />

## Drugi pogrzeb w Przewodowie. "To byli dobrzy ludzie"
 - [https://wydarzenia.interia.pl/kraj/news-drugi-pogrzeb-w-przewodowie-to-byli-dobrzy-ludzie,nId,6422971](https://wydarzenia.interia.pl/kraj/news-drugi-pogrzeb-w-przewodowie-to-byli-dobrzy-ludzie,nId,6422971)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 12:05:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-drugi-pogrzeb-w-przewodowie-to-byli-dobrzy-ludzie,nId,6422971"><img align="left" alt="Drugi pogrzeb w Przewodowie. &quot;To byli dobrzy ludzie&quot; " src="https://i.iplsc.com/drugi-pogrzeb-w-przewodowie-to-byli-dobrzy-ludzie/000GD7DLWY60E4CC-C321.jpg" /></a>W Przewodowie o godz. 13 rozpoczął się pogrzeb 59-letniego Bogdana C. - drugiej ofiary rakiety, która spadła na teren suszarni zboża. Uroczystość ma charakter państwowy, jednak rodzina prosi o uszanowanie prywatności podczas pożegnania.</p><br clear="all" />

## "Państwo w Państwie": Dawca nerki czeka w więzieniu. Sąd nie chce go wypuścić
 - [https://wydarzenia.interia.pl/kraj/news-panstwo-w-panstwie-dawca-nerki-czeka-w-wiezieniu-sad-nie-chc,nId,6423014](https://wydarzenia.interia.pl/kraj/news-panstwo-w-panstwie-dawca-nerki-czeka-w-wiezieniu-sad-nie-chc,nId,6423014)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 11:30:57+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-panstwo-w-panstwie-dawca-nerki-czeka-w-wiezieniu-sad-nie-chc,nId,6423014"><img align="left" alt="&quot;Państwo w Państwie&quot;: Dawca nerki czeka w więzieniu. Sąd nie chce go wypuścić" src="https://i.iplsc.com/panstwo-w-panstwie-dawca-nerki-czeka-w-wiezieniu-sad-nie-chc/000GD78Z9XY02ERN-C321.jpg" /></a>Krystian Kiełbik, cierpi na poważną chorobę nerek i pilnie potrzebuje przeszczepu. Organ chciałby mu oddać brat. Ten jednak siedzi w więzieniu, a sąd nie zgadza się na przerwę w karze na czas przeszczepu. Więcej w materiale Pawła Siudy o godz. 19:30 w programie Państwo w Państwie. </p><br clear="all" />

## Udusił żonę, bo ta go poprosiła. Brytyjczyk może opuścić cypryjskie więzienie
 - [https://wydarzenia.interia.pl/zagranica/news-udusil-zone-bo-ta-go-poprosila-brytyjczyk-moze-opuscic-cypry,nId,6423004](https://wydarzenia.interia.pl/zagranica/news-udusil-zone-bo-ta-go-poprosila-brytyjczyk-moze-opuscic-cypry,nId,6423004)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 11:02:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-udusil-zone-bo-ta-go-poprosila-brytyjczyk-moze-opuscic-cypry,nId,6423004"><img align="left" alt="Udusił żonę, bo ta go poprosiła. Brytyjczyk może opuścić cypryjskie więzienie" src="https://i.iplsc.com/udusil-zone-bo-ta-go-poprosila-brytyjczyk-moze-opuscic-cypry/000GD75GJNM7558S-C321.jpg" /></a>Brytyjczyk David Hunter, który udusił swoją śmiertelnie chorą żonę, nie będzie odpowiadał za zabójstwo. Obrońcy i prokuratorzy zawarli ugodę, zgodnie z którą mężczyzna przyzna się do zarzutu nieumyślnego spowodowania śmierci i prawdopodobnie będzie mógł opuścić cypryjskie więzienie. Zarówno 75-latek, jak i jego rodzina od początku procesu przekonywali, że zatrzymany chciał jedynie &quot;ulżyć w cierpieniu&quot; swojej żonie i zabił ją na jej wyłączną prośbę.</p><br clear="all" />

## Orban dogaduje się z Komisją, a my?
 - [https://wydarzenia.interia.pl/felietony/swietlik/news-orban-dogaduje-sie-z-komisja-a-my,nId,6422992](https://wydarzenia.interia.pl/felietony/swietlik/news-orban-dogaduje-sie-z-komisja-a-my,nId,6422992)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 10:40:46+00:00

<p><a href="https://wydarzenia.interia.pl/felietony/swietlik/news-orban-dogaduje-sie-z-komisja-a-my,nId,6422992"><img align="left" alt="Orban dogaduje się z Komisją, a my? " src="https://i.iplsc.com/orban-dogaduje-sie-z-komisja-a-my/000GBFKGU7EH6I0I-C321.jpg" /></a>Do Victora Orbana jest nam dziś bardzo daleko, ale pragmatyzmu i sprytu raczej nikt mu nie odmówi. I jeśli jest gotów iść na bardzo daleko idące ustępstwa w sporze z Brukselą, by odblokować pocovidowe fundusze, to chyba oznacza, że są one bardzo istotne. Dla Węgier i dla Polski.</p><br clear="all" />

## Zełenski wpakował się w kłopoty. "Dla niego cel uświęca środki"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-wpakowal-sie-w-klopoty-dla-niego-cel-uswieca-srodki,nId,6421596](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-wpakowal-sie-w-klopoty-dla-niego-cel-uswieca-srodki,nId,6421596)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 10:07:09+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-wpakowal-sie-w-klopoty-dla-niego-cel-uswieca-srodki,nId,6421596"><img align="left" alt="Zełenski wpakował się w kłopoty. &quot;Dla niego cel uświęca środki&quot;" src="https://i.iplsc.com/zelenski-wpakowal-sie-w-klopoty-dla-niego-cel-uswieca-srodki/000GD5PWTB5QA9D6-C321.jpg" /></a>- Prezydent Zełenski sam siebie postawił w bardzo kłopotliwej sytuacji przez swoją pierwszą publiczną reakcję. Teraz jest mu trudno, zwłaszcza tak szybko, całkowicie wycofać się ze swoich słów. Tym bardziej, że podparł się autorytetem swoich dowódców wojskowych. To byłaby dla niego bolesna wizerunkowa porażka - o komunikacji ukraińskich władz w sprawie incydentu w Przewodowie mówi Interii dr Daniel Szeligowski, kierownik programu &quot;Europa Wschodnia&quot; w Polskim Instytucie Spraw Międzynarodowych.</p><br clear="all" />

## Rzecznik ukraińskich wojsk: Rosja chce zająć Donbas, a później obwód zaporoski
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rzecznik-ukrainskich-wojsk-rosja-chce-zajac-donbas-a-pozniej,nId,6422976](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rzecznik-ukrainskich-wojsk-rosja-chce-zajac-donbas-a-pozniej,nId,6422976)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 09:50:50+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rzecznik-ukrainskich-wojsk-rosja-chce-zajac-donbas-a-pozniej,nId,6422976"><img align="left" alt="Rzecznik ukraińskich wojsk: Rosja chce zająć Donbas, a później obwód zaporoski" src="https://i.iplsc.com/rzecznik-ukrainskich-wojsk-rosja-chce-zajac-donbas-a-pozniej/000GD6YEQ7Q5GV50-C321.jpg" /></a>Rzecznik ukraińskiego Wschodniego Zgrupowania Wojsk Serhij Czerewaty przekazał, że rosyjska armia zamierza opanować teren obwodów ługańskiego i donieckiego w Donbasie, a następnie podbić obwód zaporoski. Dodał, że w obwodzie ługańskim &quot;mimo wszelkich ambicji wroga&quot; rosyjska armia ponosi klęski.</p><br clear="all" />

## Alarm przeciwlotniczy we wszystkich obwodach Ukrainy
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-alarm-przeciwlotniczy-we-wszystkich-obwodach-ukrainy,nId,6422974](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-alarm-przeciwlotniczy-we-wszystkich-obwodach-ukrainy,nId,6422974)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 09:49:48+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-alarm-przeciwlotniczy-we-wszystkich-obwodach-ukrainy,nId,6422974"><img align="left" alt="Alarm przeciwlotniczy we wszystkich obwodach Ukrainy" src="https://i.iplsc.com/alarm-przeciwlotniczy-we-wszystkich-obwodach-ukrainy/000GD6WBK79PSV3P-C321.jpg" /></a>Nad ranem we wszystkich obwodach Ukrainy, z wyjątkiem okupowanego Krymu, ogłoszono alarm przeciwlotniczy. W niemal wszystkich regionach zakończył się on po kilku godzinach, internauci i media nie informowały o żadnych poważnych eksplozjach i zniszczeniach.</p><br clear="all" />

## Tragiczny pożar w gminie Rypin. Zginęły dwie osoby
 - [https://wydarzenia.interia.pl/kujawsko-pomorskie/news-tragiczny-pozar-w-gminie-rypin-zginely-dwie-osoby,nId,6422959](https://wydarzenia.interia.pl/kujawsko-pomorskie/news-tragiczny-pozar-w-gminie-rypin-zginely-dwie-osoby,nId,6422959)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 08:51:17+00:00

<p><a href="https://wydarzenia.interia.pl/kujawsko-pomorskie/news-tragiczny-pozar-w-gminie-rypin-zginely-dwie-osoby,nId,6422959"><img align="left" alt="Tragiczny pożar w gminie Rypin. Zginęły dwie osoby" src="https://i.iplsc.com/tragiczny-pozar-w-gminie-rypin-zginely-dwie-osoby/000GD6RGBT6GRH6E-C321.jpg" /></a>W pożarze budynku mieszkalnego, który nocą wybuchł w miejscowości Lasoty w gminie Rypin (Kujawsko-Pomorskie) zginęły dwie osoby, a jedna została ranna - przekazała Komenda Powiatowa Państwowej Straży Pożarnej w Rypinie. Na miejscu pracuje prokuratura i biegły sądowy z zakresu pożarnictwa.</p><br clear="all" />

## Wsyp do doniczki fusy z kawy lub czosnek. Twoje kwiaty będą ci wdzięczne
 - [https://wydarzenia.interia.pl/ciekawostki/news-wsyp-do-doniczki-fusy-z-kawy-lub-czosnek-twoje-kwiaty-beda-c,nId,6412730](https://wydarzenia.interia.pl/ciekawostki/news-wsyp-do-doniczki-fusy-z-kawy-lub-czosnek-twoje-kwiaty-beda-c,nId,6412730)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 08:35:22+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-wsyp-do-doniczki-fusy-z-kawy-lub-czosnek-twoje-kwiaty-beda-c,nId,6412730"><img align="left" alt="Wsyp do doniczki fusy z kawy lub czosnek. Twoje kwiaty będą ci wdzięczne " src="https://i.iplsc.com/wsyp-do-doniczki-fusy-z-kawy-lub-czosnek-twoje-kwiaty-beda-c/000GCD7KSO27UQ7P-C321.jpg" /></a>Większość produktów do pielęgnacji roślin znajdziesz w swojej kuchni. Są one tanie i ekologiczne. Z pewnością będzie to lepszy i zdrowszy wybór niż gotowe chemiczne preparaty. Znajomość sposobów na zadbanie o kwiaty doniczkowe, które przedstawiamy, zapewni im piękny wygląd. </p><br clear="all" />

## Straż Graniczna: 43 osoby próbowały nielegalnie dostać się do Polski
 - [https://wydarzenia.interia.pl/podlaskie/news-straz-graniczna-43-osoby-probowaly-nielegalnie-dostac-sie-do,nId,6422955](https://wydarzenia.interia.pl/podlaskie/news-straz-graniczna-43-osoby-probowaly-nielegalnie-dostac-sie-do,nId,6422955)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 08:28:40+00:00

<p><a href="https://wydarzenia.interia.pl/podlaskie/news-straz-graniczna-43-osoby-probowaly-nielegalnie-dostac-sie-do,nId,6422955"><img align="left" alt="Straż Graniczna: 43 osoby próbowały nielegalnie dostać się do Polski" src="https://i.iplsc.com/straz-graniczna-43-osoby-probowaly-nielegalnie-dostac-sie-do/000GD6PM184V2N70-C321.jpg" /></a>43 osoby próbowały nielegalnie przekroczyć polsko-białoruską granicę - przekazała Straż Graniczna. W pobliżu Krynek trzech migrantów (z Kamerunu i Syrii) przeprawiło się przez graniczną rzekę Świsłocz. Zatrzymano dwie osoby, które przewoziły migrantów.</p><br clear="all" />

## Przewodów: Zakończono prace na miejscu eksplozji. Lej o głębokości 5 metrów
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-przewodow-zakonczono-prace-na-miejscu-eksplozji-lej-o-glebok,nId,6422950](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-przewodow-zakonczono-prace-na-miejscu-eksplozji-lej-o-glebok,nId,6422950)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 08:13:08+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-przewodow-zakonczono-prace-na-miejscu-eksplozji-lej-o-glebok,nId,6422950"><img align="left" alt="Przewodów: Zakończono prace na miejscu eksplozji. Lej o głębokości 5 metrów" src="https://i.iplsc.com/przewodow-zakonczono-prace-na-miejscu-eksplozji-lej-o-glebok/000GD6OSS6K9NJR9-C321.jpg" /></a>Po eksplozji w Przewodowie pozostał duży lej powybuchowy o głębokości ok. 5 metrów. Służby zakończyły tam prace. </p><br clear="all" />

## Józef Orzeł: Interesem Ziobry nie jest już interes Polski
 - [https://wydarzenia.interia.pl/kraj/news-jozef-orzel-interesem-ziobry-nie-jest-juz-interes-polski,nId,6422936](https://wydarzenia.interia.pl/kraj/news-jozef-orzel-interesem-ziobry-nie-jest-juz-interes-polski,nId,6422936)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 08:05:22+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jozef-orzel-interesem-ziobry-nie-jest-juz-interes-polski,nId,6422936"><img align="left" alt="Józef Orzeł: Interesem Ziobry nie jest już interes Polski " src="https://i.iplsc.com/jozef-orzel-interesem-ziobry-nie-jest-juz-interes-polski/000GD6K8I6AVOOF3-C321.jpg" /></a>- Widać, że interesem Ziobry nie jest już interes kraju, tylko interes jego partii. On buduje swoją pozycję na tym, że Kaczyński kiedyś odejdzie na emeryturę, a on powalczy o przywództwo w Zjednoczonej Prawicy – uważa Józef Orzeł, współzałożyciel i były poseł Porozumienia Centrum. Jak mówi Interii, pieniądze z KPO są Polsce potrzebne w ciągu najbliższych 2-3 miesięcy. - Inaczej będziemy mieli kryzys finansowy. Oby nie było tak, że Ziobro na to czeka – stwierdza. - Jeśli KE przekaże Polsce pieniądze, to koalicja rządząca się rozpadnie, albo...</p><br clear="all" />

## Zmobilizowani Rosjanie oburzeni planem przerzucenia ich do Donbasu
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zmobilizowani-rosjanie-oburzeni-planem-przerzucenia-ich-do-d,nId,6422938](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zmobilizowani-rosjanie-oburzeni-planem-przerzucenia-ich-do-d,nId,6422938)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 07:50:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zmobilizowani-rosjanie-oburzeni-planem-przerzucenia-ich-do-d,nId,6422938"><img align="left" alt="Zmobilizowani Rosjanie oburzeni planem przerzucenia ich do Donbasu" src="https://i.iplsc.com/zmobilizowani-rosjanie-oburzeni-planem-przerzucenia-ich-do-d/000GD6MQC82M198B-C321.jpg" /></a>Zmobilizowani Rosjanie są oburzeni planem swoich dowódców - donosi Sztab Generalny Sił Zbrojnych Ukrainy. Żołnierze bez przeszkolenia mają zostać przerzuceni do Donbasu, by kontynuować walki. Wojska, zdając sobie z nastrojów w armii, rozmieszczają posterunki służące do wyłapywania dezerterów.</p><br clear="all" />

## Szatan, Lucyfer, Belzebub. Jak wygląda diabeł w różnych religiach świata?
 - [https://wydarzenia.interia.pl/religia/news-szatan-lucyfer-belzebub-jak-wyglada-diabel-w-roznych-religia,nId,6397453](https://wydarzenia.interia.pl/religia/news-szatan-lucyfer-belzebub-jak-wyglada-diabel-w-roznych-religia,nId,6397453)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 07:43:03+00:00

<p><a href="https://wydarzenia.interia.pl/religia/news-szatan-lucyfer-belzebub-jak-wyglada-diabel-w-roznych-religia,nId,6397453"><img align="left" alt="Szatan, Lucyfer, Belzebub. Jak wygląda diabeł w różnych religiach świata?" src="https://i.iplsc.com/szatan-lucyfer-belzebub-jak-wyglada-diabel-w-roznych-religia/000GC7UHLCYUB3IA-C321.jpg" /></a>Wizerunek szatana zmieniał się na przestrzeni wieków. W zależności od religii i kultury diabła wyobrażano sobie na różne sposoby. Skąd wziął się szatan i dlaczego jako chrześcijanie postrzegamy go przede wszystkim jako złego ducha? Wyjaśniamy.</p><br clear="all" />

## Nieoficjalnie: Irańskie drony będą produkowane w Rosji
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nieoficjalnie-iranskie-drony-beda-produkowane-w-rosji,nId,6422941](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nieoficjalnie-iranskie-drony-beda-produkowane-w-rosji,nId,6422941)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 07:30:57+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nieoficjalnie-iranskie-drony-beda-produkowane-w-rosji,nId,6422941"><img align="left" alt="Nieoficjalnie: Irańskie drony będą produkowane w Rosji" src="https://i.iplsc.com/nieoficjalnie-iranskie-drony-beda-produkowane-w-rosji/000GD6LD5DDQO6TL-C321.jpg" /></a>Rosja i Iran porozumiały się w sprawie budowy &quot;setek&quot; dronów bojowych według irańskiego projektu na terytorium Rosji - poinformował dziennik &quot;Washington Post&quot;. Anonimowe źródła dziennikarzy twierdzą, że umowę sfinalizowano na początku listopada podczas wizyty rosyjskiej delegacji w Iranie. Produkcja ma rozpocząć się w ciągu kilku miesięcy.</p><br clear="all" />

## Problemy z bezsennością. Ekspert: Niekorzystna zmiana stylu życia
 - [https://wydarzenia.interia.pl/kraj/news-problemy-z-bezsennoscia-ekspert-niekorzystna-zmiana-stylu-zy,nId,6422932](https://wydarzenia.interia.pl/kraj/news-problemy-z-bezsennoscia-ekspert-niekorzystna-zmiana-stylu-zy,nId,6422932)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 06:58:58+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-problemy-z-bezsennoscia-ekspert-niekorzystna-zmiana-stylu-zy,nId,6422932"><img align="left" alt="Problemy z bezsennością. Ekspert: Niekorzystna zmiana stylu życia" src="https://i.iplsc.com/problemy-z-bezsennoscia-ekspert-niekorzystna-zmiana-stylu-zy/0002LMHD6LJY73TW-C321.jpg" /></a>Niekorzystna zmiana stylu życia i zaburzenia rytmu dobowego - to dziś główne przyczyny bezsenności - twierdzi prof. Adam Wichniak, specjalista zaburzeń snu. Ekspert radzi by na lepszy sen m.in. odpowiednio wcześnie wyłączyć urządzenia elektroniczne i dbać o wysiłek fizyczny.</p><br clear="all" />

## Prokurator generalny Ukrainy: Na wyzwolonych terenach znaleziono ponad 700 ciał
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-prokurator-generalny-ukrainy-na-wyzwolonych-terenach-znalezi,nId,6422931](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-prokurator-generalny-ukrainy-na-wyzwolonych-terenach-znalezi,nId,6422931)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 06:54:04+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-prokurator-generalny-ukrainy-na-wyzwolonych-terenach-znalezi,nId,6422931"><img align="left" alt="Prokurator generalny Ukrainy: Na wyzwolonych terenach znaleziono ponad 700 ciał" src="https://i.iplsc.com/prokurator-generalny-ukrainy-na-wyzwolonych-terenach-znalezi/000GD6JMGFRNVIW2-C321.jpg" /></a>Prokurator generalny Ukrainy Andrij Kostin przekazał, że na wyzwolonych terenach obwodów charkowskiego, chersońskiego i donieckiego w ciągu ostatnich dwóch miesięcy znaleziono ponad 700 ciał. Ok. 90 proc. to cywile zabici przez wojska rosyjskie.</p><br clear="all" />

## Kontrole w polskich domach. Czy musisz wpuścić inspektorów? Komu grozi kara?
 - [https://wydarzenia.interia.pl/kraj/news-kontrole-w-polskich-domach-czy-musisz-wpuscic-inspektorow-ko,nId,6419646](https://wydarzenia.interia.pl/kraj/news-kontrole-w-polskich-domach-czy-musisz-wpuscic-inspektorow-ko,nId,6419646)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 06:35:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kontrole-w-polskich-domach-czy-musisz-wpuscic-inspektorow-ko,nId,6419646"><img align="left" alt="Kontrole w polskich domach. Czy musisz wpuścić inspektorów? Komu grozi kara?" src="https://i.iplsc.com/kontrole-w-polskich-domach-czy-musisz-wpuscic-inspektorow-ko/000GCYVUSUUSEMYW-C321.jpg" /></a>Kontrola abonamentu RTV ma na celu sprawdzenie, kto posiada w domu niezarejestrowany odbiornik radiowy lub telewizyjny i kto nie płaci abonamentu, choć powinien to robić. Jak wyglądają takie kontrole i kto może spodziewać się podobnej wizyty? Jaka kara grozi za niepłacenie? </p><br clear="all" />

## Japonia: 97-letni kierowca śmiertelnie potrącił kobietę na chodniku
 - [https://wydarzenia.interia.pl/zagranica/news-japonia-97-letni-kierowca-smiertelnie-potracil-kobiete-na-ch,nId,6422924](https://wydarzenia.interia.pl/zagranica/news-japonia-97-letni-kierowca-smiertelnie-potracil-kobiete-na-ch,nId,6422924)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 06:28:09+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-japonia-97-letni-kierowca-smiertelnie-potracil-kobiete-na-ch,nId,6422924"><img align="left" alt="Japonia: 97-letni kierowca śmiertelnie potrącił kobietę na chodniku" src="https://i.iplsc.com/japonia-97-letni-kierowca-smiertelnie-potracil-kobiete-na-ch/000GD6HWVVR8SEJM-C321.jpg" /></a>97-letni kierowca w Fukushimie śmiertelnie potrącił idącą chodnikiem kobietę. Następnie mężczyzna, próbując wrócić na jezdnię, wjechał w trzy inne samochody samochody raniąc cztery inne kobiety. Japońskie media zwracają uwagę na rosnącą liczbę wypadków przez starszych kierowców.</p><br clear="all" />

## USA: Konto Donalda Trumpa na Twitterze zostało przywrócone. "Ludzie przemówili"
 - [https://wydarzenia.interia.pl/zagranica/news-usa-konto-donalda-trumpa-na-twitterze-zostalo-przywrocone-lu,nId,6422921](https://wydarzenia.interia.pl/zagranica/news-usa-konto-donalda-trumpa-na-twitterze-zostalo-przywrocone-lu,nId,6422921)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 05:54:06+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-konto-donalda-trumpa-na-twitterze-zostalo-przywrocone-lu,nId,6422921"><img align="left" alt="USA: Konto Donalda Trumpa na Twitterze zostało przywrócone. &quot;Ludzie przemówili&quot;" src="https://i.iplsc.com/usa-konto-donalda-trumpa-na-twitterze-zostalo-przywrocone-lu/000GD6G7Q92HAY17-C321.jpg" /></a>Konto byłego prezydenta USA Donalda Trumpa na Twitterze zostało przywrócone. Wcześniej właściciel firmy, Elon Musk, zorganizował dla użytkowników ankietę, w której zapytał o to, czy konto Trumpa powinno wrócić. Nieco ponad połowa głosowała za.</p><br clear="all" />

## Ile kosztował mundial w Katarze? Rekordowa suma na mistrzostwa świata
 - [https://wydarzenia.interia.pl/zagranica/news-ile-kosztowal-mundial-w-katarze-rekordowa-suma-na-mistrzostw,nId,6419464](https://wydarzenia.interia.pl/zagranica/news-ile-kosztowal-mundial-w-katarze-rekordowa-suma-na-mistrzostw,nId,6419464)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 05:30:36+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ile-kosztowal-mundial-w-katarze-rekordowa-suma-na-mistrzostw,nId,6419464"><img align="left" alt="Ile kosztował mundial w Katarze? Rekordowa suma na mistrzostwa świata" src="https://i.iplsc.com/ile-kosztowal-mundial-w-katarze-rekordowa-suma-na-mistrzostw/000GC4A88MF9Y71K-C321.jpg" /></a>Już dziś rozpoczynają się mistrzostwa świata w piłce nożnej w Katarze. Ile pieniędzy ten mały, ale bogaty kraj wydał na przygotowanie mundialu? Kto wyłożył pieniądze na organizację? </p><br clear="all" />

## Wojna w Ukrainie. 270. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-270-dzien-inwazji-rosji-relacja-na-zywo,nzId,3418,akt,200642](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-270-dzien-inwazji-rosji-relacja-na-zywo,nzId,3418,akt,200642)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 05:18:06+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-270-dzien-inwazji-rosji-relacja-na-zywo,nzId,3418,akt,200642"><img align="left" alt="Wojna w Ukrainie. 270. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-270-dzien-inwazji-rosji-relacja-na-zywo/000GD6EKF5ELR5CE-C321.jpg" /></a>Zapraszamy do śledzenia naszej relacji na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 270. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-270-dzien-inwazji-rosji-relacja-na-zywo,nzId,3418,akt,200751](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-270-dzien-inwazji-rosji-relacja-na-zywo,nzId,3418,akt,200751)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-11-20 05:18:06+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-270-dzien-inwazji-rosji-relacja-na-zywo,nzId,3418,akt,200751"><img align="left" alt="Wojna w Ukrainie. 270. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-270-dzien-inwazji-rosji-relacja-na-zywo/000GD6EKF5ELR5CE-C321.jpg" /></a>Zapraszamy do śledzenia naszej relacji na żywo.</p><br clear="all" />


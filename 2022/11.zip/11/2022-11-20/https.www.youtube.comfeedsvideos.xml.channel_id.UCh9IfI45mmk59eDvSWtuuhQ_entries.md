# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## What In-Store Shopping Is Like Now
 - [https://www.youtube.com/watch?v=kAveQ7fc2oo](https://www.youtube.com/watch?v=kAveQ7fc2oo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2022-11-20 21:10:49+00:00

Vessis early Black Friday sale is on now! Vessi is giving away a pair of socks of your choice to the first 100 shoes sold using my code SOCKSRYANGEORGE. Get your style and size you want now before they sell out! Check out their Early Black Friday sale at https://vessi.com/RYANGEORGE. Free shipping to CA, US, AU,JP, TW, KR, SGP. "Online Store"

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats.
Twitter/Instagram: @TheRyanGeorge


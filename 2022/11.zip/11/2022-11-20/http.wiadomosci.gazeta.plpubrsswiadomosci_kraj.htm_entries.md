# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Przewodów. Pogrzeb drugiej ofiary wybuchu. "W XXI wieku doszło do takiego dramatu"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29161897,przewodow-pogrzeb-drugiej-ofiary-wybuchu-w-xxi-wieku-doszlo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29161897,przewodow-pogrzeb-drugiej-ofiary-wybuchu-w-xxi-wieku-doszlo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-20 15:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/65/cf/1b/z29162085M,Przewodow--19-listopada-2022-r--Pogrzeb-Boguslawa-.jpg" vspace="2" />Odbył się pogrzeb Bogdana C. - drugiej z ofiar wybuchu rakiety w Przewodowie. Pożegnanie miało charakter państwowy. - Wyrazy współczucia i solidarności płyną z Europy i świata. Jak to możliwe, że w XXI wieku doszło do takiego dramatu - zwrócił się do zgromadzonych lubelski wojewoda.

## Legnica. Listonoszka nie doręczyła 1000 przesyłek. "Zakochała się i nie miała czasu"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29161288,legnica.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29161288,legnica.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-20 13:21:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7c/cf/1b/z29161340M,Zakochana-listonoszka-nie-doreczyla-1000-listow-i-.jpg" vspace="2" />Listonoszka z Legnicy (woj. dolnośląskie) nie dostarczała listów do adresatów, bo - jak tłumaczyła - worek z przesyłkami był dla niej za ciężki, a poza tym była zbyt zajęta swoim nowym ukochanym. Policjanci znaleźli u niej i jej wspólnika aż 1000 niedoręczonych przesyłek. Obojgu grozi do dwóch lat więzienia.

## Pogoda. Czy czeka nas powrót jesiennej aury? Synoptycy wyjaśniają
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29160899,pogoda-czy-czeka-nas-powrot-jesiennej-aury-synoptycy-wyjasniaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29160899,pogoda-czy-czeka-nas-powrot-jesiennej-aury-synoptycy-wyjasniaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-20 11:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8c/cf/1b/z29161100M,Czy-czeka-nas-powrot-jesieni-.jpg" vspace="2" />W nocy odnotowano ujemne temperatury niemal w całej Polsce. Synoptycy jednak zapowiadają, że od przyszłego tygodnia pogoda ma ulec zmianie. Temperatura będzie wzrastać, a opady maleć. Jak kształtują się prognozy na nadchodzący tydzień?

## Przewodów. Jak wygląda miejsce eksplozji? Kilkumetrowy lej, z budynku zostały tylko fundamenty
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29161002,przewodow-sluzby-zakonczyly-prace-na-miejscu-eksplozji-nikogo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29161002,przewodow-sluzby-zakonczyly-prace-na-miejscu-eksplozji-nikogo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-20 11:07:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/97/cf/1b/z29161111M,Przewodow--zdjecie-ilustracyjne-.jpg" vspace="2" />W Przewodowie, by ustalić okoliczności eksplozji w suszarni zbóż, pracował szereg funkcjonariuszy. Prawdopodobnie zakończyli już oni swoje działania. Na miejscu zdarzenia mogą przebywać już dziennikarze. - Dopiero z bliska widać ogrom tej tragedii - skomentował reporter TVN24.

## Gigantyczny "kret" przyciągnął tłumy w Warszawie. Na transport szykuje się Rzeszów
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29160810,rzeszow-szykuje-sie-na-transport-gigantycznej-maszyny-tbm-obnizy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29160810,rzeszow-szykuje-sie-na-transport-gigantycznej-maszyny-tbm-obnizy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-20 10:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3a/cf/1b/z29161018M,Transport-specjalny-maszyny-TBM.jpg" vspace="2" />Transport ogromnej maszyny TBM przyciągnął w Warszawie tłumy. Wiele osób zebrało się, by obejrzeć przejazd części "kreta", który wydrąży tunel na odcinku drogi ekspresowej S19 Rzeszów - Babica (woj. podkarpackie). Teraz na transport szykuje się Rzeszów. W związku z tym nawierzchnia jednej z ulic miasta zostanie tymczasowo obniżona.

## Kujawsko-pomorskie. Pożar domu jednorodzinnego. Dwie osoby nie żyją
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29160777,kujawsko-pomorskie-pozar-domu-nie-zyja-dwie-osoby.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29160777,kujawsko-pomorskie-pozar-domu-nie-zyja-dwie-osoby.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-20 09:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6c/cf/1b/z29160812M,Pozar-w-miejscowosci-Lasoty.jpg" vspace="2" />W miejscowości Lasoty (woj. kujawsko-pomorskie) doszło do pożaru domu jednorodzinnego. Dwie osoby zginęły, a jedna w stanie ciężkim przebywa w szpitalu. Sprawę bada prokuratura.


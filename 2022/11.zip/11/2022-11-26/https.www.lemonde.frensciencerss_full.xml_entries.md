# Source:Le Monde - science, URL:https://www.lemonde.fr/en/science/rss_full.xml, language:en-US

## In the Mastodon-Twitter face-off, will the mammoth crush the bird?
 - [https://www.lemonde.fr/en/science/article/2022/11/26/in-the-mastodon-twitter-face-off-will-the-mammoth-crush-the-bird_6005763_10.html](https://www.lemonde.fr/en/science/article/2022/11/26/in-the-mastodon-twitter-face-off-will-the-mammoth-crush-the-bird_6005763_10.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2022-11-26 22:05:51+00:00

Concerns about the evolution of Twitter since Elon Musk's takeover have been driving the scientific community to try out the communication network Mastodon.


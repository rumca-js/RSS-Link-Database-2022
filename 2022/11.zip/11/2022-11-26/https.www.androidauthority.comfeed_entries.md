# Source:Android Authority, URL:https://www.androidauthority.com/feed/, language:en-US

## The Pixel Watch is proof that Wear OS isn’t bad, it just needs a lot of work
 - [https://www.androidauthority.com/pixel-watch-wear-os-3238298/](https://www.androidauthority.com/pixel-watch-wear-os-3238298/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-11-26 19:00:02+00:00

Eight years in, we have a solid foundation with Google's smartwatch platform.

## Google Cyber Monday: Up to 50% off Pixel and Nest devices
 - [https://www.androidauthority.com/google-cyber-monday-3241693/](https://www.androidauthority.com/google-cyber-monday-3241693/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-11-26 17:56:12+00:00

Among many epic deals, the Google Pixel Buds A-Series just dropped to $49.99 for the first time.

## 5 Android apps you shouldn’t miss this week – Android Apps Weekly
 - [https://www.androidauthority.com/android-apps-weekly-460-3241479/](https://www.androidauthority.com/android-apps-weekly-460-3241479/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-11-26 17:00:18+00:00

Yes, there's another Sword Art Online game.

## I bought a Google Pixel in an unsupported country; here’s what you should know
 - [https://www.androidauthority.com/google-pixel-unsupported-country-3238240/](https://www.androidauthority.com/google-pixel-unsupported-country-3238240/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-11-26 15:00:48+00:00

From purchase methods to missing features and more, here's what you're getting yourself into.

## The Weekly Authority: 📱 Pixel 7’s 32-bit support
 - [https://www.androidauthority.com/the-weekly-authority-november-26-2022-222-3240960/](https://www.androidauthority.com/the-weekly-authority-november-26-2022-222-3240960/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-11-26 12:14:24+00:00

Plus all the Black Friday goodness, ongoing Twitter drama, amazing moon views from NASA's Orion, and more top tech news.

## Elon Musk threatens to build alternative to Android and iPhone. It won’t happen.
 - [https://www.androidauthority.com/elon-musk-alternative-iphone-android-3241680/](https://www.androidauthority.com/elon-musk-alternative-iphone-android-3241680/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-11-26 08:38:32+00:00

Elon Musk says he could totally build an alternative mobile platform. Don’t threaten us with a good time, Elon.

## The top 5 Sony deals of Black Friday 2022
 - [https://www.androidauthority.com/sony-deals-black-friday-3241540/](https://www.androidauthority.com/sony-deals-black-friday-3241540/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-11-26 00:06:16+00:00

Sony's Black Friday sale triggered record-low prices on some of the best headphones and earbuds on the market.


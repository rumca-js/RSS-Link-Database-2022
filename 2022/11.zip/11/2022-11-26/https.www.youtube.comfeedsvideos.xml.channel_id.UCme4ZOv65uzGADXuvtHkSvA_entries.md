# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Adwentowa Akcja NIEWIDZIALNI
 - [https://www.youtube.com/watch?v=VuMBmlUu7hY](https://www.youtube.com/watch?v=VuMBmlUu7hY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-11-27 00:00:00+00:00

Jak co roku zapraszamy, by włączyć się w Adwentową Akcję Charytatywną Fundacji Malak. "NIEWIDZIALNI” to zbiórka funduszy na rzecz problemu osamotnienia dzieci. Do Wigilii będziemy zbierać darowizny na sfinansowanie rocznej pracy 10. pedagogów ulicy oraz dofinansowanie rocznej psychoterapii dla 100. dzieci.

Akcja “NIEWIDZIALNI” wspiera organizacje zajmujące się streetworkingiem oraz współpracujące z ośrodkami i organizacjami zajmującymi się psychoterapią dziecięcą.

Wszystkie informacje na temat zbiórki znajdziecie tutaj:
→https://bit.ly/malak_niewidzialni

​ @Langustanapalmie #niewidzialni #adwent2022
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Dobranocka [#210] Dwaj synowie
 - [https://www.youtube.com/watch?v=4_NseeQMlhQ](https://www.youtube.com/watch?v=4_NseeQMlhQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-11-27 00:00:00+00:00

#dobranocka 

Bajka na dobranoc dla tych starszych dzieci. Opowiada ojciec Adam Szustak OP.

zdjęcia i montaż: Marcin Jończyk
Produkcja Serii: Sylwia Smoczyńska || Kamil Siciak

Muzyka:
Kai Engel: Brooks, z albumu Chapter Two: Mild – na licencji Creative Commons Attribution (https://creativecommons.org/licenses/...)
Źródło: http://freemusicarchive.org/music/Kai...
Wykonawca: http://www.kai-engel.com/


________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Historie potłuczone [#86] O Mai, co Boga na ławce spotkała
 - [https://www.youtube.com/watch?v=774VF9A4TF4](https://www.youtube.com/watch?v=774VF9A4TF4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-11-27 00:00:00+00:00

@Langustanapalmie   #historiepotłuczone

Historie potłuczone to opowieści o córkach i synach Boga, pięknych i brzydkich, świętych i grzesznych, szczęśliwych i na skraju rozpaczy. To opowieści o drodze, którą idzie się do nieba i o zakrętach i chaszczach, które spychają do piekła. To opowieści o ludziach po prostu. Czyli o nas.

Muzyka: Kai Engel: Brand New World, https://freemusicarchive.org/music/Kai_Engel/Sustains/Kai_Engel_-_Sustains_-_01_Brand_New_World

________________________________________
KARTKOWNIK jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.

ZNAJDZIESZ GO TU:
→ https://bit.ly/kartkownik

A pakiety są tu:
🎄🎁→ https://bit.ly/pakietylangustowe
________________________________________
Książkę "Jak się modlić?" znajdziecie tu:
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Psalmów || Psalm 40
 - [https://www.youtube.com/watch?v=Hm4SMiqYqtE](https://www.youtube.com/watch?v=Hm4SMiqYqtE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-11-27 00:00:00+00:00

śpiew: Rafał Maciejewski

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Modlitewne Inspiracje || [27] Orkiestra
 - [https://www.youtube.com/watch?v=lbJ3_fJIju4](https://www.youtube.com/watch?v=lbJ3_fJIju4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-11-27 00:00:00+00:00

@Langustanapalmie   #pompejanka #różaniec #modlimy #modlitewneinspiracje

Już od 1 listopada zapraszamy Was do wspólnej Nowenny Pompejańskiej! 

________________________________________
KARTKOWNIK jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.

ZNAJDZIESZ GO TU:
→ https://bit.ly/kartkownik

A pakiety są tu:
🎄🎁→ https://bit.ly/pakietylangustowe
________________________________________
Książkę "Jak się modlić?" znajdziecie tu:
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#316] Bóg chce cię okraść!
 - [https://www.youtube.com/watch?v=FGrGEUnV6F0](https://www.youtube.com/watch?v=FGrGEUnV6F0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-11-26 00:00:00+00:00

#cnn #dobrewiadomości   @Langustanapalmie 

Kazanko do okienka, czyli komentarz do niedzielnych czytań.

Niedziela, I Tydzień Adwentu, Rok A, I
Pierwsza Niedziela Adwentu

1. czytanie (Iz 2, 1-5)

Widzenie Izajasza, syna Amosa, dotyczące Judy i Jerozolimy:
Stanie się na końcu czasów, że góra świątyni Pańskiej stać będzie mocno na szczycie gór i wystrzeli ponad pagórki. Wszystkie narody do niej popłyną, mnogie ludy pójdą i rzekną: «Chodźcie, wstąpmy na górę Pańską, do świątyni Boga Jakuba! Niech nas nauczy dróg swoich, byśmy kroczyli Jego ścieżkami. Bo Prawo pochodzi z Syjonu i słowo Pańskie – z Jeruzalem».
On będzie rozjemcą pomiędzy ludami i sędzią dla licznych narodów. Wtedy swe miecze przekują na lemiesze, a swoje włócznie na sierpy. Naród przeciw narodowi nie podniesie miecza, nie będą się więcej zaprawiać do wojny. Chodźcie, domu Jakuba, postępujmy w światłości Pańskiej!

2. czytanie (Rz 13, 11-14)

Bracia:
Rozumiejcie chwilę obecną: teraz nadeszła dla was godzina powstania ze snu. Teraz bowiem zbawienie jest bliżej nas niż wtedy, gdy uwierzyliśmy.
Noc się posunęła, a przybliżył się dzień. Odrzućmy więc uczynki ciemności, a przyobleczmy się w zbroję światła! Żyjmy przyzwoicie jak w jasny dzień: nie w hulankach i pijatykach, nie w rozpuście i wyuzdaniu, nie w kłótni i zazdrości. Ale przyobleczcie się w Pana Jezusa Chrystusa i nie troszczcie się zbytnio o ciało, dogadzając żądzom.

Ewangelia (Mt 24, 37-44)

Jezus powiedział do swoich uczniów:
«Jak było za dni Noego, tak będzie z przyjściem Syna Człowieczego. Albowiem jak w czasie przed potopem jedli i pili, żenili się i za mąż wydawali aż do dnia, kiedy Noe wszedł do arki, i nie spostrzegli się, aż przyszedł potop i pochłonął wszystkich, tak również będzie z przyjściem Syna Człowieczego. Wtedy dwóch będzie w polu: jeden będzie wzięty, drugi zostawiony. Dwie będą mleć na żarnach: jedna będzie wzięta, druga zostawiona.
Czuwajcie więc, bo nie wiecie, w którym dniu Pan wasz przyjdzie. A to rozumiejcie: Gdyby gospodarz wiedział, o jakiej porze nocy nadejdzie złodziej, na pewno by czuwał i nie pozwoliłby włamać się do swego domu. Dlatego i wy bądźcie gotowi, bo o godzinie, której się nie domyślacie, Syn Człowieczy przyjdzie».
________________________________________

Niedzielnik*. Komentarze do czytań na Rok A:
→ https://wdrodze.pl/produkt/niedzielnik-a-komentarze-do-czytan/
________________________________________
KARTKOWNIK jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.

ZNAJDZIESZ GO TU:
→ https://bit.ly/kartkownik

A pakiety są tu:
🎄🎁→ https://bit.ly/pakietylangustowe
________________________________________
Książkę "Jak się modlić?" znajdziecie tu:
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste
________________________________________

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Księga Psalmów || Psalm 39
 - [https://www.youtube.com/watch?v=1JXZfN2q72o](https://www.youtube.com/watch?v=1JXZfN2q72o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-11-26 00:00:00+00:00

śpiew: Rafał Maciejewski

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
KARTKOWNIK jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.

ZNAJDZIESZ GO TU:
→ https://bit.ly/kartkownik

A pakiety są tu:
🎄🎁→ https://bit.ly/pakietylangustowe
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Modlitewne Inspiracje || [26] Roztargnienia
 - [https://www.youtube.com/watch?v=l7aN-sefkHg](https://www.youtube.com/watch?v=l7aN-sefkHg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-11-26 00:00:00+00:00

@Langustanapalmie    #pompejanka #różaniec #modlimy #modlitewneinspiracje

Już od 1 listopada zapraszamy Was do wspólnej Nowenny Pompejańskiej! 

________________________________________
KARTKOWNIK jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.

ZNAJDZIESZ GO TU:
→ https://bit.ly/kartkownik

A pakiety są tu:
🎄🎁→ https://bit.ly/pakietylangustowe
________________________________________
Książkę "Jak się modlić?" znajdziecie tu:
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#1260] Poprawa
 - [https://www.youtube.com/watch?v=UJSaWgA37_Y](https://www.youtube.com/watch?v=UJSaWgA37_Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-11-26 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
KARTKOWNIK jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.

ZNAJDZIESZ GO TU:
→ https://bit.ly/kartkownik

A pakiety są tu:
🎄🎁→ https://bit.ly/pakietylangustowe
________________________________________
Książkę "Jak się modlić?" znajdziecie tu:
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.


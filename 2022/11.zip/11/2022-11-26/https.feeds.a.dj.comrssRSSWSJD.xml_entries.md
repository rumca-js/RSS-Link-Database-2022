# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Musk Champions Twitter Fact-Checking Feature
 - [https://www.wsj.com/articles/elon-musk-champions-twitter-fact-checking-feature-that-corrects-him-11669436937?mod=rss_Technology](https://www.wsj.com/articles/elon-musk-champions-twitter-fact-checking-feature-that-corrects-him-11669436937?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2022-11-26 13:00:00+00:00

Community Notes, which uses an algorithm to combat false and misleading information, has corrected tweets from the new platform owner himself.

## The Children Making Millions on YouTube
 - [https://www.wsj.com/articles/youtube-vlad-niki-like-nastya-kids-diana-show-11669412051?mod=rss_Technology](https://www.wsj.com/articles/youtube-vlad-niki-like-nastya-kids-diana-show-11669412051?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2022-11-26 05:00:00+00:00

Vlad, Niki, Diana and Nastya party on yachts, ride in Ferraris and travel the world. Their massive audience of fellow kids can’t get enough.

## U.S. Expands Bans of Chinese Security Cameras, Network Equipment
 - [https://www.wsj.com/articles/u-s-expands-bans-of-chinese-security-cameras-network-equipment-11669407355?mod=rss_Technology](https://www.wsj.com/articles/u-s-expands-bans-of-chinese-security-cameras-network-equipment-11669407355?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2022-11-26 02:16:00+00:00

The Federal Communications Commission voted to ban sales of new telecom and surveillance equipment made by several Chinese companies, arguing that their ownership and practices threaten U.S. national security.


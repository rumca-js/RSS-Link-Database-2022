# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Sondaż: PiS najlepiej spełni obietnice wyborcze
 - [https://wydarzenia.interia.pl/kraj/news-sondaz-pis-najlepiej-spelni-obietnice-wyborcze,nId,6436087](https://wydarzenia.interia.pl/kraj/news-sondaz-pis-najlepiej-spelni-obietnice-wyborcze,nId,6436087)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-11-26 21:43:30+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sondaz-pis-najlepiej-spelni-obietnice-wyborcze,nId,6436087"><img align="left" alt="Sondaż: PiS najlepiej spełni obietnice wyborcze" src="https://i.iplsc.com/sondaz-pis-najlepiej-spelni-obietnice-wyborcze/000GEFXGVLE7SDIF-C321.jpg" /></a>35 procent Polaków twierdzi, że PiS to partia, która najlepiej spełni wyborcze obietnice. Opozycja uzyskała nieco ponad 18 procent głosów - wynika z najnowszego sondażu United Surveys dla Wirtualnej Polski.</p><br clear="all" />


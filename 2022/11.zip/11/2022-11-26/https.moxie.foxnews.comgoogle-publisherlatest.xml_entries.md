# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Alyssa Milano blasted by conservatives, Elon Musk after trading in Tesla for Volkswagen: 'Founded by Nazis'
 - [https://www.foxnews.com/entertainment/alyssa-milano-blasted-conservatives-elon-musk-trading-tesla-volkswagen-founded-nazis](https://www.foxnews.com/entertainment/alyssa-milano-blasted-conservatives-elon-musk-trading-tesla-volkswagen-founded-nazis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 23:59:11+00:00

Actress Alyssa Milano was mocked by conservatives and Elon Musk after saying she got rid of her Tesla and replaced with with a Volkswagen due to Twitter's business model.

## Republicans, ahead of House takeover, look to zero in on Biden admin's handling of border crisis
 - [https://www.foxnews.com/politics/republicans-ahead-house-takeover-look-zero-biden-admins-handling-border-crisis](https://www.foxnews.com/politics/republicans-ahead-house-takeover-look-zero-biden-admins-handling-border-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 23:47:03+00:00

House Republicans are looking to ramp up the pressure on the Biden administration when they take control of the House of Representatives early next year.

## Trump's former US ambassador to Israel blasts meeting with Ye, Nick Fuentes: 'You are better than this'
 - [https://www.foxnews.com/politics/trumps-former-us-ambassador-israel-blasts-meeting-ye-nick-fuentes](https://www.foxnews.com/politics/trumps-former-us-ambassador-israel-blasts-meeting-ye-nick-fuentes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 23:41:10+00:00

Jewish leaders are slamming former President Trump after he hosted a dinner in Florida this week that included rapper Ye and controversial political activist Nick Fuentes.

## Greta Thunberg joins lawsuit against Swedish government alleging 'insufficient' climate policies
 - [https://www.foxnews.com/world/greta-thunberg-joins-lawsuit-against-swedish-government-alleging-climate-inaction](https://www.foxnews.com/world/greta-thunberg-joins-lawsuit-against-swedish-government-alleging-climate-inaction)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 23:03:33+00:00

Teenage climate activist Greta Thunberg has joined in on a lawsuit against the government of Sweden alleging inaction on climate change that violates its Constitution.

## Abraham Lincoln statue vandalized in Chicago
 - [https://www.foxnews.com/us/abraham-lincoln-statue-vandalized-chicago](https://www.foxnews.com/us/abraham-lincoln-statue-vandalized-chicago)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 22:52:29+00:00

Two statues of Lincoln in Chicago have now been defaced in relation to Lincolns role in the Sioux uprisings and his authorization of the execution of some Dakota men.

## Chicago crime crisis: 7 carjackings reported in 1 hour on West Side
 - [https://www.foxnews.com/us/chicago-crime-crisis-7-carjackings-reported-1-hour-west-side](https://www.foxnews.com/us/chicago-crime-crisis-7-carjackings-reported-1-hour-west-side)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 22:50:53+00:00

Seven carjackings were reported on Chicago's West Side in one hour on Friday morning amid a crime spike in the Windy City.

## MSNBC’s Chris Hayes frets his ‘worst fears' have been realized since Musk acquired Twitter
 - [https://www.foxnews.com/media/msnbcs-chris-hayes-frets-worst-fears-have-been-realized-since-musk-acquired-twitter](https://www.foxnews.com/media/msnbcs-chris-hayes-frets-worst-fears-have-been-realized-since-musk-acquired-twitter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 22:06:50+00:00

MSNBC's Chris Hayes complained about Elon Musk's handling of Twitter in an guest essay for the New York Times, saying his "worst fears" have been realized.

## Christmas market crowd sent scrambling after driver plows car into pedestrian area: UK police say
 - [https://www.foxnews.com/world/christmas-market-crowd-sent-scrambling-driver-plows-car-pedestrian-area-uk-police-say](https://www.foxnews.com/world/christmas-market-crowd-sent-scrambling-driver-plows-car-pedestrian-area-uk-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 22:01:08+00:00

A car allegedly drove into a Christmas market with hundreds of shoppers in a small town in England Saturday afternoon. No one was hurt, police said.

## South Carolina upsets No. 8 Clemson, all but ending Tigers' CFP hopes
 - [https://www.foxnews.com/sports/south-carolina-upsets-no-8-clemson-all-but-ending-tigers-cfp-hopes](https://www.foxnews.com/sports/south-carolina-upsets-no-8-clemson-all-but-ending-tigers-cfp-hopes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 22:00:17+00:00

The South Carolina Gamecocks upset No. 7 Clemson on Saturday, effectively ending any chance for the Tigers to make the College Football Playoff.

## Idaho cops on college murder mystery grind out overtime as two-week mark nears without a suspect
 - [https://www.foxnews.com/us/idaho-cops-college-murder-mystery-grind-out-overtime-two-week-mark-nears-without-suspect](https://www.foxnews.com/us/idaho-cops-college-murder-mystery-grind-out-overtime-two-week-mark-nears-without-suspect)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 21:43:44+00:00

Four University of Idaho students were found stabbed to death at a rental house just yards off campus. Police have been working around the clock for days.

## No. 1 Georgia finishes strong to remain undefeated, beats Georgia Tech for fifth straight time
 - [https://www.foxnews.com/sports/no-1-georgia-finishes-strong-to-remain-undefeated-beats-georgia-tech-37-14](https://www.foxnews.com/sports/no-1-georgia-finishes-strong-to-remain-undefeated-beats-georgia-tech-37-14)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 21:28:20+00:00

Despite a slim three-point halftime lead, the top-ranked Georgia Bulldogs were able to overcome a sluggish start and scored 37 unanswered points to beat Georgia Tech.

## No. 3 Michigan dominates No. 2 Ohio State in Columbus, keeping national championship hopes alive
 - [https://www.foxnews.com/sports/no-3-michigan-dominates-no-2-ohio-state-columbus-keeping-national-championship-hopes-alive](https://www.foxnews.com/sports/no-3-michigan-dominates-no-2-ohio-state-columbus-keeping-national-championship-hopes-alive)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 21:23:09+00:00

The third-ranked Michigan Wolverines outscored No. 2 Ohio State 28-3 in the second half en route to a dominant win on the road, keeping their championship hopes alive.

## England's players take a knee before kickoff in World Cup match against the US
 - [https://www.foxnews.com/sports/england-takes-a-knee-before-kickoff-in-world-cup-match-against-the-us](https://www.foxnews.com/sports/england-takes-a-knee-before-kickoff-in-world-cup-match-against-the-us)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 20:46:50+00:00

For the second time in the 2022 World Cup, The Three Lions took a knee before the start of a match. English players demonstrated briefly before kicking off against the US.

## CIA analyst decries free speech 'nonsense' on Musk's Twitter, claims it will benefit Russian disinformation
 - [https://www.foxnews.com/media/cia-analyst-decries-free-speech-nonsense-musk-twitter-claims-benefit-russian-disinformation](https://www.foxnews.com/media/cia-analyst-decries-free-speech-nonsense-musk-twitter-claims-benefit-russian-disinformation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 20:43:19+00:00

CIA analyst Bob Baer claimed that Elon Musk's new strategies for running Twitter will benefit Russian hackers and Russian President Vladimir Putin.

## Cristiano Ronaldo receives $225 million offer to play for Saudi Arabian team
 - [https://www.foxnews.com/sports/cristiano-ronaldo-receives-225-million-offer-play-saudi-arabian-team](https://www.foxnews.com/sports/cristiano-ronaldo-receives-225-million-offer-play-saudi-arabian-team)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 20:42:33+00:00

Just a few days after parting ways with Manchester United, Cristiano Ronaldo has been given an historic offer to play for a top club in Saudi Arabia.

## Bronx mom blasts NYC crime after teen daughter is shot on Thanksgiving: 'It's out of control'
 - [https://www.foxnews.com/us/bronx-mom-teen-daughter-shot-pick-up-sugar-thanksgiving-out-control](https://www.foxnews.com/us/bronx-mom-teen-daughter-shot-pick-up-sugar-thanksgiving-out-control)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 19:51:25+00:00

A mother railed against crime in New York City after her 14-year-old daughter was shot in the Bronx while on her way to pick up sugar for family's Thanksgiving meal.

## Lane Kiffin says money was never a factor in decision to stay at Ole Miss
 - [https://www.foxnews.com/sports/lane-kiffin-money-never-factor-decision-stay-ole-miss](https://www.foxnews.com/sports/lane-kiffin-money-never-factor-decision-stay-ole-miss)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 19:47:33+00:00

University of Mississippi coach Lane Kiffin spoke to OutKick about his decision to stay with the Rebels after rumors swirled he was taking the Auburn head coaching job.

## Chinese authorities loosen COVID-19 restrictions in some neighborhoods after protests
 - [https://www.foxnews.com/world/chinese-authorities-loosen-covid-19-restrictions-neighborhoods-protests](https://www.foxnews.com/world/chinese-authorities-loosen-covid-19-restrictions-neighborhoods-protests)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 19:35:23+00:00

China's zero-COVID policy has caused significant backlash following a number of incidents that could have been avoided if not for draconian lockdown policies.

## Teen smugglers lead Texas police on high-speed chase after illegal immigrants bail from vehicle
 - [https://www.foxnews.com/us/teen-smugglers-texas-police-high-speed-chase-illegal-immigrants-bail-vehicle](https://www.foxnews.com/us/teen-smugglers-texas-police-high-speed-chase-illegal-immigrants-bail-vehicle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 19:15:56+00:00

A 16-year-old driver led Texas Department of Public Safety troopers on a high-speed chase after illegal immigrants bailed from his vehicle, authorities said.

## Ex-Mets pitcher, free-agent Trevor Williams, attempts to woo MLB teams with ‘Black Friday' advertisement
 - [https://www.foxnews.com/sports/mlb-free-agent-pitcher-trevor-williams-creates-black-friday-ad-to-woo-teams](https://www.foxnews.com/sports/mlb-free-agent-pitcher-trevor-williams-creates-black-friday-ad-to-woo-teams)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 19:14:39+00:00

In the spirit of Black Friday, former Mets pitcher and current free agent Trevor Williams decided to have his very own sale. Williams offered up himself in a 2-for-1 package.

## Idaho murders: Was Kaylee Goncalves the killer's main target? Police respond
 - [https://www.foxnews.com/us/idaho-murders-was-kaylee-goncalves-killers-main-target-police-respond](https://www.foxnews.com/us/idaho-murders-was-kaylee-goncalves-killers-main-target-police-respond)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 19:07:56+00:00

Police reveal new details about why they believe the slayings of four University of Idaho students in their sleep in mid-November was a "targeted" attack.

## Biden says family 'not having any' 2024 conversations in Nantucket
 - [https://www.foxnews.com/politics/biden-family-not-having-any-2024-conversations-nantucket](https://www.foxnews.com/politics/biden-family-not-having-any-2024-conversations-nantucket)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 18:35:21+00:00

President Biden said on Saturday that his family were celebrating rather than having conversations about a 2024 presidential bid while on vacation in Nantucket.

## Georgia runoff elections designed to ‘keep Black candidates out of office,’ claims MSNBC
 - [https://www.foxnews.com/media/georgia-runoff-elections-designed-keep-black-candidates-out-office-claims-msnbc](https://www.foxnews.com/media/georgia-runoff-elections-designed-keep-black-candidates-out-office-claims-msnbc)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 18:16:55+00:00

MSNBC show "Velshi" delved into the alleged racist origins of Georgia's runoff election system, claiming it was created to keep Black people from power.

## Florida man accused of killing couple, biting victim's face to go to trial as judge weighs insanity plea
 - [https://www.foxnews.com/us/florida-man-accused-killing-couple-biting-victim-face-face-trial-judge-weighs-insanity-plea](https://www.foxnews.com/us/florida-man-accused-killing-couple-biting-victim-face-face-trial-judge-weighs-insanity-plea)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 18:15:00+00:00

Austin Harrouff, a former college student who randomly killed a Florida couple in their garage six years ago and chewed on a victim's face, goes to trial on Monday.

## US ambassador to Ukraine tells Fox: Russia guilty of war crimes
 - [https://www.foxnews.com/world/us-ambassador-ukraine-tells-fox-russia-guilty-war-crimes](https://www.foxnews.com/world/us-ambassador-ukraine-tells-fox-russia-guilty-war-crimes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 18:05:08+00:00

US Ambassador to Ukraine Bridget Brink faces a tall task as Russia has invaded Ukraine for over nine months. Brink has specialized in Europe throughout her 25-year career.

## Iran protests: UN Human Rights Council votes to investigate regime's violent response
 - [https://www.foxnews.com/world/iran-protests-un-human-rights-council-votes-investigate-regimes-violent-response](https://www.foxnews.com/world/iran-protests-un-human-rights-council-votes-investigate-regimes-violent-response)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 17:52:40+00:00

The UN Human Rights Council has faced accusations of not living up to its mission after failing to pass a motion to investigate China's treatment of its Uyghur population.

## Idaho state crime lab prioritizes evidence testing in college students' brutal murder case
 - [https://www.foxnews.com/us/idaho-state-crime-lab-prioritizes-evidence-testing-college-students-brutal-murder-case](https://www.foxnews.com/us/idaho-state-crime-lab-prioritizes-evidence-testing-college-students-brutal-murder-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 17:30:12+00:00

The Idaho State Police Forensic Services has prioritized testing of evidence from the Moscow home where four University of Idaho students were murdered on Nov. 13.

## China sentences Chinese-Canadian pop star Kris Wu to 13 years for sex crimes
 - [https://www.foxnews.com/entertainment/china-sentences-chinese-canadian-pop-star-kris-wu-13-years-sex-crimes](https://www.foxnews.com/entertainment/china-sentences-chinese-canadian-pop-star-kris-wu-13-years-sex-crimes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 17:29:58+00:00

Beijing’s Chaoyang District Court has sentenced Chinese Canadian pop star Kris Wu to more than a decade in prison for several sex crimes, including rape and repeatedly luring underage girls.

## Meta's VR gamble: How do holiday headset prices compare?
 - [https://www.foxnews.com/tech/meta-vr-gamble-holiday-headset-prices](https://www.foxnews.com/tech/meta-vr-gamble-holiday-headset-prices)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 17:22:03+00:00

Meta said earlier this month that it would shift resources to the metaverse, firing thousands of employees. Is its virtual reality headset worth the price?

## 'Chrisley Knows Best' stars Julie and Todd Chrisley open up about 'living in fear' ahead of sentencing
 - [https://www.foxnews.com/entertainment/chrisley-knows-best-stars-julie-todd-chrisley-living-fear-sentencing](https://www.foxnews.com/entertainment/chrisley-knows-best-stars-julie-todd-chrisley-living-fear-sentencing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 17:11:28+00:00

Reality television stars Todd and Julie Chrisley got candid about "living through a nightmare" on the "Chrisley Confessions" podcast ahead of their sentencing.

## Matt Rhule hired as Nebraska football head coach, agrees to eight-year contract
 - [https://www.foxnews.com/sports/matt-rhule-officially-hired-as-nebraska-football-head-coach](https://www.foxnews.com/sports/matt-rhule-officially-hired-as-nebraska-football-head-coach)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 17:09:31+00:00

Former Carolina Panthers coach Matt Rhule has taken the job of leading Nebraska's football program. The school announced his arrival on Saturday.

## White House slams Trump's dinner with Nick Fuentes, saying bigotry and hate have 'no place in America'
 - [https://www.foxnews.com/politics/white-house-slams-trumps-dinner-nick-fuentes-saying-bigotry-hate-no-place-america](https://www.foxnews.com/politics/white-house-slams-trumps-dinner-nick-fuentes-saying-bigotry-hate-no-place-america)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 16:44:43+00:00

The White House on Saturday took aim at former President Donald Trump for hosting white nationalist Nick Fuentes at his private club in Florida on Tuesday evening.

## European officials say US profiting from Ukraine war, call Inflation Reduction Act 'very worrying'
 - [https://www.foxnews.com/world/european-officials-says-us-profiting-ukraine-war-call-inflation-reduction-act-very-worrying](https://www.foxnews.com/world/european-officials-says-us-profiting-ukraine-war-call-inflation-reduction-act-very-worrying)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 16:38:31+00:00

Top European officials expressed frustration and outrage toward President Joe Biden's green energy policies amid the ongoing war in Ukraine.

## Indiana police officer and his wife adopt infant girl abandoned in 'baby box'
 - [https://www.foxnews.com/lifestyle/indiana-police-officer-wife-adopt-infant-girl-abandoned-baby-box](https://www.foxnews.com/lifestyle/indiana-police-officer-wife-adopt-infant-girl-abandoned-baby-box)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 16:18:09+00:00

An Indiana police officer and his wife opened their homes to Myah, a child found abandoned in a "baby box" when she was one day old. They shared their story on "Fox & Friends Weekend."

## Florida doctor accused of sexually assaulting multiple women under anesthesia at ritzy cosmetic studio
 - [https://www.foxnews.com/us/florida-doctor-accused-sexually-assaulting-multiple-women-under-anesthesia-ritzy-cosmetic-studio](https://www.foxnews.com/us/florida-doctor-accused-sexually-assaulting-multiple-women-under-anesthesia-ritzy-cosmetic-studio)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 16:12:18+00:00

Cosmetic doctor Eric Salata has been accused of sexually assaulting multiple victims who were under anesthesia at his Naples, Florida, medical spa location.

## Daylight Savings Time 'disproportionately' impacts 'communities of color,' insists CNN article
 - [https://www.foxnews.com/media/daylight-savings-time-disproportionately-impacts-communities-color-insists-cnn-article](https://www.foxnews.com/media/daylight-savings-time-disproportionately-impacts-communities-color-insists-cnn-article)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 16:12:05+00:00

A recent CNN article argued that Daylight Savings Time is more harmful to the health and wellness of minority communities than it is to White people.

## NBA wife blasts Charlotte Hornets, claims team downplayed the severity of Gordon Hayward’s injury
 - [https://www.foxnews.com/sports/nba-wife-blasts-phoenix-suns-amid-gordon-haywards-mysterious-injury](https://www.foxnews.com/sports/nba-wife-blasts-phoenix-suns-amid-gordon-haywards-mysterious-injury)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 15:44:24+00:00

Gordon Hayward's agent told ESPN that his client had suffered a fractured left shoulder, but Hayward was ruled out of a game with what the Hornets labeled a "shoulder contusion."

## Newsom won't challenge Biden in 2024, says he is 'all in' on president's re-election
 - [https://www.foxnews.com/politics/newsom-wont-challenge-biden-2024-says-he-all-in-president-re-election](https://www.foxnews.com/politics/newsom-wont-challenge-biden-2024-says-he-all-in-president-re-election)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 15:29:45+00:00

California Gov. Gavin Newsom is ruling out a challenge to President Biden for the 2024 Democratic nomination, telling Biden that he is "all in" on his re-election race.

## Hubble Space Telescope image shows galaxies merge 671M light-years away
 - [https://www.foxnews.com/science/hubble-space-telescope-image-galaxies-merge-light-years-away](https://www.foxnews.com/science/hubble-space-telescope-image-galaxies-merge-light-years-away)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 15:04:37+00:00

Scientists at NASA and the European Space Agency released an image of merging galaxies captured by the Hubble Space Telescope's Advanced Camera for Surveys.

## 'PANDEMIC OF VIOLENCE': Lightfoot's record on crime at the forefront of Chicago mayoral election
 - [https://www.foxnews.com/politics/pandemic-violence-lightfoots-record-crime-forefront-chicago-mayoral-election](https://www.foxnews.com/politics/pandemic-violence-lightfoots-record-crime-forefront-chicago-mayoral-election)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 14:56:31+00:00

The Chicago mayoral election features a number of candidates and comes amid a spike in crime as incumbent Mayor Lori Lightfoot seeks to retain her post leading the city.

## Landslide on Italian island leaves up to a dozen missing
 - [https://www.foxnews.com/world/landslide-italian-island-leaves-dozen-missing](https://www.foxnews.com/world/landslide-italian-island-leaves-dozen-missing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 14:44:48+00:00

12 people were reported missing and over 100 stranded after rainfall led to landslides and collapsed at least 10 buildings on the Italian Island of Ischia.

## Matt Whitaker: "I don't have any reason to believe there's enough evidence to indict President Trump."
 - [https://www.foxnews.com/politics/matt-whitaker-dont-have-any-reason-believe-theres-enough-evidence-indict-president-trump](https://www.foxnews.com/politics/matt-whitaker-dont-have-any-reason-believe-theres-enough-evidence-indict-president-trump)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 14:16:33+00:00

Former acting Attorney General Matt Whitaker analyzes the Justice Department's special counsel probe and the legal fight to extend Title 42 expulsions.

## Irene Cara, 'Flashdance,' 'Fame' singer, dead at 63
 - [https://www.foxnews.com/entertainment/irene-cara-flashdance-fame-singer-dead-63](https://www.foxnews.com/entertainment/irene-cara-flashdance-fame-singer-dead-63)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 14:13:53+00:00

"Fame" and "Flashdance...What a Feeling" singer Irene Cara has died at the age of 63. Her publicist confirmed in a statement posted on her official social media account.

## Canada's Trudeau defends using emergency powers to shut down Freedom Convoy protests
 - [https://www.foxnews.com/world/canada-trudeau-defends-emergency-powers-shut-down-freedom-convoy-protests](https://www.foxnews.com/world/canada-trudeau-defends-emergency-powers-shut-down-freedom-convoy-protests)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 14:09:35+00:00

Canadian Prime Minister Justin Trudeau defended his use of emergency powers to end the Freedom Convoy trucker protests against COVID-19 vaccine mandates on Friday.

## Holiday stress is here: How to have a calmer, more peaceful next few months
 - [https://www.foxnews.com/lifestyle/holiday-stress-have-calmer-peaceful-months](https://www.foxnews.com/lifestyle/holiday-stress-have-calmer-peaceful-months)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 14:00:22+00:00

Author Lisa Boucher of Ohio, whose new book is "Pray. Trust. Ride," shared advice for managing stress during the holidays — and offered tips for remaining healthy, calm and centered.

## ‘Sunset Boulevard’ star Nancy Olson Livingston recalls 'daring script,' meeting Marilyn Monroe and Walt Disney
 - [https://www.foxnews.com/entertainment/sunset-boulevard-star-nancy-olson-livingston-recalls-daring-script-meeting-marilyn](https://www.foxnews.com/entertainment/sunset-boulevard-star-nancy-olson-livingston-recalls-daring-script-meeting-marilyn)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 13:00:52+00:00

Nancy Olson Livingston, who starred in classic Hollywood films "Sunset Boulevard" and Disney's "Pollyanna," has written a memoir titled "A Front Row Seat."

## Media become scandal-deniers when it comes to Biden
 - [https://www.foxnews.com/opinion/media-become-scandal-deniers-biden](https://www.foxnews.com/opinion/media-become-scandal-deniers-biden)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 13:00:35+00:00

The AP says it's "an independent global news organization dedicated to factual reporting," but it seems more like a Democrat-dependent organization.

## Former Tripwire CEO looks back on being canceled and forced to step down from company over pro-life tweet
 - [https://www.foxnews.com/media/former-tripwire-ceo-looks-back-canceled-forced-step-down-from-company-over-pro-life-tweet](https://www.foxnews.com/media/former-tripwire-ceo-looks-back-canceled-forced-step-down-from-company-over-pro-life-tweet)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 13:00:09+00:00

Ex-CEO of Tripwire reveals how 'cancel culture' forced him out of his own company after tweeting that he was pro-life on 'Tucker Carlson Today.'

## Lithuanian Foreign Minister: 'No greater threat' than Russia, seeks to preserve 'global rules-based order'
 - [https://www.foxnews.com/world/lithuanian-foreign-minister-no-greater-threat-than-russia-seeks-to-preserve-global-rules-based-order](https://www.foxnews.com/world/lithuanian-foreign-minister-no-greater-threat-than-russia-seeks-to-preserve-global-rules-based-order)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 13:00:01+00:00

Lithuania has faced retaliation from China over Taiwan, facing import discrimination after allowing Taipei to open a trade office in the city of Vilnius.

## 5 things I wish I knew when my wife was diagnosed with Alzheimer’s
 - [https://www.foxnews.com/opinion/5-things-i-wish-i-knew-when-my-wife-was-diagnosed-with-alzheimers](https://www.foxnews.com/opinion/5-things-i-wish-i-knew-when-my-wife-was-diagnosed-with-alzheimers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 12:00:41+00:00

5 things I wish I knew as a husband and caregiver when my wife was diagnosed with Alzheimer’s. She remained a wonderful person, but she was not the same person.

## One-year-old hound mix is looking for loving new home in New York: ‘Outgoing and playful’
 - [https://www.foxnews.com/lifestyle/one-year-old-hound-mix-looking-home-new-york-outgoing-playful](https://www.foxnews.com/lifestyle/one-year-old-hound-mix-looking-home-new-york-outgoing-playful)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 12:00:06+00:00

One-year-old hound mix Kit needs a new family. He's full of playful energy and is currently up for adoption at the Animal Rescue Fund of the Hamptons in New York.

## Producer of new aerial war epic 'Devotion' details the inspirational true story behind the film
 - [https://www.foxnews.com/media/producer-aerial-war-epic-devotion-details-inspirational-true-story-film](https://www.foxnews.com/media/producer-aerial-war-epic-devotion-details-inspirational-true-story-film)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 11:00:37+00:00

"Devotion" producer Molly Smith discusses her upcoming film that looks back at the pivotal events that helped shape the outcome in the Korean War with Fox News' Bret Baier.

## College Football Week 13 preview: Everything on the line as Michigan visits Ohio State
 - [https://www.foxnews.com/sports/college-football-week-13-preview-everything-line-michigan-visits-ohio-state](https://www.foxnews.com/sports/college-football-week-13-preview-everything-line-michigan-visits-ohio-state)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 11:00:29+00:00

Week 13 of the college football season features three games between top-25 teams on Saturday with No. 2 Ohio State and No. 3 Michigan kicking off the day.

## Florida man arrested for attempted murder after woman rushed to hospital with hatchet protruding from head
 - [https://www.foxnews.com/us/florida-man-arrested-attempted-murder-woman-rushed-hospital-hatchet-protruding-head](https://www.foxnews.com/us/florida-man-arrested-attempted-murder-woman-rushed-hospital-hatchet-protruding-head)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 09:30:16+00:00

A Florida man was arrested after a woman was rushed to the hospital with a hatchet protruding from her head. The suspect was charged with Attempted Second Degree Murder.

## Idaho investigators rule out connection between college murders and other unsolved stabbings
 - [https://www.foxnews.com/us/idaho-investigators-rule-out-connection-between-college-murders-and-other-unsolved-stabbings](https://www.foxnews.com/us/idaho-investigators-rule-out-connection-between-college-murders-and-other-unsolved-stabbings)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 09:14:50+00:00

Detectives looking into a quadruple homicide of a group of University of Idaho students have ruled out a connection between the attack and two other similar stabbings.

## Focus on the Family in Colorado vandalized with graffiti days after Club Q tragedy: 'Blood is on your hands'
 - [https://www.foxnews.com/us/focus-family-colorado-vandalized-graffiti-days-after-club-q-tragedy](https://www.foxnews.com/us/focus-family-colorado-vandalized-graffiti-days-after-club-q-tragedy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 09:03:27+00:00

Focus on the Family, a prominent Christian organization in Colorado Springs, was vandalized on Thanksgiving Day with a message tying the facility to the Club Q shooting.

## Musk torpedoes Axios report on 'lives at risk' over reinstating Twitter accounts: 'Much ado about nothing'
 - [https://www.foxnews.com/media/musk-jordan-peterson-others-rip-axios-report-on-lives-risk-musk-reinstating-accounts](https://www.foxnews.com/media/musk-jordan-peterson-others-rip-axios-report-on-lives-risk-musk-reinstating-accounts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 09:00:43+00:00

Twitter users hounded an Axios report from Thursday voicing the concerns of "activists" claiming Musk's handling of Twitter may put "lives at risk"

## At least 1 dead, several others injured at Danny Ocean concert in Mexico
 - [https://www.foxnews.com/entertainment/at-least-1-dead-several-others-injured-danny-ocean-concert-mexico](https://www.foxnews.com/entertainment/at-least-1-dead-several-others-injured-danny-ocean-concert-mexico)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 08:18:58+00:00

A shooting Friday night at a Danny Ocean concert in Mexico left at least 1 person dead and another 10 people injured. One person has been arrested.

## Joe and Hunter Biden go Black Friday shopping as Republicans prepare investigations into business deals
 - [https://www.foxnews.com/politics/joe-hunter-biden-black-friday-shopping-republicans-prepare-investigations-into-business-deals](https://www.foxnews.com/politics/joe-hunter-biden-black-friday-shopping-republicans-prepare-investigations-into-business-deals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 07:01:31+00:00

President Joe Biden spent Black Friday shopping with his family, including his son Hunter Biden. They visited several stores on the Massachusetts island of Nantucket.

## What's the best tailgate food? Georgia football fans share their favorites
 - [https://www.foxnews.com/us/best-tailgate-food-georgia-football-fans-share-favorites](https://www.foxnews.com/us/best-tailgate-food-georgia-football-fans-share-favorites)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 07:00:41+00:00

Football fans at the University of Georgia put their best food forward when they tailgate. From jambalaya to Chick-fil-A, these are their favorite game day staples.

## America's only hope is God, says Sean Feucht, Christian singer-activist: Nation is 'morally bankrupt'
 - [https://www.foxnews.com/lifestyle/america-hope-god-sean-feucht-christian-singer-nation-morally-bankrupt](https://www.foxnews.com/lifestyle/america-hope-god-sean-feucht-christian-singer-nation-morally-bankrupt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 07:00:22+00:00

Worship artist Sean Feucht of California plans a 50-state "Kingdom to the Capitol" tour in 2023 to pray in each state and influence change. He says God is nation's "only hope."

## FOX Bet Super 6: Michigan-Ohio State BIG Noon Saturday $25,000 jackpot
 - [https://www.foxnews.com/sports/fox-bet-super-6-michigan-ohio-state-big-noon-saturday-25000-jackpot](https://www.foxnews.com/sports/fox-bet-super-6-michigan-ohio-state-big-noon-saturday-25000-jackpot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 06:09:15+00:00

Players could win $25,000 during rivalry week as Michigan and Ohio State each enter this weekend's contest with a perfect 11-0 record. Players pick six different outcomes.

## TUCKER CARLSON: All prosperity in this country depends ultimately on energy
 - [https://www.foxnews.com/opinion/tucker-carlson-prosperity-country-depends-ultimately-energy](https://www.foxnews.com/opinion/tucker-carlson-prosperity-country-depends-ultimately-energy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 05:51:11+00:00

Fox News host Tucker Carlson voices his concerns about Americans dealing with record-high inflation as well as policies that make energy costs rise on "Tucker Carlson Tonight."

## Sean Duffy: What haven't we had a shortage of under Biden?
 - [https://www.foxnews.com/media/sean-duffy-what-havent-we-had-shortage-under-biden](https://www.foxnews.com/media/sean-duffy-what-havent-we-had-shortage-under-biden)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 05:42:24+00:00

Guest host Sean Duffy discusses how Americans have experienced shortage after shortage under Biden's administration on "The Ingraham Angle."

## Jason Chaffetz: Questions about Biden's mental and physical health are not going away
 - [https://www.foxnews.com/media/jason-chaffetz-questions-about-bidens-mental-physical-health-not-going-away](https://www.foxnews.com/media/jason-chaffetz-questions-about-bidens-mental-physical-health-not-going-away)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 05:35:41+00:00

Jason Chaffetz discusses how President Biden's mental fitness is still in question as he turns 80 and how a presidential re-run is up in the air on "Hannity."

## Autistic Florida boy, 5, found dead in pond after wandering from home
 - [https://www.foxnews.com/us/autistic-florida-boy-5-found-dead-pond-after-wandering-from-home](https://www.foxnews.com/us/autistic-florida-boy-5-found-dead-pond-after-wandering-from-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 05:32:13+00:00

A young autistic boy was found dead in a pond on Thanksgiving after wandering from his Orlando, Florida, home the day before. He had been missing for about 12 hours.

## Hugh Grant reveals he hated filming his iconic 'Love Actually' dance scene: 'Excruciating'
 - [https://www.foxnews.com/entertainment/hugh-grant-reveals-hated-filming-iconic-love-actually-dance-scene-excruciating](https://www.foxnews.com/entertainment/hugh-grant-reveals-hated-filming-iconic-love-actually-dance-scene-excruciating)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 05:15:48+00:00

"Love Actually" star Hugh Grant revealed that he disliked filming his memorable dance scene in the beloved 2003 holiday movie.

## Albuquerque, New Mexico: Police-involved shooting leaves 1 dead
 - [https://www.foxnews.com/us/albuquerque-new-mexico-police-involved-shooting-leaves-1-dead](https://www.foxnews.com/us/albuquerque-new-mexico-police-involved-shooting-leaves-1-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 04:52:09+00:00

Three Albuquerque Police Department officers were placed on administrative leave following an officer-involved shooting at a home that left one person dead.

## Illinois police save drowning child in icy pond, mother says she thought her son 'was not going to be here'
 - [https://www.foxnews.com/us/illinois-police-save-drowning-child-icy-pond-mother-says-thought-son-was-not-going-be-here](https://www.foxnews.com/us/illinois-police-save-drowning-child-icy-pond-mother-says-thought-son-was-not-going-be-here)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 03:14:56+00:00

Illinois police officers saved a 9-year-old child who was drowning in a retention pond on Wednesday afternoon while trying to retrieve a football.

## 'Squid Game' star Oh Yeong-su indicted on sexual misconduct charges in South Korea: report
 - [https://www.foxnews.com/entertainment/squid-game-star-oh-yeong-su-indicted-sexual-misconduct-charges-south-korea-report](https://www.foxnews.com/entertainment/squid-game-star-oh-yeong-su-indicted-sexual-misconduct-charges-south-korea-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 03:07:13+00:00

Actor Oh Yeong-su was indicted on sexual misconduct charges. Oh, who won a Golden Globe for his performance in "Squid Game," has denied the allegations.

## Giants-Cowboys Thanksgiving matchup highlights historic day for NFL viewership
 - [https://www.foxnews.com/sports/giants-cowboys-thanksgiving-matchup-highlights-historic-day-nfl-viewership](https://www.foxnews.com/sports/giants-cowboys-thanksgiving-matchup-highlights-historic-day-nfl-viewership)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 02:57:30+00:00

The NFL broke numerous television records on Thanksgiving Day, including highest Thanksgiving audience and most people to watch a regular season game.

## Advocates ask NM court to reconsider electricity rate case
 - [https://www.foxnews.com/us/advocates-ask-nm-court-reconsider-electricity-rate-case](https://www.foxnews.com/us/advocates-ask-nm-court-reconsider-electricity-rate-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 02:55:49+00:00

The New Mexico attorney general and advocates filed motions requesting the state Supreme Court to reconsider a case allowing its largest energy provider to delay issuing rate credits.

## Florida police prevent 'mass casualty' event after stopping woman from driving car through 5K route
 - [https://www.foxnews.com/us/florida-police-prevent-mass-casualty-event-after-stopping-woman-driving-car-5k-route](https://www.foxnews.com/us/florida-police-prevent-mass-casualty-event-after-stopping-woman-driving-car-5k-route)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 02:50:07+00:00

Florida police allege that a 38-year-old woman was about to drive her car through a 5K route, which would have caused "mass casualty" to runners.

## Jodie Sweetin on possible 'Fuller House' reunion: 'Who knows what could happen'
 - [https://www.foxnews.com/entertainment/jodie-sweetin-possible-fuller-house-reunion](https://www.foxnews.com/entertainment/jodie-sweetin-possible-fuller-house-reunion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 02:37:42+00:00

Jodie Sweetin reveals whether there is a possibility of a "Fuller House" reboot, saying no one knows what is coming. John Stamos has said he won't return.

## Maryland gun store looted on Black Friday, thieves allegedly took 'long guns'
 - [https://www.foxnews.com/us/maryland-gun-store-looted-black-friday-thieves-allegedly-took-long-guns](https://www.foxnews.com/us/maryland-gun-store-looted-black-friday-thieves-allegedly-took-long-guns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 02:28:53+00:00

Maryland police are investigating after up to six people allegedly broke into a gun store and took "long guns" in the early morning hours of Black Friday.

## North Carolina mall shooting on Black Friday leaves 2 injured, police say
 - [https://www.foxnews.com/us/north-carolina-mall-shooting-black-friday-leaves-2-injured-police-say](https://www.foxnews.com/us/north-carolina-mall-shooting-black-friday-leaves-2-injured-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 02:21:03+00:00

A dispute on Black Friday resulted in a shooting that injured two people in a North Carolina shopping mall, police said, adding it doesn't "appear random."

## Ex-Tennessee coach Jeremy Pruitt admits to giving player’s mother cash-filled Chick-fil-A bag
 - [https://www.foxnews.com/sports/x-tennessee-coach-jeremy-pruitt-admits-to-giving-players-mother-400-chick-fil-a-paper-bag](https://www.foxnews.com/sports/x-tennessee-coach-jeremy-pruitt-admits-to-giving-players-mother-400-chick-fil-a-paper-bag)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 02:08:01+00:00

According to a report from the Knoxville News Sentinel, Pruitt told investigators that giving the player's mother cash was "the human thing, the right thing to do."

## RACHEL CAMPOS-DUFFY: Biden would prefer child labor in Africa, as opposed to good paying jobs in US
 - [https://www.foxnews.com/media/rachel-campos-duffy-biden-would-prefer-child-labor-africa-opposed-good-paying-jobs-us](https://www.foxnews.com/media/rachel-campos-duffy-biden-would-prefer-child-labor-africa-opposed-good-paying-jobs-us)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 01:50:01+00:00

Fox News' Rachel Campos-Duffy cracks down on President Biden and the Democrats' green energy agenda for encouraging child slave labor in Africa on 'Jesse Watters Primetime.'

## Mexican woman allegedly killed for her organs after online courtship gone bad
 - [https://www.foxnews.com/world/mexican-woman-allegedly-killed-organs-online-courtship-gone-bad](https://www.foxnews.com/world/mexican-woman-allegedly-killed-organs-online-courtship-gone-bad)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 01:29:49+00:00

Authorities in Peru believe the organs of a Mexican woman visiting a man she met online may have been harvested after her remains washed up on a beach.

## World Cup Daily: USA controls its fate after draw vs. England
 - [https://www.foxnews.com/sports/world-cup-daily-usa-controls-its-fate-draw-vs-england](https://www.foxnews.com/sports/world-cup-daily-usa-controls-its-fate-draw-vs-england)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 01:26:07+00:00

The United States' 0-0 tie against heavily-favored England headlined Friday's action at the World Cup in Qatar. Here's everything that went down in the Middle East.

## USA should get major confidence boost from 0-0 draw with England
 - [https://www.foxnews.com/sports/usa-should-get-major-confidence-boost-0-0-draw-england](https://www.foxnews.com/sports/usa-should-get-major-confidence-boost-0-0-draw-england)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 01:03:05+00:00

The USMNT came into Friday as heavy underdogs to England, but after coming away with a 0-0 draw, things are looking up for their must-win World Cup match on Tuesday.

## Idaho murders: Detectives, FBI return to crime scene where 4 university students were massacred in their sleep
 - [https://www.foxnews.com/us/idaho-murders-detectives-fbi-return-crime-scene-where-4-university-students-massacred-their-sleep](https://www.foxnews.com/us/idaho-murders-detectives-fbi-return-crime-scene-where-4-university-students-massacred-their-sleep)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 00:58:05+00:00

Police and FBI agents returned Friday to the Moscow home where four University of Idaho students were stabbed to death in their sleep earlier this month.

## Mariah Carey shares how her 'messed up' childhood led her to find joy in Christmas
 - [https://www.foxnews.com/entertainment/mariah-carey-shares-how-her-messed-up-childhood-led-her-find-joy-christmas](https://www.foxnews.com/entertainment/mariah-carey-shares-how-her-messed-up-childhood-led-her-find-joy-christmas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 00:48:30+00:00

Mariah Carey shared the story behind "All I Want For Christmas" in a new interview for the cover of W magazine. She also opened up about her difficult childhood.

## Family of Stanford soccer star who died by suicide files wrongful death lawsuit against school
 - [https://www.foxnews.com/sports/family-stanford-soccer-star-died-suicide-files-wrongful-death-lawsuit-school](https://www.foxnews.com/sports/family-stanford-soccer-star-died-suicide-files-wrongful-death-lawsuit-school)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 00:22:24+00:00

Nine months after Stanford Cardinal soccer star Katie Meyer committed suicide, her family has filed a wrongful death lawsuit against the school. Meyer died at the age of 22.

## NYPD officers captured on video saving man from oncoming subway train
 - [https://www.foxnews.com/us/nypd-officers-captured-video-saving-man-oncoming-train](https://www.foxnews.com/us/nypd-officers-captured-video-saving-man-oncoming-train)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 00:16:08+00:00

New York City police officers rushed to rescue a man who fell onto the subway tracks just before a train arrives at a Manhattan station.

## World Cup 2022: Saudi players gifted luxury cars after upsetting Argentina
 - [https://www.foxnews.com/sports/world-cup-2022-saudi-players-gifted-luxury-cars-upsetting-argentina](https://www.foxnews.com/sports/world-cup-2022-saudi-players-gifted-luxury-cars-upsetting-argentina)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-11-26 00:01:46+00:00

After a tremendous World Cup upset victory over Argentina, each player of the Saudi Arabia team was gifted a new Rolls Royce Phantom.


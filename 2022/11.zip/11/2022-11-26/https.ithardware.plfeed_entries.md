# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Procesory AMD Ryzen 9 7900 i Ryzen 7 7700 potwierdzone?
 - [https://ithardware.pl/aktualnosci/procesory_amd_ryzen_9_7900_i_ryzen_7_7700_potwierdzone-24546.html](https://ithardware.pl/aktualnosci/procesory_amd_ryzen_9_7900_i_ryzen_7_7700_potwierdzone-24546.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-26 21:31:10+00:00

<img src="https://ithardware.pl/artykuly/min/24546_1.jpg" />            Do sieci trafiły zrzuty ekranu potwierdzające istnienie&nbsp;procesor&oacute;w&nbsp;AMD Ryzen 9 7900 oraz Ryzen 7 7700. Oba układy zostały dostrzeżone jako podzespoły gotowych komputer&oacute;w od Lenovo. Modele bez &quot;X&quot; w nazwie oferują...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/procesory_amd_ryzen_9_7900_i_ryzen_7_7700_potwierdzone-24546.html">https://ithardware.pl/aktualnosci/procesory_amd_ryzen_9_7900_i_ryzen_7_7700_potwierdzone-24546.html</a></p>

## Steam z nowym rekordem jednocześnie aktywnych graczy
 - [https://ithardware.pl/aktualnosci/steam_z_nowym_rekordem_jednoczesnie_aktywnych_graczy-24547.html](https://ithardware.pl/aktualnosci/steam_z_nowym_rekordem_jednoczesnie_aktywnych_graczy-24547.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-26 20:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/24547_1.jpg" />            W październiku Steam ustanowił rekord 30 032 005 graczy&nbsp;jednoczesnych użytkownik&oacute;w. Ten wynik jest już jednak nieaktualny, a popularna platforma z grami przebiła kolejny poziom.

26 listopada o godzinie 14:00 na&nbsp;Steam było...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/steam_z_nowym_rekordem_jednoczesnie_aktywnych_graczy-24547.html">https://ithardware.pl/aktualnosci/steam_z_nowym_rekordem_jednoczesnie_aktywnych_graczy-24547.html</a></p>

## Wyciekły ceny nadchodzących procesorów 13. generacji Intela, w tym flagowego Core i9-13900KS
 - [https://ithardware.pl/aktualnosci/wyciekly_ceny_nadchodzacych_procesorow_13_generacji_intela_w_tym_flagowego_core_i9_13900ks-24545.html](https://ithardware.pl/aktualnosci/wyciekly_ceny_nadchodzacych_procesorow_13_generacji_intela_w_tym_flagowego_core_i9_13900ks-24545.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-26 18:12:30+00:00

<img src="https://ithardware.pl/artykuly/min/24545_1.jpg" />            W jednym z zagranicznych sklep&oacute;w dostrzeżono nadchodzące procesory 13. generacji Intela. Wśr&oacute;d nich odnajdziemy podstawowe modele, wersje bez układu graficznego oraz flagową jednostkę - Core i9-13900KS. Przy każdym z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wyciekly_ceny_nadchodzacych_procesorow_13_generacji_intela_w_tym_flagowego_core_i9_13900ks-24545.html">https://ithardware.pl/aktualnosci/wyciekly_ceny_nadchodzacych_procesorow_13_generacji_intela_w_tym_flagowego_core_i9_13900ks-24545.html</a></p>

## Epic Games Store ma rozdać wiele gier na święta
 - [https://ithardware.pl/aktualnosci/epic_games_store_ma_rozdac_wiele_gier_na_swieta-24544.html](https://ithardware.pl/aktualnosci/epic_games_store_ma_rozdac_wiele_gier_na_swieta-24544.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-26 17:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/24544_1.jpg" />            Epic Games Store szykuje prawdziwą gratkę dla wszystkich kolekcjoner&oacute;w darmowych gier. Platforma w grudniu ponownie rozda masę produkcji.

Jak twierdzi użytkownik o pseudonimie&nbsp;Billbil-kun, kt&oacute;ry od ponad roku udostępniał...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/epic_games_store_ma_rozdac_wiele_gier_na_swieta-24544.html">https://ithardware.pl/aktualnosci/epic_games_store_ma_rozdac_wiele_gier_na_swieta-24544.html</a></p>

## Intel Arc chłodzony cieczą? Dlaczego nie. EK dodało do oferty nowy blok wodny
 - [https://ithardware.pl/aktualnosci/intel_arc_chlodzony_ciecza_dlaczego_nie_ek_dodalo_do_oferty_nowy_blok_wodny-24543.html](https://ithardware.pl/aktualnosci/intel_arc_chlodzony_ciecza_dlaczego_nie_ek_dodalo_do_oferty_nowy_blok_wodny-24543.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-26 16:28:30+00:00

<img src="https://ithardware.pl/artykuly/min/24543_1.jpg" />            Firma EK rozszerzyła swoją ofertę komponent&oacute;w do chłodzenia cieczą o nowy blok wodny dla kart graficznych Intel Arc A750 oraz A770. Produkt wyceniono na 240 euro, co stanowi mniej więcej 69% wartości modelu Arc A750. Na stronie EK...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/intel_arc_chlodzony_ciecza_dlaczego_nie_ek_dodalo_do_oferty_nowy_blok_wodny-24543.html">https://ithardware.pl/aktualnosci/intel_arc_chlodzony_ciecza_dlaczego_nie_ek_dodalo_do_oferty_nowy_blok_wodny-24543.html</a></p>

## Xiaomi notuje spadek przychodów. Jak poradził sobie producent smartfonów ostatnim kwartale?
 - [https://ithardware.pl/aktualnosci/xiaomi_notuje_spadek_przychodow_jak_poradzil_sobie_producent_smartfonow_ostatnim_kwartale-24542.html](https://ithardware.pl/aktualnosci/xiaomi_notuje_spadek_przychodow_jak_poradzil_sobie_producent_smartfonow_ostatnim_kwartale-24542.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-26 14:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/24542_1.jpg" />            Xiaomi w ciągu ostatnich 10 lat stało się jedną z największych na świecie firm technologicznych. Po okresie wzrost&oacute;w nadeszły gorsze czasy, w kt&oacute;rych producent smartfon&oacute;w odnotował znaczny spadek przychod&oacute;w.

Jak...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/xiaomi_notuje_spadek_przychodow_jak_poradzil_sobie_producent_smartfonow_ostatnim_kwartale-24542.html">https://ithardware.pl/aktualnosci/xiaomi_notuje_spadek_przychodow_jak_poradzil_sobie_producent_smartfonow_ostatnim_kwartale-24542.html</a></p>

## Intel NUC 13 Extreme, czyli niewielki komputer mogący pomieścić RTX 4090
 - [https://ithardware.pl/aktualnosci/intel_nuc_13_extreme_czyli_niewielki_komputer_mogacy_pomiescic_rtx_4090-24541.html](https://ithardware.pl/aktualnosci/intel_nuc_13_extreme_czyli_niewielki_komputer_mogacy_pomiescic_rtx_4090-24541.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-26 12:43:40+00:00

<img src="https://ithardware.pl/artykuly/min/24541_1.jpg" />            Chiński serwis internetowy udostępnił recenzję najnowszego komputera z serii NUC od Intela. Model 13 Extreme wyposażono&nbsp;we flagowy procesor Raptor Lake i RTX 3080 Ti. Wewnątrz jest wystarczająco miejsca, aby pomieścić&nbsp;najwydajniejszą...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/intel_nuc_13_extreme_czyli_niewielki_komputer_mogacy_pomiescic_rtx_4090-24541.html">https://ithardware.pl/aktualnosci/intel_nuc_13_extreme_czyli_niewielki_komputer_mogacy_pomiescic_rtx_4090-24541.html</a></p>

## Test MSI MAG Z790 TOMAHAWK WIFI DDR4. Płyta główna do OC Core i9-13900K
 - [https://ithardware.pl/testyirecenzje/msi_mag_z790_tomahawk_wifi_ddr4_test_recenzja_opinia-24533.html](https://ithardware.pl/testyirecenzje/msi_mag_z790_tomahawk_wifi_ddr4_test_recenzja_opinia-24533.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-26 11:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/24533_1.jpg" />            MSI MAG Z790 TOMAHAWK WIFI DDR4 - test

Wraz z procesorami Raptor Lake zadebiutowały nowe płyty gł&oacute;wne na chipsecie Intel Z790 i rozpoczynając cykl im poświęcony, na pierwszy ogień poszła MSI MAG Z790 TOMAHAWK WIFI DDR4. Test ten...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/msi_mag_z790_tomahawk_wifi_ddr4_test_recenzja_opinia-24533.html">https://ithardware.pl/testyirecenzje/msi_mag_z790_tomahawk_wifi_ddr4_test_recenzja_opinia-24533.html</a></p>

## Poznaliśmy gry, które mogą trafić do Amazon Prime Gaming w grudniu
 - [https://ithardware.pl/aktualnosci/poznalismy_gry_ktore_moga_trafic_do_amazon_prime_gaming_w_grudniu-24540.html](https://ithardware.pl/aktualnosci/poznalismy_gry_ktore_moga_trafic_do_amazon_prime_gaming_w_grudniu-24540.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-11-26 10:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/24540_1.jpg" />            Do sieci wyciekła lista gier Amazon Prime Gaming, kt&oacute;re trafią do usługi w grudniu. Chociaż brakuje hit&oacute;w to z propozycji szczeg&oacute;lnie zadowoleni powinni być fani serii Fallout.

W Internecie pojawiła się lista gier...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/poznalismy_gry_ktore_moga_trafic_do_amazon_prime_gaming_w_grudniu-24540.html">https://ithardware.pl/aktualnosci/poznalismy_gry_ktore_moga_trafic_do_amazon_prime_gaming_w_grudniu-24540.html</a></p>


# Source:Forbs - innovation, URL:https://www.forbes.com/innovation/feed2, language:en-US

## Apple Is A Favorite For NFL Sunday Ticket, But Could YouTube TV Snag The Victory In The Last Minute?
 - [https://www.forbes.com/sites/johanmoreno/2022/11/26/apple-is-a-favorite-for-nfl-sunday-ticket-but-could-youtube-tv-snag-the-victory-in-the-last-minute/](https://www.forbes.com/sites/johanmoreno/2022/11/26/apple-is-a-favorite-for-nfl-sunday-ticket-but-could-youtube-tv-snag-the-victory-in-the-last-minute/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 22:51:27+00:00

Talks for the NFL Sunday Ticket sports rights package will likely extend into early next year, The New York Times reports.

## Claims That RSV Surge Due To Covid-19 Vaccines Take Clinical Trial Data Out Of Context
 - [https://www.forbes.com/sites/brucelee/2022/11/26/claims-that-rsv-surge-due-to-covid-19-vaccines-take-clinical-trial-data-out-of-context/](https://www.forbes.com/sites/brucelee/2022/11/26/claims-that-rsv-surge-due-to-covid-19-vaccines-take-clinical-trial-data-out-of-context/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 22:17:33+00:00

Here are what passages from the U.S. Food and Drug Administration (FDA) documents say about RSV and the Moderna and Pfizer-BioNTech Covid-19 mRNA vaccines.

## The New Edition Of Paranoia Looks More Perfect Than Ever
 - [https://www.forbes.com/sites/robwieland/2022/11/26/the-new-edition-of-paranoia-looks-more-perfect-than-ever/](https://www.forbes.com/sites/robwieland/2022/11/26/the-new-edition-of-paranoia-looks-more-perfect-than-ever/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 21:30:03+00:00

Paranoia breaks all the unwritten rules of role playing games and a few of the written ones. Everybody should play it at least once and a new edition is currently on Kickstarter.

## How To Lead Your Climatetech Startup Through Difficult Times
 - [https://www.forbes.com/sites/mariannelehnis/2022/11/26/how-to-lead-your-climatetech-startup-through-difficult-times/](https://www.forbes.com/sites/mariannelehnis/2022/11/26/how-to-lead-your-climatetech-startup-through-difficult-times/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 20:12:56+00:00

The world is still reeling from a global pandemic that continues to impact our physical and mental health.

## New ‘Overwatch 2’ Hero Ramattra’s Abilities Revealed, Including An Ultimate That Can Last Indefinitely
 - [https://www.forbes.com/sites/krisholt/2022/11/26/new-overwatch-2-hero-ramattras-abilities-revealed-including-an-ultimate-that-can-last-indefinitely/](https://www.forbes.com/sites/krisholt/2022/11/26/new-overwatch-2-hero-ramattras-abilities-revealed-including-an-ultimate-that-can-last-indefinitely/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 19:52:48+00:00

Ramattra has different abilities depending on whether he's in Omnic or Nemesis form.

## ‘Overwatch 2’ Ramattra Gameplay Trailer Shows The Transforming Tank In Action
 - [https://www.forbes.com/sites/krisholt/2022/11/26/overwatch-2-ramattra-gameplay-trailer-shows-the-transforming-tank-in-action/](https://www.forbes.com/sites/krisholt/2022/11/26/overwatch-2-ramattra-gameplay-trailer-shows-the-transforming-tank-in-action/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 18:14:04+00:00

The transforming omnic tank has two forms and it seems like he'll be a dominant presence on the battlefield.

## Apple’s Shock MacBook Pro Decision
 - [https://www.forbes.com/sites/ewanspence/2022/11/26/apple-macbook-pro-sale-discount-black-friday-decision/](https://www.forbes.com/sites/ewanspence/2022/11/26/apple-macbook-pro-sale-discount-black-friday-decision/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 16:45:52+00:00

The delay of the new MacBook Pro laptops into 2023 has led to something rarely seen in the Apple Store...

## LinkedIn Just Added A New Focused Inbox To Solve All Of Your Messaging Problems (Maybe)
 - [https://www.forbes.com/sites/johnbbrandon/2022/11/26/linkedin-just-added-a-new-focused-inbox-to-solve-all-of-your-messaging-problems-maybe/](https://www.forbes.com/sites/johnbbrandon/2022/11/26/linkedin-just-added-a-new-focused-inbox-to-solve-all-of-your-messaging-problems-maybe/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 16:44:37+00:00

I’m not sure when the marketing geniuses of the world figured out that LinkedIn was relatively pristine in comparison to other apps and worth plundering, but they have arrived and infiltrated this sacred space.

## Renault Tinkers With Strategic Plan As Talks About Nissan Alliance Continue
 - [https://www.forbes.com/sites/neilwinton/2022/11/26/renault-tinkers-with-strategic-plan-as-talks-about-nissan-alliance-continue/](https://www.forbes.com/sites/neilwinton/2022/11/26/renault-tinkers-with-strategic-plan-as-talks-about-nissan-alliance-continue/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 16:11:59+00:00

Renault CEO Luca de Meo’s “Renaulution” has been updated and the company split into 5. But investors worried about the future really need to know how the alliance with Nissan can be reformed.

## Grid Edge Infrastructure: Powering The Energy Transition
 - [https://www.forbes.com/sites/woodmackenzie/2022/11/26/grid-edge-infrastructure-powering-the-energy-transition/](https://www.forbes.com/sites/woodmackenzie/2022/11/26/grid-edge-infrastructure-powering-the-energy-transition/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 15:15:00+00:00

The distributed technologies and innovations known collectively as the grid edge will be integral to effectively powering an electrified world. So, where will the capital come from to fund it? And what role will utilities play in its future? Wood Mackenzie's Ben Hertz-Shargel takes a closer look.

## How The Skincare Industry Is Turning to Gene Editing in a Race Against Time
 - [https://www.forbes.com/sites/johncumbers/2022/11/26/how-the-skincare-industry-is-turning-to-gene-editing-in-a-race-against-time/](https://www.forbes.com/sites/johncumbers/2022/11/26/how-the-skincare-industry-is-turning-to-gene-editing-in-a-race-against-time/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 15:00:00+00:00

Skincare is a $100B market. But it's not always pretty: many cosmetic ingredients come from animals or rare plants. Synthetic biology is coming to the rescue once again by helping re-create those ingredients in industrial microbes.

## What Twitter Users Need To Know About Mastodon Security
 - [https://www.forbes.com/sites/daveywinder/2022/11/26/what-twitter-users-need-to-know-about-mastodon-security/](https://www.forbes.com/sites/daveywinder/2022/11/26/what-twitter-users-need-to-know-about-mastodon-security/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 14:00:00+00:00

Twitter users migrating to Mastodon must take these steps to secure their new social media account

## Higher CO2 Levels Could Result In Crops Having At Least 20% Less Protein
 - [https://www.forbes.com/sites/anuradhavaranasi/2022/11/26/higher-co2-levels-could-result-in-crops-having-at-least-20-less-protein/](https://www.forbes.com/sites/anuradhavaranasi/2022/11/26/higher-co2-levels-could-result-in-crops-having-at-least-20-less-protein/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 13:36:31+00:00

During the Anthropocene Epoch, human activities from burning fossil fuels are emitting greenhouse gasses like carbon dioxide at such an accelerated pace that it is negatively impacting plants’ mechanisms of acquiring nutrients from the soil, according to a recent study.

## Extreme E Final Champions How Uruguay Is Setting The Pace For Renewable Energy
 - [https://www.forbes.com/sites/jamesmorris/2022/11/26/extreme-e-final-champions-how-uruguay-is-setting-the-pace-for-renewable-energy/](https://www.forbes.com/sites/jamesmorris/2022/11/26/extreme-e-final-champions-how-uruguay-is-setting-the-pace-for-renewable-energy/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 13:08:49+00:00

The Extreme E final in Uruguay highlights the country's leading renewable energy portfolio, showing what is possible if a country achieves the political will to go green.

## These Researchers Describe Getting Emotionally Attached To Their Mars Rovers As Artemis Pushes NASA Forward
 - [https://www.forbes.com/sites/ariannajohnson/2022/11/26/these-researchers-describe-getting-emotionally-attached-to-their-mars-rovers-as-artemis-pushes-nasa-forward/](https://www.forbes.com/sites/ariannajohnson/2022/11/26/these-researchers-describe-getting-emotionally-attached-to-their-mars-rovers-as-artemis-pushes-nasa-forward/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 12:30:00+00:00

Three scientists and engineers from Forbes’ 30 Under 30 list have paved the way for Moon and Mars settlements with refueling stations and homemade oxygen–and made friends with robots along the way.

## ‘Trifox’ Review: A Debut Indie With A Winning Formula
 - [https://www.forbes.com/sites/mattgardner1/2022/11/26/trifox-review-a-debut-indie-with-a-winning-formula/](https://www.forbes.com/sites/mattgardner1/2022/11/26/trifox-review-a-debut-indie-with-a-winning-formula/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 12:08:08+00:00

Combining a popular 2022 indie trope with classic platform game influences, 'Trifox' offers a surprisingly complete debut for its studio.

## ‘Rocket League’ Hints At Season 9 Theme With ‘Fire And Ice’ Teaser
 - [https://www.forbes.com/sites/maxthielmeyer/2022/11/26/rocket-league-hints-at-season-9-theme-with-fire-and-ice-teaser/](https://www.forbes.com/sites/maxthielmeyer/2022/11/26/rocket-league-hints-at-season-9-theme-with-fire-and-ice-teaser/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 12:00:00+00:00

Rocket League Season 9 begins in less than two weeks and players have finally been given a clue for its theme.

## New iPhone 15 Exclusive Reveals Stunning Apple Design Decision
 - [https://www.forbes.com/sites/gordonkelly/2022/11/26/apple-iphone-15-pro-max-ultra-design-titanium-iphone-14-pro-max-upgrade/](https://www.forbes.com/sites/gordonkelly/2022/11/26/apple-iphone-15-pro-max-ultra-design-titanium-iphone-14-pro-max-upgrade/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 11:40:55+00:00

Apple's stunning redesign for the iPhone 15 has leaked...

## Unveiling Hidden Patterns And Connections In Emerging Technologies
 - [https://www.forbes.com/sites/paulxmccarthy/2022/11/26/unveiling-hidden-patterns-and-connections-in-emerging-technologies/](https://www.forbes.com/sites/paulxmccarthy/2022/11/26/unveiling-hidden-patterns-and-connections-in-emerging-technologies/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 11:15:04+00:00

In an increasingly global world, imagine if you could see where and when new ideas, business trends and even technologies first emerged in society and then explore how they spread over time and space.

## Today’s ‘Heardle’ Answer And Clues For Saturday, November 26
 - [https://www.forbes.com/sites/krisholt/2022/11/25/todays-heardle-answer-and-clues-for-saturday-november-26/](https://www.forbes.com/sites/krisholt/2022/11/25/todays-heardle-answer-and-clues-for-saturday-november-26/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 04:40:19+00:00

Here's today's 'Heardle' song, along with some hints.

## Today’s Wordle Saturday November 26th Hints, Clues And Answer Word Of The Day #525
 - [https://www.forbes.com/sites/erikkain/2022/11/25/todays-wordle-saturday-november-26th-hints-clues-and-answer-word-of-the-day-525/](https://www.forbes.com/sites/erikkain/2022/11/25/todays-wordle-saturday-november-26th-hints-clues-and-answer-word-of-the-day-525/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 03:30:00+00:00

How to solve today's Wordle.

## Today’s ‘Quordle’ Answers And Clues For Saturday, November 26
 - [https://www.forbes.com/sites/krisholt/2022/11/25/todays-quordle-answers-and-clues-for-saturday-november-26/](https://www.forbes.com/sites/krisholt/2022/11/25/todays-quordle-answers-and-clues-for-saturday-november-26/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-11-26 01:00:41+00:00

Some hints and the solution for today's 'Quordle' are just ahead.


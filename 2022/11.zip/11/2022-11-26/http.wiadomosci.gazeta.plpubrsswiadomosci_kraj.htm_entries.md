# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Słupsk. Podczas imprezy zginął 34-latek. Ojciec z zarzutem, sąsiadka podejrzana o zacieranie śladów
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29187245,slupsk-podczas-imprezy-zginal-34-latek-policja-zatrzymala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29187245,slupsk-podczas-imprezy-zginal-34-latek-policja-zatrzymala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-26 17:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e7/d5/1b/z29187559M,Klatka-schodowa---zdjecie-ilustracyjne.jpg" vspace="2" />W Słupsku - podczas imprezy w jednym z mieszkań - 34-latek został zraniony nożem i zmarł. Podejrzany o zabójstwo jest jego ojciec, który usłyszał już zarzuty. Przyznał się do winy, a najbliższe trzy miesiące spędzi w areszcie. Sąsiadka mężczyzn została z kolei oskarżona o zacieranie śladów.

## Częstochowa. Pobił pasażera w tramwaju. Policja prosi o pomoc w schwytaniu agresora [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29186698,czestochowa-zaatakowal-pasazera-w-tramwaju-policja-udostepnila.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29186698,czestochowa-zaatakowal-pasazera-w-tramwaju-policja-udostepnila.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-26 15:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1c/d5/1b/z29186844M,Poszukiwany-mezczyzna.jpg" vspace="2" />Częstochowska policja poszukuje sprawcy brutalnego pobicia, do którego doszło latem tego roku w jednym z tramwajów. By zwiększyć szanse na schwytanie mężczyzny, opublikowane zostało nagranie, na którym widać całe zdarzenie. Rozpoznajesz agresora? Powiadom policję!

## Wrocław. Wybuch na parkingu pod centrum handlowym. Nieoficjalnie: Ładunek umieszczony na nadkolu auta
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29186762,wroclaw-wybuch-na-parkingu-pod-centrum-handlowym-nieoficjalnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29186762,wroclaw-wybuch-na-parkingu-pod-centrum-handlowym-nieoficjalnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-26 14:49:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5e/98/1b/z28936798M,Straz-pozarna--zdjecie-ilustracyjne-.jpg" vspace="2" />Na parkingu pod centrum handlowym Marino we Wrocławiu doszło do wybuchu. Jak nieoficjalnie podaje "Gazeta Wrocławska", eksplodował ładunek wybuchowy umieszczony na nadkolu samochodu. Na miejscu pracują służby.

## Pogoda. Atak zimy i -20 stopni. "Zbliża się wyż znad Rosji". Synoptycy ostrzegają
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29186169,pogoda-atak-zimy-i-20-stopni-zbliza-sie-wyz-znad-rosji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29186169,pogoda-atak-zimy-i-20-stopni-zbliza-sie-wyz-znad-rosji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-26 14:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1d/d5/1b/z29186589M,Mroz-w-Polsce---prognoza-na-niedziele-4-12.jpg" vspace="2" />Przed nami kolejny atak zimy. Przełom listopada i grudnia może być mroźny, gdyż zbliża się do nas wyż kontynentalny znad Rosji. Synoptycy ostrzegają: temperatura moze spaść nawet do -20 stopni.

## Gdańsk. Natalka mieszkała z mamą w namiocie. Teraz zjawił się jej ojciec. "To ona uciekła ode mnie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29186025,gdansk-natalka-mieszkala-z-mama-w-namiocie-teraz-zjawil-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29186025,gdansk-natalka-mieszkala-z-mama-w-namiocie-teraz-zjawil-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-26 12:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f9/d2/1b/z29174777M,Kobieta-mieszkala-z-corka-w-namiocie-w-Gdansku.jpg" vspace="2" />Sprawa dwuletniej Natalki wyszła na jaw 21 listopada, gdy policjanci odkryli, że w namiocie rozstawionym na gdańskiej Zaspie mieszkają cztery osoby, w tym 24-letnia kobieta i jej dwuletnia córka. Po ujawnieniu tej historii nagle pojawił się ojciec Natalki, który nie miał kontaktu z dziewczynką od niemal roku.

## Abp Jędraszewski zrezygnował z zasiadania w radzie fundacji episkopatu. Powodem krytyczne publikacje
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29186000,abp-jedraszewski-zrezygnowal-z-zasiadania-w-radzie-fundacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29186000,abp-jedraszewski-zrezygnowal-z-zasiadania-w-radzie-fundacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-26 12:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3b/a2/1b/z28978491M.jpg" vspace="2" />Abp Marek Jędraszewski zrezygnował z członkostwa w Radzie Fundacji "Dzieło Nowego Tysiąclecia". "Jedna z pań redaktor od pewnego czasu jest łaskawa dość systematycznie krytykować moją skromną osobę" - stwierdził metropolita krakowski w piśmie, do którego dotarła "Więź".

## Andrzej Duda powołał radę bez kobiet. Konferencja rektorów reaguje
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29185906,andrzej-duda-powolal-rade-bez-kobiet-konferencja-rektorow-reaguje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29185906,andrzej-duda-powolal-rade-bez-kobiet-konferencja-rektorow-reaguje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-26 11:13:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f5/d2/1b/z29172213M,Prezydent-powolal-Rade-ds--Szkolnictwa-Wyzszego--N.jpg" vspace="2" />Konferencja Rektorów Akademickich Szkół Polskich zgłosiła Kancelarii Prezydenta "konieczność włączenia kobiet" w prace Rady ds. Szkolnictwa Wyższego, Nauki i Innowacji. Prezydent Andrzej Duda był w ostatnich dniach krytykowany, ponieważ w powołanej przez niego radzie nie ma ani jednej kobiety.

## Kolejna amerykańska baza w Polsce "działa od miesięcy". Nieoficjalnie: Potrzebna dla Ukrainy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29185888,kolejna-amerykanska-baza-w-polsce-dziala-od-miesiecy-nieoficjalnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29185888,kolejna-amerykanska-baza-w-polsce-dziala-od-miesiecy-nieoficjalnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-26 11:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d7/d4/1b/z29181399M,Wojna-w-Ukrainie---zdjecie-ilustracyjne.jpg" vspace="2" />"The New York Times" twierdzi, że Pentagon utworzył w Polsce nową bazę. Jej celem ma być remont haubic, które zostały przekazane Ukrainie przez Stany Zjednoczone. W wyniku intensywnych działań na froncie sprzęt ten zużywa się szybciej, niż zakładano.

## Akcja przed domem Jarosława Kaczyńskiego. Prezesowi PiS przypomniano niespełnione obietnice
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29185683,akcja-przed-domem-jaroslawa-kaczynskiego-prezesowi-pis-przypomniano.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29185683,akcja-przed-domem-jaroslawa-kaczynskiego-prezesowi-pis-przypomniano.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-11-26 09:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cb/d5/1b/z29185739M,Protest-przeciwnikow-futer-przed-domem-Jaroslawa-K.jpg" vspace="2" />Aktywiści zgromadzili się w piątek przed domem Jarosława Kaczyńskiego na warszawskim Żoliborzu. W Międzynarodowy Dzień Bez Futra przypomniano prezesowi PiS o jego projekcie, który miał doprowadzić m.in. do zakazu hodowli zwierząt na futro w Polsce. Projekt, w którego prace zaangażował się sam Kaczyński, został wycofany.


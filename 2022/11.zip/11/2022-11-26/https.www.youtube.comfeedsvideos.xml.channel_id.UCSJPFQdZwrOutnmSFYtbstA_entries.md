# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Avatar 2 - Will It Flop?
 - [https://www.youtube.com/watch?v=d0HHjJXmCIw](https://www.youtube.com/watch?v=d0HHjJXmCIw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-11-26 16:00:31+00:00

Avatar made quite a splash when it came out 13 years ago. But that was then, and this is now. And with the recent admission that the sequel, The Way of Water, needs to make at least $2 Billion just to break even, can this movie possibly hope to succeed? 

Link to Critical Drinker Plush: https://www.makeship.com/products/tcg-cyborg-plush


# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## FUTO charity repair/soldering workshops are open: come by and learn something!
 - [https://www.youtube.com/watch?v=l09zR4h4RWQ](https://www.youtube.com/watch?v=l09zR4h4RWQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-11-27 00:00:00+00:00

ADDRESS: 2410 San Antonio St, Austin, TX, 78705
TIMES OF WORKSHOPS: https://futo.org/workshops/ louis@futo.org
Want to try a microscope or soldering iron? COME ON BY! IT'S FREE!

These workshops are made possible by FUTO, learn more about FUTO here:
https://youtu.be/OJPmbcU-Vzo
https://youtu.be/xZ1rLq4OH8s
https://futo.org/what-is-futo/

👉 Post a message on screen http://bit.ly/postamessage 
👉 Stream FAQ: https://store.rossmanngroup.com/faq.txt
👉 Discord: https://tinyurl.com/rossmatrix
👉 Repair business: https://rossmanngroup.com
👉 Non-profit: https://fighttorepair.org

## I'm getting audited AGAIN: totally random 🤣
 - [https://www.youtube.com/watch?v=YvHt1Q3k-44](https://www.youtube.com/watch?v=YvHt1Q3k-44)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-11-27 00:00:00+00:00

👉 Workshops: https://futo.org/workshops/

👉 Rossmann chat - send Louis a letter: https://tinyurl.com/writetolouis
👉 Video references:
🔵 My audit ending: https://www.youtube.com/watch?v=nSlGTVInDOI
🔵 IRS auditing more poor people after promising to go after rich: https://www.youtube.com/watch?v=l8iaud11fGg
🔵 Karma for being mean to Paul: https://www.youtube.com/watch?v=HIdb8fU18oI

👉 Equipment used:
🔵 Chair: https://amzn.to/3MjLrnT
🔵 Microphone: https://amzn.to/3g1hsok
🔵 Mic stand: https://amzn.to/3Vg47ZI
🔵 Audio interface: https://amzn.to/3VuKihx
🔵 Camera: https://amzn.to/3CTk1Av (YOU CAN FIND THIS FOR $250 ON EBAY WITH A BROKEN FLASH FROM TIME TO TIME, I HAVE NEVER SPENT MORE THAN $300 ON THIS CAMERA!)
🔵 Lighting: https://amzn.to/3RSriGC

👉 Stream FAQ: https://store.rossmanngroup.com/faq.txt

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

00:00 Cat announcement
00:20 Disclaimer
00:35 My audit last year
01:22 I actually might've overpaid my corporate income tax...
02:30 It's not worth the time to go back and refile
03:05 Another audit :D
03:29 Promising to have auditors go after rich people...
04:00 Why I deserve this
05:10 I look forward to spending my salary on my CPA 
05:40 My dad's good advice
06:10 I might actually get money back from this
06:34 Public repair workshop schedule

## a random livestream
 - [https://www.youtube.com/watch?v=52vbtXwGXk4](https://www.youtube.com/watch?v=52vbtXwGXk4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-11-26 00:00:00+00:00

https://futo.org/workshops/

👉 Post a message on screen http://bit.ly/postamessage 
👉 Stream FAQ: https://store.rossmanngroup.com/faq.txt
👉 Discord: https://tinyurl.com/rossmatrix
👉 Repair business: https://rossmanngroup.com
👉 Non-profit: https://fighttorepair.org

🔵 Chair: https://amzn.to/3MjLrnT
🔵 Microphone: https://amzn.to/3g1hsok
🔵 Mic stand: https://amzn.to/3Vg47ZI
🔵 Audio interface: https://amzn.to/3VuKihx
🔵 Camera: https://amzn.to/3CTk1Av (YOU CAN FIND THIS FOR $250 ON EBAY WITH A BROKEN FLASH FROM TIME TO TIME, I HAVE NEVER SPENT MORE THAN $300 ON THIS CAMERA!)
🔵 Lighting: https://amzn.to/3RSriGC

👉 Stream FAQ: https://store.rossmanngroup.com/faq.txt

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ


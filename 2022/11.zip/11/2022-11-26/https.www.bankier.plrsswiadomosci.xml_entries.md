# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Kim Dzong Un: Celem Korei Północnej jest posiadanie najpotężniejszego arsenału nuklearnego na świecie
 - [https://www.bankier.pl/wiadomosc/Kim-Dzong-Un-Celem-Korei-Polnocnej-jest-posiadanie-najpotezniejszego-arsenalu-nuklearnego-na-swiecie-8446686.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kim-Dzong-Un-Celem-Korei-Polnocnej-jest-posiadanie-najpotezniejszego-arsenalu-nuklearnego-na-swiecie-8446686.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 22:37:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/8/178030c08dfae0-945-567-0-83-1755-1053.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przywódca Korei Płn. Kim Dzong Un oświadczył w sobotę, że finalnym celem Korei Płn. jest "posiadanie najpotężniejszego arsenału nuklearnego na świecie". Wygłosił to oświadczenie podczas uroczystości promowania oficerów pracujących przy programie nuklearnym na wyższe stopnie wojskowe.</p>

## USA łagodzą sankcje ws. embarga na ropę wobec Wenezueli
 - [https://www.bankier.pl/wiadomosc/USA-lagodza-sankcje-ws-embarga-na-rope-wobec-Wenezueli-8446677.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/USA-lagodza-sankcje-ws-embarga-na-rope-wobec-Wenezueli-8446677.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 21:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/2/050aed8cd8a158-948-568-0-90-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Stany Zjednoczone ogłosiły w sobotę złagodzenie embarga na ropę wobec Wenezueli w obliczu rosyjskiej izolacji, zaraz po ogłoszeniu podpisania porozumienia między rządzącym krajem Nicolasem  Maduro a opozycją, poinformowała AFP.</p>

## Jest zawiadomienie do prokuratury ws. dodatków węglowych
 - [https://www.bankier.pl/wiadomosc/Dodatki-weglowe-nieprzekazywane-w-terminie-Jest-zawiadomienie-do-prokuratury-8446676.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dodatki-weglowe-nieprzekazywane-w-terminie-Jest-zawiadomienie-do-prokuratury-8446676.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 21:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/3/12f714a13c3c67-948-567-0-32-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Skierowałem zawiadomienie do prokuratury w sprawie nieprzekazywania przez rząd w terminie dodatków węglowych - poinformował w sobotę wieczorem senator KO Krzysztof Brejza. Jego zdaniem setki osób oczekuje ponad dwa miesiące na wypłatę tych dodatków, nie mając za co kupić opału.</p>

## Chińczycy mają dość lockdownów; wyszli protestować na ulice. Kolejne rekordy zakażeń
 - [https://www.bankier.pl/wiadomosc/Chinczycy-maja-dosc-lockdownow-wyszli-protestowac-na-ulice-Kolejne-rekordy-zakazen-8446674.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chinczycy-maja-dosc-lockdownow-wyszli-protestowac-na-ulice-Kolejne-rekordy-zakazen-8446674.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 20:49:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/7/38f3c079ca2643-948-568-0-70-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Protesty przeciwko chińskiej polityce "zero covid", surowym restrykcjom i lockdownom wybuchły w sobotę w Pekinie, Szanghaju, Xianie, Nankinie i innych miastach Chin – wynika z relacji i nagrań zamieszczanych w mediach społecznościowych.</p>

## Gang Bystrzaków to nie tylko maskotki. Klienci Biedronki zaoszczędzili na akcji ponad 520 mln zł
 - [https://www.bankier.pl/wiadomosc/Gang-Bystrzakow-to-nie-tylko-maskotki-Klienci-Biedronki-zaoszczedzili-na-akcji-ponad-520-mln-zl-8443644.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gang-Bystrzakow-to-nie-tylko-maskotki-Klienci-Biedronki-zaoszczedzili-na-akcji-ponad-520-mln-zl-8443644.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/2/59b5faba2a9bc4-948-568-0-72-1807-1084.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Akcje lojalnościowe cieszą się w Biedronce dużym zainteresowaniem. Z karty Moja Biedronka, która daje dostęp do różnych promocji i rabatów, korzysta już 14 mln klientów. Co roku rekordy...</p>

## Oferował budowę drewnianych domów; wyłudził blisko 2,5 mln zł, nie płacił pracownikom i oszukał podwykonawców
 - [https://www.bankier.pl/wiadomosc/Oferowal-budowe-drewnianych-domow-wyludzil-blisko-2-5-mln-zl-nie-placil-pracownikom-i-oszukal-podwykonawcow-8444411.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Oferowal-budowe-drewnianych-domow-wyludzil-blisko-2-5-mln-zl-nie-placil-pracownikom-i-oszukal-podwykonawcow-8444411.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/d/723bf7a114ac2c-948-568-0-99-3072-1843.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Policjanci z Olkusza (Małopolskie) zatrzymali oszusta podejrzanego o wyłudzenie blisko 2,5 mln zł od inwestorów z całej Polski, którym oferował budowę drewnianych domów. Jego spółka wykonywała jedynie pierwszy etap prac budowlanych, a potem zaprzestawała działalności.</p>

## Błaszczak: Przeznaczamy największe w historii środki na modernizację wojska
 - [https://www.bankier.pl/wiadomosc/Blaszczak-Wydatki-Polski-na-obronnosc-wyniosa-3-proc-PKB-w-2023-roku-8446575.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Blaszczak-Wydatki-Polski-na-obronnosc-wyniosa-3-proc-PKB-w-2023-roku-8446575.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 10:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/e/6530282a86b318-948-568-0-276-4096-2457.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W 2023 roku wydatki Polski na obronność wyniosą 3 proc. PKB — powiedział w sobotę w Toruniu wicepremier, szef MON Mariusz Błaszczak. Podkreślił, że polską racją stanu jest wspieranie euroatlantyckich aspiracji Ukrainy i Gruzji.</p>

## Morgan Stanley: przychody europejskich banków nadal będą rosnąć. Pomagają podwyżki stóp proc.
 - [https://www.bankier.pl/wiadomosc/Morgan-Stanley-przychody-europejskich-bankow-nadal-beda-rosnac-Pomagaja-podwyzki-stop-proc-8446557.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Morgan-Stanley-przychody-europejskich-bankow-nadal-beda-rosnac-Pomagaja-podwyzki-stop-proc-8446557.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 09:38:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/5/67e6652e048bac-948-567-0-30-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wzrost europejskiego sektora bankowego wyniesie w przyszłym roku 8 proc. - informuje w najnowszej analizie bank inwestycyjny Morgan Stanley. Analitycy oceniają, że przychody banków będą rosły niezależnie od geopolitycznych zawirowań.</p>

## Premierzy Polski, Ukrainy i Litwy podpisali w Kijowie wspólną deklarację
 - [https://www.bankier.pl/wiadomosc/Premierzy-Polski-Ukrainy-i-Litwy-podpisali-w-Kijowie-wspolna-deklaracje-8446553.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Premierzy-Polski-Ukrainy-i-Litwy-podpisali-w-Kijowie-wspolna-deklaracje-8446553.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 09:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/d/d47954b3e1e12e-948-567-2-0-960-575.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Kijowie odbyło się w sobotę spotkanie Trójkąta Lubelskiego z udziałem szefów rządów Polski, Ukrainy i Litwy, podczas którego premierzy podpisali wspólną deklarację.</p>

## Polak "na pudełkach". Krajowy rynek cateringu dietetycznego wart ok. 2 mld zł i ciągle rośnie
 - [https://www.bankier.pl/wiadomosc/Polak-na-pudelkach-Krajowy-rynek-cateringu-dietetycznego-wart-ok-2-mld-zl-i-ciagle-rosnie-8441892.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polak-na-pudelkach-Krajowy-rynek-cateringu-dietetycznego-wart-ok-2-mld-zl-i-ciagle-rosnie-8441892.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/4/4d781791621c3e-948-568-0-67-1000-600.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ostatnie lata na polskim rynku przyniosły dynamiczny wzrost popularności cateringu dietetycznego. Według różnych badań „na pudełkach” regularnie jest od kilku do kilkudziesięciu procent Polaków. - Polska...</p>

## Rejestracja na spowiedź przez internet? Tak działa pierwsza w Polsce cyfrowa parafia
 - [https://www.bankier.pl/wiadomosc/Rejestracja-na-spowiedz-przez-internet-Tak-dziala-pierwsza-w-Polsce-cyfrowa-parafia-8445034.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rejestracja-na-spowiedz-przez-internet-Tak-dziala-pierwsza-w-Polsce-cyfrowa-parafia-8445034.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/2/54ac75241eebe6-899-539-0-29-899-539.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na poznańskiej Łacinie działa pierwsza w Polsce parafia z Biurem Parafialnym obsługiwanym cyfrowo. Przez internet można tu zamówić mszę św. wybierając datę w cyfrowym kalendarzu, zgłosić ślub lub dziecko do chrztu, czy też „umówić” się na spowiedź.</p>

## Szykuje się wakacyjna rewolucja? Pomysł wydłużenia wakacji na trzy miesiące i podzielenie na regiony
 - [https://www.bankier.pl/wiadomosc/Szykuje-sie-wakacyjna-rewolucja-Pomysl-wydluzenia-wakacji-na-trzy-miesiace-i-podzielenie-na-regiony-8445037.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szykuje-sie-wakacyjna-rewolucja-Pomysl-wydluzenia-wakacji-na-trzy-miesiace-i-podzielenie-na-regiony-8445037.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/4/38eb77c53be4c9-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pomysł rozłożenia wakacyjnych turnusów na trzy miesiące, zaproponowany przez Stowarzyszenia Gminy Górskich RP, to pomysł warty rozważenia i dyskusji, ale wymagałby korelacji kilku resortów – powiedział PAP wiceminister sportu i turystyki Andrzej Gut-Mostowy. Pomysł mocno popiera branża turystyczna.</p>

## Cyfrowy paszport i rozpoznawanie twarzy. Te linie lotnicze mają plan na zmniejszenie kolejek na lotnisku
 - [https://www.bankier.pl/wiadomosc/Cyfrowy-paszport-i-rozpoznawanie-twarzy-Te-linie-lotnicze-maja-plan-na-zmniejszenie-kolejek-na-lotnisku-8444586.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Cyfrowy-paszport-i-rozpoznawanie-twarzy-Te-linie-lotnicze-maja-plan-na-zmniejszenie-kolejek-na-lotnisku-8444586.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/8/812bc107fe1c88-948-568-0-141-1736-1041.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Holenderskie linie lotnicze KLM ogłosiły, że od przyszłego roku na lotnisku Schiphol w Amsterdamie wprowadzą specjalny cyfrowy paszport połączony z rozpoznawaniem twarzy podczas przechodzenia przez bramkę na lotnisku - informuje dziennik „De Telegraaf”. Nowy system ma pomóc w rozładowaniu kolejek.</p>

## Policja w Indiach oskarżyła szczury o zjedzenie blisko 200 kilogramów marihuany
 - [https://www.bankier.pl/wiadomosc/Policja-w-Indiach-oskarzyla-szczury-o-zjedzenie-blisko-200-kilogramow-marihuany-8445248.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Policja-w-Indiach-oskarzyla-szczury-o-zjedzenie-blisko-200-kilogramow-marihuany-8445248.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/3/bcdfe884abdbe2-948-568-0-112-2500-1499.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Policja w Indiach oskarżyła szczury o zjedzenie blisko 200 kilogramów marihuany skonfiskowanej handlarzom i przechowywanej na posterunkach - podał serwis BBC.</p>

## Motoryzacyjny Black Week - rabaty na auta potrafią zaskoczyć. Możemy spodziewać się też wyprzedaży rocznika w salonach
 - [https://www.bankier.pl/wiadomosc/Motoryzacyjny-Black-Week-rabaty-na-auta-potrafia-zaskoczyc-Mozemy-spodziewac-sie-tez-wyprzedazy-rocznika-w-salonach-8444339.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Motoryzacyjny-Black-Week-rabaty-na-auta-potrafia-zaskoczyc-Mozemy-spodziewac-sie-tez-wyprzedazy-rocznika-w-salonach-8444339.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/a/7fb275d204a3f5-948-568-0-0-1828-1096.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W tym roku powinna powrócić wyprzedaż rocznika w salonach samochodowych - przewidują eksperci Carsmile. Jak wskazali, place dealerskie nie są już puste, a z okazji Black Friday i "Black Week" trafiają się oferty z rabatem sięgającym od 7 proc. do nawet 35 proc.</p>

## Rekordowy spadek płac, inflacyjne nadzieje, monetarne harakiri i "efekt tequili"
 - [https://www.bankier.pl/wiadomosc/Rekordowy-spadek-plac-inflacyjne-nadzieje-monetarne-harakiri-i-efekt-tequili-8445907.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rekordowy-spadek-plac-inflacyjne-nadzieje-monetarne-harakiri-i-efekt-tequili-8445907.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/1/a1de3b050cebd1-948-568-0-101-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ostatni pełny tydzień listopada obfitował w interesujące wydarzenia ze świata gospodarki. Większość danych nie napawała co prawda większym optymizmem (chciałoby się powiedzieć: już tradycyjnie), jednak w tunelu widać też pojedyncze światełka. Wszystkie najciekawsze dane podsumowaliśmy w formie 10 wykresów.


</p>

## Sprzedam apartament 38 metrów w wielkiej płycie. Ale czy na pewno? Sprawdzamy, kiedy mieszkanie "zasługuje" na miano apartamentu
 - [https://www.bankier.pl/wiadomosc/Mieszkanie-a-apartament-Jakie-sa-roznice-8443272.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mieszkanie-a-apartament-Jakie-sa-roznice-8443272.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/3/6ae777bc9aa4f2-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sprzedający nieruchomości
zarówno na rynku pierwotnym, jak i wtórnym często tytułują swoje mieszkania
określeniem apartament. Eksperci portalu GetHome.pl postanowili sprawdzić, czy faktycznie
te lokale można uznać za apartamenty, czy jest to bardziej zabieg marketingowy,
który ma przyciągnąć klienta. Choć nigdzie nie ma zbioru przepisów określających,
czym jest apartament, możemy wskazać na kilka cech, które powinna
mieć taka nieruchomość.</p>

## Wysokie ceny materiałów budowlanych - które są najdroższe? "Bardziej opłaca się dekorować mieszkania, niż je budować"
 - [https://www.bankier.pl/wiadomosc/Wysokie-ceny-materialow-budowlanych-ktore-sa-najdrozsze-Bardziej-oplaca-sie-dekorowac-mieszkania-niz-je-budowac-8444392.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wysokie-ceny-materialow-budowlanych-ktore-sa-najdrozsze-Bardziej-oplaca-sie-dekorowac-mieszkania-niz-je-budowac-8444392.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/3/12eaf01144f382-948-568-0-101-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Obecna inflacja i kryzys energetyczny wpływa na każdą gałąź gospodarki kraju. Ich skutki dotykają zarówno indywidualne gospodarstwa domowe, jak i średnie i duże przedsiębiorstwa. Nie omijają także branży budowlanej. W związku z bardzo wysoką ceną materiałów budowlanych wiele inwestycji zostało zatrzymanych, a koszty budowy nowych domów przewyższają budżety kolejnych inwestorów oraz osób prywatnych. Czy kolejnymi ofiarami kryzysu staną się popularne sklepy budowlane?</p>

## W Chinach ponownie rekord zakażeń. Najwięcej przypadków od początku pandemii
 - [https://www.bankier.pl/wiadomosc/W-Chinach-ponownie-rekord-zakazen-Najwiecej-przypadkow-od-poczatku-pandemii-8446492.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-Chinach-ponownie-rekord-zakazen-Najwiecej-przypadkow-od-poczatku-pandemii-8446492.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 04:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/4/8fb57945f82b7e-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Chińskie władze zgłosiły w sobotę najwyższy bilans zakażeń koronawirusem od początku pandemii. Od trzech dni bilanse zakażeń w Chinach są wyższe niż w połowie kwietnia, gdy w zamieszkanym przez 25 mln osób Szanghaju obowiązywał surowy lockdown, który ostatecznie zniesiono dopiero po dwóch miesiącach.</p>

## Chińskie firmy w USA na cenzurowanym. Zakaz sprzedaży urządzeń zagrażających bezpieczeństwu narodowemu
 - [https://www.bankier.pl/wiadomosc/Chinskie-firmy-w-USA-na-cenzurowanym-Zakaz-sprzedazy-urzadzen-zagrazajacych-bezpieczenstwu-narodowemu-8446483.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chinskie-firmy-w-USA-na-cenzurowanym-Zakaz-sprzedazy-urzadzen-zagrazajacych-bezpieczenstwu-narodowemu-8446483.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-11-26 00:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/2/d390bd34e50d01-945-560-33-37-1466-879.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Administracja prezydenta Joe Bidena w piątek zakazała zatwierdzania sprzedaży nowych urządzeń telekomunikacyjnych chińskich firm Huawei Technologies, ZTE i kilku innych. Uzasadniła to stwarzaniem "nieakceptowalnego ryzyka" dla bezpieczeństwa narodowego USA.</p>


# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## EU probes TikTok, Tumblr ♥️ Fediverse, Fedora's new installer: Linux & Open Source News
 - [https://www.youtube.com/watch?v=yPMTL0BUcBc](https://www.youtube.com/watch?v=yPMTL0BUcBc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2022-11-26 00:00:00+00:00

Get 100$ credit for your own Linux and gaming server: https://www.linode.com/linuxexperiment 
Grab a brand new laptop or desktop running Linux:https://www.tuxedocomputers.com/en#


👏 SUPPORT THE CHANNEL:
Get access to a weekly podcast, vote on the next topics I cover, and get your name in the credits:

YouTube: https://www.youtube.com/channel/UC5UAwBUum7CPN5buc-_N1Fw/join
Patreon: https://www.patreon.com/thelinuxexperiment

Or, you can donate whatever you want: https://paypal.me/thelinuxexp?locale.x=fr_FR

🏆 FOLLOW ME ELSEWHERE:
Twitter : http://twitter.com/thelinuxEXP
Instagram: https://www.instagram.com/nick_thelinuxexp/
Mastodon: https://mastodon.social/web/@thelinuxEXP
Pixelfed: https://pixelfed.social/TLENick
I'm also on ODYSEE: https://odysee.com/$/invite/@TheLinuxExperiment:e
And on PEERTUBE: https://tilvids.com/c/thelinuxexperiment_channel/videos

This video is distributed under the Creative Commons Share Alike license.

#news #linux #opensource

00:00 Intro
00:50 Sponsor: 100$ free credit on your Linux or gaming server
01:49 The EU is looking into TikTok for GDPR breaches
03:25 Tumblr will join the Fediverse, Flickr thinking about it as well
05:04 Fedora reveals what their new installer looks like
06:36 WSL out of beta with GPU and graphical app support
07:52 iCloud on Windows has a major security problem
09:05 Cinnamon 5.6 polishes Mint's desktop environment
10:37 GNOME and KDE weekly updates
12:19 Nintendo goes after JPEGS, Steam Deck wins an award
13:53 Sponsor: Get a device that runs Linux perfectly with Tuxedo
14:58 Support the channel


The EU is looking into TikTok for GDPR breaches
https://www.engadget.com/tiktok-data-investigation-data-practices-161535147.html

https://ec.europa.eu/commission/presscorner/detail/en/IP_22_3823


Tumblr will join the Fediverse, Flickr thinking about it as well
https://techcrunch.com/2022/11/21/tumblr-to-add-support-for-activitypub-the-social-protocol-powering-mastodon-and-other-apps/

https://twitter.com/donmacaskill/status/1594945727255699457

https://www.youtube.com/watch?v=5npl2KCt2ok&t=427s

Fedora reveals what their new installer looks like
https://linuxiac.com/first-look-at-the-upcoming-fedora-web-based-installer/

WSL out of beta with GPU and graphical app support
https://news.itsfoss.com/wsl-stable-available/

iCloud on Windows has a major security problem
https://9to5mac.com/2022/11/21/icloud-for-windows-photos-videos-strangers/

Cinnamon 5.6 polishes Mint's desktop environment
https://blog.linuxmint.com/?p=4424

GNOME and KDE weekly updates
https://thisweek.gnome.org/posts/2022/11/twig-70/

https://pointieststick.com/2022/11/18/this-week-in-kde-less-rage-inducing-error-messages-in-discover/

https://invent.kde.org/plasma/plasma-welcome

Nintendo goes after JPEGS, Steam Deck wins an award
https://www.gamingonlinux.com/2022/11/nintendo-goes-after-steamgriddb-likely-for-people-doing-emulation-on-steam-deck/

https://linuxgamingcentral.com/posts/valve-introduces-proton-next/

https://www.gamingonlinux.com/2022/11/steam-deck-wins-best-gaming-hardware-at-the-40th-golden-joystick-awards/


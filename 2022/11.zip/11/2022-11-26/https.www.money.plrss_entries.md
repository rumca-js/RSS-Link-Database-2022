# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Regionalne sery, wina i drony. Tym Dolny Śląsk chce podbić Koreę
 - [https://www.money.pl/gospodarka/regionalne-sery-wina-i-drony-tym-dolny-slask-chce-podbic-koree-6837314002852512a.html](https://www.money.pl/gospodarka/regionalne-sery-wina-i-drony-tym-dolny-slask-chce-podbic-koree-6837314002852512a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-11-26 17:20:12+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d72aa909-1a24-4989-bb5d-1b666bf3cb04" width="308" /> Dwanaście firm z Dolnego Śląska, które tworzą m.in. innowacyjne aplikacje, zajmują się dronami, branżą kosmetyczną i produkują regionalne produkty, uczestniczy w misji gospodarczej w Seulu zorganizowanej przez samorząd województwa. Przedsiębiorcy wizytę w Korei chcą wykorzystać do promocji swoich produktów oraz nawiązania nowych, biznesowych kontaktów.

## Polacy u prywatnych lekarzy zostawiają miliardy. Grozi nam kryzys. Oto dlaczego
 - [https://www.money.pl/ubezpieczenia/polacy-u-prywatnych-lekarzy-zostawiaja-miliardy-grozi-nam-kryzys-oto-dlaczego-6837770137012896a.html](https://www.money.pl/ubezpieczenia/polacy-u-prywatnych-lekarzy-zostawiaja-miliardy-grozi-nam-kryzys-oto-dlaczego-6837770137012896a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-11-26 12:56:06+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/210d10f8-e0a6-487d-9a5a-aabd5cb5288c" width="308" /> - Niesprawny system publicznej ochrony zdrowia, brak wsparcia dla dodatkowych ubezpieczeń, rosnący dług zdrowotny, a także inflacja, fale uchodźców i wiele innych współczesnych nieszczęść to przepis na kryzys zdrowia w społeczeństwie - twierdzi Dorota M. Fal. Na kanwie tych problemów rośnie zainteresowanie prywatnymi ubezpieczeniami zdrowotnymi - takie ma co dziesiąty Polak.

## Czym jest depozyt notarialny?
 - [https://www.money.pl/gospodarka/czym-jest-depozyt-notarialny-6837783537416864a.html](https://www.money.pl/gospodarka/czym-jest-depozyt-notarialny-6837783537416864a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-11-26 12:52:15+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0701073-5f5e-485e-b5a9-26ca0630ddb9" width="308" /> Notariusz jest zawodem zaufania publicznego. Wykonuje go osoba z wykształceniem prawniczym, która pracuje w kancelarii notarialnej. Udajesz się do niej w celu np. zawarcia umowy kupna-sprzedaży nieruchomości lub dokonania upoważnienia innej osoby do czynności prawnych. Notariusze przyjmują jednak również specyficzne depozyty, nazywane depozytami notarialnymi. Czym one są i jaki jest ich koszt?

## W Chinach źle się dzieje. To jasny sygnał dla świata
 - [https://www.money.pl/gospodarka/w-chinach-zle-sie-dzieje-to-jasny-sygnal-dla-swiata-6838096277650112a.html](https://www.money.pl/gospodarka/w-chinach-zle-sie-dzieje-to-jasny-sygnal-dla-swiata-6838096277650112a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-11-26 10:04:57+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/08a47e0d-cd33-4da1-a27a-38ecc66eede6" width="308" /> Chiny poinformowały, że w sobotę zanotowano najwyższy od początku pandemii dzienny przyrost nowych zakażeń. Mowa o 35,2 tys. zakażeń. To więcej niż w trakcie ostrego lockdownu w kwietniu. To bardzo zło wieści dla światowych gospodarek.

## Mundial w liczbach. Oto dlaczego Mistrzostwa Świata w Katarze są najdroższe w historii
 - [https://www.money.pl/pieniadze/mundial-w-liczbach-oto-dlaczego-mistrzostwa-swiata-w-katarze-sa-najdrozsze-w-historii-6837055449098912a.html](https://www.money.pl/pieniadze/mundial-w-liczbach-oto-dlaczego-mistrzostwa-swiata-w-katarze-sa-najdrozsze-w-historii-6837055449098912a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-11-26 08:08:32+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e8d1eb5b-c70c-4d33-b3ae-0bd795ab6b8d" width="308" /> Jeszcze przed pierwszym gwizdkiem tegoroczny mundial został uznany za najdroższy w historii. Nieoficjalnie szacuje się, że na samą organizację i przygotowanie Mistrzostwa Świata w piłce nożnej Katar wydał około 220 mld dol. Ile kosztowała budowa infrastruktury, ile FIFA wypłaci tegorocznemu zwycięzcy, a ile sama spodziewa się zarobić? Dane na ten temat zebrał amerykański "Forbes".

## Czy diamenty inwestycyjne mają certyfikat?
 - [https://www.money.pl/gospodarka/czy-diamenty-inwestycyjne-maja-certyfikat-6837779086719680a.html](https://www.money.pl/gospodarka/czy-diamenty-inwestycyjne-maja-certyfikat-6837779086719680a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-11-26 07:27:15+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/172595c5-3db1-414f-8686-0c4582479f41" width="308" /> Kamienie szlachetne są piękne, trwałe, a przy tym stanowią ważny nośnik wartości. Inwestycje w takie aktywa pozwalają na zachowanie wartości pieniądza w czasie. Taką inwestycją mogą być diamenty. Gdzie je kupić i czym kierować się przy wyborze? Czy powinny mieć certyfikat?

## Nowy wzór formularza PIT-2. Resort finansów tłumaczy zmiany
 - [https://www.money.pl/podatki/nowy-wzor-formularza-pit-2-resort-finansow-tlumaczy-zmiany-6838054820027040a.html](https://www.money.pl/podatki/nowy-wzor-formularza-pit-2-resort-finansow-tlumaczy-zmiany-6838054820027040a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-11-26 07:16:16+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c2d248c7-7177-4b46-a4eb-35e8f7222d97" width="308" /> Ministerstwo Finansów opublikowało nowe wzory formularzy PIT-2, PIT-2A i PIT-3 - poinformował w piątek resort. Trwają prace nad objaśnieniami regulacji, zawartych w ustawie "Niskie Podatki", dotyczących zasad poboru zaliczek na podatek przez płatników PIT - dodało MF.

## Nie dzwoń i nie pisz do zajętych ludzi w poniedziałek rano. 5 porad dotyczących kariery od milionera
 - [https://www.money.pl/pieniadze/nie-dzwon-i-nie-pisz-do-zajetych-ludzi-w-poniedzialek-rano-5-porad-dotyczacych-kariery-od-milionera-6837818369178304a.html](https://www.money.pl/pieniadze/nie-dzwon-i-nie-pisz-do-zajetych-ludzi-w-poniedzialek-rano-5-porad-dotyczacych-kariery-od-milionera-6837818369178304a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-11-26 06:37:48+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b2b37f6f-122a-42f5-beac-91e940194421" width="308" /> "Kolejne pokolenia, nieważne czy stare, czy młode, są bardzo różne, ale podstawowe zasady dotyczące sukcesu pozostają te same" - twierdzi John Spooner, amerykański doradca finansowy, milioner i autor książek o finansach. Spooner w CNBC dał kilka porad dotyczących pieniędzy i kariery, które jego zdaniem powinien przyswoić każdy młody człowiek.


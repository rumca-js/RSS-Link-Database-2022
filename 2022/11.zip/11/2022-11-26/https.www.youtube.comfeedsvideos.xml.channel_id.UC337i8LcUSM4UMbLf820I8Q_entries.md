# Source:Just Some Guy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC337i8LcUSM4UMbLf820I8Q, language:en-US

## Strange World: A Predictable Flop
 - [https://www.youtube.com/watch?v=mQER0RebFCY](https://www.youtube.com/watch?v=mQER0RebFCY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC337i8LcUSM4UMbLf820I8Q
 - date published: 2022-11-26 04:02:30+00:00

Strange World: A Predictable Flop
----------------------------------------------------------------------------------------------
Art by Just Some Guy

Original trailer concept: Bleach Opening 01

Music: "Enkon Hakuchuumu" by Sakagami Souichi - Copyright (C) 2015 Trial & Error/Sakagami Souichi All rights reserved.

Trial & Error: http://www.tandess.com/en/music/


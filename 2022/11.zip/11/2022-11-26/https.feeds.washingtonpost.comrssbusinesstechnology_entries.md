# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Crypto company stunt brings giant Musk ‘Goat’ statue to Tesla factory
 - [https://www.washingtonpost.com/technology/2022/11/26/elon-musk-cryptocurrency-goat-statue/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/11/26/elon-musk-cryptocurrency-goat-statue/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-11-26 22:55:11+00:00

Elon GOAT Token, a cryptocurrency company, commissioned the statue with the goal of billionaire Elon Musk accepting it and bringing exposure to its token

## Would you buy a made-in-China electric car? They’re coming.
 - [https://www.washingtonpost.com/technology/2022/11/26/polestar-china-ev/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/11/26/polestar-china-ev/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-11-26 06:00:17+00:00

China is already a major manufacturer of electric vehicles for its own market. Now it's starting to export to the U.S. and Europe.

